---
url: "https://www.docomo.ne.jp/charge/promotion/eraberu/"
title: "ドコモで選べる料金プラン | 料金・割引 | NTTドコモ"
---

[![NTT docomo](https://www.docomo.ne.jp/images_osp/common/newhf/header/cmn-rwd-header-logo.svg?ver=1751324418)](https://www.docomo.ne.jp/?icid=CRP_common_header_to_CRP_TOP)

- [![別ウィンドウで開きます。my docomo](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-my-docomo-logo.svg)](https://www.docomo.ne.jp/mydocomo/?icid=CRP_outerhead_to_MYD_TOP)
- [![別ウィンドウで開きます。Online Shop](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-online-shop-icon2.svg)](https://onlineshop.docomo.ne.jp/top-ols/?xcid=OLS_TOP_from_CRP_outerhead)

- 商品・サービス












- モバイル
  - [iPhone](https://www.docomo.ne.jp/iphone/?icid=CRP_menu_to_CRP_IPH)

  - [iPad](https://www.docomo.ne.jp/ipad/?icid=CRP_menu_to_CRP_IPA)

  - [製品](https://www.docomo.ne.jp/product/?icid=CRP_menu_to_CRP_PRD)

  - [料金・割引](https://www.docomo.ne.jp/charge/?icid=CRP_menu_to_CRP_CHA)

  - [サービス・機能](https://www.docomo.ne.jp/service/?icid=CRP_menu_to_CRP_SER)

  - [通信・エリア](https://www.docomo.ne.jp/area/?icid=CRP_menu_to_CRP_AREA)
- インターネット回線・固定電話
  - [インターネット回線・固定電話トップ](https://www.docomo.ne.jp/internet/?icid=CRP_menu_to_CRP_INT)

  - [ドコモ光](https://www.docomo.ne.jp/internet/hikari/?icid=CRP_menu_to_CRP_INT_hikari)

  - [ahamo光](https://www.docomo.ne.jp/internet/ahamo_hikari/?icid=CRP_menu_to_CRP_internet_ahamo_hikari)

  - [home 5G](https://www.docomo.ne.jp/home_5g/?icid=CRP_menu_to_CRP_HOM)

  - [homeでんわ](https://www.docomo.ne.jp/home_denwa/?icid=CRP_menu_to_CRP_DENWA)
- スマートライフ
  - [スマートライフ トップ](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_menu_to_CRP_SER_smart-life)

  - [決済・保険・投資](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_menu_to_CRP_SER_smart-life_finance&tgl_entertainment=0&tgl_life-support=0&tgl_finance=1&tgl_shopping=0&tgl_healthcare=0#finance)

  - [エンターテインメント](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_menu_to_CRP_SER_smart-life_entertainment&tgl_entertainment=1&tgl_life-support=0&tgl_finance=0&tgl_shopping=0&tgl_healthcare=0#entertainment)

  - [ライフサポート](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_menu_to_CRP_SER_smart-life_life-support&tgl_entertainment=0&tgl_life-support=1&tgl_finance=0&tgl_shopping=0&tgl_healthcare=0#life-support)

  - [ショッピング](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_menu_to_CRP_SER_smart-life_shopping&tgl_entertainment=0&tgl_life-support=0&tgl_finance=0&tgl_shopping=1&tgl_healthcare=0#shopping)

  - [ヘルスケア](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_menu_to_CRP_SER_smart-life_healthcare&tgl_entertainment=0&tgl_life-support=0&tgl_finance=0&tgl_shopping=0&tgl_healthcare=1#healthcare)
- 電気・ガス
  - [ドコモでんき／\\
      \\
      ドコモ ガス トップ](https://www.docomo.ne.jp/denki/?icid=CRP_menu_to_CRP_DENKI)

- お知らせ














- [お知らせトップ](https://www.docomo.ne.jp/info/?icid=CRP_menu_to_CRP_INFO)

- [ニュースルーム](https://www.docomo.ne.jp/info/update/?icid=CRP_menu_to_CRP_INFO_update)

- [報道発表](https://www.docomo.ne.jp/info/news_release/?icid=CRP_menu_to_CRP_INFO_news_release)

- [重要なお知らせ（通信障害）](https://www.docomo.ne.jp/info/network/?icid=CRP_menu_to_CRP_INFO_network)

- [携帯電話サービスの通信状況（地域別）](https://www.docomo.ne.jp/info/status/?icid=CRP_menu_to_CRP_INFO_status)

- [工事のお知らせ](https://www.docomo.ne.jp/info/construction/?icid=CRP_menu_to_CRP_INFO_construction)


- 企業情報














- [企業情報トップ](https://www.docomo.ne.jp/corporate/?icid=CRP_menu_to_CRP_CORP)

- [あなたとドコモ](https://www.docomo.ne.jp/corporate/anatatodocomo/?icid=CRP_menu_to_CRP_CORP_anatatodocomo)

- [企業理念・ビジョン](https://www.docomo.ne.jp/corporate/philosophy_vision/?icid=CRP_menu_to_CRP_CORP_philosophy_vision)

- [会社案内](https://www.docomo.ne.jp/corporate/about/?icid=CRP_menu_to_CRP_CORP_about)

- [サステナビリティ](https://www.docomo.ne.jp/corporate/csr/?icid=CRP_menu_to_CRP_CORP_csr)

- [技術とあんしん](https://www.docomo.ne.jp/corporate/technology_safety/?icid=CRP_menu_to_CRP_CORP_technology_safety)

- [IR情報](https://www.docomo.ne.jp/corporate/ir/library/?icid=CRP_menu_to_CRP_CORP_ir_library)

- [採用情報](https://www.docomo.ne.jp/corporate/recruit/?icid=CRP_menu_to_CRP_CORP_recruit)

- [NTTドコモグループ _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://nttdocomo-group.com/index.html)


- 法人のお客さま














- [NTTドコモビジネス _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.ntt.com/index.html)

- [NTTドコモ\\
\\
ソリューションズ _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.nttcom.co.jp/)

- [NTTドコモ・グローバル](https://www.docomo.ne.jp/global/?icid=CRP_TOP_to_CRP_global)


- [![別ウィンドウで開きます。my docomo](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-my-docomo-logo.svg)](https://www.docomo.ne.jp/mydocomo/?icid=CRP_outerhead_to_MYD_TOP)



[![別ウィンドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-online-shop-icon.svg)\\
Online Shop](https://onlineshop.docomo.ne.jp/top-ols/?xcid=OLS_TOP_from_CRP_outerhead)



[![別ウィンドウで開きます。のりかえ（MNP）](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-online-mnp-icon_pc.png)](https://onlineshop.docomo.ne.jp/special-contents/mnp?xcid=OLS_special-contents_mnp_flow_from_CRP_TOP_mnp_btn)



[![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-switch-online-icon.svg)機種変更](https://www.docomo.ne.jp/support/switch_online/?icid=CRP_outerhead_to_SUP_switch_online)


[![](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-daccount-logo.svg)\\
ログインする](https://cfg.smt.docomo.ne.jp/auth/cgi/anidlogin?rl=https%3A%2F%2Fwww.docomo.ne.jp%2Fcharge%2Fpromotion%2Feraberu%2F)

[![dポイントクラブ](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-d-point-club-logo.svg)\\
\\
P\\
\\
![ランク](https://www.docomo.ne.jp/charge/promotion/eraberu/)](https://www.docomo.ne.jp/charge/promotion/eraberu/) [![ドコモビジネスメンバーズ](https://www.docomo.ne.jp/images_osp/common/newhf/ico/ico_businessmembers.png)](https://www.docomo.ne.jp/charge/promotion/eraberu/)

MENU

[![NTT docomo](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-header-logo.svg?ver=1751324418)](https://www.docomo.ne.jp/?icid=CRP_drawer_to_CRP_TOP)

[English](https://www.docomo.ne.jp/english/?icid=CRP_drawer_to_CRP_EN)

* * *

![検索する](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-header-search-icon.svg)

- [![](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-my-docomo-logo.svg)My docomo _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.docomo.ne.jp/mydocomo/?icid=CRP_drawer_to_MYD_TOP)
- [![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-online-shop-icon.svg)Online Shop _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://onlineshop.docomo.ne.jp/top-ols/?xcid=OLS_TOP_from_CRP_drawer)
- [![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-docomo-shop-icon.svg)ドコモショップ _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://shop.smt.docomo.ne.jp/?xcid=DS_TOP_from_CRP_drawer)
- [![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-customer-support-icon.svg)お客さまサポート](https://www.docomo.ne.jp/support/?icid=CRP_drawer_sup01_to_CRP_SUP)
- [![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-campaign-icon.svg)キャンペーン・特典](https://www.docomo.ne.jp/campaign_event/?icid=CRP_drawer_to_CRP_CAM)
- [![](https://www.docomo.ne.jp/assets/content/dam/corp/jp/ja/common/images/logo/cmn-rwd-d-point-club-logo.svg)dポイントクラブ _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://dpoint.docomo.ne.jp/)

- 商品・サービス
  - ![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/ico_mobile.png)モバイル



- [iPhone](https://www.docomo.ne.jp/iphone/?icid=CRP_drawer_to_CRP_IPH)
- [iPad](https://www.docomo.ne.jp/ipad/?icid=CRP_drawer_to_CRP_IPA)
- [製品](https://www.docomo.ne.jp/product/?icid=CRP_drawer_to_CRP_PRD)
- [料金・割引](https://www.docomo.ne.jp/charge/?icid=CRP_drawer_to_CRP_CHA)
- [サービス・機能](https://www.docomo.ne.jp/service/?icid=CRP_drawer_to_CRP_SER)
- [通信・エリア](https://www.docomo.ne.jp/area/?icid=CRP_drawer_to_CRP_AREA)

  - ![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/ico_internet.png)インターネット回線・固定電話



- [インターネット回線・固定電話トップ](https://www.docomo.ne.jp/internet/?icid=CRP_drawer_to_CRP_INT)
- [ドコモ光](https://www.docomo.ne.jp/internet/hikari/?icid=CRP_drawer_to_CRP_INT_hikari)
- [ahamo光](https://www.docomo.ne.jp/internet/ahamo_hikari/?icid=CRP_drawer_to_CRP_internet_ahamo_hikari)
- [home 5G](https://www.docomo.ne.jp/home_5g/?icid=CRP_drawer_to_CRP_HOM)
- [homeでんわ](https://www.docomo.ne.jp/home_denwa/?icid=CRP_drawer_to_CRP_DENWA)

  - ![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/ico_smartlife.png)スマートライフ



- [スマートライフ トップ](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_drawer_to_CRP_SER_smart-life)
- [決済・保険・投資](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_drawer_to_CRP_SER_smart-life_finance&tgl_entertainment=0&tgl_life-support=0&tgl_finance=1&tgl_shopping=0&tgl_healthcare=0#finance)
- [エンターテインメント](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_drawer_to_CRP_SER_smart-life_entertainment&tgl_entertainment=1&tgl_life-support=0&tgl_finance=0&tgl_shopping=0&tgl_healthcare=0#entertainment)
- [ライフサポート](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_drawer_to_CRP_SER_smart-life_life-support&tgl_entertainment=0&tgl_life-support=1&tgl_finance=0&tgl_shopping=0&tgl_healthcare=0#life-support)
- [ショッピング](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_drawer_to_CRP_SER_smart-life_shopping&tgl_entertainment=0&tgl_life-support=0&tgl_finance=0&tgl_shopping=1&tgl_healthcare=0#shopping)
- [ヘルスケア](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_drawer_to_CRP_SER_smart-life_healthcare&tgl_entertainment=0&tgl_life-support=0&tgl_finance=0&tgl_shopping=0&tgl_healthcare=1#healthcare)

  - ![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/ico_denki.png?ver=1748827032)電気・ガス



- [ドコモでんき／\\
\\
ドコモ ガス トップ](https://www.docomo.ne.jp/denki/?icid=CRP_drawer_to_CRP_DENKI)
- お知らせ
  - お知らせ

- [お知らせ トップ](https://www.docomo.ne.jp/info/?icid=CRP_drawer_to_CRP_INFO)
- [ニュースルーム](https://www.docomo.ne.jp/info/update/?icid=CRP_drawer_to_CRP_INFO_update)
- [報道発表](https://www.docomo.ne.jp/info/news_release/?icid=CRP_drawer_to_CRP_INFO_news_release)
- [重要なお知らせ（通信障害）](https://www.docomo.ne.jp/info/network/?icid=CRP_drawer_to_CRP_INFO_network)
- [携帯電話サービスの通信状況（地域別）](https://www.docomo.ne.jp/info/status/?icid=CRP_drawer_to_CRP_INFO_status)
- [工事のお知らせ](https://www.docomo.ne.jp/info/construction/?icid=CRP_drawer_to_CRP_INFO_construction)
- 企業情報
  - 企業情報

- [企業情報 トップ](https://www.docomo.ne.jp/corporate/?icid=CRP_drawer_to_CRP_CORP)
- [あなたとドコモ](https://www.docomo.ne.jp/corporate/anatatodocomo/?icid=CRP_drawer_to_CRP_CORP_anatatodocomo)
- [企業理念・ビジョン](https://www.docomo.ne.jp/corporate/philosophy_vision/?icid=CRP_drawer_to_CRP_CORP_philosophy_vision)
- [会社案内](https://www.docomo.ne.jp/corporate/about/?icid=CRP_drawer_to_CRP_CORP_about)
- [サステナビリティ](https://www.docomo.ne.jp/corporate/csr/?icid=CRP_drawer_to_CRP_CORP_csr)
- [技術とあんしん](https://www.docomo.ne.jp/corporate/technology_safety/?icid=CRP_drawer_to_CRP_CORP_technology_safety)
- [IR情報](https://www.docomo.ne.jp/corporate/ir/library/?icid=CRP_drawer_to_CRP_CORP_ir_library)
- [採用情報](https://www.docomo.ne.jp/corporate/recruit/?icid=CRP_drawer_to_CRP_CORP_recruit)
- [NTTドコモグループ _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://nttdocomo-group.com/index.html)
- 地域別情報

- [北海道](https://www.docomo.ne.jp/hokkaido/?icid=CRP_drawer_to_hokkaido)
- [東北](https://www.docomo.ne.jp/tohoku/?icid=CRP_drawer_to_tohoku)
- [関東・甲信越](https://www.docomo.ne.jp/kanto/?icid=CRP_drawer_to_kanto)
- [東海](https://www.docomo.ne.jp/tokai/?icid=CRP_drawer_to_tokai)
- [北陸](https://www.docomo.ne.jp/hokuriku/?icid=CRP_drawer_to_hokuriku)
- [関西](https://www.docomo.ne.jp/kansai/?icid=CRP_drawer_to_kansai)
- [中国](https://www.docomo.ne.jp/chugoku/?icid=CRP_drawer_to_chugoku)
- [四国](https://www.docomo.ne.jp/shikoku/?icid=CRP_drawer_to_shikoku)
- [九州・沖縄](https://www.docomo.ne.jp/kyushu/?icid=CRP_drawer_to_kyushu)

- 地域別情報



- [北海道](https://www.docomo.ne.jp/hokkaido/?icid=CRP_drawer_to_hokkaido) \|
- [東北](https://www.docomo.ne.jp/tohoku/?icid=CRP_drawer_to_tohoku) \|
- [関東・甲信越](https://www.docomo.ne.jp/kanto/?icid=CRP_drawer_to_kanto) \|
- [東海](https://www.docomo.ne.jp/tokai/?icid=CRP_drawer_to_tokai) \|
- [北陸](https://www.docomo.ne.jp/hokuriku/?icid=CRP_drawer_to_hokuriku) \|
- [関西](https://www.docomo.ne.jp/kansai/?icid=CRP_drawer_to_kansai) \|
- [中国](https://www.docomo.ne.jp/chugoku/?icid=CRP_drawer_to_chugoku) \|
- [四国](https://www.docomo.ne.jp/shikoku/?icid=CRP_drawer_to_shikoku) \|
- [九州・沖縄](https://www.docomo.ne.jp/kyushu/?icid=CRP_drawer_to_kyushu)
- 法人のお客さま

- [NTTドコモビジネス _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.ntt.com/index.html)
- [NTTドコモソリューションズ _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.nttcom.co.jp/)
- [NTTドコモ・グローバル](https://www.docomo.ne.jp/global/?icid=CRP_drawer_to_CRP_global)

- 法人のお客さま



- [NTTドコモビジネス _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.ntt.com/index.html) \|
- [NTTドコモソリューションズ _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.nttcom.co.jp/) \|
- [NTTドコモ・グローバル](https://www.docomo.ne.jp/global/?icid=CRP_drawer_to_CRP_global)

ログインすると

ポイント・ランク情報が確認できます

[![](https://www.docomo.ne.jp/assets/content/dam/corp/jp/ja/common/images/logo/cmn-rwd-d-point-club-logo.svg)dアカウントにログインする](https://cfg.smt.docomo.ne.jp/auth/cgi/anidlogin?rl=https%3A%2F%2Fwww.docomo.ne.jp)

- [dアカウントでもっと便利に](https://www.docomo.ne.jp/utility/daccount/?icid=CRP_drawer_to_CRP_UTI_daccount)
- [別のIDでログイン](https://cfg.smt.docomo.ne.jp/auth/cgi/anidlogin?rl=https%3A%2F%2Fwww.docomo.ne.jp%2F)
- [ログアウト](https://www.docomo.ne.jp/mydocomo/utility/confirm_logout/index.html)
- [会員情報確認・変更 _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon-white.svg)_](https://profile.smt.docomo.ne.jp/VIEW_ESITE/mem/sc/main.jsp?nid=MEG002006BJP)
- [ログインでお困りの方 _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon-white.svg)_](https://id.smt.docomo.ne.jp/src/utility/idpw_forget.html)
- [２段階認証のお願い _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon-white.svg)_](https://id.smt.docomo.ne.jp/src/utility/sp/twostepauth.html)

オートログイン中

[![ランク](https://www.docomo.ne.jp/charge/promotion/eraberu/#)](https://dpoint.docomo.ne.jp/member/stage_info/index.html)

* * *

[うち期間・用途限定](https://www.docomo.ne.jp/charge/promotion/eraberu/)

* * *

[![ドコモビジネスメンバーズ](https://www.docomo.ne.jp/images_osp/common/newhf/ico/ico_businessmembers.png)](https://www.docomo.ne.jp/charge/promotion/eraberu/)

- [別のIDでログイン](https://cfg.smt.docomo.ne.jp/auth/cgi/anidlogin?rl=https%3A%2F%2Fwww.docomo.ne.jp%2F)
- [ログアウト](https://www.docomo.ne.jp/mydocomo/utility/confirm_logout/index.html)
- [会員情報確認・変更 _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon-white.svg)_](https://profile.smt.docomo.ne.jp/VIEW_ESITE/mem/sc/main.jsp?nid=MEG002006BJP)
- [２段階認証のお願い _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon-white.svg)_](https://id.smt.docomo.ne.jp/src/utility/sp/twostepauth.html)

- [CMギャラリー _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.youtube.com/playlist?list=PLB334710B4B8111A8)
- [よくあるご質問](https://faq.front.smt.docomo.ne.jp/?utm_source=docomo.ne.jp&utm_medium=api_linkage&utm_campaign=api_CRP_TOP)
- [見やすさ・使いやすさの調整](https://www.docomo.ne.jp/utility/term/web_accessibility/faciliti/?icid=CRP_drawer_to_CRP_UTI_term_web_accessibility_faciliti)
- [パーソナルデータ（個人情報など）について](https://www.docomo.ne.jp/utility/personal_data/?icid=CRP_drawer_to_CRP_UTI_personal_data)

- [![](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-daccount-logo.svg)\\
ログインする](https://cfg.smt.docomo.ne.jp/auth/cgi/anidlogin?rl=https%3A%2F%2Fwww.docomo.ne.jp%2Fcharge%2Fpromotion%2Feraberu%2F)
- [![別ウィンドウで開きます。のりかえ（MNP）](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-online-mnp-icon_smt.png)](https://onlineshop.docomo.ne.jp/special-contents/mnp?xcid=OLS_special-contents_mnp_flow_from_CRP_TOP_mnp_btn)

- [![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-switch-online-icon.svg)機種変更](https://www.docomo.ne.jp/support/switch_online/?icid=CRP_outerhead_to_SUP_switch_online)
- [![](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-d-point-club-logo.svg)\\
\\
P\\
\\
![](https://www.docomo.ne.jp/charge/promotion/eraberu/)](https://www.docomo.ne.jp/charge/promotion/eraberu/)

[![ドコモビジネスメンバーズ](https://www.docomo.ne.jp/images_osp/common/newhf/ico/ico_businessmembers.png)](https://www.docomo.ne.jp/charge/promotion/eraberu/)

お客さまの設定により、お客さま情報が「非表示」となっております。お客さま情報を表示するにはdアカウントでログインしてください。


[お客さま情報表示について](https://www.docomo.ne.jp/charge/promotion/eraberu/) へ


[お客さま情報表示について](https://www.docomo.ne.jp/charge/promotion/eraberu/) へ


# ![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/img_kv_pc.png?ver=1749049244)![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/img_kv_smt.png?ver=1749049244)

![あなたのニーズに合ったプランを選択](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/ttl_tab_pc.png?ver=1749049245)![あなたのニーズに合ったプランを選択](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/ttl_tab_smt.png?ver=1749049245)

- 1GB～無制限ドコモ MAX
- 無制限ドコモ ポイ活MAX
- 20GB～無制限ドコモ ポイ活20
- 4GB／10GBドコモ mini
- 30GBahamo

※ahamoはオンラインでのお手続きとなります。

## ![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/logo_docomo-max.png?ver=1749049245)

![ドコモ MAX 3GB～無制限での料金イメージ 基本料金7,680円／月（税込8,448円／月） 割引適用分 実質4,680円／月（税込5,148円／月）](https://www.docomo.ne.jp/flcache_data/charge/index/img_graph_docomo_max_pc.png?ver=1757466019)![ドコモ MAX 3GB～無制限での料金イメージ 基本料金7,680円／月（税込8,448円／月） 割引適用分 実質4,680円／月（税込5,148円／月）](https://www.docomo.ne.jp/flcache_data/charge/index/img_graph_docomo_max_smt.png?ver=1757466019)![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/img_discount_docomo-max_pc.png?ver=1749049244)![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/img_discount_docomo-max_smt.png?ver=1749049244)

- みんなドコモ割を3回線以上、長期利用割を20年以上、dカードお支払割でdカード PLATINUM、dカード GOLD、dカード GOLD Uをご利用いただいた場合の金額になります。


＼うれしい特典が充実／

[特典の詳細をみる __](https://www.docomo.ne.jp/charge/promotion/eraberu/#privilege_docomo-max)

### 割引適用内訳

![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/img_detail_docomo-max.png?ver=1760918415)

![スクロール](https://www.docomo.ne.jp/images_osp/common/img/img_guide_scroll01@2x.png)

![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/img_price_docomo-max_pc.png?ver=1749049245)![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/img_price_docomo-max_smt.png?ver=1749049245)

1. 大量通信時などに通信制限がかかる場合があります。「5Gデータプラス」「データプラス」「データプラス（2019年9月30日以前お申込み）」をご契約の場合、ペア回線の利用可能データ量は30GBとなり、上限超過後は通信速度が送受信最大1Mbpsとなります。詳細は「 [5Gデータプラス](https://www.docomo.ne.jp/charge/5g-dataplus/?icid=CRP_CHA_promotion_eraberu_01-to_CRP_CHA_5g-dataplus)」をご確認ください。

2. 同一「ファミリー割引」グループ内における音声通話が可能な料金プラン（「2in1」、「キッズケータイプラス」、「キッズケータイプラン」「irumo（0.5GB）」を除く）契約回線がカウント対象となります。

3. 月末時点の支払い方法をdカード、dカード GOLD U、dカード GOLD、dカード PLATINUMによる定期クレジット設定にしていることが割引条件となります。


- 家族カードも対象

- 一括請求代表回線のお支払い方法が定期クレジット設定（本料金プランをdカード／dカード GOLD U／dカード GOLD／dカード PLATINUMで毎月支払う設定）の場合、一括請求代表回線の料金プランにかかわらず、対象料金プランを契約している一括請求子回線は割引が適用されます。


「dカードお支払割」は回線契約が個人名義のお客さまのみが対象です。回線契約が法人名義のお客さま向けには、「ビジネスメンバーズ割」（1回線あたり275円（税込）／月を月額利用料から割引）、「社員割」（6回線以上ご契約の法人名義に1回線あたり275円（税込）／月を月額利用料から割引）をご用意しております。

- 月末時点の支払い方法をdカードで定期クレジット設定している場合は220円（税込）（ただし、キャンペーン期間中は550円（税込））、dカード GOLD U、dカード GOLD、dカード PLATINUMで定期クレジット設定している場合は550円（税込）割り引きします。


4. 「dカード」を定期支払いに設定いただいたお客さまを対象に、カード券種に関係なく550円（税込）／月を割り引くキャンペーンを実施いたします。（2025年10月31日をもちまして、本キャンペーンは終了しました）

5. 「ドコモ光」または「home 5G プラン」契約者と同一「ファミリー割引」グループ内の「ドコモ MAX」「ドコモ ポイ活 MAX」「ドコモ ポイ活 20」「ドコモ mini」の契約者が対象です。同一「ファミリー割引」グループ内に「ドコモ光」「home 5G プラン」の両方が存在する場合は、「ドコモ光セット割」が適用されます。月額料金が日割り計算となる場合は、割引額も日割り計算となります。また、適用には「ドコモ光」もしくは「home 5G プラン」のご契約が必要となり別途費用がかかります（「ドコモ光」の場合、プロバイダ込・1ギガ・解約金（戸建：5,500円（税込）／マンション：4,180円（税込））有で月4,400円（税込）～5,940円（税込）。「home 5G プラン」の場合、月5,280円（税込）と別途HR01／HR02のご購入が必要）。

6. 同一「ファミリー割引」グループ内に、「ドコモでんき」のペア回線（「ドコモでんき」と対になる携帯電話回線）が含まれている場合、同一「ファミリー割引」グループ内の対象料金プランを契約する各回線に対してそれぞれ割引が適用となります。本契約回線が「ドコモでんき」のペア回線に指定されている場合でも、同一「ファミリー割引」グループ内の「ドコモ ポイ活 MAX」「ドコモ ポイ活 20」「ドコモ MAX」「ドコモ mini」については「ドコモでんきセット割」の対象となります。割引対象回線の月額料金が日割りとなる場合、「ドコモでんきセット割」の割引額も日割りとなります。また、適用には「ドコモでんき」のご契約が必要となり、「ドコモでんき」は別途料金がかかります。各エリアごとの料金については [ドコモでんきサイト _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://denki.docomo.ne.jp/plan/price/) の料金単価表をご確認ください。

7. dカードは年会費無料、dカード GOLD Uは年会費3,300円（税込）、dカード GOLDは年会費11,000円（税込）、dカード PLATINUMは年会費29,700円（税込）がかかります。各種dカードはそれぞれ所定の審査があります。


- 別途機種代金・通話料（国内通話の場合30秒ごとに22円（税込））などがかかります。


[料金プランを詳しくみる __](https://www.docomo.ne.jp/charge/docomo_max/index.html?icid=CRP_CHA_promotion_eraberu_to_CRP_CHA_docomo_max)

## 「ドコモ MAX」にするなら  **Web・ドコモショップ店頭** で

### ![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/ico_application-online.png?ver=1749049244)Webでお申込みを  ご希望の方

#### ドコモ回線の方

- [申込む _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window02.png)_](https://mydocomo.docomo.ne.jp/procedure/process?pid=201&xcid=OLT_procedure_process_from_CRP_max_plan_newplan_LP2)

#### のりかえ（MNP）・新規契約の方

- [申込む _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window02.png)_](https://onlineshop.docomo.ne.jp/products/exclusive/sim?xcid=OLS_sim_from_CRP_202508_max_eraberu_sim-only&utm_source=corp_charge&utm_medium=owned&utm_campaign=ols_202508_max-eraberu&utm_content=202508_max_sim_eraberu_sim-only)

- SIM形状の変更が必要な場合、「ドコモオンラインショップ」にてプラン変更およびSIMカード発行のお申込み（手数料無料）が必要となり、新プランへの切替にはSIMカードお届け後にお客さまご自身で開通手続きを行っていただく必要がございます。

- 4G端末をご利用の方はご自身の端末がご利用可能か [4G対応端末一覧（PDF形式：330KB） _PDF_](https://www.docomo.ne.jp/binary/pdf/charge/eximo/notice/supported_phones.pdf?ver=1758865571) よりご確認ください。

- 4G対応機種をご利用中かつSIM形状の変更が必要な方は、「ドコモオンラインショップ」でのお申込みとなります。


### ![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/ico_application-shop.png?ver=1749049244)ドコモショップ店頭でお申込みを  ご希望の方

- [来店予約・店舗検索する _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window02.png)_](https://shop.smt.docomo.ne.jp/?xcid=DS_TOP_from_CRP_CHA_promotion_eraberu_docomo_max)

- 4G端末をご利用の方はご自身の端末がご利用可能か [4G対応端末一覧（PDF形式：330KB） _PDF_](https://www.docomo.ne.jp/binary/pdf/charge/eximo/notice/supported_phones.pdf?ver=1758865571) よりご確認ください。


![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/img_privilege_docomo-max_pc.png?ver=1761614532)![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/img_privilege_docomo-max_smt.png?ver=1761614532)

[![Leminoプレミアム入会で最大6か月間おトクに使えるキャンペーン ※入会月の月末までにエントリー要。毎月1回以上の視聴など各種条件あり。初回無料期間など各種特典適用がある期間はポイント進呈の対象外となる場合あり。詳しくはこちら](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/img_privilege_lemino_pc.png?ver=1749049245)![Leminoプレミアム入会で最大6か月間おトクに使えるキャンペーン ※入会月の月末までにエントリー要。毎月1回以上の視聴など各種条件あり。初回無料期間など各種特典適用がある期間はポイント進呈の対象外となる場合あり。詳しくはこちら](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/img_privilege_lemino_smt.png?ver=1749049245)](https://lemino.docomo.ne.jp/cp/0000123/?utm_source=corp_charge&utm_medium=free-display&utm_campaign=lemino_202506_dcmcorp-eraberu-nyukai900ptcp-0605)

＼Amazonプライムについて／

[ご登録はこちら _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://ssw.web.docomo.ne.jp/prime/campaign/max_202506/?utm_source=corp_other&utm_medium=free-display&utm_campaign=ap_202506_ap_0000754)

[![ドコモから入会がお得ディズニープラスの月額料金から毎月1,140円が最大6か月間割引要エントリー](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/bnr_disneyplus_01_pc.png?ver=1756083612)![ドコモから入会がお得ディズニープラスの月額料金から毎月1,140円が最大6か月間割引要エントリー](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/bnr_disneyplus_01_smt.png?ver=1756083612)_![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://service.smt.docomo.ne.jp/site/special/src/disneyplus_campaign_index.html?ex_cmp=dp_ddcm_corp_eraberu_max&utm_source=corp_eraberu_max&utm_medium=display&utm_campaign=dp_202006_set)

[![「ギガライト」「irumo」契約者限定！「ドコモ MAX」「ドコモ ポイ活 MAX」にWebにてお申込みで3,000ポイントプレゼントキャンペーン](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/bnr-gigalite-irumo_pc.png?ver=1761096850)![「ギガライト」「irumo」契約者限定！「ドコモ MAX」「ドコモ ポイ活 MAX」にWebにてお申込みで3,000ポイントプレゼントキャンペーン](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/bnr-gigalite-irumo_smt.png?ver=1761096850)_![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://ssw.web.docomo.ne.jp/nssw/dcmgiga/cp/maxweb3000ptcp/?utm_source=corp_campaign&utm_medium=free-display&utm_campaign=dcmgiga_202510_cam_0003766)

1. 「NBA docomo」の配信対象試合について詳しくは [こちら _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://nba.docomo.ne.jp/lp/entry001/?utm_source=corp_other&utm_medium=free-display&utm_campaign=nbaservicelp_202510_nbadocomo_newplan_eraberu1) をご確認ください。

2. 2026年1月まで（予定）に「ドコモ MAX」「ドコモ ポイ活 MAX」を翌月適用でお申込みいただいた場合、お申込み当月から「NBA docomo」「DAZN for docomo」が追加料金なしでご利用になれます。ただし、対象料金プランの翌月適用がキャンセルされた場合、当月の「NBA docomo」 「DAZN for docomo」の月額利用料を請求いたします。ドコモ回線以外のお客さまが追加料金なしで「NBA docomo」もしくは「DAZN for docomo」をご利用いただくためには各サービスのお申込み時点において、「ドコモ MAX」「ドコモ ポイ活 MAX」をご契約いただいている必要があります。対象料金プランお申込み前に各サービスをご契約された場合、対象料金プランお申込みの翌月以降でないと、各サービスを追加料金なしでご利用いただけませんのでご注意ください。

3. ドコモ以外でご契約中のDAZNを退会される際、退会手続き後に一定期間課金が発生する場合があります。詳しくは [こちら _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://www.dazn.com/ja-JP/help/articles/16194539395613-DAZN%E3%81%AE%E9%80%80%E4%BC%9A%E6%96%B9%E6%B3%95) をご確認ください。

4. ドコモからの「Amazonプライム」登録で、回線利用料と「Amazonプライム」月額会費の合計額から、「Amazonプライム」月額会費相当の600円を最大6か月間割引きます。当社提供のほかAmazonプライム割引特典と重畳はできません。本特典が優先となります。

5. 「Amazonプライム」の月額会費は600円（税込）です（2025年6月時点）。「Amazonプライム」は6か月間の割引終了後、ご登録期間中はdポイント（期間・用途限定）を毎月120ポイント還元いたします。

6. 海外データ通信について詳しくは [こちら](https://www.docomo.ne.jp/service/world/roaming/max/?icid=CRP_CHA_promotion_eraberu_txt01_to_CRP_SER_world_roaming_max) をご確認ください。

7. 一部対象外の地域があります。詳しくは [こちら](https://www.docomo.ne.jp/service/world/roaming/charge/web.html?icid=CRP_CHA_promotion_eraberu_txt01_to_CRP_SER_world_roaming_charge_web#anc-01) をご確認ください。

8. 長期利用割は「ドコモ MAX」「ドコモ ポイ活 MAX」のお客さまが対象です。ドコモのご利用継続期間が20年以上のお客さまは220円／月、10年以上のお客さまは110円／月を月額料金から割引きます。


## ![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/logo_docomo-poikatsu-max.png?ver=1749049245)

![ドコモ ポイ活 MAXでの料金イメージ 基本料金10,680円／月（税込11,748円／月） 割引適用分 ポイント充当分 実質2,680円／月（税込2,948円／月）](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/img_graph_docomo_poikatsu_max_pc.png?ver=1757466020)![ドコモ ポイ活 MAXでの料金イメージ 基本料金10,680円／月（税込11,748円／月） 割引適用分 ポイント充当分 実質2,680円／月（税込2,948円／月）](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/img_graph_docomo_poikatsu_max_smt.png?ver=1757466020)![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/img_pointdiscount_docomo_poikatsu_max_pc.png?ver=1758869472)![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/img_pointdiscount_docomo_poikatsu_max_smt.png?ver=1758869472)

[ポイント特典についてはこちら __](https://www.docomo.ne.jp/charge/promotion/eraberu/#anc-02-01-poikatsu-max)

![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/img_discount_docomo-poikatsu-max_pc.png?ver=1749049244)![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/img_discount_docomo-poikatsu-max_smt.png?ver=1749049244)

- みんなドコモ割を3回線以上、長期利用割を20年以上、dカードお支払割でdカード PLATINUM、dカード GOLD、dカード GOLD Uをご利用いただいた場合の金額になります。


### 割引適用内訳

![スクロール](https://www.docomo.ne.jp/images_osp/common/img/img_guide_scroll01@2x.png)

![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/img_detail_docomo-poikatsu-max.png?ver=1756170012)

![スクロール](https://www.docomo.ne.jp/images_osp/common/img/img_guide_scroll01@2x.png)

![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/img_price_docomo-poikatsu-max_pc.png?ver=1749049245)![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/img_price_docomo-poikatsu-max_smt.png?ver=1749049245)

＼うれしい特典が充実／

[特典の詳細をみる __](https://www.docomo.ne.jp/charge/promotion/eraberu/#privilege_docomo-poikatsu-max)

![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/ttl_campaign_docomo-poikatsu-max_pc.png?ver=1749049245)![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/ttl_campaign_docomo-poikatsu-max_smt.png?ver=1749049245)

![スクロール](https://www.docomo.ne.jp/images_osp/common/img/img_guide_scroll01@2x.png)

![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/img_campaign_docomo-poikatsu-max.png?ver=1758869472)

![スクロール](https://www.docomo.ne.jp/images_osp/common/img/img_guide_scroll01@2x.png)

#### ポイント還元の料金イメージをシミュレーション

＼月々の支払いを選択して獲得ポイント目安をチェック／

[詳しくみる __](https://www.docomo.ne.jp/charge/promotion/new_plan/?icid=CRP_CHA_promotion_eraberu_to_CRP_CHA_promotion_new_plan#simulation)

＼マネックス証券特典／

[詳しくみる _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://monex.docomo.ne.jp/service/nisa/index.html?utm_source=eximo&utm_medium=pull&utm_campaign=eximo_202411&utm_term=11&utm_content=399_docomo&acOpenChannel=d19071102#merit-box2)

＼ポイ活 ファミリー特典／

ご家族でドコモの回線をご契約いただき、「ドコモ ポイ活 MAX」「eximoポイ活」のご契約が1回線以上ある場合に適用される特典です。「ドコモ ポイ活 MAX」ご契約者および2025年2月4日以降に「eximoポイ活」をご契約された方は、自動適用となりますのでお手続きは不要です。

[詳しくみる __](https://www.docomo.ne.jp/campaign_event/promotion/poikatsu_family/?icid=CRP_CHA_promotion_eraberu_to_CRP_CAM_promotion_poikatsu_family)

01. 大量通信時などに通信制限がかかる場合があります。「5Gデータプラス」「データプラス」「データプラス（2019年9月30日以前お申込み）」をご契約の場合、ペア回線の利用可能データ量は30GBとなり、上限超過後は通信速度が送受信最大1Mbpsとなります。詳細は「 [5Gデータプラス](https://www.docomo.ne.jp/charge/5g-dataplus/?icid=CRP_CHA_promotion_eraberu_02-to_CRP_CHA_5g-dataplus)」をご確認ください。

02. 同一「ファミリー割引」グループ内における音声通話が可能な料金プラン（「2in1」、「キッズケータイプラス」、「キッズケータイプラン」「irumo（0.5GB）」を除く）契約回線がカウント対象となります。

03. 月末時点の支払い方法をdカード、dカード GOLD U、dカード GOLD、dカード PLATINUMによる定期クレジット設定にしていることが割引条件となります。

- 家族カードも対象

- 一括請求代表回線のお支払い方法が定期クレジット設定（本料金プランをdカード／dカード GOLD U／dカード GOLD／dカード PLATINUMで毎月支払う設定）の場合、一括請求代表回線の料金プランにかかわらず、対象料金プランを契約している一括請求子回線は割引が適用されます。


「dカードお支払割」は回線契約が個人名義のお客さまのみが対象です。回線契約が法人名義のお客さま向けには、「ビジネスメンバーズ割」（1回線あたり275円（税込）／月を月額利用料から割引）、「社員割」（6回線以上ご契約の法人名義に1回線あたり275円（税込）／月を月額利用料から割引）をご用意しております。

- 月末時点の支払い方法をdカードで定期クレジット設定している場合は220円（税込）（ただし、キャンペーン期間中は550円（税込））、dカード GOLD U、dカード GOLD、dカード PLATINUMで定期クレジット設定している場合は550円（税込）割り引きします。


04. 「dカード」を定期支払いに設定いただいたお客さまを対象に、カード券種に関係なく550円（税込）／月を割り引くキャンペーンを実施いたします。（2025年10月31日をもちまして、本キャンペーンは終了しました）

05. 「ドコモ光」または「home 5G プラン」契約者と同一「ファミリー割引」グループ内の「ドコモ MAX」「ドコモ ポイ活 MAX」「ドコモ ポイ活 20」「ドコモ mini」の契約者が対象です。同一「ファミリー割引」グループ内に「ドコモ光」「home 5G プラン」の両方が存在する場合は、「ドコモ光セット割」が適用されます。月額料金が日割り計算となる場合は、割引額も日割り計算となります。また、適用には「ドコモ光」もしくは「home 5G プラン」のご契約が必要となり別途費用がかかります（「ドコモ光」の場合、プロバイダ込・1ギガ・解約金（戸建：5,500円（税込）／マンション：4,180円（税込））有で月4,400円（税込）～5,940円（税込）。「home 5G プラン」の場合、月5,280円（税込）と別途HR01／HR02のご購入が必要）。

06. 同一「ファミリー割引」グループ内に、「ドコモでんき」のペア回線（「ドコモでんき」と対になる携帯電話回線）が含まれている場合、同一「ファミリー割引」グループ内の対象料金プランを契約する各回線に対してそれぞれ割引が適用となります。本契約回線が「ドコモでんき」のペア回線に指定されている場合でも、同一「ファミリー割引」グループ内の「ドコモ ポイ活 MAX」「ドコモ ポイ活 20」「ドコモ MAX」「ドコモ mini」については「ドコモでんきセット割」の対象となります。割引対象回線の月額料金が日割りとなる場合、「ドコモでんきセット割」の割引額も日割りとなります。また、適用には「ドコモでんき」のご契約が必要となり、「ドコモでんき」は別途料金がかかります。各エリアごとの料金については [ドコモでんきサイト _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://denki.docomo.ne.jp/plan/price/) の料金単価表をご確認ください。

07. 定期クレジット設定しているdカード GOLD U／dカード GOLD／dカード PLATINUMとは別のdカード GOLD U／dカード GOLD／dカード PLATINUMに対しご利用携帯電話番号登録いただいた場合でも、dカード GOLD U／dカード GOLDは5.0%、dカード PLATINUMは10.0%の進呈率を適用します。

08. dポイント（期間・用途限定）は対象決済の利用があった翌月下旬に進呈され、進呈日から93日間が有効期限となります。翌月のポイント進呈日を超えて反映された売上分の特典（dポイント）は、反映が遅れた日程分、有効期限（進呈日から93日間）が短くなります。対象決済がdカード／dカード GOLD U／dカード GOLD／dカード PLATINUMの場合、決済において、キャンセルが発生した場合、対象の決済にて進呈したポイントは減算されます。dポイント獲得履歴はdポイントクラブサイトで確認が可能です。

09. 対象決済がdカード GOLD U／dカード GOLD／dカード PLATINUMの場合、対象決済の利用日の23：59時点で、ご利用携帯電話番号として登録した、本料金プランを契約している回線の利用料金をdカード／dカード GOLD U／dカード GOLD／dカード PLATINUMで支払う設定をしている必要があります。対象決済がd払いの場合、決済時点で本料金プランを契約している回線の料金プランをdカード／dカード GOLD U／dカード GOLD／dカード PLATINUMで支払う設定をしていることに加え、ご利用のdカード GOLD U／dカード GOLD／dカード PLATINUMに本料金プランを契約している回線のご利用携帯電話番号登録の設定をしている必要があります。

10. 対象決済を行った日において、ご利用のdカード／dカード GOLD U／dカード GOLD／dカード PLATINUM（本カード／家族カード）に本料金プランを契約している回線のご利用携帯電話番号が設定されていることが必要です。

11. dカードで通常たまるポイント（利用額100円（税込）につき1ポイント）の対象になるお支払い、「ドコモでんき」および「ドコモ ガス」ご利用料金が対象です。毎月のドコモの携帯電話ご利用料金、年会費、各種手数料、電子マネー・プリペイドカードへのチャージ、「THEO＋docomo」などは進呈対象外となります。詳細は [こちら _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://dcard.docomo.ne.jp/st/beginner_about/attention/index.html) をご確認ください。

12. d払いを利用した決済であっても、dポイント利用によるお支払い分、クーポン利用によるお支払い分、モバイルSuicaチャージによるお支払い分、決済対象が請求書払い（公共料金、地方税統一QRコードなど）である場合、ポイント進呈の対象外となります。なお、一部ポイント進呈対象外の店舗がございます。詳細は [こちら _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://service.smt.docomo.ne.jp/keitai_payment/town/no-reward.html) をご確認ください。

13. d払いのお支払い方法を電話料金合算払い（電話料金の支払い方法にdカード以外のクレジットカードを設定している場合を除く）、dカード、d払い残高に設定されたお支払いのみが対象です。

14. d払いのお支払い方法を電話料金合算払い（電話料金の支払い方法にdカード以外のクレジットカードを設定している場合）、またはdカード以外のクレジットカードに設定したお支払いはdポイントの進呈対象外です。d払いの基本還元率は、dカードによるお支払いは1.0%、電話料金合算払い（電話料金の支払い方法にdカード以外のクレジットカードを設定している場合を除く）およびd払い残高によるお支払いは0.5%、電話料金合算払い（電話料金の支払い方法にdカード以外のクレジットカードを設定している場合）およびdカード以外のクレジットカードによるお支払いは0%となります。

15. 定期クレジットの設定状況および、dカード GOLD U／dカード GOLD／dカード PLATINUMのご利用携帯電話番号への登録状況にかかわらず、キャンペーン期間中の進呈率は10%となります。ただし、dカード決済の場合はご利用電話番号登録が必要です。また、キャンペーン終了時期未定です。当社は、1か月前までに当社が適当と判断する方法で周知することにより、キャンペーンを終了することができます。

16. dカードは年会費無料、dカード GOLD Uは年会費3,300円（税込）、dカード GOLDは年会費11,000円（税込）、dカード PLATINUMは年会費29,700円（税込）がかかります。各種dカードはそれぞれ所定の審査があります。


- 別途機種代金・通話料（国内通話の場合30秒ごとに22円（税込））などがかかります。


[料金プランを詳しくみる __](https://www.docomo.ne.jp/charge/docomo_poikatsu_max/index.html?icid=CRP_CHA_promotion_eraberu_to_CRP_CHA_docomo_poikatsu_max)

## 「ドコモ ポイ活 MAX」にするなら  **Web・ドコモショップ店頭** で

### ![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/ico_application-online.png?ver=1749049244)Webでお申込みを  ご希望の方

#### ドコモ回線の方

- [申込む _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window02.png)_](https://mydocomo.docomo.ne.jp/procedure/process?pid=201&xcid=OLT_procedure_process_from_CRP_poikatsu-max_plan_newplan_LP2)

#### のりかえ（MNP）・新規契約の方

- [申込む _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window02.png)_](https://onlineshop.docomo.ne.jp/products/exclusive/sim?xcid=OLS_sim_from_CRP_202508_poikatsu-max_eraberu_sim-only&utm_source=corp_charge&utm_medium=owned&utm_campaign=ols_202508_poikatsu-max-eraberu&utm_content=202508_poikatsu-max_sim_eraberu_sim-only)

- SIM形状の変更が必要な場合、「ドコモオンラインショップ」にてプラン変更およびSIMカード発行のお申込み（手数料無料）が必要となり、新プランへの切替にはSIMカードお届け後にお客さまご自身で開通手続きを行っていただく必要がございます。

- 4G端末をご利用の方はご自身の端末がご利用可能か [4G対応端末一覧（PDF形式：330KB） _PDF_](https://www.docomo.ne.jp/binary/pdf/charge/eximo/notice/supported_phones.pdf?ver=1758865571) よりご確認ください。

- 4G対応機種をご利用中かつSIM形状の変更が必要な方は、「ドコモオンラインショップ」でのお申込みとなります。


### ![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/ico_application-shop.png?ver=1749049244)ドコモショップ店頭でお申込みを  ご希望の方

- [来店予約・店舗検索する _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window02.png)_](https://shop.smt.docomo.ne.jp/?xcid=DS_TOP_from_CRP_CHA_promotion_eraberu_docomo_poikatsu_max)

- 4G端末をご利用の方はご自身の端末がご利用可能か [4G対応端末一覧（PDF形式：330KB） _PDF_](https://www.docomo.ne.jp/binary/pdf/charge/eximo/notice/supported_phones.pdf?ver=1758865571) よりご確認ください。


![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/img_privilege_docomo-poikatsu-max_pc.png?ver=1761614532)![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/img_privilege_docomo-poikatsu-max_smt.png?ver=1761614532)

[![Leminoプレミアム入会で最大6か月間おトクに使えるキャンペーン ※入会月の月末までにエントリー要。毎月1回以上の視聴など各種条件あり。初回無料期間など各種特典適用がある期間はポイント進呈の対象外となる場合あり。詳しくはこちら](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/img_privilege_lemino_pc.png?ver=1749049245)![Leminoプレミアム入会で最大6か月間おトクに使えるキャンペーン ※入会月の月末までにエントリー要。毎月1回以上の視聴など各種条件あり。初回無料期間など各種特典適用がある期間はポイント進呈の対象外となる場合あり。詳しくはこちら](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/img_privilege_lemino_smt.png?ver=1749049245)](https://lemino.docomo.ne.jp/cp/0000123/?utm_source=corp_charge&utm_medium=free-display&utm_campaign=lemino_202506_dcmcorp-eraberu-nyukai900ptcp-0605)

**＼Amazonプライムについて／**

[ご登録はこちら _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://ssw.web.docomo.ne.jp/prime/campaign/max_202506/?utm_source=corp_other&utm_medium=free-display&utm_campaign=ap_202506_ap_0000754)

[![ドコモから入会がお得ディズニープラスの月額料金から毎月1,140円が最大6か月間割引要エントリー](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/bnr_disneyplus_01_pc.png?ver=1756083612)![ドコモから入会がお得ディズニープラスの月額料金から毎月1,140円が最大6か月間割引要エントリー](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/bnr_disneyplus_01_smt.png?ver=1756083612)_![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://service.smt.docomo.ne.jp/site/special/src/disneyplus_campaign_index.html?ex_cmp=dp_ddcm_corp_eraberu_poikatsu_max&utm_source=corp_eraberu_poikatsu_max&utm_medium=display&utm_campaign=dp_202006_set)

[![「ギガライト」「irumo」契約者限定！「ドコモ MAX」「ドコモ ポイ活 MAX」にWebにてお申込みで3,000ポイントプレゼントキャンペーン](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/bnr-gigalite-irumo_pc.png?ver=1761096850)![「ギガライト」「irumo」契約者限定！「ドコモ MAX」「ドコモ ポイ活 MAX」にWebにてお申込みで3,000ポイントプレゼントキャンペーン](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/bnr-gigalite-irumo_smt.png?ver=1761096850)_![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://ssw.web.docomo.ne.jp/nssw/dcmgiga/cp/maxweb3000ptcp/?utm_source=corp_campaign&utm_medium=free-display&utm_campaign=dcmgiga_202510_cam_0003766)

1. 「NBA docomo」の配信対象試合について詳しくは [こちら _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://nba.docomo.ne.jp/lp/entry001/?utm_source=corp_other&utm_medium=free-display&utm_campaign=nbaservicelp_202510_nbadocomo_newplan_eraberu1) をご確認ください。

2. 2026年1月まで（予定）に「ドコモ MAX」「ドコモ ポイ活 MAX」を翌月適用でお申込みいただいた場合、お申込み当月から「NBA docomo」「DAZN for docomo」が追加料金なしでご利用になれます。ただし、対象料金プランの翌月適用がキャンセルされた場合、当月の「NBA docomo」 「DAZN for docomo」の月額利用料を請求いたします。ドコモ回線以外のお客さまが追加料金なしで「NBA docomo」もしくは「DAZN for docomo」をご利用いただくためには各サービスのお申込み時点において、「ドコモ MAX」「ドコモ ポイ活 MAX」をご契約いただいている必要があります。対象料金プランお申込み前に各サービスをご契約された場合、対象料金プランお申込みの翌月以降でないと、各サービスを追加料金なしでご利用いただけませんのでご注意ください。

3. ドコモ以外でご契約中のDAZNを退会される際、退会手続き後に一定期間課金が発生する場合があります。詳しくは [こちら _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://www.dazn.com/ja-JP/help/articles/16194539395613-DAZN%E3%81%AE%E9%80%80%E4%BC%9A%E6%96%B9%E6%B3%95) をご確認ください。

4. ドコモからの「Amazonプライム」登録で、回線利用料と「Amazonプライム」月額会費の合計額から、「Amazonプライム」月額会費相当の600円を最大6か月間割引きます。当社提供のほかAmazonプライム割引特典と重畳はできません。本特典が優先となります。

5. 「Amazonプライム」の月額会費は600円（税込）です（2025年6月時点）。「Amazonプライム」は6か月間の割引終了後、ご登録期間中はdポイント（期間・用途限定）を毎月120ポイント還元いたします。

6. 海外データ通信について詳しくは [こちら](https://www.docomo.ne.jp/service/world/roaming/max/?icid=CRP_CHA_promotion_eraberu_txt02_to_CRP_SER_world_roaming_max) をご確認ください。

7. 一部対象外の地域があります。詳しくは [こちら](https://www.docomo.ne.jp/service/world/roaming/charge/web.html?icid=CRP_CHA_promotion_eraberu_txt02_to_CRP_SER_world_roaming_charge_web#anc-01) をご確認ください。

8. 長期利用割は「ドコモ MAX」「ドコモ ポイ活 MAX」のお客さまが対象です。ドコモのご利用継続期間が20年以上のお客さまは220円／月、10年以上のお客さまは110円／月を月額料金から割引きます。


## ![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/logo_docomo-poikatsu-20.png?ver=1749049245)

![ドコモ ポイ活 20 ～20Bでの料金イメージ 基本料金7,180円／月（税込7,898円／月） 割引適用分 ポイント充当分 実質1,880円／月（税込2,068円／月）](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/img_graph_docomo_poikatsu_20_pc.png?ver=1757466020)![ドコモ ポイ活 20 ～20Bでの料金イメージ 基本料金7,180円／月（税込7,898円／月） 割引適用分 ポイント充当分 実質1,880円／月（税込2,068円／月）](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/img_graph_docomo_poikatsu_20_smt.png?ver=1757466020)![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/img_pointdiscount_docomo_poikatsu_20_pc.png?ver=1758869472)![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/img_pointdiscount_docomo_poikatsu_20_smt.png?ver=1758869472)

[ポイント特典についてはこちら __](https://www.docomo.ne.jp/charge/promotion/eraberu/#anc-02-01-poikatsu-20)

![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/img_discount_docomo-poikatsu-20_pc.png?ver=1749049244)![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/img_discount_docomo-poikatsu-20_smt.png?ver=1749049244)

- みんなドコモ割を3回線以上、dカードお支払割でdカード PLATINUM、dカード GOLD、dカード GOLD Uをご利用いただいた場合の金額になります。


### 割引適用内訳

![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/img_detail_docomo-poikatsu-20.png?ver=1756170012)

![スクロール](https://www.docomo.ne.jp/images_osp/common/img/img_guide_scroll01@2x.png)

![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/img_price_docomo-poikatsu-20_pc.png?ver=1749049245)![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/img_price_docomo-poikatsu-20_smt.png?ver=1749049245)

[特典の詳細をみる __](https://www.docomo.ne.jp/charge/promotion/eraberu/#privilege_docomo-poikatsu-20)

![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/ttl_campaign_docomo-poikatsu-20_pc.png?ver=1749049245)![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/ttl_campaign_docomo-poikatsu-20_smt.png?ver=1749049245)

![スクロール](https://www.docomo.ne.jp/images_osp/common/img/img_guide_scroll01@2x.png)

![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/img_campaign_docomo-poikatsu-20.png?ver=1758869472)

![スクロール](https://www.docomo.ne.jp/images_osp/common/img/img_guide_scroll01@2x.png)

＼マネックス証券特典／

[詳しくみる _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://monex.docomo.ne.jp/service/nisa/index.html?utm_source=eximo&utm_medium=pull&utm_campaign=eximo_202411&utm_term=11&utm_content=399_docomo&acOpenChannel=d19071102#merit-box2)

[料金プランを詳しくみる __](https://www.docomo.ne.jp/charge/docomo_poikatsu_20/index.html?icid=CRP_CHA_promotion_eraberu_to_CRP_CHA_docomo_poikatsu_20)

## 「ドコモ ポイ活 20」にするなら  **Web・ドコモショップ店頭** で

### ![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/ico_application-online.png?ver=1749049244)Webでお申込みを  ご希望の方

#### ドコモ回線の方

- [申込む _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window02.png)_](https://mydocomo.docomo.ne.jp/procedure/process?pid=201&xcid=OLT_procedure_process_from_CRP_poikatsu20_plan_newplan_LP2)

#### のりかえ（MNP）・新規契約の方

- [申込む _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window02.png)_](https://onlineshop.docomo.ne.jp/products/exclusive/sim?xcid=OLS_sim_from_CRP_202508_poikatsu20_eraberu_sim-only&utm_source=corp_charge&utm_medium=owned&utm_campaign=ols_202508_poikatsu20-eraberu&utm_content=202508_poikatsu20_sim_eraberu_sim-only)

- SIM形状の変更が必要な場合、「ドコモオンラインショップ」にてプラン変更およびSIMカード発行のお申込み（手数料無料）が必要となり、新プランへの切替にはSIMカードお届け後にお客さまご自身で開通手続きを行っていただく必要がございます。

- 4G端末をご利用の方はご自身の端末がご利用可能か [4G対応端末一覧（PDF形式：330KB） _PDF_](https://www.docomo.ne.jp/binary/pdf/charge/eximo/notice/supported_phones.pdf?ver=1758865571) よりご確認ください。

- 4G対応機種をご利用中かつSIM形状の変更が必要な方は、「ドコモオンラインショップ」でのお申込みとなります。


### ![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/ico_application-shop.png?ver=1749049244)ドコモショップ店頭でお申込みを  ご希望の方

- [来店予約・店舗検索する _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window02.png)_](https://shop.smt.docomo.ne.jp/?xcid=DS_TOP_from_CRP_CHA_promotion_eraberu_docomo_poikatsu20)

- 4G端末をご利用の方はご自身の端末がご利用可能か [4G対応端末一覧（PDF形式：330KB） _PDF_](https://www.docomo.ne.jp/binary/pdf/charge/eximo/notice/supported_phones.pdf?ver=1758865571) よりご確認ください。


01. 大量通信時などに通信制限がかかる場合があります。「5Gデータプラス」「データプラス」「データプラス（2019年9月30日以前お申込み）」をご契約の場合、ペア回線の利用可能データ量は30GBとなり、上限超過後は通信速度が送受信最大1Mbpsとなります。詳細は「 [5Gデータプラス](https://www.docomo.ne.jp/charge/5g-dataplus/?icid=CRP_CHA_promotion_eraberu_03-to_CRP_CHA_5g-dataplus)」をご確認ください。

02. 同一「ファミリー割引」グループ内における音声通話が可能な料金プラン（「2in1」、「キッズケータイプラス」、「キッズケータイプラン」「irumo（0.5GB）」を除く）契約回線がカウント対象となります。

03. 月末時点の支払い方法をdカード、dカード GOLD U、dカード GOLD、dカード PLATINUMによる定期クレジット設定にしていることが割引条件となります。

- 家族カードも対象

- 一括請求代表回線のお支払い方法が定期クレジット設定（本料金プランをdカード／dカード GOLD U／dカード GOLD／dカード PLATINUMで毎月支払う設定）の場合、一括請求代表回線の料金プランにかかわらず、対象料金プランを契約している一括請求子回線は割引が適用されます。


「dカードお支払割」は回線契約が個人名義のお客さまのみが対象です。回線契約が法人名義のお客さま向けには、「ビジネスメンバーズ割」（1回線あたり275円（税込）／月を月額利用料から割引）、「社員割」（6回線以上ご契約の法人名義に1回線あたり275円（税込）／月を月額利用料から割引）をご用意しております。

- 月末時点の支払い方法をdカードで定期クレジット設定している場合は220円（税込）（ただし、キャンペーン期間中は550円（税込））、dカード GOLD U、dカード GOLD、dカード PLATINUMで定期クレジット設定している場合は550円（税込）割り引きします。


04. 「dカード」を定期支払いに設定いただいたお客さまを対象に、カード券種に関係なく550円（税込）／月を割り引くキャンペーンを実施いたします。（2025年10月31日をもちまして、本キャンペーンは終了しました）

05. 「ドコモ光」または「home 5G プラン」契約者と同一「ファミリー割引」グループ内の「ドコモ MAX」「ドコモ ポイ活 MAX」「ドコモ ポイ活 20」「ドコモ mini」の契約者が対象です。同一「ファミリー割引」グループ内に「ドコモ光」「home 5G プラン」の両方が存在する場合は、「ドコモ光セット割」が適用されます。月額料金が日割り計算となる場合は、割引額も日割り計算となります。また、適用には「ドコモ光」もしくは「home 5G プラン」のご契約が必要となり別途費用がかかります（「ドコモ光」の場合、プロバイダ込・1ギガ・解約金（戸建：5,500円（税込）／マンション：4,180円（税込））有で月4,400円（税込）～5,940円（税込）。「home 5G プラン」の場合、月5,280円（税込）と別途HR01／HR02のご購入が必要）。

06. 同一「ファミリー割引」グループ内に、「ドコモでんき」のペア回線（「ドコモでんき」と対になる携帯電話回線）が含まれている場合、同一「ファミリー割引」グループ内の対象料金プランを契約する各回線に対してそれぞれ割引が適用となります。


    本契約回線が「ドコモでんき」のペア回線に指定されている場合でも、同一「ファミリー割引」グループ内の「ドコモ ポイ活 MAX」「ドコモ ポイ活 20」「ドコモ MAX」「ドコモ mini」については「ドコモでんきセット割」の対象となります。割引対象回線の月額料金が日割りとなる場合、「ドコモでんきセット割」の割引額も日割りとなります。また、適用には「ドコモでんき」のご契約が必要となり、「ドコモでんき」は別途料金がかかります。各エリアごとの料金については [ドコモでんきサイト _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://denki.docomo.ne.jp/plan/price/) の料金単価表をご確認ください。

07. 定期クレジット設定しているdカード GOLD U／dカード GOLD／dカード PLATINUMとは別のdカード GOLD U／dカード GOLD／dカード PLATINUMに対しご利用携帯電話番号登録いただいた場合でも、dカード GOLD U／dカード GOLDは2.0%、dカード PLATINUMは5.0%の進呈率を適用します。

08. dポイント（期間・用途限定）は対象決済の利用があった翌月下旬に進呈され、進呈日から93日間が有効期限となります。翌月のポイント進呈日を超えて反映された売上分の特典（dポイント）は、反映が遅れた日程分、有効期限（進呈日から93日間）が短くなります。対象決済がdカード／dカード GOLD U／dカード GOLD／dカード PLATINUMの場合、決済において、キャンセルが発生した場合、対象の決済にて進呈したポイントは減算されます。dポイント獲得履歴はdポイントクラブサイトで確認が可能です。

09. 対象決済がdカード GOLD U／dカード GOLD／dカード PLATINUMの場合、対象決済の利用日の23：59時点で、ご利用携帯電話番号として登録した、本料金プランを契約している回線の利用料金をdカード／dカード GOLD U／dカード GOLD／dカード PLATINUMで支払う設定をしている必要があります。対象決済がd払いの場合、決済時点で本料金プランを契約している回線の料金プランをdカード／dカード GOLD U／dカード GOLD／dカード PLATINUMで支払う設定をしていることに加え、ご利用のdカード GOLD U／dカード GOLD／dカード PLATINUMに本料金プランを契約している回線のご利用携帯電話番号登録の設定をしている必要があります。

10. 対象決済を行った日において、ご利用のdカード／dカード GOLD U／dカード GOLD／dカード PLATINUM（本カード／家族カード）に本料金プランを契約している回線のご利用携帯電話番号が設定されていることが必要です。

11. dカードで通常たまるポイント（利用額100円（税込）につき1ポイント）の対象になるお支払い、「ドコモでんき」および「ドコモ ガス」ご利用料金が対象です。毎月のドコモの携帯電話ご利用料金、年会費、各種手数料、電子マネー・プリペイドカードへのチャージ、「THEO＋docomo」などは進呈対象外となります。詳細は [こちら _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://dcard.docomo.ne.jp/st/beginner_about/attention/index.html) をご確認ください。

12. d払いを利用した決済であっても、dポイント利用によるお支払い分、クーポン利用によるお支払い分、モバイルSuicaチャージによるお支払い分、決済対象が請求書払い（公共料金、地方税統一QRコードなど）である場合、ポイント進呈の対象外となります。なお、一部ポイント進呈対象外の店舗がございます。詳細は [こちら _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://service.smt.docomo.ne.jp/keitai_payment/town/no-reward.html) をご確認ください。

13. d払いのお支払い方法を電話料金合算払い（電話料金の支払い方法にdカード以外のクレジットカードを設定している場合を除く）、dカード、d払い残高に設定されたお支払いのみが対象です。

14. d払いのお支払い方法を電話料金合算払い（電話料金の支払い方法にdカード以外のクレジットカードを設定している場合）、またはdカード以外のクレジットカードに設定したお支払いはdポイントの進呈対象外です。d払いの基本還元率は、dカードによるお支払いは1.0%、電話料金合算払い（電話料金の支払い方法にdカード以外のクレジットカードを設定している場合を除く）およびd払い残高によるお支払いは0.5%、電話料金合算払い（電話料金の支払い方法にdカード以外のクレジットカードを設定している場合）およびdカード以外のクレジットカードによるお支払いは0%となります。

15. 定期クレジットの設定状況および、dカード GOLD U／dカード GOLD／dカード PLATINUMのご利用携帯電話番号への登録状況に関わらず、キャンペーン期間中の進呈率は5%となります。ただし、dカード決済の場合はご利用電話番号登録が必要です。また、キャンペーン終了時期未定です。当社は、1か月前までに当社が適当と判断する方法で周知することにより、キャンペーンを終了することができます。

16. dカードは年会費無料、dカード GOLD Uは年会費3,300円（税込）、dカード GOLDは年会費11,000円（税込）、dカード PLATINUMは年会費29,700円（税込）がかかります。各種dカードはそれぞれ所定の審査があります。


- 別途機種代金・通話料（国内通話の場合30秒ごとに22円（税込））などがかかります。


![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/img_privilege_docomo-poikatsu-20_pc.png?ver=1749049245)![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/img_privilege_docomo-poikatsu-20_smt.png?ver=1749049245)

＼Amazonプライムについて／

[ご登録はこちら _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://ssw.web.docomo.ne.jp/prime/campaign/max_202506/?utm_source=corp_other&utm_medium=free-display&utm_campaign=ap_202506_ap_0000754)

1. ドコモからの「Amazonプライム」登録で、回線利用料と「Amazonプライム」月額会費の合計額から、「Amazonプライム」月額会費相当の600円を最大6か月間割引きます。当社提供のほかAmazonプライム割引特典と重畳はできません。本特典が優先となります。

2. 「Amazonプライム」の月額会費は600円（税込）です（2025年6月時点）。「Amazonプライム」は6か月間の割引終了後、ご登録期間中はdポイント（期間・用途限定）を毎月120ポイント還元いたします。


## ![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/logo_docomo-mini.png?ver=1749049245)

![ドコモ mini 4GBでの料金イメージ 基本料金2,500円／月（税込2,750円／月）割引適用分 実質800円／月（税込880円／月）](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/img_graph_docomo_mini_pc.png?ver=1757466020)![ドコモ mini 4GBでの料金イメージ 基本料金2,500円／月（税込2,750円／月）割引適用分 実質800円／月（税込880円／月）](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/img_graph_docomo_mini_smt.png?ver=1757466020)![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/img_discount_docomo-mini_pc.png?ver=1749049244)![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/img_discount_docomo-mini_smt.png?ver=1749049244)

[特典の詳細をみる __](https://www.docomo.ne.jp/charge/promotion/eraberu/#privilege_docomo-mini)

### 割引適用内訳

![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/img_detail_docomo-mini.png?ver=1749049244)

![スクロール](https://www.docomo.ne.jp/images_osp/common/img/img_guide_scroll01@2x.png)

![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/img_price_docomo-mini_pc.png?ver=1749049245)![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/img_price_docomo-mini_smt.png?ver=1749049245)

[料金プランを詳しくみる __](https://www.docomo.ne.jp/charge/docomo_mini/index.html?icid=CRP_CHA_promotion_eraberu_to_CRP_CHA_docomo_mini)

1. 月末時点の支払い方法をdカード、dカード GOLD U、dカード GOLD、dカード PLATINUMによる定期クレジット設定にしていることが割引条件となります。

- 家族カードも対象

- 一括請求代表回線のお支払い方法が定期クレジット設定（本料金プランをdカード／dカード GOLD U／dカード GOLD／dカード PLATINUMで毎月支払う設定）の場合、一括請求代表回線の料金プランにかかわらず、対象料金プランを契約している一括請求子回線は割引が適用されます。


「dカードお支払割」は回線契約が個人名義のお客さまのみが対象です。回線契約が法人名義のお客さま向けには、「ビジネスメンバーズ割」（1回線あたり275円（税込）／月を月額利用料から割引）、「社員割」（6回線以上ご契約の法人名義に1回線あたり275円（税込）／月を月額利用料から割引）をご用意しております。

- 月末時点の支払い方法をdカードで定期クレジット設定している場合は220円（税込）（ただし、キャンペーン期間中は550円（税込））、dカード GOLD U、dカード GOLD、dカード PLATINUMで定期クレジット設定している場合は550円（税込）割り引きします。


2. 「dカード」を定期支払いに設定いただいたお客さまを対象に、カード券種に関係なく550円（税込）／月を割り引くキャンペーンを実施いたします。（2025年10月31日をもちまして、本キャンペーンは終了しました）

3. 「ドコモ光」または「home 5G プラン」契約者と同一「ファミリー割引」グループ内の「ドコモ MAX」「ドコモ ポイ活 MAX」「ドコモ ポイ活 20」「ドコモ mini」の契約者が対象です。同一「ファミリー割引」グループ内に「ドコモ光」「home 5G プラン」の両方が存在する場合は、「ドコモ光セット割」が適用されます。月額料金が日割り計算となる場合は、割引額も日割り計算となります。また、適用には「ドコモ光」もしくは「home 5G プラン」のご契約が必要となり別途費用がかかります（「ドコモ光」の場合、プロバイダ込・1ギガ・解約金（戸建：5,500円（税込）／マンション：4,180円（税込））有で月4,400円（税込）～5,940円（税込）。「home 5G プラン」の場合、月5,280円（税込）と別途HR01／HR02のご購入が必要）。

4. 同一「ファミリー割引」グループ内に、「ドコモでんき」のペア回線（「ドコモでんき」と対になる携帯電話回線）が含まれている場合、同一「ファミリー割引」グループ内の対象料金プランを契約する各回線に対してそれぞれ割引が適用となります。本契約回線が「ドコモでんき」のペア回線に指定されている場合でも、同一「ファミリー割引」グループ内の「ドコモ ポイ活 MAX」「ドコモ ポイ活 20」「ドコモ MAX」「ドコモ mini」については「ドコモでんきセット割」の対象となります。割引対象回線の月額料金が日割りとなる場合、「ドコモでんきセット割」の割引額も日割りとなります。また、適用には「ドコモでんき」のご契約が必要となり、「ドコモでんき」は別途料金がかかります。各エリアごとの料金については [ドコモでんきサイト _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://denki.docomo.ne.jp/plan/price/) の料金単価表をご確認ください。


- 別途機種代金・通話料（国内通話の場合30秒ごとに22円（税込））などがかかります。


## 「ドコモ mini」にするなら  **Web・ドコモショップ店頭** で

### ![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/ico_application-online.png?ver=1749049244)Webでお申込みを  ご希望の方

#### ドコモ回線の方

- [申込む _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window02.png)_](https://mydocomo.docomo.ne.jp/procedure/process?pid=201&xcid=OLT_procedure_process_from_CRP_mini_plan_newplan_LP2)

#### のりかえ（MNP）・新規契約の方

- [申込む _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window02.png)_](https://onlineshop.docomo.ne.jp/products/exclusive/sim?xcid=OLS_sim_from_CRP_202508_mini_eraberu_sim-only&utm_source=corp_charge&utm_medium=owned&utm_campaign=ols_202508_mini-eraberu&utm_content=202508_mini_sim_eraberu_sim-only)

- SIM形状の変更が必要な場合、「ドコモオンラインショップ」にてプラン変更およびSIMカード発行のお申込み（手数料無料）が必要となり、新プランへの切替にはSIMカードお届け後にお客さまご自身で開通手続きを行っていただく必要がございます。

- 4G端末をご利用の方はご自身の端末がご利用可能か [4G対応端末一覧（PDF形式：330KB） _PDF_](https://www.docomo.ne.jp/binary/pdf/charge/eximo/notice/supported_phones.pdf?ver=1758865571) よりご確認ください。

- 4G対応機種をご利用中かつSIM形状の変更が必要な方は、「ドコモオンラインショップ」でのお申込みとなります。


### ![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/ico_application-shop.png?ver=1749049244)ドコモショップ店頭でお申込みを  ご希望の方

- [来店予約・店舗検索する _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window02.png)_](https://shop.smt.docomo.ne.jp/?xcid=DS_TOP_from_CRP_CHA_promotion_eraberu_docomo_mini)

- 4G端末をご利用の方はご自身の端末がご利用可能か [4G対応端末一覧（PDF形式：330KB） _PDF_](https://www.docomo.ne.jp/binary/pdf/charge/eximo/notice/supported_phones.pdf?ver=1758865571) よりご確認ください。


![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/img_privilege_docomo-mini_pc.png?ver=1749049245)![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/img_privilege_docomo-mini_smt.png?ver=1749049245)

＼Amazonプライムについて／

[ご登録はこちら _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://ssw.web.docomo.ne.jp/prime/campaign/mini_202506/?utm_source=corp_other&utm_medium=free-display&utm_campaign=ap_202506_ap_0000755)

1. ドコモからの「Amazonプライム」登録で、回線利用料と「Amazonプライム」月額会費の合計額から、「Amazonプライム」月額会費相当の600円を最大3か月間割引きます。当社提供のほかAmazonプライム割引特典と重畳はできません。本特典が優先となります。

2. 「Amazonプライム」の月額会費は600円（税込）です（2025年6月時点）。「Amazonプライム」は3か月間の割引終了後、ご登録期間中はdポイント（期間・用途限定）を毎月120ポイント還元いたします。


## ![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/logo_ahamo.png?ver=1749049245)

プランはひとつだけ！

お申し込みから契約後のサポートまでオンラインにて受付する料金プランです。

5分以内の通話無料※1・

「みんなドコモ割」のカウント対象

- 1回あたりの通話時間が5分を超過した場合、超過分について30秒ごとに22円（税込）の通話料がかかります。またデジタル通信料（テレビ電話など）についても5分以内の通信は定額対象となります。SMS、他社接続サービスなどへの発信は、別途料金がかかります。


![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/img_price_ahamo_pc.png?ver=1749049244)![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/img_price_ahamo_smt.png?ver=1749049245)

![スクロール](https://www.docomo.ne.jp/images_osp/common/img/img_guide_scroll01@2x.png)

![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/img_detail_ahamo.png?ver=1756170012)

![スクロール](https://www.docomo.ne.jp/images_osp/common/img/img_guide_scroll01@2x.png)

- dカードは年会費無料、dカード GOLD Uは年会費3,300円（税込）、dカード GOLDは年会費11,000円（税込）、dカード PLATINUMは年会費29,700円（税込）がかかります。dカード／dカード GOLD U／dカード GOLD／dカード PLATINUMにはそれぞれ所定の審査があります。


01. 機種代金・通話料が別途かかります。

02. 定期クレジット設定しているdカード GOLD U／dカード GOLD／dカード PLATINUMとは別のdカード GOLD U／dカード GOLD／dカード PLATINUMに対しご利用携帯電話番号登録いただいた場合でも、dカード GOLD U／dカード GOLDは5％、dカード PLATINUMは10％の進呈率を適用します。

03. 定期クレジットの設定状況および、 dカード GOLD U／dカード GOLD／dカード PLATINUMのご利用携帯電話番号への登録状況に関わらず、キャンペーン期間中の進呈率は10%となります。ただし、dカード決済の場合はご利用電話番号登録が必要です。

04. dポイント（期間・用途限定）は対象決済の利用があった翌月下旬に進呈され、進呈日から93日間が有効期限となります。翌月のポイント進呈日を超えて反映された売上分の特典（dポイント）は、反映が遅れた日程分、有効期限（進呈日から93日間）が短くなります。対象決済がdカード／dカード GOLD U／dカード GOLD／dカード PLATINUMの場合、決済において、キャンセルが発生した場合、対象の決済にて進呈したポイントは減算されます。dポイント獲得履歴はdポイントクラブサイトで確認が可能です。

05. 対象決済がdカード GOLD U／dカード GOLD／dカード PLATINUMの場合、対象決済の利用日の23:59時点で、ご利用携帯電話番号として登録した、本料金プランを契約している回線の利用料金をdカード／dカード GOLD U／dカード GOLD／dカード PLATINUMで支払う設定をしている必要があります。対象決済がd払い（支払い方法をdカードからの支払い、または電話料金合算払いからの支払い、またはd払い残高からの支払いに設定した場合）の場合、決済時点で本料金プランを契約している回線の料金プランをdカード／dカード GOLD U／dカード GOLD/dカード PLATINUMで支払う設定をしていることに加え、ご利用のdカード GOLD U／dカード GOLD/dカード PLATINUMに本料金プランを契約している回線のご利用携帯電話番号登録の設定をしている必要があります。

06. dカードで通常たまるポイント（利用額100円（税込）につき1ポイント）の対象になる支払い、ドコモでんきご利用料金、ドコモ ガスご利用料金および「マネックス証券」におけるdカード積立が対象です。毎月のドコモの携帯電話ご利用料金、年会費、各種手数料、電子マネー・プリペイドカードへのチャージ、「THEO＋docomo」などは進呈対象外となります。詳細は [こちら _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://dcard.docomo.ne.jp/st/beginner_about/attention/index.html) をご確認ください。

07. d払いを利用した決済であっても、dポイント利用によるお支払い分、クーポン利用によるお支払い分、モバイルSuicaチャージによるお支払い分、決済対象が請求書払い（公共料金、地方税統一QRコード等）である場合、ポイント進呈の対象外となります。なお、一部ポイント進呈対象外の店舗がございます。詳細は [こちら _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://service.smt.docomo.ne.jp/keitai_payment/town/no-reward.html) をご確認ください。

08. d払いのお支払い方法を電話料金合算払い（電話料金の支払い方法にdカード以外のクレジットカードを設定している場合を除く）、dカード、d払い残高に設定されたお支払いのみが対象です。

09. キャンペーン終了時期未定です。当社は、1か月前までに当社が適当と判断する方法で周知することにより、キャンペーンを終了することができます。

10. 対象決済を行った日において、ご利用のdカード／dカード GOLD U／dカード GOLD／dカード PLATINUM（本カード／家族カード）に本料金プランを契約している回線のご利用携帯電話番号が設定されていることが必要です。

11. d払いのお支払い方法を電話料金合算払い（電話料金の支払い方法にdカード以外のクレジットカードを設定している場合）、またはdカード以外のクレジットカードに設定したお支払いはdポイントの進呈対象外です。d払いの基本還元率は、dカードによるお支払いは1.0%、電話料金合算払い（電話料金の支払い方法にdカード以外のクレジットカードを設定している場合を除く）およびd払い残高によるお支払いは0.5%、電話料金合算払い（電話料金の支払い方法にdカード以外のクレジットカードを設定している場合）およびdカード以外のクレジットカードによるお支払いは0%となります。

12. 電話料金合算払いからの支払い（請求書払い）は、原則対象外でお客さまご自身で選択することはできません。ただし、一括請求の全廃止に伴い、一括請求の子回線だったahamoが単独請求となる場合、自動的に請求書払いの対応になることがあります。この場合、他の電話料金合算からの支払いと同様の条件および進呈率で、dポイント（期間・用途限定）を進呈いたします。


〈注意事項〉

- 「ポイ活オプション」によるポイント進呈可否の判別は、「d払い商品等購入代金」に係る決済情報の確認処理を完了した時点で行われます。

- ポイントはポイ活オプションにオプション加入している「料金プラン（ahamo）」の契約にかかるドコモ回線dアカウント（当社が別途定める「dアカウント規約」における「ドコモ回線dアカウント」の定義と同義とします）に進呈されます。

- 「ポイ活オプション」により進呈されるdポイント（期間・用途限定）の表示名称は「ahamoポイ活特典」となります。

- 以下の場合は、ポイント進呈がされません

1. d払いでのお支払いをキャンセルされた場合

2. ポイント進呈前にdポイントクラブを退会された場合

3. d払いのお支払い方法に設定しているdカードや通信によるエラーなどがあり、d払いの決済が正常に完了しなかった場合

4. 不正行為が行われたと当社が判断した場合、その他当社が提供するサービスの利用規約その他契約条件に違反する行為があった場合、またはその恐れがあると当社が判断した場合


- ポイ活オプションの月額料金は、ご利用日数にかかわらず日割りで計算しません。

- 大盛りオプションを解約した場合、その時点でポイ活オプションも自動解約となります。

- 当社は、3か月前までに当社が適当と判断する方法でポイ活オプションのご契約者に周知することにより、ポイ活オプションの一部または全部の提供内容を変更し、または提供を中止もしくは廃止することができます。

- ポイ活オプションおよび関連するキャンペーンによるdポイント（期間・用途限定）の進呈および利用に関する条件等は、本提供条件書に定める事項を除き、d払いご利用規約、dポイントクラブ会員規約に定める条件その他当社が当該条件等を個別に定める規約等に定めるところによります。

- その他詳細の注意事項や最新情報は [ahamoサイト _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://ahamo.com/special/poikatsu/) をご確認ください。


- ahamoでは一部ご利用できないサービスがあります。詳細は [こちら](https://www.docomo.ne.jp/charge/ahamo_notice/auto_cancel_service_list.html?icid=CRP_CHA_promotion_eraberu_to_CRP_CHA_ahamo_notice_auto_cancel_service_list) をご確認ください。

- 料金プラン（ahamo）の利用可能データ量（30GB）と大盛りオプションの利用可能データ量（80GB）の合計利用可能データ量（110GB）のうち、海外データ通信エリアにおけるご利用データ量が30GBを超えた場合には速度制限（送受信時最大1Mbps）がかかります。ただし、システム等の影響により30GBを超えて通常速度利用できる場合があります。


## ＼もっと知りたい方はこちら／

- [ahamoを詳しくみる _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window02.png)_](https://ahamo.com/)
- [ahamo ポイ活を詳しくみる _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window02.png)_](https://ahamo.com/special/poikatsu/)

[![NEW ahamoユーザー限定！ ahamo光 フレッツ光回線の設備を使った、光インターネットサービス](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/bnr_ahamo_02_pc.png?ver=1749049244)![NEW ahamoユーザー限定！ ahamo光 フレッツ光回線の設備を使った、光インターネットサービス](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/bnr_ahamo_02_smt.png?ver=1749049244)](https://www.docomo.ne.jp/internet/ahamo_hikari/?icid=CRP_CHA_promotion_eraberu_to_CRP_INT_ahamo_hikari)

## ＼ドコモでは他にも  ニーズに合ったプランを提供中／

### _![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/ico_other_01.png?ver=1749049244)_ スマホデビューの料金プランで  お悩みならこのプラン!

- [![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/bnr_other_01_pc.png?ver=1749049244)![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/bnr_other_01_smt.png?ver=1749049244)](https://www.docomo.ne.jp/support/promotion/migration/?icid=CRP_CHA_promotion_eraberu_to_CRP_SUP_promotion_migration)
- [![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/bnr_other_02_pc.png?ver=1749049244)![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/bnr_other_02_smt.png?ver=1749049244)](https://www.docomo.ne.jp/charge/promotion/u15_hajimete_plan/?icid=CRP_CHA_promotion_eraberu_to_CRP_CHA_promotion_u15_hajimete_plan)

### _![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/ico_other_02.png?ver=1749049244)_ データ容量を抑えた利用なら  こちらもチェック

[![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/bnr_other_03_pc.png?ver=1749049244)![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/bnr_other_03_smt.png?ver=1749049244)](https://www.docomo.ne.jp/charge/docomo_economy_mvno/?icid=CRP_CHA_promotion_eraberu_to_CRP_CHA_docomo_economy_mvno)

- エコノミーMVNOとはドコモショップでお手続き可能な、MVNO事業者。


## 料金プランの変更・ご購入

- [**契約前に金額を比較したい**![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/img_line_01.png?ver=1721696417)\\
\\
![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/ico_charge_sim_01.png?ver=1721696417)\\
\\
料金\\
\\
シミュレーション\\
\\
![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/ico_circle_arrow_red.png?ver=1749049244)](https://www.docomo.ne.jp/charge/simulation/?icid=CRP_CHA_promotion_eraberu_to_CRP_CHA_simulation)
- [**機種を購入してプラン契約**![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/img_line_01.png?ver=1721696417)\\
\\
![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/ico_contract_01.png?ver=1721696417)\\
\\
新規契約・機種変更\\
\\
![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/ico_circle_external_red.png?ver=1749049244)](https://www.docomo.ne.jp/charge/promotion/eraberu/#select-plan-modal--subscribe-switch-01)
- [**現在の機種でプランを見直し**![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/img_line_01.png?ver=1721696417)\\
\\
![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/ico_plan_change_01.png?ver=1721696417)\\
\\
プラン変更・のりかえ（MNP）\\
\\
![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/ico_circle_external_red.png?ver=1749049244)](https://www.docomo.ne.jp/charge/promotion/eraberu/#select-plan-modal--subscribe-switch-02)

## ご契約内容の確認はこちら

[![mydocomo](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/ico_mydocomo_01.png?ver=1721696417)![別ウインドウで開きます。](https://www.docomo.ne.jp/images_osp/common/ico/ico_circle_external_black.svg)](https://mydocomo.docomo.ne.jp/)

×

#### 新規契約・機種変更

ご希望のプランを選択

[![ドコモ MAX](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/logo_docomo-max.png?ver=e)\\
_![別ウインドウで開きます。](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://onlineshop.docomo.ne.jp/products/mobile?xcid=OLS_mobile_from_CRP_202508_max_eraberu_with-product&utm_source=corp_charge&utm_medium=owned&utm_campaign=ols_202508_max-eraberu&utm_content=202508_max_mobile_eraberu_with-product)

[![ドコモ ポイ活 MAX](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/logo_docomo-poikatsu-max.png?ver=e)\\
_![別ウインドウで開きます。](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://onlineshop.docomo.ne.jp/products/mobile?xcid=OLS_mobile_from_CRP_202508_poikatsu-max_eraberu_with-product&utm_source=corp_charge&utm_medium=owned&utm_campaign=ols_202508_poikatsu-max-eraberu&utm_content=202508_poikatsu-max_mobile_eraberu_with-product)

[![ドコモ ポイ活 20](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/logo_docomo-poikatsu-20.png?ver=e)\\
_![別ウインドウで開きます。](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://onlineshop.docomo.ne.jp/products/mobile?xcid=OLS_mobile_from_CRP_202508_poikatsu20_eraberu_with-product&utm_source=corp_charge&utm_medium=owned&utm_campaign=ols_202508_poikatsu20-eraberu&utm_content=202508_poikatsu20_mobile_eraberu_with-product)

[![ドコモ mini](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/logo_docomo-mini.png?ver=e)\\
_![別ウインドウで開きます。](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://onlineshop.docomo.ne.jp/products/mobile?xcid=OLS_mobile_from_CRP_202508_mini_eraberu_with-product&utm_source=corp_charge&utm_medium=owned&utm_campaign=ols_202508_mini-eraberu&utm_content=202508_mini_mobile_eraberu_with-product)

[![ahamo（アハモ）](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/logo_ahamo.png?ver=1749049243)\\
_![別ウインドウで開きます。](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://ahamo.com/store/pub/application/type/)

[その他のプラン\\
\\
（はじめてスマホ\\
\\
プランなど）\\
\\
_![別ウインドウで開きます。](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://onlineshop.docomo.ne.jp/products/mobile?xcid=OLS_products_mobile_from_CRP_CHA_promotion_eraberu)

[機種のみ変更をご希望の方はオンラインショップでお手続きしてください。 _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://onlineshop.docomo.ne.jp/products/mobile?_gl=1*19s39zb*_gcl_au*MTk0NDI0NjAyMC4xNzQyOTc1NzYy*ga4_corporate_ga*MTYyNTQxMTkxOC4xNzE5MjkyNzIw*ga4_corporate_ga_PGCZ86Z6FM*czE3NDcxODgxNTckbzIyNCRnMSR0MTc0NzE5MDU3MiRqMTAkbDAkaDA.&xcid=OLS_products_mobile_from_CRP_CHA_promotion_eraberu)

閉じる

×

#### プラン変更・のりかえ（MNP）

ご希望のプランを選択

- ドコモ回線から
- 他社回線から

[![ドコモ MAX](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/logo_docomo-max.png?ver=e)\\
_![別ウインドウで開きます。](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://mydocomo.docomo.ne.jp/procedure/process?pid=201&xcid=OLT_procedure_process_from_CRP_max_plan_newplan_LP2)

[![ドコモ ポイ活 MAX](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/logo_docomo-poikatsu-max.png?ver=e)\\
_![別ウインドウで開きます。](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://mydocomo.docomo.ne.jp/procedure/process?pid=201&xcid=OLT_procedure_process_from_CRP_poikatsu-max_plan_newplan_LP2)

[![ドコモ ポイ活 20](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/logo_docomo-poikatsu-20.png?ver=e)\\
_![別ウインドウで開きます。](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://mydocomo.docomo.ne.jp/procedure/process?pid=201&xcid=OLT_procedure_process_from_CRP_poikatsu20_plan_newplan_LP2)

[![ドコモ mini](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/logo_docomo-mini.png?ver=e)\\
_![別ウインドウで開きます。](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://mydocomo.docomo.ne.jp/procedure/process?pid=201&xcid=OLT_procedure_process_from_CRP_mini_plan_newplan_LP2)

[![ahamo（アハモ）](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/logo_ahamo.png?ver=1749049243)\\
_![別ウインドウで開きます。](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://ahamo.com/store/pub/application/type/)

[その他のプラン\\
\\
（はじめてスマホプランなど）\\
\\
_![別ウインドウで開きます。](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://application.ald.smt.docomo.ne.jp/VIEW_ESITE/est/sc/main.jsp)

- 他社回線からののりかえで、機種も一緒に購入をご希望の方は、「新規契約・機種変更」の窓口よりお手続きください。


[他社回線からドコモ MAXなどのその他プラン、ahamoからドコモ MAXなどのその他プランへの変更は、事前にSIMカードの発行手続きが必要です。 _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://onlineshop.smt.docomo.ne.jp/sim-card/index.html?_gl=1*hjzcr6*_gcl_au*MTk0NDI0NjAyMC4xNzQyOTc1NzYy*ga4_corporate_ga*MTYyNTQxMTkxOC4xNzE5MjkyNzIw*ga4_corporate_ga_PGCZ86Z6FM*czE3NDcxODgxNTckbzIyNCRnMSR0MTc0NzE5MDU2MyRqMTkkbDAkaDA.)

[![ドコモ MAX](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/logo_docomo-max.png?ver=e)\\
_![別ウインドウで開きます。](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://onlineshop.docomo.ne.jp/products/exclusive/sim?xcid=OLS_sim_from_CRP_202508_max_eraberu_sim-only&utm_source=corp_charge&utm_medium=owned&utm_campaign=ols_202508_max-eraberu&utm_content=202508_max_sim_eraberu_sim-only)

[![ドコモ ポイ活 MAX](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/logo_docomo-poikatsu-max.png?ver=e)\\
_![別ウインドウで開きます。](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://onlineshop.docomo.ne.jp/products/exclusive/sim?xcid=OLS_sim_from_CRP_202508_poikatsu-max_eraberu_sim-only&utm_source=corp_charge&utm_medium=owned&utm_campaign=ols_202508_poikatsu-max-eraberu&utm_content=202508_poikatsu-max_sim_eraberu_sim-only)

[![ドコモ ポイ活 20](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/logo_docomo-poikatsu-20.png?ver=e)\\
_![別ウインドウで開きます。](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://onlineshop.docomo.ne.jp/products/exclusive/sim?xcid=OLS_sim_from_CRP_202508_poikatsu20_eraberu_sim-only&utm_source=corp_charge&utm_medium=owned&utm_campaign=ols_202508_poikatsu20-eraberu&utm_content=202508_poikatsu20_sim_eraberu_sim-only)

[![ドコモ mini](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/logo_docomo-mini.png?ver=e)\\
_![別ウインドウで開きます。](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://onlineshop.docomo.ne.jp/products/exclusive/sim?xcid=OLS_sim_from_CRP_202508_mini_eraberu_sim-only&utm_source=corp_charge&utm_medium=owned&utm_campaign=ols_202508_mini-eraberu&utm_content=202508_mini_sim_eraberu_sim-only)

[![ahamo（アハモ）](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/logo_ahamo.png?ver=1749049243)\\
_![別ウインドウで開きます。](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://ahamo.com/store/pub/application/type/)

[その他のプラン\\
\\
（はじめてスマホ\\
\\
プランなど）\\
\\
_![別ウインドウで開きます。](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://application.ald.smt.docomo.ne.jp/VIEW_ESITE/est/sc/main.jsp)

- 他社回線からののりかえで、機種も一緒に購入をご希望の方は、「新規契約・機種変更」の窓口よりお手続きください。


[他社回線からドコモ MAXなどのその他プラン、ahamoからドコモ MAXなどのその他プランへの変更は、事前にSIMカードの発行手続きが必要です。 _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://onlineshop.smt.docomo.ne.jp/sim-card/index.html?_gl=1*hjzcr6*_gcl_au*MTk0NDI0NjAyMC4xNzQyOTc1NzYy*ga4_corporate_ga*MTYyNTQxMTkxOC4xNzE5MjkyNzIw*ga4_corporate_ga_PGCZ86Z6FM*czE3NDcxODgxNTckbzIyNCRnMSR0MTc0NzE5MDU2MyRqMTkkbDAkaDA.)

閉じる

## おすすめ！

[![My docomo](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/ico_mydocomo_02.png?ver=1721696417)\\
現在のご契約\\
\\
を\\
\\
確認する _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03-strong_v2.png)_](https://mydocomo.docomo.ne.jp/) [![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/ico_plan_change_02.png?ver=e)\\
プラン変更・\\
\\
のりかえ（MNP） __](https://www.docomo.ne.jp/charge/promotion/eraberu/#select-plan-modal--subscribe-switch-02) [![](https://www.docomo.ne.jp/flcache_data/charge/promotion/eraberu/images/ico_tetsuduki_support01.png?ver=1737435971)\\
オンライン\\
\\
で相談 _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03-strong_v2.png)_](https://tetsuduki-support.docomo.ne.jp/?utm_source=corp&utm_medium=free-display&utm_campaign=onsapo_202501_corp-eraberu&utm_content=corp-eraberu-202501) [![閉じる](https://www.docomo.ne.jp/images_osp/common/btn/btn_x_close_01_pc.png)](https://www.docomo.ne.jp/charge/promotion/eraberu/#)

[![このページのトップへ](https://www.docomo.ne.jp/images_osp/common/btn/btn_pagetop_01.png)](https://www.docomo.ne.jp/charge/promotion/eraberu/#)

## よくあるご質問（FAQ）

- ![Q](https://www.docomo.ne.jp/images_osp/common/ico/ico_question01.png)



[_料金_ _プラン_ の変更に手数料はかかりますか？](https://faq.front.smt.docomo.ne.jp/detail?faqId=240797&utm_source=docomo.ne.jp&utm_medium=api_linkage&utm_campaign=api_CRP_CHA_promotion_eraberu)

- ![Q](https://www.docomo.ne.jp/images_osp/common/ico/ico_question01.png)



[_料金_ _プラン_ 変更をしたい](https://faq.front.smt.docomo.ne.jp/detail?faqId=170006&utm_source=docomo.ne.jp&utm_medium=api_linkage&utm_campaign=api_CRP_CHA_promotion_eraberu)

- ![Q](https://www.docomo.ne.jp/images_osp/common/ico/ico_question01.png)



[_料金_ _プラン_ の変更を予約したい](https://faq.front.smt.docomo.ne.jp/detail?faqId=146865&utm_source=docomo.ne.jp&utm_medium=api_linkage&utm_campaign=api_CRP_CHA_promotion_eraberu)


[「料金プラン」に関するよくあるご質問（FAQ）へ](https://faq.front.smt.docomo.ne.jp/search?keyword=%E6%96%99%E9%87%91%E3%83%97%E3%83%A9%E3%83%B3&categoryId=9&utm_source=docomo.ne.jp&utm_medium=api_linkage&utm_campaign=api_CRP_CHA_promotion_eraberu&sort=3)

[![お困りですか？](https://www.docomo.ne.jp/images_osp/common/chat_tool/bnr_chat_tool.svg)](https://tetsuduki-support.docomo.ne.jp/?utm_source=corp&utm_medium=free-display&utm_campaign=onsapo_)

このページの情報は役に立ちましたか？

- はい
- いいえ

送信する

このページの情報は役に立ちましたか？

- はい
- いいえ

送信する

## ドコモサイトの改善のために、  あなたの回答の理由を教えてください（問）

※「アンケートに回答する」ボタンを押すと、

アンケート画面が開きます。

[アンケートに回答する](https://www.docomo.ne.jp/charge/promotion/eraberu/#survey)

## ご回答ありがとうございました

ご意見は今後のWebサイト改善の参考とさせていただきます。

- データは匿名化されており、個人が特定されることはございません。また調査以外の目的で利用されることはございません。


## NTTドコモサイトについてのアンケート

差し支えなければ、以下のアンケートにもご協力ください。

※この画面を閉じて元のページに戻るには画面右上の「閉じる」を押してください。

### Q.お探しの情報はどのような情報でしたか？あてはまるものをすべて選択してください。

### Q.あなたの年齢をお答えください。

- 10代以下
- 20代
- 30代
- 40代
- 50代
- 60代
- 70代以上
- 回答しない

10代以下20代30代選択してください40代50代60代70代以上回答しない

### Q.このページが「役に立たなかった」と思われた点について、あてはまるものをすべて選択してください。

- [ ] 知りたい情報が書かれていなかった
- [ ] 必要な情報がまとまっていなかった
- [ ] 知りたい内容までの適切な誘導がなかった
- [ ] GoogleやYahoo！で検索しても目的のページが出てこなかった
- [ ] このサイト内で検索しても目的のページが出てこなかった
- [ ] どのキーワードで検索すればいいかわからなかった
- [ ] 目的と違うページにたどり着いた
- [ ] 見たい情報がどこにありそうか想定できなかった
- [ ] 選択肢が紛らわしかった
- [ ] クリックなど操作がしづらかった
- [ ] 文章がわかりづらかった
- [ ] 絵や画像がわかりづらかった
- [ ] 表示されるのが遅かった
- [ ] その他
- [ ] あてはまるものはない

回答を送信する

## NTTドコモサイトについてのアンケート

### ご回答ありがとうございました。

※本アンケートに関する個人情報等の取扱いについては「 [NTTドコモ プライバシーポリシー](https://www.docomo.ne.jp/utility/privacy/?icid=CRP_SURVEY_end_to_CRP_UTI_privacy)」で定めています。

- [お知らせ](https://www.docomo.ne.jp/info/?icid=CRP_common_footer_to_CRP_INFO)
- [企業情報](https://www.docomo.ne.jp/corporate/?icid=CRP_common_footer_to_CRP_CORP)

* * *

- [パーソナルデータ（個人情報など）について](https://www.docomo.ne.jp/utility/personal_data/?icid=CRP_common_footer_to_CRP_UTI_personal_data)
- [プライバシーポリシー](https://www.docomo.ne.jp/utility/privacy/?icid=CRP_common_footer_to_CRP_UTI_privacy)
- [サイトご利用にあたって](https://www.docomo.ne.jp/utility/term/?icid=CRP_common_footer_to_CRP_UTI_term)
- [お客さまご利用端末からの情報の外部送信について](https://www.docomo.ne.jp/utility/term/?icid=CRP_common_footer_02_to_CRP_UTI_term#p09)
- [見やすさ・使いやすさの調整](https://www.docomo.ne.jp/utility/term/web_accessibility/faciliti/?icid=CRP_common_footer_to_CRP_UTI_term_web_accessibility_faciliti)
- [サイトメンテナンス情報 _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon-white.svg)_](https://www.docomo.ne.jp/mydocomo/maint/?icid=CRP_common_footer_to_CRP_MYD_maint)
- [サイトマップ](https://www.docomo.ne.jp/sitemap/?icid=CRP_common_footer_to_CRP_sitemap)
- [ご意見・ご要望](https://www.docomo.ne.jp/support/inquiry/feedback/?icid=CRP_common_footer_to_CRP_SUP_inquiry_feedback)
- [お問い合わせ](https://www.docomo.ne.jp/support/inquiry/?icid=CRP_common_footer_to_CRP_SUP_inquiry)
- [NTTドコモグループ _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon-white.svg)_](https://nttdocomo-group.com/index.html)

© NTT DOCOMO

![閉じる](https://www.docomo.ne.jp/images_osp/common/smtnav/btn_smtmenu_01_close_crp.png)