---
url: "https://www.docomo.ne.jp/charge/128k/about/"
title: "定額データプラン１２８Ｋとは | 定額データプラン１２８Ｋ | 料金・割引 | NTTドコモ"
---

[![NTT docomo](https://www.docomo.ne.jp/images_osp/common/newhf/header/cmn-rwd-header-logo.svg?ver=1751324418)](https://www.docomo.ne.jp/?icid=CRP_common_header_to_CRP_TOP)

- [![別ウィンドウで開きます。my docomo](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-my-docomo-logo.svg)](https://www.docomo.ne.jp/mydocomo/?icid=CRP_outerhead_to_MYD_TOP)
- [![別ウィンドウで開きます。Online Shop](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-online-shop-icon2.svg)](https://onlineshop.docomo.ne.jp/top-ols/?xcid=OLS_TOP_from_CRP_outerhead)

- 商品・サービス












- モバイル
  - [iPhone](https://www.docomo.ne.jp/iphone/?icid=CRP_menu_to_CRP_IPH)

  - [iPad](https://www.docomo.ne.jp/ipad/?icid=CRP_menu_to_CRP_IPA)

  - [製品](https://www.docomo.ne.jp/product/?icid=CRP_menu_to_CRP_PRD)

  - [料金・割引](https://www.docomo.ne.jp/charge/?icid=CRP_menu_to_CRP_CHA)

  - [サービス・機能](https://www.docomo.ne.jp/service/?icid=CRP_menu_to_CRP_SER)

  - [通信・エリア](https://www.docomo.ne.jp/area/?icid=CRP_menu_to_CRP_AREA)
- インターネット回線・固定電話
  - [インターネット回線・固定電話トップ](https://www.docomo.ne.jp/internet/?icid=CRP_menu_to_CRP_INT)

  - [ドコモ光](https://www.docomo.ne.jp/internet/hikari/?icid=CRP_menu_to_CRP_INT_hikari)

  - [ahamo光](https://www.docomo.ne.jp/internet/ahamo_hikari/?icid=CRP_menu_to_CRP_internet_ahamo_hikari)

  - [home 5G](https://www.docomo.ne.jp/home_5g/?icid=CRP_menu_to_CRP_HOM)

  - [homeでんわ](https://www.docomo.ne.jp/home_denwa/?icid=CRP_menu_to_CRP_DENWA)
- スマートライフ
  - [スマートライフ トップ](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_menu_to_CRP_SER_smart-life)

  - [決済・保険・投資](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_menu_to_CRP_SER_smart-life_finance&tgl_entertainment=0&tgl_life-support=0&tgl_finance=1&tgl_shopping=0&tgl_healthcare=0#finance)

  - [エンターテインメント](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_menu_to_CRP_SER_smart-life_entertainment&tgl_entertainment=1&tgl_life-support=0&tgl_finance=0&tgl_shopping=0&tgl_healthcare=0#entertainment)

  - [ライフサポート](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_menu_to_CRP_SER_smart-life_life-support&tgl_entertainment=0&tgl_life-support=1&tgl_finance=0&tgl_shopping=0&tgl_healthcare=0#life-support)

  - [ショッピング](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_menu_to_CRP_SER_smart-life_shopping&tgl_entertainment=0&tgl_life-support=0&tgl_finance=0&tgl_shopping=1&tgl_healthcare=0#shopping)

  - [ヘルスケア](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_menu_to_CRP_SER_smart-life_healthcare&tgl_entertainment=0&tgl_life-support=0&tgl_finance=0&tgl_shopping=0&tgl_healthcare=1#healthcare)
- 電気・ガス
  - [ドコモでんき／\\
      \\
      ドコモ ガス トップ](https://www.docomo.ne.jp/denki/?icid=CRP_menu_to_CRP_DENKI)

- お知らせ














- [お知らせトップ](https://www.docomo.ne.jp/info/?icid=CRP_menu_to_CRP_INFO)

- [ニュースルーム](https://www.docomo.ne.jp/info/update/?icid=CRP_menu_to_CRP_INFO_update)

- [報道発表](https://www.docomo.ne.jp/info/news_release/?icid=CRP_menu_to_CRP_INFO_news_release)

- [重要なお知らせ（通信障害）](https://www.docomo.ne.jp/info/network/?icid=CRP_menu_to_CRP_INFO_network)

- [携帯電話サービスの通信状況（地域別）](https://www.docomo.ne.jp/info/status/?icid=CRP_menu_to_CRP_INFO_status)

- [工事のお知らせ](https://www.docomo.ne.jp/info/construction/?icid=CRP_menu_to_CRP_INFO_construction)


- 企業情報














- [企業情報トップ](https://www.docomo.ne.jp/corporate/?icid=CRP_menu_to_CRP_CORP)

- [あなたとドコモ](https://www.docomo.ne.jp/corporate/anatatodocomo/?icid=CRP_menu_to_CRP_CORP_anatatodocomo)

- [企業理念・ビジョン](https://www.docomo.ne.jp/corporate/philosophy_vision/?icid=CRP_menu_to_CRP_CORP_philosophy_vision)

- [会社案内](https://www.docomo.ne.jp/corporate/about/?icid=CRP_menu_to_CRP_CORP_about)

- [サステナビリティ](https://www.docomo.ne.jp/corporate/csr/?icid=CRP_menu_to_CRP_CORP_csr)

- [技術とあんしん](https://www.docomo.ne.jp/corporate/technology_safety/?icid=CRP_menu_to_CRP_CORP_technology_safety)

- [IR情報](https://www.docomo.ne.jp/corporate/ir/library/?icid=CRP_menu_to_CRP_CORP_ir_library)

- [採用情報](https://www.docomo.ne.jp/corporate/recruit/?icid=CRP_menu_to_CRP_CORP_recruit)

- [NTTドコモグループ _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://nttdocomo-group.com/index.html)


- 法人のお客さま














- [NTTドコモビジネス _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.ntt.com/index.html)

- [NTTドコモ\\
\\
ソリューションズ _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.nttcom.co.jp/)

- [NTTドコモ・グローバル](https://www.docomo.ne.jp/global/?icid=CRP_TOP_to_CRP_global)


- [![別ウィンドウで開きます。my docomo](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-my-docomo-logo.svg)](https://www.docomo.ne.jp/mydocomo/?icid=CRP_outerhead_to_MYD_TOP)



[![別ウィンドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-online-shop-icon.svg)\\
Online Shop](https://onlineshop.docomo.ne.jp/top-ols/?xcid=OLS_TOP_from_CRP_outerhead)



[![別ウィンドウで開きます。のりかえ（MNP）](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-online-mnp-icon_pc.png)](https://onlineshop.docomo.ne.jp/special-contents/mnp?xcid=OLS_special-contents_mnp_flow_from_CRP_TOP_mnp_btn)



[![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-switch-online-icon.svg)機種変更](https://www.docomo.ne.jp/support/switch_online/?icid=CRP_outerhead_to_SUP_switch_online)


[![](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-daccount-logo.svg)\\
ログインする](https://cfg.smt.docomo.ne.jp/auth/cgi/anidlogin?rl=https%3A%2F%2Fwww.docomo.ne.jp%2Fcharge%2F128k%2Fabout%2F)

[![dポイントクラブ](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-d-point-club-logo.svg)\\
\\
P\\
\\
![ランク](https://www.docomo.ne.jp/charge/128k/about/)](https://www.docomo.ne.jp/charge/128k/about/) [![ドコモビジネスメンバーズ](https://www.docomo.ne.jp/images_osp/common/newhf/ico/ico_businessmembers.png)](https://www.docomo.ne.jp/charge/128k/about/)

MENU

[![NTT docomo](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-header-logo.svg?ver=1751324418)](https://www.docomo.ne.jp/?icid=CRP_drawer_to_CRP_TOP)

[English](https://www.docomo.ne.jp/english/?icid=CRP_drawer_to_CRP_EN)

* * *

![検索する](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-header-search-icon.svg)

- [![](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-my-docomo-logo.svg)My docomo _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.docomo.ne.jp/mydocomo/?icid=CRP_drawer_to_MYD_TOP)
- [![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-online-shop-icon.svg)Online Shop _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://onlineshop.docomo.ne.jp/top-ols/?xcid=OLS_TOP_from_CRP_drawer)
- [![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-docomo-shop-icon.svg)ドコモショップ _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://shop.smt.docomo.ne.jp/?xcid=DS_TOP_from_CRP_drawer)
- [![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-customer-support-icon.svg)お客さまサポート](https://www.docomo.ne.jp/support/?icid=CRP_drawer_sup01_to_CRP_SUP)
- [![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-campaign-icon.svg)キャンペーン・特典](https://www.docomo.ne.jp/campaign_event/?icid=CRP_drawer_to_CRP_CAM)
- [![](https://www.docomo.ne.jp/assets/content/dam/corp/jp/ja/common/images/logo/cmn-rwd-d-point-club-logo.svg)dポイントクラブ _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://dpoint.docomo.ne.jp/)

- 商品・サービス
  - ![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/ico_mobile.png)モバイル



- [iPhone](https://www.docomo.ne.jp/iphone/?icid=CRP_drawer_to_CRP_IPH)
- [iPad](https://www.docomo.ne.jp/ipad/?icid=CRP_drawer_to_CRP_IPA)
- [製品](https://www.docomo.ne.jp/product/?icid=CRP_drawer_to_CRP_PRD)
- [料金・割引](https://www.docomo.ne.jp/charge/?icid=CRP_drawer_to_CRP_CHA)
- [サービス・機能](https://www.docomo.ne.jp/service/?icid=CRP_drawer_to_CRP_SER)
- [通信・エリア](https://www.docomo.ne.jp/area/?icid=CRP_drawer_to_CRP_AREA)

  - ![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/ico_internet.png)インターネット回線・固定電話



- [インターネット回線・固定電話トップ](https://www.docomo.ne.jp/internet/?icid=CRP_drawer_to_CRP_INT)
- [ドコモ光](https://www.docomo.ne.jp/internet/hikari/?icid=CRP_drawer_to_CRP_INT_hikari)
- [ahamo光](https://www.docomo.ne.jp/internet/ahamo_hikari/?icid=CRP_drawer_to_CRP_internet_ahamo_hikari)
- [home 5G](https://www.docomo.ne.jp/home_5g/?icid=CRP_drawer_to_CRP_HOM)
- [homeでんわ](https://www.docomo.ne.jp/home_denwa/?icid=CRP_drawer_to_CRP_DENWA)

  - ![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/ico_smartlife.png)スマートライフ



- [スマートライフ トップ](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_drawer_to_CRP_SER_smart-life)
- [決済・保険・投資](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_drawer_to_CRP_SER_smart-life_finance&tgl_entertainment=0&tgl_life-support=0&tgl_finance=1&tgl_shopping=0&tgl_healthcare=0#finance)
- [エンターテインメント](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_drawer_to_CRP_SER_smart-life_entertainment&tgl_entertainment=1&tgl_life-support=0&tgl_finance=0&tgl_shopping=0&tgl_healthcare=0#entertainment)
- [ライフサポート](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_drawer_to_CRP_SER_smart-life_life-support&tgl_entertainment=0&tgl_life-support=1&tgl_finance=0&tgl_shopping=0&tgl_healthcare=0#life-support)
- [ショッピング](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_drawer_to_CRP_SER_smart-life_shopping&tgl_entertainment=0&tgl_life-support=0&tgl_finance=0&tgl_shopping=1&tgl_healthcare=0#shopping)
- [ヘルスケア](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_drawer_to_CRP_SER_smart-life_healthcare&tgl_entertainment=0&tgl_life-support=0&tgl_finance=0&tgl_shopping=0&tgl_healthcare=1#healthcare)

  - ![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/ico_denki.png?ver=1748827032)電気・ガス



- [ドコモでんき／\\
\\
ドコモ ガス トップ](https://www.docomo.ne.jp/denki/?icid=CRP_drawer_to_CRP_DENKI)
- お知らせ
  - お知らせ

- [お知らせ トップ](https://www.docomo.ne.jp/info/?icid=CRP_drawer_to_CRP_INFO)
- [ニュースルーム](https://www.docomo.ne.jp/info/update/?icid=CRP_drawer_to_CRP_INFO_update)
- [報道発表](https://www.docomo.ne.jp/info/news_release/?icid=CRP_drawer_to_CRP_INFO_news_release)
- [重要なお知らせ（通信障害）](https://www.docomo.ne.jp/info/network/?icid=CRP_drawer_to_CRP_INFO_network)
- [携帯電話サービスの通信状況（地域別）](https://www.docomo.ne.jp/info/status/?icid=CRP_drawer_to_CRP_INFO_status)
- [工事のお知らせ](https://www.docomo.ne.jp/info/construction/?icid=CRP_drawer_to_CRP_INFO_construction)
- 企業情報
  - 企業情報

- [企業情報 トップ](https://www.docomo.ne.jp/corporate/?icid=CRP_drawer_to_CRP_CORP)
- [あなたとドコモ](https://www.docomo.ne.jp/corporate/anatatodocomo/?icid=CRP_drawer_to_CRP_CORP_anatatodocomo)
- [企業理念・ビジョン](https://www.docomo.ne.jp/corporate/philosophy_vision/?icid=CRP_drawer_to_CRP_CORP_philosophy_vision)
- [会社案内](https://www.docomo.ne.jp/corporate/about/?icid=CRP_drawer_to_CRP_CORP_about)
- [サステナビリティ](https://www.docomo.ne.jp/corporate/csr/?icid=CRP_drawer_to_CRP_CORP_csr)
- [技術とあんしん](https://www.docomo.ne.jp/corporate/technology_safety/?icid=CRP_drawer_to_CRP_CORP_technology_safety)
- [IR情報](https://www.docomo.ne.jp/corporate/ir/library/?icid=CRP_drawer_to_CRP_CORP_ir_library)
- [採用情報](https://www.docomo.ne.jp/corporate/recruit/?icid=CRP_drawer_to_CRP_CORP_recruit)
- [NTTドコモグループ _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://nttdocomo-group.com/index.html)
- 地域別情報

- [北海道](https://www.docomo.ne.jp/hokkaido/?icid=CRP_drawer_to_hokkaido)
- [東北](https://www.docomo.ne.jp/tohoku/?icid=CRP_drawer_to_tohoku)
- [関東・甲信越](https://www.docomo.ne.jp/kanto/?icid=CRP_drawer_to_kanto)
- [東海](https://www.docomo.ne.jp/tokai/?icid=CRP_drawer_to_tokai)
- [北陸](https://www.docomo.ne.jp/hokuriku/?icid=CRP_drawer_to_hokuriku)
- [関西](https://www.docomo.ne.jp/kansai/?icid=CRP_drawer_to_kansai)
- [中国](https://www.docomo.ne.jp/chugoku/?icid=CRP_drawer_to_chugoku)
- [四国](https://www.docomo.ne.jp/shikoku/?icid=CRP_drawer_to_shikoku)
- [九州・沖縄](https://www.docomo.ne.jp/kyushu/?icid=CRP_drawer_to_kyushu)

- 地域別情報



- [北海道](https://www.docomo.ne.jp/hokkaido/?icid=CRP_drawer_to_hokkaido) \|
- [東北](https://www.docomo.ne.jp/tohoku/?icid=CRP_drawer_to_tohoku) \|
- [関東・甲信越](https://www.docomo.ne.jp/kanto/?icid=CRP_drawer_to_kanto) \|
- [東海](https://www.docomo.ne.jp/tokai/?icid=CRP_drawer_to_tokai) \|
- [北陸](https://www.docomo.ne.jp/hokuriku/?icid=CRP_drawer_to_hokuriku) \|
- [関西](https://www.docomo.ne.jp/kansai/?icid=CRP_drawer_to_kansai) \|
- [中国](https://www.docomo.ne.jp/chugoku/?icid=CRP_drawer_to_chugoku) \|
- [四国](https://www.docomo.ne.jp/shikoku/?icid=CRP_drawer_to_shikoku) \|
- [九州・沖縄](https://www.docomo.ne.jp/kyushu/?icid=CRP_drawer_to_kyushu)
- 法人のお客さま

- [NTTドコモビジネス _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.ntt.com/index.html)
- [NTTドコモソリューションズ _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.nttcom.co.jp/)
- [NTTドコモ・グローバル](https://www.docomo.ne.jp/global/?icid=CRP_drawer_to_CRP_global)

- 法人のお客さま



- [NTTドコモビジネス _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.ntt.com/index.html) \|
- [NTTドコモソリューションズ _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.nttcom.co.jp/) \|
- [NTTドコモ・グローバル](https://www.docomo.ne.jp/global/?icid=CRP_drawer_to_CRP_global)

ログインすると

ポイント・ランク情報が確認できます

[![](https://www.docomo.ne.jp/assets/content/dam/corp/jp/ja/common/images/logo/cmn-rwd-d-point-club-logo.svg)dアカウントにログインする](https://cfg.smt.docomo.ne.jp/auth/cgi/anidlogin?rl=https%3A%2F%2Fwww.docomo.ne.jp)

- [dアカウントでもっと便利に](https://www.docomo.ne.jp/utility/daccount/?icid=CRP_drawer_to_CRP_UTI_daccount)
- [別のIDでログイン](https://cfg.smt.docomo.ne.jp/auth/cgi/anidlogin?rl=https%3A%2F%2Fwww.docomo.ne.jp%2F)
- [ログアウト](https://www.docomo.ne.jp/mydocomo/utility/confirm_logout/index.html)
- [会員情報確認・変更 _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon-white.svg)_](https://profile.smt.docomo.ne.jp/VIEW_ESITE/mem/sc/main.jsp?nid=MEG002006BJP)
- [ログインでお困りの方 _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon-white.svg)_](https://id.smt.docomo.ne.jp/src/utility/idpw_forget.html)
- [２段階認証のお願い _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon-white.svg)_](https://id.smt.docomo.ne.jp/src/utility/sp/twostepauth.html)

オートログイン中

[![ランク](https://www.docomo.ne.jp/charge/128k/about/#)](https://dpoint.docomo.ne.jp/member/stage_info/index.html)

* * *

[うち期間・用途限定](https://www.docomo.ne.jp/charge/128k/about/)

* * *

[![ドコモビジネスメンバーズ](https://www.docomo.ne.jp/images_osp/common/newhf/ico/ico_businessmembers.png)](https://www.docomo.ne.jp/charge/128k/about/)

- [別のIDでログイン](https://cfg.smt.docomo.ne.jp/auth/cgi/anidlogin?rl=https%3A%2F%2Fwww.docomo.ne.jp%2F)
- [ログアウト](https://www.docomo.ne.jp/mydocomo/utility/confirm_logout/index.html)
- [会員情報確認・変更 _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon-white.svg)_](https://profile.smt.docomo.ne.jp/VIEW_ESITE/mem/sc/main.jsp?nid=MEG002006BJP)
- [２段階認証のお願い _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon-white.svg)_](https://id.smt.docomo.ne.jp/src/utility/sp/twostepauth.html)

- [CMギャラリー _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.youtube.com/playlist?list=PLB334710B4B8111A8)
- [よくあるご質問](https://faq.front.smt.docomo.ne.jp/?utm_source=docomo.ne.jp&utm_medium=api_linkage&utm_campaign=api_CRP_TOP)
- [見やすさ・使いやすさの調整](https://www.docomo.ne.jp/utility/term/web_accessibility/faciliti/?icid=CRP_drawer_to_CRP_UTI_term_web_accessibility_faciliti)
- [パーソナルデータ（個人情報など）について](https://www.docomo.ne.jp/utility/personal_data/?icid=CRP_drawer_to_CRP_UTI_personal_data)

- [![](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-daccount-logo.svg)\\
ログインする](https://cfg.smt.docomo.ne.jp/auth/cgi/anidlogin?rl=https%3A%2F%2Fwww.docomo.ne.jp%2Fcharge%2F128k%2Fabout%2F)
- [![別ウィンドウで開きます。のりかえ（MNP）](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-online-mnp-icon_smt.png)](https://onlineshop.docomo.ne.jp/special-contents/mnp?xcid=OLS_special-contents_mnp_flow_from_CRP_TOP_mnp_btn)

- [![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-switch-online-icon.svg)機種変更](https://www.docomo.ne.jp/support/switch_online/?icid=CRP_outerhead_to_SUP_switch_online)
- [![](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-d-point-club-logo.svg)\\
\\
P\\
\\
![](https://www.docomo.ne.jp/charge/128k/about/)](https://www.docomo.ne.jp/charge/128k/about/)

[![ドコモビジネスメンバーズ](https://www.docomo.ne.jp/images_osp/common/newhf/ico/ico_businessmembers.png)](https://www.docomo.ne.jp/charge/128k/about/)

お客さまの設定により、お客さま情報が「非表示」となっております。お客さま情報を表示するにはdアカウントでログインしてください。


[お客さま情報表示について](https://www.docomo.ne.jp/charge/128k/about/) へ


[お客さま情報表示について](https://www.docomo.ne.jp/charge/128k/about/) へ


- [ホーム](https://www.docomo.ne.jp/)
- [料金・割引](https://www.docomo.ne.jp/charge/)
- [新規申込み受付が終了の料金プラン・割引など : FOMAデータ通信プラン](https://www.docomo.ne.jp/charge/close.html#anc-06)
- [定額データプラン１２８Ｋ](https://www.docomo.ne.jp/charge/128k/?dynaviid=case0008.dynavi)
- 定額データプラン１２８Ｋとは

# 定額データプラン１２８Ｋとは

- [プラン概要](https://www.docomo.ne.jp/charge/128k/about/#p01)
- [定額データプラン対応プロバイダへの加入が必要](https://www.docomo.ne.jp/charge/128k/about/#p02)
- [ベーシックコース向け料金プラン](https://www.docomo.ne.jp/charge/128k/about/#p03)

## プラン概要

「定額データプラン１２８Ｋ」は、は完全定額でご利用いただける料金プランです。ブラウジングやアプリのダウンロードなど料金を気にせず使い放題。

プラン概要の表

| 通信速度 | 受信最大 | 128kbps※ [1](https://www.docomo.ne.jp/charge/128k/about/#notice01) |
| 送信速度 | 64kbps※ [1](https://www.docomo.ne.jp/charge/128k/about/#notice01) |
| 通信料金 | 定額 |

1. 通信速度は、送受信時の技術規格上の最大値であり、実際の通信速度を示すものではありません。ベストエフォート方式による提供となり、実際の通信速度は、通信環境やネットワークの混雑状況に応じて変化します。


## 定額データプラン対応プロバイダへの加入が必要

「定額データプラン１２８Ｋ」をご利用の際には別途mopera Uなどの対応プロバイダとのご契約が必要です。

定額データプラン１２８Ｋの専用プランmoperaU Uスーパーライトプランであれば月額使用料165円（税込）でご利用いただけます。

## ベーシックコース向け料金プラン

ベーシックコース

ベーシックコースにて対象機種をご購入いただいたお客様はベーシックプランをお選びいただけます。

### ベーシックコース対象機種

N2502および905iシリーズ以降に発売されるHIGH-SPEED対応機種で、かつドコモが指定する機種（A2502 HIGH-SPEEDおよびHIGH-SPEED対応PCは対象外）が対象となります。

![ベーシックコース対象機種のイメージ](https://www.docomo.ne.jp/charge/128k/about/images/img_128k_value.gif)

[ベーシックプラン](https://www.docomo.ne.jp/charge/basic/?dynaviid=case0008.dynavi)

## 定額データプラン１２８Ｋ詳細情報

- _定額データプラン１２８Ｋとは_
- [ご利用料金](https://www.docomo.ne.jp/charge/128k/plan/?dynaviid=case0008.dynavi)
- [お申込み方法](https://www.docomo.ne.jp/charge/128k/application/?dynaviid=case0008.dynavi)
- [ご注意事項](https://www.docomo.ne.jp/charge/128k/notice/?dynaviid=case0008.dynavi)

[定額データプラン１２８Ｋ](https://www.docomo.ne.jp/charge/128k/?dynaviid=case0008.dynavi) へ戻る

[![このページのトップへ](https://www.docomo.ne.jp/images_osp/common/btn/btn_pagetop_01.png)](https://www.docomo.ne.jp/charge/128k/about/#)

## [料金・割引](https://www.docomo.ne.jp/charge/)

- [新規申込み受付が終了の料金プラン・割引など : FOMAデータ通信プラン](https://www.docomo.ne.jp/charge/close.html#anc-06)
  - [定額制データ通信](https://www.docomo.ne.jp/charge/flat_rate/?dynaviid=case0008.dynavi)
  - [定額データプラン スタンダード](https://www.docomo.ne.jp/charge/standard/?dynaviid=case0008.dynavi)
  - [定額データプラン スタンダード バリュー](https://www.docomo.ne.jp/charge/standard_value/?dynaviid=case0008.dynavi)
  - [定額データプラン スタンダード２](https://www.docomo.ne.jp/charge/standard2/?dynaviid=case0008.dynavi)
  - [定額データプラン スタンダード２ バリュー](https://www.docomo.ne.jp/charge/standard2_value/?dynaviid=case0008.dynavi)
  - _定額データプラン１２８Ｋ_
  - [定額データプラン１２８Ｋ バリュー](https://www.docomo.ne.jp/charge/128k_value/?dynaviid=case0008.dynavi)
  - [定額データプラン フラット](https://www.docomo.ne.jp/charge/flat/?dynaviid=case0008.dynavi)
  - [定額データプラン フラット バリュー](https://www.docomo.ne.jp/charge/flat_value/?dynaviid=case0008.dynavi)
  - [定額データプランHIGH-SPEED](https://www.docomo.ne.jp/charge/high_speed/?dynaviid=case0008.dynavi)
  - [定額データ スタンダード割](https://www.docomo.ne.jp/charge/data_standard/?dynaviid=case0008.dynavi)
  - [定額データ スタンダード割２](https://www.docomo.ne.jp/charge/data_standard2/?dynaviid=case0008.dynavi)
  - [定額データ １２８Ｋ割](https://www.docomo.ne.jp/charge/data_128k/?dynaviid=case0008.dynavi)
  - [定額データ割](https://www.docomo.ne.jp/charge/discount_old/?dynaviid=case0008.dynavi)
  - [従量制データ通信](https://www.docomo.ne.jp/charge/measured_rate/?dynaviid=case0008.dynavi)
  - [従量データプラン](https://www.docomo.ne.jp/charge/for_dataonly/?dynaviid=case0008.dynavi)

- [ホーム](https://www.docomo.ne.jp/)
- [料金・割引](https://www.docomo.ne.jp/charge/)
- [新規申込み受付が終了の料金プラン・割引など : FOMAデータ通信プラン](https://www.docomo.ne.jp/charge/close.html#anc-06)
- [定額データプラン１２８Ｋ](https://www.docomo.ne.jp/charge/128k/?dynaviid=case0008.dynavi)
- 定額データプラン１２８Ｋとは

[![お困りですか？](https://www.docomo.ne.jp/images_osp/common/chat_tool/bnr_chat_tool.svg)](https://tetsuduki-support.docomo.ne.jp/?utm_source=corp&utm_medium=free-display&utm_campaign=onsapo_)

このページの情報は役に立ちましたか？

- はい
- いいえ

送信する

このページの情報は役に立ちましたか？

- はい
- いいえ

送信する

## ドコモサイトの改善のために、  あなたの回答の理由を教えてください（問）

※「アンケートに回答する」ボタンを押すと、

アンケート画面が開きます。

[アンケートに回答する](https://www.docomo.ne.jp/charge/128k/about/#survey)

## ご回答ありがとうございました

ご意見は今後のWebサイト改善の参考とさせていただきます。

- データは匿名化されており、個人が特定されることはございません。また調査以外の目的で利用されることはございません。


## NTTドコモサイトについてのアンケート

差し支えなければ、以下のアンケートにもご協力ください。

※この画面を閉じて元のページに戻るには画面右上の「閉じる」を押してください。

### Q.お探しの情報はどのような情報でしたか？あてはまるものをすべて選択してください。

### Q.あなたの年齢をお答えください。

- 10代以下
- 20代
- 30代
- 40代
- 50代
- 60代
- 70代以上
- 回答しない

10代以下20代30代選択してください40代50代60代70代以上回答しない

### Q.このページが「役に立たなかった」と思われた点について、あてはまるものをすべて選択してください。

- [ ] 知りたい情報が書かれていなかった
- [ ] 必要な情報がまとまっていなかった
- [ ] 知りたい内容までの適切な誘導がなかった
- [ ] GoogleやYahoo！で検索しても目的のページが出てこなかった
- [ ] このサイト内で検索しても目的のページが出てこなかった
- [ ] どのキーワードで検索すればいいかわからなかった
- [ ] 目的と違うページにたどり着いた
- [ ] 見たい情報がどこにありそうか想定できなかった
- [ ] 選択肢が紛らわしかった
- [ ] クリックなど操作がしづらかった
- [ ] 文章がわかりづらかった
- [ ] 絵や画像がわかりづらかった
- [ ] 表示されるのが遅かった
- [ ] その他
- [ ] あてはまるものはない

回答を送信する

## NTTドコモサイトについてのアンケート

### ご回答ありがとうございました。

※本アンケートに関する個人情報等の取扱いについては「 [NTTドコモ プライバシーポリシー](https://www.docomo.ne.jp/utility/privacy/?icid=CRP_SURVEY_end_to_CRP_UTI_privacy)」で定めています。

- [お知らせ](https://www.docomo.ne.jp/info/?icid=CRP_common_footer_to_CRP_INFO)
- [企業情報](https://www.docomo.ne.jp/corporate/?icid=CRP_common_footer_to_CRP_CORP)

* * *

- [パーソナルデータ（個人情報など）について](https://www.docomo.ne.jp/utility/personal_data/?icid=CRP_common_footer_to_CRP_UTI_personal_data)
- [プライバシーポリシー](https://www.docomo.ne.jp/utility/privacy/?icid=CRP_common_footer_to_CRP_UTI_privacy)
- [サイトご利用にあたって](https://www.docomo.ne.jp/utility/term/?icid=CRP_common_footer_to_CRP_UTI_term)
- [お客さまご利用端末からの情報の外部送信について](https://www.docomo.ne.jp/utility/term/?icid=CRP_common_footer_02_to_CRP_UTI_term#p09)
- [見やすさ・使いやすさの調整](https://www.docomo.ne.jp/utility/term/web_accessibility/faciliti/?icid=CRP_common_footer_to_CRP_UTI_term_web_accessibility_faciliti)
- [サイトメンテナンス情報 _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon-white.svg)_](https://www.docomo.ne.jp/mydocomo/maint/?icid=CRP_common_footer_to_CRP_MYD_maint)
- [サイトマップ](https://www.docomo.ne.jp/sitemap/?icid=CRP_common_footer_to_CRP_sitemap)
- [ご意見・ご要望](https://www.docomo.ne.jp/support/inquiry/feedback/?icid=CRP_common_footer_to_CRP_SUP_inquiry_feedback)
- [お問い合わせ](https://www.docomo.ne.jp/support/inquiry/?icid=CRP_common_footer_to_CRP_SUP_inquiry)
- [NTTドコモグループ _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon-white.svg)_](https://nttdocomo-group.com/index.html)

© NTT DOCOMO

![閉じる](https://www.docomo.ne.jp/images_osp/common/smtnav/btn_smtmenu_01_close_crp.png)