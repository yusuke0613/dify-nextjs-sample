---
url: "https://www.docomo.ne.jp/charge/?icid=CRP_menu_to_CRP_CHA"
title: "料金・割引 | NTTドコモ"
---

[![NTT docomo](https://www.docomo.ne.jp/images_osp/common/newhf/header/cmn-rwd-header-logo.svg?ver=1751324418)](https://www.docomo.ne.jp/?icid=CRP_common_header_to_CRP_TOP)

- [![別ウィンドウで開きます。my docomo](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-my-docomo-logo.svg)](https://www.docomo.ne.jp/mydocomo/?icid=CRP_outerhead_to_MYD_TOP)
- [![別ウィンドウで開きます。Online Shop](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-online-shop-icon2.svg)](https://onlineshop.docomo.ne.jp/top-ols/?xcid=OLS_TOP_from_CRP_outerhead)

- 商品・サービス












- モバイル
  - [iPhone](https://www.docomo.ne.jp/iphone/?icid=CRP_menu_to_CRP_IPH)

  - [iPad](https://www.docomo.ne.jp/ipad/?icid=CRP_menu_to_CRP_IPA)

  - [製品](https://www.docomo.ne.jp/product/?icid=CRP_menu_to_CRP_PRD)

  - [料金・割引](https://www.docomo.ne.jp/charge/?icid=CRP_menu_to_CRP_CHA)

  - [サービス・機能](https://www.docomo.ne.jp/service/?icid=CRP_menu_to_CRP_SER)

  - [通信・エリア](https://www.docomo.ne.jp/area/?icid=CRP_menu_to_CRP_AREA)
- インターネット回線・固定電話
  - [インターネット回線・固定電話トップ](https://www.docomo.ne.jp/internet/?icid=CRP_menu_to_CRP_INT)

  - [ドコモ光](https://www.docomo.ne.jp/internet/hikari/?icid=CRP_menu_to_CRP_INT_hikari)

  - [ahamo光](https://www.docomo.ne.jp/internet/ahamo_hikari/?icid=CRP_menu_to_CRP_internet_ahamo_hikari)

  - [home 5G](https://www.docomo.ne.jp/home_5g/?icid=CRP_menu_to_CRP_HOM)

  - [homeでんわ](https://www.docomo.ne.jp/home_denwa/?icid=CRP_menu_to_CRP_DENWA)
- スマートライフ
  - [スマートライフ トップ](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_menu_to_CRP_SER_smart-life)

  - [決済・保険・投資](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_menu_to_CRP_SER_smart-life_finance&tgl_entertainment=0&tgl_life-support=0&tgl_finance=1&tgl_shopping=0&tgl_healthcare=0#finance)

  - [エンターテインメント](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_menu_to_CRP_SER_smart-life_entertainment&tgl_entertainment=1&tgl_life-support=0&tgl_finance=0&tgl_shopping=0&tgl_healthcare=0#entertainment)

  - [ライフサポート](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_menu_to_CRP_SER_smart-life_life-support&tgl_entertainment=0&tgl_life-support=1&tgl_finance=0&tgl_shopping=0&tgl_healthcare=0#life-support)

  - [ショッピング](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_menu_to_CRP_SER_smart-life_shopping&tgl_entertainment=0&tgl_life-support=0&tgl_finance=0&tgl_shopping=1&tgl_healthcare=0#shopping)

  - [ヘルスケア](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_menu_to_CRP_SER_smart-life_healthcare&tgl_entertainment=0&tgl_life-support=0&tgl_finance=0&tgl_shopping=0&tgl_healthcare=1#healthcare)
- 電気・ガス
  - [ドコモでんき／\\
      \\
      ドコモ ガス トップ](https://www.docomo.ne.jp/denki/?icid=CRP_menu_to_CRP_DENKI)

- お知らせ














- [お知らせトップ](https://www.docomo.ne.jp/info/?icid=CRP_menu_to_CRP_INFO)

- [ニュースルーム](https://www.docomo.ne.jp/info/update/?icid=CRP_menu_to_CRP_INFO_update)

- [報道発表](https://www.docomo.ne.jp/info/news_release/?icid=CRP_menu_to_CRP_INFO_news_release)

- [重要なお知らせ（通信障害）](https://www.docomo.ne.jp/info/network/?icid=CRP_menu_to_CRP_INFO_network)

- [携帯電話サービスの通信状況（地域別）](https://www.docomo.ne.jp/info/status/?icid=CRP_menu_to_CRP_INFO_status)

- [工事のお知らせ](https://www.docomo.ne.jp/info/construction/?icid=CRP_menu_to_CRP_INFO_construction)


- 企業情報














- [企業情報トップ](https://www.docomo.ne.jp/corporate/?icid=CRP_menu_to_CRP_CORP)

- [あなたとドコモ](https://www.docomo.ne.jp/corporate/anatatodocomo/?icid=CRP_menu_to_CRP_CORP_anatatodocomo)

- [企業理念・ビジョン](https://www.docomo.ne.jp/corporate/philosophy_vision/?icid=CRP_menu_to_CRP_CORP_philosophy_vision)

- [会社案内](https://www.docomo.ne.jp/corporate/about/?icid=CRP_menu_to_CRP_CORP_about)

- [サステナビリティ](https://www.docomo.ne.jp/corporate/csr/?icid=CRP_menu_to_CRP_CORP_csr)

- [技術とあんしん](https://www.docomo.ne.jp/corporate/technology_safety/?icid=CRP_menu_to_CRP_CORP_technology_safety)

- [IR情報](https://www.docomo.ne.jp/corporate/ir/library/?icid=CRP_menu_to_CRP_CORP_ir_library)

- [採用情報](https://www.docomo.ne.jp/corporate/recruit/?icid=CRP_menu_to_CRP_CORP_recruit)

- [NTTドコモグループ _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://nttdocomo-group.com/index.html)


- 法人のお客さま














- [NTTドコモビジネス _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.ntt.com/index.html)

- [NTTドコモ\\
\\
ソリューションズ _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.nttcom.co.jp/)

- [NTTドコモ・グローバル](https://www.docomo.ne.jp/global/?icid=CRP_TOP_to_CRP_global)


- [![別ウィンドウで開きます。my docomo](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-my-docomo-logo.svg)](https://www.docomo.ne.jp/mydocomo/?icid=CRP_outerhead_to_MYD_TOP)



[![別ウィンドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-online-shop-icon.svg)\\
Online Shop](https://onlineshop.docomo.ne.jp/top-ols/?xcid=OLS_TOP_from_CRP_outerhead)



[![別ウィンドウで開きます。のりかえ（MNP）](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-online-mnp-icon_pc.png)](https://onlineshop.docomo.ne.jp/special-contents/mnp?xcid=OLS_special-contents_mnp_flow_from_CRP_TOP_mnp_btn)



[![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-switch-online-icon.svg)機種変更](https://www.docomo.ne.jp/support/switch_online/?icid=CRP_outerhead_to_SUP_switch_online)


[![](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-daccount-logo.svg)\\
ログインする](https://cfg.smt.docomo.ne.jp/auth/cgi/anidlogin?rl=https%3A%2F%2Fwww.docomo.ne.jp%2Fcharge%2F)

[![dポイントクラブ](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-d-point-club-logo.svg)\\
\\
P\\
\\
![ランク](https://www.docomo.ne.jp/charge/?icid=CRP_menu_to_CRP_CHA)](https://www.docomo.ne.jp/charge/?icid=CRP_menu_to_CRP_CHA) [![ドコモビジネスメンバーズ](https://www.docomo.ne.jp/images_osp/common/newhf/ico/ico_businessmembers.png)](https://www.docomo.ne.jp/charge/?icid=CRP_menu_to_CRP_CHA)

MENU

[![NTT docomo](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-header-logo.svg?ver=1751324418)](https://www.docomo.ne.jp/?icid=CRP_drawer_to_CRP_TOP)

[English](https://www.docomo.ne.jp/english/?icid=CRP_drawer_to_CRP_EN)

* * *

![検索する](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-header-search-icon.svg)

- [![](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-my-docomo-logo.svg)My docomo _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.docomo.ne.jp/mydocomo/?icid=CRP_drawer_to_MYD_TOP)
- [![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-online-shop-icon.svg)Online Shop _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://onlineshop.docomo.ne.jp/top-ols/?xcid=OLS_TOP_from_CRP_drawer)
- [![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-docomo-shop-icon.svg)ドコモショップ _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://shop.smt.docomo.ne.jp/?xcid=DS_TOP_from_CRP_drawer)
- [![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-customer-support-icon.svg)お客さまサポート](https://www.docomo.ne.jp/support/?icid=CRP_drawer_sup01_to_CRP_SUP)
- [![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-campaign-icon.svg)キャンペーン・特典](https://www.docomo.ne.jp/campaign_event/?icid=CRP_drawer_to_CRP_CAM)
- [![](https://www.docomo.ne.jp/assets/content/dam/corp/jp/ja/common/images/logo/cmn-rwd-d-point-club-logo.svg)dポイントクラブ _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://dpoint.docomo.ne.jp/)

- 商品・サービス
  - ![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/ico_mobile.png)モバイル



- [iPhone](https://www.docomo.ne.jp/iphone/?icid=CRP_drawer_to_CRP_IPH)
- [iPad](https://www.docomo.ne.jp/ipad/?icid=CRP_drawer_to_CRP_IPA)
- [製品](https://www.docomo.ne.jp/product/?icid=CRP_drawer_to_CRP_PRD)
- [料金・割引](https://www.docomo.ne.jp/charge/?icid=CRP_drawer_to_CRP_CHA)
- [サービス・機能](https://www.docomo.ne.jp/service/?icid=CRP_drawer_to_CRP_SER)
- [通信・エリア](https://www.docomo.ne.jp/area/?icid=CRP_drawer_to_CRP_AREA)

  - ![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/ico_internet.png)インターネット回線・固定電話



- [インターネット回線・固定電話トップ](https://www.docomo.ne.jp/internet/?icid=CRP_drawer_to_CRP_INT)
- [ドコモ光](https://www.docomo.ne.jp/internet/hikari/?icid=CRP_drawer_to_CRP_INT_hikari)
- [ahamo光](https://www.docomo.ne.jp/internet/ahamo_hikari/?icid=CRP_drawer_to_CRP_internet_ahamo_hikari)
- [home 5G](https://www.docomo.ne.jp/home_5g/?icid=CRP_drawer_to_CRP_HOM)
- [homeでんわ](https://www.docomo.ne.jp/home_denwa/?icid=CRP_drawer_to_CRP_DENWA)

  - ![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/ico_smartlife.png)スマートライフ



- [スマートライフ トップ](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_drawer_to_CRP_SER_smart-life)
- [決済・保険・投資](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_drawer_to_CRP_SER_smart-life_finance&tgl_entertainment=0&tgl_life-support=0&tgl_finance=1&tgl_shopping=0&tgl_healthcare=0#finance)
- [エンターテインメント](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_drawer_to_CRP_SER_smart-life_entertainment&tgl_entertainment=1&tgl_life-support=0&tgl_finance=0&tgl_shopping=0&tgl_healthcare=0#entertainment)
- [ライフサポート](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_drawer_to_CRP_SER_smart-life_life-support&tgl_entertainment=0&tgl_life-support=1&tgl_finance=0&tgl_shopping=0&tgl_healthcare=0#life-support)
- [ショッピング](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_drawer_to_CRP_SER_smart-life_shopping&tgl_entertainment=0&tgl_life-support=0&tgl_finance=0&tgl_shopping=1&tgl_healthcare=0#shopping)
- [ヘルスケア](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_drawer_to_CRP_SER_smart-life_healthcare&tgl_entertainment=0&tgl_life-support=0&tgl_finance=0&tgl_shopping=0&tgl_healthcare=1#healthcare)

  - ![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/ico_denki.png?ver=1748827032)電気・ガス



- [ドコモでんき／\\
\\
ドコモ ガス トップ](https://www.docomo.ne.jp/denki/?icid=CRP_drawer_to_CRP_DENKI)
- お知らせ
  - お知らせ

- [お知らせ トップ](https://www.docomo.ne.jp/info/?icid=CRP_drawer_to_CRP_INFO)
- [ニュースルーム](https://www.docomo.ne.jp/info/update/?icid=CRP_drawer_to_CRP_INFO_update)
- [報道発表](https://www.docomo.ne.jp/info/news_release/?icid=CRP_drawer_to_CRP_INFO_news_release)
- [重要なお知らせ（通信障害）](https://www.docomo.ne.jp/info/network/?icid=CRP_drawer_to_CRP_INFO_network)
- [携帯電話サービスの通信状況（地域別）](https://www.docomo.ne.jp/info/status/?icid=CRP_drawer_to_CRP_INFO_status)
- [工事のお知らせ](https://www.docomo.ne.jp/info/construction/?icid=CRP_drawer_to_CRP_INFO_construction)
- 企業情報
  - 企業情報

- [企業情報 トップ](https://www.docomo.ne.jp/corporate/?icid=CRP_drawer_to_CRP_CORP)
- [あなたとドコモ](https://www.docomo.ne.jp/corporate/anatatodocomo/?icid=CRP_drawer_to_CRP_CORP_anatatodocomo)
- [企業理念・ビジョン](https://www.docomo.ne.jp/corporate/philosophy_vision/?icid=CRP_drawer_to_CRP_CORP_philosophy_vision)
- [会社案内](https://www.docomo.ne.jp/corporate/about/?icid=CRP_drawer_to_CRP_CORP_about)
- [サステナビリティ](https://www.docomo.ne.jp/corporate/csr/?icid=CRP_drawer_to_CRP_CORP_csr)
- [技術とあんしん](https://www.docomo.ne.jp/corporate/technology_safety/?icid=CRP_drawer_to_CRP_CORP_technology_safety)
- [IR情報](https://www.docomo.ne.jp/corporate/ir/library/?icid=CRP_drawer_to_CRP_CORP_ir_library)
- [採用情報](https://www.docomo.ne.jp/corporate/recruit/?icid=CRP_drawer_to_CRP_CORP_recruit)
- [NTTドコモグループ _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://nttdocomo-group.com/index.html)
- 地域別情報

- [北海道](https://www.docomo.ne.jp/hokkaido/?icid=CRP_drawer_to_hokkaido)
- [東北](https://www.docomo.ne.jp/tohoku/?icid=CRP_drawer_to_tohoku)
- [関東・甲信越](https://www.docomo.ne.jp/kanto/?icid=CRP_drawer_to_kanto)
- [東海](https://www.docomo.ne.jp/tokai/?icid=CRP_drawer_to_tokai)
- [北陸](https://www.docomo.ne.jp/hokuriku/?icid=CRP_drawer_to_hokuriku)
- [関西](https://www.docomo.ne.jp/kansai/?icid=CRP_drawer_to_kansai)
- [中国](https://www.docomo.ne.jp/chugoku/?icid=CRP_drawer_to_chugoku)
- [四国](https://www.docomo.ne.jp/shikoku/?icid=CRP_drawer_to_shikoku)
- [九州・沖縄](https://www.docomo.ne.jp/kyushu/?icid=CRP_drawer_to_kyushu)

- 地域別情報



- [北海道](https://www.docomo.ne.jp/hokkaido/?icid=CRP_drawer_to_hokkaido) \|
- [東北](https://www.docomo.ne.jp/tohoku/?icid=CRP_drawer_to_tohoku) \|
- [関東・甲信越](https://www.docomo.ne.jp/kanto/?icid=CRP_drawer_to_kanto) \|
- [東海](https://www.docomo.ne.jp/tokai/?icid=CRP_drawer_to_tokai) \|
- [北陸](https://www.docomo.ne.jp/hokuriku/?icid=CRP_drawer_to_hokuriku) \|
- [関西](https://www.docomo.ne.jp/kansai/?icid=CRP_drawer_to_kansai) \|
- [中国](https://www.docomo.ne.jp/chugoku/?icid=CRP_drawer_to_chugoku) \|
- [四国](https://www.docomo.ne.jp/shikoku/?icid=CRP_drawer_to_shikoku) \|
- [九州・沖縄](https://www.docomo.ne.jp/kyushu/?icid=CRP_drawer_to_kyushu)
- 法人のお客さま

- [NTTドコモビジネス _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.ntt.com/index.html)
- [NTTドコモソリューションズ _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.nttcom.co.jp/)
- [NTTドコモ・グローバル](https://www.docomo.ne.jp/global/?icid=CRP_drawer_to_CRP_global)

- 法人のお客さま



- [NTTドコモビジネス _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.ntt.com/index.html) \|
- [NTTドコモソリューションズ _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.nttcom.co.jp/) \|
- [NTTドコモ・グローバル](https://www.docomo.ne.jp/global/?icid=CRP_drawer_to_CRP_global)

ログインすると

ポイント・ランク情報が確認できます

[![](https://www.docomo.ne.jp/assets/content/dam/corp/jp/ja/common/images/logo/cmn-rwd-d-point-club-logo.svg)dアカウントにログインする](https://cfg.smt.docomo.ne.jp/auth/cgi/anidlogin?rl=https%3A%2F%2Fwww.docomo.ne.jp)

- [dアカウントでもっと便利に](https://www.docomo.ne.jp/utility/daccount/?icid=CRP_drawer_to_CRP_UTI_daccount)
- [別のIDでログイン](https://cfg.smt.docomo.ne.jp/auth/cgi/anidlogin?rl=https%3A%2F%2Fwww.docomo.ne.jp%2F)
- [ログアウト](https://www.docomo.ne.jp/mydocomo/utility/confirm_logout/index.html)
- [会員情報確認・変更 _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon-white.svg)_](https://profile.smt.docomo.ne.jp/VIEW_ESITE/mem/sc/main.jsp?nid=MEG002006BJP)
- [ログインでお困りの方 _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon-white.svg)_](https://id.smt.docomo.ne.jp/src/utility/idpw_forget.html)
- [２段階認証のお願い _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon-white.svg)_](https://id.smt.docomo.ne.jp/src/utility/sp/twostepauth.html)

オートログイン中

[![ランク](https://www.docomo.ne.jp/charge/?icid=CRP_menu_to_CRP_CHA#)](https://dpoint.docomo.ne.jp/member/stage_info/index.html)

* * *

[うち期間・用途限定](https://www.docomo.ne.jp/charge/?icid=CRP_menu_to_CRP_CHA)

* * *

[![ドコモビジネスメンバーズ](https://www.docomo.ne.jp/images_osp/common/newhf/ico/ico_businessmembers.png)](https://www.docomo.ne.jp/charge/?icid=CRP_menu_to_CRP_CHA)

- [別のIDでログイン](https://cfg.smt.docomo.ne.jp/auth/cgi/anidlogin?rl=https%3A%2F%2Fwww.docomo.ne.jp%2F)
- [ログアウト](https://www.docomo.ne.jp/mydocomo/utility/confirm_logout/index.html)
- [会員情報確認・変更 _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon-white.svg)_](https://profile.smt.docomo.ne.jp/VIEW_ESITE/mem/sc/main.jsp?nid=MEG002006BJP)
- [２段階認証のお願い _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon-white.svg)_](https://id.smt.docomo.ne.jp/src/utility/sp/twostepauth.html)

- [CMギャラリー _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.youtube.com/playlist?list=PLB334710B4B8111A8)
- [よくあるご質問](https://faq.front.smt.docomo.ne.jp/?utm_source=docomo.ne.jp&utm_medium=api_linkage&utm_campaign=api_CRP_TOP)
- [見やすさ・使いやすさの調整](https://www.docomo.ne.jp/utility/term/web_accessibility/faciliti/?icid=CRP_drawer_to_CRP_UTI_term_web_accessibility_faciliti)
- [パーソナルデータ（個人情報など）について](https://www.docomo.ne.jp/utility/personal_data/?icid=CRP_drawer_to_CRP_UTI_personal_data)

- [![](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-daccount-logo.svg)\\
ログインする](https://cfg.smt.docomo.ne.jp/auth/cgi/anidlogin?rl=https%3A%2F%2Fwww.docomo.ne.jp%2Fcharge%2F)
- [![別ウィンドウで開きます。のりかえ（MNP）](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-online-mnp-icon_smt.png)](https://onlineshop.docomo.ne.jp/special-contents/mnp?xcid=OLS_special-contents_mnp_flow_from_CRP_TOP_mnp_btn)

- [![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-switch-online-icon.svg)機種変更](https://www.docomo.ne.jp/support/switch_online/?icid=CRP_outerhead_to_SUP_switch_online)
- [![](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-d-point-club-logo.svg)\\
\\
P\\
\\
![](https://www.docomo.ne.jp/charge/?icid=CRP_menu_to_CRP_CHA)](https://www.docomo.ne.jp/charge/?icid=CRP_menu_to_CRP_CHA)

[![ドコモビジネスメンバーズ](https://www.docomo.ne.jp/images_osp/common/newhf/ico/ico_businessmembers.png)](https://www.docomo.ne.jp/charge/?icid=CRP_menu_to_CRP_CHA)

お客さまの設定により、お客さま情報が「非表示」となっております。お客さま情報を表示するにはdアカウントでログインしてください。


[お客さま情報表示について](https://www.docomo.ne.jp/charge/?icid=CRP_menu_to_CRP_CHA) へ


[お客さま情報表示について](https://www.docomo.ne.jp/charge/?icid=CRP_menu_to_CRP_CHA) へ


- [ホーム](https://www.docomo.ne.jp/)
- 料金・割引

# 料金・割引

![タブの自動切り替えを停止](https://www.docomo.ne.jp/assets/content/dam/corp/jp/ja/common/image/main_pr/pause.svg)![タブの自動切り替えを再開](https://www.docomo.ne.jp/assets/content/dam/corp/jp/ja/common/image/main_pr/play.svg)

- 11
- 22
- 33
- 44
- 55

![前へ](https://www.docomo.ne.jp/images_osp/common/btn/btn_carousel_prev01.png)

[![ahamoポイ活 好評受付中！ キャンペーン実施中！ 合計最大＋10%還元 詳しくはahamoポイ活ページへ](https://www.docomo.ne.jp/flcache_data/charge/index/mainpr/img_mainpr_ahamo_poikatsu.jpg?ver=1732978825)![別ウインドウが開きます](https://www.docomo.ne.jp/assets/content/dam/corp/jp/ja/home/images/campaign_event/common/cmn-rwd-new-window-icon.svg)](https://ahamo.com/special/poikatsu/)

[![これは、知識も技術もいらない生成AI。Stella AIセット割 対象料金プランなら Stella AI スタンダードプラン（1,628円）の場合 毎月1,628円 税込 が合計1年間割引 適用条件など詳しくはこちら](https://www.docomo.ne.jp/flcache_data/charge/index/mainpr/img_mainpr_stella-ai.jpg?ver=1749049243)![別ウインドウが開きます](https://www.docomo.ne.jp/assets/content/dam/corp/jp/ja/home/images/campaign_event/common/cmn-rwd-new-window-icon.svg)](https://lp.stella-ai.net/campaign/00001/?q=0000000000006)

[![6／5（木曜）登場！ 新料金プラン ドコモ Max／ドコモ ポイ活 Max うれしい特典が充実！ 詳しくはこちら](https://www.docomo.ne.jp/flcache_data/charge/index/mainpr/img_mainpr_new_plan.png?ver=1745467217)](https://www.docomo.ne.jp/charge/promotion/new_plan/?icid=CRP_CHA_top_to_CRP_CHA_promotion_new_plan)

[![29歳以下ならドコモMAXがおトクに！ ドコモ U29割](https://www.docomo.ne.jp/flcache_data/charge/index/mainpr/img_mainpr_u29wari.png?ver=1756652413)](https://www.docomo.ne.jp/campaign_event/promotion/docomo_u29_wari/?icid=CRP_CHA_top_to_CRP_CAM_promotion_docomo_u29_wari)

[![今のスマホのままドコモが使える！ドコモ MAX・ドコモ ポイ活 MAX・ドコモ miniならのりかえ（MNP）で最大20,000ポイント dポイント（期間・用途限定）SIMのみ契約でもらえる！ドコモ ポイ活 20なら最大10,000ポイント進呈　適用条件はこちら](https://www.docomo.ne.jp/flcache_data/charge/index/mainpr/img_mainpr_sim_campaign.png?ver=1760454014)![別ウインドウが開きます](https://www.docomo.ne.jp/assets/content/dam/corp/jp/ja/home/images/campaign_event/common/cmn-rwd-new-window-icon.svg)](https://onlineshop.docomo.ne.jp/special/sim-campaign?utm_source=owned&utm_medium=crp_charge&utm_campaign=ols_202507_sim_campaign&utm_content=202507_crp_charge&xcid=OLS_SP_sim-campaign_202507_from_CRP_CHA)

[![ahamoポイ活 好評受付中！ キャンペーン実施中！ 合計最大＋10%還元 詳しくはahamoポイ活ページへ](https://www.docomo.ne.jp/flcache_data/charge/index/mainpr/img_mainpr_ahamo_poikatsu.jpg?ver=1732978825)![別ウインドウが開きます](https://www.docomo.ne.jp/assets/content/dam/corp/jp/ja/home/images/campaign_event/common/cmn-rwd-new-window-icon.svg)](https://ahamo.com/special/poikatsu/)

[![これは、知識も技術もいらない生成AI。Stella AIセット割 対象料金プランなら Stella AI スタンダードプラン（1,628円）の場合 毎月1,628円 税込 が合計1年間割引 適用条件など詳しくはこちら](https://www.docomo.ne.jp/flcache_data/charge/index/mainpr/img_mainpr_stella-ai.jpg?ver=1749049243)![別ウインドウが開きます](https://www.docomo.ne.jp/assets/content/dam/corp/jp/ja/home/images/campaign_event/common/cmn-rwd-new-window-icon.svg)](https://lp.stella-ai.net/campaign/00001/?q=0000000000006)

[![6／5（木曜）登場！ 新料金プラン ドコモ Max／ドコモ ポイ活 Max うれしい特典が充実！ 詳しくはこちら](https://www.docomo.ne.jp/flcache_data/charge/index/mainpr/img_mainpr_new_plan.png?ver=1745467217)](https://www.docomo.ne.jp/charge/promotion/new_plan/?icid=CRP_CHA_top_to_CRP_CHA_promotion_new_plan)

[![29歳以下ならドコモMAXがおトクに！ ドコモ U29割](https://www.docomo.ne.jp/flcache_data/charge/index/mainpr/img_mainpr_u29wari.png?ver=1756652413)](https://www.docomo.ne.jp/campaign_event/promotion/docomo_u29_wari/?icid=CRP_CHA_top_to_CRP_CAM_promotion_docomo_u29_wari)

[![今のスマホのままドコモが使える！ドコモ MAX・ドコモ ポイ活 MAX・ドコモ miniならのりかえ（MNP）で最大20,000ポイント dポイント（期間・用途限定）SIMのみ契約でもらえる！ドコモ ポイ活 20なら最大10,000ポイント進呈　適用条件はこちら](https://www.docomo.ne.jp/flcache_data/charge/index/mainpr/img_mainpr_sim_campaign.png?ver=1760454014)![別ウインドウが開きます](https://www.docomo.ne.jp/assets/content/dam/corp/jp/ja/home/images/campaign_event/common/cmn-rwd-new-window-icon.svg)](https://onlineshop.docomo.ne.jp/special/sim-campaign?utm_source=owned&utm_medium=crp_charge&utm_campaign=ols_202507_sim_campaign&utm_content=202507_crp_charge&xcid=OLS_SP_sim-campaign_202507_from_CRP_CHA)

[![ahamoポイ活 好評受付中！ キャンペーン実施中！ 合計最大＋10%還元 詳しくはahamoポイ活ページへ](https://www.docomo.ne.jp/flcache_data/charge/index/mainpr/img_mainpr_ahamo_poikatsu.jpg?ver=1732978825)![別ウインドウが開きます](https://www.docomo.ne.jp/assets/content/dam/corp/jp/ja/home/images/campaign_event/common/cmn-rwd-new-window-icon.svg)](https://ahamo.com/special/poikatsu/)

[![これは、知識も技術もいらない生成AI。Stella AIセット割 対象料金プランなら Stella AI スタンダードプラン（1,628円）の場合 毎月1,628円 税込 が合計1年間割引 適用条件など詳しくはこちら](https://www.docomo.ne.jp/flcache_data/charge/index/mainpr/img_mainpr_stella-ai.jpg?ver=1749049243)![別ウインドウが開きます](https://www.docomo.ne.jp/assets/content/dam/corp/jp/ja/home/images/campaign_event/common/cmn-rwd-new-window-icon.svg)](https://lp.stella-ai.net/campaign/00001/?q=0000000000006)

![次へ](https://www.docomo.ne.jp/images_osp/common/btn/btn_carousel_next01.png)

- [![](https://www.docomo.ne.jp/flcache_data/charge/index/ico_price.svg?ver=1722438014)料金プラン](https://www.docomo.ne.jp/charge/?icid=CRP_menu_to_CRP_CHA#sec_plan)
- [![](https://www.docomo.ne.jp/flcache_data/charge/index/ico_option.svg?ver=1722438014)オプション](https://www.docomo.ne.jp/charge/?icid=CRP_menu_to_CRP_CHA#sec_option)
- [![](https://www.docomo.ne.jp/flcache_data/charge/index/ico_campaign.svg?ver=1722438014)割引・特典](https://www.docomo.ne.jp/charge/?icid=CRP_menu_to_CRP_CHA#sec_discount)
- [![](https://www.docomo.ne.jp/flcache_data/charge/index/ico_simulation.svg?ver=1722438014)料金シミュレーション](https://www.docomo.ne.jp/charge/?icid=CRP_menu_to_CRP_CHA#sec_simulation)

[![My docomo ドコモユーザー向け 契約内容・料金確認](https://www.docomo.ne.jp/flcache_data/charge/index/bnr_mydocomo01_pc.png?ver=1722438014)![My docomo ドコモユーザー向け 契約内容・料金確認](https://www.docomo.ne.jp/flcache_data/charge/index/bnr_mydocomo01_smt.png?ver=1722438014)](https://www.docomo.ne.jp/mydocomo/?icid=CRP_CHA_top_to_CRP_MYD)

## 料金プラン

**＼あなたのニーズに合った料金プランを選択／**

**あなたのニーズに合った**

**＼　料金プランを選択　／**

[![](https://www.docomo.ne.jp/flcache_data/charge/index/btn_anchor_docomo_max.png?ver=1749049241)](https://www.docomo.ne.jp/charge/?icid=CRP_menu_to_CRP_CHA#sec-docomo-max)

[![](https://www.docomo.ne.jp/flcache_data/charge/index/btn_anchor_docomo_poikatsu_max.png?ver=1749049241)](https://www.docomo.ne.jp/charge/?icid=CRP_menu_to_CRP_CHA#sec-docomo-poikatsu-max)

[![](https://www.docomo.ne.jp/flcache_data/charge/index/btn_anchor_docomo_poikatsu_20.png?ver=1749049241)](https://www.docomo.ne.jp/charge/?icid=CRP_menu_to_CRP_CHA#sec-docomo-poikatsu-20)

[![](https://www.docomo.ne.jp/flcache_data/charge/index/btn_anchor_docomo_mini.png?ver=1749049241)](https://www.docomo.ne.jp/charge/?icid=CRP_menu_to_CRP_CHA#sec-docomo-mini)

[![](https://www.docomo.ne.jp/flcache_data/charge/index/btn_anchor_ahamo.png?ver=1749049241)](https://www.docomo.ne.jp/charge/?icid=CRP_menu_to_CRP_CHA#sec-ahamo)

※ ahamoはオンラインでのお手続きとなります。

[料金プランを比較\\
\\
したい人はこちら __](https://www.docomo.ne.jp/charge/promotion/eraberu/?icid=CRP_CHA_text_to_CRP_CHA_promotion_eraberu)

![ドコモ MAX](https://www.docomo.ne.jp/flcache_data/charge/index/logo_docomo_max.png?ver=1749049243)

### うれしい特典が充実！   ドコモのあらゆるバリューを通信と組み合わせたプラン

多様なライフスタイルにお応えし、ドコモならではのバリューを詰め込んだ料金プラン

![ドコモ MAX 3GB～無制限での料金イメージ 基本料金7,680円／月（税込8,448円／月） 割引適用分 実質4,680円／月（税込5,148円／月）](https://www.docomo.ne.jp/flcache_data/charge/index/img_graph_docomo_max_pc.png?ver=1757466019)![](https://www.docomo.ne.jp/flcache_data/charge/index/img_price_docomo_max_pc.png?ver=1760918415)

![ドコモ MAX 3GB～無制限での料金イメージ 基本料金7,680円／月（税込8,448円／月） 割引適用分 実質4,680円／月（税込5,148円／月）](https://www.docomo.ne.jp/flcache_data/charge/index/img_graph_docomo_max_smt.png?ver=1757466019)![](https://www.docomo.ne.jp/flcache_data/charge/index/img_price_docomo_max_smt_01.png?ver=1760918415)![割引適用内訳](https://www.docomo.ne.jp/flcache_data/charge/index/img_price_common_ttl.png?ver=1749049242)

![](https://www.docomo.ne.jp/flcache_data/charge/index/img_price_docomo_max_smt_02.png?ver=1760918415)

![スクロール](https://www.docomo.ne.jp/images_osp/common/img/img_guide_scroll01@2x.png)![](https://www.docomo.ne.jp/flcache_data/charge/index/img_price_docomo_max_smt_03.png?ver=1758869472)

手続き窓口

- オンライン：〇

- 電話：◯

- 店頭：〇


1. 大量通信時などに通信制限がかかる場合があります。「5Gデータプラス」「データプラス」「データプラス（2019年9月30日以前お申込み）」をご契約の場合、ペア回線の利用可能データ量は30GBとなり、上限超過後は通信速度が送受信最大1Mbpsとなります。詳細は「 [5Gデータプラス](https://www.docomo.ne.jp/charge/5g-dataplus/?icid=CRP_CHA_top_to_CRP_CHA_5g-dataplus)」をご確認ください。

2. 同一「ファミリー割引」グループ内における音声通話が可能な料金プラン（「2in1」、「キッズケータイプラス」、「キッズケータイプラン」「irumo（0.5GB）」を除く）契約回線がカウント対象となります。

3. 月末時点の支払い方法をdカード、dカード GOLD U、dカード GOLD、dカード PLATINUMによる定期クレジット設定にしていることが割引条件となります。


- 家族カードも対象

- 一括請求代表回線のお支払い方法が定期クレジット設定（本料金プランをdカード／dカード GOLD U／dカード GOLD／dカード PLATINUMで毎月支払う設定）の場合、一括請求代表回線の料金プランにかかわらず、対象料金プランを契約している一括請求子回線は割引が適用されます。


「dカードお支払割」は回線契約が個人名義のお客さまのみが対象です。回線契約が法人名義のお客さま向けには、「ビジネスメンバーズ割」（1回線当たり275円（税込）／月を月額利用料から割引）、「社員割」（6回線以上ご契約の法人名義に1回線当たり275円（税込）／月を月額利用料から割引）をご用意しております。

- 月末時点の支払い方法をdカードで定期クレジット設定している場合は220円（税込）（ただし、キャンペーン期間中は550円（税込））、dカード GOLD U、dカード GOLD、dカード PLATINUMで定期クレジット設定している場合は550円（税込）割り引きします。


4. 「dカード」を定期支払いに設定いただいたお客さまを対象に、カード券種に関係なく550円（税込）／月を割り引くキャンペーンを実施いたします。（2025年10月31日をもちまして、本キャンペーンは終了しました）

5. 「ドコモ光」または「home 5G プラン」契約者と同一「ファミリー割引」グループ内の「ドコモ MAX」「ドコモ ポイ活 MAX」「ドコモ ポイ活 20」「ドコモ mini」の契約者が対象です。同一「ファミリー割引」グループ内に「ドコモ光」「home 5G プラン」の両方が存在する場合は、「ドコモ光セット割」が適用されます。月額料金が日割り計算となる場合は、割引額も日割り計算となります。また、適用には「ドコモ光」もしくは「home 5G プラン」のご契約が必要となり別途費用がかかります（「ドコモ光」の場合、プロバイダ込・1ギガ・解約金（戸建：5,500円（税込）／マンション：4,180円（税込））有で月4,400円（税込）～5,940円（税込）。「home 5G プラン」の場合、月5,280円（税込）と別途HR01／HR02のご購入が必要）。

6. 同一「ファミリー割引」グループ内に、「ドコモでんき」のペア回線（「ドコモでんき」と対になる携帯電話回線）が含まれている場合、同一「ファミリー割引」グループ内の対象料金プランを契約する各回線に対してそれぞれ割引が適用となります。


本契約回線が「ドコモでんき」のペア回線に指定されている場合でも、同一「ファミリー割引」グループ内の「ドコモ ポイ活 MAX」「ドコモ ポイ活 20」「ドコモ MAX」「ドコモ mini」については「ドコモでんきセット割」の対象となります。割引対象回線の月額料金が日割りとなる場合、「ドコモでんきセット割」の割引額も日割りとなります。また、適用には「ドコモでんき」のご契約が必要となり、「ドコモでんき」は別途料金がかかります。各エリアごとの料金については [ドコモでんきサイト _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://denki.docomo.ne.jp/plan/price/) の料金単価表をご確認ください。

7. dカードは年会費無料、dカード GOLD Uは年会費3,300円（税込）、dカード GOLDは年会費11,000円（税込）、dカード PLATINUMは年会費29,700円（税込）がかかります。各種dカードはそれぞれ所定の審査があります。


- 別途機種代金・通話料（国内通話の場合30秒ごとに22円（税込））などがかかります。


![](https://www.docomo.ne.jp/flcache_data/charge/index/img_bonus_pc_01.png?ver=1761614532)![](https://www.docomo.ne.jp/flcache_data/charge/index/img_bonus_smt_01.png?ver=1761614532)[![Leminoプレミアム入会で最大6か月間おトクに使えるキャンペーン ※入会月の月末までにエントリー要。毎月1回以上の視聴など各種条件あり。初回無料期間など各種特典適用がある期間はポイント進呈の対象外となる場合あり。詳しくはこちら](https://www.docomo.ne.jp/flcache_data/charge/index/bnr_lemino_pc.png?ver=1749049241)![Leminoプレミアム入会で最大6か月間おトクに使えるキャンペーン ※入会月の月末までにエントリー要。毎月1回以上の視聴など各種条件あり。初回無料期間など各種特典適用がある期間はポイント進呈の対象外となる場合あり。詳しくはこちら](https://www.docomo.ne.jp/flcache_data/charge/index/bnr_lemino_smt.png?ver=1749049241)](https://lemino.docomo.ne.jp/cp/0000123/?utm_source=corp_charge&utm_medium=free-display&utm_campaign=lemino_202506_dcmcorp-ryoukin-nyukai900ptcp-0605)

**＼Amazonプライムについて／**

[ご登録はこちら _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://ssw.web.docomo.ne.jp/prime/campaign/max_202506/?utm_source=corp_other&utm_medium=free-display&utm_campaign=ap_202506_ap_0000748)

[![ドコモから入会がお得ディズニープラスの月額料金から毎月1,140円が最大6か月間割引要エントリー](https://www.docomo.ne.jp/flcache_data/charge/index/bnr_disneyplus_01_pc.png?ver=1756083612)![ドコモから入会がお得ディズニープラスの月額料金から毎月1,140円が最大6か月間割引要エントリー](https://www.docomo.ne.jp/flcache_data/charge/index/bnr_disneyplus_01_smt.png?ver=1756083612)_![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://service.smt.docomo.ne.jp/site/special/src/disneyplus_campaign_index.html?ex_cmp=dp_ddcm_corp_2ndTOP_max&utm_source=corp_2ndTOP_max&utm_medium=display&utm_campaign=dp_202006_set)

[![「ギガライト」「irumo」契約者限定！「ドコモ MAX」「ドコモ ポイ活 MAX」にWebにてお申込みで3,000ポイントプレゼントキャンペーン](https://www.docomo.ne.jp/flcache_data/charge/index/bnr-gigalite-irumo_pc.png?ver=1761096850)![「ギガライト」「irumo」契約者限定！「ドコモ MAX」「ドコモ ポイ活 MAX」にWebにてお申込みで3,000ポイントプレゼントキャンペーン](https://www.docomo.ne.jp/flcache_data/charge/index/bnr-gigalite-irumo_smt.png?ver=1761096850)_![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://ssw.web.docomo.ne.jp/nssw/dcmgiga/cp/maxweb3000ptcp/?utm_source=corp_campaign&utm_medium=free-display&utm_campaign=dcmgiga_202510_cam_0003766)

1. 「NBA docomo」の配信対象試合について詳しくは [こちら _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://nba.docomo.ne.jp/lp/entry001/?utm_source=corp_other&utm_medium=free-display&utm_campaign=nbaservicelp_202510_nbadocomo_newplan_charge1) をご確認ください。

2. 2026年1月まで（予定）に「ドコモ MAX」「ドコモ ポイ活 MAX」を翌月適用でお申込みいただいた場合、お申込み当月から「NBA docomo」「DAZN for docomo」が追加料金なしでご利用になれます。ただし、対象料金プランの翌月適用がキャンセルされた場合、当月の「NBA docomo」 「DAZN for docomo」の月額利用料を請求いたします。ドコモ回線以外のお客さまが追加料金なしで「NBA docomo」もしくは「DAZN for docomo」をご利用いただくためには各サービスのお申込み時点において、「ドコモ MAX」「ドコモ ポイ活 MAX」をご契約いただいている必要があります。対象料金プランお申込み前に各サービスをご契約された場合、対象料金プランお申込みの翌月以降でないと、各サービスを追加料金なしでご利用いただけませんのでご注意ください。

3. ドコモ以外でご契約中のDAZNを退会される際、退会手続き後に一定期間課金が発生する場合があります。詳しくは [こちら _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://www.dazn.com/ja-JP/help/articles/16194539395613-DAZN%E3%81%AE%E9%80%80%E4%BC%9A%E6%96%B9%E6%B3%95) をご確認ください。

4. ドコモからの「Amazonプライム」登録で、回線利用料と「Amazonプライム」月額会費の合計額から、「Amazonプライム」月額会費相当の600円を最大6か月間割り引きます。当社提供の他Amazonプライム割引特典と重畳はできません。本特典が優先となります。

5. 「Amazonプライム」の月額会費は600円（税込）です（2025年6月時点）。「Amazonプライム」は6か月間の割引終了後、ご登録期間中はdポイント（期間・用途限定）を毎月120ポイント還元いたします。

6. 海外データ通信について詳しくは [こちら](https://www.docomo.ne.jp/service/world/roaming/max/?icid=CRP_CHA_top_to_CRP_SER_world_roaming_max) をご確認ください。

7. 一部対象外の地域があります。詳しくは [こちら](https://www.docomo.ne.jp/service/world/roaming/charge/web.html?icid=CRP_CHA_top_to_CRP_SER_world_roaming_charge_web#anc-01) をご確認ください。

8. 長期利用割は「ドコモ MAX」「ドコモ ポイ活 MAX」のお客さまが対象です。ドコモのご利用継続期間が20年以上のお客さまは220円／月、10年以上のお客さまは110円／月を月額料金から割り引きます。


[料金プランを詳しくみる __](https://www.docomo.ne.jp/charge/docomo_max/?icid=CRP_CHA_to_CRP_CHA_docomo_max)

![ドコモ ポイ活 MAX](https://www.docomo.ne.jp/flcache_data/charge/index/logo_docomo_poikatsu_max.png?ver=1749049243)

### うれしい特典が充実！   ドコモ MAXのバリューはそのままに   d払い※1&dカード※2でのお買い物が還元率UP！

ドコモ MAX同様のバリューを詰め込み

ポイントがもっとたまって、つかえておトクがつづく料金プラン

1. d払いはお支払い方法をdカード／電話料金合算払い（電話料金の支払い方法にdカード以外のクレジットカードを設定している場合を除く）／d払い残高に設定されたお支払いが対象です。


※ただし、dポイント利用分などは対象外。

2. dカードは年会費無料、dカード GOLD Uは年会費3,300円（税込）、dカード GOLDは年会費11,000円（税込）、dカード PLATINUMは年会費29,700円（税込）がかかります。各種dカードはそれぞれ所定の審査があります。


![ドコモ ポイ活 MAXでの料金イメージ 基本料金10,680円／月（税込11,748円／月） 割引適用分 ポイント充当分 実質2,680円／月（税込2,948円／月）](https://www.docomo.ne.jp/flcache_data/charge/index/img_graph_docomo_poikatsu_max_pc.png?ver=1758869472)![ドコモ ポイ活 MAXでの料金イメージ 基本料金10,680円／月（税込11,748円／月） 割引適用分 ポイント充当分 実質2,680円／月（税込2,948円／月）](https://www.docomo.ne.jp/flcache_data/charge/index/img_graph_docomo_poikatsu_max_smt.png?ver=1758869472)

[ポイント特典についてはこちら __](https://www.docomo.ne.jp/charge/?icid=CRP_menu_to_CRP_CHA#anc-02-01-poikatsu-max)

![](https://www.docomo.ne.jp/flcache_data/charge/index/img_price_docomo_poikatsu_max_pc_01.png?ver=1758869472)

![](https://www.docomo.ne.jp/flcache_data/charge/index/img_price_docomo_poikatsu_max_smt_01.png?ver=1760918415)![割引適用内訳](https://www.docomo.ne.jp/flcache_data/charge/index/img_price_common_ttl.png?ver=1749049242)

![](https://www.docomo.ne.jp/flcache_data/charge/index/img_price_docomo_poikatsu_max_smt_02.png?ver=1756170012)

![スクロール](https://www.docomo.ne.jp/images_osp/common/img/img_guide_scroll01@2x.png)![](https://www.docomo.ne.jp/flcache_data/charge/index/img_price_docomo_poikatsu_max_smt_03.png?ver=1758869472)

![](https://www.docomo.ne.jp/flcache_data/charge/index/img_price_docomo_poikatsu_max_pc_03.png?ver=1758869472)

![](https://www.docomo.ne.jp/flcache_data/charge/index/img_price_docomo_poikatsu_max_smt_04.png?ver=1749049243)

![](https://www.docomo.ne.jp/flcache_data/charge/index/img_price_docomo_poikatsu_max_smt_05.png?ver=1758869472)

![スクロール](https://www.docomo.ne.jp/images_osp/common/img/img_guide_scroll01@2x.png)

手続き窓口

- オンライン：〇

- 電話：◯

- 店頭：〇


**＼マネックス証券特典／**

[詳しくみる _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://monex.docomo.ne.jp/service/nisa/index.html?utm_source=eximo&utm_medium=pull&utm_campaign=eximo_202411&utm_term=11&utm_content=399_docomo&acOpenChannel=d19071102#merit-box2)

**＼ポイ活ファミリー特典／**

ご家族でドコモの回線をご契約いただき、「ドコモ ポイ活 MAX」「eximoポイ活」のご契約が1回線以上ある場合に適用される特典です。「ドコモ ポイ活 MAX」ご契約者および2025年2月4日以降に「eximoポイ活」をご契約された方は、自動適用となりますのでお手続きは不要です。

[詳しくみる __](https://www.docomo.ne.jp/campaign_event/promotion/poikatsu_family/?icid=CRP_CHA_to_CRP_CAM_promotion_poikatsu_family)

01. 大量通信時などに通信制限がかかる場合があります。「5Gデータプラス」「データプラス」「データプラス（2019年9月30日以前お申込み）」をご契約の場合、ペア回線の利用可能データ量は30GBとなり、上限超過後は通信速度が送受信最大1Mbpsとなります。詳細は「 [5Gデータプラス](https://www.docomo.ne.jp/charge/5g-dataplus/?icid=CRP_CHA_mid_to_CRP_CHA_5g-dataplus)」をご確認ください。

02. 同一「ファミリー割引」グループ内における音声通話が可能な料金プラン（「2in1」、「キッズケータイプラス」、「キッズケータイプラン」「irumo（0.5GB）」を除く）契約回線がカウント対象となります。

03. 月末時点の支払い方法をdカード、dカード GOLD U、dカード GOLD、dカード PLATINUMによる定期クレジット設定にしていることが割引条件となります。


- 家族カードも対象

- 一括請求代表回線のお支払い方法が定期クレジット設定（本料金プランをdカード／dカード GOLD U／dカード GOLD／dカード PLATINUMで毎月支払う設定）の場合、一括請求代表回線の料金プランにかかわらず、対象料金プランを契約している一括請求子回線は割引が適用されます。


「dカードお支払割」は回線契約が個人名義のお客さまのみが対象です。回線契約が法人名義のお客さま向けには、「ビジネスメンバーズ割」（1回線当たり275円（税込）／月を月額利用料から割引）、「社員割」（6回線以上ご契約の法人名義に1回線当たり275円（税込）／月を月額利用料から割引）をご用意しております。

- 月末時点の支払い方法をdカードで定期クレジット設定している場合は220円（税込）（ただし、キャンペーン期間中は550円（税込））、dカード GOLD U、dカード GOLD、dカード PLATINUMで定期クレジット設定している場合は550円（税込）割り引きします。


04. 「dカード」を定期支払いに設定いただいたお客さまを対象に、カード券種に関係なく550円（税込）／月を割り引くキャンペーンを実施いたします。（2025年10月31日をもちまして、本キャンペーンは終了しました）

05. 「ドコモ光」または「home 5G プラン」契約者と同一「ファミリー割引」グループ内の「ドコモ MAX」「ドコモ ポイ活 MAX」「ドコモ ポイ活 20」「ドコモ mini」の契約者が対象です。同一「ファミリー割引」グループ内に「ドコモ光」「home 5G プラン」の両方が存在する場合は、「ドコモ光セット割」が適用されます。月額料金が日割り計算となる場合は、割引額も日割り計算となります。また、適用には「ドコモ光」もしくは「home 5G プラン」のご契約が必要となり別途費用がかかります（「ドコモ光」の場合、プロバイダ込・1ギガ・解約金（戸建：5,500円（税込）／マンション：4,180円（税込））有で月4,400円（税込）～5,940円（税込）。「home 5G プラン」の場合、月5,280円（税込）と別途HR01／HR02のご購入が必要）。

06. 同一「ファミリー割引」グループ内に、「ドコモでんき」のペア回線（「ドコモでんき」と対になる携帯電話回線）が含まれている場合、同一「ファミリー割引」グループ内の対象料金プランを契約する各回線に対してそれぞれ割引が適用となります。


    本契約回線が「ドコモでんき」のペア回線に指定されている場合でも、同一「ファミリー割引」グループ内の「ドコモ ポイ活 MAX」「ドコモ ポイ活 20」「ドコモ MAX」「ドコモ mini」については「ドコモでんきセット割」の対象となります。割引対象回線の月額料金が日割りとなる場合、「ドコモでんきセット割」の割引額も日割りとなります。また、適用には「ドコモでんき」のご契約が必要となり、「ドコモでんき」は別途料金がかかります。各エリアごとの料金については [ドコモでんきサイト _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://denki.docomo.ne.jp/plan/price/) の料金単価表をご確認ください。

07. 定期クレジット設定しているdカード GOLD U／dカード GOLD／dカード PLATINUMとは別のdカード GOLD U／dカード GOLD／dカード PLATINUMに対しご利用携帯電話番号登録いただいた場合でも、dカード GOLD U／dカード GOLDは5.0%、dカード PLATINUMは10.0%の進呈率を適用します。

08. dポイント（期間・用途限定）は対象決済の利用があった翌月下旬に進呈され、進呈日から93日間が有効期限となります。翌月のポイント進呈日を超えて反映された売上分の特典（dポイント）は、反映が遅れた日程分、有効期限（進呈日から93日間）が短くなります。対象決済がdカード／dカード GOLD U／dカード GOLD／dカード PLATINUMの場合、決済において、キャンセルが発生した場合、対象の決済にて進呈したポイントは減算されます。dポイント獲得履歴はdポイントクラブサイトで確認が可能です。

09. 対象決済がdカード GOLD U／dカード GOLD／dカード PLATINUMの場合、対象決済の利用日の23：59時点で、ご利用携帯電話番号として登録した、本料金プランを契約している回線の利用料金をdカード／dカード GOLD U／dカード GOLD／dカード PLATINUMで支払う設定をしている必要があります。対象決済がd払いの場合、決済時点で本料金プランを契約している回線の料金プランをdカード／dカード GOLD U／dカード GOLD／dカード PLATINUMで支払う設定をしていることに加え、ご利用のdカード GOLD U／dカード GOLD／dカード PLATINUMに本料金プランを契約している回線のご利用携帯電話番号登録の設定をしている必要があります。

10. 対象決済を行った日において、ご利用のdカード／dカード GOLD U／dカード GOLD／dカード PLATINUM（本カード／家族カード）に本料金プランを契約している回線のご利用携帯電話番号が設定されていることが必要です。

11. dカードで通常たまるポイント（利用額100円（税込）につき1ポイント）の対象になるお支払い、「ドコモでんき」および「ドコモ ガス」ご利用料金が対象です。毎月のドコモの携帯電話ご利用料金、年会費、各種手数料、電子マネー・プリペイドカードへのチャージ、「THEO＋docomo」などは進呈対象外となります。詳細は [こちら _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://dcard.docomo.ne.jp/st/beginner_about/attention/index.html) をご確認ください。

12. d払いを利用した決済であっても、dポイント利用によるお支払い分、クーポン利用によるお支払い分、モバイルSuicaチャージによるお支払い分、決済対象が請求書払い（公共料金、地方税統一QRコードなど）である場合、ポイント進呈の対象外となります。なお、一部ポイント進呈対象外の店舗がございます。詳細は [こちら _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://service.smt.docomo.ne.jp/keitai_payment/town/no-reward.html) をご確認ください。

13. d払いのお支払い方法を電話料金合算払い（電話料金の支払い方法にdカード以外のクレジットカードを設定している場合を除く）、dカード、d払い残高に設定されたお支払いのみが対象です。

14. d払いのお支払い方法を電話料金合算払い（電話料金の支払い方法にdカード以外のクレジットカードを設定している場合）、またはdカード以外のクレジットカードに設定したお支払いはdポイントの進呈対象外です。d払いの基本還元率は、dカードによるお支払いは1.0%、電話料金合算払い（電話料金の支払い方法にdカード以外のクレジットカードを設定している場合を除く）およびd払い残高によるお支払いは0.5%、電話料金合算払い（電話料金の支払い方法にdカード以外のクレジットカードを設定している場合）およびdカード以外のクレジットカードによるお支払いは0%となります。

15. 定期クレジットの設定状況および、dカード GOLD U／dカード GOLD／dカード PLATINUMのご利用携帯電話番号への登録状況に関わらず、キャンペーン期間中の進呈率は10%となります。ただし、dカード決済の場合はご利用電話番号登録が必要です。また、キャンペーン終了時期未定です。当社は、1か月前までに当社が適当と判断する方法で周知することにより、キャンペーンを終了することができます。

16. dカードは年会費無料、dカード GOLD Uは年会費3,300円（税込）、dカード GOLDは年会費11,000円（税込）、dカード PLATINUMは年会費29,700円（税込）がかかります。各種dカードはそれぞれ所定の審査があります。


- 別途機種代金・通話料（国内通話の場合30秒ごとに22円（税込））などがかかります。


![](https://www.docomo.ne.jp/flcache_data/charge/index/img_bonus_pc_01.png?ver=1761614532)![](https://www.docomo.ne.jp/flcache_data/charge/index/img_bonus_smt_01.png?ver=1761614532)[![Leminoプレミアム入会で最大6か月間おトクに使えるキャンペーン ※入会月の月末までにエントリー要。毎月1回以上の視聴など各種条件あり。初回無料期間など各種特典適用がある期間はポイント進呈の対象外となる場合あり。詳しくはこちら](https://www.docomo.ne.jp/flcache_data/charge/index/bnr_lemino_pc.png?ver=1749049241)![Leminoプレミアム入会で最大6か月間おトクに使えるキャンペーン ※入会月の月末までにエントリー要。毎月1回以上の視聴など各種条件あり。初回無料期間など各種特典適用がある期間はポイント進呈の対象外となる場合あり。詳しくはこちら](https://www.docomo.ne.jp/flcache_data/charge/index/bnr_lemino_smt.png?ver=1749049241)](https://lemino.docomo.ne.jp/cp/0000123/?utm_source=corp_charge&utm_medium=free-display&utm_campaign=lemino_202506_dcmcorp-ryoukin-nyukai900ptcp-0605)

**＼Amazonプライムについて／**

[ご登録はこちら _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://ssw.web.docomo.ne.jp/prime/campaign/max_202506/?utm_source=corp_other&utm_medium=free-display&utm_campaign=ap_202506_ap_0000748)

[![ドコモから入会がお得ディズニープラスの月額料金から毎月1,140円が最大6か月間割引要エントリー](https://www.docomo.ne.jp/flcache_data/charge/index/bnr_disneyplus_01_pc.png?ver=1756083612)![ドコモから入会がお得ディズニープラスの月額料金から毎月1,140円が最大6か月間割引要エントリー](https://www.docomo.ne.jp/flcache_data/charge/index/bnr_disneyplus_01_smt.png?ver=1756083612)_![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://service.smt.docomo.ne.jp/site/special/src/disneyplus_campaign_index.html?ex_cmp=dp_ddcm_corp_2ndTOP_poikatsu_max&utm_source=corp_2ndTOP_poikatsu_max&utm_medium=display&utm_campaign=dp_202006_set)

[![「ギガライト」「irumo」契約者限定！「ドコモ MAX」「ドコモ ポイ活 MAX」にWebにてお申込みで3,000ポイントプレゼントキャンペーン](https://www.docomo.ne.jp/flcache_data/charge/index/bnr-gigalite-irumo_pc.png?ver=1761096850)![「ギガライト」「irumo」契約者限定！「ドコモ MAX」「ドコモ ポイ活 MAX」にWebにてお申込みで3,000ポイントプレゼントキャンペーン](https://www.docomo.ne.jp/flcache_data/charge/index/bnr-gigalite-irumo_smt.png?ver=1761096850)_![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://ssw.web.docomo.ne.jp/nssw/dcmgiga/cp/maxweb3000ptcp/?utm_source=corp_campaign&utm_medium=free-display&utm_campaign=dcmgiga_202510_cam_0003766)

1. 「NBA docomo」の配信対象試合について詳しくは [こちら _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://nba.docomo.ne.jp/lp/entry001/?utm_source=corp_other&utm_medium=free-display&utm_campaign=nbaservicelp_202510_nbadocomo_newplan_charge1) をご確認ください。

2. 2026年1月まで（予定）に「ドコモ MAX」「ドコモ ポイ活 MAX」を翌月適用でお申込みいただいた場合、お申込み当月から「NBA docomo」「DAZN for docomo」が追加料金なしでご利用になれます。ただし、対象料金プランの翌月適用がキャンセルされた場合、当月の「NBA docomo」 「DAZN for docomo」の月額利用料を請求いたします。ドコモ回線以外のお客さまが追加料金なしで「NBA docomo」もしくは「DAZN for docomo」をご利用いただくためには各サービスのお申込み時点において、「ドコモ MAX」「ドコモ ポイ活 MAX」をご契約いただいている必要があります。対象料金プランお申込み前に各サービスをご契約された場合、対象料金プランお申込みの翌月以降でないと、各サービスを追加料金なしでご利用いただけませんのでご注意ください。

3. ドコモ以外でご契約中のDAZNを退会される際、退会手続き後に一定期間課金が発生する場合があります。詳しくは [こちら _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://www.dazn.com/ja-JP/help/articles/16194539395613-DAZN%E3%81%AE%E9%80%80%E4%BC%9A%E6%96%B9%E6%B3%95) をご確認ください。

4. ドコモからの「Amazonプライム」登録で、回線利用料と「Amazonプライム」月額会費の合計額から、「Amazonプライム」月額会費相当の600円を最大6か月間割り引きます。当社提供の他Amazonプライム割引特典と重畳はできません。本特典が優先となります。

5. 「Amazonプライム」の月額会費は600円（税込）です（2025年6月時点）。「Amazonプライム」は6か月間の割引終了後、ご登録期間中はdポイント（期間・用途限定）を毎月120ポイント還元いたします。

6. 海外データ通信について詳しくは [こちら](https://www.docomo.ne.jp/service/world/roaming/max/?icid=CRP_CHA_btm_to_CRP_SER_world_roaming_max) をご確認ください。

7. 一部対象外の地域があります。詳しくは [こちら](https://www.docomo.ne.jp/service/world/roaming/charge/web.html?icid=CRP_CHA_btm_to_CRP_SER_world_roaming_charge_web#anc-01) をご確認ください。

8. 長期利用割は「ドコモ MAX」「ドコモ ポイ活 MAX」のお客さまが対象です。ドコモのご利用継続期間が20年以上のお客さまは220円／月、10年以上のお客さまは110円／月を月額料金から割り引きます。


[料金プランを詳しくみる __](https://www.docomo.ne.jp/charge/docomo_poikatsu_max/?icid=CRP_CHA_to_CRP_CHA_docomo_poikatsu_max)

![ドコモ ポイ活 20](https://www.docomo.ne.jp/flcache_data/charge/index/logo_docomo_poikatsu_20.png?ver=1749049243)

### 気軽にポイ活をスタート！   d払い※1&dカード※2でのお買い物が還元率UP！

ドコモでポイ活を気軽に

はじめていただける

月間利用可能データ量が

2段階制の料金プラン

1. d払いはお支払い方法をdカード／電話料金合算払い（電話料金の支払い方法にdカード以外のクレジットカードを設定している場合を除く）／d払い残高に設定されたお支払いが対象です。


※ただし、dポイント利用分などは対象外。

2. dカードは年会費無料、dカード GOLD Uは年会費3,300円（税込）、dカード GOLDは年会費11,000円（税込）、dカード PLATINUMは年会費29,700円（税込）がかかります。各種dカードはそれぞれ所定の審査があります。


![ドコモ ポイ活 20 ～20Bでの料金イメージ 基本料金7,180円／月（税込7,898円／月） 割引適用分 ポイント充当分 実質1,880円／月（税込2,068円／月）](https://www.docomo.ne.jp/flcache_data/charge/index/img_graph_docomo_poikatsu_20_pc.png?ver=1758869471)![ドコモ ポイ活 20 ～20Bでの料金イメージ 基本料金7,180円／月（税込7,898円／月） 割引適用分 ポイント充当分 実質1,880円／月（税込2,068円／月）](https://www.docomo.ne.jp/flcache_data/charge/index/img_graph_docomo_poikatsu_20_smt.png?ver=1758869471)

[ポイント特典についてはこちら __](https://www.docomo.ne.jp/charge/?icid=CRP_menu_to_CRP_CHA#anc-02-01-poikatsu-20)

![](https://www.docomo.ne.jp/flcache_data/charge/index/img_price_docomo_poikatsu_20_pc_01.png?ver=1758869472)

![](https://www.docomo.ne.jp/flcache_data/charge/index/img_price_docomo_poikatsu_20_smt_01.png?ver=1758869472)![割引適用内訳](https://www.docomo.ne.jp/flcache_data/charge/index/img_price_common_ttl.png?ver=1749049242)

![](https://www.docomo.ne.jp/flcache_data/charge/index/img_price_docomo_poikatsu_20_smt_02.png?ver=1756170012)

![スクロール](https://www.docomo.ne.jp/images_osp/common/img/img_guide_scroll01@2x.png)![](https://www.docomo.ne.jp/flcache_data/charge/index/img_price_docomo_poikatsu_20_smt_03.png?ver=1758869472)

![](https://www.docomo.ne.jp/flcache_data/charge/index/img_price_docomo_poikatsu_20_pc_03.png?ver=1758869472)

![](https://www.docomo.ne.jp/flcache_data/charge/index/img_price_docomo_poikatsu_20_smt_04.png?ver=1749049243)![スクロール](https://www.docomo.ne.jp/images_osp/common/img/img_guide_scroll01@2x.png)

![](https://www.docomo.ne.jp/flcache_data/charge/index/img_price_docomo_poikatsu_20_smt_05.png?ver=1758869472)

![スクロール](https://www.docomo.ne.jp/images_osp/common/img/img_guide_scroll01@2x.png)

手続き窓口

- オンライン：〇

- 電話：◯

- 店頭：〇


**＼マネックス証券特典／**

[詳しくみる _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://monex.docomo.ne.jp/service/nisa/index.html?utm_source=eximo&utm_medium=pull&utm_campaign=eximo_202411&utm_term=11&utm_content=399_docomo&acOpenChannel=d19071102#merit-box2)

01. 大量通信時などに通信制限がかかる場合があります。「5Gデータプラス」「データプラス」「データプラス（2019年9月30日以前お申込み）」をご契約の場合、ペア回線の利用可能データ量は30GBとなり、上限超過後は通信速度が送受信最大1Mbpsとなります。詳細は「 [5Gデータプラス](https://www.docomo.ne.jp/charge/5g-dataplus/?icid=CRP_CHA_btm_to_CRP_CHA_5g-dataplus)」をご確認ください。

02. 同一「ファミリー割引」グループ内における音声通話が可能な料金プラン（「2in1」、「キッズケータイプラス」、「キッズケータイプラン」「irumo（0.5GB）」を除く）契約回線がカウント対象となります。

03. 月末時点の支払い方法をdカード、dカード GOLD U、dカード GOLD、dカード PLATINUMによる定期クレジット設定にしていることが割引条件となります。


- 家族カードも対象

- 一括請求代表回線のお支払い方法が定期クレジット設定（本料金プランをdカード／dカード GOLD U／dカード GOLD／dカード PLATINUMで毎月支払う設定）の場合、一括請求代表回線の料金プランにかかわらず、対象料金プランを契約している一括請求子回線は割引が適用されます。


「dカードお支払割」は回線契約が個人名義のお客さまのみが対象です。回線契約が法人名義のお客さま向けには、「ビジネスメンバーズ割」（1回線当たり275円（税込）／月を月額利用料から割引）、「社員割」（6回線以上ご契約の法人名義に1回線当たり275円（税込）／月を月額利用料から割引）をご用意しております。

- 月末時点の支払い方法をdカードで定期クレジット設定している場合は220円（税込）（ただし、キャンペーン期間中は550円（税込））、dカード GOLD U、dカード GOLD、dカード PLATINUMで定期クレジット設定している場合は550円（税込）割り引きします。


04. 「dカード」を定期支払いに設定いただいたお客さまを対象に、カード券種に関係なく550円（税込）／月を割り引くキャンペーンを実施いたします。（2025年10月31日をもちまして、本キャンペーンは終了しました）

05. 「ドコモ光」または「home 5G プラン」契約者と同一「ファミリー割引」グループ内の「ドコモ MAX」「ドコモ ポイ活 MAX」「ドコモ ポイ活 20」「ドコモ mini」の契約者が対象です。同一「ファミリー割引」グループ内に「ドコモ光」「home 5G プラン」の両方が存在する場合は、「ドコモ光セット割」が適用されます。月額料金が日割り計算となる場合は、割引額も日割り計算となります。また、適用には「ドコモ光」もしくは「home 5G プラン」のご契約が必要となり別途費用がかかります（「ドコモ光」の場合、プロバイダ込・1ギガ・解約金（戸建：5,500円（税込）／マンション：4,180円（税込））有で月4,400円（税込）～5,940円（税込）。「home 5G プラン」の場合、月5,280円（税込）と別途HR01／HR02のご購入が必要）。

06. 同一「ファミリー割引」グループ内に、「ドコモでんき」のペア回線（「ドコモでんき」と対になる携帯電話回線）が含まれている場合、同一「ファミリー割引」グループ内の対象料金プランを契約する各回線に対してそれぞれ割引が適用となります。


    本契約回線が「ドコモでんき」のペア回線に指定されている場合でも、同一「ファミリー割引」グループ内の「ドコモ ポイ活 MAX」「ドコモ ポイ活 20」「ドコモ MAX」「ドコモ mini」については「ドコモでんきセット割」の対象となります。割引対象回線の月額料金が日割りとなる場合、「ドコモでんきセット割」の割引額も日割りとなります。また、適用には「ドコモでんき」のご契約が必要となり、「ドコモでんき」は別途料金がかかります。各エリアごとの料金については [ドコモでんきサイト _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://denki.docomo.ne.jp/plan/price/) の料金単価表をご確認ください。

07. 定期クレジット設定しているdカード GOLD U／dカード GOLD／dカード PLATINUMとは別のdカード GOLD U／dカード GOLD／dカード PLATINUMに対しご利用携帯電話番号登録いただいた場合でも、dカード GOLD U／dカード GOLDは2.0%、dカード PLATINUMは5.0%の進呈率を適用します。

08. dポイント（期間・用途限定）は対象決済の利用があった翌月下旬に進呈され、進呈日から93日間が有効期限となります。翌月のポイント進呈日を超えて反映された売上分の特典（dポイント）は、反映が遅れた日程分、有効期限（進呈日から93日間）が短くなります。対象決済がdカード／dカード GOLD U／dカード GOLD／dカード PLATINUMの場合、決済において、キャンセルが発生した場合、対象の決済にて進呈したポイントは減算されます。dポイント獲得履歴はdポイントクラブサイトで確認が可能です。

09. 対象決済がdカード GOLD U／dカード GOLD／dカード PLATINUMの場合、対象決済の利用日の23：59時点で、ご利用携帯電話番号として登録した、本料金プランを契約している回線の利用料金をdカード／dカード GOLD U／dカード GOLD／dカード PLATINUMで支払う設定をしている必要があります。対象決済がd払いの場合、決済時点で本料金プランを契約している回線の料金プランをdカード／dカード GOLD U／dカード GOLD／dカード PLATINUMで支払う設定をしていることに加え、ご利用のdカード GOLD U／dカード GOLD／dカード PLATINUMに本料金プランを契約している回線のご利用携帯電話番号登録の設定をしている必要があります。

10. 対象決済を行った日において、ご利用のdカード／dカード GOLD U／dカード GOLD／dカード PLATINUM（本カード／家族カード）に本料金プランを契約している回線のご利用携帯電話番号が設定されていることが必要です。

11. dカードで通常たまるポイント（利用額100円（税込）につき1ポイント）の対象になるお支払い、「ドコモでんき」および「ドコモ ガス」ご利用料金が対象です。毎月のドコモの携帯電話ご利用料金、年会費、各種手数料、電子マネー・プリペイドカードへのチャージ、「THEO＋docomo」などは進呈対象外となります。詳細は [こちら _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://dcard.docomo.ne.jp/st/beginner_about/attention/index.html) をご確認ください。

12. d払いを利用した決済であっても、dポイント利用によるお支払い分、クーポン利用によるお支払い分、モバイルSuicaチャージによるお支払い分、決済対象が請求書払い（公共料金、地方税統一QRコードなど）である場合、ポイント進呈の対象外となります。なお、一部ポイント進呈対象外の店舗がございます。詳細は [こちら _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://service.smt.docomo.ne.jp/keitai_payment/town/no-reward.html) をご確認ください。

13. d払いのお支払い方法を電話料金合算払い（電話料金の支払い方法にdカード以外のクレジットカードを設定している場合を除く）、dカード、d払い残高に設定されたお支払いのみが対象です。

14. d払いのお支払い方法を電話料金合算払い（電話料金の支払い方法にdカード以外のクレジットカードを設定している場合）、またはdカード以外のクレジットカードに設定したお支払いはdポイントの進呈対象外です。d払いの基本還元率は、dカードによるお支払いは1.0%、電話料金合算払い（電話料金の支払い方法にdカード以外のクレジットカードを設定している場合を除く）およびd払い残高によるお支払いは0.5%、電話料金合算払い（電話料金の支払い方法にdカード以外のクレジットカードを設定している場合）およびdカード以外のクレジットカードによるお支払いは0%となります。

15. 定期クレジットの設定状況および、dカード GOLD U／dカード GOLD／dカード PLATINUMのご利用携帯電話番号への登録状況に関わらず、キャンペーン期間中の進呈率は5%となります。ただし、dカード決済の場合はご利用電話番号登録が必要です。また、キャンペーン終了時期未定です。当社は、1か月前までに当社が適当と判断する方法で周知することにより、キャンペーンを終了することができます。

16. dカードは年会費無料、dカード GOLD Uは年会費3,300円（税込）、dカード GOLDは年会費11,000円（税込）、dカード PLATINUMは年会費29,700円（税込）がかかります。各種dカードはそれぞれ所定の審査があります。


- 別途機種代金・通話料（国内通話の場合30秒ごとに22円（税込））などがかかります。


![](https://www.docomo.ne.jp/flcache_data/charge/index/img_bonus_pc_02.png?ver=1749049242)![](https://www.docomo.ne.jp/flcache_data/charge/index/img_bonus_smt_02.png?ver=1749049242)

**＼Amazonプライムについて／**

[ご登録はこちら _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://ssw.web.docomo.ne.jp/prime/campaign/max_202506/?utm_source=corp_other&utm_medium=free-display&utm_campaign=ap_202506_ap_0000748)

1. ドコモからの「Amazonプライム」登録で、回線利用料と「Amazonプライム」月額会費の合計額から、「Amazonプライム」月額会費相当の600円を最大6か月間割り引きます。当社提供の他Amazonプライム割引特典と重畳はできません。本特典が優先となります。

2. 「Amazonプライム」の月額会費は600円（税込）です（2025年6月時点）。「Amazonプライム」は6か月間の割引終了後、ご登録期間中はdポイント（期間・用途限定）を毎月120ポイント還元いたします。


[料金プランを詳しくみる __](https://www.docomo.ne.jp/charge/docomo_poikatsu_20/?icid=CRP_CHA_to_CRP_CHA_docomo_poikatsu_20)

![ドコモ mini](https://www.docomo.ne.jp/flcache_data/charge/index/logo_docomo_mini.png?ver=1749049243)

### 4GB／10GB   ギガを必要なぶんだけ

データ利用量が少なく、

毎月の通信料を抑えたい

お客さま向けの料金プラン

ご利用状況に合わせて

2つのデータ容量から選べる

![ドコモ mini 4GBでの料金イメージ 基本料金2,500円／月（税込2,750円／月）割引適用分 実質800円／月（税込880円／月）](https://www.docomo.ne.jp/flcache_data/charge/index/img_graph_docomo_mini_pc.png?ver=1758869471)![](https://www.docomo.ne.jp/flcache_data/charge/index/img_price_docomo_mini_pc_01.png?ver=1758869472)

![ドコモ mini 4GBでの料金イメージ 基本料金2,500円／月（税込2,750円／月）割引適用分 実質800円／月（税込880円／月）](https://www.docomo.ne.jp/flcache_data/charge/index/img_graph_docomo_mini_smt.png?ver=1758869471)![割引適用内訳](https://www.docomo.ne.jp/flcache_data/charge/index/img_price_common_ttl.png?ver=1749049242)

![](https://www.docomo.ne.jp/flcache_data/charge/index/img_price_docomo_mini_smt_02.png?ver=1749049242)

![スクロール](https://www.docomo.ne.jp/images_osp/common/img/img_guide_scroll01@2x.png)![](https://www.docomo.ne.jp/flcache_data/charge/index/img_price_docomo_mini_smt_03.png?ver=1758869472)

手続き窓口

- オンライン：〇

- 電話：◯

- 店頭：〇


1. 月末時点の支払い方法をdカード、dカード GOLD U、dカード GOLD、dカード PLATINUMによる定期クレジット設定にしていることが割引条件となります。


- 家族カードも対象

- 一括請求代表回線のお支払い方法が定期クレジット設定（本料金プランをdカード／dカード GOLD U／dカード GOLD／dカード PLATINUMで毎月支払う設定）の場合、一括請求代表回線の料金プランにかかわらず、対象料金プランを契約している一括請求子回線は割引が適用されます。


「dカードお支払割」は回線契約が個人名義のお客さまのみが対象です。回線契約が法人名義のお客さま向けには、「ビジネスメンバーズ割」（1回線当たり275円（税込）／月を月額利用料から割引）、「社員割」（6回線以上ご契約の法人名義に1回線当たり275円（税込）／月を月額利用料から割引）をご用意しております。

- 月末時点の支払い方法をdカードで定期クレジット設定している場合は220円（税込）（ただし、キャンペーン期間中は550円（税込））、dカード GOLD U、dカード GOLD、dカード PLATINUMで定期クレジット設定している場合は550円（税込）割り引きします。


2. 「dカード」を定期支払いに設定いただいたお客さまを対象に、カード券種に関係なく550円（税込）／月を割り引くキャンペーンを実施いたします。（2025年10月31日をもちまして、本キャンペーンは終了しました）

3. 「ドコモ光」または「home 5G プラン」契約者と同一「ファミリー割引」グループ内の「ドコモ MAX」「ドコモ ポイ活 MAX」「ドコモ ポイ活 20」「ドコモ mini」の契約者が対象です。同一「ファミリー割引」グループ内に「ドコモ光」「home 5G プラン」の両方が存在する場合は、「ドコモ光セット割」が適用されます。月額料金が日割り計算となる場合は、割引額も日割り計算となります。また、適用には「ドコモ光」もしくは「home 5G プラン」のご契約が必要となり別途費用がかかります（「ドコモ光」の場合、プロバイダ込・1ギガ・解約金（戸建：5,500円（税込）／マンション：4,180円（税込））有で月4,400円（税込）～5,940円（税込）。「home 5G プラン」の場合、月5,280円（税込）と別途HR01／HR02のご購入が必要）。

4. 同一「ファミリー割引」グループ内に、「ドコモでんき」のペア回線（「ドコモでんき」と対になる携帯電話回線）が含まれている場合、同一「ファミリー割引」グループ内の対象料金プランを契約する各回線に対してそれぞれ割引が適用となります。


本契約回線が「ドコモでんき」のペア回線に指定されている場合でも、同一「ファミリー割引」グループ内の「ドコモ ポイ活 MAX」「ドコモ ポイ活 20」「ドコモ MAX」「ドコモ mini」については「ドコモでんきセット割」の対象となります。割引対象回線の月額料金が日割りとなる場合、「ドコモでんきセット割」の割引額も日割りとなります。また、適用には「ドコモでんき」のご契約が必要となり、「ドコモでんき」は別途料金がかかります。各エリアごとの料金については [ドコモでんきサイト _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://denki.docomo.ne.jp/plan/price/) の料金単価表をご確認ください。


- 別途機種代金・通話料（国内通話の場合30秒ごとに22円（税込））などがかかります。


![](https://www.docomo.ne.jp/flcache_data/charge/index/img_bonus_pc_03.png?ver=1749049242)![](https://www.docomo.ne.jp/flcache_data/charge/index/img_bonus_smt_03.png?ver=1749049242)

**＼Amazonプライムについて／**

[ご登録はこちら _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://ssw.web.docomo.ne.jp/prime/campaign/mini_202506/?utm_source=corp_other&utm_medium=free-display&utm_campaign=ap_202506_ap_0000749)

1. ドコモからの「Amazonプライム」登録で、回線利用料と「Amazonプライム」月額会費の合計額から、「Amazonプライム」月額会費相当の600円を最大3か月間割り引きます。当社提供のほかAmazonプライム割引特典と重畳はできません。本特典が優先となります。

2. 「Amazonプライム」の月額会費は600円（税込）です（2025年6月時点）。「Amazonプライム」は3か月間の割引終了後、ご登録期間中はdポイント（期間・用途限定）を毎月120ポイント還元いたします。


[料金プランを詳しくみる __](https://www.docomo.ne.jp/charge/docomo_mini/?icid=CRP_CHA_to_CRP_CHA_docomo_mini)

![ahamo](https://www.docomo.ne.jp/flcache_data/charge/index/logo_ahamo.png?ver=1749049243)

### たっぷり30GB  シンプルワンプラン

プランはひとつだけ！

お申し込みから契約後の

サポートまでオンラインにて

受付する料金プランです。

5分以内の通話無料※1・「みんなドコモ割」の

カウント対象

1. 1回あたりの通話時間が5分を超過した場合、超過分について30秒ごとに22円（税込）の通話料がかかります。またデジタル通信料（テレビ電話など）についても5分以内の通信は定額対象となります。SMS、他社接続サービスなどへの発信は、別途料金がかかります。


![](https://www.docomo.ne.jp/flcache_data/charge/index/img_price_ahamo_pc_01.png?ver=1749049242)

[詳しくみる _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://ahamo.com/?utm_source=corp_charge&utm_medium=free-display&utm_campaign=ahamo_202110_top_general_br)

![](https://www.docomo.ne.jp/flcache_data/charge/index/img_price_ahamo_pc_02.png?ver=1749049242)

[詳しくみる _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://ahamo.com/special/oomori/)

![](https://www.docomo.ne.jp/flcache_data/charge/index/img_price_ahamo_pc_03.png?ver=1749049242)

![](https://www.docomo.ne.jp/flcache_data/charge/index/img_price_ahamo_smt_01.png?ver=1749049242)

[詳しくみる _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://ahamo.com/?utm_source=corp_charge&utm_medium=free-display&utm_campaign=ahamo_202110_top_general_br)

![](https://www.docomo.ne.jp/flcache_data/charge/index/img_price_ahamo_smt_02.png?ver=1749049242)

![スクロール](https://www.docomo.ne.jp/images_osp/common/img/img_guide_scroll01@2x.png)

[詳しくみる _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://ahamo.com/special/oomori/)

![](https://www.docomo.ne.jp/flcache_data/charge/index/img_price_ahamo_smt_03.png?ver=1749049242)

![スクロール](https://www.docomo.ne.jp/images_osp/common/img/img_guide_scroll01@2x.png)

- 「ポイ活オプション」のご加入には「大盛りオプション」のご契約が必要となります。


![](https://www.docomo.ne.jp/flcache_data/charge/index/img_price_ahamo_pc_04.png?ver=1749049242)

1決済ごと、dカード：100円（税込）、d払い：200円（税込）につき

[詳しくみる _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://ahamo.com/special/poikatsu/)

手続き窓口

- オンライン：〇

- 電話：×

- 店頭：×


1. 機種代金・通話料が別途かかります。


- 国内通話5分以内無料となる対象通話


ドコモ／他社携帯電話着、固定電話着、光／IP電話着、時報（117）、番号案内通話料（104）※番号案内料を除く、災害対策伝言ダイヤル（171）


・国内通話無料の対象外通話


海外での発着信、「WORLD CALL」、「SMS」、（0570）（0180）（0067）等から始まる他社が料金設定している他社接続サービス、（188）特番、（104）の番号案内料、衛星電話／衛星船舶電話、当社が指定する電話番号（機械的な発信などにより、長時間または多数の通信を一定期間継続して接続する電話番号）など、上記の対象通話以外への発信は定額の対象外となり、別途料金がかかります。

- 進呈上限はポイント（期間・用途限定）4,000ポイント／月です。

- d払いのお支払い方法を電話料金合算払い（電話料金の支払い方法にdカード以外のクレジットカードを設定している場合を除く）、dカード、d払い残高に設定されたお支払いのみが対象です。ポイ活オプション加入日以降のd払いのご利用分が対象となります。ポイ活オプション加入前（予約中含む）および解約後のd払いのご利用分は特典進呈の対象外となります。対象外のお買い物は、dポイント利用分、クーポン利用分、モバイルSuicaチャージによる支払い分、請求書払い（公共料金、地方税統一QRコード）となります。一部対象外の店舗がございます。詳細は [こちら _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://service.smt.docomo.ne.jp/keitai_payment/town/no-reward.html) をご確認ください。


[ahamoへプラン変更手続きを\\
\\
行う際の注意事項 __](https://www.docomo.ne.jp/charge/ahamo_notice/?icid=CRP_CHA_to_CRP_CHA_ahamo_notice)

[料金プランを詳しくみる _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://ahamo.com/?utm_source=corp_charge&utm_medium=free-display&utm_campaign=ahamo_202110_top_general_br)

**5つのプランの特徴を比較したい方はこちら**

[![ドコモで選べる料金プラン](https://www.docomo.ne.jp/images_osp/charge/bnr/bnr_eraberu_pc.png?ver=1749049243)![ドコモで選べる料金プラン](https://www.docomo.ne.jp/images_osp/charge/bnr/bnr_eraberu_smt.png?ver=1749049243)](https://www.docomo.ne.jp/charge/promotion/eraberu/?icid=CRP_CHA_btn_to_CRP_CHA_promotion_eraberu)

## プラン検討・契約はこちら

[![料金シミュレーション](https://www.docomo.ne.jp/flcache_data/charge/index/btn_cv_01_pc.png?ver=1722438014)![料金シミュレーション](https://www.docomo.ne.jp/flcache_data/charge/index/btn_cv_01_smt.png?ver=1722438014)](https://www.docomo.ne.jp/charge/simulation/?icid=CRP_CHA_top_to_CRP_CHA_simulation)

[![機種購入＋プラン契約 モーダルウインドウが開きます](https://www.docomo.ne.jp/flcache_data/charge/index/btn_cv_02_pc.png?ver=1729478412)![機種購入＋プラン契約 モーダルウインドウが開きます](https://www.docomo.ne.jp/flcache_data/charge/index/btn_cv_02_smt.png?ver=1729478412)](https://www.docomo.ne.jp/charge/?icid=CRP_menu_to_CRP_CHA#select-plan-modal--subscribe-switch-01)

[![プランのみ契約 モーダルウインドウが開きます](https://www.docomo.ne.jp/flcache_data/charge/index/btn_cv_03_pc.png?ver=1729478412)![プランのみ契約 モーダルウインドウが開きます](https://www.docomo.ne.jp/flcache_data/charge/index/btn_cv_03_smt.png?ver=1729478412)](https://www.docomo.ne.jp/charge/?icid=CRP_menu_to_CRP_CHA#select-plan-modal--subscribe-switch-02)

[機種のみ購入の方はこちら _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://onlineshop.docomo.ne.jp/products/mobile?xcid=OLS_products_mobile_from_CRP_CHA)

## スマホデビューの方向け

5G4G(LTE)

[![はじめてスマホプラン](https://www.docomo.ne.jp/flcache_data/charge/index/bnr_hajimete_plan_pc.png?ver=1722438014)![はじめてスマホプラン](https://www.docomo.ne.jp/flcache_data/charge/index/bnr_hajimete_plan_smt.png?ver=1722438014)](https://www.docomo.ne.jp/support/promotion/migration/?icid=CRP_CHA_to_CRP_SUP_promotion_migration)

### FOMA・他社3G回線からスマホへ乗り換えなら

FOMAからの契約変更や他社3G回線からの5G・Xi（4G／LTE）へ

お乗りかえの方向けの料金プランです。

5分以内の国内通話が無料

![はじめてスマホプラン 1GB※1 基本料金 1,650円／月※2（税込1,815円／月） 割引後料金 最大12ヶ月間※5 980円／月（税込1,078円／月） 13ヶ月目以降ずっと※5 1,480円／月（税込1,628円／月）割引内訳 はじめてスマホ割（はじめてスマホプラン）※3 最大12か月-500円（税込550円） dカードお支払割※4 -170円（税込187円）](https://www.docomo.ne.jp/flcache_data/charge/index/img_price_hajimete_plan_pc.png?ver=1749049243)![はじめてスマホプラン 1GB※1 基本料金 1,650円／月※2（税込1,815円／月） 割引後料金 最大12ヶ月間※5 980円／月（税込1,078円／月） 13ヶ月目以降ずっと※5 1,480円／月（税込1,628円／月）割引内訳 はじめてスマホ割（はじめてスマホプラン）※3 最大12か月-500円（税込550円） dカードお支払割※4 -170円（税込187円）](https://www.docomo.ne.jp/flcache_data/charge/index/img_price_hajimete_plan_smt.png?ver=1749049243)手続き窓口

- オンライン：〇

- 電話：◯

- 店頭：〇


1. 当月のデータ量が1GBを超えた場合、通信速度は送受信最大128kbpsとなります。

2. 「はじめてスマホプラン（月額：税込1,980円）」に、「はじめてスマホISP割（月額：税込165円割引）」を適用した料金です。

3. お申込み日にかかわらず、初回割引適用月を1か月目として起算し、最大12か月間割引します。

4. 各ご利用月の末日時点でご利用料金のお支払い方法をdカード／dカード GOLD U／dカード GOLD／dカード PLATINUM（家族カード含む）に設定（一括請求グループは代表回線での設定）をされている方が対象です。

5. 「はじめてスマホプラン」（月額：税込1,980円）に、「はじめてスマホISP割（月額：税込165円割引）」「はじめてスマホ割（最大12か月間　月額：税込550円割引）」「dカードお支払割（月額：税込187円割引）」を適用した料金です。


- 「定期契約（2年）あり」の場合は、割引条件、月額料金などが異なりますので「はじめてスマホプラン」の「割引・特典」をご確認ください。

- 国内通話無料となる対象通話


ドコモ／他社携帯電話着、固定電話着、光／IP電話着、時報（117）、番号案内通話料（104）※番号案内料を除く、災害対策伝言ダイヤル（171）


- 国内通話無料の対象外通話


海外での発着信、「WORLD CALL」、「SMS」、（0570）（0180）（0067）等から始まる他社が料金設定している他社接続サービス、（188）特番、（104）の番号案内料、衛星電話／衛星船舶電話、当社が指定する電話番号（機械的な発信などにより、長時間または多数の通信を一定期間継続して接続する電話番号）など、上記の対象通話以外への発信は定額の対象外となり、別途料金がかかります。


[詳しくみる __](https://www.docomo.ne.jp/charge/hajimete_plan/?icid=CRP_CHA_ac_to_CRP_CHA_hajimete_plan)

5G4G(LTE)

[![U15はじめてスマホプラン](https://www.docomo.ne.jp/flcache_data/charge/index/bnr_u15_hajimete_plan_pc.png?ver=1722438014)![U15はじめてスマホプラン](https://www.docomo.ne.jp/flcache_data/charge/index/bnr_u15_hajimete_plan_smt.png?ver=1722438014)](https://www.docomo.ne.jp/charge/promotion/u15_hajimete_plan/?icid=CRP_CHA_to_CRP_CHA_promotion_u15_hajimete_plan)

### 15歳以下の  スマホデビューがおトクに！

15歳以下でスマホデビューをする方が対象のおトクな料金プランです。

5分以内の国内通話が無料・18歳までの間はデータ通信料がずっと変わらない

![U15はじめてスマホプラン 5GB 基本料金 1,650円／月※1（税込1,815円／月） 割引後料金 1,480円／月（税込1,628円／月） 10GB 基本料金 2,450円／月※2 （税込2,695円／月） 割引後料金 2,280円／月（税込2,508円／月） 割引内訳 dカードお支払割※3 -170円（税込187円）](https://www.docomo.ne.jp/flcache_data/charge/index/img_price_u15_hajimete_plan_pc.png?ver=1749049243)![U15はじめてスマホプラン 5GB 基本料金 1,650円／月※1（税込1,815円／月） 割引後料金 1,480円／月（税込1,628円／月） 10GB 基本料金 2,450円／月※2 （税込2,695円／月） 割引後料金 2,280円／月（税込2,508円／月） 割引内訳 dカードお支払割※3 -170円（税込187円）](https://www.docomo.ne.jp/flcache_data/charge/index/img_price_u15_hajimete_plan_smt.png?ver=1749049243)手続き窓口

- オンライン：〇

- 電話：〇

- 店頭：〇


1. 「U15はじめてスマホプラン（5GB）」（月額：税込1,980円）に、「U15はじめてスマホISP割（月額：税込165円割引）」を適用した料金です。

2. 「U15はじめてスマホプラン（10GB）」（月額：税込2,860円）に、「U15はじめてスマホISP割（月額：税込165円割引）」を適用した料金です。

3. 各ご利用月の末日時点でご利用料金のお支払い方法をdカード／dカード GOLD U／dカード GOLD／dカード PLATINUM（家族カード含む）に設定（一括請求グループは代表回線での設定）をされている方が対象です。


- ご登録されている利用者が満19歳を迎えた場合、翌月以降の利用可能データ量がU15はじめてスマホプラン（5GB）は1GB／月、U15はじめてスマホプラン（10GB）は2GB／月になります。

- 当月のご利用可能データ量を超えた場合、当月末までの通信速度が送受信時最大128kbpsとなります。


[詳しくみる __](https://www.docomo.ne.jp/charge/u15_hajimete_plan/?icid=CRP_CHA_ac_to_CRP_CHA_u15_hajimete_plan)

## その他の料金プラン

### ケータイをご利用の方向け

#### 通話利用中心の方にオススメ！

4G(LTE)

[![ケータイプラン](https://www.docomo.ne.jp/flcache_data/charge/index/bnr_keitaiplan_pc.png?ver=1722438014)![ケータイプラン](https://www.docomo.ne.jp/flcache_data/charge/index/bnr_keitaiplan_smt.png?ver=1722438014)](https://www.docomo.ne.jp/charge/keitaiplan-2/?icid=CRP_CHA_to_CRP_CHA_keitaiplan-2)

ドコモ ケータイをお使いの、通話利用が中心の方におすすめの料金プランです。

家族間通話無料※1

![ケータイプラン 100MB※2 基本料金 1,370円／月（税込1,507円／月） 割引後料金 1,200円／月（税込1,320円／月） 割引内訳 dカードお支払割※3 -170円（税込187円）](https://www.docomo.ne.jp/flcache_data/charge/index/img_price_keitaiplan_pc.png?ver=1749049243)![ケータイプラン 100MB※2 基本料金 1,370円／月（税込1,507円／月） 割引後料金 1,200円／月（税込1,320円／月） 割引内訳 dカードお支払割※3 -170円（税込187円）](https://www.docomo.ne.jp/flcache_data/charge/index/img_price_keitaiplan_smt.png?ver=1749049243)手続き窓口

- オンライン：〇

- 電話：〇

- 店頭：〇


1. 「家族」とは、同一「ファミリー割引」グループをさします。「ファミリー割引」を契約の場合、同一「ファミリー割引」グループ内の国内通話料は無料となります。

2. 当月のデータ量が利用可能データ量を超えた場合、通信速度は送受信最大128kbpsとなります。

3. 各ご利用月の末日時点でご利用料金のお支払い方法をdカード／dカード GOLD U／dカード GOLD／dカード PLATINUM（家族カード含む）に設定（一括請求グループは代表回線での設定）をされてる方が対象です。


[詳しくみる __](https://www.docomo.ne.jp/charge/keitaiplan-2/?icid=CRP_CHA_ac_to_CRP_CHA_keitaiplan-2)

#### お子さま向けのケータイを  お探しの方に

4G(LTE)

[![ケータイプラン](https://www.docomo.ne.jp/flcache_data/charge/index/bnr_kidskeitaiplan_pc.png?ver=1722438014)![ケータイプラン](https://www.docomo.ne.jp/flcache_data/charge/index/bnr_kidskeitaiplan_smt.png?ver=1722438014)](https://www.docomo.ne.jp/charge/kidskeitaiplan-3/?icid=CRP_CHA_to_CRP_CHA_kidskeitaiplan-3)

「キッズケータイ KY-41C」「キッズケータイ SK-41D」「キッズケータイ SH-03M」をお使いの方向けの料金プランです。

家族間通話無料※1

![キッズケータイプラン 無制限※2※3※4 基本料金 500円／月（税込550円／月）](https://www.docomo.ne.jp/flcache_data/charge/index/img_price_kidskeitaiplan_pc.png?ver=1749049243)![キッズケータイプラン 無制限※2※3※4 基本料金 500円／月（税込550円／月）](https://www.docomo.ne.jp/flcache_data/charge/index/img_price_kidskeitaiplan_smt.png?ver=1749049243)手続き窓口

- オンライン：〇

- 電話：〇

- 店頭：〇


1. 「家族」とは、同一「ファミリー割引」グループをさします。「ファミリー割引」を契約の場合、同一「ファミリー割引」グループ内の国内通話料は無料となります。

2. 「＋メッセージ（プラスメッセージ）」での、テキストメッセージ・スタンプ・写真・動画の送受信にかかるデータ量が無制限となります（「＋メッセージ」のご利用は「キッズケータイKY-41C」のみとなります）。

3. 「キッズケータイ KY-41C」「キッズケータイ コンパクト SK-41D」をご利用のお客さまは、「＋メッセージ（プラスメッセ―ジ）」を無制限でご利用になれます。なお「キッズケータイ コンパクト SK-41D」からスタンプ、写真、動画の送信をすることはできません。

4. キッズケータイ端末からのブラウザ閲覧などはご利用いただけません。


[詳しくみる __](https://www.docomo.ne.jp/charge/kidskeitaiplan-3/?icid=CRP_CHA_ac_to_CRP_CHA_kidskeitaiplan-3)

## データシェアご利用の方向け

### タブレット・ルータなどの  2台目機種の5G通信

5G

[![5Gデータプラス](https://www.docomo.ne.jp/flcache_data/charge/index/bnr_5g-dataplus_pc.png?ver=1722438013)![5Gデータプラス](https://www.docomo.ne.jp/flcache_data/charge/index/bnr_5g-dataplus_smt.png?ver=1722438013)](https://www.docomo.ne.jp/charge/5g-dataplus/?icid=CRP_CHA_to_CRP_CHA_5g-dataplus)

タブレット・ルーターや2台目機種へデータ量をシェアできる

5G専用の料金プランです。

![5Gデータプラス ペアとなる料金プラン※1のデータ量シェア※2 基本料金 1,000円／月（税込1,100円／月）](https://www.docomo.ne.jp/flcache_data/charge/index/img_price_5g-dataplus_pc.png?ver=1749049242)![5Gデータプラス ペアとなる料金プラン※1のデータ量シェア※2 基本料金 1,000円／月（税込1,100円／月）](https://www.docomo.ne.jp/flcache_data/charge/index/img_price_5g-dataplus_smt.png?ver=1749049242)手続き窓口

- オンライン：〇

- 電話：〇

- 店頭：〇


1. ペアとなる料金プラン：「ドコモ MAX」「ドコモ ポイ活 MAX」「ドコモ ポイ活 20」「eximo ポイ活」「eximo」「ahamo」「5Gギガホ プレミア」「5Gギガホ」「5Gギガライト」「ギガホプレミア」「ギガホ」「ギガライト」

2. 同一のご契約名義において、「eximo ポイ活」などのペアとなる料金プランのご契約回線がある場合のみお申込み可能で、「データプラス」単独でのご契約はできません。


[詳しくみる __](https://www.docomo.ne.jp/charge/5g-dataplus/?icid=CRP_CHA_ac_to_CRP_CHA_5g-dataplus)

#### タブレット・ルータなどの  2台目機種の4G通信

4G(LTE)

[![データプラス](https://www.docomo.ne.jp/flcache_data/charge/index/bnr_dataplus_pc.png?ver=1722438013)![データプラス](https://www.docomo.ne.jp/flcache_data/charge/index/bnr_dataplus_smt.png?ver=1722438013)](https://www.docomo.ne.jp/charge/dataplus-2/?icid=CRP_CHA_to_CRP_CHA_dataplus-2)

タブレット・ルーターや2台目機種へデータ量をシェアできる

料金プランです。

![データプラス ペアとなる料金プラン※1のデータ量シェア※2 基本料金 1,000円／月（税込1,100円／月）](https://www.docomo.ne.jp/flcache_data/charge/index/img_price_dataplus_pc.png?ver=1749049242)![データプラス ペアとなる料金プラン※1のデータ量シェア※2 基本料金 1,000円／月（税込1,100円／月）](https://www.docomo.ne.jp/flcache_data/charge/index/img_price_dataplus_smt.png?ver=1749049242)手続き窓口

- オンライン：〇

- 電話：〇

- 店頭：〇


1. ペアとなる料金プラン：「ドコモ MAX」「ドコモ ポイ活 MAX」「ドコモ ポイ活 20」「eximo ポイ活」「eximo」「ahamo」「5Gギガホ プレミア」「5Gギガホ」「5Gギガライト」「ギガホプレミア」「ギガホ」「ギガライト」

2. 同一のご契約名義において、「eximo ポイ活」などのペアとなる料金プランのご契約回線がある場合のみお申込み可能で、「データプラス」単独でのご契約はできません。


[詳しくみる __](https://www.docomo.ne.jp/charge/dataplus-2/?icid=CRP_CHA_ac_to_CRP_CHA_dataplus-2)

## 上空でLTEモバイルネットワークをご利用の方向け

4G(LTE)

[![LTE上空利用プラン](https://www.docomo.ne.jp/flcache_data/charge/index/bnr_lte-joukuriyou-plan_pc.png?ver=1722438014)![LTE上空利用プラン](https://www.docomo.ne.jp/flcache_data/charge/index/bnr_lte-joukuriyou-plan_smt.png?ver=1722438014)](https://www.docomo.ne.jp/charge/lte-joukuriyou-plan/?icid=CRP_CHA_to_CRP_CHA_lte-joukuriyou-plan)

無人航空機（ドローンなど）および、

小型航空機など向け専用料金プランです。

![選べる2つの料金タイプ データ無制限「定額無制限タイプ」45,273円／月（税込49,800円） 利用可能データ量 通信速度を気にせず無制限 新料金プラン「従量タイプ」基本料金11,364円／月～（税込12,500円） 利用可能データ量 0GB：11,364円（税込12,500円）～3GB未満：33,910円（税込37,300円）～120GB：45,273円（税込49,800円）](https://www.docomo.ne.jp/flcache_data/charge/index/img_price_lte-joukuriyou-plan_pc.png?ver=1752627623)![選べる2つの料金タイプ データ無制限「定額無制限タイプ」45,273円／月（税込49,800円） 利用可能データ量 通信速度を気にせず無制限 新料金プラン「従量タイプ」基本料金11,364円／月～（税込12,500円） 利用可能データ量 0GB：11,364円（税込12,500円）～3GB未満：33,910円（税込37,300円）～120GB：45,273円（税込49,800円）](https://www.docomo.ne.jp/flcache_data/charge/index/img_price_lte-joukuriyou-plan_smt.png?ver=1752627623)

[詳しくみる __](https://www.docomo.ne.jp/charge/lte-joukuriyou-plan/?icid=CRP_CHA_ac_to_CRP_CHA_lte-joukuriyou-plan)

## 他社提供・小容量プラン

[![ドコモのエコノミーMVNO](https://www.docomo.ne.jp/flcache_data/charge/index/bnr_docomo_economy_mvno_pc.png?ver=1722438013)![ドコモのエコノミーMVNO](https://www.docomo.ne.jp/flcache_data/charge/index/bnr_docomo_economy_mvno_smt.png?ver=1722438013)](https://www.docomo.ne.jp/charge/docomo_economy_mvno/?icid=CRP_CHA_to_CRP_CHA_docomo_economy_mvno)

- MVNOとは：ドコモなどの移動通信事業者の提供する通信回線を借り受け、通信サービス提供する電気通信事業者です。


## プラン検討・契約はこちら

[![料金シミュレーション](https://www.docomo.ne.jp/flcache_data/charge/index/btn_cv_01_pc.png?ver=1722438014)![料金シミュレーション](https://www.docomo.ne.jp/flcache_data/charge/index/btn_cv_01_smt.png?ver=1722438014)](https://www.docomo.ne.jp/charge/simulation/?icid=CRP_CHA_middle_to_CRP_CHA_simulation)

[![機種購入＋プラン契約 モーダルウインドウが開きます](https://www.docomo.ne.jp/flcache_data/charge/index/btn_cv_02_pc.png?ver=1729478412)![機種購入＋プラン契約 モーダルウインドウが開きます](https://www.docomo.ne.jp/flcache_data/charge/index/btn_cv_02_smt.png?ver=1729478412)](https://www.docomo.ne.jp/charge/?icid=CRP_menu_to_CRP_CHA#select-plan-modal--subscribe-switch-01)

[![プランのみ契約 モーダルウインドウが開きます](https://www.docomo.ne.jp/flcache_data/charge/index/btn_cv_03_pc.png?ver=1729478412)![プランのみ契約 モーダルウインドウが開きます](https://www.docomo.ne.jp/flcache_data/charge/index/btn_cv_03_smt.png?ver=1729478412)](https://www.docomo.ne.jp/charge/?icid=CRP_menu_to_CRP_CHA#select-plan-modal--subscribe-switch-02)

[機種のみ購入の方はこちら _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://onlineshop.docomo.ne.jp/products/mobile?xcid=OLS_products_mobile_from_CRP_CHA_btm)

## オプション

#### 通話関連  （ドコモ MAX／ドコモ ポイ活 MAX／ドコモ ポイ活 20／ドコモ miniご契約の方向け）

- [![5分通話無料オプション](https://www.docomo.ne.jp/flcache_data/charge/index/ico_5min.png?ver=1722438014)5分通話無料オプション880円（税込）／月\\
__](https://www.docomo.ne.jp/charge/onsei_option/?icid=CRP_CHA_txt01_to_CRP_CHA_onsei_option)
- [![かけ放題オプション](https://www.docomo.ne.jp/flcache_data/charge/index/ico_houdai.png?ver=1722438014)かけ放題オプション1,980円（税込）／月\\
__](https://www.docomo.ne.jp/charge/onsei_option/?icid=CRP_CHA_txt02_to_CRP_CHA_onsei_option)

#### ギガ追加

- [![1GB追加オプション](https://www.docomo.ne.jp/flcache_data/charge/index/ico_1gb.png?ver=1722438014)1GB追加オプション1,100円（税込）／1GB\\
__](https://www.docomo.ne.jp/charge/1gb_option/?icid=CRP_CHA_to_CRP_CHA_1gb_option)
- [![スピードモード](https://www.docomo.ne.jp/flcache_data/charge/index/ico_speedmood.png?ver=1725354343)スピードモード1,100円（税込）／1GB\\
__](https://www.docomo.ne.jp/charge/speedmode/?icid=CRP_CHA_to_CRP_CHA_speedmode)

#### 海外利用

- [![世界そのままギガ](https://www.docomo.ne.jp/flcache_data/charge/index/ico_world.png?ver=1722438015)世界そのままギガ200～円／1時間\\
__](https://www.docomo.ne.jp/service/world/roaming/sonomama-giga/?icid=CRP_CHA_to_CRP_SER_world_roaming_sonomama-giga)
- [![世界ギガし放題](https://www.docomo.ne.jp/flcache_data/charge/index/ico_world_sihodai.png?ver=1722438015)世界ギガし放題最大2,980円／日\\
__](https://www.docomo.ne.jp/service/world/roaming/giga-shihodai/?icid=CRP_CHA_to_CRP_SER_world_roaming_giga-shihodai)

#### データ使用量制限

- [![上限設定オプション](https://www.docomo.ne.jp/flcache_data/charge/index/ico_upper_limit.png?ver=1722438014)上限設定オプション無料\\
__](https://www.docomo.ne.jp/charge/upper_limit_option/?icid=CRP_CHA_to_CRP_CHA_upper_limit_option)
- [![データ量到達通知サービス](https://www.docomo.ne.jp/flcache_data/charge/index/ico_data.png?ver=1722438014)データ量到達通知サービス無料\\
__](https://www.docomo.ne.jp/charge/online_notification_service/?icid=CRP_CHA_to_CRP_CHA_online_notification_service)

#### 副回線

- [![副回線サービス](https://www.docomo.ne.jp/flcache_data/charge/index/ico_hukukaisen.png?ver=1722438014)副回線サービス429円～（税込）／月\\
__](https://www.docomo.ne.jp/service/hukukaisen/?icid=CRP_CHA_to_CRP_SER_hukukaisen)

## 割引・特典

- [![1年ごとにおトクに最新機種へ買いかえできるプログラム！](https://www.docomo.ne.jp/flcache_data/charge/index/discount/bnr_discount_01.png?ver=1722438015)\\
\\
1年ごとにおトクに最新機種へ買いかえできるプログラム！](https://www.docomo.ne.jp/campaign_event/kaedoki_program_plus/?icid=CRP_CHA_to_CRP_CAM_kaedoki_program_plus)
- [![iPhone・Androidスマホ・iPad・タブレットなどを下取り実施中](https://www.docomo.ne.jp/flcache_data/charge/index/discount/bnr_discount_02.jpg?ver=1750320015)\\
\\
下取りプログラム活用で、おトクに機種を買替えよう](https://www.docomo.ne.jp/campaign_event/shitadori/?icid=CRP_CHA_to_CRP_CAM_shitadori)
- [![](https://www.docomo.ne.jp/flcache_data/charge/index/discount/bnr_discount_other.svg?ver=1722438015)\\
\\
割引・特典一覧をみる](https://www.docomo.ne.jp/charge/discount.html?icid=CRP_CHA_to_CRP_CHA_discount)

## 料金シミュレーション

契約プラン・オプションでお悩みの方はこちら

[![選んでいくだけ！月々のお支払い額が分かる 料金シミュレーション](https://www.docomo.ne.jp/flcache_data/charge/index/bnr_kantan_simulation_pc.png?ver=1722438014)![選んでいくだけ！月々のお支払い額が分かる 料金シミュレーション](https://www.docomo.ne.jp/flcache_data/charge/index/bnr_kantan_simulation_smt.png?ver=1722438014)](https://www.docomo.ne.jp/charge/simulation/?icid=CRP_CHA_to_CRP_CHA_simulation)

## 契約内容・料金確認

[![My docomo ドコモユーザー向け 契約内容・料金確認](https://www.docomo.ne.jp/flcache_data/charge/index/bnr_mydocomo01_pc.png?ver=1722438014)![My docomo ドコモユーザー向け 契約内容・料金確認](https://www.docomo.ne.jp/flcache_data/charge/index/bnr_mydocomo01_smt.png?ver=1722438014)](https://www.docomo.ne.jp/mydocomo/?icid=CRP_CHA_to_CRP_MYD)

- [料金のご請求とお支払いについて __](https://www.docomo.ne.jp/support/bill_schedule/?icid=CRP_CHA_to_CRP_SUP_bill_schedule)
- [法人のお客さまはこちら](https://www.ntt.com/business/mobile/charge.html)

## 料金関連情報

[![新規申し込み受付を終了した料金プラン・割引など](https://www.docomo.ne.jp/flcache_data/charge/index/bnr_close_pc.png?ver=1722438013)![新規申し込み受付を終了した料金プラン・割引など](https://www.docomo.ne.jp/flcache_data/charge/index/bnr_close_smt.png?ver=1722438013)](https://www.docomo.ne.jp/charge/close.html?icid=CRP_CHA_to_CRP_CHA_close)

- [一般電話・公衆電話からの通話料 __](https://www.docomo.ne.jp/charge/call_charge/?icid=CRP_CHA_to_CRP_CHA_call_charge)
- [海外でつかう・日本から海外へかける __](https://www.docomo.ne.jp/service/world/?icid=CRP_CHA_to_CRP_SER_world)
- [ユニバーサルサービス制度 __](https://www.docomo.ne.jp/corporate/disclosure/universal_service/?icid=CRP_CHA_to_CRP_CORP_disclosure_universal_service)
- [電話リレーサービスの制度 __](https://www.docomo.ne.jp/corporate/disclosure/telephonerelay/?icid=CRP_CHA_to_CRP_CORP_disclosure_telephonerelay)

## 更新情報

[![](https://www.docomo.ne.jp/images_osp/common/ico/ico_rss_01.png?ver=1678089614)RSS](https://www.docomo.ne.jp/info/rss/)

- 2025年6月5日



[お客さまのさまざまなニーズにお応えする新料金プラン 「ドコモ MAX」「ドコモ ポイ活 MAX」「ドコモ ポイ活 20」「ドコモ mini」を提供開始しました。](https://www.docomo.ne.jp/info/news_release/2025/04/24_00.html)

- 2024年7月31日



[ドコモポイ活プラン「eximo ポイ活」の提供を開始 -ｄカードのご利用でdポイントがもっとたまる！もっとつかえる！ ギガ無制限の新料金プランが登場-](https://www.docomo.ne.jp/info/news_release/2024/07/31_01.html)

- 2023年6月20日



[2023年7月1日（土曜）から提供開始　新料金プラン「eximo」-小容量から無制限のデータ利用まで多様なニーズに応える料金プラン-](https://www.docomo.ne.jp/info/news_release/2023/06/20_01.html)


[更新情報一覧へ __](https://www.docomo.ne.jp/info/update/?icid=CRP_CHA_to_CRP_INFO_update&directSearch=1&year-select=%E3%83%BC&category-select=%E6%9B%B4%E6%96%B0%E6%83%85%E5%A0%B1&type=%E6%96%99%E9%87%91%E3%83%BB%E5%89%B2%E5%BC%95)

## キャンペーン・特典

[**爆アゲセレクション**\\
\\
![爆アゲセレクション](https://www.docomo.ne.jp/campaign_event/common/images/20230306_bakuage_smt.jpg)\\
\\
あの人気サブスクが賢くおトクに！月額料金の10～25％相当のdポイント還元！\\
\\
_別ウインドウが開きます_](https://ssw.web.docomo.ne.jp/bakuage/)

[キャンペーン・特典一覧へ __](https://www.docomo.ne.jp/campaign_event/?icid=CRP_CHA_to_CRP_CAM)

## キャンペーン・特典

[**爆アゲセレクション**\\
\\
![爆アゲセレクション](https://www.docomo.ne.jp/campaign_event/common/images/20230306_bakuage_smt.jpg)\\
\\
あの人気サブスクが賢くおトクに！月額料金の10～25％相当のdポイント還元！\\
\\
_別ウインドウが開きます_](https://ssw.web.docomo.ne.jp/bakuage/)

[キャンペーン・特典一覧へ __](https://www.docomo.ne.jp/campaign_event/?icid=CRP_CHA_to_CRP_CAM)

- Apple、Appleのロゴ、AirPlay、AirPods、Apple Music、Apple Pay、Apple Pencil、Apple TV、Apple Watch、Ceramic Shield、Dynamic Island、Face ID、FaceTime、iBooks、iPad、iPhone、iTunes、Lightning、Magic Keyboard、MagSafe、ProMotion、Siri、Touch ID、TrueDepth、True Toneは、米国および他の国々で登録されたApple Inc.の商標です。iPhoneの商標は、 [アイホン株式会社 _別ウインドウが開きます_](https://www.aiphone.co.jp/) のライセンスにもとづき使用されています。App Store、Apple Arcade、AppleCare+、Apple TV+、iCloudは、Apple Inc.のサービスマークです。TM and © 2025 Apple Inc. All rights reserved.


- [![ドコモ光とスマホがセットでおトク！家のインターネットはドコモ光](https://www.docomo.ne.jp/images_osp/charge/bnr/bnr_docomo_hikari_01.png?ver=1545001211)](https://www.docomo.ne.jp/hikari/?icid=CRP_CHA_to_CRP_HIKARI)


×

#### 機種購入＋プラン契約

ご希望のプランを選択ください

[![ドコモ MAX](https://www.docomo.ne.jp/flcache_data/charge/index/logo_docomo_max.png?ver=1749049243)\\
_![別ウインドウで開きます。](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://onlineshop.docomo.ne.jp/products/mobile?xcid=OLS_mobile_from_CRP_202508_max_2nd_with-product&utm_source=corp_charge&utm_medium=owned&utm_campaign=ols_202508_max-2nd&utm_content=202508_max_mobile_2nd_with-product)

[![ドコモ ポイ活 MAX](https://www.docomo.ne.jp/flcache_data/charge/index/logo_docomo_poikatsu_max.png?ver=1749049243)\\
_![別ウインドウで開きます。](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://onlineshop.docomo.ne.jp/products/mobile?xcid=OLS_mobile_from_CRP_202508_poikatsu-max_2nd_with-product&utm_source=corp_charge&utm_medium=owned&utm_campaign=ols_202508_poikatsu-max-2nd&utm_content=202508_poikatsu-max_mobile_2nd_with-product)

[![ドコモ ポイ活 20](https://www.docomo.ne.jp/flcache_data/charge/index/logo_docomo_poikatsu_20.png?ver=1749049243)\\
_![別ウインドウで開きます。](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://onlineshop.docomo.ne.jp/products/mobile?xcid=OLS_mobile_from_CRP_202508_poikatsu20_2nd_with-product&utm_source=corp_charge&utm_medium=owned&utm_campaign=ols_202508_poikatsu20-2nd&utm_content=202508_poikatsu20_mobile_2nd_with-product)

[![ドコモ mini](https://www.docomo.ne.jp/flcache_data/charge/index/logo_docomo_mini.png?ver=1749049243)\\
_![別ウインドウで開きます。](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://onlineshop.docomo.ne.jp/products/mobile?xcid=OLS_mobile_from_CRP_202508_mini_2nd_with-product&utm_source=corp_charge&utm_medium=owned&utm_campaign=ols_202508_mini-2nd&utm_content=202508_mini_mobile_2nd_with-product)

[![ahamo（アハモ）](https://www.docomo.ne.jp/flcache_data/charge/index/ico_ahamo.svg?ver=1722438014)\\
_![別ウインドウで開きます。](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://ahamo.com/store/pub/application/type/)

[その他のプラン\\
\\
（はじめてスマホ\\
\\
プランなど）\\
\\
_![別ウインドウで開きます。](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://onlineshop.docomo.ne.jp/products/mobile?_gl=1*1f34spf*ga4_corporate_ga*MTYyNTQxMTkxOC4xNzE5MjkyNzIw*ga4_corporate_ga_PGCZ86Z6FM*MTcyNzI0MTUwMS44LjEuMTcyNzI0Mzk5OC42MC4wLjA.&xcid=OLS_products_mobile_from_CRP_CHA)

- ご契約状況によって手続きが異なりますので、上記の遷移先ページの

「お申込手順」にてご確認ください。


閉じる

×

#### プランのみ契約

ご利用中の回線を選択のうえ、上記の遷移先ページの

「お申込みガイド」にてご確認ください。

- ドコモ回線から
- 他社回線から

[![ドコモ MAX](https://www.docomo.ne.jp/flcache_data/charge/index/logo_docomo_max.png?ver=1749049243)\\
_![別ウインドウで開きます。](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://mydocomo.docomo.ne.jp/procedure/process?pid=201&xcid=OLT_procedure_process_from_CRP_max_plan_newplan_LP3)

[![ドコモ ポイ活 MAX](https://www.docomo.ne.jp/flcache_data/charge/index/logo_docomo_poikatsu_max.png?ver=1749049243)\\
_![別ウインドウで開きます。](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://mydocomo.docomo.ne.jp/procedure/process?pid=201&xcid=OLT_procedure_process_from_CRP_poikatsu-max_plan_newplan_LP3)

[![ドコモ ポイ活 20](https://www.docomo.ne.jp/flcache_data/charge/index/logo_docomo_poikatsu_20.png?ver=1749049243)\\
_![別ウインドウで開きます。](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://mydocomo.docomo.ne.jp/procedure/process?pid=201&xcid=OLT_procedure_process_from_CRP_poikatsu20_plan_newplan_LP3)

[![ドコモ mini](https://www.docomo.ne.jp/flcache_data/charge/index/logo_docomo_mini.png?ver=1749049243)\\
_![別ウインドウで開きます。](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://mydocomo.docomo.ne.jp/procedure/process?pid=201&xcid=OLT_procedure_process_from_CRP_mini_plan_newplan_LP3)

[![ahamo（アハモ）](https://www.docomo.ne.jp/flcache_data/charge/index/ico_ahamo.svg?ver=1722438014)\\
_![別ウインドウで開きます。](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://ahamo.com/store/pub/application/type/)

[その他のプラン\\
\\
（はじめてスマホ\\
\\
プランなど）\\
\\
_![別ウインドウで開きます。](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://mydocomo.docomo.ne.jp/procedure/process?pid=201&renkeiKbn=1&xcid=MYD_esite_from_CRP_CHA&_gl=1*ac6g5x*ga4_corporate_ga*MTYyNTQxMTkxOC4xNzE5MjkyNzIw*ga4_corporate_ga_PGCZ86Z6FM*MTcyNzIzMzM2OC43LjEuMTcyNzIzNjY2NC41MS4wLjA.)

- ご契約状況によって手続きが異なりますので、上記の遷移先ページの

「お申込みガイド」にてご確認ください。


[![ドコモ MAX](https://www.docomo.ne.jp/flcache_data/charge/index/logo_docomo_max.png?ver=1749049243)\\
_![別ウインドウで開きます。](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://onlineshop.docomo.ne.jp/products/exclusive/sim?xcid=OLS_sim_from_CRP_202508_max_2nd_sim-only&utm_source=corp_charge&utm_medium=owned&utm_campaign=ols_202508_max-2nd&utm_content=202508_max_sim_2nd_sim-only)

[![ドコモ ポイ活 MAX](https://www.docomo.ne.jp/flcache_data/charge/index/logo_docomo_poikatsu_max.png?ver=1749049243)\\
_![別ウインドウで開きます。](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://onlineshop.docomo.ne.jp/products/exclusive/sim?xcid=OLS_sim_from_CRP_202508_poikatsu-max_2nd_sim-only&utm_source=corp_charge&utm_medium=owned&utm_campaign=ols_202508_poikatsu-max-2nd&utm_content=202508_poikatsu-max_sim_2nd_sim-only)

[![ドコモ ポイ活 20](https://www.docomo.ne.jp/flcache_data/charge/index/logo_docomo_poikatsu_20.png?ver=1749049243)\\
_![別ウインドウで開きます。](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://onlineshop.docomo.ne.jp/products/exclusive/sim?xcid=OLS_sim_from_CRP_202508_poikatsu20_2nd_sim-only&utm_source=corp_charge&utm_medium=owned&utm_campaign=ols_202508_poikatsu20-2nd&utm_content=202508_poikatsu20_sim_2nd_sim-only)

[![ドコモ mini](https://www.docomo.ne.jp/flcache_data/charge/index/logo_docomo_mini.png?ver=1749049243)\\
_![別ウインドウで開きます。](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://onlineshop.docomo.ne.jp/products/exclusive/sim?xcid=OLS_sim_from_CRP_202508_mini_2nd_sim-only&utm_source=corp_charge&utm_medium=owned&utm_campaign=ols_202508_mini-2nd&utm_content=202508_mini_sim_2nd_sim-only)

[![ahamo（アハモ）](https://www.docomo.ne.jp/flcache_data/charge/index/ico_ahamo.svg?ver=1722438014)\\
_![別ウインドウで開きます。](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://ahamo.com/store/pub/application/type/)

[その他のプラン\\
\\
（はじめてスマホ\\
\\
プランなど）\\
\\
_![別ウインドウで開きます。](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://onlineshop.smt.docomo.ne.jp/sim-card/index.html?xcid=OLS_sim-card_from_CRP_CHA_modal_plan)

- ご契約状況によって手続きが異なりますので、上記の遷移先ページの

「お申込みガイド」にてご確認ください。


- ドコモ回線から
- 他社回線から

閉じる

[![このページのトップへ](https://www.docomo.ne.jp/images_osp/common/btn/btn_pagetop_01.png)](https://www.docomo.ne.jp/charge/?icid=CRP_menu_to_CRP_CHA#)

[![My docomo](https://www.docomo.ne.jp/flcache_data/charge/index/ico_mydocomo.png?ver=1722438014)\\
契約状況\\
\\
確認 _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03-strong_v2.png)_](https://mydocomo.docomo.ne.jp/) [![](https://www.docomo.ne.jp/flcache_data/charge/index/ico_products-purchase.png?ver=1730343551)\\
機種購入＋\\
\\
プラン契約 __](https://www.docomo.ne.jp/charge/?icid=CRP_menu_to_CRP_CHA#select-plan-modal--subscribe-switch-01) [![](https://www.docomo.ne.jp/flcache_data/charge/index/ico_plan_change.png?ver=1722438014)\\
プランのみ\\
\\
契約 __](https://www.docomo.ne.jp/charge/?icid=CRP_menu_to_CRP_CHA#select-plan-modal--subscribe-switch-02) [![](https://www.docomo.ne.jp/flcache_data/charge/index/ico_tetsuduki-support.png?ver=1730343551)\\
オンライン\\
\\
で相談 _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03-strong_v2.png)_](https://tetsuduki-support.docomo.ne.jp/?utm_source=corp&utm_medium=free-display&utm_campaign=onsapo_202411_corp-002-0007&utm_content=corp-002-0007-202411)![閉じる](https://www.docomo.ne.jp/images_osp/common/btn/btn_x_close_01_pc.png)![閉じる](https://www.docomo.ne.jp/images_osp/common/btn/btn_x_close_01_smt.png)

[![お困りですか？](https://www.docomo.ne.jp/images_osp/common/chat_tool/bnr_chat_tool.svg)](https://tetsuduki-support.docomo.ne.jp/?utm_source=corp&utm_medium=free-display&utm_campaign=onsapo_)

- [お知らせ](https://www.docomo.ne.jp/info/?icid=CRP_common_footer_to_CRP_INFO)
- [企業情報](https://www.docomo.ne.jp/corporate/?icid=CRP_common_footer_to_CRP_CORP)

* * *

- [パーソナルデータ（個人情報など）について](https://www.docomo.ne.jp/utility/personal_data/?icid=CRP_common_footer_to_CRP_UTI_personal_data)
- [プライバシーポリシー](https://www.docomo.ne.jp/utility/privacy/?icid=CRP_common_footer_to_CRP_UTI_privacy)
- [サイトご利用にあたって](https://www.docomo.ne.jp/utility/term/?icid=CRP_common_footer_to_CRP_UTI_term)
- [お客さまご利用端末からの情報の外部送信について](https://www.docomo.ne.jp/utility/term/?icid=CRP_common_footer_02_to_CRP_UTI_term#p09)
- [見やすさ・使いやすさの調整](https://www.docomo.ne.jp/utility/term/web_accessibility/faciliti/?icid=CRP_common_footer_to_CRP_UTI_term_web_accessibility_faciliti)
- [サイトメンテナンス情報 _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon-white.svg)_](https://www.docomo.ne.jp/mydocomo/maint/?icid=CRP_common_footer_to_CRP_MYD_maint)
- [サイトマップ](https://www.docomo.ne.jp/sitemap/?icid=CRP_common_footer_to_CRP_sitemap)
- [ご意見・ご要望](https://www.docomo.ne.jp/support/inquiry/feedback/?icid=CRP_common_footer_to_CRP_SUP_inquiry_feedback)
- [お問い合わせ](https://www.docomo.ne.jp/support/inquiry/?icid=CRP_common_footer_to_CRP_SUP_inquiry)
- [NTTドコモグループ _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon-white.svg)_](https://nttdocomo-group.com/index.html)

© NTT DOCOMO

![閉じる](https://www.docomo.ne.jp/images_osp/common/smtnav/btn_smtmenu_01_close_crp.png)

M