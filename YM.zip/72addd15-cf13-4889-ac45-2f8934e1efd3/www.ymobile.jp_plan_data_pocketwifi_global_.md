---
url: "https://www.ymobile.jp/plan/data/pocketwifi_global/"
title: "Pocket WiFi® 海外データ定額｜Pocket WiFi®｜料金｜Y!mobile - 格安SIM・スマホはワイモバイルで"
---

[![BLACK FRIDAY セール オンラインストア限定 12/1（月）14:59まで](https://www.ymobile.jp/common_c/images/index/head_promotion.png?20251120)![BLACK FRIDAY セール オンラインストア限定 12/1（月）14:59まで](https://www.ymobile.jp/common_c/images/index/head_promotion_sp.png?20251120)](https://www.ymobile.jp/lineup/?ref=topticker)

[Y!mobile](https://www.ymobile.jp/)

- [料金](https://www.ymobile.jp/plan/)
- [製品](https://www.ymobile.jp/lineup/)
- [SIM/eSIM](https://www.ymobile.jp/store/sp/sim/)
- [サービス](https://www.ymobile.jp/service/)
- [会員クーポン](https://www.ymobile.jp/service/ymobile/premium/#coupon-link)

- [お申し込み](https://www.ymobile.jp/select_contract/)
- [ログイン](https://www.ymobile.jp/support/online/login/)
- [法人ご契約](https://www.ymobile.jp/biz/)
- メニュー

- [![](https://www.ymobile.jp/common_c/images/common/icon/icon_home.svg)ホーム](https://www.ymobile.jp/)
- [料金](https://www.ymobile.jp/plan/)
- [Pocket WiFi®](https://www.ymobile.jp/plan/data/)
- Pocket WiFi® 海外データ定額

# Pocket WiFi® 海外データ定額

- 2021年5月11日（火）をもって「Pocket WiFi® 海外データ定額」の新規加入受付終了
- 2021年5月12日（水）以降に701UCの新規契約・機種変更をした場合、「世界対応ケータイ」に加入することで海外渡航時に自動で「海外パケットし放題」の利用が可能
- 2022年2月1日（火）以降、解除料撤廃により契約解除料は発生いたしません。

表示価格は特に記載がない限り税込です。

消費税の計算上、請求金額と異なる場合があります。

- 一部海外の国・地域において2G/3G通信サービスが終了しております。この影響により、2G/3G通信サービスを終了した国・地域では、Pocket WiFi® 海外データ定額をご利用いただけなくなります。ご利用の際は事前にご利用可能国をご確認ください。


なお、今後も2G/3G通信サービスが終了し、本サービスが利用できなくなる国・地域が発生する可能性がございます。uCloudlink Japan 株式会社より海外モバイル通信事業者の2G/3Ｇ通信サービスの提供終了状況が確認でき次第ご案内する予定ですが、利用可能と記載していても利用できない国もある可能性があるため、海外へお出かけの際は、渡航先の情報をご確認いただきますようお願い申し上げます。

![](https://www.ymobile.jp/plan/data/pocketwifi_global/images/img01.png)

- ※1 海外データ定額利用料は90円/日（免税）となります。

## 国内利用時

![](https://www.ymobile.jp/plan/data/pocketwifi_global/images/img02.png)

- ●国内で当月ご利用のデータ通信量が7GBを超えた場合に、当月末までデータ通信速度の低速化（送受信時最大128kbps）を行います。海外で当月ご利用のデータ通信料が7GBを超えた場合、当月末までデータ通信速度の低速化（送受信最大64kbps）を行います。なお翌月1日（GMT基準）まで通常速度には戻せません。また低速化に関する通知は行いません。
- ●国内利用時、通常速度に戻す場合は、0.5GBごとに550円の追加料金が必要です。


（通常速度に戻す申し込みは、 [My Y!mobile](https://www.ymobile.jp/support/online/login/) から可能です。1回の申し込みにあたり、当月分のみが適用されます。）
- ※混雑回避など通信品質確保のための速度制御（3日間で約10GB以上利用時）があります。 [通信速度制御の詳細はこちら](https://www.ymobile.jp/service/info/tsushin.html)

## 海外データ定額

### 従来サービスの1/20以下の料金！

![](https://www.ymobile.jp/plan/data/pocketwifi_global/images/img03.png)

- ※2当社国際ローミングとの比較です。
- ※3海外パケットし放題：日本国内でのご利用の機種で、海外でもデータ通信がご利用になれるサービスです。ご利用データ通信量が25MBまでは0円～1,980円/日。25MB以上は2,980円/日で利用できます。（免税）

### 世界100カ国以上で、たっぷりデータ通信！

![](https://www.ymobile.jp/plan/data/pocketwifi_global/images/img04.png)

- ※海外で当月ご利用のデータ通信料が7GBを超えた場合、当月末までデータ通信速度の低速化（送受信最大64kbps）を行います。なお翌月1日（GMT基準）まで通常速度には戻せません。また低速化に関する通知は行いません。

### ご利用可能国（2025年6月4日時点）

| 南・北アメリカ |
| --- |
| アメリカ※ | アラスカ | ハワイ※ |
| アルゼンチン | ウルグアイ | エクアドル |
| エルサルバドル | カナダ | グアテマラ |
| コスタリカ | コロンビア | チリ |
| ドミニカ共和国 | ニカラグア | パナマ |
| プエルトリコ | ブラジル | ベネズエラ |
| ペルー | ボリビア | メキシコ |
| アジア |
| インド※ | インドネシア※ | カンボジア |
| 韓国 | タイ | 中国 |
| ネパール | パキスタン | バングラデシュ |
| フィリピン※ | ベトナム※ | 香港 |
| マレーシア※ | ミャンマー | モンゴル |
| ヨルダン | ラオス |  |
| ヨーロッパ |
| アイスランド | アイルランド※ | アルバニア |
| イギリス※ | イタリア※ | ウクライナ |
| エストニア | オーストリア | オランダ※ |
| カザフスタン | キプロス | クロアチア※ |
| サンマリノ | スイス | スウェーデン |
| スペイン | スロバキア※ | スロベニア |
| セルビア | チェコ※ | デンマーク※ |
| ドイツ※ | トルコ※ | ノルウェー |
| バチカン | ハンガリー | フィンランド※ |
| フランス | ブルガリア | ベルギー※ |
| ポーランド | ポルトガル※ | マルタ |
| モナコ | ラトビア※ | リトアニア |
| リヒテンシュタイン | ルーマニア | ルクセンブルク |
| ロシア |  |  |
| オセアニア |
| グアム | サイパン | ニュージーランド |
| フィジー |  |  |
| 中東 |
| アラブ首長国連邦 | イエメン | イスラエル |
| カタール | サウジアラビア※ | バーレーン※ |
| アフリカ |
| アルジェリア | アンゴラ | エジプト |
| ガーナ | ケニア | ザンビア |
| タンザニア | チュニジア | ナイジェリア |
| モーリシャス | モロッコ |  |
| サービス提供終了国 |
| オーストラリア | ギリシャ | シンガポール |
| スリランカ | 台湾 | マカオ |
| 南アフリカ |  |  |

- ※海外通信事業者のサービス提供状況により、限られた一部のエリアでのご利用になる場合があります。

## 月々のお支払

| 契約種別 | 基本料 |
| --- | --- |
| ベーシック | 4,378円 |

- ※1契約期間に定めのない契約種別となります。
- ※併用サービスの使用料、端末代金は含まれていません。
- ※契約変更時、変更後契約の申し込み当月における料金プラン基本料はかかりません。
- ※ご契約初月は月額料金・割引額を日割り計算しますが、月途中の解約・解除の場合は日割り計算をしません。
- ※新規および契約変更でのご契約の場合には、 [契約事務手数料](https://www.ymobile.jp/plan/commission/) がかかります。
- ※[ユニバーサルサービス料](https://www.ymobile.jp/plan/info/universal/) が別途かかります。

2019年9月30日までにお申し込みの料金・契約期間について

## 月々のお支払

| 契約種別 | 基本料 |
| --- | --- |
| さんねん | 4,378円 |
| バリューセット※1 | 5,548.4円 |
| バリューセットライト※1 | 5,163.4円 |
| ベーシック | 6,578円 |

[料金改定について（2018年6月1日実施）](https://www.ymobile.jp/info/2018/0228/?plan=2)

- ※1加入月の翌月を1ヵ月目とし37ヵ月目に契約種別「さんねん」へ自動移行されます。
- ※併用サービスの使用料、端末代金は含まれていません。
- ※契約変更時、変更後契約の申し込み当月における料金プラン基本料はかかりません。
- ※ご契約初月は月額料金・割引額を日割り計算しますが、月途中の解約・解除の場合は日割り計算をしません。
- ※新規および契約変更でのご契約の場合には、 [契約事務手数料](https://www.ymobile.jp/plan/commission/) がかかります。
- ※[ユニバーサルサービス料](https://www.ymobile.jp/plan/info/universal/) が別途かかります。

## 契約種別について

| 契約種別 | 契約期間 | 長期契約割引 | 説明 |
| --- | --- | --- | --- |
| さんねん | 3年 | - | 契約期間が3年間の契約種別です。（3年毎に自動更新） |
| バリューセット | 3年 | 43,340円 | 契約期間が3年間の契約種別です。3年間の継続利用をいただくお約束で長期契約割引を適用します。長期契約割引は、原則、購入時のお支払い額（当社指定機器代金含む）からの割引とします。<br>契約期間満了後「さんねん」に自動移行します。 |
| バリューセットライト | 3年 | 29,040円 |
| ベーシック | - | - | 契約期間に定めのない契約種別です。 |

- ※「バリューセット」「バリューセットライト」は、Pocket WiFi®とパソコンやタブレットなどを同時購入する場合、3年間の継続利用をいただくお約束で長期契約割引を適用するご契約となります。

## ご加入条件・契約期間について

- ●3年間を契約期間としてご利用いただく料金プランです。
- ●契約期間は、契約開始日から算出し、3年後の同日が含まれる料金月を「満了月」とします。
- ●契約期間は、お申し出がない限り、自動更新（継続）されます。（「バリューセット」「バリューセットライト」の場合、加入月の翌月を1ヵ月目とし、37ヵ月目に契約種別が「さんねん」へ自動移行されます。）自動更新が不要の場合（満了月での終了をご希望の場合）は、満了月または契約更新月にMy Y!mobileなどで契約期間に定めのないプランへご変更ください。

### 契約解除料について

契約期間中に他の契約種別へ変更もしくは解約された場合、契約解除料がかかります。

契約種別「さんねん」の場合は10,450円、「バリューセット」「バリューセットライト」の場合は契約経過期間に応じた契約解除料がかかります。詳細は [こちら](https://www.ymobile.jp/plan/data/valueset_wifi2/) をご確認ください。

- ※ 「バリューセット」「バリューセットライト」は初回の満了月は無料期間の対象外となります。

#### 「さんねん」契約の場合

![](https://www.ymobile.jp/plan/images/data_aboutcancel02.png)

[![](https://www.ymobile.jp/plan/images/data_aboutcancel02.png)](https://www.ymobile.jp/plan/images/data_aboutcancel02.png)

### 注意事項

- ●「Pocket WiFi® 海外データ定額」では以下のオプションは加入いただけません。
- ・故障安心パック/世界対応ケータイ

詳細は提供条件書をお読みください

[「Pocket WiFi® 海外データ定額」プラン提供条件書](https://www.ymobile.jp/corporate/open/agreement/pdf/pokcetwifi_global.pdf)

【Pocket WiFi® 海外データ定額について】

- ・専用端末(701UC)購入と同時にのみ加入可能です。本プランを一度解約した専用端末では、本プランへ再度加入することはできません。
- ・本プランは個人名義のお客様のみご契約可能です。
- ・お客様が回線契約を解約された場合、本プランも解除となります。また譲渡並びに対象外プランへの
変更をされた場合、本プランを解除し Pocket WiFi® プラン 2 を適用、もしくは変更後のプランが適用となります。

【海外でのデータ通信について】

- ・海外でのデータ通信は、uCloudlink Japan株式会社のCloudSIMサービスと、同社が契約する海外モバイル通信事業者のモバイル通信網を利用して提供します。そのため、海外でPocket WiFi® 海外データ定額を利用できるエリアは、当該モバイル通信事業者のエリアに限られます。海外での本サービスの通信品質は、当該モバイル通信事業者が定めるところによります。
- ・海外での現地の事情によりエリア内であってもご利用いただけない場合があります。渡航・滞在を予定している方は、各国の規制等をあらかじめご確認ください。
- ・Pocket WiFi® 海外データ定額に加入している間は、国際ローミングをご利用できません。

[トップへ戻る](https://www.ymobile.jp/plan/data/pocketwifi_global/#top)

- [![社会課題に、アンサーを。](https://www.ymobile.jp/common_c/images/bnr/bnr_corp_special_answer.png?20251024)](https://www.softbank.jp/corp/special/answer/)
- [![SoftBank⇒サステナビリティ](https://www.ymobile.jp/common_c/images/bnr/bnr_esg_rating.png)](https://www.softbank.jp/corp/sustainability/)
- [![ワイモバイルの改善活動](https://www.ymobile.jp/common_c/images/bnr/bnr_kaizen_action.png)](https://www.softbank.jp/mobile/special/kaizen-action/?brand=ym&utm_source=yahoo&utm_medium=officialsite&utm_campaign=_mobile_cx_kaizen_20240905_018)

SEARCH

### ご契約を検討中のお客さま

- [新規ご契約](https://www.ymobile.jp/support/process/new_application/)
- [他社からのりかえ](https://www.ymobile.jp/support/process/portability/)
- [請求・お支払い](https://www.ymobile.jp/support/charge/)
- [エリアを確認したい](https://www.ymobile.jp/area/)
- [ショップを検索したい](https://www.ymobile.jp/shop/)
- [お得な情報が知りたい](https://www.ymobile.jp/cp/)

### 現在ご利用中のお客さま

- [My Y!mobileへログイン](https://www.ymobile.jp/support/online/login/)
- [困ったときは](https://www.ymobile.jp/support/trouble/)
- [オンライン手続きガイド](https://www.ymobile.jp/support/online/guide/)
- [製品サポート](https://www.ymobile.jp/support/product/)
- [機種変更](https://www.ymobile.jp/support/process/model_change/)
- [障害情報](https://www.ymobile.jp/info/failure/)
- [工事情報](https://www.ymobile.jp/info/maintenance/)

### 企業情報を知りたいお客さま

- [企業情報](https://www.softbank.jp/corp/aboutus/)
- [プレスリリース](https://www.softbank.jp/corp/news/press/sbkk/)
- [公開情報](https://www.softbank.jp/corp/aboutus/public/)
- [電子公告](https://www.softbank.jp/corp/ir/e_publicnotice/)
- [サステナビリティ](https://www.softbank.jp/corp/sustainability/)
- [採用情報](https://www.softbank.jp/corp/careers/)

### おすすめ情報

- [キャンペーン・おすすめ情報](https://www.ymobile.jp/cp/)
- [カタログ・パンフレット・ガイド](https://www.ymobile.jp/sp/p_guide/)
- [徹底解説！スマホとSIMのギモン](https://www.ymobile.jp/sp/guide/)

[よくあるご質問](https://www.ymobile.jp/support/faq/) [お問い合わせ](https://www.ymobile.jp/support/contact/)

SEARCH

- [当サイトについて](https://www.ymobile.jp/copyright/)
- [商標について](https://www.softbank.jp/corp/aboutus/governance/intellectual-property/trademark/)
- [約款・重要説明事項](https://www.ymobile.jp/corporate/open/agreement/)
- [個人情報について](https://www.softbank.jp/corp/privacy/)
- [情報セキュリティポリシー](https://www.softbank.jp/corp/security/)
- [プライバシーセンター](https://www.softbank.jp/privacy/)
- [企業情報](https://www.softbank.jp/corp/aboutus/)

© SoftBank Corp. All rights reserved.電気通信事業登録番号：第72号

閉じる

SEARCH

- [AIチャットで検索する](https://ymkarakuri.karakuri-gen.com/ymobile1/embed) [AIチャットで検索する](https://ymkarakuri.karakuri-gen.com/ymobile1/embed)
- [お申し込み](https://www.ymobile.jp/select_contract/)
- [My Y!mobile](https://www.ymobile.jp/support/online/login/)
- [法人のお客さま](https://www.ymobile.jp/biz/)

- [料金](https://www.ymobile.jp/plan/)
- [製品](https://www.ymobile.jp/lineup/)
- [SIM/eSIM](https://www.ymobile.jp/store/sp/sim/)
- [サービス](https://www.ymobile.jp/service/)
- [会員クーポン](https://www.ymobile.jp/service/ymobile/premium/#coupon-link)
- [SIMタイプ変更](https://www.ymobile.jp/sp/sim_kihen/)
- _サポート_






- [My Y!mobileご利用ガイド](https://www.ymobile.jp/support/online/)
- [オンラインストアご利用ガイド](https://www.ymobile.jp/store/to_beginner/)
- [ご契約者さま向けオンライン手続きガイド](https://www.ymobile.jp/support/online/guide/)
- [製品サポート](https://www.ymobile.jp/support/product/)
- [お申込後の初期設定ガイド](https://www.ymobile.jp/yservice/howto/)
- [請求・お支払い](https://www.ymobile.jp/support/charge/)
- [その他サポート](https://www.ymobile.jp/support/)
- [よくあるご質問](https://www.ymobile.jp/support/faq/)
- [お問い合わせ](https://www.ymobile.jp/support/contact/)

- [キャンペーン](https://www.ymobile.jp/cp/)
- _ショップ_






- [ショップを探す](https://www.ymobile.jp/shop/)
- [かんたん来店予約](https://www.ymobile.jp/shop/reservation/about/)
- [マイワイモバイルショップ](https://www.ymobile.jp/shop/myshop/)

![オンラインでお手続き！](https://www.ymobile.jp/common_c/images/common/txt-online.png)

[![オンライン手続きガイド](https://www.ymobile.jp/common_c/images/bnr/bnr_onlineguide2.png)](https://www.ymobile.jp/support/online/guide/)[![オンラインストア](https://www.ymobile.jp/common_c/images/bnr/bnr_store.png)](https://www.ymobile.jp/store/)

- [オンラインストア](https://www.ymobile.jp/store/)
- [エリア](https://www.ymobile.jp/area/)
- [法人の方](https://www.ymobile.jp/biz/)

- [![](https://www.ymobile.jp/common_c/images/bnr/bnr_ymotoku.png)](https://www.ymobile.jp/sp/ymobile-otoku/)

- [料金](https://www.ymobile.jp/plan/)
- [製品](https://www.ymobile.jp/lineup/)
- [SIM/eSIM](https://www.ymobile.jp/store/sp/sim/)
- [サービス](https://www.ymobile.jp/service/)
- [会員クーポン](https://www.ymobile.jp/service/ymobile/premium/#coupon-link)

![](https://www.ymobile.jp/store/common/cart_data/images/violet-new-service-page/intersect-sp.png)![](https://www.ymobile.jp/store/common/cart_data/images/violet-new-service-page/intersect-pc.png)![](https://www.ymobile.jp/store/common/cart_data/images/violet-new-service-page/futenyan_front.png)

# ご希望のお手続きを教えてください

## どちらで申し込みますか？

- 今の電話番号をそのまま使用する
- 新しい電話番号で申し込む

## 今ご利用中の携帯電話会社はどちらですか？

- ワイモバイル
- ワイモバイル以外

## ソフトバンクやLINEMOからののりかえですか？

- はい
- いいえ

## 端末もあわせて申し込みますか？

- はい
- いいえ（SIMのみ申し込む）

ワイモバイルの商品を見る