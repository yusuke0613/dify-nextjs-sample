---
url: "https://www.ymobile.jp/plan/commission/"
title: "各種手数料｜料金｜Y!mobile - 格安SIM・スマホはワイモバイルで"
---

[![BLACK FRIDAY セール オンラインストア限定 12/1（月）14:59まで](https://www.ymobile.jp/common_c/images/index/head_promotion.png?20251120)![BLACK FRIDAY セール オンラインストア限定 12/1（月）14:59まで](https://www.ymobile.jp/common_c/images/index/head_promotion_sp.png?20251120)](https://www.ymobile.jp/lineup/?ref=topticker)

[Y!mobile](https://www.ymobile.jp/)

- [料金](https://www.ymobile.jp/plan/)
- [製品](https://www.ymobile.jp/lineup/)
- [SIM/eSIM](https://www.ymobile.jp/store/sp/sim/)
- [サービス](https://www.ymobile.jp/service/)
- [会員クーポン](https://www.ymobile.jp/service/ymobile/premium/#coupon-link)

- [お申し込み](https://www.ymobile.jp/select_contract/)
- [ログイン](https://www.ymobile.jp/support/online/login/)
- [法人ご契約](https://www.ymobile.jp/biz/)
- メニュー

- [![](https://www.ymobile.jp/common_c/images/common/icon/icon_home.svg)ホーム](https://www.ymobile.jp/)
- [料金](https://www.ymobile.jp/plan/)
- 各種手数料

# 各種手数料

2025年8月20日改定

| 手続き内容 | 店頭※1 | ウェブ |
| --- | --- | --- |
| 新規契約 | 4,950円 | 3,850円 |
| 機種変更 | 4,950円 | 3,850円<br>“LINEMO”は<br>受け付け対象外 |
| SIM<br>再発行 | USIM | 4,950円 | 3,850円<br>→当面無料※2<br>“ソフトバンク”は<br>受け付け対象外 |
| eSIM | 4,950円 | 3,850円<br>→当面無料※2 |
| 譲渡 | 4,950円 | 3,850円<br>“LINEMO”<br>のみ受け付け |
| 電話番号変更 | 4,950円 | 3,850円 |
| ブランド間の<br>のりかえ※3 | 4,950円 | 3,850円 |

\[注\]

- ※1 法人向けの訪問販売も含みます。
- ※2 ウェブでのSIM再発行に関する手続きは当面無料です。有料化の準備が整い次第、別途ウェブサイトなどでお知らせします。
- ※3 LINEモバイルからのブランド間ののりかえも対象です。また、下記の各種キャンペーンは、2025年8月19日に終了します。

「 [ワイモバイル→ソフトバンクのりかえ特典A](https://www.softbank.jp/mobile/campaigns/list/ymobile-softbank-norikae/)」、「 [事務手数料0円特典（ソフトバンク）](https://www.softbank.jp/mobile/campaigns/list/lm-sb-tesuryomuryo/)」、「 [事務手数料0円特典（LINEモバイル→ソフトバンク）](https://www.softbank.jp/mobile/campaigns/list/line-sb-tesuryomuryo/)」、「 [ソフトバンク→ワイモバイルのりかえ特典](https://www.ymobile.jp/cp/sb-ym/)」、「 [事務手数料0円特典（ワイモバイル）](https://www.ymobile.jp/cp/tesuryo-ym/)」、「 [事務手数料0円特典（LINEモバイル→ワイモバイル）](https://www.ymobile.jp/cp/ly_tesuryomuryo/)」

##### 特典

PayPayカードをご利用のお客さまを対象に、下記の特典の提供を、2025年8月20日に開始します※4。なお、両方の特典の条件を同時に満たした場合、二つの特典が適用されます。特典適用時の実質金額は、下表をご覧ください。

| 特典① | 特典内容 | 1,100円相当のPayPayポイント※5を付与 |
| 付与条件 | - 対象の手続きを行うこと<br>- “ソフトバンク”と“ワイモバイル”において、対象の手続きを行った日が属する請求月の翌請求締め日に「PayPayカード割」※6が適用されている場合<br>- “LINEMO”において、対象の手続きを行った日が属する請求月の翌月15日までに利用料金の支払い方法を「PayPayカード」もしくは「PayPayカード ゴールド」（年会費1万1,000円）に設定し月末まで支払い方法を変更しない場合 |
| 特典② | 特典内容<br>（ブランド間の<br>のりかえ） | - 店頭での手続き：3,850円相当のPayPayポイント※5を付与<br>- ウェブでの手続き：2,750円相当のPayPayポイント※5を付与 |
| 付与条件 | - ブランド間ののりかえ完了日の属する請求月の翌請求締め日に「PayPayカード割」※6が適用され、「ペイトク50」もしくは「ペイトク無制限」に加入していること |

\[注\]

- ※4 法人契約のお客さまおよびウェブでのSIM再発行は特典の対象外です。特典の終了時期は未定です。
- ※5 PayPayポイントは、PayPay／PayPayカード公式ストアでも利用可能です。出金や譲渡はできません。詳細は [こちら](https://paypay.ne.jp/help/c0048/) をご覧ください。
- ※6 “ソフトバンク”と“ワイモバイル”の場合、「PayPayカード割」の対象プランに加入し、利用料金の支払い方法を「PayPayカード」もしくは「PayPayカード ゴールド」（年会費1万1,000円）に設定した方が対象です。詳細は [こちら](https://www.softbank.jp/mobile/set/common/pdf/legal/spguide/price_plan/paypay-card.pdf) をご覧ください。

##### 特典適用時の各種手数料および実質金額

特典適用時の各種手数料の実質金額（事務手数料から上記の特典のPayPayポイント相当額を差し引いた金額）は、かっこ内の金額になります。

| 手続き内容 | 店頭※1 | ウェブ |
| --- | --- | --- |
| 新規契約 | 4,950円<br>（3,850円） | 3,850円<br>（2,750円） |
| 機種変更 | 4,950円<br>（3,850円） | 3,850円<br>（2,750円）<br>“LINEMO”は<br>受け付け対象外 |
| SIM<br>再発行 | USIM | 4,950円<br>（3,850円） | 3,850円<br>→当面無料※2<br>“ソフトバンク”は<br>受け付け対象外 |
| eSIM | 4,950円<br>（3,850円） | 3,850円<br>→当面無料※2 |
| 譲渡 | 4,950円<br>（3,850円） | 3,850円<br>（2,750円）<br>“LINEMO”<br>のみ受け付け |
| 電話番号変更 | 4,950円<br>（3,850円） | 3,850円<br>（2,750円） |
| ブランド間ののりかえ※3 | 「ペイトク無制限」<br>もしくは<br>「ペイトク50」 | 4,950円<br>（0円）※7 | 3,850円<br>（0円）※7 |
| 上記以外のプラン | 4,950円<br>（3,850円） | 3,850円<br>（2,750円） |

\[注\]

- ※7 特典①および②が適用された場合の実質金額です。

[トップへ戻る](https://www.ymobile.jp/plan/commission/#top)

- [![社会課題に、アンサーを。](https://www.ymobile.jp/common_c/images/bnr/bnr_corp_special_answer.png?20251024)](https://www.softbank.jp/corp/special/answer/)
- [![SoftBank⇒サステナビリティ](https://www.ymobile.jp/common_c/images/bnr/bnr_esg_rating.png)](https://www.softbank.jp/corp/sustainability/)
- [![ワイモバイルの改善活動](https://www.ymobile.jp/common_c/images/bnr/bnr_kaizen_action.png)](https://www.softbank.jp/mobile/special/kaizen-action/?brand=ym&utm_source=yahoo&utm_medium=officialsite&utm_campaign=_mobile_cx_kaizen_20240905_018)

SEARCH

### ご契約を検討中のお客さま

- [新規ご契約](https://www.ymobile.jp/support/process/new_application/)
- [他社からのりかえ](https://www.ymobile.jp/support/process/portability/)
- [請求・お支払い](https://www.ymobile.jp/support/charge/)
- [エリアを確認したい](https://www.ymobile.jp/area/)
- [ショップを検索したい](https://www.ymobile.jp/shop/)
- [お得な情報が知りたい](https://www.ymobile.jp/cp/)

### 現在ご利用中のお客さま

- [My Y!mobileへログイン](https://www.ymobile.jp/support/online/login/)
- [困ったときは](https://www.ymobile.jp/support/trouble/)
- [オンライン手続きガイド](https://www.ymobile.jp/support/online/guide/)
- [製品サポート](https://www.ymobile.jp/support/product/)
- [機種変更](https://www.ymobile.jp/support/process/model_change/)
- [障害情報](https://www.ymobile.jp/info/failure/)
- [工事情報](https://www.ymobile.jp/info/maintenance/)

### 企業情報を知りたいお客さま

- [企業情報](https://www.softbank.jp/corp/aboutus/)
- [プレスリリース](https://www.softbank.jp/corp/news/press/sbkk/)
- [公開情報](https://www.softbank.jp/corp/aboutus/public/)
- [電子公告](https://www.softbank.jp/corp/ir/e_publicnotice/)
- [サステナビリティ](https://www.softbank.jp/corp/sustainability/)
- [採用情報](https://www.softbank.jp/corp/careers/)

### おすすめ情報

- [キャンペーン・おすすめ情報](https://www.ymobile.jp/cp/)
- [カタログ・パンフレット・ガイド](https://www.ymobile.jp/sp/p_guide/)
- [徹底解説！スマホとSIMのギモン](https://www.ymobile.jp/sp/guide/)

[よくあるご質問](https://www.ymobile.jp/support/faq/) [お問い合わせ](https://www.ymobile.jp/support/contact/)

SEARCH

- [当サイトについて](https://www.ymobile.jp/copyright/)
- [商標について](https://www.softbank.jp/corp/aboutus/governance/intellectual-property/trademark/)
- [約款・重要説明事項](https://www.ymobile.jp/corporate/open/agreement/)
- [個人情報について](https://www.softbank.jp/corp/privacy/)
- [情報セキュリティポリシー](https://www.softbank.jp/corp/security/)
- [プライバシーセンター](https://www.softbank.jp/privacy/)
- [企業情報](https://www.softbank.jp/corp/aboutus/)

© SoftBank Corp. All rights reserved.電気通信事業登録番号：第72号

閉じる

SEARCH

- [AIチャットで検索する](https://ymkarakuri.karakuri-gen.com/ymobile1/embed) [AIチャットで検索する](https://ymkarakuri.karakuri-gen.com/ymobile1/embed)
- [お申し込み](https://www.ymobile.jp/select_contract/)
- [My Y!mobile](https://www.ymobile.jp/support/online/login/)
- [法人のお客さま](https://www.ymobile.jp/biz/)

- [料金](https://www.ymobile.jp/plan/)
- [製品](https://www.ymobile.jp/lineup/)
- [SIM/eSIM](https://www.ymobile.jp/store/sp/sim/)
- [サービス](https://www.ymobile.jp/service/)
- [会員クーポン](https://www.ymobile.jp/service/ymobile/premium/#coupon-link)
- [SIMタイプ変更](https://www.ymobile.jp/sp/sim_kihen/)
- _サポート_






- [My Y!mobileご利用ガイド](https://www.ymobile.jp/support/online/)
- [オンラインストアご利用ガイド](https://www.ymobile.jp/store/to_beginner/)
- [ご契約者さま向けオンライン手続きガイド](https://www.ymobile.jp/support/online/guide/)
- [製品サポート](https://www.ymobile.jp/support/product/)
- [お申込後の初期設定ガイド](https://www.ymobile.jp/yservice/howto/)
- [請求・お支払い](https://www.ymobile.jp/support/charge/)
- [その他サポート](https://www.ymobile.jp/support/)
- [よくあるご質問](https://www.ymobile.jp/support/faq/)
- [お問い合わせ](https://www.ymobile.jp/support/contact/)

- [キャンペーン](https://www.ymobile.jp/cp/)
- _ショップ_






- [ショップを探す](https://www.ymobile.jp/shop/)
- [かんたん来店予約](https://www.ymobile.jp/shop/reservation/about/)
- [マイワイモバイルショップ](https://www.ymobile.jp/shop/myshop/)

![オンラインでお手続き！](https://www.ymobile.jp/common_c/images/common/txt-online.png)

[![オンライン手続きガイド](https://www.ymobile.jp/common_c/images/bnr/bnr_onlineguide2.png)](https://www.ymobile.jp/support/online/guide/)[![オンラインストア](https://www.ymobile.jp/common_c/images/bnr/bnr_store.png)](https://www.ymobile.jp/store/)

- [オンラインストア](https://www.ymobile.jp/store/)
- [エリア](https://www.ymobile.jp/area/)
- [法人の方](https://www.ymobile.jp/biz/)

- [![](https://www.ymobile.jp/common_c/images/bnr/bnr_ymotoku.png)](https://www.ymobile.jp/sp/ymobile-otoku/)

- [料金](https://www.ymobile.jp/plan/)
- [製品](https://www.ymobile.jp/lineup/)
- [SIM/eSIM](https://www.ymobile.jp/store/sp/sim/)
- [サービス](https://www.ymobile.jp/service/)
- [会員クーポン](https://www.ymobile.jp/service/ymobile/premium/#coupon-link)

![](https://www.ymobile.jp/store/common/cart_data/images/violet-new-service-page/intersect-sp.png)![](https://www.ymobile.jp/store/common/cart_data/images/violet-new-service-page/intersect-pc.png)![](https://www.ymobile.jp/store/common/cart_data/images/violet-new-service-page/futenyan_front.png)

# ご希望のお手続きを教えてください

## どちらで申し込みますか？

- 今の電話番号をそのまま使用する
- 新しい電話番号で申し込む

## 今ご利用中の携帯電話会社はどちらですか？

- ワイモバイル
- ワイモバイル以外

## ソフトバンクやLINEMOからののりかえですか？

- はい
- いいえ

## 端末もあわせて申し込みますか？

- はい
- いいえ（SIMのみ申し込む）

ワイモバイルの商品を見る