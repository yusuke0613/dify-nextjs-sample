---
url: "https://www.ymobile.jp/plan/discount/kazokuwari/"
title: "家族割引サービス｜割引サービス｜料金｜Y!mobile - 格安SIM・スマホはワイモバイルで"
---

[![BLACK FRIDAY セール オンラインストア限定 12/1（月）14:59まで](https://www.ymobile.jp/common_c/images/index/head_promotion.png?20251120)![BLACK FRIDAY セール オンラインストア限定 12/1（月）14:59まで](https://www.ymobile.jp/common_c/images/index/head_promotion_sp.png?20251120)](https://www.ymobile.jp/lineup/?ref=topticker)

[Y!mobile](https://www.ymobile.jp/)

- [料金](https://www.ymobile.jp/plan/)
- [製品](https://www.ymobile.jp/lineup/)
- [SIM/eSIM](https://www.ymobile.jp/store/sp/sim/)
- [サービス](https://www.ymobile.jp/service/)
- [会員クーポン](https://www.ymobile.jp/service/ymobile/premium/#coupon-link)

- [お申し込み](https://www.ymobile.jp/select_contract/)
- [ログイン](https://www.ymobile.jp/support/online/login/)
- [法人ご契約](https://www.ymobile.jp/biz/)
- メニュー

- [![](https://www.ymobile.jp/common_c/images/common/icon/icon_home.svg)ホーム](https://www.ymobile.jp/)
- [料金](https://www.ymobile.jp/plan/)
- [割引サービス](https://www.ymobile.jp/plan/discount/)
- 家族割引サービス

# 家族割引サービス

2025年9月25日のシンプル3提供開始に伴い、2025年9月25日分より対象料金プランを拡大します。

[“ワイモバイル”の新料金プラン「シンプル3」を提供開始](https://www.softbank.jp/corp/news/press/sbkk/2025/20250904_01/)

![](https://www.ymobile.jp/plan/discount/kazokuwari/images/kazokuwari.png?20250925)

![](https://www.ymobile.jp/common_c/images/bnr/bnr_familydiscount.png?20250925)

表示価格は特に記載がない限り税込です。

消費税の計算上、請求金額と異なる場合があります。

## 概要

ご家族などで利用される複数の回線を、指定料金プランにて契約いただくと、2回線目以降の各基本使用料が毎月550円または1,100円、1,188円の割引になります。（最大9回線まで割引が適用）

お一人さまで複数回線を契約いただく場合でも適用になります。

![](https://www.ymobile.jp/plan/discount/kazokuwari/images/planimage.png?20250925)

- ※現在お申し込みが可能な対象料金プランです。（ケータイベーシックプランSS、データベーシックプランSは対象外となります。）

受付終了済みの対象料金プランなど、詳細は [提供条件書](https://www.ymobile.jp/corporate/open/agreement/pdf/kazokuwari.pdf) をご確認ください。

## 家族割引サービスの“家族”とは？

ご家族（血縁・婚姻）、もしくは同住所であることが確認できること。

お手続きには家族確認書類が必要となります。

- 血縁・婚姻
  - 同居しているご家族
  - 離れて暮らすご家族

    親族関係を示す親等についての条件はありません。
- 同住所
  - 同一の住所であることが確認できるご契約者さま（別姓可）

## お申込みに必要な書類

- 1\. 家族確認書類

家族確認書類とは、ご契約者様とのご関係を証明する書類です。

同姓または同住所であることを確認できるもの、または1枚でご契約者さまとのご関係を証明できるものが該当します。

以下のいずれかをご持参ください。

- ●同姓または同住所であることを確認できる、それぞれの本人確認書類
- ●ご契約者さまとのご関係を証明できるもの

（ご契約者さまと代理人さまの両方の氏名が記載されている「住民票記載事項証明書」「健康保険証」「遠隔地保険証」「住民票」「戸籍謄 （抄）本」など。ただし、「住民票記載事項証明書」 「住民票」「戸籍謄（抄）本」は発行日から3ヵ月以内のものに限ります。）
- ●同性とのパートナーシップを証明する書類

- 2\. [家族割引サービス同意書](https://www.ymobile.jp/corporate/open/agreement/pdf/kazokuwari_doui.pdf)

[家族確認書類に関する詳細はこちら](https://www.ymobile.jp/support/faq/view/21442)

## お申し込みについて

My Y!mobile※1、全国のワイモバイルショップ・取扱店、オンラインストア※2にてお申込みください。

[My Y!mobileからお申し込み](https://my.ymobile.jp/muc/d/webLink/doSend/MWBWL0205) [オンラインストア](https://www.ymobile.jp/store/)

[ショップ・取扱店](https://www.ymobile.jp/shop/)

- ※1 My Y!mobileからお申し込みの場合、SMSを受信できない機種(Pocket WiFi®、タブレット)ではお申し込みできません。
- ※2 オンラインストアでは、新しく契約する回線を副回線とする場合のみお申し込み可能です。

- ※ PayPayミニアプリからはご契約と同時の申込みが不可となるため、ご契約後にMy Y!mobileからお申し込みください。

## ご注意事項

- ●1回線目（主回線）ならびに2回線目以降（副回線）は、ご契約お申し込み時にお客さまよりご指定いただきます。なお副回線は、主回線を除き最大9回線までご指定いただけます。
- ●法人のお客さまは対象外となります。
- ●以下の場合、当社指定プランによる提供は終了となり、翌料金月より2回線目以降（副回線）の料金プラン月額基本使用料・ユニバーサルサービス料が発生いたします。

（副回線を料金プラン変更した場合の月額基本使用料は変更日以降、発生いたします。）


- 【1】1回線目（主回線）のワイモバイル通信サービス契約が解約となった場合。
- 【2】1回線目（主回線）もしくは2回線目以降（副回線）を当社指定プラン以外の料金プランに変更された場合。

- ●おうち割 光セット（A）・おうち割 光セット（A）申込特典など、重複して割引を適用できないサービスがあります。

詳細は提供条件書をご確認ください。

[家族割引サービス提供条件書](https://www.ymobile.jp/corporate/open/agreement/pdf/kazokuwari.pdf)

## よくあるご質問

[トップへ戻る](https://www.ymobile.jp/plan/discount/kazokuwari/#top)

- [![社会課題に、アンサーを。](https://www.ymobile.jp/common_c/images/bnr/bnr_corp_special_answer.png?20251024)](https://www.softbank.jp/corp/special/answer/)
- [![SoftBank⇒サステナビリティ](https://www.ymobile.jp/common_c/images/bnr/bnr_esg_rating.png)](https://www.softbank.jp/corp/sustainability/)
- [![ワイモバイルの改善活動](https://www.ymobile.jp/common_c/images/bnr/bnr_kaizen_action.png)](https://www.softbank.jp/mobile/special/kaizen-action/?brand=ym&utm_source=yahoo&utm_medium=officialsite&utm_campaign=_mobile_cx_kaizen_20240905_018)

SEARCH

### ご契約を検討中のお客さま

- [新規ご契約](https://www.ymobile.jp/support/process/new_application/)
- [他社からのりかえ](https://www.ymobile.jp/support/process/portability/)
- [請求・お支払い](https://www.ymobile.jp/support/charge/)
- [エリアを確認したい](https://www.ymobile.jp/area/)
- [ショップを検索したい](https://www.ymobile.jp/shop/)
- [お得な情報が知りたい](https://www.ymobile.jp/cp/)

### 現在ご利用中のお客さま

- [My Y!mobileへログイン](https://www.ymobile.jp/support/online/login/)
- [困ったときは](https://www.ymobile.jp/support/trouble/)
- [オンライン手続きガイド](https://www.ymobile.jp/support/online/guide/)
- [製品サポート](https://www.ymobile.jp/support/product/)
- [機種変更](https://www.ymobile.jp/support/process/model_change/)
- [障害情報](https://www.ymobile.jp/info/failure/)
- [工事情報](https://www.ymobile.jp/info/maintenance/)

### 企業情報を知りたいお客さま

- [企業情報](https://www.softbank.jp/corp/aboutus/)
- [プレスリリース](https://www.softbank.jp/corp/news/press/sbkk/)
- [公開情報](https://www.softbank.jp/corp/aboutus/public/)
- [電子公告](https://www.softbank.jp/corp/ir/e_publicnotice/)
- [サステナビリティ](https://www.softbank.jp/corp/sustainability/)
- [採用情報](https://www.softbank.jp/corp/careers/)

### おすすめ情報

- [キャンペーン・おすすめ情報](https://www.ymobile.jp/cp/)
- [カタログ・パンフレット・ガイド](https://www.ymobile.jp/sp/p_guide/)
- [徹底解説！スマホとSIMのギモン](https://www.ymobile.jp/sp/guide/)

[よくあるご質問](https://www.ymobile.jp/support/faq/) [お問い合わせ](https://www.ymobile.jp/support/contact/)

SEARCH

- [当サイトについて](https://www.ymobile.jp/copyright/)
- [商標について](https://www.softbank.jp/corp/aboutus/governance/intellectual-property/trademark/)
- [約款・重要説明事項](https://www.ymobile.jp/corporate/open/agreement/)
- [個人情報について](https://www.softbank.jp/corp/privacy/)
- [情報セキュリティポリシー](https://www.softbank.jp/corp/security/)
- [プライバシーセンター](https://www.softbank.jp/privacy/)
- [企業情報](https://www.softbank.jp/corp/aboutus/)

© SoftBank Corp. All rights reserved.電気通信事業登録番号：第72号

閉じる

SEARCH

- [AIチャットで検索する](https://ymkarakuri.karakuri-gen.com/ymobile1/embed) [AIチャットで検索する](https://ymkarakuri.karakuri-gen.com/ymobile1/embed)
- [お申し込み](https://www.ymobile.jp/select_contract/)
- [My Y!mobile](https://www.ymobile.jp/support/online/login/)
- [法人のお客さま](https://www.ymobile.jp/biz/)

- [料金](https://www.ymobile.jp/plan/)
- [製品](https://www.ymobile.jp/lineup/)
- [SIM/eSIM](https://www.ymobile.jp/store/sp/sim/)
- [サービス](https://www.ymobile.jp/service/)
- [会員クーポン](https://www.ymobile.jp/service/ymobile/premium/#coupon-link)
- [SIMタイプ変更](https://www.ymobile.jp/sp/sim_kihen/)
- _サポート_






- [My Y!mobileご利用ガイド](https://www.ymobile.jp/support/online/)
- [オンラインストアご利用ガイド](https://www.ymobile.jp/store/to_beginner/)
- [ご契約者さま向けオンライン手続きガイド](https://www.ymobile.jp/support/online/guide/)
- [製品サポート](https://www.ymobile.jp/support/product/)
- [お申込後の初期設定ガイド](https://www.ymobile.jp/yservice/howto/)
- [請求・お支払い](https://www.ymobile.jp/support/charge/)
- [その他サポート](https://www.ymobile.jp/support/)
- [よくあるご質問](https://www.ymobile.jp/support/faq/)
- [お問い合わせ](https://www.ymobile.jp/support/contact/)

- [キャンペーン](https://www.ymobile.jp/cp/)
- _ショップ_






- [ショップを探す](https://www.ymobile.jp/shop/)
- [かんたん来店予約](https://www.ymobile.jp/shop/reservation/about/)
- [マイワイモバイルショップ](https://www.ymobile.jp/shop/myshop/)

![オンラインでお手続き！](https://www.ymobile.jp/common_c/images/common/txt-online.png)

[![オンライン手続きガイド](https://www.ymobile.jp/common_c/images/bnr/bnr_onlineguide2.png)](https://www.ymobile.jp/support/online/guide/)[![オンラインストア](https://www.ymobile.jp/common_c/images/bnr/bnr_store.png)](https://www.ymobile.jp/store/)

- [オンラインストア](https://www.ymobile.jp/store/)
- [エリア](https://www.ymobile.jp/area/)
- [法人の方](https://www.ymobile.jp/biz/)

- [![](https://www.ymobile.jp/common_c/images/bnr/bnr_ymotoku.png)](https://www.ymobile.jp/sp/ymobile-otoku/)

- [料金](https://www.ymobile.jp/plan/)
- [製品](https://www.ymobile.jp/lineup/)
- [SIM/eSIM](https://www.ymobile.jp/store/sp/sim/)
- [サービス](https://www.ymobile.jp/service/)
- [会員クーポン](https://www.ymobile.jp/service/ymobile/premium/#coupon-link)

![](https://www.ymobile.jp/store/common/cart_data/images/violet-new-service-page/intersect-sp.png)![](https://www.ymobile.jp/store/common/cart_data/images/violet-new-service-page/intersect-pc.png)![](https://www.ymobile.jp/store/common/cart_data/images/violet-new-service-page/futenyan_front.png)

# ご希望のお手続きを教えてください

## どちらで申し込みますか？

- 今の電話番号をそのまま使用する
- 新しい電話番号で申し込む

## 今ご利用中の携帯電話会社はどちらですか？

- ワイモバイル
- ワイモバイル以外

## ソフトバンクやLINEMOからののりかえですか？

- はい
- いいえ

## 端末もあわせて申し込みますか？

- はい
- いいえ（SIMのみ申し込む）

ワイモバイルの商品を見る


画面を閉じてお手続きを進める

※ボタンをタップしても閉じられない場合は、

ブラウザの「×」で閉じてください。