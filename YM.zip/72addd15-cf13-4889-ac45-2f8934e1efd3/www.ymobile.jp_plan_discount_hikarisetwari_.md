---
url: "https://www.ymobile.jp/plan/discount/hikarisetwari/"
title: "おうち割 光セット（A）｜割引サービス｜料金｜Y!mobile - 格安SIM・スマホはワイモバイルで"
---

[![BLACK FRIDAY セール オンラインストア限定 12/1（月）14:59まで](https://www.ymobile.jp/common_c/images/index/head_promotion.png?20251120)![BLACK FRIDAY セール オンラインストア限定 12/1（月）14:59まで](https://www.ymobile.jp/common_c/images/index/head_promotion_sp.png?20251120)](https://www.ymobile.jp/lineup/?ref=ols_ticker)

[Y!mobile](https://www.ymobile.jp/)

# ![おうち割 光セット（A）](https://www.ymobile.jp/plan/discount/hikarisetwari/images/title_pc.jpg)![おうち割 光セット（A）](https://www.ymobile.jp/plan/discount/hikarisetwari/images/title_sp.jpg)

※表示価格は特に記載がない限り税込です。

消費税の計算上、請求金額と異なる場合があります。

## ![おうちのネットとワイモバイルをセットで利用するだけ！ワイモバイルの月々のご利用料金が毎月ずーーっと割引になります。](https://www.ymobile.jp/plan/discount/hikarisetwari/images/lead.png?20220701)![おうちのネットとワイモバイルをセットで利用するだけ！ワイモバイルの月々のご利用料金が毎月ずーーっと割引になります。](https://www.ymobile.jp/plan/discount/hikarisetwari/images/lead_sp.png?20220701)

![ひとりあたり 毎月最大1,650円引き](https://www.ymobile.jp/plan/discount/hikarisetwari/images/otoku.png?20250918)![ひとりあたり 毎月最大1,650円引き](https://www.ymobile.jp/plan/discount/hikarisetwari/images/otoku_sp.png?20250918)

- ※1【加入例】SoftBank 光 ファミリーの場合、月額基本料金5,720円／月＋指定オプション550円／月～が別途必要です（2年自動更新プラン：2022年7月1日以降の契約者は、契約期間満了月の当月・翌月・翌々月以外での解約には解除料5,720円が必要。詳しくは [こちら](https://u.softbank.jp/3KFwQRZ)）。
- ※ シンプル2 M/Lは毎月1,650円割引、シンプル2 Sは毎月1,100円割引、シンプルS/M/Lは毎月1,188円割引、スマホベーシックプランS/M/R/L、データベーシックプランL、Pocket WiFi®プラン2（ベーシック）、スマホプランS、データプランL、Pocket WiFi®プラン2は毎月550円割引、スマホプランM/Rは毎月770円割引、スマホプランLは毎月1,100円割引します。
- ※ モバイル通信サービスの対象料金プラン基本使用料を割引します。
- ※ 家族割引サービスなど、一部重複して割引を適用できないサービスがあります。詳しくは [こちら](https://www.ymobile.jp/corporate/open/agreement/pdf/hikarisetwari.pdf) をご確認ください。

おうち割 光セット（A）申込特典

SoftBank Air / SoftBank 光 開通前でも、

おうち割 光セット（A）お申し込み日の翌月から

割引が適用になります。（最大5ヵ月間）

- ※ お申し込みから5ヵ月以内に開通されなかった場合は

特典の適用は終了いたします。

[提供条件書](https://www.ymobile.jp/corporate/open/agreement/pdf/hikarisetwari2.pdf)

## ソフトバンクの  選べるインターネット

[![工事がいらないおうちのWi-Fi SoftBank Air](https://www.ymobile.jp/plan/discount/hikarisetwari/images/btn_air.png)](https://www.ymobile.jp/plan/discount/hikarisetwari/#section-air)

[![超高速・安定の光回線 SoftBank 光](https://www.ymobile.jp/plan/discount/hikarisetwari/images/btn_hikari.png)](https://www.ymobile.jp/plan/discount/hikarisetwari/#section-hikari)

### SoftBank Air

工事不要で管理会社や

大家さんへの確認も不要！

賃貸にお住まいの方、

一人暮らしの方におすすめ！


![](https://www.ymobile.jp/plan/discount/hikarisetwari/images/air_01.png)

* * *

### 毎月のお支払い目安

![](https://www.ymobile.jp/plan/discount/hikarisetwari/images/air_02.png?20221007)

![](https://www.ymobile.jp/plan/discount/hikarisetwari/images/air_plan_pc.png?20250123)![](https://www.ymobile.jp/plan/discount/hikarisetwari/images/air_plan_sp.png?20250123)

- ※1 4ヵ月目以降の月々のご利用料金は「Airターミナル6 最大にねんサポートキャンペーン」適用で割引後基本料金4,950円です。25ヵ月目以降は5,368円です。
- ※2 月月割は課金開始月を1ヵ月目として2ヵ月目～49ヵ月目まで1,485円/月を月額基本料金より割引します。 Airターミナル機器代金は割引されません。また、SoftBank Airを解約された場合は割引が終了となります。

併用されるキャンペーンの割引総額が月額基本料金を上回る場合、月額基本料金の金額が割引上限となります。

2ヵ月目および3ヵ月目は、月月割および「SoftBank Air めちゃトク割」など、併用可能キャンペーンの割引総額が月額基本料金を上回るため月月割を46回として計算しています。
- ・対象サービスの請求額が割引額を下回る場合、同請求額が割引の上限となります。この場合でも、翌月以降に繰り越して割引を適用することはできません。
- ・端末代金71,280円は当社直営店販売価格です。
- ・レンタルなどは対象外です。
- ・「SoftBank Air めちゃトク割」の [詳細をみる](https://www.softbank.jp/internet/campaigns/list/sbair-mechatoku/)
- ・「Airターミナル6 最大にねんサポートキャンペーン」の [詳細をみる](https://www.softbank.jp/internet/campaigns/list/air6-ninen-support/)

[![SoftBank Air Airターミナル6](https://www.ymobile.jp/plan/discount/hikarisetwari/images/bnr_sb_air6.png?20251118)![SoftBank Air Airターミナル6](https://www.ymobile.jp/plan/discount/hikarisetwari/images/bnr_sb_air6_sp.png?20251118)](https://www.softbank.jp/internet/campaigns/list/sbair-smartlife/)

- ・レンタルなどは対象外です。

[SoftBank Airを詳しくみる](https://www.softbank.jp/ybb/special/air/?utm_source=ymobile&utm_medium=banner&utm_campaign=fy20_air_ym&utm_content=5_1_1_00136)

### SoftBank 光

光回線を利用した超高速で安定な

インターネット接続サービスです。


![](https://www.ymobile.jp/plan/discount/hikarisetwari/images/hikari_01.png)

テレワークや

オンライン授業も安心

高速通信が必要な

オンラインゲームにも

* * *

### 毎月のお支払い目安

![softbank光 おうち割 光セット（A）](https://www.ymobile.jp/plan/discount/hikarisetwari/images/hikari_02_pc.png?20250926)![softbank光 おうち割 光セット（A）](https://www.ymobile.jp/plan/discount/hikarisetwari/images/hikari_02_sp.png?20250926)

- ※1 キャンペーン適用の場合。


・他社から乗り換えの方向けのキャンペーンは [こちら](https://www.softbank.jp/internet/campaigns/list/sbhikari-1g-mechatoku/)


・新たにSoftBank 光をお申込みの方向けのキャンペーンは [こちら](https://www.softbank.jp/internet/campaigns/list/sbhikari-1g-0yen/)
- ※2 おうち割 光セット（A）にお申し込みの場合、指定オプション550円／月へのご加入が必要です。7ヵ月目以降は集合住宅の場合は4,180円、戸建住宅の場合は5,720円にそれぞれ指定オプション550円／月を足した金額となります。
- ● 別途、 [契約事務手数料がかかります。](https://www.softbank.jp/internet/sbhikari/price/#anchor-initial-cost)
- ● SoftBank 光 2年自動更新プランの場合です。契約期間満了月の当月・翌月・翌々月以外で解約をされた場合、解約時の契約プラン・回線タイプに応じた割引前の月額料金相当額が必要です。契約成立日が2022年6月30日以前の場合、10,450円の解除料が必要です。詳しくは [こちら](https://u.softbank.jp/3KFwQRZ) をご確認ください。なお、ブロードバンドサービスと付随するオプションサービスを同月内に解約し解除料が重複して発生する場合は、11,000円を解除料の上限金額としてお支払いいただきます。
- ● 集合住宅用のプランでお申込みいただいても、お住まいの建物に集合住宅向けの光回線が提供ができない場合は戸建住宅用のプランをご提案させていただきます。
- ● ファミリー・10ギガ、マンション・10ギガは除きます。

* * *

### 回線工事費

0円～31,680円

回線工事費は、お申し込みの内容や派遣工事の有無によって異なります。

![](https://www.ymobile.jp/plan/discount/hikarisetwari/images/img_hikari_cost.png?20240401)

- ※1 SoftBank 光への事業者変更と同時に移転または回線タイプ変更を行う場合、工事が必要になります。ファミリー・10ギガの場合、NTT東西のフレッツ光／他社光コラボレーションサービスを現在ご利用中の方であっても、新規ご契約となり、立ち会い工事が必要です。

- ※2 現在ご自宅のネット利用がない場合、SoftBankモバイルデータ端末／Y!mobileモバイルデータ端末をご利用中の場合、「SoftBank 光 工事費サポート はじめて割」が適用となります。 [詳細をみる](https://www.softbank.jp/internet/campaigns/list/sbhikari-hajimetewari/)
- ※3 現在他社回線をご利用中の場合、「SoftBank 光 乗り換え新規で割引キャンペーン」が適用となります。NTTフレッツ光からSoftBank 光に転用されるお客さま、他社光コラボレーションサービスから対象サービスに事業者変更されるお客さまおよび当社が提携するケーブルライン取り扱いケーブルテレビ事業者のインターネット回線をご利用中のお客さまは対象外。 [詳細をみる](https://www.softbank.jp/internet/campaigns/list/sbhikari-norikae-07/)
- ※2 ※3 回線工事費31,680円の場合は、1,320円×24ヵ月間、回線工事費4,620円の場合は、1,155円×4ヵ月間の割引となります。回線工事費が発生しない場合は、キャンペーンの対象外です。

[SoftBank 光を詳しくみる](https://www.softbank.jp/ybb/special/sbhikari-01/?utm_source=ymobile&utm_medium=banner&utm_campaign=fy20_hikari_ym&utm_content=5_1_1_00137)

![更に快適！脅威的な速さ](https://www.ymobile.jp/plan/discount/hikarisetwari/images/comfortable_speed_ribbon_pc.png)![更に快適！脅威的な速さ](https://www.ymobile.jp/plan/discount/hikarisetwari/images/comfortable_speed_ribbon_sp.png)

[![](https://www.ymobile.jp/plan/discount/hikarisetwari/images/bnr_sbhikari_10g_pc.png)![](https://www.ymobile.jp/plan/discount/hikarisetwari/images/bnr_sbhikari_10g_sp.png)](https://www.softbank.jp/internet/campaigns/list/sbhikari-10g-0yen/)

- ※1「SoftBank 光・10ギガ めちゃトク割」と併用した場合
- ※2 最大10Gbpsは技術規格上の最大値です。利用環境、回線の混雑状況等により異なります。10ギガ提供エリアは限られます。お申込み前に以下ホームページにてエリアをご確認ください。

[「10ギガ提供エリアについて」](https://www.softbank.jp/internet/sbhikari/10g/#service-area)
- ・「SoftBank 光・10ギガ もっとめちゃトク割」については、SoftBank光からSoftBank光・10ギガへの変更は対象外です。
- ・SoftBank 光 自動更新なしプランは対象外です。
- ・「SoftBank 光・10ギガ めちゃトク割」の [詳細を見る](https://www.softbank.jp/internet/campaigns/list/sbhikari-10g-mechatoku/)

## 公式サイト限定！おトクなキャンペーン

[![【公式】SoftBank Air（ソフトバンクエアー）お申し込みサイト SoftBank Air ご契約特典 10,000円キャッシュバック](https://www.ymobile.jp/plan/discount/hikarisetwari/images/bnr_campaign_gentei.png?20251022)](https://www.softbank.jp/internet/special/air5/)

- ※ Airターミナル（専用接続機器）を分割もしくは一括で購入すること。
- ※ 機種変更・レンタルは対象外。

[SoftBank Air ご契約特典 1 万円キャッシュバックキャンペーン](https://www.softbank.jp/internet/set/data/terms/pdf/condition-tokuten-cp251015.pdf)

[![【公式】ソフトバンクにまとめておトク SoftBank Air さらにおトク！10,000円キャッシュバック](https://www.ymobile.jp/plan/discount/hikarisetwari/images/bnr_timesale_cp.webp?20251022)](https://www.softbank.jp/ybb/special/sbinternet/)

- ※ 「U-25／O-60 向け SoftBank Air スマートライフ割」との併用はできません
- ※ Airターミナル（専用接続機器）を分割もしくは一括で購入すること。
- ※ 機種変更・レンタルは対象外。

[SoftBank Air さらにおトク！1 万円キャッシュバックキャンペーン](https://www.softbank.jp/internet/set/data/terms/pdf/condition-otoku-cp251015.pdf)

* * *

## 実施中のキャンペーン

[![](https://www.ymobile.jp/plan/discount/hikarisetwari/images/bnr_kangen.png)](https://www.softbank.jp/ybb/campaigns/list/anshin-norikae01/)

- ※ キャッシュバックの対象は他社サービス解約時に発生する契約解除料金・撤去費用・ホームルーターおよびモバイルWi-Fiルーターにてインターネットに接続するために必要な接続機器（以下「端末」といいます）を購入した場合の残債です。
- ※ キャッシュバック金額は合計で最大10万円となります。ただし、モバイルWi-Fiルーター端末代金の残債に対するキャッシュバック金額は42,000円が上限です。
- ※ 当社が提携するケーブルライン取り扱いケーブルテレビ事業者のインターネット回線をご利用中のお客さまは対象外です。

[SoftBank あんしん乗り換えキャンペーン](https://www.softbank.jp/ybb/campaigns/list/anshin-norikae01/)

* * *

## おすすめオプションサービス

[![](https://www.ymobile.jp/plan/discount/hikarisetwari/images/bnr_mesh_wifi.png)](https://www.softbank.jp/internet/option/mesh-wifi/)

- ※ メッシュWi-Fiルーターの電波が届く範囲および実効速度は、周囲の電波状況や住宅の構造など利用環境により大きく異なります。

[メッシュWi-Fi](https://www.softbank.jp/internet/option/mesh-wifi/)

[![](https://www.ymobile.jp/plan/discount/hikarisetwari/images/bner_anshin_exchange_warranty.png)](https://www.softbank.jp/internet/option/anshin-exchange-warranty/)

[あんしん交換保証](https://www.softbank.jp/internet/option/anshin-exchange-warranty/)

## お申し込みの流れ

既にスマホ・タブレット・Pocket WiFi®をご利用のお客さま

新規・のりかえ（MNP）のお客さま

スマホ・タブレット・Pocket WiFi®のお申し込み

- [ショップ・取扱店](https://www.ymobile.jp/shop/)


「SoftBank Air」、「SoftBank 光」のお申し込み

- [ショップ・取扱店](https://www.ymobile.jp/shop/)

- [SoftBank Air オンラインお申し込み](http://www.softbank.jp/ybb/order/air-02/?cid=sair_150803_plan/discount/hikariotokuwari/index.html_029)

- [SoftBank 光 オンラインお申し込み](https://www.ymobile.jp/plan/discount/hikarisetwari/form/)


お電話での申込み

新規受付センター：

[0120-981-211](tel:0120-981-211)

（通話料無料）

受付時間 午前9時から午後10時

おうち割 光セット（A）のお申し込み

- [My Y!mobileからお申し込み](https://stn.mb.softbank.jp/y5L0k)

- [ワイモバイルショップでお申し込み](https://www.ymobile.jp/shop/)


- 固定通信サービス契約者本人以外からのお申し込みの場合、固定通信サービス契約者の同意書および契約者の家族であることを証明できる確認書類が必要となります。
  - 家族確認書類（詳細は [こちら](https://www.ymobile.jp/support/faq/view/21442) をご確認ください）
  - [おうち割 光セット専用同意書](https://www.ymobile.jp/plan/discount/hikarisetwari/pdf/doui.pdf)（568KB）
     ※ひかりdeトークS/NURO 光 でんわとお申込みの場合のみ
- My Y!mobileでお申し込みの場合は固定通信サービスの「S-ID」または「Yahoo! JAPAN ID」が必要です。
- ショップでお申し込みの場合は「SoftBank Air」、「SoftBank 光」のお申し込み番号（14桁）またはカスタマーIDが必要です。

- ※ ケーブルライン、ひかりdeトークS（ケーブルライン）、NURO光でんわ（ケーブルライン）の場合は、事業者によって「おうち割 光セット（A）」に申し込みできるタイミングが異なります。詳しくは各事業者までお問い合わせください。

## おうち割 光セット（A） 詳細

### 適用条件

- 当社指定窓口に本割引をお申し込みいただくこと。
- 受付期間内に本割引をお申し込みいただくこと。
- 個人のお客さまであること。
- モバイル通信サービスを対象料金プランでご利用中またはお申し込みいただくこと。
- 固定通信サービスお申し込み後180日以内に固定通信サービスが契約成立（開通）をすること。
- お申し込みのお客さま、またはそのご家族が対象固定通信サービスの契約者で指定オプション（550円/月～）をご利用中またはお申し込みいただくこと。
  - ※ ご家族の方が本割引をお申し込みの場合、対象固定通信サービス契約者のご家族であることを証明できる確認書類が必要です。

| モバイル通信サービス<br>（対象料金プラン） | 固定通信サービス<br>（対象料金プラン） |
| シンプル3 S/M/L、シンプル2 S/M/L、シンプルS/M/L、スマホベーシックプラン（タイプ1）、スマホプラン（タイプ1）、データプランL、Pocket WiFiプラン2 | SoftBank 光　自動更新ありプラン※1 |
|  | プラン | 指定オプション |
|  | SoftBank 光・10ギガ以外に<br>ご加入の場合 | - ・光BBユニットレンタル<br>- ・「Wi-Fiマルチパック」または「Wi-Fi地デジパック」<br>- ・「ホワイト光電話」、「BB フォン」または「光電話（N）および BB フォン」 |
|  | SoftBank 光・10ギガに<br>ご加入の場合 | - ・Wi-Fiマルチパック<br>- ・「ホワイト光電話」、「BB フォン」または「光電話（N）および BB フォン」 |
| SoftBank Air |
| Yahoo! BB 光シティ※2 |
| シンプル3 S/M/L、シンプル2 S/M/L | ケーブルライン※3 |
| ひかり de トーク S（ケーブルライン） ※3 ※4 |
| NURO 光 でんわ（ケーブルライン）※4 ※5 |

- ※1 自動更新なしプランは対象外です。
- ※2 Yahoo! BB光シティは地域限定のサービスです。
- ※3 本割引の対象となる提供事業者については当社ホームページの「提携ケーブルテレビ事業者様」記載の事業者 をご確認ください。


URL： [https://www.softbank.jp/biz/nw/isp/cableline/cabletv/](https://www.softbank.jp/biz/nw/isp/cableline/cabletv/)
- ※4 ひかりdeトークSは、株式会社TOKAIケーブルネットワーク、NURO光でんわはソニーネットワークコミュニケーションズ

株式会社が当社と連携して提供するサービスです。
- ※5 ソニーネットワークコミュニケーションズ株式会社がお客さまから直接申込を受けて提供する場合が対象です。


ソニーネットワークコミュニケーションズ株式会社が光回線卸受事業者から申込の取次を受けて提供する場合や、お客さまから直接申込を受けたとしても、他事業者と提携し、ブランド名や商品名等を変更して提供している場合は対象外となります。

### 割引について

- モバイル通信サービスの対象料金プラン基本使用料を割引します。
- 固定通信サービスの契約成立確認はおうち割 光セット（A）申込翌月より毎月1～2日の契約成立確認期間に行います。
- 適用条件が確認された当月利用分より割引を適用します。


ただし、契約成立確認日（毎月2日）までにモバイル回線を解約された場合、適用条件を満たさないため割引を適用することはできません。また、契約成立確認期間中におうち割 光セット（A）を解除および再申し込みした場合、再申し込みした翌月より契約成立確認を行います。
- 以下の割引、キャンペーンと重複して割引を適用することはできません。
  - おうち割 光セット（A）申込特典
  - 光おトク割
  - 家族割引サービス
  - Wi-Fiセット割
  - タブレット割引（スタートキャンペーン向け）
- 以下のいずれかに該当する場合、以下条件が確認された当月利用分をもって割引の適用を終了します。
  - モバイル通信サービス回線を解約した場合
  - モバイル通信サービス回線を対象外料金プランに変更した場合
  - 対象固定通信サービスや指定オプションの変更、解約、譲渡などにより、適用条件を満たしていないことを確認した場合
- 以下に該当する場合、以下条件が確認された当日をもって割引の適用を終了します。
  - モバイル通信サービス回線を譲渡した場合
- 以下に該当する場合、以下条件が確認された時点で「おうち割 光セット（A）」の申込をキャンセルします。
  - 固定通信サービスのお申し込みから180日経過後も、契約未成立（未開通）または指定オプション未加入だった場合

＜SoftBank 光 割引特典＞

「おうち割 光セット（A）」が適用されたお客さまに対し、指定オプションをパック料金（550円/月～）にて提供します。

詳細は提供条件書をご確認ください。

- [「おうち割 光セット（A）」提供条件書](https://www.ymobile.jp/corporate/open/agreement/pdf/hikarisetwari.pdf)
- [「おうち割 光セット（A） 申込特典」提供条件書](https://www.ymobile.jp/corporate/open/agreement/pdf/hikarisetwari2.pdf)

## よくあるご質問

[トップへ戻る](https://www.ymobile.jp/plan/discount/hikarisetwari/#top)

- [ワイモバイルの\\
\\
お申し込み](https://www.ymobile.jp/plan/discount/hikarisetwari/#)
- [おうちのネットの\\
\\
お申し込み](https://www.ymobile.jp/plan/discount/hikarisetwari/#)

ワイモバイルのお申し込み

オンラインストア

お申し込み完了後、おうちのネットをお申し込みください。

ワイモバイルの開通後にMy Y!mobileよりおうち割に加入できます。

[ワイモバイル オンラインストア](https://www.ymobile.jp/store/)

店舗

ワイモバイルショップでは、「ワイモバイル」と「おうち割 光セット（A）」の同時申し込みが可能です。

[お近くのワイモバイルショップを探す](https://www.ymobile.jp/shop/)

閉じる

おうちのネットのお申し込み

オンラインで

おうち割 光セット（A）も同時お申し込みできます。

- [SoftBank 光](https://www.ymobile.jp/plan/discount/hikarisetwari/form/)
- [SoftBank Air](http://www.softbank.jp/ybb/order/air-02/?ref=ym_phoenix_other)

お電話・店舗で

新規受付センター **0120-981-211** **[0120-981-211](tel:0120-981-211)**

通話料無料

受付時間：午前9時から午後10時

[お近くのワイモバイルショップを探す](https://www.ymobile.jp/shop/)

ご注意

ワイモバイルショップでお申し込み時のご注意

ワイモバイルサービスとSoftBank 光のご契約名義が異なる場合は下記の提出が必要になります。

- ・おうち割 光セット（A）申込者のご本人様確認書類（運転免許証、パスポートなどで、ご本人を確認できるもの）
- ・家族確認書類

（詳細は [こちら](https://www.ymobile.jp/support/faq/view/21442) をご確認ください）
- ・[同意書](https://www.ymobile.jp/plan/discount/hikariotokuwari/pdf/doui.pdf)

「ワイモバイル」も「おうちのネット」もご利用中のお客さまは

『 [My Y!mobile](https://www.ymobile.jp/plan/discount/hikarisetwari/myym/)』より「おうち割 光セット（A）」をお申し込みいただけます。

閉じる

- [当サイトについて](https://www.ymobile.jp/copyright/)
- [商標について](https://www.softbank.jp/corp/aboutus/governance/intellectual-property/trademark/)
- [約款・重要説明事項](https://www.ymobile.jp/corporate/open/agreement/)
- [個人情報について](https://www.softbank.jp/corp/privacy/)
- [情報セキュリティポリシー](https://www.softbank.jp/corp/security/)
- [プライバシーセンター](https://www.softbank.jp/privacy/)
- [企業情報](https://www.softbank.jp/corp/)

© SoftBank Corp. All rights reserved.電気通信事業登録番号：第72号

![](https://www.ymobile.jp/store/common/cart_data/images/violet-new-service-page/intersect-sp.png)![](https://www.ymobile.jp/store/common/cart_data/images/violet-new-service-page/intersect-pc.png)![](https://www.ymobile.jp/store/common/cart_data/images/violet-new-service-page/futenyan_front.png)

# ご希望のお手続きを教えてください

## どちらで申し込みますか？

- 今の電話番号をそのまま使用する
- 新しい電話番号で申し込む

## 今ご利用中の携帯電話会社はどちらですか？

- ワイモバイル
- ワイモバイル以外

## ソフトバンクやLINEMOからののりかえですか？

- はい
- いいえ

## 端末もあわせて申し込みますか？

- はい
- いいえ（SIMのみ申し込む）

ワイモバイルの商品を見る


画面を閉じてお手続きを進める

※ボタンをタップしても閉じられない場合は、

ブラウザの「×」で閉じてください。