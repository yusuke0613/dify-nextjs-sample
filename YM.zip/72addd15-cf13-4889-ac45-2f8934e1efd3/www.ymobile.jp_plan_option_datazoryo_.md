---
url: "https://www.ymobile.jp/plan/option/datazoryo/"
title: "データ増量オプション"
---

[![BLACK FRIDAY セール オンラインストア限定 12/1（月）14:59まで](https://www.ymobile.jp/common_c/images/index/head_promotion.png?20251120)![BLACK FRIDAY セール オンラインストア限定 12/1（月）14:59まで](https://www.ymobile.jp/common_c/images/index/head_promotion_sp.png?20251120)](https://www.ymobile.jp/lineup/?ref=topticker)

[Y!mobile](https://www.ymobile.jp/)

- [料金](https://www.ymobile.jp/plan/)
- [製品](https://www.ymobile.jp/lineup/)
- [SIM/eSIM](https://www.ymobile.jp/store/sp/sim/)
- [サービス](https://www.ymobile.jp/service/)
- [会員クーポン](https://www.ymobile.jp/service/ymobile/premium/#coupon-link)

- [お申し込み](https://www.ymobile.jp/select_contract/)
- [ログイン](https://www.ymobile.jp/support/online/login/)
- [法人ご契約](https://www.ymobile.jp/biz/)
- メニュー

- [![](https://www.ymobile.jp/common_c/images/common/icon/icon_home.svg)ホーム](https://www.ymobile.jp/)
- [サービス](https://www.ymobile.jp/service/)
- [通話・通信](https://www.ymobile.jp/service/#call-data-box)
- データ増量オプション

- [スーパーだれとでも定額・だれとでも定額](https://www.ymobile.jp/plan/tuwaoptionplus/)
- [データ増量オプション](https://www.ymobile.jp/plan/option/datazoryo/)
- [留守番電話サービス/留守番電話プラス](https://www.ymobile.jp/service/answering_service/)
- [データくりこし](https://www.ymobile.jp/service/kurikoshi/)
- [アドバンスオプション](https://www.ymobile.jp/plan/option/advance_option/)
- [オートチャージ（快適モード）](https://www.ymobile.jp/service/kaitekimode/)
- [ソフトバンクWi-Fiスポット](https://www.ymobile.jp/service/sws/)
- [テザリング](https://www.ymobile.jp/service/tethering/)
- [メール](https://www.ymobile.jp/service/mail/)
- [Y!mobile メール](https://www.ymobile.jp/service/ymobile/mail/)
- [ナンバーブロック](https://www.ymobile.jp/service/call_block/)
- [VoLTE／VoLTE（HD＋）](https://www.ymobile.jp/service/volte/)
- [グループ通話](https://www.ymobile.jp/service/call_group/)
- [割込通話](https://www.ymobile.jp/service/call_warikomi/)
- [発信者番号通知](https://www.ymobile.jp/service/call_incoming/#call_numberdisplay)
- [発信規制・着信規制](https://www.ymobile.jp/service/call_incoming/#call_regulation)
- [着信お知らせ機能](https://www.ymobile.jp/service/answering_service/#call_incoming)
- [着信転送サービス](https://www.ymobile.jp/service/call_tenso/)
- [電話番号案内（104）](https://www.ymobile.jp/service/104annai/)
- [お好み番号セレクト](https://www.ymobile.jp/service/okonomi-bango-select/)
- [通話オプション（シンプル S/M/L）](https://www.ymobile.jp/plan/tuwaoption/)

# データ増量オプション

[![](https://www.ymobile.jp/cp/datazoryo3/images/title.png?20241201)![](https://www.ymobile.jp/common_c/images/bnr/bnr_datazoryo3.png?20241201)](https://www.ymobile.jp/cp/datazoryo3/)

表示価格は特に記載がない限り税込です。

消費税の計算上、請求金額と異なる場合があります。

６か月間無料は法人契約は対象外となります

## 対象料金プラン

シンプル3 S/M/L、シンプル2 S/M/L、シンプルS/M/L、スマホプラン、スマホベーシックプラン

| 申し込み | 必要 |
| 月額料 | 550円 初月無料★ |

- ★はじめてデータ増量オプションを申し込みし加入した方限定
- ●月途中の加入・解約の場合でも、月額料の日割り計算は行いません。
- ●新規契約と同時にお申し込みの場合、お申し込み当月から適用になります。それ以外のお申し込みの場合、翌月からの適用となります。

## 申し込みはこちら

- アプリ / WEB
- ショップ

### お手続きは  ワイモバイル対応アプリでも可能！

[My SoftBankアプリを\\
\\
インストール](https://www.ymobile.jp/plan/option/datazoryo/#) [My SoftBankアプリを\\
\\
インストール](https://stn.mb.softbank.jp/r3Q7N) [My SoftBankアプリを\\
\\
インストール](https://stn.mb.softbank.jp/a209l) [申し込む](https://ymobile.jp/s/T8n1p)

### ご来店の際は事前予約をお願いします

[申し込む](https://www.ymobile.jp/shop/?EasyRsvStep2)

## 高速データ通信量が増量に！

当オプションを追加すると、高速データ通信量が増量になります。

### シンプル3 S/M/Lの場合

|  | シンプル3 S | シンプル3 M | シンプル3 L |
| --- | --- | --- | --- |
| 通常のデータ通信量<br>（規定容量） | 5GB | 30GB | 35GB |
| **データ増量オプション増量分** | **+** 2 **GB** | **+** 5 **GB** | **+** 5 **GB** |
| **合計** | **7** **GB** | **35** **GB** | **40** **GB** |

### シンプル2 S/M/Lの場合

|  | シンプル2 S | シンプル2 M | シンプル2 L |
| --- | --- | --- | --- |
| 通常のデータ通信量<br>（規定容量） | 4GB | 30GB | 35GB |
| **データ増量オプション増量分** | **+** 2 **GB** | **+** 5 **GB** | **+** 5 **GB** |
| **合計** | **6** **GB** | **35** **GB** | **40** **GB** |

シンプルS/M/Lの場合


|  | シンプルS | シンプルM | シンプルL |
| --- | --- | --- | --- |
| 通常のデータ通信量<br>（規定容量） | 3GB | 15GB | 25GB |
| **データ増量オプション増量分** | **+** 2 **GB** | **+** 5 **GB** | **+** 5 **GB** |
| **合計** | **5** **GB** | **20** **GB** | **30** **GB** |

スマホプラン、スマホベーシックの場合


本オプションで追加されたデータ容量は、ご利用料金プランの規定容量を使い切って通信速度が低速化された際、通常速度に戻す時にご利用いただけます。

ご契約の料金プランに応じ、通常速度に戻す追加料金（以下、追加料金）を以下のとおり割引します。

| 対象プラン | データ増量オプション増量分 | 追加料金の無料回数 |
| --- | --- | --- |
| スマホプランS | +1GB | 0.5GB×2回 |
| スマホプランM/R | +3GB | 0.5GB×6回 |
| スマホプランL | +7GB | 0.5GB×14回 |
| スマホベーシックプランL | +7GB | 0.5GB×14回 |

- ※ お客さまご自身でMy Y!mobile等から通常の速度に戻すお申し込みが必要です。
- ※ 追加料金の割引は、請求時に割引します。
- ※ 料金プラン変更を行った場合、変更後の料金プランに応じた追加料金の無料回数および割引金額を適用します。

#### データ増量オプション加入時のくりこし

## シンプル3 Mの場合

![](https://www.ymobile.jp/plan/option/datazoryo/images/img02.png?20250601)![](https://www.ymobile.jp/plan/option/datazoryo/images/img02_sp.png?20250601)

- ※ 翌月へくりこしできるデータ容量の上限は、翌月加入のプランのデータ容量（データ増量オプションによる増量分を含む）までとなります。
- ※ データ量はくりこし分＞規定容量（データ増量オプションによるデータ増量を含む）＞追加購入データ量の順に消費されます。
- ※ くりこしたデータ容量は翌月末まで利用可能です。くりこしされるデータは100MB未満は切り捨てとなります。
- ※ シェアプランについて、親回線とデータ容量を分け合っている期間（シェア適用中）はデータがくりこしできます。ただし、親回線とのシェアが開始になる前月およびシェアが解除になる最終月の余ったデータ容量は翌月にくりこしされません。

#### オートチャージ設定中のお客さまへご注意事項

2021年9月1日以降、シンプルS/M/Lのお客様について、データ増量オプション加入で追加されるデータ容量はデータ容量の追加購入手続きが不要となるため、オートチャージの設定を1～14回に設定されているお客さまは、設定を「OFF」にしていただきますようお願いいたします。
設定の変更は [こちら](https://my.ymobile.jp/muc/d/webLink/doSend/MWBWL0121) からお申し込みください。※My Y!mobileのログインが必要です。

設定変更までの間にオートチャージにより購入されたデータ容量については、料金（0.5GB/550円）が発生します。

- ※ スマホベーシックプラン/スマホプラン/ケータイベーシックプランSS/ケータイプランSSでデータ増量オプションに加入しているかつ、オートチャージ設定をしているお客さまも、シンプルS/M/Lへプラン変更する場合、上記に該当いたします。
- ※ オートチャージ設定の変更は、即時に反映されます。

## 注意事項

- ●データ容量増量を特典とするキャンペーン適用中のお客さまは、キャンペーンが優先適用されるためデータ容量はそのままとなります。ただし、キャンペーン適用中はデータ増量オプションにお申込みいただいた場合でも月額料金は発生しません。
- ●月途中の加入・解約の場合でも、月額料の日割り計算は行いません。
- ●新規契約と同時にお申し込みの場合、お申し込み当月から適用になります。それ以外のお申し込みの 場合、お申し込み翌月からの適用となります。
- ●2021年8月17日以前よりシンプルS/M/Lでデータ増量オプションにご加入中のお客さまのオプション内容改定、およびデータ増量オプションによるデータ増量分のデータくりこしについては2021年9月1日から適用されます。なお改定までは従前のデータ増量オプションの内容（低速化した通信速度を通常速度に戻す申込みにかかる追加料金の値引き）が適用されます。
- ●くりこし対象の5GBを超過した際には通信速度が低速化します。
- ●本オプションはデータ容量を増量する過去のキャンペーン（データ容量2倍キャンペーンなど）と併用はできません。

本オプションサービスについての詳細は提供条件書よりご確認ください。

[「データ増量オプション」提供条件書](https://www.ymobile.jp/corporate/open/agreement/pdf/data_zoryo_option.pdf)

[トップへ戻る](https://www.ymobile.jp/plan/option/datazoryo/#top)

- [![社会課題に、アンサーを。](https://www.ymobile.jp/common_c/images/bnr/bnr_corp_special_answer.png?20251024)](https://www.softbank.jp/corp/special/answer/)
- [![SoftBank⇒サステナビリティ](https://www.ymobile.jp/common_c/images/bnr/bnr_esg_rating.png)](https://www.softbank.jp/corp/sustainability/)
- [![ワイモバイルの改善活動](https://www.ymobile.jp/common_c/images/bnr/bnr_kaizen_action.png)](https://www.softbank.jp/mobile/special/kaizen-action/?brand=ym&utm_source=yahoo&utm_medium=officialsite&utm_campaign=_mobile_cx_kaizen_20240905_018)

SEARCH

### ご契約を検討中のお客さま

- [新規ご契約](https://www.ymobile.jp/support/process/new_application/)
- [他社からのりかえ](https://www.ymobile.jp/support/process/portability/)
- [請求・お支払い](https://www.ymobile.jp/support/charge/)
- [エリアを確認したい](https://www.ymobile.jp/area/)
- [ショップを検索したい](https://www.ymobile.jp/shop/)
- [お得な情報が知りたい](https://www.ymobile.jp/cp/)

### 現在ご利用中のお客さま

- [My Y!mobileへログイン](https://www.ymobile.jp/support/online/login/)
- [困ったときは](https://www.ymobile.jp/support/trouble/)
- [オンライン手続きガイド](https://www.ymobile.jp/support/online/guide/)
- [製品サポート](https://www.ymobile.jp/support/product/)
- [機種変更](https://www.ymobile.jp/support/process/model_change/)
- [障害情報](https://www.ymobile.jp/info/failure/)
- [工事情報](https://www.ymobile.jp/info/maintenance/)

### 企業情報を知りたいお客さま

- [企業情報](https://www.softbank.jp/corp/aboutus/)
- [プレスリリース](https://www.softbank.jp/corp/news/press/sbkk/)
- [公開情報](https://www.softbank.jp/corp/aboutus/public/)
- [電子公告](https://www.softbank.jp/corp/ir/e_publicnotice/)
- [サステナビリティ](https://www.softbank.jp/corp/sustainability/)
- [採用情報](https://www.softbank.jp/corp/careers/)

### おすすめ情報

- [キャンペーン・おすすめ情報](https://www.ymobile.jp/cp/)
- [カタログ・パンフレット・ガイド](https://www.ymobile.jp/sp/p_guide/)
- [徹底解説！スマホとSIMのギモン](https://www.ymobile.jp/sp/guide/)

[よくあるご質問](https://www.ymobile.jp/support/faq/) [お問い合わせ](https://www.ymobile.jp/support/contact/)

SEARCH

- [当サイトについて](https://www.ymobile.jp/copyright/)
- [商標について](https://www.softbank.jp/corp/aboutus/governance/intellectual-property/trademark/)
- [約款・重要説明事項](https://www.ymobile.jp/corporate/open/agreement/)
- [個人情報について](https://www.softbank.jp/corp/privacy/)
- [情報セキュリティポリシー](https://www.softbank.jp/corp/security/)
- [プライバシーセンター](https://www.softbank.jp/privacy/)
- [企業情報](https://www.softbank.jp/corp/aboutus/)

© SoftBank Corp. All rights reserved.電気通信事業登録番号：第72号

閉じる

SEARCH

- [AIチャットで検索する](https://ymkarakuri.karakuri-gen.com/ymobile1/embed) [AIチャットで検索する](https://ymkarakuri.karakuri-gen.com/ymobile1/embed)
- [お申し込み](https://www.ymobile.jp/select_contract/)
- [My Y!mobile](https://www.ymobile.jp/support/online/login/)
- [法人のお客さま](https://www.ymobile.jp/biz/)

- [料金](https://www.ymobile.jp/plan/)
- [製品](https://www.ymobile.jp/lineup/)
- [SIM/eSIM](https://www.ymobile.jp/store/sp/sim/)
- [サービス](https://www.ymobile.jp/service/)
- [会員クーポン](https://www.ymobile.jp/service/ymobile/premium/#coupon-link)
- [SIMタイプ変更](https://www.ymobile.jp/sp/sim_kihen/)
- _サポート_






- [My Y!mobileご利用ガイド](https://www.ymobile.jp/support/online/)
- [オンラインストアご利用ガイド](https://www.ymobile.jp/store/to_beginner/)
- [ご契約者さま向けオンライン手続きガイド](https://www.ymobile.jp/support/online/guide/)
- [製品サポート](https://www.ymobile.jp/support/product/)
- [お申込後の初期設定ガイド](https://www.ymobile.jp/yservice/howto/)
- [請求・お支払い](https://www.ymobile.jp/support/charge/)
- [その他サポート](https://www.ymobile.jp/support/)
- [よくあるご質問](https://www.ymobile.jp/support/faq/)
- [お問い合わせ](https://www.ymobile.jp/support/contact/)

- [キャンペーン](https://www.ymobile.jp/cp/)
- _ショップ_






- [ショップを探す](https://www.ymobile.jp/shop/)
- [かんたん来店予約](https://www.ymobile.jp/shop/reservation/about/)
- [マイワイモバイルショップ](https://www.ymobile.jp/shop/myshop/)

![オンラインでお手続き！](https://www.ymobile.jp/common_c/images/common/txt-online.png)

[![オンライン手続きガイド](https://www.ymobile.jp/common_c/images/bnr/bnr_onlineguide2.png)](https://www.ymobile.jp/support/online/guide/)[![オンラインストア](https://www.ymobile.jp/common_c/images/bnr/bnr_store.png)](https://www.ymobile.jp/store/)

- [オンラインストア](https://www.ymobile.jp/store/)
- [エリア](https://www.ymobile.jp/area/)
- [法人の方](https://www.ymobile.jp/biz/)

- [![](https://www.ymobile.jp/common_c/images/bnr/bnr_ymotoku.png)](https://www.ymobile.jp/sp/ymobile-otoku/)

- [料金](https://www.ymobile.jp/plan/)
- [製品](https://www.ymobile.jp/lineup/)
- [SIM/eSIM](https://www.ymobile.jp/store/sp/sim/)
- [サービス](https://www.ymobile.jp/service/)
- [会員クーポン](https://www.ymobile.jp/service/ymobile/premium/#coupon-link)

![](https://www.ymobile.jp/store/common/cart_data/images/violet-new-service-page/intersect-sp.png)![](https://www.ymobile.jp/store/common/cart_data/images/violet-new-service-page/intersect-pc.png)![](https://www.ymobile.jp/store/common/cart_data/images/violet-new-service-page/futenyan_front.png)

# ご希望のお手続きを教えてください

## どちらで申し込みますか？

- 今の電話番号をそのまま使用する
- 新しい電話番号で申し込む

## 今ご利用中の携帯電話会社はどちらですか？

- ワイモバイル
- ワイモバイル以外

## ソフトバンクやLINEMOからののりかえですか？

- はい
- いいえ

## 端末もあわせて申し込みますか？

- はい
- いいえ（SIMのみ申し込む）

ワイモバイルの商品を見る


下記より、アプリケーションをダウンロードしてご利用ください。

- iPhone、iPad の方

[![ ](https://www.ymobile.jp/support/online/login/images/logo_app.png)](https://stn.mb.softbank.jp/r3Q7N)![ ](https://www.ymobile.jp/support/online/login/images/qr-app-store.svg)

- スマートフォン、タブレットの方

[![ ](https://www.ymobile.jp/support/online/login/images/logo_googleplay.png)](https://stn.mb.softbank.jp/a209l)![ ](https://www.ymobile.jp/support/online/login/images/qr-google-play.svg)


閉じる

画面を閉じてお手続きを進める

※ボタンをタップしても閉じられない場合は、

ブラウザの「×」で閉じてください。