---
url: "https://www.ymobile.jp/plan/data/pocketwifi_2/"
title: "Pocket WiFi®プラン2（ベーシック）｜Pocket WiFi®｜料金｜Y!mobile - 格安SIM・スマホはワイモバイルで"
---

[![BLACK FRIDAY セール オンラインストア限定 12/1（月）14:59まで](https://www.ymobile.jp/common_c/images/index/head_promotion.png?20251120)![BLACK FRIDAY セール オンラインストア限定 12/1（月）14:59まで](https://www.ymobile.jp/common_c/images/index/head_promotion_sp.png?20251120)](https://www.ymobile.jp/lineup/?ref=topticker)

[Y!mobile](https://www.ymobile.jp/)

- [料金](https://www.ymobile.jp/plan/)
- [製品](https://www.ymobile.jp/lineup/)
- [SIM/eSIM](https://www.ymobile.jp/store/sp/sim/)
- [サービス](https://www.ymobile.jp/service/)
- [会員クーポン](https://www.ymobile.jp/service/ymobile/premium/#coupon-link)

- [お申し込み](https://www.ymobile.jp/select_contract/)
- [ログイン](https://www.ymobile.jp/support/online/login/)
- [法人ご契約](https://www.ymobile.jp/biz/)
- メニュー

- [![](https://www.ymobile.jp/common_c/images/common/icon/icon_home.svg)ホーム](https://www.ymobile.jp/)
- [料金](https://www.ymobile.jp/plan/)
- [Pocket WiFi®](https://www.ymobile.jp/plan/data/)
- Pocket WiFi®プラン2（ベーシック）

# Pocket WiFi®プラン2（ベーシック）

[2019年9月30日受付終了のPocket WiFi®プラン2](https://www.ymobile.jp/plan/others/data/pocketwifi_2_nenkei/)

表示価格は特に記載がない限り税込です。

消費税の計算上、請求金額と異なる場合があります。

- 2026年1月29日（木）をもちまして、Pocket WiFi® 502HWの端末上での追加データ予約／購入機能を終了させていただきます。低速化の解除はMy Y!mobileよりお申し込みいただけます。

![](https://www.ymobile.jp/plan/data/pocketwifi_2/images/image01.png)

![](https://www.ymobile.jp/plan/data/pocketwifi_2/images/image02.png)

- 〇 5G通信のご利用には、5G対応端末が必要です。〇高速大容量5G（新周波数）は対象エリアが限られます。 [エリアマップをみる](https://www.ymobile.jp/area/)
- ※1 4G高速データ通信量が上限無しのアドバンスオプション「アドバンスモード」は、通信方式「TDD-LTE」･「AXGP」の提供エリアでご利用いただけます。 詳しくは製品ごとのエリアマップをご確認ください。


「FDD-LTE」のみの提供エリアでは、「標準モード」への切り替えが必要です。なお、「アドバンスモード」利用時、混雑回避など通信品質確保のための速度制御があります。（3日間で約10GB以上利用時／「アドバンスモード」と「標準モード」での利用パケット通信量の合計において）

### 対応機種

[5G対応\\
\\
![](https://www.ymobile.jp/lineup/images/a501zt.webp)\\
\\
**A501ZT**](https://www.ymobile.jp/lineup/a501zt/)

[5G対応\\
\\
![](https://www.ymobile.jp/lineup/images/a102zt.png)\\
\\
**A102ZT**](https://www.ymobile.jp/lineup/a102zt/)

[![](https://www.ymobile.jp/lineup/images/803zt.png)\\
\\
**803ZT**](https://www.ymobile.jp/lineup/803zt/)

[![](https://www.ymobile.jp/lineup/images/801hw.png)\\
\\
**801HW**](https://www.ymobile.jp/lineup/801hw/)

[![](https://www.ymobile.jp/lineup/images/603hw.png)\\
\\
**603HW**](https://www.ymobile.jp/lineup/603hw/)

![](https://www.ymobile.jp/plan/data/pocketwifi_2/images/img02.png)

- ●当月ご利用のデータ通信量が7GBを超えた場合に、当月末まで _データ通信速度の低速化_（送受信時最大 _128kbps_）を行います。
- ●通常速度に戻す場合は、 _0.5GBごとに550円の追加料金が必要_ です。
- ※通常速度に戻す申し込みは、「 [My Y!mobile](https://www.ymobile.jp/support/online/login/)」またはPocket WiFi® 本体から設定いただくか、ワイモバイルの [カスタマーサポート](https://www.ymobile.jp/support/contact/) へご連絡ください。（1回のお申し込みにあたり、当月分のみが適用されます。）常に通常速度を維持する「オートチャージ(快適モード)」をお申込みいただくと、規定容量(7GB)超過後も、低速化せず高速データ通信のままご利用いただけます。
- ※各通信速度は、ベストエフォート方式のため、回線の混雑状況や通信環境などにより、通信速度が低下、または通信ができなくなる場合があります。
- ※_混雑回避など通信品質確保のための速度制御（3日間で約10GB以上利用時）があります。_
通信速度制御の詳細は [こちら](https://www.ymobile.jp/service/info/tsushin.html)
- ●5G通信のご利用には、5G対応端末が必要です。
- ●高速大容量５G（新周波数）は対象エリアが限られます。 [エリアマップをみる](https://www.ymobile.jp/area/)

### ![](https://www.ymobile.jp/plan/data/pocketwifi_2/images/title01.png)

[![](https://www.ymobile.jp/plan/data/pocketwifi_2/images/btn01.png)](https://www.ymobile.jp/plan/option/advance_option/)

[![](https://www.ymobile.jp/plan/data/pocketwifi_2/images/btn02.png)](https://www.ymobile.jp/service/kaitekimode/)

## 基本使用料

| Pocket WiFi®プラン2（ベーシック） | 4,065.6円 |

- ※年間契約の定めのないプランです。
- ※併用サービスの使用料、端末代金は含まれていません。
- ※割引内容および期間は予告なく変更する場合があります。
- ※契約変更時、変更後契約の申し込み当月における料金プラン基本料はかかりません。
- ※ご契約初月は月額料金・割引額を日割り計算しますが、月途中の解約・解除の場合は日割り計算をしません。
- ※新規および契約変更でのご契約の場合には、 [契約事務手数料](https://www.ymobile.jp/plan/commission/) がかかります。
- ※[ユニバーサルサービス料](https://www.ymobile.jp/plan/info/universal/) が別途かかります。

## おすすめオプションサービス

[![](https://www.ymobile.jp/plan/data/images/btn_op05.png)](https://www.ymobile.jp/service/kosho_anshin/)

[![](https://www.ymobile.jp/plan/data/images/btn_op02.png)](https://www.ymobile.jp/service/widesupport/)

[その他、併用可能サービスはこちら](https://www.ymobile.jp/service/)

## 注意事項

- ● Pocket WiFi®プラン2（ベーシック）では、「アドバンスモード」利用時、ご利用料金プランの月間データ通信量に対する速度制限とは別途、混雑回避など通信品質確保のための速度制御(3日間で約10GB以上利用時/「アドバンスモード」と「標準モード」での利用パケット通信量の合計において)があります。
- ● 長時間連続して通信を行った場合、またはほかの通信に影響があると当社が判断した場合など、その通信を切断することがあります。その場合、あらためて接続動作を行っていただくことで接続が再開されます。

【5Gサービスについて】

- ● SoftBank 5Gサービスエリアは当初限定的であるため、お客さまによっては4Gでのご利用が中心となります。
- ● 5G対応端末を購入の際は、事前にエリアをご確認ください。また、お使いの端末画面上（画面上部）に待ち受け時は「5G」と表示されている場合でも、通信を行う際は表示が「4G」に切り替わり4G通信が使用される場合があります。
- ● 5Gサービスにおいては開始当初と比べ今後の利用者の増加等に伴い実際の通信速度が低下することが予想されます。

[トップへ戻る](https://www.ymobile.jp/plan/data/pocketwifi_2/#top)

- [![社会課題に、アンサーを。](https://www.ymobile.jp/common_c/images/bnr/bnr_corp_special_answer.png?20251024)](https://www.softbank.jp/corp/special/answer/)
- [![SoftBank⇒サステナビリティ](https://www.ymobile.jp/common_c/images/bnr/bnr_esg_rating.png)](https://www.softbank.jp/corp/sustainability/)
- [![ワイモバイルの改善活動](https://www.ymobile.jp/common_c/images/bnr/bnr_kaizen_action.png)](https://www.softbank.jp/mobile/special/kaizen-action/?brand=ym&utm_source=yahoo&utm_medium=officialsite&utm_campaign=_mobile_cx_kaizen_20240905_018)

SEARCH

### ご契約を検討中のお客さま

- [新規ご契約](https://www.ymobile.jp/support/process/new_application/)
- [他社からのりかえ](https://www.ymobile.jp/support/process/portability/)
- [請求・お支払い](https://www.ymobile.jp/support/charge/)
- [エリアを確認したい](https://www.ymobile.jp/area/)
- [ショップを検索したい](https://www.ymobile.jp/shop/)
- [お得な情報が知りたい](https://www.ymobile.jp/cp/)

### 現在ご利用中のお客さま

- [My Y!mobileへログイン](https://www.ymobile.jp/support/online/login/)
- [困ったときは](https://www.ymobile.jp/support/trouble/)
- [オンライン手続きガイド](https://www.ymobile.jp/support/online/guide/)
- [製品サポート](https://www.ymobile.jp/support/product/)
- [機種変更](https://www.ymobile.jp/support/process/model_change/)
- [障害情報](https://www.ymobile.jp/info/failure/)
- [工事情報](https://www.ymobile.jp/info/maintenance/)

### 企業情報を知りたいお客さま

- [企業情報](https://www.softbank.jp/corp/aboutus/)
- [プレスリリース](https://www.softbank.jp/corp/news/press/sbkk/)
- [公開情報](https://www.softbank.jp/corp/aboutus/public/)
- [電子公告](https://www.softbank.jp/corp/ir/e_publicnotice/)
- [サステナビリティ](https://www.softbank.jp/corp/sustainability/)
- [採用情報](https://www.softbank.jp/corp/careers/)

### おすすめ情報

- [キャンペーン・おすすめ情報](https://www.ymobile.jp/cp/)
- [カタログ・パンフレット・ガイド](https://www.ymobile.jp/sp/p_guide/)
- [徹底解説！スマホとSIMのギモン](https://www.ymobile.jp/sp/guide/)

[よくあるご質問](https://www.ymobile.jp/support/faq/) [お問い合わせ](https://www.ymobile.jp/support/contact/)

SEARCH

- [当サイトについて](https://www.ymobile.jp/copyright/)
- [商標について](https://www.softbank.jp/corp/aboutus/governance/intellectual-property/trademark/)
- [約款・重要説明事項](https://www.ymobile.jp/corporate/open/agreement/)
- [個人情報について](https://www.softbank.jp/corp/privacy/)
- [情報セキュリティポリシー](https://www.softbank.jp/corp/security/)
- [プライバシーセンター](https://www.softbank.jp/privacy/)
- [企業情報](https://www.softbank.jp/corp/aboutus/)

© SoftBank Corp. All rights reserved.電気通信事業登録番号：第72号

閉じる

SEARCH

- [AIチャットで検索する](https://ymkarakuri.karakuri-gen.com/ymobile1/embed) [AIチャットで検索する](https://ymkarakuri.karakuri-gen.com/ymobile1/embed)
- [お申し込み](https://www.ymobile.jp/select_contract/)
- [My Y!mobile](https://www.ymobile.jp/support/online/login/)
- [法人のお客さま](https://www.ymobile.jp/biz/)

- [料金](https://www.ymobile.jp/plan/)
- [製品](https://www.ymobile.jp/lineup/)
- [SIM/eSIM](https://www.ymobile.jp/store/sp/sim/)
- [サービス](https://www.ymobile.jp/service/)
- [会員クーポン](https://www.ymobile.jp/service/ymobile/premium/#coupon-link)
- [SIMタイプ変更](https://www.ymobile.jp/sp/sim_kihen/)
- _サポート_






- [My Y!mobileご利用ガイド](https://www.ymobile.jp/support/online/)
- [オンラインストアご利用ガイド](https://www.ymobile.jp/store/to_beginner/)
- [ご契約者さま向けオンライン手続きガイド](https://www.ymobile.jp/support/online/guide/)
- [製品サポート](https://www.ymobile.jp/support/product/)
- [お申込後の初期設定ガイド](https://www.ymobile.jp/yservice/howto/)
- [請求・お支払い](https://www.ymobile.jp/support/charge/)
- [その他サポート](https://www.ymobile.jp/support/)
- [よくあるご質問](https://www.ymobile.jp/support/faq/)
- [お問い合わせ](https://www.ymobile.jp/support/contact/)

- [キャンペーン](https://www.ymobile.jp/cp/)
- _ショップ_






- [ショップを探す](https://www.ymobile.jp/shop/)
- [かんたん来店予約](https://www.ymobile.jp/shop/reservation/about/)
- [マイワイモバイルショップ](https://www.ymobile.jp/shop/myshop/)

![オンラインでお手続き！](https://www.ymobile.jp/common_c/images/common/txt-online.png)

[![オンライン手続きガイド](https://www.ymobile.jp/common_c/images/bnr/bnr_onlineguide2.png)](https://www.ymobile.jp/support/online/guide/)[![オンラインストア](https://www.ymobile.jp/common_c/images/bnr/bnr_store.png)](https://www.ymobile.jp/store/)

- [オンラインストア](https://www.ymobile.jp/store/)
- [エリア](https://www.ymobile.jp/area/)
- [法人の方](https://www.ymobile.jp/biz/)

- [![](https://www.ymobile.jp/common_c/images/bnr/bnr_ymotoku.png)](https://www.ymobile.jp/sp/ymobile-otoku/)

- [料金](https://www.ymobile.jp/plan/)
- [製品](https://www.ymobile.jp/lineup/)
- [SIM/eSIM](https://www.ymobile.jp/store/sp/sim/)
- [サービス](https://www.ymobile.jp/service/)
- [会員クーポン](https://www.ymobile.jp/service/ymobile/premium/#coupon-link)

![](https://www.ymobile.jp/store/common/cart_data/images/violet-new-service-page/intersect-sp.png)![](https://www.ymobile.jp/store/common/cart_data/images/violet-new-service-page/intersect-pc.png)![](https://www.ymobile.jp/store/common/cart_data/images/violet-new-service-page/futenyan_front.png)

# ご希望のお手続きを教えてください

## どちらで申し込みますか？

- 今の電話番号をそのまま使用する
- 新しい電話番号で申し込む

## 今ご利用中の携帯電話会社はどちらですか？

- ワイモバイル
- ワイモバイル以外

## ソフトバンクやLINEMOからののりかえですか？

- はい
- いいえ

## 端末もあわせて申し込みますか？

- はい
- いいえ（SIMのみ申し込む）

ワイモバイルの商品を見る