---
url: "https://www.ymobile.jp/plan/old/"
title: "受付/提供終了プラン・割引｜料金｜Y!mobile - 格安SIM・スマホはワイモバイルで"
---

[![BLACK FRIDAY セール オンラインストア限定 12/1（月）14:59まで](https://www.ymobile.jp/common_c/images/index/head_promotion.png?20251120)![BLACK FRIDAY セール オンラインストア限定 12/1（月）14:59まで](https://www.ymobile.jp/common_c/images/index/head_promotion_sp.png?20251120)](https://www.ymobile.jp/lineup/?ref=topticker)

[Y!mobile](https://www.ymobile.jp/)

- [料金](https://www.ymobile.jp/plan/)
- [製品](https://www.ymobile.jp/lineup/)
- [SIM/eSIM](https://www.ymobile.jp/store/sp/sim/)
- [サービス](https://www.ymobile.jp/service/)
- [会員クーポン](https://www.ymobile.jp/service/ymobile/premium/#coupon-link)

- [お申し込み](https://www.ymobile.jp/select_contract/)
- [ログイン](https://www.ymobile.jp/support/online/login/)
- [法人ご契約](https://www.ymobile.jp/biz/)
- メニュー

- [![](https://www.ymobile.jp/common_c/images/common/icon/icon_home.svg)ホーム](https://www.ymobile.jp/)
- [料金](https://www.ymobile.jp/plan/)
- 受付/提供終了プラン・割引

# 受付/提供終了プラン・割引

## 受付終了プラン・割引

スマートフォン

- [シンプル2 S/M/L](https://www.ymobile.jp/plan/old/simple2/)
- [シンプル S/M/L](https://www.ymobile.jp/plan/old/simple/)
- [スマホベーシックプランS/M/R](https://www.ymobile.jp/plan/old/smartphone/basic/)
- [スマホプラン](https://www.ymobile.jp/plan/old/others/smartphone_nenkei/)
- [4G-Sプラン、4G-Sベーシックプラン](https://www.ymobile.jp/plan/old/4g-s_plan/)

ケータイ（PHS、3G）

- [ケータイプランSS](https://www.ymobile.jp/plan/old/others/phone/ketai_ss_nenkei/)

一般・公衆電話からPHSにかけた場合の料金は [こちら](https://www.ymobile.jp/plan/old/others/phs_fee/)

データ通信

- [Pocket WiFi®プラン2](https://www.ymobile.jp/plan/others/data/pocketwifi_2_nenkei/)
- [Pocket WiFi®プラン2 ライト](https://www.ymobile.jp/plan/old/others/data/pocketwifi_2_lite_nenkei/)
- [データプランS/L](https://www.ymobile.jp/plan/old/others/phone/dataplan_nenkei/)
- [Pocket WiFi®プランL](https://www.ymobile.jp/plan/old/data/pocketwifi_l/)
- [Pocket WiFi®プランSS](https://www.ymobile.jp/plan/old/data/pocketwifi_ss/)
- [Pocket WiFi®プラン](https://www.ymobile.jp/plan/old/data/pocketwifi/)
- [Pocket WiFi®プランS](https://www.ymobile.jp/plan/old/data/pocketwifi_s/)
- [Pocket WiFi®プラン＋](https://www.ymobile.jp/plan/old/data/pocketwifi_plus/)
- [4Gデータプラン](https://www.ymobile.jp/plan/old/4gdata/)
- [LTEプラン](https://www.ymobile.jp/plan/old/others/lte/)
- [EMOBILE G4 データプラン](https://www.ymobile.jp/plan/old/others/data3g/)
- [データプラン](https://www.ymobile.jp/plan/old/others/data3g/)
- [EMOBILE G4 データプランB](https://www.ymobile.jp/plan/old/others/data3g/)
- [データプランB](https://www.ymobile.jp/plan/old/others/data3g/)
- [EMOBILE G4 スーパーライトデータプラン](https://www.ymobile.jp/plan/old/others/data3g/)
- [スーパーライトデータプラン](https://www.ymobile.jp/plan/old/others/data3g/)
- [EMOBILE G4 バリューデータプラン](https://www.ymobile.jp/plan/old/others/data3g/)
- [バリューデータプラン](https://www.ymobile.jp/plan/old/others/data3g/)
- [EMOBILE G4 ギガデータプラン](https://www.ymobile.jp/plan/old/others/data3g/)
- [ギガデータプラン](https://www.ymobile.jp/plan/old/others/data3g/)
- [昼割プラン、EMOBILE G4 昼割プラン](https://www.ymobile.jp/plan/old/others/hiruwari/)
- [フレッツ＋定額モバイル](https://www.ymobile.jp/service/others/emhikari/#a02)
- [フレッツ＋スーパーライト](https://www.ymobile.jp/service/others/emhikari/#a03)
- [フレッツ＋昼割モバイル](https://www.ymobile.jp/service/others/emhikari/#a01)
- [フレッツ＋EMOBILE G4定額モバイル](https://www.ymobile.jp/service/others/emhikari/#a05)
- [フレッツ＋EMOBILE G4スーパーライト](https://www.ymobile.jp/service/others/emhikari/#a06)
- [フレッツ＋EMOBILE G4昼割モバイル](https://www.ymobile.jp/service/others/emhikari/#a04)
- モバイル閉域網接続定額プラン
- モバイル閉域網接続2段階プラン

オプションサービス

- [データ定額-S](https://www.ymobile.jp/plan/old/others/data_teigaku3-s/)
- [EMベーシックパック-S](https://www.ymobile.jp/plan/old/em_basic/)
- [24時間通話定額-S](https://www.ymobile.jp/plan/old/24h_tsuwa_teigaku-s/)

割引サービス

- [おうち割 でんきセット（A）](https://www.ymobile.jp/plan/discount/ouchiwari/?tabid=tab-ouchi&tabnum=2)
- [新規割](https://www.ymobile.jp/plan/old/discount/shinkiwari/)
- [SIM単体契約特別割引](https://www.ymobile.jp/corporate/open/agreement/pdf/simsp.pdf)
- [月額割引-S](https://www.ymobile.jp/plan/old/others/discount/getsugakuwaribiki-s/)
- [家族割引-S](https://www.ymobile.jp/plan/old/family/)
- [年とく割](https://www.ymobile.jp/plan/old/others/discount/nentoku/)

## 提供終了プラン・割引

スマートフォン

- [スマホプランタイプ3](https://www.ymobile.jp/plan/old/others/smartphone_type3/)
- [スマホベーシックプランタイプ3](https://www.ymobile.jp/plan/old/others/smartphone_type3/)
- [ウィルコムプランLite](https://www.ymobile.jp/plan/old/planlite/)
- [ウィルコムプランD＋](https://www.ymobile.jp/plan/old/plandplus/)
- スマホプランタイプ2
- スマホベーシックプランタイプ2
- LTE電話プラン
- スマートプラン
- スマートプランライト

ケータイ（PHS、3G）

- [ケータイプラン](https://www.ymobile.jp/plan/phone/ketai/)
- [プランW](https://www.ymobile.jp/plan/old/others/planw/)
- [プランGS](https://www.ymobile.jp/plan/old/others/new_fixed_rate_gs/)
- [新ウィルコム定額プランS](https://www.ymobile.jp/plan/old/new_fixed_rate_s/)
- [新ウィルコム定額プラン](https://www.ymobile.jp/plan/old/new_fixed_rate/)
- [標準コース](https://www.ymobile.jp/plan/old/standard/)
- [通話相手先限定](https://www.ymobile.jp/plan/old/safety/)
- [ウィルコム定額プラン](https://www.ymobile.jp/plan/old/fixed_rate/)
- [スーパーパックLL](https://www.ymobile.jp/plan/old/sp_ll/)
- [スーパーパックL](https://www.ymobile.jp/plan/old/sp_l/)
- [スーパーパックS](https://www.ymobile.jp/plan/old/sp_s/)
- [昼得コース](https://www.ymobile.jp/plan/old/daytime/)
- ケータイ定額プラン
- ケータイプラン

データ通信

- [新つなぎ放題](https://www.ymobile.jp/plan/old/whole_new/)
- [Two LINK DATA](https://www.ymobile.jp/plan/old/others/data/tld/)
- [3Gデータ定額（S）](https://www.ymobile.jp/plan/old/others/core3g_s/)
- [ネット25\[PRO\]](https://www.ymobile.jp/plan/old/net25_pro/)
- [つなぎ放題\[PRO\]](https://www.ymobile.jp/plan/old/whole_pro/)
- [ネット25](https://www.ymobile.jp/plan/old/net25/)
- [つなぎ放題\[4x\]](https://www.ymobile.jp/plan/old/whole_4x/)
- [つなぎ放題](https://www.ymobile.jp/plan/old/whole/)
- [パケコミネット](https://www.ymobile.jp/plan/old/pakekomi/)
- [データパック](https://www.ymobile.jp/plan/old/datapack/)
- [データパックmini](https://www.ymobile.jp/plan/old/datapack_mini/)
- 3Gデータ定額ビジネス（S）

オプションサービス

- [だれとでも定額 for EM-S](https://www.ymobile.jp/plan/old/daretei-s/)
- [ソフトバンク／イー・モバイル通話定額](https://www.ymobile.jp/plan/old/sb_em_unlimitedcall/)
- [ソフトバンク／ウィルコム通話定額](https://www.ymobile.jp/plan/old/sbwc_tsuwa_teigaku/)
- [だれとでも定額](https://www.ymobile.jp/plan/old/option/daretodemo/)
- [話し放題](https://www.ymobile.jp/plan/old/talk_free/)
- [新通話パック](https://www.ymobile.jp/plan/old/new_talk_pack/)
- [テザリングオプション](https://www.ymobile.jp/plan/old/tethering/)
- [通話パック](https://www.ymobile.jp/plan/old/talk_pack/)
- [データ定額](https://www.ymobile.jp/plan/old/data_fixed/)
- [リアルインターネットプラス](https://www.ymobile.jp/plan/old/rip/)
- [オプションメール放題](https://www.ymobile.jp/plan/old/mail/)
- [オプションメール放題＆トーク割](https://www.ymobile.jp/plan/old/mail_talk/)
- [年契+メール割引サービス](https://www.ymobile.jp/plan/old/year_mail/)
- [無料通話パック](https://www.ymobile.jp/plan/old/others/tsuwapack/)
- EM定額オプション
- だれとでも定額 for EM
- だれとでも定額 for EM(LTE電話プラン)

その他

- [パス専用プラン](https://www.ymobile.jp/plan/old/others/pass/)
- [迷惑電話チェッカー専用プラン](https://www.ymobile.jp/plan/old/others/checkers/)
- [おしらせ窓センサー専用料金プラン](https://www.ymobile.jp/plan/old/others/window_sensor/)

割引サービス

- [バリュースタイル・バリュースタイル（Ｆ）](https://www.ymobile.jp/plan/old/data/valuestyle/)
- [ワンキュッパ割](https://www.ymobile.jp/cp/wankyuppa/)
- [月額割引・月額割引（F）](https://www.ymobile.jp/plan/old/discount/getsugakuwari/)
- [だれとでも定額](https://www.ymobile.jp/plan/old/option/daretodemo/)
- おトク割（Pocket WiFi®プランSS/S/L/+）
- 長期利用割引（Pocket WiFi®プランSS/S/L/+）
- [ファミリーパック](https://www.ymobile.jp/plan/old/family_pack/)
- [ハートフルサポート](https://www.ymobile.jp/plan/old/heartful_support/)
- [長期割引サービス](https://www.ymobile.jp/plan/old/others/discount/long/old/)
- [複数割引サービス（家族・法人・複数割引）](https://www.ymobile.jp/plan/old/plural/)
- [マルチパック](https://www.ymobile.jp/plan/old/multipack/mobile/)
- [A&B割](https://www.ymobile.jp/plan/old/abwari/)
- [年間契約割引](https://www.ymobile.jp/plan/old/year/)
- [データセット割引](https://www.ymobile.jp/plan/old/dataset/)
- [長期契約割引](https://www.ymobile.jp/plan/old/others/discount/long/)
- 月額割
- いちねん得割
- にねん得割
- [W-VALUE SELECT（ダブルバリューセレクト）](https://www.ymobile.jp/plan/old/phone/wvalue/)
- [スマホプラン割引](https://www.ymobile.jp/plan/discount/smtplan/)
- 長期利用割引（スマホプランS／M／L）
- おトク割（Pocket WiFi®プラン2、Pocket WiFi®プラン2ライト、データプランS／L）
- 長期利用割引（Pocket WiFi®プラン2、Pocket WiFi®プラン2ライト、データプランS／L）

[トップへ戻る](https://www.ymobile.jp/plan/old/#top)

- [![社会課題に、アンサーを。](https://www.ymobile.jp/common_c/images/bnr/bnr_corp_special_answer.png?20251024)](https://www.softbank.jp/corp/special/answer/)
- [![SoftBank⇒サステナビリティ](https://www.ymobile.jp/common_c/images/bnr/bnr_esg_rating.png)](https://www.softbank.jp/corp/sustainability/)
- [![ワイモバイルの改善活動](https://www.ymobile.jp/common_c/images/bnr/bnr_kaizen_action.png)](https://www.softbank.jp/mobile/special/kaizen-action/?brand=ym&utm_source=yahoo&utm_medium=officialsite&utm_campaign=_mobile_cx_kaizen_20240905_018)

SEARCH

### ご契約を検討中のお客さま

- [新規ご契約](https://www.ymobile.jp/support/process/new_application/)
- [他社からのりかえ](https://www.ymobile.jp/support/process/portability/)
- [請求・お支払い](https://www.ymobile.jp/support/charge/)
- [エリアを確認したい](https://www.ymobile.jp/area/)
- [ショップを検索したい](https://www.ymobile.jp/shop/)
- [お得な情報が知りたい](https://www.ymobile.jp/cp/)

### 現在ご利用中のお客さま

- [My Y!mobileへログイン](https://www.ymobile.jp/support/online/login/)
- [困ったときは](https://www.ymobile.jp/support/trouble/)
- [オンライン手続きガイド](https://www.ymobile.jp/support/online/guide/)
- [製品サポート](https://www.ymobile.jp/support/product/)
- [機種変更](https://www.ymobile.jp/support/process/model_change/)
- [障害情報](https://www.ymobile.jp/info/failure/)
- [工事情報](https://www.ymobile.jp/info/maintenance/)

### 企業情報を知りたいお客さま

- [企業情報](https://www.softbank.jp/corp/aboutus/)
- [プレスリリース](https://www.softbank.jp/corp/news/press/sbkk/)
- [公開情報](https://www.softbank.jp/corp/aboutus/public/)
- [電子公告](https://www.softbank.jp/corp/ir/e_publicnotice/)
- [サステナビリティ](https://www.softbank.jp/corp/sustainability/)
- [採用情報](https://www.softbank.jp/corp/careers/)

### おすすめ情報

- [キャンペーン・おすすめ情報](https://www.ymobile.jp/cp/)
- [カタログ・パンフレット・ガイド](https://www.ymobile.jp/sp/p_guide/)
- [徹底解説！スマホとSIMのギモン](https://www.ymobile.jp/sp/guide/)

[よくあるご質問](https://www.ymobile.jp/support/faq/) [お問い合わせ](https://www.ymobile.jp/support/contact/)

SEARCH

- [当サイトについて](https://www.ymobile.jp/copyright/)
- [商標について](https://www.softbank.jp/corp/aboutus/governance/intellectual-property/trademark/)
- [約款・重要説明事項](https://www.ymobile.jp/corporate/open/agreement/)
- [個人情報について](https://www.softbank.jp/corp/privacy/)
- [情報セキュリティポリシー](https://www.softbank.jp/corp/security/)
- [プライバシーセンター](https://www.softbank.jp/privacy/)
- [企業情報](https://www.softbank.jp/corp/aboutus/)

© SoftBank Corp. All rights reserved.電気通信事業登録番号：第72号

閉じる

SEARCH

- [AIチャットで検索する](https://ymkarakuri.karakuri-gen.com/ymobile1/embed) [AIチャットで検索する](https://ymkarakuri.karakuri-gen.com/ymobile1/embed)
- [お申し込み](https://www.ymobile.jp/select_contract/)
- [My Y!mobile](https://www.ymobile.jp/support/online/login/)
- [法人のお客さま](https://www.ymobile.jp/biz/)

- [料金](https://www.ymobile.jp/plan/)
- [製品](https://www.ymobile.jp/lineup/)
- [SIM/eSIM](https://www.ymobile.jp/store/sp/sim/)
- [サービス](https://www.ymobile.jp/service/)
- [会員クーポン](https://www.ymobile.jp/service/ymobile/premium/#coupon-link)
- [SIMタイプ変更](https://www.ymobile.jp/sp/sim_kihen/)
- _サポート_






- [My Y!mobileご利用ガイド](https://www.ymobile.jp/support/online/)
- [オンラインストアご利用ガイド](https://www.ymobile.jp/store/to_beginner/)
- [ご契約者さま向けオンライン手続きガイド](https://www.ymobile.jp/support/online/guide/)
- [製品サポート](https://www.ymobile.jp/support/product/)
- [お申込後の初期設定ガイド](https://www.ymobile.jp/yservice/howto/)
- [請求・お支払い](https://www.ymobile.jp/support/charge/)
- [その他サポート](https://www.ymobile.jp/support/)
- [よくあるご質問](https://www.ymobile.jp/support/faq/)
- [お問い合わせ](https://www.ymobile.jp/support/contact/)

- [キャンペーン](https://www.ymobile.jp/cp/)
- _ショップ_






- [ショップを探す](https://www.ymobile.jp/shop/)
- [かんたん来店予約](https://www.ymobile.jp/shop/reservation/about/)
- [マイワイモバイルショップ](https://www.ymobile.jp/shop/myshop/)

![オンラインでお手続き！](https://www.ymobile.jp/common_c/images/common/txt-online.png)

[![オンライン手続きガイド](https://www.ymobile.jp/common_c/images/bnr/bnr_onlineguide2.png)](https://www.ymobile.jp/support/online/guide/)[![オンラインストア](https://www.ymobile.jp/common_c/images/bnr/bnr_store.png)](https://www.ymobile.jp/store/)

- [オンラインストア](https://www.ymobile.jp/store/)
- [エリア](https://www.ymobile.jp/area/)
- [法人の方](https://www.ymobile.jp/biz/)

- [![](https://www.ymobile.jp/common_c/images/bnr/bnr_ymotoku.png)](https://www.ymobile.jp/sp/ymobile-otoku/)

- [料金](https://www.ymobile.jp/plan/)
- [製品](https://www.ymobile.jp/lineup/)
- [SIM/eSIM](https://www.ymobile.jp/store/sp/sim/)
- [サービス](https://www.ymobile.jp/service/)
- [会員クーポン](https://www.ymobile.jp/service/ymobile/premium/#coupon-link)

![](https://www.ymobile.jp/store/common/cart_data/images/violet-new-service-page/intersect-sp.png)![](https://www.ymobile.jp/store/common/cart_data/images/violet-new-service-page/intersect-pc.png)![](https://www.ymobile.jp/store/common/cart_data/images/violet-new-service-page/futenyan_front.png)

# ご希望のお手続きを教えてください

## どちらで申し込みますか？

- 今の電話番号をそのまま使用する
- 新しい電話番号で申し込む

## 今ご利用中の携帯電話会社はどちらですか？

- ワイモバイル
- ワイモバイル以外

## ソフトバンクやLINEMOからののりかえですか？

- はい
- いいえ

## 端末もあわせて申し込みますか？

- はい
- いいえ（SIMのみ申し込む）

ワイモバイルの商品を見る