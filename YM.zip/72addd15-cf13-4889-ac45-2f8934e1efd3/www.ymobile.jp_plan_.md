---
url: "https://www.ymobile.jp/plan/"
title: "料金プラン｜Y!mobile - 格安SIM・スマホはワイモバイルで"
---

[![売り尽くしSALE実施中！最大77%OFF](https://www.ymobile.jp/common_c/images/index/head_promotion.png?20251024)![売り尽くしSALE実施中！最大77%OFF](https://www.ymobile.jp/common_c/images/index/head_promotion_sp.png?20251024)](https://www.ymobile.jp/lineup/?contract=new&ref=topticker)

[Y!mobile](https://www.ymobile.jp/)

- [料金](https://www.ymobile.jp/plan/)
- [製品](https://www.ymobile.jp/lineup/)
- [SIM/eSIM](https://www.ymobile.jp/store/sp/sim/)
- [サービス](https://www.ymobile.jp/service/)
- [会員クーポン](https://www.ymobile.jp/service/ymobile/premium/#coupon-link)

- [お申し込み](https://www.ymobile.jp/select_contract/)
- [ログイン](https://www.ymobile.jp/support/online/login/)
- [法人ご契約](https://www.ymobile.jp/biz/)
- メニュー

- [![](https://www.ymobile.jp/common_c/images/common/icon/icon_home.svg)ホーム](https://www.ymobile.jp/)
- 料金プラン

# 料金プラン

シンプル3（スマートフォン/SIM）


![親子割](https://www.ymobile.jp/plan/common/images/mv_oyako.webp)

親子割を適用する税抜- _1,000_ 円/月（-1,100円/月）

[親子割の詳細はこちら](https://www.ymobile.jp/sp/oyako/)

- [S](https://www.ymobile.jp/plan/#plan-s)
- [M](https://www.ymobile.jp/plan/#plan-m)
- [L](https://www.ymobile.jp/plan/#plan-l)

データ量増量！＊

シンプル3 S

SoftBank Airに加入PayPayカードゴールド支払いで

親子割対象外

月額基本使用料

税抜 2,780円

（3,058円）

割引後料金

_**翌月から**_

_税抜_ 780円（858円）

月額基本使用料

税抜 2,780円

（3,058円）

割引後2回線目料金

_**翌月から**_

_税抜_ 円（円）

1回線目

_**翌月から**_

_税抜_ 円（円）

割引内訳

シンプル3 S 基本使用料税抜2,780円/月

_PayPayカード ゴールド_※1税抜 -500円/月

_おうち割光セット（A）_※2税抜 -1,500円/月

SoftBank Air加入例 5,368円/月。家族割引等併用不可。おうち割 光セット（A）等併用不可。 家族割引等併用不可。 _シンプル3 Sは対象外。_PayPayカード ゴールド年会費11,000円要。
通話料・端末代別途要


詳細を見る

PayPayカード割※1PayPayカード ゴールド税抜- _500_ 円/月

**(- _550_ 円/月)**PayPayカード税抜- _300_ 円/月

**(- _330_ 円/月)**割引サービス 重複割引不可※2おうち割 光セット（A）税抜- _1,500_ 円/月

**(- _1,650_ 円/月)**おうち割 でんきセット（E）

_※シンプル3 S対象外_税抜- _1,000_ 円/月

**(- _1,100_ 円/月)**家族割引(2回線目以降)税抜- _1,000_ 円/月

**(- _1,100_ 円/月)**

- ※1 PayPayカード ゴールド年会費11,000円要。通常カードの場合は300円（330円）割引 。家族カードも対象です。
- ※2 「おうち割 光セット（A）」、「おうち割 でんきセット（E）」、「家族割引サービス」は重複して割引はされません。

通話料金

通話オプションなし

_20_ 円( _22_ 円)/ _30_ 秒

だれとでも定額+

税抜 _800_ 円/月( _880_ 円)

に加入で10分間

国内通話かけ放題

スーパーだれとでも定額+

税抜 _1,800_ 円/月( _1,980_ 円)

国内通話24時間無料

_60_ 歳以上

通話ずーっと割引キャンペーン _1,100_ 円引き _880_ 円

- ●通話料・端末代別途要
- ※ 月途中に本オプションに加入または解除する場合、月額料金を日割り計算しません。


月途中に本オプション加入（新規契約と同時を除く）または解除の申込をした場合、翌月から適用となります。


本オプション対象外の料金プランへ変更をされる場合、本オプションは自動解除となります。

閉じる

たっぷり使えてこの価格！

シンプル3 M親子割

対象

SoftBank Airに加入PayPayカードゴールド支払いで

親子割適用で翌月から12ヵ月間

月額基本使用料

税抜 3,780円

（4,158円）

2年間割引後料金

_**翌月から**_

_税抜_ 1,780円（1,958円）

月額基本使用料

税抜 3,780円

（4,158円）

割引後2回線目料金

_**翌月から**_

_税抜_ 円（円）

1回線目

_**翌月から**_

_税抜_ 円（円）

割引内訳

シンプル3 M 基本使用料税抜3,780円/月

_PayPayカード ゴールド_※1税抜 -500円/月

_おうち割光セット（A）_※2税抜 -1,500円/月

_親子割(最大13ヶ月間)_税抜 -1,000円/月

SoftBank Air加入例 5,368円/月。家族割引等併用不可。おうち割 光セット（A）等併用不可。 家族割引等併用不可。 _シンプル3 Sは対象外。_PayPayカード ゴールド年会費11,000円要。
通話料・端末代別途要


詳細を見る

PayPayカード割※1PayPayカード ゴールド税抜- _500_ 円/月

**(- _550_ 円/月)**PayPayカード税抜- _300_ 円/月

**(- _330_ 円/月)**割引サービス 重複割引不可※2おうち割 光セット（A）税抜- _1,500_ 円/月

**(- _1,650_ 円/月)**おうち割 でんきセット（E）

_※シンプル3 S対象外_税抜- _1,000_ 円/月

**(- _1,100_ 円/月)**家族割引(2回線目以降)税抜- _1,000_ 円/月

**(- _1,100_ 円/月)**

親子割

5歳以上18歳以下のお客様（ご使用者）とその家族が対象

![最大13ヵ月間割引！親も子も超おトク！ワイモバ親子割](https://www.ymobile.jp/plan/common/images/img-oyako.webp)

親子割税抜- _1,000_ 円/月

**(- _1,100_ 円/月)**

[![親子割と合わせてWでおトク！お子様向け新規ご契約でおトクなオンライン限定キャンペーン開催中！](https://www.ymobile.jp/plan/common/images/tuika_plan_sp.webp)](https://www.ymobile.jp/store/sp/tsuika/?ref=plan)

- ※1 PayPayカード ゴールド年会費11,000円要。通常カードの場合は300円（330円）割引 。家族カードも対象です。
- ※2 「おうち割 光セット（A）」、「おうち割 でんきセット（E）」、「家族割引サービス」は重複して割引はされません。

通話料金

通話オプションなし

_20_ 円( _22_ 円)/ _30_ 秒

だれとでも定額+

税抜 _800_ 円/月( _880_ 円)

に加入で10分間

国内通話かけ放題

スーパーだれとでも定額+

税抜 _1,800_ 円/月( _1,980_ 円)

国内通話24時間無料

_60_ 歳以上

通話ずーっと割引キャンペーン _1,100_ 円引き _880_ 円

- ●通話料・端末代別途要
- ※ 月途中に本オプションに加入または解除する場合、月額料金を日割り計算しません。


月途中に本オプション加入（新規契約と同時を除く）または解除の申込をした場合、翌月から適用となります。


本オプション対象外の料金プランへ変更をされる場合、本オプションは自動解除となります。

閉じる

10分以内国内通話かけ放題コミ

シンプル3 L親子割

対象

SoftBank Airに加入PayPayカードゴールド支払いで

親子割適用で翌月から12ヵ月間

月額基本使用料

税抜 4,780円

（5,258円）

2年間割引後料金

_**翌月から**_

_税抜_ 2,780円（3,058円）

月額基本使用料

税抜 4,780円

（5,258円）

割引後2回線目料金

_**翌月から**_

_税抜_ 円（円）

1回線目

_**翌月から**_

_税抜_ 円（円）

割引内訳

シンプル3 L 基本使用料税抜4,780円/月

_PayPayカード ゴールド_※1税抜 -500円/月

_おうち割光セット（A）_※2税抜 -1,500円/月

_親子割(最大13ヶ月間)_税抜 -1,000円/月

SoftBank Air加入例 5,368円/月。家族割引等併用不可。おうち割 光セット（A）等併用不可。 家族割引等併用不可。 _シンプル3 Sは対象外。_PayPayカード ゴールド年会費11,000円要。
通話料・端末代別途要


詳細を見る

PayPayカード割※1PayPayカード ゴールド税抜- _500_ 円/月

**(- _550_ 円/月)**PayPayカード税抜- _300_ 円/月

**(- _330_ 円/月)**割引サービス 重複割引不可※2おうち割 光セット（A）税抜- _1,500_ 円/月

**(- _1,650_ 円/月)**おうち割 でんきセット（E）

_※シンプル3 S対象外_税抜- _1,000_ 円/月

**(- _1,100_ 円/月)**家族割引(2回線目以降)税抜- _1,000_ 円/月

**(- _1,100_ 円/月)**

親子割

5歳以上18歳以下のお客様（ご使用者）とその家族が対象

![最大13ヵ月間割引！親も子も超おトク！ワイモバ親子割](https://www.ymobile.jp/plan/common/images/img-oyako.webp)

親子割税抜- _1,000_ 円/月

**(- _1,100_ 円/月)**

[![親子割と合わせてWでおトク！お子様向け新規ご契約でおトクなオンライン限定キャンペーン開催中！](https://www.ymobile.jp/plan/common/images/tuika_plan_sp.webp)](https://www.ymobile.jp/store/sp/tsuika/?ref=plan)

- ※1 PayPayカード ゴールド年会費11,000円要。通常カードの場合は300円（330円）割引 。家族カードも対象です。
- ※2 「おうち割 光セット（A）」、「おうち割 でんきセット（E）」、「家族割引サービス」は重複して割引はされません。

通話料金

10分間国内通話かけ放題

10分超えた場合、20円(22円)/30秒

スーパーだれとでも定額+（L）

税抜 _1,000_ 円/月( _1,100_ 円)

国内通話24時間無料

_60_ 歳以上

通話ずーっと割引キャンペーン _1,100_ 円引き _0_ 円

- ●通話料・端末代別途要
- ※ 月途中に本オプションに加入または解除する場合、月額料金を日割り計算しません。


月途中に本オプション加入（新規契約と同時を除く）または解除の申込をした場合、翌月から適用となります。


本オプション対象外の料金プランへ変更をされる場合、本オプションは自動解除となります。

閉じる

SoftBank Air加入例 5,368円/月。家族割引等併用不可。おうち割 光セット（A）等併用不可。 家族割引等併用不可。 _シンプル3 Sは対象外。_PayPayカード ゴールド年会費11,000円要。
通話料・端末代別途要


### 割引サービス

PayPayカード割※1PayPayカード ゴールド税抜- _500_ 円/月

**(- _550_ 円/月)**PayPayカード税抜- _300_ 円/月

**(- _330_ 円/月)**

割引サービス 重複割引不可※2おうち割 光セット（A）税抜- _1,500_ 円/月

**(- _1,650_ 円/月)**おうち割 でんきセット（E）

_※シンプル3 S対象外_税抜- _1,000_ 円/月

**(- _1,100_ 円/月)**家族割引(2回線目以降)税抜- _1,000_ 円/月

**(- _1,100_ 円/月)**

シンプル3 S

親子割対象外

### 親子割

5歳以上18歳以下のお客様（ご使用者）とその家族が対象

![最大13ヵ月間割引！親も子も超おトク！ワイモバ親子割](https://www.ymobile.jp/plan/common/images/img-oyako.webp)

親子割税抜- _1,000_ 円/月

**(- _1,100_ 円/月)**

[![親子割と合わせてWでおトク！お子様向け新規ご契約でおトクなオンライン限定キャンペーン開催中！](https://www.ymobile.jp/plan/common/images/tuika_plan.webp)](https://www.ymobile.jp/store/sp/tsuika/?ref=plan)

通話料金

通話オプションなし

_20_ 円( _22_ 円)/ _30_ 秒

だれとでも定額+

税抜 _800_ 円/月( _880_ 円)に加入で10分間国内通話かけ放題

スーパーだれとでも定額+

税抜 _1,800_ 円/月( _1,980_ 円) 国内通話24時間無料

_60_ 歳以上 通話ずーっと割引キャンペーン _1,100_ 円引き _880_ 円

通話料金

10分間国内通話かけ放題

10分超えた場合、20円(22円)/30秒

スーパーだれとでも定額+（L）

税抜 _1,000_ 円/月( _1,100_ 円)

国内通話24時間無料

_60_ 歳以上 通話ずーっと割引キャンペーン

_1,100_ 円引き _0_ 円

- ※1 PayPayカード ゴールド年会費11,000円要。通常カードの場合は300円（330円）割引 。家族カードも対象です。
- ※2 「おうち割 光セット（A）」、「おうち割 でんきセット（E）」、「家族割引サービス」は重複して割引はされません。
- ＊ シンプル2 Sと比べて。

### 割引サービス

- [通信料金をPayPayカードで\\
\\
支払うとおトク！\\
\\
![PayPayカード割](https://www.ymobile.jp/plan/smartphone/images/waribiki_ppcard_sp.png?20250225)PayPayカード割詳細をみる](https://www.ymobile.jp/sp/paypay-card/)
- [おうちの\\
\\
ネットとセットでおトク\\
\\
![おうち割 光セット（A）](https://www.ymobile.jp/plan/smartphone/images/waribiki_ouchi_sp.png?20251020)おうち割 光セット（A）詳細をみる](https://www.ymobile.jp/plan/discount/hikarisetwari/)
- [遠方の親戚、\\
\\
同居している恋人も対象！\\
\\
![家族割引サービス](https://www.ymobile.jp/plan/smartphone/images/waribiki_kazoku_sp.png?20250225)家族割引サービス詳細をみる](https://www.ymobile.jp/plan/discount/kazokuwari/)
- [おうちの\\
\\
でんきとセットでおトク\\
\\
![おうちでんき](https://www.ymobile.jp/plan/smartphone/images/waribiki_denki_sp.png)おうち割 でんきセット（E）詳細をみる](https://www.ymobile.jp/plan/discount/ouchiwari/?tab=denki#tab-ouchi)

【その他の注記事項】

シンプル3


●国内通話は30秒につき22円かかります。

●シンプル3 Lの場合、携帯電話・固定電話（IP電話含む）への1回あたり10分以内の国内通話が追加料金なしでご利用できます。

当社が長時間通話と判断した通話については、その通話を切断することがあります。

シンプル3 Lに申し込みした際、「留守番電話プラス」「一定額ストップサービス」「割込通話」および「グループ通話」は、追加料金なしでご利用できます。

各サービスのご利用には別途お申し込みが必要です。

各サービスをご利用中に、シンプル3 S/Mにプラン変更した場合、翌月から各サービスの月額料金が発生します。ご利用にならない場合には、別途、解除のお手続きが必要です。

●国際ローミング･国際電話（海外への通話）・衛星電話宛通話料・0570等から始まる他社が料金設定している電話番号への通話料・番号案内（104）など、一部対象外の通話があります。NTTドコモが提供する衛星電話サービス（ワイドスター）宛の通話は177.1円／30秒となります。

●国内SMSは送信文字数に応じて1回あたり3.3～33円です。詳細は当社約款等をご確認ください。

● [契約事務手数料（店頭：4,950円　オンライン：3,850円）がかかります。](https://www.ymobile.jp/plan/commission/)

ユニバーサルサービス料、電話リレーサービス料が別途かかります。

●留守番電話サービスを利用する場合は別途留守番電話プラスへの加入が必要です。

●当月ご利用のデータ通信量が規定容量（5GB/30GB/35GB）とデータ増量オプションで追加されたデータ容量（データ増量オプション加入者のみ。

2GB/5GB/5GB）の合計を超えた場合、当月末までデータ通信速度の低速化（送受信時について、シンプル3 Sは最大300kbps、シンプル3 M/Lは1Mbps）を行います。更に規定容量の半分（2.5GB/15GB/17.5GB）を消費した場合、当月末までデータ通信速度の低速化（送受信時について最大128kbps）を行います。


国内通話10分以内かけ放題/だれとでも定額＋


●国際ローミング・国際電話（海外への通話）・衛星電話宛通話料・留守番電話センターへの通話料（再生時等1416）・着信転送サービスにおける転送先への通話料・ナビダイヤル（0570）・番号案内（104）・当社が指定し別途公表する電話番号（ymobile.jp/r/telephone/）など、一部対象外の通話があります。

●当社が不正な長時間通話と判断した際、通話を切断する場合があります。

●対象外の料金プランへプラン変更をされる場合、本オプションは自動解除となります。

●以下に該当する通話を行ったと当社が判断した場合、当社の指定日をもって当サービスは解除、または当該通話について利用の中止を行います。

・ 事前に当社の許可なく、電話機を機器や設備に接続して利用すること

・ 通信の媒介・転送機能の利用、または他社が提供するサービスへの接続などで、通信による直接収入を得る目的で利用をすること。

・ ソフトウェアやコンピュータプログラミングなど（当社または当社が認める電気通信事業者が提供するものを除く）を用いて、自動的に発信された通話。

・ 通話以外の用途において利用する通信。

●シンプル3 Lの場合はだれとでも定額＋に申し込み不要で10分以内の国内通話が追加料金なしで利用可能。


おうち割 光セット（A）


【加入例】SoftBank 光ファミリーの場合、基本料金5,720円/月+指定オプション550 円/月～が別途必要です。（2年自動更新プラン:2022年7月1日以降の契約者は、契約期間満了月の当月・翌月・翌々月以外での解約には解除料5,720円が必要。詳しくは [こちら](https://www.softbank.jp/internet/cancellation-fee/)）。

●SoftBank光自動更新なしプランは対象外。

●固定通信サービス1回線につき携帯電話回線（スマートフォン/ケータイ/タブレット/モバイルWi-Fiルーター）最大10回線まで適用。

●シンプル S/M/Lは毎月1,188円割引、シンプル2 Sは毎月1,100円割引、シンプル2 M/Lは毎月1,650円割引、スマホベーシックプラン S/M/R/L、データベーシックプラン L、Pocket WiFi®プラン 2（ベーシック）、スマホプラン S、データプラン L、Pocket WiFi®プラン 2は毎月550円割引、スマホプラン M/Rは毎月770円割引、スマホプラン Lは毎月1,100円割引します。

●｢家族割引｣、「おうち割 光セット（A）」、「おうち割 でんきセット（E）」は重複して割引はされません。


おうち割 でんきセット（E）


「シンプル3 S」は対象外です。

※下記の①②の条件を初めて満たした場合の「対象請求月」を1カ月目（以下「適用開始月」）として、24カ月目まで割引を適用します。適用開始月はMy Y!mobileなどでご確認いただけます。

①ソフトバンク株式会社が定める月次判定時に「おうち割 でんきセット（E）」への加入が確認できること

②当該月次判定時が含まれるモバイル通信サービスの請求月（「対象請求月」）の前月に対象電力サービスの料金が確定していること

※対象電力サービス1契約につき、最大10回線まで“ワイモバイル”の対象料金プランの回線を指定することが可能です。

※「家族割引サービス」「おうち割 光セット（A）」「おうち割 光セット（A）申込特典」などと重複して、「おうち割 でんきセット（E）」に加入した場合、割引額の大きい方の特典（割引額が同額の場合はいずれかの特典のみ）が適用され、「おうち割 でんきセット（E）」による割引は適用されない場合があります。適用状況は請求金額確定後にMy Y!mobileでご確認ください。なお、他の割引との重複などにより一時的に「おうち割 でんきセット（E）」の割引が適用されない期間が生じた場合も、24カ月の適用期間は継続してカウントされます。

※東北電力対象プラン、北陸電力対象プランおよび九州電力対象プランは、同等の割引が受けられる別のサービスを提供しています。


PayPayカード割


●適用条件：請求締日時点で、

①対象のデータプランに加入していること

②対象データプランのお支払い方法に「PayPayカード」または「PayPayカードゴールド」を設定していること

③個人名義による契約であること

※設定してもカード停止等により決済が行われず、振込用紙およびソフトバンク・ワイモバイル店頭にてカードで決済された場合は対象外です。

●本割引サービスは、適用条件を満たした当該請求月から適用します。

なお、以下に該当する場合等、お支払い方法の変更の適用がお手続き翌請求月となる場合があります。

その場合は、適用条件を満たした翌請求月から適用します。割引対象データプランの定額料が日割となる場合、本割引サービスの割引額は日割となります（1円未満の端数が生じた場合は、その端数を切り上げます）。

●PayPayカード330円割引/PayPayカードゴールド550円割引。

●PayPayカード ゴールド年会費11,000円（税込）要。

●家族カードも対象です。

●請求代行サービスを利用している場合、適用されません。

●譲渡・承継又は解約された場合等は、前請求月で割引は終了します。解約された場合は、解約日の属する請求月も割引が適用されます。


ワイモバ親子割


●受付期間中に、お申し込み時の使用者年齢が5～18歳で新規、他社からののりかえ（MNP）、ソフトバンクまたはLINEMOからの番号移行、契約変更、プラン変更にてシンプル3 M/Lへご契約いただくと、適用条件を満たした月を1ヵ月目として13ヵ月目まで基本使用料を毎月1,100円割引します。 ●My Y!mobile等でプラン変更のお申し込みをされる場合は、事前にMy Y!mobileにてワイモバ親子割のお申し込み手続きを行い、手続き完了のSMSが送付された後にプラン変更をお申し込みいただく必要があります。（すでに使用者の情報をご登録済みで、かつ当社で使用者と契約者が同じとみなした場合、手続き完了のSMSは配信されません。My Y!mobileにて本キャンペーンのお申し込み手続き後、そのままプラン変更をお申し込みいただけます。)


ワイモバ親子割（家族）

●受付期間中に、新規、他社からののりかえ（MNP）、ソフトバンクまたはLINEMOからの番号移行、契約変更、プラン変更にてシンプル3 M/Lへご契約いただき、ワイモバ親子割が適用されている回線と同一グループの家族割引サービス（主回線または副回線）に加入された場合、適用条件を満たした月を1ヵ月目として13ヵ月目まで基本使用料を毎月1,100円割引します。


ワイモバ親子割・ワイモバ親子割（家族）共通注意事項

●シンプル3 Sは本キャンペーンの割引対象外プランです。 ●プラン変更のお申し込みの場合、シンプル3 M/L間のプラン変更も対象です。 ●プラン変更以外でのご契約の場合、ご契約月は割引額を日割りします。 ●譲渡した月は割引額を日割りします。 ●本キャンペーンの内容および期間は、予告なく変更する場合があります。

●契約事務手数料3,850円、ユニバーサルサービス料、電話リレーサービス料が別途かかります。 ●表示価格は特に断りがない限り税込です。●本キャンペーンの内容および期間は、予告なく変更する場合があります。


## シンプル3のおトクな特典追加料金なしでつかえる！

![](https://www.ymobile.jp/sp/simple3/images/icon_abroad.webp)海外でもおトクに使える！

国際ローミング


申込：不要（世界対応ケータイの加入必須）

月額料：追加料金なし(通話料あり)

2026年夏以降提供開始予定

海外での高速データ通信

![毎月2GBまで追加料金なしで使える](https://www.ymobile.jp/sp/simple3/images/img_roaming.webp)

SIMのみの新規契約は5ヵ月目以降

提供開始まで


2025年9月25日～2026年夏頃までは [海外あんしん定額（定額国L）](https://www.ymobile.jp/sp/p_guide/data/web/etc06/) 3GB/24時間 980円（不課税）


1ヵ月あたり最大7日分（6,860円）が追加料金なしでご利用いただけます。


※ 対象国・地域で利用可。通話/SMSは有料。

・海外でご利用の音声通話、SMS及び国際SMSは、対象外です。

・2026年夏以降に提供開始してからは、シンプル3では海外あんしん定額（定額国L）及び海外パケットし放題をご利用できません。

・SIMのみで新規契約された方は、契約月から4ヵ月間は、海外でのデータ通信をご利用になれません。

・世界対応ケータイに加入していることが必要

・具体的な提供開始時期は、追って当社ウェブサイト等でお知らせします。


【注記事項】


・2GB/月を超過した場合、通信速度を送受信時最大128Kbpsに制限します。2GB/月を超過した場合は、1,000円/GB（不課税）で追加データ容量を購入します。

・機種によっては、渡航先の国/地域の法令などにより、持ち込みなどが禁止されている場合があります。事前に渡航先の規制をご確認ください。

・次のいずれかに該当する場合、それぞれ次に定める日（日本時間）をもって、海外でのデータ通信ができなくなります。

(1)世界対応ケータイが適用されなくなった場合世界対応ケータイの適用が終了した日

(2)回線を解約等により終了した場合回線の終了日

・当社指定の海外通信事業者へ優先的に接続の上、本サービスを提供する場合及び一部の海外通信事業者について、お客さまが接続先として選択できない場合があります。

・2026年夏以降提供開始予定。


LYPプレミアムで

対象のLINEスタンプ使い放題！

申込：不要（アカウント連携が必要）

月額料：追加料金なし

※通常、月額料金508円

![LYPプレミアム](https://www.ymobile.jp/service/common/images/img-lyp.png)

例えばこんな特典が使い放題

- ![](https://www.ymobile.jp/service/common/images/img-lyp-01.png)

LINEで1,500万種類以上の

対象スタンプが使い放題※1

- ![](https://www.ymobile.jp/service/common/images/img-lyp-02.png)

ヤフーショッピング 毎日7％※2

- ![](https://www.ymobile.jp/service/common/images/img-lyp-03.png)

会員限定PayPayクーポンが使える！


[詳細はこちら](https://www.ymobile.jp/service/ymobile/premium/)

※1 スタンプは最大5パッケージ保有可能。

※2 通常ポイント0.5％＋期間限定ポイント6.5％

付与上限5,000pt/月。各キャンペーンの合計であり、それぞれ対象金額・付与条件が異なる。端数処理やショッピングクーポン使用により7%にならない場合あり。Y!mobileサービスの初期登録とLINEアカウント連携が必要。詳しくは [こちら。](https://shopping.yahoo.co.jp/promotion/campaign/ppevr5/?pre=on)

![](https://www.ymobile.jp/plan/common/images/icon_data.png)データが余ってもくりこせる！

申込：不要

月額料：無料

余ったデータは無料で自動的に

翌月にくりこしで無駄がありません！

![](https://www.ymobile.jp/sp/simple3/images/img_kurikoshi.webp)

・翌月へくりこしできるデータ容量の上限は、翌月加入のプランのデータ容量（データ増量オプションによる追加分を含む）まで。

・ 対象外プランへ変更された場合、くりこしされません。

・ シェアプランについて、親回線とデータ容量を分け合っている期間（シェア適用中）はデータがくりこしできます。ただし、親回線とのシェアが開始になる前月およびシェアが解除になる最終月の余ったデータ容量は翌月にくりこしされません。

・くりこしできるのは、規程容量とデータ増量オプションで追加したデータ容量のみであり、通常速度に戻す申し込みで追加購入されたデータ容量はくりこしできません。くりこしされるデータは100MB未満は切捨てとなります。

・データ容量はくりこし分＞規定容量（データ増量オプションによるデータ増量を含む）＞追加購入データ量の順に消費されます。


## キャンペーン

![](https://www.ymobile.jp/sp/simple3/images/icon_shopping.webp)毎月ギガがもらえる！

PayPay使ってギガ増量キャンペーン

2025年11月1日（土）～提供開始

毎月ギガもらえる

キャンペーン

200円以上のPayPay決済回数(クレジット/残高/ポイント)に応じ

翌月にギガもらえる


![シンプル3 S/M/L 決算回数](https://www.ymobile.jp/sp/simple3/images/img_paypay_table.webp)

・追加データくりこし不可

・特典付与には、決済月と特典付与月に対象プランに加入していることが必要です。

・本特典の適用には、PayPayアプリとのアカウント連携が必要です。

・増量するギガ数は受取月に適用されているプランで決定

・通信料等カウント対象外の決済あり。キャンペーン内容は変更の可能性あり。終了時期未定。


[詳細はこちら](https://www.ymobile.jp/cp/ppgigazoryo/)

[![30秒でできる](https://www.ymobile.jp/plan/smartphone/images/btn_float.png)![30秒でできる](https://www.ymobile.jp/plan/smartphone/images/btn_cta.png)料金シミュレーション](https://www.ymobile.jp/sp/simulation/)

## お申込みはショップ・オンラインストアで

[かんたん来店予約](https://www.ymobile.jp/shop/reservation/about/)

[オンラインストア](https://www.ymobile.jp/store/)

[プラン変更やオプション追加はこちら](https://my.ymobile.jp/muc/d/webLink/doSend/MWBWL0030)

[その他ケータイ/Poket WiFiの料金はこちら](https://www.ymobile.jp/plan/#others)

## おすすめオプション

- ### スマホをさまざまな危険や  トラブルから守る  セキュリティパックプレミアム



![](https://www.ymobile.jp/plan/smartphone/images/option_security_sp.png?20250225)




税抜 700円/月 (770円/月)





初月無料





| S | M | L |
| --- | --- | --- |
| 税抜 700円/月 (770円/月) |




※ セキュリティパックプレミアムは別途お申し込みが必要です




[詳しく見る](https://www.ymobile.jp/service/security_packpremium/)

- ### 初めての加入で  6ヵ月無料！  データ増量オプション



![](https://www.ymobile.jp/plan/smartphone/images/option_datazoryo_sp.png?20250225)




税抜 500円/月 (550円/月)





初めての加入で6ヵ月間無料！



オプション加入時の月間追加データ量




| S | M | L |
| --- | --- | --- |
| +2GB | +5GB | +5GB |




初めてのデータ増量オプションを申し込みして契約した場合、データ増量オプションの月額料が６ヵ月間無料になるキャンペーンです。


※ 月途中の加入・解約の場合でも、月額料の日割り計算は行いません。


新規契約と同時にお申し込みの場合、お申し込み当月から適用になります。それ以外のお申し込みの場合、お申し込み翌月からの適用となります。




[詳しく見る](https://www.ymobile.jp/plan/option/datazoryo/)


## 割引サービス

- おうちのネットと

セットでおトク





![おうち割 光セット（A）](https://www.ymobile.jp/plan/smartphone/images/waribiki_ouchi_sp.png?20251021)




おうち割 光セット（A）





シンプル3 S/M/Lご契約で





税抜 1,500円/月割引


(1,650円/月)





家族割引・おうち割 でんきセット（E）は重複して割引はされません。




【加入例】SoftBank 光ファミリーの場合、基本料金5,720円/月+指定オプション550円/月～が別途必要です。（2年自動更新プラン:2022年7月1日以降の契約者は、契約期間満了月の当月・翌月・翌々月以外での解約には解除料5,720円が必要）



その他注意事項




●SoftBank 光自動更新なしプランは対象外。


●固定通信サービス1回線につき携帯電話回線（スマートフォン/ケータイ/タブレット/モバイルWi-Fiルーター）最大10回線まで適用。


●シンプル S/M/Lは毎月1,188円割引、シンプル2 Sは毎月1,100円割引、シンプル2 M/Lは毎月1,650円割引、スマホベーシックプラン S/M/R/L、データベーシックプラン L、Pocket WiFi®プラン 2（ベーシック）、スマホプラン S、データプラン L、Pocket WiFi®プラン 2は毎月550円割引、スマホプラン M/Rは毎月770円割引、スマホプラン Lは毎月1,100円割引します。




[詳しく見る](https://www.ymobile.jp/plan/discount/hikarisetwari/)

- おうちのでんきと

セットでおトク





![おうちでんき](https://www.ymobile.jp/plan/smartphone/images/waribiki_denki_sp.png)




おうち割 でんきセット（E）





シンプル3 M/Lご契約で24ヵ月間




_税抜_ 1,000円/月割引


(1,100円/月)





シンプル3 Sは対象外、家族割引・おうち割 光セット（A）は重複して割引はされません。




[おうちでんきについて詳しく見る](https://www.softbank.jp/energy/special/ouchi-denki/?ouchiwari=ym&cid=ymw_2509_dkod_02&argument=jsl6aztR&dmai=a68d4fe256a549)



[おうち割 でんきセット（E）について詳しく見る](https://www.ymobile.jp/plan/discount/ouchiwari/?tab=denki#tab-ouchi)

- 遠方の親戚、同居

している恋人も対象！





![家族割引サービス](https://www.ymobile.jp/plan/smartphone/images/waribiki_kazoku_sp.png?20250225)




家族割引サービス





シンプル3 S/M/Lご契約で

2回線目以降一人あたり




税抜 1,000円/月割引


(1,100円/月)





おうち割 光セット（A）、でんきセット（E）は重複して割引はされません。





※ 最大9回線まで割引が適用




[詳しく見る](https://www.ymobile.jp/plan/discount/kazokuwari/)

- 通信料金をPayPayカードで

支払うとおトク！





![PayPayカード割](https://www.ymobile.jp/plan/smartphone/images/waribiki_ppcard_sp.png?20250225)




PayPayカード割








PayPayカード ゴールド

※年会費11,000円



税抜- **500** 円/月

（- **550** 円/月）割引







PayPayカード



税抜- **300** 円/月

（- **330** 円/月）割引







その他注意事項



※シンプル3 S/M/L が対象


※支払方法のカード種類を変更した場合、支払方法変更の手続きを行った当月の請求より変更後の割引額が適用


●適用条件：請求締日時点で、PayPayカード、PayPayカードゴールドが、ご利用料金のお支払い方法として適用されているとき。


●家族カードも対象です。


●請求代行サービスを利用している場合、適用されません。


●割引対象料金プランの基本使用料が日割となる場合、本割引サービスの割引額は日割となります。


●譲渡・承継された場合等は、前請求月で割引は終了します。

解約された場合は、解約日の属する請求月も割引が適用されます。



[詳しく見る](https://www.ymobile.jp/sp/paypay-card/)

- おうちのネットと

セットでおトク





![おうち割 光セット（A）](https://www.ymobile.jp/plan/smartphone/images/waribiki_ouchi_sp.png?20251021)




おうち割 光セット（A）





シンプル3 S/M/Lご契約で





税抜 1,500円/月割引


(1,650円/月)





家族割引・おうち割 でんきセット（E）は重複して割引はされません。




【加入例】SoftBank 光ファミリーの場合、基本料金5,720円/月+指定オプション550円/月～が別途必要です。（2年自動更新プラン:2022年7月1日以降の契約者は、契約期間満了月の当月・翌月・翌々月以外での解約には解除料5,720円が必要）



その他注意事項




●SoftBank 光自動更新なしプランは対象外。


●固定通信サービス1回線につき携帯電話回線（スマートフォン/ケータイ/タブレット/モバイルWi-Fiルーター）最大10回線まで適用。


●シンプル S/M/Lは毎月1,188円割引、シンプル2 Sは毎月1,100円割引、シンプル2 M/Lは毎月1,650円割引、スマホベーシックプラン S/M/R/L、データベーシックプラン L、Pocket WiFi®プラン 2（ベーシック）、スマホプラン S、データプラン L、Pocket WiFi®プラン 2は毎月550円割引、スマホプラン M/Rは毎月770円割引、スマホプラン Lは毎月1,100円割引します。




[詳しく見る](https://www.ymobile.jp/plan/discount/hikarisetwari/)

- おうちのでんきと

セットでおトク





![おうちでんき](https://www.ymobile.jp/plan/smartphone/images/waribiki_denki_sp.png)




おうち割 でんきセット（E）





シンプル3 M/Lご契約で24ヵ月間




_税抜_ 1,000円/月割引


(1,100円/月)





シンプル3 Sは対象外、家族割引・おうち割 光セット（A）は重複して割引はされません。




[おうちでんきについて詳しく見る](https://www.softbank.jp/energy/special/ouchi-denki/?ouchiwari=ym&cid=ymw_2509_dkod_02&argument=jsl6aztR&dmai=a68d4fe256a549)



[おうち割 でんきセット（E）について詳しく見る](https://www.ymobile.jp/plan/discount/ouchiwari/?tab=denki#tab-ouchi)

- 遠方の親戚、同居

している恋人も対象！





![家族割引サービス](https://www.ymobile.jp/plan/smartphone/images/waribiki_kazoku_sp.png?20250225)




家族割引サービス





シンプル3 S/M/Lご契約で

2回線目以降一人あたり




税抜 1,000円/月割引


(1,100円/月)





おうち割 光セット（A）、でんきセット（E）は重複して割引はされません。





※ 最大9回線まで割引が適用




[詳しく見る](https://www.ymobile.jp/plan/discount/kazokuwari/)

- 通信料金をPayPayカードで

支払うとおトク！





![PayPayカード割](https://www.ymobile.jp/plan/smartphone/images/waribiki_ppcard_sp.png?20250225)




PayPayカード割








PayPayカード ゴールド

※年会費11,000円



税抜- **500** 円/月

（- **550** 円/月）割引







PayPayカード



税抜- **300** 円/月

（- **330** 円/月）割引







その他注意事項



※シンプル3 S/M/L が対象


※支払方法のカード種類を変更した場合、支払方法変更の手続きを行った当月の請求より変更後の割引額が適用


●適用条件：請求締日時点で、PayPayカード、PayPayカードゴールドが、ご利用料金のお支払い方法として適用されているとき。


●家族カードも対象です。


●請求代行サービスを利用している場合、適用されません。


●割引対象料金プランの基本使用料が日割となる場合、本割引サービスの割引額は日割となります。


●譲渡・承継された場合等は、前請求月で割引は終了します。

解約された場合は、解約日の属する請求月も割引が適用されます。



[詳しく見る](https://www.ymobile.jp/sp/paypay-card/)

- おうちのネットと

セットでおトク





![おうち割 光セット（A）](https://www.ymobile.jp/plan/smartphone/images/waribiki_ouchi_sp.png?20251021)




おうち割 光セット（A）





シンプル3 S/M/Lご契約で





税抜 1,500円/月割引


(1,650円/月)





家族割引・おうち割 でんきセット（E）は重複して割引はされません。




【加入例】SoftBank 光ファミリーの場合、基本料金5,720円/月+指定オプション550円/月～が別途必要です。（2年自動更新プラン:2022年7月1日以降の契約者は、契約期間満了月の当月・翌月・翌々月以外での解約には解除料5,720円が必要）



その他注意事項




●SoftBank 光自動更新なしプランは対象外。


●固定通信サービス1回線につき携帯電話回線（スマートフォン/ケータイ/タブレット/モバイルWi-Fiルーター）最大10回線まで適用。


●シンプル S/M/Lは毎月1,188円割引、シンプル2 Sは毎月1,100円割引、シンプル2 M/Lは毎月1,650円割引、スマホベーシックプラン S/M/R/L、データベーシックプラン L、Pocket WiFi®プラン 2（ベーシック）、スマホプラン S、データプラン L、Pocket WiFi®プラン 2は毎月550円割引、スマホプラン M/Rは毎月770円割引、スマホプラン Lは毎月1,100円割引します。




[詳しく見る](https://www.ymobile.jp/plan/discount/hikarisetwari/)

- おうちのでんきと

セットでおトク





![おうちでんき](https://www.ymobile.jp/plan/smartphone/images/waribiki_denki_sp.png)




おうち割 でんきセット（E）





シンプル3 M/Lご契約で24ヵ月間




_税抜_ 1,000円/月割引


(1,100円/月)





シンプル3 Sは対象外、家族割引・おうち割 光セット（A）は重複して割引はされません。




[おうちでんきについて詳しく見る](https://www.softbank.jp/energy/special/ouchi-denki/?ouchiwari=ym&cid=ymw_2509_dkod_02&argument=jsl6aztR&dmai=a68d4fe256a549)



[おうち割 でんきセット（E）について詳しく見る](https://www.ymobile.jp/plan/discount/ouchiwari/?tab=denki#tab-ouchi)

- 遠方の親戚、同居

している恋人も対象！





![家族割引サービス](https://www.ymobile.jp/plan/smartphone/images/waribiki_kazoku_sp.png?20250225)




家族割引サービス





シンプル3 S/M/Lご契約で

2回線目以降一人あたり




税抜 1,000円/月割引


(1,100円/月)





おうち割 光セット（A）、でんきセット（E）は重複して割引はされません。





※ 最大9回線まで割引が適用




[詳しく見る](https://www.ymobile.jp/plan/discount/kazokuwari/)

- 通信料金をPayPayカードで

支払うとおトク！





![PayPayカード割](https://www.ymobile.jp/plan/smartphone/images/waribiki_ppcard_sp.png?20250225)




PayPayカード割








PayPayカード ゴールド

※年会費11,000円



税抜- **500** 円/月

（- **550** 円/月）割引







PayPayカード



税抜- **300** 円/月

（- **330** 円/月）割引







その他注意事項



※シンプル3 S/M/L が対象


※支払方法のカード種類を変更した場合、支払方法変更の手続きを行った当月の請求より変更後の割引額が適用


●適用条件：請求締日時点で、PayPayカード、PayPayカードゴールドが、ご利用料金のお支払い方法として適用されているとき。


●家族カードも対象です。


●請求代行サービスを利用している場合、適用されません。


●割引対象料金プランの基本使用料が日割となる場合、本割引サービスの割引額は日割となります。


●譲渡・承継された場合等は、前請求月で割引は終了します。

解約された場合は、解約日の属する請求月も割引が適用されます。



[詳しく見る](https://www.ymobile.jp/sp/paypay-card/)


## その他の料金プラン

[![](https://www.ymobile.jp/plan/images/pict_plantop_tablet2.png)\\
\\
データ容量を無駄なく分ける\\
\\
**シェアプラン  （子回線専用）** \\
\\
月々 0円～](https://www.ymobile.jp/plan/smartphone/shareplan/)

[![](https://www.ymobile.jp/plan/images/pict_plantop_pocketwifi1.png)\\
\\
たっぷり使うなら\\
\\
**Pocket WiFi®  プラン2  （ベーシック）** \\
\\
月々 4,065.6円～](https://www.ymobile.jp/plan/data/pocketwifi_2/)

[![](https://www.ymobile.jp/plan/images/pict_plantop_pocketwifi3.png)\\
\\
海外でもお得に使うなら\\
\\
**Pocket WiFi®  海外データ定額** \\
\\
月々 4,065.6円～](https://www.ymobile.jp/plan/data/pocketwifi_global/)

### その他

[割引サービス](https://www.ymobile.jp/plan/discount/) [オプションサービス](https://www.ymobile.jp/service/) [各種手数料](https://www.ymobile.jp/plan/commission/) [受付/提供終了プラン・割引](https://www.ymobile.jp/plan/old/)

会社のスマホもワイモバイルで

法人契約割引3なら

2回線以上の契約で

ずーっと毎月1,000円（税抜）割引！

[詳しくはこちら](https://www.ymobile.jp/biz/plan/houjinkeiyakuwari2/)

※表示価格は特に記載がない限り税込です。

消費税の計算上、請求金額と異なる場合があります。

[![30秒でできる](https://www.ymobile.jp/plan/smartphone/images/btn_float.png)![30秒でできる](https://www.ymobile.jp/plan/smartphone/images/btn_cta.png)料金シミュレーション](https://www.ymobile.jp/sp/simulation/)

×

![ワイモバ親子割](https://www.ymobile.jp/plan/smartphone/images/waribiki_oyako2025.png)

シンプル3 M/Lの場合


税抜 1,000円/月割引

(1,100円/月)


学生（5歳以上18歳以下のお客様（ご使用者））とその家族が対象

ワイモバ親子割

●シンプル3 Sは本キャンペーンの割引対象外プランです。

●プラン変更のお申し込みの場合、シンプル3 M/L間のプラン変更も対象です。

●プラン変更以外でのご契約の場合、ご契約月は割引額を日割りします。

●譲渡した月は割引額を日割りします。


[詳しく見る](https://www.ymobile.jp/sp/oyako/)

×

遠方の親戚、同居している恋人も対象！

![ワイモバ親子割](https://www.ymobile.jp/plan/smartphone/images/waribiki_oyako.png?20250225)

シンプル2 M/Lの場合


税抜 1,000円/月割引

(1,100円/月)


学生（5歳以上18歳以下のお客様（ご使用者））とその家族が対象


●シンプル2 Sは本キャンペーンの割引対象外プランです。

●プラン変更のお申し込みの場合、シンプル2 M/L間のプラン変更も対象です。

●プラン変更以外でのご契約の場合、ご契約月は割引額を日割りします。

●譲渡した月は割引額を日割りします。

●シンプル2 M/Lの総データ使用量が1GB/月以下の割引が適用される月は、本割引は適用されません。この場合でも、本割引の割引金額は翌月に繰り越しいたしません。また当月も割引適用期間としてカウントします。


[詳しく見る](https://www.ymobile.jp/sp/oyako/)

×

おうちのネットとセットでおトク

![おうち割 光セット（A）](https://www.ymobile.jp/plan/smartphone/images/waribiki_ouchi_sp.png?20251021)

おうち割 光セット（A）


シンプル3 S/M/Lご契約で


税抜 1,500円/月割引

(1,650円/月)


家族割引・おうち割 でんきセット（E）は重複して割引はされません。


【加入例】SoftBank 光ファミリーの場合、基本料金5,720円/月+指定オプション550円/月～が別途必要です。（2年自動更新プラン:2022年7月1日以降の契約者は、契約期間満了月の当月・翌月・翌々月以外での解約には解除料5,720円が必要）

その他注意事項

●SoftBank 光自動更新なしプランは対象外。

●固定通信サービス1回線につき携帯電話回線（スマートフォン/ケータイ/タブレット/モバイルWi-Fiルーター）最大10回線まで適用。

●シンプル S/M/Lは毎月1,188円割引、シンプル2 Sは毎月1,100円割引、シンプル2 M/Lは毎月1,650円割引、スマホベーシックプラン S/M/R/L、データベーシックプラン L、Pocket WiFi®プラン 2（ベーシック）、スマホプラン S、データプラン L、Pocket WiFi®プラン 2は毎月550円割引、スマホプラン M/Rは毎月770円割引、スマホプラン Lは毎月1,100円割引します。


[詳しく見る](https://www.ymobile.jp/plan/discount/hikarisetwari/)

×

遠方の親戚、同居している恋人も対象！

![家族割引サービス](https://www.ymobile.jp/plan/smartphone/images/waribiki_kazoku_sp.png?20250225)

家族割引サービス


シンプル3 S/M/Lご契約で

2回線目以降一人あたり

税抜 1,000円/月割引

(1,100円/月)


おうち割 光セット（A）、でんきセット（E）は重複して割引はされません。


※ 最大9回線まで割引が適用


[詳しく見る](https://www.ymobile.jp/plan/discount/kazokuwari/)

×

おうちのでんきとセットでおトク

![おうちでんき](https://www.ymobile.jp/plan/smartphone/images/waribiki_denki_sp.png)

おうち割 でんきセット（E）


シンプル3 M/Lご契約で24ヵ月間


_税抜_ 1,000円/月割引

(1,100円/月)


シンプル3 Sは対象外、家族割引・おうち割 光セット（A）は重複して割引はされません。


[おうちでんきについて詳しく見る](https://www.softbank.jp/energy/special/ouchi-denki/?ouchiwari=ym&cid=ymw_2509_dkod_02&argument=jsl6aztR&dmai=a68d4fe256a549)

[おうち割 でんきセット（E）について詳しく見る](https://www.ymobile.jp/plan/discount/ouchiwari/?tab=denki#tab-ouchi)

×

通信料金をPayPayカードで

支払うとおトク！

![PayPayカード割](https://www.ymobile.jp/plan/smartphone/images/waribiki_ppcard_sp.png?20250225)

PayPayカード割


PayPayカード ゴールド

※年会費11,000円

税抜- **500** 円/月

（- **550** 円/月）割引

PayPayカード

税抜- **300** 円/月

（- **330** 円/月）割引

その他注意事項

※シンプル3 S/M/L が対象

※支払方法のカード種類を変更した場合、支払方法変更の手続きを行った当月の請求より変更後の割引額が適用

●適用条件：請求締日時点で、PayPayカード、PayPayカードゴールドが、ご利用料金のお支払い方法として適用されているとき。

●家族カードも対象です。

●請求代行サービスを利用している場合、適用されません。

●割引対象料金プランの基本使用料が日割となる場合、本割引サービスの割引額は日割となります。

●譲渡・承継された場合等は、前請求月で割引は終了します。

解約された場合は、解約日の属する請求月も割引が適用されます。

[詳しく見る](https://www.ymobile.jp/sp/paypay-card/)

[トップへ戻る](https://www.ymobile.jp/plan/#top)

- [![社会課題に、アンサーを。](https://www.ymobile.jp/common_c/images/bnr/bnr_corp_special_answer.png?20251024)](https://www.softbank.jp/corp/special/answer/)
- [![SoftBank⇒サステナビリティ](https://www.ymobile.jp/common_c/images/bnr/bnr_esg_rating.png)](https://www.softbank.jp/corp/sustainability/)
- [![ワイモバイルの改善活動](https://www.ymobile.jp/common_c/images/bnr/bnr_kaizen_action.png)](https://www.softbank.jp/mobile/special/kaizen-action/?brand=ym&utm_source=yahoo&utm_medium=officialsite&utm_campaign=_mobile_cx_kaizen_20240905_018)

SEARCH

### ご契約を検討中のお客さま

- [新規ご契約](https://www.ymobile.jp/support/process/new_application/)
- [他社からのりかえ](https://www.ymobile.jp/support/process/portability/)
- [請求・お支払い](https://www.ymobile.jp/support/charge/)
- [エリアを確認したい](https://www.ymobile.jp/area/)
- [ショップを検索したい](https://www.ymobile.jp/shop/)
- [お得な情報が知りたい](https://www.ymobile.jp/cp/)

### 現在ご利用中のお客さま

- [My Y!mobileへログイン](https://www.ymobile.jp/support/online/login/)
- [困ったときは](https://www.ymobile.jp/support/trouble/)
- [オンライン手続きガイド](https://www.ymobile.jp/support/online/guide/)
- [製品サポート](https://www.ymobile.jp/support/product/)
- [機種変更](https://www.ymobile.jp/support/process/model_change/)
- [障害情報](https://www.ymobile.jp/info/failure/)
- [工事情報](https://www.ymobile.jp/info/maintenance/)

### 企業情報を知りたいお客さま

- [企業情報](https://www.softbank.jp/corp/aboutus/)
- [プレスリリース](https://www.softbank.jp/corp/news/press/sbkk/)
- [公開情報](https://www.softbank.jp/corp/aboutus/public/)
- [電子公告](https://www.softbank.jp/corp/ir/e_publicnotice/)
- [サステナビリティ](https://www.softbank.jp/corp/sustainability/)
- [採用情報](https://www.softbank.jp/corp/careers/)

### おすすめ情報

- [キャンペーン・おすすめ情報](https://www.ymobile.jp/cp/)
- [カタログ・パンフレット・ガイド](https://www.ymobile.jp/sp/p_guide/)
- [徹底解説！スマホとSIMのギモン](https://www.ymobile.jp/sp/guide/)

[よくあるご質問](https://www.ymobile.jp/support/faq/) [お問い合わせ](https://www.ymobile.jp/support/contact/)

SEARCH

- [当サイトについて](https://www.ymobile.jp/copyright/)
- [商標について](https://www.softbank.jp/corp/aboutus/governance/intellectual-property/trademark/)
- [約款・重要説明事項](https://www.ymobile.jp/corporate/open/agreement/)
- [個人情報について](https://www.softbank.jp/corp/privacy/)
- [情報セキュリティポリシー](https://www.softbank.jp/corp/security/)
- [プライバシーセンター](https://www.softbank.jp/privacy/)
- [企業情報](https://www.softbank.jp/corp/aboutus/)

© SoftBank Corp. All rights reserved.電気通信事業登録番号：第72号

閉じる

SEARCH

- [AIチャットで検索する](https://ymkarakuri.karakuri-gen.com/ymobile1/embed) [AIチャットで検索する](https://ymkarakuri.karakuri-gen.com/ymobile1/embed)
- [お申し込み](https://www.ymobile.jp/select_contract/)
- [My Y!mobile](https://www.ymobile.jp/support/online/login/)
- [法人のお客さま](https://www.ymobile.jp/biz/)

- [料金](https://www.ymobile.jp/plan/)
- [製品](https://www.ymobile.jp/lineup/)
- [SIM/eSIM](https://www.ymobile.jp/store/sp/sim/)
- [サービス](https://www.ymobile.jp/service/)
- [会員クーポン](https://www.ymobile.jp/service/ymobile/premium/#coupon-link)
- [SIMタイプ変更](https://www.ymobile.jp/sp/sim_kihen/)
- _サポート_






- [My Y!mobileご利用ガイド](https://www.ymobile.jp/support/online/)
- [オンラインストアご利用ガイド](https://www.ymobile.jp/store/to_beginner/)
- [ご契約者さま向けオンライン手続きガイド](https://www.ymobile.jp/support/online/guide/)
- [製品サポート](https://www.ymobile.jp/support/product/)
- [お申込後の初期設定ガイド](https://www.ymobile.jp/yservice/howto/)
- [請求・お支払い](https://www.ymobile.jp/support/charge/)
- [その他サポート](https://www.ymobile.jp/support/)
- [よくあるご質問](https://www.ymobile.jp/support/faq/)
- [お問い合わせ](https://www.ymobile.jp/support/contact/)

- [キャンペーン](https://www.ymobile.jp/cp/)
- _ショップ_






- [ショップを探す](https://www.ymobile.jp/shop/)
- [かんたん来店予約](https://www.ymobile.jp/shop/reservation/about/)
- [マイワイモバイルショップ](https://www.ymobile.jp/shop/myshop/)

![オンラインでお手続き！](https://www.ymobile.jp/common_c/images/common/txt-online.png)

[![オンライン手続きガイド](https://www.ymobile.jp/common_c/images/bnr/bnr_onlineguide2.png)](https://www.ymobile.jp/support/online/guide/)[![オンラインストア](https://www.ymobile.jp/common_c/images/bnr/bnr_store.png)](https://www.ymobile.jp/store/)

- [オンラインストア](https://www.ymobile.jp/store/)
- [エリア](https://www.ymobile.jp/area/)
- [法人の方](https://www.ymobile.jp/biz/)

- [![](https://www.ymobile.jp/common_c/images/bnr/bnr_ymotoku.png)](https://www.ymobile.jp/sp/ymobile-otoku/)

- [料金](https://www.ymobile.jp/plan/)
- [製品](https://www.ymobile.jp/lineup/)
- [SIM/eSIM](https://www.ymobile.jp/store/sp/sim/)
- [サービス](https://www.ymobile.jp/service/)
- [会員クーポン](https://www.ymobile.jp/service/ymobile/premium/#coupon-link)

![](https://www.ymobile.jp/store/common/cart_data/images/violet-new-service-page/intersect-sp.png)![](https://www.ymobile.jp/store/common/cart_data/images/violet-new-service-page/intersect-pc.png)![](https://www.ymobile.jp/store/common/cart_data/images/violet-new-service-page/futenyan_front.png)

# ご希望のお手続きを教えてください

## どちらで申し込みますか？

- 今の電話番号をそのまま使用する
- 新しい電話番号で申し込む

## 今ご利用中の携帯電話会社はどちらですか？

- ワイモバイル
- ワイモバイル以外

## ソフトバンクやLINEMOからののりかえですか？

- はい
- いいえ

## 端末もあわせて申し込みますか？

- はい
- いいえ（SIMのみ申し込む）

ワイモバイルの商品を見る