---
url: "https://www.ymobile.jp/plan/smartphone/shareplan/"
title: "子回線専用プラン（シェアプラン）｜料金｜Y!mobile - 格安SIM・スマホはワイモバイルで"
---

[![BLACK FRIDAY セール オンラインストア限定 12/1（月）14:59まで](https://www.ymobile.jp/common_c/images/index/head_promotion.png?20251120)![BLACK FRIDAY セール オンラインストア限定 12/1（月）14:59まで](https://www.ymobile.jp/common_c/images/index/head_promotion_sp.png?20251120)](https://www.ymobile.jp/lineup/?ref=topticker)

[Y!mobile](https://www.ymobile.jp/)

- [料金](https://www.ymobile.jp/plan/)
- [製品](https://www.ymobile.jp/lineup/)
- [SIM/eSIM](https://www.ymobile.jp/store/sp/sim/)
- [サービス](https://www.ymobile.jp/service/)
- [会員クーポン](https://www.ymobile.jp/service/ymobile/premium/#coupon-link)

- [お申し込み](https://www.ymobile.jp/select_contract/)
- [ログイン](https://www.ymobile.jp/support/online/login/)
- [法人ご契約](https://www.ymobile.jp/biz/)
- メニュー

- [![](https://www.ymobile.jp/common_c/images/common/icon/icon_home.svg)ホーム](https://www.ymobile.jp/)
- [料金](https://www.ymobile.jp/plan/)
- 子回線専用プラン（シェアプラン）

# 子回線専用プラン（シェアプラン）

2025年9月25日のシンプル3提供開始に伴い、2025年9月25日分より対象料金プランを拡大します。

[“ワイモバイル”の新料金プラン「シンプル3」を提供開始](https://www.softbank.jp/corp/news/press/sbkk/2025/20250904_01/)

表示価格は特に記載がない限り税込です。

消費税の計算上、請求金額と異なる場合があります。

「シンプル3 S/M/L」「シンプル2 S/M/L」「シンプルS/M/L」「スマホプラン/スマホベーシックプラン」または「データプラン/データベーシックプラン」をご加入のかたが、スマートフォンのデータ通信容量をタブレットなどの別の端末で効率良く分け合うことができる子回線専用のプランです。 最大3枚のUSIMカードが使え、タブレットや他社が販売するSIMフリーの端末にもご利用いただけます。

- ※ シェアプラン（子回線）はeSIMではご利用いただけません。

![最大3枚のUSIMカードが使えて、親回線との間で高速データ通信容量を自由に分け合える。](https://www.ymobile.jp/plan/smartphone/shareplan/images/image1.png?20250925)![最大3枚のUSIMカードが使えて、親回線との間で高速データ通信容量を自由に分け合える。](https://www.ymobile.jp/plan/smartphone/shareplan/images/image1_sp.png?20250925)

- ※「シェアプランセット割」は、親回線が「シンプル3 S/M/L」「シンプル2 S/M/L」「シンプルM/L」「スマホプランM/R/L/スマホベーシックプランM/R/L」または「データプランL/データベーシックプランL」の場合、シェアプランの基本使用料を割引します。

[他社が販売する携帯電話を\\
\\
ワイモバイルで利用する](https://www.ymobile.jp/service/others/simonly/)

## ポイント

### 基本使用料がおトク

![シェアプラン 基本使用料がおトク：今までは・・・](https://www.ymobile.jp/plan/smartphone/shareplan/images/image3_before.webp)

![シェアプラン 基本使用料がおトク：シェアプランを使えば](https://www.ymobile.jp/plan/smartphone/shareplan/images/image3_after.webp)

- ※タブレットなどの機種代金は別途必要です。

### パケットがムダなく使える

![シェアプラン パケットがムダなく使える：今までは・・・](https://www.ymobile.jp/plan/smartphone/shareplan/images/image4_before.webp)

![シェアプラン パケットがムダなく使える：シェアプランを使えば](https://www.ymobile.jp/plan/smartphone/shareplan/images/image4_after.webp)

## あまったデータをくりこせるから、もっとおトクにシェアできる

※ 親回線がシンプル3 S/M/Lの場合

余ったデータを、もっとムダなく使える！

![余ったデータを、もっとムダなく使える！](https://www.ymobile.jp/plan/smartphone/shareplan/images/image2.png?20250925)![余ったデータを、もっとムダなく使える！](https://www.ymobile.jp/plan/smartphone/shareplan/images/image2_sp.png?20250925)

[詳しくはこちら](https://www.ymobile.jp/service/kurikoshi/)

- ※ 2021年8月以降、プランのデータ容量を翌月にくりこしできるようになります。
- ※ くりこしたデータ容量は翌月末まで利用可能です。くりこしできるのは、規定容量とデータ増量オプションで増加したデータ容量のみであり、通常速度に戻す申し込みで追加購入されたデータ容量はくりこしできません。くりこしされるデータは100MB未満は切り捨てとなります。
- ※ 翌月へくりこしできるデータ容量の上限は、翌月加入のプランのデータ容量（データ増量オプションによる増量分を含む）までとなります。
- ※ データ量はくりこし分＞規定容量（データ増量オプションによるデータ増量を含む）＞追加購入データ量の順に消費されます。
- ※ シェアプランについて、親回線とデータ容量を分け合っている期間（シェア適用中）はデータがくりこしできます。ただし、親回線とのシェアが開始になる前月およびシェアが解除になる最終月の余ったデータ容量は翌月にくりこしされません。

## 親回線対象機種

「シンプル3 S/M/L」「シンプル2 S/M/L」「シンプルS/M/L」「スマホプラン/スマホベーシックプラン」または「データプラン/データベーシックプラン」でご契約のスマートフォン・タブレットが親回線対象です。

## 基本使用料

| 親回線プラン | 基本使用料<br> （3回線まで） | 通信速度低速化までの通信量 | 追加料金 |
| --- | --- | --- | --- |
| 加入月 | 加入翌月以降 |
| スマホプランS | 1,078円 | 3GB（加入月） | 2GB（親回線との合算） | 550円/0.5GB |
| シンプルS<br>スマホベーシックプランS | 3GB（親回線との合算） |
| シンプル2 S | 539円※ | 4GB（親回線との合算） |
| シンプル3 S | 5GB（親回線との合算） |
| スマホプランM | 6GB（親回線との合算） |
| シンプルM | 15GB（親回線との合算） |
| シンプル3 M、シンプル2 M | 30GB（親回線との合算）※1 |
| スマホベーシックプランM | 10GB（親回線との合算） |
| スマホプランR | 10GB（親回線との合算） |
| シンプルL | 25GB（親回線との合算） |
| シンプル3 L、シンプル2 L | 35GB（親回線との合算）※1 |
| スマホベーシックプランR | 14GB（親回線との合算） |
| スマホプランL | 0円※ | 14GB（親回線との合算） |
| スマホベーシックプランL |
| データプランS | 1,078円 | 1GB（親回線との合算） |
| データベーシックプランS |
| データプランL | 0円※ | 7GB（親回線との合算） |
| データベーシックプランL |

- ※「シェアプランセット割」適用時

### シェアプランセット割とは

「シェアプランセット割」は、当社が指定するプランとシェアプランをご契約されたお客さまを対象にシェアプラン基本料金を割引します。

| 適用条件 | 受付期間内に親回線となる「シンプル3 S/M/L」「シンプル2 S/M/L」「シンプルM/L」「スマホプランM/R/L」「スマホベーシックプランM/R/L」または「データプランL/データベーシックプランL」をご指定のうえ、シェアプランをご契約いただくこと。 |
| 受付期間 | 2014年12月4日（木）～<br>※終了時期は当サイトでお知らせいたします。 |
| 割引額 | 「シンプル3 S/M/L」「シンプル2 S/M/L」「シンプルM/L」「スマホプランM/R」「スマホベーシックプランM/R」 | 539円/月 |
| 「スマホプランL/スマホベーシックプランL」「データプランL/データベーシックプランL」ご契約の場合 | 1,078円/月 |

- ※シェアプランご加入の翌月から適用となります。
- ※親回線の料金プランを変更した場合、これらの変更のお申し込みがなされた月の翌月から変更後割引額が適用となります。
- ※解約または親回線を適用対象外料金プランに変更した場合、これらのお申し込みがなされた月をもって割引適用終了となります。
- ※キャンペーンの内容および期間は、予告なく変更する場合があります。

詳細は提供条件書をお読みください。

[シェアプランセット割提供条件書](https://www.ymobile.jp/corporate/open/agreement/pdf/shareplanset.pdf)

### その他キャンペーンについて

受付期間中にシェアプランをご契約したお客さまは下記キャンペーンが適用となります。

| 適用条件 | 本キャンペーン受付期間内にシェアプランをご契約いただくこと。 |
| 受付期間 | 2014年12月4日（木）～<br>※終了時期は当サイトでお知らせいたします。 |
| 割引額 | シェアプランご加入当月の基本使用料（1,078円）を無料<br> 親回線と同時加入でない場合の契約事務手数料を無料<br> ※親回線と同時加入の場合は契約事務手数料はかかりません |

- ※キャンペーンの内容および期間は、予告なく変更する場合があります。

## 通信料

| SMS送信料 | 3.3円/通 |
| SMS受信料 | 無料 |

## 利用可能なサービス

シェアプランでは下記のサービスがご利用いただけます。

[故障安心パックプラス](https://www.ymobile.jp/service/kosho_anshinplus/)

[ウェブ安心サービス](https://www.ymobile.jp/service/web_safety/)

[一定額お知らせメール](https://www.ymobile.jp/service/amount_mail/)

[一定額ストップサービス](https://www.ymobile.jp/service/amount_stop/)

[利用明細サービス](https://www.ymobile.jp/service/meisaihakko/)

[ワイモバイルまとめて支払い](https://www.ymobile.jp/service/payment/)

[国際ローミング（世界対応ケータイ）](https://www.ymobile.jp/service/global_roaming/)

- ※ご利用になる端末によってはご利用いただけない場合があります。

## ご注意事項

- ※ご利用になる端末によってはご利用いただけない場合があります。
- ●シェアプランの子回線としてケータイ、iPhone、かんたんスマホ、かんたんスマホ2はご加入できません。
- ●当料金プランのご加入には、契約名義・請求先が同一の、「シンプル3 S/M/L」「シンプル2 S/M/L」「シンプルS/M/L」「スマホプラン/スマホベーシックプラン」または「データプラン/データベーシックプラン」のご加入が必要です。
- ●親回線1に対し、当料金プラン（子回線）は3回線までご加入できます。
- ●当料金プランはデータ通信専用の料金プランです。音声サービスのご利用はできません。
- ●シェアプランから他のプランへの変更はできません。
- ●ご加入月の翌月から、親回線の高速データ通信容量を分け合うことができます。（ご加入月は子回線ごとに、3GBまでの高速データ通信がご利用になれます。）
- ●ご加入当月のご利用のデータ通信量が3GBに達した場合、当月末まで通信速度を低速化します。通常速度に戻すには、追加料金（550円/0.5GB）が必要です。（子回線ごとに実施します。）
- ●加入翌月以降、親回線と共用する当月ご利用のデータ通信量が速度制限の基準に達した場合、当月末まで通信速度を低速化します。通常速度に戻すには、追加料金（550円/0.5GB）が必要です。親回線から通常速度に戻す申込みが可能です。
- ●当料金プランは、親回線と同時加入でない場合、USIMカードを追加するごとに契約事務手数料が別途かかります。契約事務手数料については [こちら](https://www.ymobile.jp/support/process/fee/) をご確認ください。
- ●形状の異なるUSIMカードに変更する場合は、発行手数料が別途かかります。発行手数料については [こちら](https://www.ymobile.jp/support/process/fee/) をご確認ください。
- ●月途中のご加入の場合、月額料金を日割り計算しますが、月途中の解除の場合、日割計算しません。
- ●契約期間の定めはありません。
- ●親回線および子回線が提供条件を満たさなくなった場合、子回線は解約となります。


・親回線を解約した場合


・親回線を対象外の料金プランへ変更した場合
- ●ご利用に応じて通信料がかかります。
- ●ユニバーサルサービス料はかかりません。
- ●シェアプランの対応周波数は以下となります。対応エリアはそれぞれの周波数でご確認ください。


\[5G\] [3.7GHz](https://www.ymobile.jp/area/select.html?service=5g37&use_service=5g37)


\[4G\] [2.5GHz](https://www.ymobile.jp/area/select.html?use_service=4g25&device_name=&service=4g25)、 [2.1GHz](https://www.ymobile.jp/area/select.html?use_service=4g21&device_name=&service=4g21)、 [1.7GHz](https://www.ymobile.jp/area/select.html?use_service=4g17&device_name=&service=4g17)、 [900MHz](https://www.ymobile.jp/area/select.html?use_service=4g09&device_name=&service=4g09)


\[3G\] [2.1GHz](https://www.ymobile.jp/area/select.html?use_service=3g21&device_name=&service=3g21)、 [900MHz](https://www.ymobile.jp/area/select.html?use_service=3g09&device_name=&service=3g09)


親回線が5Gサービスに対応した料金プランの場合、シェアプランでも5Gサービスがご利用になれます。


高速大容量5G（新周波数）は限定エリアで提供。事前に対象エリアを十分にご確認の上、ご契約ください。


利用エリアはご利用機種が対応している通信方式、周波数により異なります。


機種により利用可能な通信方式や周波数が合致していてもご利用いただけない場合があります。


ご利用機種の仕様については携帯電話機の販売事業者にお問い合わせください。
- ●端末により利用可能な通信方式や周波数が合致していてもご利用いただけない場合があります。

[トップへ戻る](https://www.ymobile.jp/plan/smartphone/shareplan/#top)

- [![社会課題に、アンサーを。](https://www.ymobile.jp/common_c/images/bnr/bnr_corp_special_answer.png?20251024)](https://www.softbank.jp/corp/special/answer/)
- [![SoftBank⇒サステナビリティ](https://www.ymobile.jp/common_c/images/bnr/bnr_esg_rating.png)](https://www.softbank.jp/corp/sustainability/)
- [![ワイモバイルの改善活動](https://www.ymobile.jp/common_c/images/bnr/bnr_kaizen_action.png)](https://www.softbank.jp/mobile/special/kaizen-action/?brand=ym&utm_source=yahoo&utm_medium=officialsite&utm_campaign=_mobile_cx_kaizen_20240905_018)

SEARCH

### ご契約を検討中のお客さま

- [新規ご契約](https://www.ymobile.jp/support/process/new_application/)
- [他社からのりかえ](https://www.ymobile.jp/support/process/portability/)
- [請求・お支払い](https://www.ymobile.jp/support/charge/)
- [エリアを確認したい](https://www.ymobile.jp/area/)
- [ショップを検索したい](https://www.ymobile.jp/shop/)
- [お得な情報が知りたい](https://www.ymobile.jp/cp/)

### 現在ご利用中のお客さま

- [My Y!mobileへログイン](https://www.ymobile.jp/support/online/login/)
- [困ったときは](https://www.ymobile.jp/support/trouble/)
- [オンライン手続きガイド](https://www.ymobile.jp/support/online/guide/)
- [製品サポート](https://www.ymobile.jp/support/product/)
- [機種変更](https://www.ymobile.jp/support/process/model_change/)
- [障害情報](https://www.ymobile.jp/info/failure/)
- [工事情報](https://www.ymobile.jp/info/maintenance/)

### 企業情報を知りたいお客さま

- [企業情報](https://www.softbank.jp/corp/aboutus/)
- [プレスリリース](https://www.softbank.jp/corp/news/press/sbkk/)
- [公開情報](https://www.softbank.jp/corp/aboutus/public/)
- [電子公告](https://www.softbank.jp/corp/ir/e_publicnotice/)
- [サステナビリティ](https://www.softbank.jp/corp/sustainability/)
- [採用情報](https://www.softbank.jp/corp/careers/)

### おすすめ情報

- [キャンペーン・おすすめ情報](https://www.ymobile.jp/cp/)
- [カタログ・パンフレット・ガイド](https://www.ymobile.jp/sp/p_guide/)
- [徹底解説！スマホとSIMのギモン](https://www.ymobile.jp/sp/guide/)

[よくあるご質問](https://www.ymobile.jp/support/faq/) [お問い合わせ](https://www.ymobile.jp/support/contact/)

SEARCH

- [当サイトについて](https://www.ymobile.jp/copyright/)
- [商標について](https://www.softbank.jp/corp/aboutus/governance/intellectual-property/trademark/)
- [約款・重要説明事項](https://www.ymobile.jp/corporate/open/agreement/)
- [個人情報について](https://www.softbank.jp/corp/privacy/)
- [情報セキュリティポリシー](https://www.softbank.jp/corp/security/)
- [プライバシーセンター](https://www.softbank.jp/privacy/)
- [企業情報](https://www.softbank.jp/corp/aboutus/)

© SoftBank Corp. All rights reserved.電気通信事業登録番号：第72号

閉じる

SEARCH

- [AIチャットで検索する](https://ymkarakuri.karakuri-gen.com/ymobile1/embed) [AIチャットで検索する](https://ymkarakuri.karakuri-gen.com/ymobile1/embed)
- [お申し込み](https://www.ymobile.jp/select_contract/)
- [My Y!mobile](https://www.ymobile.jp/support/online/login/)
- [法人のお客さま](https://www.ymobile.jp/biz/)

- [料金](https://www.ymobile.jp/plan/)
- [製品](https://www.ymobile.jp/lineup/)
- [SIM/eSIM](https://www.ymobile.jp/store/sp/sim/)
- [サービス](https://www.ymobile.jp/service/)
- [会員クーポン](https://www.ymobile.jp/service/ymobile/premium/#coupon-link)
- [SIMタイプ変更](https://www.ymobile.jp/sp/sim_kihen/)
- _サポート_






- [My Y!mobileご利用ガイド](https://www.ymobile.jp/support/online/)
- [オンラインストアご利用ガイド](https://www.ymobile.jp/store/to_beginner/)
- [ご契約者さま向けオンライン手続きガイド](https://www.ymobile.jp/support/online/guide/)
- [製品サポート](https://www.ymobile.jp/support/product/)
- [お申込後の初期設定ガイド](https://www.ymobile.jp/yservice/howto/)
- [請求・お支払い](https://www.ymobile.jp/support/charge/)
- [その他サポート](https://www.ymobile.jp/support/)
- [よくあるご質問](https://www.ymobile.jp/support/faq/)
- [お問い合わせ](https://www.ymobile.jp/support/contact/)

- [キャンペーン](https://www.ymobile.jp/cp/)
- _ショップ_






- [ショップを探す](https://www.ymobile.jp/shop/)
- [かんたん来店予約](https://www.ymobile.jp/shop/reservation/about/)
- [マイワイモバイルショップ](https://www.ymobile.jp/shop/myshop/)

![オンラインでお手続き！](https://www.ymobile.jp/common_c/images/common/txt-online.png)

[![オンライン手続きガイド](https://www.ymobile.jp/common_c/images/bnr/bnr_onlineguide2.png)](https://www.ymobile.jp/support/online/guide/)[![オンラインストア](https://www.ymobile.jp/common_c/images/bnr/bnr_store.png)](https://www.ymobile.jp/store/)

- [オンラインストア](https://www.ymobile.jp/store/)
- [エリア](https://www.ymobile.jp/area/)
- [法人の方](https://www.ymobile.jp/biz/)

- [![](https://www.ymobile.jp/common_c/images/bnr/bnr_ymotoku.png)](https://www.ymobile.jp/sp/ymobile-otoku/)

- [料金](https://www.ymobile.jp/plan/)
- [製品](https://www.ymobile.jp/lineup/)
- [SIM/eSIM](https://www.ymobile.jp/store/sp/sim/)
- [サービス](https://www.ymobile.jp/service/)
- [会員クーポン](https://www.ymobile.jp/service/ymobile/premium/#coupon-link)

![](https://www.ymobile.jp/store/common/cart_data/images/violet-new-service-page/intersect-sp.png)![](https://www.ymobile.jp/store/common/cart_data/images/violet-new-service-page/intersect-pc.png)![](https://www.ymobile.jp/store/common/cart_data/images/violet-new-service-page/futenyan_front.png)

# ご希望のお手続きを教えてください

## どちらで申し込みますか？

- 今の電話番号をそのまま使用する
- 新しい電話番号で申し込む

## 今ご利用中の携帯電話会社はどちらですか？

- ワイモバイル
- ワイモバイル以外

## ソフトバンクやLINEMOからののりかえですか？

- はい
- いいえ

## 端末もあわせて申し込みますか？

- はい
- いいえ（SIMのみ申し込む）

ワイモバイルの商品を見る