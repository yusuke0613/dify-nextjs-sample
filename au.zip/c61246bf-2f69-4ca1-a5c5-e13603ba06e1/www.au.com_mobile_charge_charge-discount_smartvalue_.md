---
url: "https://www.au.com/mobile/charge/charge-discount/smartvalue/"
title: "auスマートバリュー | 料金・割引：スマートフォン・携帯電話 | au"
---

![メニュー](https://www.au.com/etc.clientlibs/settings/wcm/designs/au-com/clientlib-site/resources/images/icon/icon_menu_smp.png)[![おもしろい方の未来へ。 au](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/common/icon/au_logo_y.png?scl=1&fmt=png-alpha)](https://www.au.com/)

×

ログインすると、ポイントやお知らせの確認をはじめ、お客さまの契約内容に応じた表示ができます。

[My au利用規約](https://www.au.com/my-au/terms/)、 [My UQ mobile利用規約](https://www.kddi.com/extlib/files/corporate/kddi/kokai/keiyaku_yakkan/pdf/myuqmobile_service.pdf)、 [ID利用規約](https://id.auone.jp/id/pc/legal/auid_terms.html)、 [au Ponta ポイントプログラム規約](https://www.au.com/support/point/regulation-point/) および [アクセスデータの利用](https://www.kddi.com/terms/requirements/#a06) に同意の上、ログインしてください。

ログインすると、ポイントやお知らせの確認をはじめ、お客さまの契約内容に応じた表示ができます。

[My au利用規約](https://www.au.com/my-au/terms/)、 [My UQ mobile利用規約](https://www.kddi.com/extlib/files/corporate/kddi/kokai/keiyaku_yakkan/pdf/myuqmobile_service.pdf)、 [ID利用規約](https://id.auone.jp/id/sp/legal/auid_terms.html)、 [au Ponta ポイントプログラム規約](https://www.au.com/support/point/regulation-point/) および [アクセスデータの利用](https://www.kddi.com/terms/requirements/#a06) に同意の上、ログインしてください。

au IDでログイン

※ログインしない場合は、右上の｢×｣ボタンで本画面を閉じてください。

[![おもしろい方の未来へ。 au](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/common/icon/au_logo_t.png?scl=1&fmt=png-alpha)](https://www.au.com/)

- 商品・サービス
- [サポート](https://www.au.com/support/)
- [My au](https://my.au.com/)

- [![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_shop.png?fmt=png-alpha&scl=1)ショップ検索・\\
\\
来店予約](https://www.au.com/storelocator/)
- [![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_auonlineshop.png?fmt=png-alpha&scl=1)au Online Shop](https://www.au.com/mobile/onlineshop/)
- ![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_search.png?fmt=png-alpha&scl=1)


- [ニュースセンター](https://www.au.com/information/)
- [お問い合わせ](https://www.au.com/support/inquiry/)
- [English](https://www.au.com/english/)
- 企業情報

- [企業情報](https://www.kddi.com/corporate/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
- [サステナビリティ](https://www.kddi.com/corporate/sustainability/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
- [投資家情報](https://www.kddi.com/corporate/ir/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
- [採用情報](https://www.kddi.com/corporate/recruit/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
- [法人のお客さま](https://biz.kddi.com/service/mobile/)

- [企業情報トップ](https://www.kddi.com/corporate/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
- [サステナビリティ](https://www.kddi.com/corporate/sustainability/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
- [投資家情報](https://www.kddi.com/corporate/ir/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
- [採用情報](https://www.kddi.com/corporate/recruit/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
- [法人のお客さま](https://biz.kddi.com/service/mobile/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_smartphone_white.png?fmt=png-alpha&scl=1)

[スマートフォン・携帯電話 TOP](https://www.au.com/mobile/)

- [Android](https://www.au.com/mobile/product/smartphone/)
- [iPhone](https://www.au.com/iphone/)
- [iPad](https://www.au.com/ipad/)
- [料金・割引](https://www.au.com/mobile/charge/)
- [サービス・機能](https://www.au.com/mobile/service/)
- [エリア](https://www.au.com/mobile/area/)
- [キャンペーン](https://www.au.com/mobile/campaign/)
- [スマホ教室](https://school.au.com/?medid=au&serial=global_navi&srcid=074)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_internet_white.png?fmt=png-alpha&scl=1)

[インターネット回線 TOP](https://www.au.com/internet/)

- [auひかり ホーム10ギガ・5ギガ](https://www.au.com/internet/auhikari_10-5g/)
- [auひかり ホーム1ギガ](https://www.au.com/internet/auhikari_1g/)
- [auひかり マンション](https://www.au.com/internet/mansion/)
- [au one net](https://www.au.com/internet/auonenet/)
- [お申し込み・コース変更](https://www.au.com/internet/application/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_pontapass_white_68ca7486d78e8d37.png?fmt=png-alpha&scl=1)

[Pontaパス TOP](https://www.au.com/pontapass/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_payment2_white.png?fmt=png-alpha&scl=1)

[ポイント・決済 TOP](https://www.au.com/payment/)

- [Pontaポイント](https://www.au.com/payment/point/)
- [au PAY（コード支払い/ネット支払い）](https://www.au.com/payment/aupay/)
- [au PAY プリペイドカード](https://www.au.com/payment/prepaid/)
- [au PAY カード](https://www.au.com/payment/card/)
- [au PAY（auかんたん決済）](https://www.au.com/payment/easy/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_hoken_white.png?fmt=png-alpha&scl=1)

[auの金融・保険サービス TOP](https://www.au.com/finance/)

- [auの生命ほけん](https://www.au.com/finance/life-insurance/)
- [auの損害ほけん](https://www.au.com/finance/nonlife-insurance/)
- [auのiDeCo](https://www.au.com/finance/ideco/)
- [auの住宅ローン](https://www.au.com/finance/loan/housing/)
- [auじぶん銀行](https://www.au.com/finance/primebank/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_denki_white.png?fmt=png-alpha&scl=1)

[auでんき・エネルギーサービス TOP](https://www.au.com/energy/)

- [料金プラン](https://www.au.com/energy/denki/merit/plan/)
- [ご契約者向けサポート](https://energy.auone.jp/denki/cs)
- [お引っ越しのご案内](https://energy.auone.jp/denki/merit/moving/)
- [ガスのご案内](https://www.au.com/energy/gas/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_contents_white.png?fmt=png-alpha&scl=1)

[エンタメ TOP](https://www.au.com/entertainment/)

- [映像](https://www.au.com/entertainment/?tabopen=tab_video#anc_01)
- [音楽](https://www.au.com/entertainment/?tabopen=tab_music#anc_01)
- [書籍](https://www.au.com/entertainment/?tabopen=tab_book#anc_01)
- [ニュース](https://www.au.com/entertainment/newspass/)
- [クラウド](https://www.au.com/entertainment/googleone/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_home_white.png?fmt=png-alpha&scl=1)

[くらしのサービス TOP](https://www.au.com/life/)

- [au HOME](https://www.au.com/life/auhome/)
- [auおうちあんしんサポート](https://www.au.com/life/ouchi-anshin/)
- [auわんにゃんサポート](https://pet.life-kurashi.au.com/)
- [au自転車サポート](https://www.au.com/life/bicycle-support/)
- [au PAY ふるさと納税](https://www.au.com/life/furusato-tax/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_wallet_white.png?fmt=png-alpha&scl=1)

[ショッピング TOP](https://www.au.com/shopping/)

- [au PAY マーケット（総合通販）](https://www.au.com/shopping/wowma/)
- [au Online Shop](https://www.au.com/mobile/onlineshop/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_healthcare_white.png?fmt=png-alpha&scl=1)

[ヘルスケア TOP](https://wellness.auone.jp/?medid=au&serial=entertainment&srcid=banner)

x

[![閉じる](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_close_gray_large.png?fmt=png-alpha&scl=1)](https://www.au.com/mobile/charge/charge-discount/smartvalue/#)

商品・サービス![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_smartphone_gray.png?fmt=png-alpha&scl=1)スマートフォン・携帯電話


- [スマートフォン・携帯電話 TOP](https://www.au.com/mobile/)
- [Android](https://www.au.com/mobile/product/smartphone/)
- [iPhone](https://www.au.com/iphone/)
- [iPad](https://www.au.com/ipad/)
- [料金・割引](https://www.au.com/mobile/charge/)
- [サービス・機能](https://www.au.com/mobile/service/)
- [エリア](https://www.au.com/mobile/area/)
- [キャンペーン](https://www.au.com/mobile/campaign/)
- [スマホ教室](https://school.au.com/?medid=au&serial=global_navi&srcid=074)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_internet_gray.png?fmt=png-alpha&scl=1)インターネット回線


- [インターネット回線 TOP](https://www.au.com/internet/)
- [auひかり ホーム10ギガ・5ギガ](https://www.au.com/internet/auhikari_10-5g/)
- [auひかり ホーム1ギガ](https://www.au.com/internet/auhikari_1g/)
- [auひかり マンション](https://www.au.com/internet/mansion/)
- [au one net](https://www.au.com/internet/auonenet/)
- [お申し込み・コース変更](https://www.au.com/internet/application/)

[![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_pontapass_gray_51d343cd9cd339bd.png?fmt=png-alpha&scl=1)Pontaパス](https://www.au.com/pontapass/)![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_payment2_gray.png?fmt=png-alpha&scl=1)ポイント・決済


- [ポイント・決済 TOP](https://www.au.com/payment/)
- [Pontaポイント](https://www.au.com/payment/point/)
- [au PAY（コード支払い/ネット支払い）](https://www.au.com/payment/aupay/)
- [au PAY プリペイドカード](https://www.au.com/payment/prepaid/)
- [au PAY カード](https://www.au.com/payment/card/)
- [au PAY（auかんたん決済）](https://www.au.com/payment/easy/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_hoken_gray.png?fmt=png-alpha&scl=1)auの金融・保険サービス


- [auの金融・保険サービス TOP](https://www.au.com/finance/)
- [auの生命ほけん](https://www.au.com/finance/life-insurance/)
- [auの損害ほけん](https://www.au.com/finance/nonlife-insurance/)
- [auのiDeCo](https://www.au.com/finance/ideco/)
- [auの住宅ローン](https://www.au.com/finance/loan/housing/)
- [auじぶん銀行](https://www.au.com/finance/primebank/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_denki_gray.png?fmt=png-alpha&scl=1)auでんき・エネルギーサービス


- [auでんき・エネルギーサービス TOP](https://www.au.com/energy/)
- [料金プラン](https://www.au.com/energy/denki/merit/plan/)
- [ご契約者向けサポート](https://energy.auone.jp/denki/cs)
- [お引っ越しのご案内](https://energy.auone.jp/denki/merit/moving/)
- [ガスのご案内](https://www.au.com/energy/gas/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_contents_gray.png?fmt=png-alpha&scl=1)エンタメ


- [エンタメ TOP](https://www.au.com/entertainment/)
- [映像](https://www.au.com/entertainment/?tabopen=tab_video#anc_01)
- [音楽](https://www.au.com/entertainment/?tabopen=tab_music#anc_01)
- [書籍](https://www.au.com/entertainment/?tabopen=tab_book#anc_01)
- [ニュース](https://www.au.com/entertainment/newspass/)
- [クラウド](https://www.au.com/entertainment/googleone/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_home_gray.png?fmt=png-alpha&scl=1)くらしのサービス


- [くらしのサービス TOP](https://www.au.com/life/)
- [au HOME](https://www.au.com/life/auhome/)
- [auおうちあんしんサポート](https://www.au.com/life/ouchi-anshin/)
- [auわんにゃんサポート](https://pet.life-kurashi.au.com/)
- [au自転車サポート](https://www.au.com/life/bicycle-support/)
- [au PAY ふるさと納税](https://www.au.com/life/furusato-tax/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_wallet_gray.png?fmt=png-alpha&scl=1)ショッピング


- [ショッピング TOP](https://www.au.com/shopping/)
- [au PAY マーケット（総合通販）](https://www.au.com/shopping/wowma/)
- [au Online Shop](https://www.au.com/mobile/onlineshop/)

[![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_healthcare_gray.png?fmt=png-alpha&scl=1)ヘルスケア](https://wellness.auone.jp/?medid=au&serial=entertainment&srcid=banner)[サポート](https://www.au.com/support/)My au[My au TOP](https://my.au.com/aus/hc-cs/omt/OMT0010001.hc)[スマートフォン・携帯電話](https://my.au.com/aus/hc-cs/osm/OSM0000001.hc)[インターネット・電話](https://my.au.com/aus/hc-cs/oin/OIN0010001.hc)[au HOME](https://my.au.com/aus/WCV411001/WCE411001.hc)[エンタメ](https://my.au.com/aus/hc-cs/oct/OCT0010001.hc)[au PAY](https://my.au.com/aus/hc-cs/ocd/OCD0010001.hc)[ショッピング](https://my.au.com/aus/hc-cs/owm/OWM0010001.hc)[auでんき](https://my.au.com/aus/hc-cs/oet/OET0010001.hc)[auの金融・保険サービス](https://my.au.com/aus/hc-cs/oir/OIR0000001.hc)[ポイント](https://my.au.com/aus/au-cs1/AuHome?PageID=SSO&ActionID=POINT&agdt=2)[お知らせ](https://my.au.com/aus/hc-cs/ony/ONY0010001.hc)

- [![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_shop.png?fmt=png-alpha&scl=1)ショップ検索・来店予約](https://www.au.com/storelocator/)
- [![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_auonlineshop.png?fmt=png-alpha&scl=1)au Online Shop](https://www.au.com/mobile/onlineshop/)
- [ニュースセンター](https://www.au.com/information/)
  - [お問い合わせ](https://www.au.com/support/inquiry/)
  - [English](https://www.au.com/english/)
  - [企業情報](https://www.kddi.com/corporate/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
  - [サステナビリティ](https://www.kddi.com/corporate/sustainability/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
  - [投資家情報](https://www.kddi.com/corporate/ir/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
  - [採用情報](https://www.kddi.com/corporate/recruit/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
  - [法人のお客さま](https://biz.kddi.com/service/mobile/)

[スマートフォン・携帯電話](https://www.au.com/mobile/charge/charge-discount/smartvalue/#)

- [スマートフォン・携帯電話](https://www.au.com/mobile/?bid=we-we-gn-2001)
- [スマートフォン・携帯電話 TOP](https://www.au.com/mobile/?bid=we-we-gn-2001)
  - [Android](https://www.au.com/mobile/product/smartphone/)
  - [iPhone](https://www.au.com/iphone/)
  - [料金・割引](https://www.au.com/mobile/charge/?bid=we-we-gn-2003)
  - [サービス・機能](https://www.au.com/mobile/service/?bid=we-we-gn-2004)
  - [エリア](https://www.au.com/mobile/area/?bid=we-we-gn-2005)
  - [キャンペーン](https://www.au.com/mobile/campaign/?bid=we-we-gn-2006)

[![Cart](https://www.au.com/etc.clientlibs/settings/wcm/designs/au-com/clientlib-site/resources/images/icon/icon_cart.png)0](https://www.au.com/cart/?bid=we-we-gn-2904)

1. [トップ](https://www.au.com/)
2. [スマートフォン・携帯電話](https://www.au.com/mobile/)
3. [料金・割引](https://www.au.com/mobile/charge/)
4. auスマートバリュー

# auスマートバリュー

## 概要

ネットとセットでauスマホのご利用料金がおトクになるサービスです。

詳しく



![イメージ画像](<Base64-Image-Removed>)

auスマホのご利用料金から

**最大 1,100円／月割引**

詳しく



**2025年7月1日～対象拡大★1！**

![同居のご家族も離れて暮らすご家族もみんな「家族」の対象です！](<Base64-Image-Removed>)

1. 従来キャンペーンで提供してきましたが、適用条件を改定し、住所の異なるご家族の方も割引にお申し込みいただけるようになりました。



-
対象のご自宅のインターネットサービスのご契約者と別姓や別住所の場合、店頭でのお手続きおよび家族関係を証明する書類が必要です（すでに家族割を組まれている場合を除く）。



[お手続きに必要な書類について詳しくはこちら](https://www.au.com/mobile/charge/charge-discount/kazoku-wari/#shop)

## 割引金額

対象のプランは以下表よりご確認ください。

|     |     |
| --- | --- |
| 対象のプラン | 割引 |
| auバリューリンクプラン ALL STARパック<br>auバリューリンクプラン DAZNパック<br>auバリューリンクプラン ドラマ・バラエティパック<br>auバリューリンクプラン Netflixパック（P）<br>auバリューリンクプラン Netflixパック<br>auバリューリンクプラン with Amazonプライム<br>auバリューリンクプラン<br>auマネ活バリューリンクプラン ALL STARパック<br>auマネ活バリューリンクプラン DAZNパック<br>auマネ活バリューリンクプラン ドラマ・バラエティパック<br>auマネ活バリューリンクプラン Netflixパック（P）<br>auマネ活バリューリンクプラン Netflixパック<br>auマネ活バリューリンクプラン with Amazonプライム<br>auマネ活バリューリンクプラン<br>使い放題MAX＋ 5G ALL STARパック<br>使い放題MAX＋ 5G／4G DAZNパック<br>使い放題MAX＋ 5G／4G ドラマ・バラエティパック<br>使い放題MAX＋ 5G／4G Netflixパック（P）<br>使い放題MAX＋ 5G／4G Netflixパック<br>使い放題MAX＋ 5G with Amazonプライム<br>使い放題MAX＋ 5G／4G<br>auマネ活プラン＋ 5G ALL STARパック<br>auマネ活プラン＋ 5G／4G DAZNパック<br>auマネ活プラン＋ 5G／4G ドラマ・バラエティパック<br>auマネ活プラン＋ 5G／4G Netflixパック（P）<br>auマネ活プラン＋ 5G／4G Netflixパック<br>auマネ活プラン＋ 5G with Amazonプライム<br>auマネ活プラン＋ 5G／4G<br>スマホミニプラン＋ 5G／4G<br>シニアバリュープラン | 翌月から<br>**1,100円／月**割引 |
| U16バリュープラン | 翌月から<br>**550円／月**割引 |

[**＜新規受付終了済のプランはこちら＞**](https://www.au.com/mobile/charge/charge-discount/smartvalue/#)

|     |     |
| --- | --- |
| 新規受付終了　スマホプラン | 割引 |
| 使い放題MAX 5G ALL STARパック3<br>使い放題MAX 5G ALL STARパック2<br>使い放題MAX 5G ALL STARパック<br>使い放題MAX 5G／4G DAZNパック<br>使い放題MAX 5G／4G ドラマ・バラエティパック<br>使い放題MAX 5G／4G Netflixパック2（P）<br>使い放題MAX 5G／4G Netflixパック2<br>使い放題MAX 5G／4G Netflixパック（P）<br>使い放題MAX 5G／4G Netflixパック<br>使い放題MAX 5G with Amazonプライム<br>使い放題MAX 5G／4G<br>auマネ活プラン 5G ALL STARパック3<br>auマネ活プラン 5G ALL STARパック2<br>auマネ活プラン 5G／4G DAZNパック<br>auマネ活プラン 5G／4G ドラマ・バラエティパック<br>auマネ活プラン 5G／4G Netflixパック2（P）<br>auマネ活プラン 5G／4G Netflixパック2<br>auマネ活プラン 5G／4G Netflixパック（P）<br>auマネ活プラン 5G／4G Netflixパック<br>auマネ活プラン with Amazonプライム<br>auマネ活プラン 5G／4G<br>データMAX 5G ALL STARパック<br>データMAX 5G／4G LTE ドラマ・バラエティパック<br>データMAX 5G Netflixパック（P）<br>データMAX 5G／4G LTE Netflixパック<br>データMAX 5G with Amazonプライム<br>データMAX 5G／4G LTE<br>auデータMAXプランPro<br>auデータMAXプラン Netflixパック<br>auデータMAXプラン<br>auフラットプラン30<br>auフラットプラン25 NetflixパックN<br>auフラットプラン25 Netflixパック<br>auフラットプラン20N<br>auフラットプラン20<br>auフラットプラン7プラスN<br>auフラットプラン7プラス<br>auフラットプラン5（学割専用） | 翌月から1,100円／月割引 |
| スマホスタートプランベーシック 5G／4G<br>スマホミニプラン 5G／4G | 翌月から550円／月割引 |
| ピタットプラン 5G／4G LTE<br>新auピタットプラン | データ容量　1GB超～7GB：翌月から550円／月割引<br>- <br>データ容量～1GBご利用の月は割引適用されません。 |
| ピタットプラン 5G／4G LTE（s） | データ容量　2GB超～20GB：翌月から550円／月割引<br>- <br>データ容量～2GBご利用の月は割引適用されません。 |
| auピタットプラン<br>auピタットプラン（s） | データ容量　～2GB：翌月から550円／月割引<br>- <br>auピタットプラン（シンプル）でデータ容量～1GBご利用の月は割引適用されません。<br>  <br>2GB超：翌月から1,100円／月割引 |
| auピタットプランN（s） | データ容量　～2GB：翌月から550円／月割引<br>2GB超：翌月から1,100円／月割引 |

|     |     |
| --- | --- |
| 新規受付終了　ケータイ・タブレット・データ定額 | 割引 |
| データ定額10／13／30 | 翌月以降最大2年間2,200円／月割引<br>3年目以降1,027円／月割引 |
| データ定額5／8／20<br>LTEフラット | 翌月以降最大2年間1,551円／月割引<br>3年目以降1,027円／月割引 |
| データ定額2／3<br>ジュニアスマートフォンプラン<br>シニアプラン | 翌月から1,027円／月割引 |
| データ定額1 | 翌月以降最大2年間1,027円／月割引<br>3年目以降550円／月割引 |
| データ定額10（ケータイ）／13（ケータイ） | 翌月以降最大2年間2,200円／月割引<br>3年目以降1,027円／月割引 |
| データ定額5（ケータイ）／8（ケータイ） | 翌月以降最大2年間1,551円／月割引<br>3年目以降1,027円／月割引 |
| データ定額2（ケータイ）／3（ケータイ） | 翌月から1,027円／月割引 |
| データ定額1（ケータイ） | 翌月以降最大2年間1,027円／月割引<br>3年目以降550円／月割引 |
| タブレットプラン20 | 翌月から1,100円／月割引 |
| データ定額5／8／20<br>LTEフラット<br>LTEフラット for Tab／Tab（i）／Tab（L）／DATA（m） | 翌月以降最大2年間1,551円／月割引<br>3年目以降1,027円／月割引 |

閉じる

## 条件

以下①②の条件を満たすこと

1. auスマホ／auタブレット／auケータイで対象の料金プランに加入


2. 以下のいずれかに加入










[**「auひかり」などの「対象のご自宅のインターネットサービス」★2（ネット＋電話のセットでのご利用が必要です）**](https://www.au.com/mobile/charge/charge-discount/smartvalue/#)











1. 「対象のご自宅のインターネットサービス」












【光サービス】












au ひかり（@nifty、@T COM ［アットティーコム］、ASAHIネット、au one net、BIGLOBE、DTI、So-net）・auひかり ちゅら・コミュファ光・eo光・Pikara［ピカラ光］・メガエッグ・BBIQ













【ケーブルテレビ】












J:COM・提携先ケーブルテレビ













【光コラボレーションサービス】












BIGLOBE光・So-net光・@nifty光・@T COM （アットティーコム）ヒカリ・ひかりゆいまーる・ひかりＪ


-
一部サービスは対象外となります。


-
「ネット＋電話」、「ネット＋テレビ」、「テレビ＋電話」は、同一の会社でのご利用が必要です。


-
対象のご自宅のインターネットサービスの詳細については、以下ページ・店頭スタッフまでご確認ください。



[対象となるご自宅のインターネット一覧（詳細）](https://www.au.com/mobile/charge/charge-discount/smartvalue/catv/#kotei-service)

閉じる

**or**

[**「au ホームルーター 5G★3 ・ auスマートポート★4 ・ WiMAX +5G★5」（対象の料金プラン★6 のご利用が必要です）**](https://www.au.com/mobile/charge/charge-discount/smartvalue/#)

1. 対象機種：Speed Wi-Fi HOME 5G L11／Speed Wi-Fi HOME 5G L12／Speed Wi-Fi HOME 5G L13


2. 対象機種：Speed Wi-Fi HOME L02／Speed Wi-Fi HOME L01s／Speed Wi-Fi HOME L01／WiMAX HOME 01


3. 対象のルーターサービスの詳細については以下ページまたはUQホームページ・店頭スタッフまでご確認ください。








[自宅セット割（インターネットコース）セット対象となるご自宅のインターネット一覧](https://www.uqwimax.jp/mobile/plan/discount/setwari/alliance/#anchor03)

4. 対象の料金プラン












【au ホームルーター 5Gの場合】












ホームルータープラン 5G













【au スマートポートの場合】












ホームルータープラン、WiMAX 2+ フラット for HOME（新規受付終了）













【WiMAX +5Gの場合】












以下のUQ WiMAXホームページか店頭スタッフまでご確認ください。









[料金プラン・サービス](https://www.uqwimax.jp/wimax/plan/)


閉じる

-
対象のご自宅のインターネットサービスなどのご加入が必要です。

加入例）auひかりホーム・ずっとギガ得プラン（契約期間3年）の場合、基本料金5,610円／月＋電話月額利用料 770円／月が別途必要です。インターネットサービス解約時に、ご契約期間に応じて契約解除料4,730円が発生する場合があります。詳しくは下記よりご確認ください。








[auスマートバリュー](https://www.au.com/mobile/charge/charge-discount/smartvalue/)


## 適用時期

auスマートバリューのお申し込み翌月以降から割引適用となります。

## 注意事項

[**ご注意事項はこちら**](https://www.au.com/mobile/charge/charge-discount/smartvalue/#)


【割引適用】


-
ご契約はご自宅のインターネットサービス1回線につき、au携帯電話（タブレット・PC含む）合計10回線（またはau ホームルーター 5G／au スマートポートなどの対象のルーターサービスの場合1回線につき、au携帯電話合計9回線）までです。「auスマートバリュー」をご契約の回線が「家族割プラス」グループまたはUQ mobileの「自宅セット割」グループにも加入している場合、各グループにご加入のau／UQ携帯電話も回線数のカウントに含まれます。


-
auスマートバリューのお申し込み翌月以降から割引適用です。


-
スマホセット割ご加入の方がauスマートバリューを申し込みされた場合、自動的にauスマートバリューの割引に切り替わります。ただしauスマートバリュー適用前にスマホセット割を廃止した場合、前月末をもってスマホセット割は終了となり、auスマートバリューは翌月からの割引です。


-
auスマートバリューご加入から2年間の割引（2,200円／月、1,551円／月、1,027円／月）適用は、対象のau携帯電話（タブレット・PC含む）1回線につき、auスマートバリューの割引を初めて適用した月を1カ月目としてカウントし、最大24カ月の割引をもって終了します。3年目以降は割引額が変更となります。


-
割引対象合計額が割引金額を下回る場合は、割引対象合計額を上限として割引します。


-
割引額は、月末時点で加入しているau携帯電話の料金プランやデータ定額サービスにより判定します。月末時点で条件を満たさない月は、割引は適用されません。


-
au回線を解約 ・一時休止された場合、お手続きの当月をもって割引の適用を終了します。au回線を譲渡／承継（家族間は除く）された場合は、お手続きの前月分をもって割引の適用を終了します。


-
対象のご自宅のインターネットサービスを「利用中」または「手続き中」の場合も、割引の適用となります。


-
対象のご自宅のインターネットサービスを解約された場合、割引の適用は解約のお申し込み月の前月をもって終了します。auスマートポート、au ホームルーター 5Gなど、対象のルーターサービスを解約された場合、割引の適用はお申し込み月の当月をもって終了します。


-
auスマートバリューお申し込み後、対象のご自宅のインターネットサービスが6カ月経過後も開通されていない場合は、順次、割引を一時停止します。開通後、再び割引を再開します。


-
ご自宅のインターネットサービスを提供会社側都合で取り消しされた場合は、取消月の翌月から3カ月目まで割引します。ただし、開通前にお客さま都合により取り消しされた場合は、受け付けの前月利用分をもって割引を終了し、それまでの割引額をau携帯電話（タブレット・PC含む）側のご利用料金に合算し請求します。


-
弊社が実施するほかの施策とは併用できない場合があります。




【共通注意事項】


-
内容などが変更となる場合には事前にお知らせいたします。


-
別途、機種代金、通話・通信料、契約にかかる費用、ユニバーサルサービス料、電話リレーサービス料などがかかります。


-
掲載の内容は2025年7月1日現在の情報です。



閉じる

## auスマートバリューに関するお問い合わせ

チャット形式でかんたんにお問い合わせいただけます。

-
受付時間：24時間（年中無休）


-
回答時間：AI：24時間（コミュニケーター：9時～20時）



[お問い合わせはこちら](https://www.au.com/support/inquiry/message/)

## よくあるご質問

- [【auスマートバリュー】サービスの申込方法を教えてください](https://www.au.com/support/faq/details/00/0000/000022/pg00002213/)
- [【auスマートバリュー】引っ越し時の継続手続きは必要ですか？](https://www.au.com/support/faq/details/00/0000/000022/pg00002236/)
- [【auスマートバリュー】割り引きが適用されなかった理由を知りたい](https://www.au.com/support/faq/details/00/0000/000020/pg00002058/)

## お申し込み

5回線以上のお申し込みについては、au Style/auショップでのお手続きが必要です。

店頭でお申し込み

オンラインでお申し込み

新規契約／機種変更

プラン変更

[![](https://www.au.com/content/dam/au-com/common/icon/cmn_icon_71.png)\\
\\
**au Style/auショップ・au取扱店**](https://www.au.com/mobile/charge/charge-discount/smartvalue/#)

au Style/auショップで手続きを承ります。

[ショップ検索](https://www.au.com/storelocator/)

#### お申し込みに必要なもの

-
契約者ご本人さま確認書類












[ご本人さま確認書類](https://www.au.com/support/service/mobile/procedure/verifying/)


お申し込み

[![](https://www.au.com/content/dam/au-com/common/icon/cmn_icon_72.png)\\
\\
**My au**](https://www.au.com/mobile/charge/charge-discount/smartvalue/#)

ご自宅の「ネット」「電話サービス」と「全てのスマートフォン・タブレット」の契約が「同一姓・同一住所」または「異姓・同一住所・同一の家族割プラスグループにご加入中」である場合、My auでお手続きいただけます。

[お申し込みはこちら](https://my.au.com/aus/au-cs/SvHome?PageID=SSO&ActionID=SVMOUSHIKOMI&agdt=2&_gl=1*8ywd5i*_ga*MTM4NjM1OTM3OS4xNjgzNjgwMjA0*_ga_NEDL1XGXY7*MTc0MzM5NTUzNS4zNDAuMS4xNzQzMzk3MTgxLjAuMC4w)

対象のご自宅のインターネットサービスの新規お申し込みはこちら

### お電話でお問い合わせ・お申し込み

**KDDIブロードバンドキ​ャンペーンセンター**

#### [![](https://www.au.com/content/dam/au-com/common/icon/cmn_icon_freecall.png)\  0120-92-5000](tel:0120925000)

（通話料無料）

受付時間 9:00～20:00 \[土日祝日受付\]

12月31日は18:00まで、1月1日、2日は除く

※auひかりご利用中または手続き中のお問い合わせ先は
![](https://www.au.com/content/dam/au-com/common/icon/cmn_icon_freecall.png) 0077-777（9:00～18:00）となります。

詳しく



### WEBでお申し込み

ご自宅で利用可能なauひかりのサービスをご確認後、そのままお申し込みができます。

※ auひかりの回線をお申し込み後、別途auスマートバリューのお申し込みが必要です。

[WEBでお申し込み](https://auhikari-koushiki.au.com/2110moushikomi_cta_d/?medid=auhikari_web&serial=bnr_hikari&srcid=0017)

詳しく



- 表記の金額は特に記載のある場合を除きすべて税込です。

- [サイトマップ](https://www.au.com/sitemap/)
- [au IDについて](https://www.au.com/au-id/)
- [au ブランドについて](https://www.au.com/brand/)
- [KDDIブランドについて](https://brand.kddi.com/)
- [サステナビリティ](https://www.kddi.com/corporate/sustainability/)
- [法人のお客さま](https://biz.kddi.com/)
- [企業情報](https://www.kddi.com/corporate/)
- [KDDIサイトマップ](https://www.kddi.com/sitemap/)

- [サイトポリシー](https://www.kddi.com/terms/sitepolicy/)
- [My au利用規約](https://www.au.com/my-au/terms/)
- [プライバシーポリシー](https://www.kddi.com/corporate/kddi/public/privacy/)
- [プライバシーポータル](https://www.kddi.com/corporate/kddi/public/privacy-portal/)
- [セキュリティポータル](https://www.kddi.com/corporate/kddi/public/security-portal/)
- [ソーシャルメディアポリシー](https://www.kddi.com/terms/social-media/)
- [動作環境・Cookie情報の利用について](https://www.kddi.com/terms/requirements/)
- [ウェブアクセシビリティの取り組み](https://www.au.com/accessibility/)
- [商標について](https://www.au.com/trademark/)

[![KDDI](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/footer_logo.png?fmt=png-alpha&scl=1)](https://www.kddi.com/)

COPYRIGHT © KDDI CORPORATION, ALL RIGHTS RESERVED.