---
url: "https://www.au.com/mobile/charge/?bid=we-we-gn-2003"
title: "料金・割引 | スマートフォン・携帯電話 | au"
---

![メニュー](https://www.au.com/etc.clientlibs/settings/wcm/designs/au-com/clientlib-site/resources/images/icon/icon_menu_smp.png)[![おもしろい方の未来へ。 au](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/common/icon/au_logo_y.png?scl=1&fmt=png-alpha)](https://www.au.com/)

×

ログインすると、ポイントやお知らせの確認をはじめ、お客さまの契約内容に応じた表示ができます。

[My au利用規約](https://www.au.com/my-au/terms/)、 [My UQ mobile利用規約](https://www.kddi.com/extlib/files/corporate/kddi/kokai/keiyaku_yakkan/pdf/myuqmobile_service.pdf)、 [ID利用規約](https://id.auone.jp/id/pc/legal/auid_terms.html)、 [au Ponta ポイントプログラム規約](https://www.au.com/support/point/regulation-point/) および [アクセスデータの利用](https://www.kddi.com/terms/requirements/#a06) に同意の上、ログインしてください。

ログインすると、ポイントやお知らせの確認をはじめ、お客さまの契約内容に応じた表示ができます。

[My au利用規約](https://www.au.com/my-au/terms/)、 [My UQ mobile利用規約](https://www.kddi.com/extlib/files/corporate/kddi/kokai/keiyaku_yakkan/pdf/myuqmobile_service.pdf)、 [ID利用規約](https://id.auone.jp/id/sp/legal/auid_terms.html)、 [au Ponta ポイントプログラム規約](https://www.au.com/support/point/regulation-point/) および [アクセスデータの利用](https://www.kddi.com/terms/requirements/#a06) に同意の上、ログインしてください。

au IDでログイン

※ログインしない場合は、右上の｢×｣ボタンで本画面を閉じてください。

[![おもしろい方の未来へ。 au](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/common/icon/au_logo_t.png?scl=1&fmt=png-alpha)](https://www.au.com/)

- 商品・サービス
- [サポート](https://www.au.com/support/)
- [My au](https://my.au.com/)

- [![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_shop.png?fmt=png-alpha&scl=1)ショップ検索・\\
\\
来店予約](https://www.au.com/storelocator/)
- [![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_auonlineshop.png?fmt=png-alpha&scl=1)au Online Shop](https://www.au.com/mobile/onlineshop/)
- ![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_search.png?fmt=png-alpha&scl=1)


- [ニュースセンター](https://www.au.com/information/)
- [お問い合わせ](https://www.au.com/support/inquiry/)
- [English](https://www.au.com/english/)
- 企業情報

- [企業情報](https://www.kddi.com/corporate/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
- [サステナビリティ](https://www.kddi.com/corporate/sustainability/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
- [投資家情報](https://www.kddi.com/corporate/ir/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
- [採用情報](https://www.kddi.com/corporate/recruit/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
- [法人のお客さま](https://biz.kddi.com/service/mobile/)

- [企業情報トップ](https://www.kddi.com/corporate/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
- [サステナビリティ](https://www.kddi.com/corporate/sustainability/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
- [投資家情報](https://www.kddi.com/corporate/ir/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
- [採用情報](https://www.kddi.com/corporate/recruit/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
- [法人のお客さま](https://biz.kddi.com/service/mobile/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_smartphone_white.png?fmt=png-alpha&scl=1)

[スマートフォン・携帯電話 TOP](https://www.au.com/mobile/)

- [Android](https://www.au.com/mobile/product/smartphone/)
- [iPhone](https://www.au.com/iphone/)
- [iPad](https://www.au.com/ipad/)
- [料金・割引](https://www.au.com/mobile/charge/)
- [サービス・機能](https://www.au.com/mobile/service/)
- [エリア](https://www.au.com/mobile/area/)
- [キャンペーン](https://www.au.com/mobile/campaign/)
- [スマホ教室](https://school.au.com/?medid=au&serial=global_navi&srcid=074)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_internet_white.png?fmt=png-alpha&scl=1)

[インターネット回線 TOP](https://www.au.com/internet/)

- [auひかり ホーム10ギガ・5ギガ](https://www.au.com/internet/auhikari_10-5g/)
- [auひかり ホーム1ギガ](https://www.au.com/internet/auhikari_1g/)
- [auひかり マンション](https://www.au.com/internet/mansion/)
- [au one net](https://www.au.com/internet/auonenet/)
- [お申し込み・コース変更](https://www.au.com/internet/application/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_pontapass_white_68ca7486d78e8d37.png?fmt=png-alpha&scl=1)

[Pontaパス TOP](https://www.au.com/pontapass/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_payment2_white.png?fmt=png-alpha&scl=1)

[ポイント・決済 TOP](https://www.au.com/payment/)

- [Pontaポイント](https://www.au.com/payment/point/)
- [au PAY（コード支払い/ネット支払い）](https://www.au.com/payment/aupay/)
- [au PAY プリペイドカード](https://www.au.com/payment/prepaid/)
- [au PAY カード](https://www.au.com/payment/card/)
- [au PAY（auかんたん決済）](https://www.au.com/payment/easy/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_hoken_white.png?fmt=png-alpha&scl=1)

[auの金融・保険サービス TOP](https://www.au.com/finance/)

- [auの生命ほけん](https://www.au.com/finance/life-insurance/)
- [auの損害ほけん](https://www.au.com/finance/nonlife-insurance/)
- [auのiDeCo](https://www.au.com/finance/ideco/)
- [auの住宅ローン](https://www.au.com/finance/loan/housing/)
- [auじぶん銀行](https://www.au.com/finance/primebank/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_denki_white.png?fmt=png-alpha&scl=1)

[auでんき・エネルギーサービス TOP](https://www.au.com/energy/)

- [料金プラン](https://www.au.com/energy/denki/merit/plan/)
- [ご契約者向けサポート](https://energy.auone.jp/denki/cs)
- [お引っ越しのご案内](https://energy.auone.jp/denki/merit/moving/)
- [ガスのご案内](https://www.au.com/energy/gas/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_contents_white.png?fmt=png-alpha&scl=1)

[エンタメ TOP](https://www.au.com/entertainment/)

- [映像](https://www.au.com/entertainment/?tabopen=tab_video#anc_01)
- [音楽](https://www.au.com/entertainment/?tabopen=tab_music#anc_01)
- [書籍](https://www.au.com/entertainment/?tabopen=tab_book#anc_01)
- [ニュース](https://www.au.com/entertainment/newspass/)
- [クラウド](https://www.au.com/entertainment/googleone/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_home_white.png?fmt=png-alpha&scl=1)

[くらしのサービス TOP](https://www.au.com/life/)

- [au HOME](https://www.au.com/life/auhome/)
- [auおうちあんしんサポート](https://www.au.com/life/ouchi-anshin/)
- [auわんにゃんサポート](https://pet.life-kurashi.au.com/)
- [au自転車サポート](https://www.au.com/life/bicycle-support/)
- [au PAY ふるさと納税](https://www.au.com/life/furusato-tax/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_wallet_white.png?fmt=png-alpha&scl=1)

[ショッピング TOP](https://www.au.com/shopping/)

- [au PAY マーケット（総合通販）](https://www.au.com/shopping/wowma/)
- [au Online Shop](https://www.au.com/mobile/onlineshop/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_healthcare_white.png?fmt=png-alpha&scl=1)

[ヘルスケア TOP](https://wellness.auone.jp/?medid=au&serial=entertainment&srcid=banner)

x

[![閉じる](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_close_gray_large.png?fmt=png-alpha&scl=1)](https://www.au.com/mobile/charge/?bid=we-we-gn-2003#)

商品・サービス![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_smartphone_gray.png?fmt=png-alpha&scl=1)スマートフォン・携帯電話


- [スマートフォン・携帯電話 TOP](https://www.au.com/mobile/)
- [Android](https://www.au.com/mobile/product/smartphone/)
- [iPhone](https://www.au.com/iphone/)
- [iPad](https://www.au.com/ipad/)
- [料金・割引](https://www.au.com/mobile/charge/)
- [サービス・機能](https://www.au.com/mobile/service/)
- [エリア](https://www.au.com/mobile/area/)
- [キャンペーン](https://www.au.com/mobile/campaign/)
- [スマホ教室](https://school.au.com/?medid=au&serial=global_navi&srcid=074)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_internet_gray.png?fmt=png-alpha&scl=1)インターネット回線


- [インターネット回線 TOP](https://www.au.com/internet/)
- [auひかり ホーム10ギガ・5ギガ](https://www.au.com/internet/auhikari_10-5g/)
- [auひかり ホーム1ギガ](https://www.au.com/internet/auhikari_1g/)
- [auひかり マンション](https://www.au.com/internet/mansion/)
- [au one net](https://www.au.com/internet/auonenet/)
- [お申し込み・コース変更](https://www.au.com/internet/application/)

[![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_pontapass_gray_51d343cd9cd339bd.png?fmt=png-alpha&scl=1)Pontaパス](https://www.au.com/pontapass/)![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_payment2_gray.png?fmt=png-alpha&scl=1)ポイント・決済


- [ポイント・決済 TOP](https://www.au.com/payment/)
- [Pontaポイント](https://www.au.com/payment/point/)
- [au PAY（コード支払い/ネット支払い）](https://www.au.com/payment/aupay/)
- [au PAY プリペイドカード](https://www.au.com/payment/prepaid/)
- [au PAY カード](https://www.au.com/payment/card/)
- [au PAY（auかんたん決済）](https://www.au.com/payment/easy/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_hoken_gray.png?fmt=png-alpha&scl=1)auの金融・保険サービス


- [auの金融・保険サービス TOP](https://www.au.com/finance/)
- [auの生命ほけん](https://www.au.com/finance/life-insurance/)
- [auの損害ほけん](https://www.au.com/finance/nonlife-insurance/)
- [auのiDeCo](https://www.au.com/finance/ideco/)
- [auの住宅ローン](https://www.au.com/finance/loan/housing/)
- [auじぶん銀行](https://www.au.com/finance/primebank/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_denki_gray.png?fmt=png-alpha&scl=1)auでんき・エネルギーサービス


- [auでんき・エネルギーサービス TOP](https://www.au.com/energy/)
- [料金プラン](https://www.au.com/energy/denki/merit/plan/)
- [ご契約者向けサポート](https://energy.auone.jp/denki/cs)
- [お引っ越しのご案内](https://energy.auone.jp/denki/merit/moving/)
- [ガスのご案内](https://www.au.com/energy/gas/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_contents_gray.png?fmt=png-alpha&scl=1)エンタメ


- [エンタメ TOP](https://www.au.com/entertainment/)
- [映像](https://www.au.com/entertainment/?tabopen=tab_video#anc_01)
- [音楽](https://www.au.com/entertainment/?tabopen=tab_music#anc_01)
- [書籍](https://www.au.com/entertainment/?tabopen=tab_book#anc_01)
- [ニュース](https://www.au.com/entertainment/newspass/)
- [クラウド](https://www.au.com/entertainment/googleone/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_home_gray.png?fmt=png-alpha&scl=1)くらしのサービス


- [くらしのサービス TOP](https://www.au.com/life/)
- [au HOME](https://www.au.com/life/auhome/)
- [auおうちあんしんサポート](https://www.au.com/life/ouchi-anshin/)
- [auわんにゃんサポート](https://pet.life-kurashi.au.com/)
- [au自転車サポート](https://www.au.com/life/bicycle-support/)
- [au PAY ふるさと納税](https://www.au.com/life/furusato-tax/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_wallet_gray.png?fmt=png-alpha&scl=1)ショッピング


- [ショッピング TOP](https://www.au.com/shopping/)
- [au PAY マーケット（総合通販）](https://www.au.com/shopping/wowma/)
- [au Online Shop](https://www.au.com/mobile/onlineshop/)

[![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_healthcare_gray.png?fmt=png-alpha&scl=1)ヘルスケア](https://wellness.auone.jp/?medid=au&serial=entertainment&srcid=banner)[サポート](https://www.au.com/support/)My au[My au TOP](https://my.au.com/aus/hc-cs/omt/OMT0010001.hc)[スマートフォン・携帯電話](https://my.au.com/aus/hc-cs/osm/OSM0000001.hc)[インターネット・電話](https://my.au.com/aus/hc-cs/oin/OIN0010001.hc)[au HOME](https://my.au.com/aus/WCV411001/WCE411001.hc)[エンタメ](https://my.au.com/aus/hc-cs/oct/OCT0010001.hc)[au PAY](https://my.au.com/aus/hc-cs/ocd/OCD0010001.hc)[ショッピング](https://my.au.com/aus/hc-cs/owm/OWM0010001.hc)[auでんき](https://my.au.com/aus/hc-cs/oet/OET0010001.hc)[auの金融・保険サービス](https://my.au.com/aus/hc-cs/oir/OIR0000001.hc)[ポイント](https://my.au.com/aus/au-cs1/AuHome?PageID=SSO&ActionID=POINT&agdt=2)[お知らせ](https://my.au.com/aus/hc-cs/ony/ONY0010001.hc)

- [![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_shop.png?fmt=png-alpha&scl=1)ショップ検索・来店予約](https://www.au.com/storelocator/)
- [![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_auonlineshop.png?fmt=png-alpha&scl=1)au Online Shop](https://www.au.com/mobile/onlineshop/)
- [ニュースセンター](https://www.au.com/information/)
  - [お問い合わせ](https://www.au.com/support/inquiry/)
  - [English](https://www.au.com/english/)
  - [企業情報](https://www.kddi.com/corporate/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
  - [サステナビリティ](https://www.kddi.com/corporate/sustainability/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
  - [投資家情報](https://www.kddi.com/corporate/ir/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
  - [採用情報](https://www.kddi.com/corporate/recruit/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
  - [法人のお客さま](https://biz.kddi.com/service/mobile/)

[スマートフォン・携帯電話](https://www.au.com/mobile/charge/?bid=we-we-gn-2003#)

- [スマートフォン・携帯電話](https://www.au.com/mobile/?bid=we-we-gn-2001)
- [スマートフォン・携帯電話 TOP](https://www.au.com/mobile/?bid=we-we-gn-2001)
  - [Android](https://www.au.com/mobile/product/smartphone/)
  - [iPhone](https://www.au.com/iphone/)
  - [料金・割引](https://www.au.com/mobile/charge/?bid=we-we-gn-2003)
  - [サービス・機能](https://www.au.com/mobile/service/?bid=we-we-gn-2004)
  - [エリア](https://www.au.com/mobile/area/?bid=we-we-gn-2005)
  - [キャンペーン](https://www.au.com/mobile/campaign/?bid=we-we-gn-2006)

[![Cart](https://www.au.com/etc.clientlibs/settings/wcm/designs/au-com/clientlib-site/resources/images/icon/icon_cart.png)0](https://www.au.com/cart/?bid=we-we-gn-2904)

1. [トップ](https://www.au.com/)
2. [スマートフォン・携帯電話](https://www.au.com/mobile/)
3. 料金・割引

# 料金・割引

## あなたにピッタリなプランを選ぼう！

[![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/mobile/charge/images/renew2024/mb_charge_icon_md_13_1f9c894cf402b964.png?scl=1&fmt=webp-alpha)\\
\\
詳しく\\
\\
\\
\\
\\
auバリューリンクプラン\\
\\
\\
データを気にせずつかえてPontaパスもコミコミ\\
\\
詳しく](https://www.au.com/mobile/charge/?bid=we-we-gn-2003#anc09)

[![](<Base64-Image-Removed>)\\
\\
詳しく\\
\\
\\
\\
\\
auマネ活バリューリンクプラン\\
\\
\\
データを気にせずつかえてPontaパスもコミコミ。さらにマネ活も。\\
\\
詳しく](https://www.au.com/mobile/charge/?bid=we-we-gn-2003#anc10)

[![](<Base64-Image-Removed>)\\
\\
詳しく\\
\\
\\
\\
\\
使い放題MAX＋\\
\\
\\
データを気にせずつかえる\\
\\
詳しく](https://www.au.com/mobile/charge/?bid=we-we-gn-2003#anc06)

[![](<Base64-Image-Removed>)\\
\\
詳しく\\
\\
\\
\\
\\
auマネ活プラン＋\\
\\
\\
賢くマネ活、データも気にせずつかえる\\
\\
詳しく](https://www.au.com/mobile/charge/?bid=we-we-gn-2003#anc05)

[![](<Base64-Image-Removed>)\\
\\
詳しく\\
\\
\\
\\
\\
スマホミニプラン＋\\
\\
\\
メール・電話が中心の方におすすめ\\
\\
詳しく](https://www.au.com/mobile/charge/?bid=we-we-gn-2003#anc07)

[![](<Base64-Image-Removed>)\\
\\
詳しく\\
\\
\\
\\
NEW\\
\\
\\
U12バリュープラン\\
\\
\\
5～12歳の方がご加入いただけるプラン\\
\\
詳しく](https://www.au.com/mobile/charge/?bid=we-we-gn-2003#anc11)

[![](<Base64-Image-Removed>)\\
\\
詳しく\\
\\
\\
\\
NEW\\
\\
\\
U16バリュープラン\\
\\
\\
5～16歳の方がご加入いただけるプラン\\
\\
詳しく](https://www.au.com/mobile/charge/?bid=we-we-gn-2003#anc12)

[![](<Base64-Image-Removed>)\\
\\
詳しく\\
\\
\\
\\
NEW\\
\\
\\
シニアバリュープラン\\
\\
\\
60歳以上の方がご加入いただけるプラン\\
\\
詳しく](https://www.au.com/mobile/charge/?bid=we-we-gn-2003#anc13)

[スマホ以外の料金プランをみる](https://www.au.com/mobile/charge/charge-list/?bid=we-charge-b-0012)

＼


どれを選べばいいかわからない...

そんなあなたに！

ぴったりのプランを診断！


／

[料金シミュレーションをみる](https://www.au.com/mobile/simulation/)

詳しく



### auバリューリンクプラン

Pontaパスがコミコミ！圏外／混雑時／海外でも安心。

データが使い放題※1のプランです。

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/mobile/charge/smartphone/plan/images/mb_plan_icon-datatraffic.png?fmt=png-alpha&scl=1)データ容量

使い放題

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/mobile/charge/smartphone/plan/images/icon_tooltip_d60664504adab10e.png?fmt=png-alpha&scl=1)

データ容量200GB／月超の場合、通常利用に影響のない範囲（最大5Mbps）で制限。

テザリングなどは合計60GB／月まで

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/mobile/charge/smartphone/plan/images/mb_plan_icon-receiver.png?fmt=png-alpha&scl=1)通話

22円／30秒

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/mobile/charge/smartphone/plan/images/icon_tooltip_d60664504adab10e.png?fmt=png-alpha&scl=1)

通話
衛星電話への通話など、一部通話料が異なる場合があります。また他社が料金設定している電話番号へは指定の通話料がかかります。

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/mobile/charge/smartphone/plan/images/mb_plan_icon_mail.png?fmt=png-alpha&scl=1)国内SMS

送信：3.3円／通

（70文字まで）

受信：無料


![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/mobile/charge/smartphone/plan/images/icon_tooltip_d60664504adab10e.png?fmt=png-alpha&scl=1)

国内SMS機種により最大全角670文字まで送信可能です。ただし、134文字までは2通分、それ以降は67文字ごとに1通分の送信料がかかります。

各種割引適用の場合   **4,980****円**（税抜）

（5,478円）

[料金内訳＋](https://www.au.com/mobile/charge/?bid=we-we-gn-2003#)

[プランの詳細をみる](https://www.au.com/mobile/charge/smartphone/plan/auvaluelink/)

[![あなたの毎日に、もっとつながる、もっといいこと。au Starlink Direct　au 海外放題　au 5G Fast Lane　サブスクぷらすポイント　Pontaパス　プランに含まれるサービスについて 詳しくはこちら　のバナー画像](<Base64-Image-Removed>)](https://www.au.com/pr/newplan/)

1. 200GB／月超の場合通常利用に影響のない範囲（最大5Mbps）で制限。

テザリングなどは合計60GBまで。混雑時など通信速度制限の場合あり。



* * *

#### ​auバリューリンクプランなら  **人気のサービスが**  **セットでおトク！**    auなら、通信料金と各種サービスのご利用料金が  セットになっておトク！

![](<Base64-Image-Removed>)

##### セットのプランをご用意している  サービス一覧

![Netflix、Apple Music、YouTube Premium、TELASA、DAZN、ピッコマ、FODプレミアム、U-NEXT、Amazonプライム](<Base64-Image-Removed>)

[**セットになったプランを詳しくみる**](https://www.au.com/mobile/charge/?bid=we-we-gn-2003#)

###### auバリューリンクプラン   with Amazonプライム

利用できるサービス

![Amazonプライム、TELASA](<Base64-Image-Removed>)

[auバリューリンクプラン with Amazonプライムの詳細をみる](https://www.au.com/mobile/charge/smartphone/plan/auvaluelink-amazon/)

* * *

###### auバリューリンクプラン   Netflixパック（P）

利用できるサービス

![Netflix、TELASA、Amazonプライム](<Base64-Image-Removed>)

[auバリューリンクプラン Netflixパック（P）の詳細をみる](https://www.au.com/mobile/charge/smartphone/plan/auvaluelink-netflix-p/)

* * *

###### auバリューリンクプラン   ドラマ・バラエティパック

利用できるサービス

![TELASA、FODプレミアム、U-NEXT](<Base64-Image-Removed>)

[auバリューリンクプラン ドラマ・バラエティパックの詳細をみる](https://www.au.com/mobile/charge/smartphone/plan/auvaluelink-dmpack/)

* * *

###### auバリューリンクプラン   DAZNパック

利用できるサービス

![DAZN](<Base64-Image-Removed>)

[auバリューリンクプラン DAZNパックの詳細をみる](https://www.au.com/mobile/charge/smartphone/plan/auvaluelink-dazn/)

* * *

###### auバリューリンクプラン   ALL STARパック

利用できるサービス

![Netflix、Apple Music、YouTube Premium、TELASA、DAZN、ピッコマ、Amazonプライム](<Base64-Image-Removed>)

[auバリューリンクプラン ALL STARパックの詳細をみる](https://www.au.com/mobile/charge/smartphone/plan/auvaluelink-allstar/)

閉じる

詳しく



詳しく



### auマネ活バリューリンクプラン

詳しく



**各種「auマネ活バリューリンクプラン」新規受付終了のお知らせ**

各種「auマネ活バリューリンクプラン」は2025年11月30日をもって新規受付を終了いたします。

-
au Online Shopからの受付は同日20:00、My auからの受付は同日21:00、そのほかの受付窓口についてはそれぞれの営業時間内での受付をもって終了いたします。



掲載日：2025年11月17日

詳しく



Pontaパスがコミコミ！圏外／混雑時／海外でも安心。

データが使い放題※2のプランです。

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/mobile/charge/smartphone/plan/images/mb_plan_icon-datatraffic.png?fmt=png-alpha&scl=1)データ容量

使い放題

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/mobile/charge/smartphone/plan/images/icon_tooltip_d60664504adab10e.png?fmt=png-alpha&scl=1)

データ容量200GB／月超の場合、通常利用に影響のない範囲（最大5Mbps）で制限。

テザリングなどは合計60GB／月まで

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/mobile/charge/smartphone/plan/images/mb_plan_icon-receiver.png?fmt=png-alpha&scl=1)通話

22円／30秒

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/mobile/charge/smartphone/plan/images/icon_tooltip_d60664504adab10e.png?fmt=png-alpha&scl=1)

通話
衛星電話への通話など、一部通話料が異なる場合があります。また他社が料金設定している電話番号へは指定の通話料がかかります。

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/mobile/charge/smartphone/plan/images/mb_plan_icon_mail.png?fmt=png-alpha&scl=1)国内SMS

送信：3.3円／通

（70文字まで）

受信：無料


![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/mobile/charge/smartphone/plan/images/icon_tooltip_d60664504adab10e.png?fmt=png-alpha&scl=1)

国内SMS機種により最大全角670文字まで送信可能です。ただし、134文字までは2通分、それ以降は67文字ごとに1通分の送信料がかかります。

![](<Base64-Image-Removed>)

**Pontaポイント毎月合計最大4,000円相当たまる！**


auスマートバリュー／サービス利用・支払いポイント特典／サービス決済特典適用で


実質    **3,480** **円**（税抜）

（4,228円）

[料金内訳＋](https://www.au.com/mobile/charge/?bid=we-we-gn-2003#)

[プランの詳細をみる](https://www.au.com/mobile/charge/smartphone/plan/auvaluelink-moneyact/)

[![あなたの毎日に、もっとつながる、もっといいこと。au Starlink Direct　au 海外放題　au 5G Fast Lane　サブスクぷらすポイント　Pontaパス　プランに含まれるサービスについて 詳しくはこちら　のバナー画像](<Base64-Image-Removed>)](https://www.au.com/pr/newplan/)

1. 200GB／月超の場合通常利用に影響のない範囲（最大5Mbps）で制限。

テザリングなどは合計60GBまで。混雑時など通信速度制限の場合あり。



-
割引適用後の税抜・税込額からPontaポイント還元分を引いた金額。Pontaポイントは後日還元、auご利用料金への充当には上限や条件あり。



* * *

#### ​auマネ活バリューリンクプランなら  **人気のサービスが**  **セットでおトク！**    auなら、通信料金と各種サービスのご利用料金が  セットになっておトク！

![](<Base64-Image-Removed>)

##### セットのプランをご用意している  サービス一覧

![Netflix、Apple Music、YouTube Premium、TELASA、DAZN、ピッコマ、FODプレミアム、U-NEXT、Amazonプライム](<Base64-Image-Removed>)

[**セットになったプランを詳しくみる**](https://www.au.com/mobile/charge/?bid=we-we-gn-2003#)

###### auマネ活バリューリンクプラン   with Amazonプライム

利用できるサービス

![Amazonプライム、TELASA](<Base64-Image-Removed>)

[auマネ活バリューリンクプラン with Amazonプライムの詳細をみる](https://www.au.com/mobile/charge/smartphone/plan/auvaluelink-amazon-moneyact/)

* * *

###### auマネ活バリューリンクプラン   Netflixパック（P）

利用できるサービス

![Netflix、TELASA、Amazonプライム](<Base64-Image-Removed>)

[auマネ活バリューリンクプラン Netflixパック（P）の詳細をみる](https://www.au.com/mobile/charge/smartphone/plan/auvaluelink-netflix-p-moneyact/)

* * *

###### auマネ活バリューリンクプラン   ドラマ・バラエティパック

利用できるサービス

![TELASA、FODプレミアム、U-NEXT](<Base64-Image-Removed>)

[auマネ活バリューリンクプラン ドラマ・バラエティパックの詳細をみる](https://www.au.com/mobile/charge/smartphone/plan/auvaluelink-dmpack-moneyact/)

* * *

###### auマネ活バリューリンクプラン   DAZNパック

利用できるサービス

![DAZN](<Base64-Image-Removed>)

[auマネ活バリューリンクプラン DAZNパックの詳細をみる](https://www.au.com/mobile/charge/smartphone/plan/auvaluelink-dazn-moneyact/)

* * *

###### auマネ活バリューリンクプラン   ALL STARパック

利用できるサービス

![Netflix、Apple Music、YouTube Premium、TELASA、DAZN、ピッコマ、Amazonプライム](<Base64-Image-Removed>)

[auマネ活バリューリンクプラン ALL STARパックの詳細をみる](https://www.au.com/mobile/charge/smartphone/plan/auvaluelink-allstar-moneyact/)

閉じる

詳しく



詳しく



### 使い放題MAX＋ 5G／4G

データが使い放題※3のプランです。データ利用量が合計1GB以下の月は自動で割引！

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/mobile/charge/smartphone/plan/images/mb_plan_icon-datatraffic.png?fmt=png-alpha&scl=1)データ容量

使い放題

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/mobile/charge/smartphone/plan/images/icon_tooltip_d60664504adab10e.png?fmt=png-alpha&scl=1)

データ容量200GB／月超の場合、通常利用に影響のない範囲（最大5Mbps）で制限。

テザリングなどは合計60GB／月まで

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/mobile/charge/smartphone/plan/images/mb_plan_icon-receiver.png?fmt=png-alpha&scl=1)通話

22円／30秒

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/mobile/charge/smartphone/plan/images/icon_tooltip_d60664504adab10e.png?fmt=png-alpha&scl=1)

通話
衛星電話への通話など、一部通話料が異なる場合があります。また他社が料金設定している電話番号へは指定の通話料がかかります。

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/mobile/charge/smartphone/plan/images/mb_plan_icon_mail.png?fmt=png-alpha&scl=1)国内SMS

送信：3.3円／通

（70文字まで）

受信：無料


![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/mobile/charge/smartphone/plan/images/icon_tooltip_d60664504adab10e.png?fmt=png-alpha&scl=1)

国内SMS機種により最大全角670文字まで送信可能です。ただし、134文字までは2通分、それ以降は67文字ごとに1通分の送信料がかかります。

各種割引適用の場合  **4,780****円**（税抜）

（5,258円）

[料金内訳＋](https://www.au.com/mobile/charge/?bid=we-we-gn-2003#)

[プランの詳細をみる](https://www.au.com/mobile/charge/smartphone/plan/data-unlimited-plus/)

[![「au Starlink Direct、au海外放題、au 5G Fast Lane、サブスクぷらすポイント」プランに含まれるサービスについて詳しくはこちら のバナー画像](<Base64-Image-Removed>)](https://www.au.com/mobile/charge/smartphone/plan/service/)

1. 200GB／月超の場合通常利用に影響のない範囲（最大5Mbps）で制限。

テザリングなどは合計60GBまで。混雑時など通信速度制限の場合あり。



* * *

#### ​使い放題MAX＋ 5G／4Gなら  **人気のサービスが**  **セットでおトク！**    auなら、通信料金と各種サービスのご利用料金が  セットになっておトク！

![](<Base64-Image-Removed>)

##### セットのプランをご用意している  サービス一覧

![Netflix、Apple Music、YouTube Premium、TELASA、DAZN、GeForce NOW Powered by au、ピッコマ、FODプレミアム、U-NEXT、Amazonプライム](<Base64-Image-Removed>)

[**セットになったプランを詳しくみる**](https://www.au.com/mobile/charge/?bid=we-we-gn-2003#)

###### 使い放題MAX＋ 5G with   Amazonプライム

利用できるサービス

![Amazonプライム、TELASA](<Base64-Image-Removed>)

[使い放題MAX＋ 5G with Amazonプライムの詳細をみる](https://www.au.com/mobile/charge/smartphone/plan/data-unlimited-plus-amazon/)

* * *

###### 使い放題MAX＋ 5G／4G   Netflixパック（P）

利用できるサービス

![Netflix、TELASA、Amazonプライム](<Base64-Image-Removed>)

[使い放題MAX＋ 5G／4G Netflixパック（P）の詳細をみる](https://www.au.com/mobile/charge/smartphone/plan/data-unlimited-plus-netflix-p/)

* * *

###### 使い放題MAX＋ 5G／4G   ドラマ・バラエティパック

利用できるサービス

![TELASA、FODプレミアム、U-NEXT](<Base64-Image-Removed>)

[使い放題MAX＋ 5G／4G ドラマ・バラエティパックの詳細をみる](https://www.au.com/mobile/charge/smartphone/plan/data-unlimited-plus-dmpack/)

* * *

###### 使い放題MAX＋ 5G／4G   DAZNパック

利用できるサービス

![DAZN](<Base64-Image-Removed>)

[使い放題MAX＋ 5G／4G DAZNパックの詳細をみる](https://www.au.com/mobile/charge/smartphone/plan/data-unlimited-plus-dazn/)

* * *

###### 使い放題MAX＋ 5G   ALL STARパック

利用できるサービス

![Netflix、Apple Music、YouTube Premium、TELASA、DAZN、ピッコマ、Amazonプライム](<Base64-Image-Removed>)

[使い放題MAX＋ 5G ALL STARパックの詳細をみる](https://www.au.com/mobile/charge/smartphone/plan/data-unlimited-plus-allstar/)

閉じる

詳しく



詳しく



### auマネ活プラン＋ 5G／4G

詳しく



**各種「auマネ活プラン＋」新規受付終了のお知らせ**

各種「auマネ活プラン＋」は2025年11月30日をもって新規受付を終了いたします。

-
au Online Shopからの受付は同日20:00、My auからの受付は同日21:00、そのほかの受付窓口についてはそれぞれの営業時間内での受付をもって終了いたします。



掲載日：2025年11月17日

詳しく



auの金融サービスとあわせてご利用でおトク！

データが使い放題※4のプランです。

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/mobile/charge/smartphone/plan/images/mb_plan_icon-datatraffic.png?fmt=png-alpha&scl=1)データ容量

使い放題

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/mobile/charge/smartphone/plan/images/icon_tooltip_d60664504adab10e.png?fmt=png-alpha&scl=1)

データ容量200GB／月超の場合、通常利用に影響のない範囲（最大5Mbps）で制限。

テザリングなどは合計60GB／月まで

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/mobile/charge/smartphone/plan/images/mb_plan_icon-receiver.png?fmt=png-alpha&scl=1)通話

22円／30秒

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/mobile/charge/smartphone/plan/images/icon_tooltip_d60664504adab10e.png?fmt=png-alpha&scl=1)

通話
衛星電話への通話など、一部通話料が異なる場合があります。また他社が料金設定している電話番号へは指定の通話料がかかります。

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/mobile/charge/smartphone/plan/images/mb_plan_icon_mail.png?fmt=png-alpha&scl=1)国内SMS

送信：3.3円／通

（70文字まで）

受信：無料


![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/mobile/charge/smartphone/plan/images/icon_tooltip_d60664504adab10e.png?fmt=png-alpha&scl=1)

国内SMS機種により最大全角670文字まで送信可能です。ただし、134文字までは2通分、それ以降は67文字ごとに1通分の送信料がかかります。

![](<Base64-Image-Removed>)

**Pontaポイント毎月合計最大4,000円相当たまる！**


auスマートバリュー／サービス利用・支払いポイント特典／サービス決済特典適用で


実質    **3,280** **円**（税抜）

（4,008円）

[料金内訳＋](https://www.au.com/mobile/charge/?bid=we-we-gn-2003#)

[プランの詳細をみる](https://www.au.com/mobile/charge/smartphone/plan/data-unlimited-moneyact-plus/)

[auマネ活プラン＋の特集ページをみる](https://www.au.com/pr/moneyactivity/plan/)

[![「au Starlink Direct、au海外放題、au 5G Fast Lane、サブスクぷらすポイント」プランに含まれるサービスについて詳しくはこちら のバナー画像](<Base64-Image-Removed>)](https://www.au.com/mobile/charge/smartphone/plan/service/)

1. 200GB／月超の場合通常利用に影響のない範囲（最大5Mbps）で制限。

テザリングなどは合計60GBまで。混雑時など通信速度制限の場合あり。



-
割引適用後の税抜・税込額からPontaポイント還元分を引いた金額。Pontaポイントは後日還元、auご利用料金への充当には上限や条件あり。



* * *

#### ​auマネ活プラン＋ 5G／4Gなら  **人気のサービスが**  **セットでおトク！**    auなら、通信料金と各種サービスのご利用料金が  セットになっておトク！

![](<Base64-Image-Removed>)

##### セットのプランをご用意している  サービス一覧

![Netflix、Apple Music、YouTube Premium、TELASA、DAZN、GeForce NOW Powered by au、ピッコマ、FODプレミアム、U-NEXT、Amazonプライム](<Base64-Image-Removed>)

[**セットになったプランを詳しくみる**](https://www.au.com/mobile/charge/?bid=we-we-gn-2003#)

###### auマネ活プラン＋ 5G with   Amazonプライム

利用できるサービス

![Amazonプライム、TELASA](<Base64-Image-Removed>)

[auマネ活プラン＋ 5G with Amazonプライムの詳細をみる](https://www.au.com/mobile/charge/smartphone/plan/data-unlimited-amazon-moneyact-plus/)

* * *

###### auマネ活プラン＋ 5G／4G   Netflixパック（P）

利用できるサービス

![Netflix、TELASA、Amazonプライム](<Base64-Image-Removed>)

[auマネ活プラン＋ 5G／4G Netflixパック（P）の詳細をみる](https://www.au.com/mobile/charge/smartphone/plan/data-unlimited-netflix-p-moneyact-plus/)

* * *

###### auマネ活プラン＋ 5G／4G   ドラマ・バラエティパック

利用できるサービス

![TELASA、FODプレミアム、U-NEXT](<Base64-Image-Removed>)

[auマネ活プラン＋ 5G／4G ドラマ・バラエティパックの詳細をみる](https://www.au.com/mobile/charge/smartphone/plan/data-unlimited-dmpack-moneyact-plus/)

* * *

###### auマネ活プラン＋ 5G／4G   DAZNパック

利用できるサービス

![DAZN](<Base64-Image-Removed>)

[auマネ活プラン＋ 5G／4G DAZNパックの詳細をみる](https://www.au.com/mobile/charge/smartphone/plan/data-unlimited-dazn-moneyact-plus/)

* * *

###### auマネ活プラン＋ 5G   ALL STARパック

利用できるサービス

![Netflix、Apple Music、YouTube Premium、TELASA、DAZN、ピッコマ、Amazonプライム](<Base64-Image-Removed>)

[auマネ活プラン＋ 5G ALL STARパックの詳細をみる](https://www.au.com/mobile/charge/smartphone/plan/data-unlimited-allstar-moneyact-plus/)

閉じる

詳しく



詳しく



### スマホミニプラン＋ 5G／4G

5GBまでつかった分だけお支払いのプラン

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/mobile/charge/smartphone/plan/images/mb_plan_icon-datatraffic.png?fmt=png-alpha&scl=1)データ容量

5GB／月

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/mobile/charge/smartphone/plan/images/mb_plan_icon-receiver.png?fmt=png-alpha&scl=1)通話

22円／30秒

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/mobile/charge/smartphone/plan/images/icon_tooltip_d60664504adab10e.png?fmt=png-alpha&scl=1)

通話
衛星電話への通話など、一部通話料が異なる場合があります。また他社が料金設定している電話番号へは指定の通話料がかかります。

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/mobile/charge/smartphone/plan/images/mb_plan_icon_mail.png?fmt=png-alpha&scl=1)国内SMS

送信：3.3円／通

（70文字まで）

受信：無料


![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/mobile/charge/smartphone/plan/images/icon_tooltip_d60664504adab10e.png?fmt=png-alpha&scl=1)

国内SMS機種により最大全角670文字まで送信可能です。ただし、134文字までは2通分、それ以降は67文字ごとに1通分の送信料がかかります。

各種割引適用の場合

～1GB

**2,180** **円**（税抜）

（2,398円）

～3GB

**3,680****円** ～（税抜）

（4,048円）

～5GB

**5,180****円** ～（税抜）

（5,698円）

[料金内訳＋](https://www.au.com/mobile/charge/?bid=we-we-gn-2003#)

[プランの詳細をみる](https://www.au.com/mobile/charge/smartphone/plan/sp-mini-plus/)

[![「au Starlink Direct、サブスクぷらすポイント」プランに含まれるサービスについて詳しくはこちら のバナー画像](<Base64-Image-Removed>)](https://www.au.com/mobile/charge/smartphone/plan/service/)

詳しく



詳しく



NEW

### U12バリュープラン

安心と学びがセットになったおトクなプラン！

5～12歳の方がご加入いただけます。

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/mobile/charge/smartphone/plan/images/mb_plan_icon-receiver.png?fmt=png-alpha&scl=1)通話

22円／30秒

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/mobile/charge/smartphone/plan/images/icon_tooltip_d60664504adab10e.png?fmt=png-alpha&scl=1)

通話衛星電話への通話など、一部通話料が異なる場合があります。また他社が料金設定している電話暗号へは指定の通話料がかかります。

同一の「家族割」にご加入の家族への国内通話は無料でご利用いただけます（別途お申し込みが必要）。

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/mobile/charge/smartphone/plan/images/mb_plan_icon_mail.png?fmt=png-alpha&scl=1)国内SMS

送信：3.3円／通

（70文字まで）

受信：無料


![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/mobile/charge/smartphone/plan/images/icon_tooltip_d60664504adab10e.png?fmt=png-alpha&scl=1)

国内SMS機種により最大全角670文字まで送信可能です。ただし、134文字までは2通分、それ以降は67文字ごとに1通分の送信料がかかります。

同一の「家族割」にご加入の家族への国内SMSは無料でご利用いただけます（別途お申し込みが必要）。

**各種割引適用後**

**500** 円／月（税抜）

（550円／月）

[料金内訳＋](https://www.au.com/mobile/charge/?bid=we-we-gn-2003#)

[プランの詳細をみる](https://www.au.com/mobile/charge/smartphone/plan/u12value/)

[![安心 スマホの使い過ぎ防止に、安全 コドマモ(790円/月相当)がコミコミ！、学び auキッズラボ(1,100円/月相当)がコミコミ！](<Base64-Image-Removed>)](https://www.au.com/pr/valueplan_junior/#kds-u12)

対象機種なら「au Starlink Direct」もつかえる！

[詳しくはこちら](https://www.au.com/mobile/service/starlink-direct/)

詳しく



詳しく



NEW

### U16バリュープラン

使い方に合わせたおトクなプラン。

5～16歳の方がご加入いただけます。

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/mobile/charge/smartphone/plan/images/mb_plan_icon-datatraffic.png?fmt=png-alpha&scl=1)データ容量

20GB／月

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/mobile/charge/smartphone/plan/images/mb_plan_icon-receiver.png?fmt=png-alpha&scl=1)通話

22円／30秒

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/mobile/charge/smartphone/plan/images/icon_tooltip_d60664504adab10e.png?fmt=png-alpha&scl=1)

通話
衛星電話への通話など、一部通話料が異なる場合があります。また他社が料金設定している電話番号へは指定の通話料がかかります。

同一の「家族割」にご加入の家族への国内通話は無料でご利用いただけます（別途お申し込みが必要）。

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/mobile/charge/smartphone/plan/images/mb_plan_icon_mail.png?fmt=png-alpha&scl=1)国内SMS

送信：3.3円／通

（70文字まで）

受信：無料


![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/mobile/charge/smartphone/plan/images/icon_tooltip_d60664504adab10e.png?fmt=png-alpha&scl=1)

国内SMS機種により最大全角670文字まで送信可能です。ただし、134文字までは2通分、それ以降は67文字ごとに1通分の送信料がかかります。

同一の「家族割」にご加入の家族への国内SMSは無料でご利用いただけます（別途お申し込みが必要）。

**各種割引適用後**

～3GB

**980**円／月（税抜）（1,078円／月）

3GB超～20GB

**2,480**円／月（税抜）（2,728円／月）

[料金内訳＋](https://www.au.com/mobile/charge/?bid=we-we-gn-2003#)

[プランの詳細をみる](https://www.au.com/mobile/charge/smartphone/plan/u16value/)

[![「au Starlink Direct、サブスクぷらすポイント」プランに含まれるサービスについて詳しくはこちら のバナー画像](<Base64-Image-Removed>)](https://www.au.com/mobile/charge/smartphone/plan/service/)

詳しく



詳しく



NEW

### シニアバリュープラン

5分通話かけ放題・迷惑電話対策つきで安心・おトク！

60歳以上の方がご加入いただけます。

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/mobile/charge/smartphone/plan/images/mb_plan_icon-datatraffic.png?fmt=png-alpha&scl=1)データ容量

5GB／月

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/mobile/charge/smartphone/plan/images/mb_plan_icon-receiver.png?fmt=png-alpha&scl=1)通話

5分／回以内の国内通話が

かけ放題

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/mobile/charge/smartphone/plan/images/icon_tooltip_d60664504adab10e.png?fmt=png-alpha&scl=1)

通話
0570（ナビダイヤル）・衛星電話など、かけ放題の対象外となる通話があります。1回の通話が5分を超えた場合、5分超過分につき、22円／30秒の通話料が別途かかります。

同一の「家族割」にご加入の家族への国内通話は無料でご利用いただけます（別途お申し込みが必要）。

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/mobile/charge/smartphone/plan/images/mb_plan_icon_mail.png?fmt=png-alpha&scl=1)国内SMS

送信：3.3円／通

（70文字まで）

受信：無料


![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/mobile/charge/smartphone/plan/images/icon_tooltip_d60664504adab10e.png?fmt=png-alpha&scl=1)

国内SMS機種により最大全角670文字まで送信可能です。ただし、134文字までは2通分、それ以降は67文字ごとに1通分の送信料がかかります。

同一の「家族割」にご加入の家族への国内SMSは無料でご利用いただけます（別途お申し込みが必要）。

**各種割引適用後**

**2,480** 円／月（税抜）

（2,728円／月）

[料金内訳＋](https://www.au.com/mobile/charge/?bid=we-we-gn-2003#)

[プランの詳細をみる](https://www.au.com/mobile/charge/smartphone/plan/seniorvalue/)

[![「au Starlink Direct、サブスクぷらすポイント」プランに含まれるサービスについて詳しくはこちら のバナー画像](<Base64-Image-Removed>)](https://www.au.com/mobile/charge/smartphone/plan/service/)

詳しく



[注意事項をみる](https://www.au.com/mobile/charge/?bid=we-we-gn-2003#attention)

[プランを変更する](https://my.au.com/aus/au-cs1/AuHome?PageID=SSO&ActionID=CHARGEPLAN&agdt=2)

## 製品の料金を知りたい

詳しく



auのスマートフォン、タブレット、

ケータイ端末の価格一覧

![](<Base64-Image-Removed>)

[製品価格一覧](https://www.au.com/mobile/product/price/)

詳しく



詳しく



製品のスペックを比較しながら

料金を確認

![](<Base64-Image-Removed>)

[製品比較リスト](https://www.au.com/mobile/product/comparison/)

詳しく



[スマートフォン・携帯電話トップをみる](https://www.au.com/mobile/)

## 割引


料金プランと一緒のご利用で、

さらにおトクになります。


[詳しく\\
\\
\\
\\
**auスマートバリュー**\\
\\
ネットサービスとセットでご利用いただくと、スマホのご利用料金を割り引きます。\\
\\
詳しくみる](https://www.au.com/mobile/charge/charge-discount/smartvalue/)

[詳しく\\
\\
\\
\\
**家族割プラス**\\
\\
家族割プラス／auスマートバリューグループに加入すると割引を受けられます。\\
\\
詳しくみる](https://www.au.com/mobile/charge/charge-discount/kazoku-wari-plus/)

[詳しく\\
\\
\\
\\
**au PAY カードお支払い割**\\
\\
au PAY カードでのお支払いで月々のご利用料金を割り引きいたします。\\
\\
詳しくみる](https://www.au.com/mobile/charge/discount-option/aupay-card-wari/)

## オプション

[![](<Base64-Image-Removed>)\\
\\
詳しく\\
\\
\\
\\
NEW\\
\\
**データ1日放題**\\
\\
24時間使い放題でデータ通信できるサービスです。\\
\\
**料金：** 550円／1回（24時間）\\
\\
詳しく](https://www.au.com/mobile/charge/discount-option/data-houdai/)

[![](<Base64-Image-Removed>)\\
\\
詳しく\\
\\
\\
\\
**通話定額2／通話定額ライト2**\\
\\
国内通話をおトクにご利用いただけるオプションです。\\
\\
詳しく](https://www.au.com/mobile/charge/smartphone/plan/calling-option2/)

[![](<Base64-Image-Removed>)\\
\\
詳しく\\
\\
\\
\\
**電話きほんパック（V）**\\
\\
三者通話サービスなど、人気の通話オプションをパックにしたオプションです。\\
\\
詳しく](https://www.au.com/mobile/service/denwa-kihon-v/)

[![](<Base64-Image-Removed>)\\
\\
詳しく\\
\\
\\
\\
**テザリングオプション**\\
\\
PCやタブレットをauスマホとつないで、ネット接続を楽しむことができます。\\
\\
詳しく](https://www.au.com/mobile/service/tethering/)

[![](<Base64-Image-Removed>)\\
\\
詳しく\\
\\
\\
\\
**故障紛失サポート**\\
\\
おつかいの端末の紛失時に、端末交換ができたり、修理代金が割引になります。\\
\\
詳しく](https://www.au.com/mobile/service/kosho-funshitsu/)

[![](<Base64-Image-Removed>)\\
\\
詳しく\\
\\
\\
\\
**Pontaパス（旧auスマートパスプレミアム）**\\
\\
豊富なエンタメコンテンツが楽しめるほか、故障紛失時のサポートが受けられます。\\
\\
詳しく](https://www.au.com/entertainment/smartpass/)

[![](<Base64-Image-Removed>)\\
\\
詳しく\\
\\
\\
\\
**使い方サポート**\\
\\
スマホやタブレット、アプリなどのつかい方まで、アドバイザーが丁寧にご案内いたします。\\
\\
詳しく](https://www.au.com/mobile/service/tsukaikata-support/)

[その他のオプション](https://www.au.com/mobile/charge/discount-option/)

## 各種割引・キャンペーン

# 料金・割引 \| スマートフォン・携帯電話 \| au

[![スキマ時間に楽しく英語が学べる「AEONチャンネル」アプリ 使い放題MAXやauマネ活プランなどご加入中の方ならおトク！ 特典1：「AEONチャンネル」アプリが月額660円（税込）→無料で使える 特典2：アプリインストール＆au IDで初回ログインで100Pontaポイントもらえる！ 条件など詳しくはこちら](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/mobile/charge/images/renew2024/mb_charge_bnr_03_a21153288eaff4d8.png?scl=1&fmt=webp-alpha)](https://aeon-ch.auone.jp/lp/index.html?utm_medium=au.com&utm_source=ryoukin&utm_campaign=0084&utm_id=240401)

[![au 最新iPhoneもいきなりおトク！ 回線契約がなくてもOK！★ スマホトクするプログラム ★：au回線解約後も本プログラムの継続利用は可能です。 ※au回線をお持ちでない未成年者は対象外です。 ※プログラム料は無料です。お申し込みが必要です。 条件など詳しくはこちら](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/mobile/charge/images/renew2024/mb_charge_bnr_04_bac3e4ffbd4fe9ff.png?scl=1&fmt=webp-alpha)](https://www.au.com/mobile/tokusuru-program/)

[![スキマ時間に楽しく英語が学べる「AEONチャンネル」アプリ 使い放題MAXやauマネ活プランなどご加入中の方ならおトク！ 特典1：「AEONチャンネル」アプリが月額660円（税込）→無料で使える 特典2：アプリインストール＆au IDで初回ログインで100Pontaポイントもらえる！ 条件など詳しくはこちら](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/mobile/charge/images/renew2024/mb_charge_bnr_03_a21153288eaff4d8.png?scl=1&fmt=webp-alpha)](https://aeon-ch.auone.jp/lp/index.html?utm_medium=au.com&utm_source=ryoukin&utm_campaign=0084&utm_id=240401)

[![au 最新iPhoneもいきなりおトク！ 回線契約がなくてもOK！★ スマホトクするプログラム ★：au回線解約後も本プログラムの継続利用は可能です。 ※au回線をお持ちでない未成年者は対象外です。 ※プログラム料は無料です。お申し込みが必要です。 条件など詳しくはこちら](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/mobile/charge/images/renew2024/mb_charge_bnr_04_bac3e4ffbd4fe9ff.png?scl=1&fmt=webp-alpha)](https://www.au.com/mobile/tokusuru-program/)

[![スキマ時間に楽しく英語が学べる「AEONチャンネル」アプリ 使い放題MAXやauマネ活プランなどご加入中の方ならおトク！ 特典1：「AEONチャンネル」アプリが月額660円（税込）→無料で使える 特典2：アプリインストール＆au IDで初回ログインで100Pontaポイントもらえる！ 条件など詳しくはこちら](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/mobile/charge/images/renew2024/mb_charge_bnr_03_a21153288eaff4d8.png?scl=1&fmt=webp-alpha)](https://aeon-ch.auone.jp/lp/index.html?utm_medium=au.com&utm_source=ryoukin&utm_campaign=0084&utm_id=240401)

[![au 最新iPhoneもいきなりおトク！ 回線契約がなくてもOK！★ スマホトクするプログラム ★：au回線解約後も本プログラムの継続利用は可能です。 ※au回線をお持ちでない未成年者は対象外です。 ※プログラム料は無料です。お申し込みが必要です。 条件など詳しくはこちら](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/mobile/charge/images/renew2024/mb_charge_bnr_04_bac3e4ffbd4fe9ff.png?scl=1&fmt=webp-alpha)](https://www.au.com/mobile/tokusuru-program/)

- 1
- 2

PreviousNext

[キャンペーン・割引特典](https://www.au.com/mobile/campaign/)

## 注意事項

### 【全料金プラン共通】

-
混雑時や大量のデータ通信のご利用があった場合などに通信速度の制限を行うことがあります。


-
5G対応スマートフォンは4G料金プランではご利用になれません。



-
テザリング、データシェアのご利用には、データ容量の上限があります。上限を超えた場合、これらのサービスの通信速度は送受信最大128kbpsとなります。

（通信速度の制限は、翌月1日に順次解除されます。）



### 【Amazonがついてくる料金プランについて】

-
本プランはKDDI株式会社提供です。


-
Amazon プライムの会費は、KDDI株式会社が負担しています。


-
Amazon、Amazonプライムおよびこれらに関連するすべての商標は、Amazon.com, Inc.またはその関連会社の商標です。



[お申し込み受付終了プラン](https://www.au.com/mobile/charge/application-ended/)

-
掲載の内容は2025年11月17日時点の情報です。



- 表記の金額は特に記載のある場合を除きすべて税込です。

×

### 実質金額内訳

詳しく



ご利用料金

（条件適用前）

8,280円（税抜）

（9,108円）

＋

auスマートバリュー\*1

－1,000円（税抜）

（－1,100円）

↓

Ⅰ：合計額

7,280円（税抜）

（8,008円）

詳しく



＋

詳しく



Ⅱ：サービス利用・支払いポイント特典

（合計最大1,000円相当還元）

au PAY カード特典

300円相当還元

auじぶん銀行特典

300円相当還元

通信料金支払い特典

最大400円相当還元\*2

詳しく



＋

詳しく



Ⅲ：サービス決済特典

（合計最大3,000円相当還元）

au PAY 決済特典

-
「au PAY ゴールドカード」を保有の場合、1決済につき「au PAY（コード支払い／ネット支払い）」で200円ごとに9P



最大1,500円相当還元

au PAYカード決済特典

-
「au PAY ゴールドカード」でお支払いの場合、1決済につき100円ごとに4P



最大1,500円相当還元

詳しく



↓

詳しく



実質合計額

（Ⅰ＋Ⅱ＋Ⅲ）

3,280円（税抜）

（4,008円※）

※Pontaポイント還元前7,280円に対する消費税728円を含む額

詳しく



-
割引適用後の税抜・税込額からPontaポイント還元分を引いた金額。Pontaポイントは後日還元、auご利用料金への充当には上限や条件あり。



[Pontaポイントのauご利用料金への充当についてはこちら](https://www.au.com/support/faq/details/00/0000/000001/pg00000167/)

【auスマートバリュー】

1. 対象のご自宅のインターネットサービスなどのご加入が必要です。加入例）auひかりホーム・ずっとギガ得プラン（契約期間3年）の場合、基本料金5,610円／月＋電話月額利用料 770円／月が別途必要です。インターネットサービス解約時に、ご契約期間に応じて契約解除料4,730円が発生する場合があります。



[auスマートバリューの詳細についてはこちら](https://www.au.com/mobile/charge/charge-discount/smartvalue/)

1. 「au PAY カード」会員かつ「auじぶん銀行」の口座を保有している方が、ご利用料金を「au PAY カード」でお支払い設定かつその「au PAY カード」の引き落とし先を「auじぶん銀行」に設定した場合の還元額です。



×

詳しく



#### 毎月のお支払い額

① ご利用料金（割引適用前）

**7,788円**

* * *

② auスマートバリュー★

**－1,100円**

③ 家族割プラス

3人以上でご加入時

**－1,210円**

2人でご加入時

**－660円**

④ au PAY カードお支払い割

**－220円**

* * *

**お支払い合計額①～④**

**4,780円（税抜）（5,258円）**

詳しく



★：対象のご自宅のインターネットサービスなどのご加入が必要です。

加入例）auひかりホーム・ずっとギガ得プラン（契約期間3年）の場合、基本料金5,610円／月＋電話月額利用料 770円／月が別途必要です。インターネットサービス解約時に、ご契約期間に応じて契約解除料4,730円が発生する場合があります。

[auスマートバリューの詳細についてはこちら](https://www.au.com/mobile/charge/charge-discount/smartvalue/)

×

詳しく




毎月のお支払い額（内訳）　～1GB


① ご利用料金（割引適用前）

**4,928円**

* * *

② auスマートバリュー★

**－1,100円**

③ 家族割プラス

3人以上でご加入時

**－1,210円**

2人でご加入時

**－660円**

④ au PAY カードお支払い割

**－220円**

* * *

**お支払い合計額①～④**

**2,180円（税抜）（2,398円）**

詳しく



![〜1GBまで：税抜4,280円（4,708円）②③④適用後→税抜1,980円（2,178円） 〜3GBまで：税抜5,780円（6,358円）②③④適用後→税抜3,480円（3,828円） 〜5GBまで：税抜7,280円（8,008円）②③④適用後→税抜4,980円（5,478円）](<Base64-Image-Removed>)

★：対象のご自宅のインターネットサービスなどのご加入が必要です。

加入例）auひかりホーム・ずっとギガ得プラン（契約期間3年）の場合、基本料金5,610円／月＋電話月額利用料 770円／月が別途必要です。インターネットサービス解約時に、ご契約期間に応じて契約解除料4,730円が発生する場合があります。

[auスマートバリューの詳細についてはこちら](https://www.au.com/mobile/charge/charge-discount/smartvalue/)

×

詳しく



#### 毎月のお支払い額

① ご利用料金（割引適用前）

**8,008円**

* * *

② auスマートバリュー★

**－1,100円**

③ 家族割プラス

3人以上でご加入時

**－1,210円**

2人でご加入時

**－660円**

④ au PAY カードお支払い割

**－220円**

* * *

**お支払い合計額①～④**

**4,980円（税抜）（5,478円）**

詳しく



★：対象のご自宅のインターネットサービスなどのご加入が必要です。

加入例）auひかりホーム・ずっとギガ得プラン（契約期間3年）の場合、基本料金5,610円／月＋電話月額利用料 770円／月が別途必要です。インターネットサービス解約時に、ご契約期間に応じて契約解除料4,730円が発生する場合があります。

[auスマートバリューの詳細についてはこちら](https://www.au.com/mobile/charge/charge-discount/smartvalue/)

×

### 実質金額内訳

詳しく



ご利用料金

（条件適用前）

8,480円（税抜）

（9,328円）

＋

auスマートバリュー\*1

－1,000円（税抜）

（－1,100円）

↓

Ⅰ：合計額

7,480円（税抜）

（8,228円）

詳しく



＋

詳しく



Ⅱ：サービス利用・支払いポイント特典

（合計最大1,000円相当還元）

au PAY カード特典

300円相当還元

auじぶん銀行特典

300円相当還元

通信料金支払い特典

最大400円相当還元\*2

詳しく



＋

詳しく



Ⅲ：サービス決済特典

（合計最大3,000円相当還元）

au PAY 決済特典

-
「au PAY ゴールドカード」を保有の場合、1決済につき「au PAY（コード支払い／ネット支払い）」で200円ごとに9P



最大1,500円相当還元

au PAYカード決済特典

-
「au PAY ゴールドカード」でお支払いの場合、1決済につき100円ごとに4P



最大1,500円相当還元

詳しく



↓

詳しく



実質合計額

（Ⅰ＋Ⅱ＋Ⅲ）

3,480円（税抜）

＋消費税748円（Pontaポイント還元前7,480円に対する税）

（4,228円）

詳しく



-
割引適用後の税抜・税込額からPontaポイント還元分を引いた金額。Pontaポイントは後日還元、auご利用料金への充当には上限や条件あり。



[Pontaポイントのauご利用料金への充当についてはこちら](https://www.au.com/support/faq/details/00/0000/000001/pg00000167/)

【auスマートバリュー】

1. 対象のご自宅のインターネットサービスなどのご加入が必要です。加入例）auひかりホーム・ずっとギガ得プラン（契約期間3年）の場合、基本料金5,610円／月＋電話月額利用料 770円／月が別途必要です。インターネットサービス解約時に、ご契約期間に応じて契約解除料4,730円が発生する場合があります。



[auスマートバリューの詳細についてはこちら](https://www.au.com/mobile/charge/charge-discount/smartvalue/)

1. 「au PAY カード」会員かつ「auじぶん銀行」の口座を保有している方が、ご利用料金を「au PAY カード」でお支払い設定かつその「au PAY カード」の引き落とし先を「auじぶん銀行」に設定した場合の還元額です。



×

詳しく



#### 毎月のお支払い額

① ご利用料金（割引適用前）

**4,048円**

* * *

② auスマートバリュー★

**－1,100円**

③ au PAY カードお支払い割

**－220円**

または

auじぶん銀行お支払い割

* * *

**お支払い合計額①～③**

**2,480円（税抜）（2,728円）**

詳しく



★：対象のご自宅のインターネットサービスなどのご加入が必要です。

加入例）auひかりホーム・ずっとギガ得プラン（契約期間3年）の場合、基本料金5,610円／月＋電話月額利用料 770円／月が別途必要です。インターネットサービス解約時に、ご契約期間に応じて契約解除料4,730円が発生する場合があります。

[auスマートバリューの詳細についてはこちら](https://www.au.com/mobile/charge/charge-discount/smartvalue/)

×

詳しく




毎月のお支払い額（内訳）　～3GB


① ご利用料金（割引適用前）

**2,398円**

* * *

② auスマートバリュー★

**ー550円**

③ 家族割プラス

3人以上でご加入時

**ー550円**

2人でご加入時

**ー220円**

④ au PAY カードお支払い割

**－220円**

* * *

**お支払い合計額①～④**

**980円（税抜）（1,078円）**

詳しく



★：対象のご自宅のインターネットサービスなどのご加入が必要です。

加入例）auひかりホーム・ずっとギガ得プラン（契約期間3年）の場合、基本料金5,610円／月＋電話月額利用料 770円／月が別途必要です。インターネットサービス解約時に、ご契約期間に応じて契約解除料4,730円が発生する場合があります。

[auスマートバリューの詳細についてはこちら](https://www.au.com/mobile/charge/charge-discount/smartvalue/)

![データ利用料が3GB以下の月は1,078円/月で使える！](<Base64-Image-Removed>)

1. 本プランは19歳になる月の翌月から、データ容量によりご利用料金が変動せず20GBまで定額で使えます。データ利用量が3GB以下の場合も月額料金は料金表内の「3GB超～20GB」の金額です。ご希望でない場合は、お客さまご自身でプラン変更のお手続きが可能です。プラン料金、その他の提供条件には変更の可能性があります。



×

詳しく



#### 毎月のお支払い額

① ご利用料金（割引適用前）

**1,870円**

* * *

② U12家族割

**－1,100円**

③ au PAY カードお支払い割

**－220円**

* * *

**お支払い合計額①～③**

**500円（税抜）（550円）**

詳しく



- [サイトマップ](https://www.au.com/sitemap/)
- [au IDについて](https://www.au.com/au-id/)
- [au ブランドについて](https://www.au.com/brand/)
- [KDDIブランドについて](https://brand.kddi.com/)
- [サステナビリティ](https://www.kddi.com/corporate/sustainability/)
- [法人のお客さま](https://biz.kddi.com/)
- [企業情報](https://www.kddi.com/corporate/)
- [KDDIサイトマップ](https://www.kddi.com/sitemap/)

- [サイトポリシー](https://www.kddi.com/terms/sitepolicy/)
- [My au利用規約](https://www.au.com/my-au/terms/)
- [プライバシーポリシー](https://www.kddi.com/corporate/kddi/public/privacy/)
- [プライバシーポータル](https://www.kddi.com/corporate/kddi/public/privacy-portal/)
- [セキュリティポータル](https://www.kddi.com/corporate/kddi/public/security-portal/)
- [ソーシャルメディアポリシー](https://www.kddi.com/terms/social-media/)
- [動作環境・Cookie情報の利用について](https://www.kddi.com/terms/requirements/)
- [ウェブアクセシビリティの取り組み](https://www.au.com/accessibility/)
- [商標について](https://www.au.com/trademark/)

[![KDDI](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/footer_logo.png?fmt=png-alpha&scl=1)](https://www.kddi.com/)

COPYRIGHT © KDDI CORPORATION, ALL RIGHTS RESERVED.