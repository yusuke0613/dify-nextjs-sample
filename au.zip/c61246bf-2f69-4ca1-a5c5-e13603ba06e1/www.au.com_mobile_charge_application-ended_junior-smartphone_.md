---
url: "https://www.au.com/mobile/charge/application-ended/junior-smartphone/"
title: "ジュニアスマートフォンプラン | 料金・割引：スマートフォン・携帯電話 | au"
---

![メニュー](https://www.au.com/etc.clientlibs/settings/wcm/designs/au-com/clientlib-site/resources/images/icon/icon_menu_smp.png)[![おもしろい方の未来へ。 au](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/common/icon/au_logo_y.png?scl=1&fmt=png-alpha)](https://www.au.com/)

×

ログインすると、ポイントやお知らせの確認をはじめ、お客さまの契約内容に応じた表示ができます。

[My au利用規約](https://www.au.com/my-au/terms/)、 [My UQ mobile利用規約](https://www.kddi.com/extlib/files/corporate/kddi/kokai/keiyaku_yakkan/pdf/myuqmobile_service.pdf)、 [ID利用規約](https://id.auone.jp/id/pc/legal/auid_terms.html)、 [au Ponta ポイントプログラム規約](https://www.au.com/support/point/regulation-point/) および [アクセスデータの利用](https://www.kddi.com/terms/requirements/#a06) に同意の上、ログインしてください。

ログインすると、ポイントやお知らせの確認をはじめ、お客さまの契約内容に応じた表示ができます。

[My au利用規約](https://www.au.com/my-au/terms/)、 [My UQ mobile利用規約](https://www.kddi.com/extlib/files/corporate/kddi/kokai/keiyaku_yakkan/pdf/myuqmobile_service.pdf)、 [ID利用規約](https://id.auone.jp/id/sp/legal/auid_terms.html)、 [au Ponta ポイントプログラム規約](https://www.au.com/support/point/regulation-point/) および [アクセスデータの利用](https://www.kddi.com/terms/requirements/#a06) に同意の上、ログインしてください。

au IDでログイン

※ログインしない場合は、右上の｢×｣ボタンで本画面を閉じてください。

[![おもしろい方の未来へ。 au](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/common/icon/au_logo_t.png?scl=1&fmt=png-alpha)](https://www.au.com/)

- 商品・サービス
- [サポート](https://www.au.com/support/)
- [My au](https://my.au.com/)

- [![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_shop.png?fmt=png-alpha&scl=1)ショップ検索・\\
\\
来店予約](https://www.au.com/storelocator/)
- [![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_auonlineshop.png?fmt=png-alpha&scl=1)au Online Shop](https://www.au.com/mobile/onlineshop/)
- ![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_search.png?fmt=png-alpha&scl=1)


- [ニュースセンター](https://www.au.com/information/)
- [お問い合わせ](https://www.au.com/support/inquiry/)
- [English](https://www.au.com/english/)
- 企業情報

- [企業情報](https://www.kddi.com/corporate/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
- [サステナビリティ](https://www.kddi.com/corporate/sustainability/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
- [投資家情報](https://www.kddi.com/corporate/ir/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
- [採用情報](https://www.kddi.com/corporate/recruit/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
- [法人のお客さま](https://biz.kddi.com/service/mobile/)

- [企業情報トップ](https://www.kddi.com/corporate/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
- [サステナビリティ](https://www.kddi.com/corporate/sustainability/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
- [投資家情報](https://www.kddi.com/corporate/ir/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
- [採用情報](https://www.kddi.com/corporate/recruit/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
- [法人のお客さま](https://biz.kddi.com/service/mobile/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_smartphone_white.png?fmt=png-alpha&scl=1)

[スマートフォン・携帯電話 TOP](https://www.au.com/mobile/)

- [Android](https://www.au.com/mobile/product/smartphone/)
- [iPhone](https://www.au.com/iphone/)
- [iPad](https://www.au.com/ipad/)
- [料金・割引](https://www.au.com/mobile/charge/)
- [サービス・機能](https://www.au.com/mobile/service/)
- [エリア](https://www.au.com/mobile/area/)
- [キャンペーン](https://www.au.com/mobile/campaign/)
- [スマホ教室](https://school.au.com/?medid=au&serial=global_navi&srcid=074)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_internet_white.png?fmt=png-alpha&scl=1)

[インターネット回線 TOP](https://www.au.com/internet/)

- [auひかり ホーム10ギガ・5ギガ](https://www.au.com/internet/auhikari_10-5g/)
- [auひかり ホーム1ギガ](https://www.au.com/internet/auhikari_1g/)
- [auひかり マンション](https://www.au.com/internet/mansion/)
- [au one net](https://www.au.com/internet/auonenet/)
- [お申し込み・コース変更](https://www.au.com/internet/application/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_pontapass_white_68ca7486d78e8d37.png?fmt=png-alpha&scl=1)

[Pontaパス TOP](https://www.au.com/pontapass/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_payment2_white.png?fmt=png-alpha&scl=1)

[ポイント・決済 TOP](https://www.au.com/payment/)

- [Pontaポイント](https://www.au.com/payment/point/)
- [au PAY（コード支払い/ネット支払い）](https://www.au.com/payment/aupay/)
- [au PAY プリペイドカード](https://www.au.com/payment/prepaid/)
- [au PAY カード](https://www.au.com/payment/card/)
- [au PAY（auかんたん決済）](https://www.au.com/payment/easy/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_hoken_white.png?fmt=png-alpha&scl=1)

[auの金融・保険サービス TOP](https://www.au.com/finance/)

- [auの生命ほけん](https://www.au.com/finance/life-insurance/)
- [auの損害ほけん](https://www.au.com/finance/nonlife-insurance/)
- [auのiDeCo](https://www.au.com/finance/ideco/)
- [auの住宅ローン](https://www.au.com/finance/loan/housing/)
- [auじぶん銀行](https://www.au.com/finance/primebank/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_denki_white.png?fmt=png-alpha&scl=1)

[auでんき・エネルギーサービス TOP](https://www.au.com/energy/)

- [料金プラン](https://www.au.com/energy/denki/merit/plan/)
- [ご契約者向けサポート](https://energy.auone.jp/denki/cs)
- [お引っ越しのご案内](https://energy.auone.jp/denki/merit/moving/)
- [ガスのご案内](https://www.au.com/energy/gas/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_contents_white.png?fmt=png-alpha&scl=1)

[エンタメ TOP](https://www.au.com/entertainment/)

- [映像](https://www.au.com/entertainment/?tabopen=tab_video#anc_01)
- [音楽](https://www.au.com/entertainment/?tabopen=tab_music#anc_01)
- [書籍](https://www.au.com/entertainment/?tabopen=tab_book#anc_01)
- [ニュース](https://www.au.com/entertainment/newspass/)
- [クラウド](https://www.au.com/entertainment/googleone/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_home_white.png?fmt=png-alpha&scl=1)

[くらしのサービス TOP](https://www.au.com/life/)

- [au HOME](https://www.au.com/life/auhome/)
- [auおうちあんしんサポート](https://www.au.com/life/ouchi-anshin/)
- [auわんにゃんサポート](https://pet.life-kurashi.au.com/)
- [au自転車サポート](https://www.au.com/life/bicycle-support/)
- [au PAY ふるさと納税](https://www.au.com/life/furusato-tax/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_wallet_white.png?fmt=png-alpha&scl=1)

[ショッピング TOP](https://www.au.com/shopping/)

- [au PAY マーケット（総合通販）](https://www.au.com/shopping/wowma/)
- [au Online Shop](https://www.au.com/mobile/onlineshop/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_healthcare_white.png?fmt=png-alpha&scl=1)

[ヘルスケア TOP](https://wellness.auone.jp/?medid=au&serial=entertainment&srcid=banner)

x

[![閉じる](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_close_gray_large.png?fmt=png-alpha&scl=1)](https://www.au.com/mobile/charge/application-ended/junior-smartphone/#)

商品・サービス![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_smartphone_gray.png?fmt=png-alpha&scl=1)スマートフォン・携帯電話


- [スマートフォン・携帯電話 TOP](https://www.au.com/mobile/)
- [Android](https://www.au.com/mobile/product/smartphone/)
- [iPhone](https://www.au.com/iphone/)
- [iPad](https://www.au.com/ipad/)
- [料金・割引](https://www.au.com/mobile/charge/)
- [サービス・機能](https://www.au.com/mobile/service/)
- [エリア](https://www.au.com/mobile/area/)
- [キャンペーン](https://www.au.com/mobile/campaign/)
- [スマホ教室](https://school.au.com/?medid=au&serial=global_navi&srcid=074)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_internet_gray.png?fmt=png-alpha&scl=1)インターネット回線


- [インターネット回線 TOP](https://www.au.com/internet/)
- [auひかり ホーム10ギガ・5ギガ](https://www.au.com/internet/auhikari_10-5g/)
- [auひかり ホーム1ギガ](https://www.au.com/internet/auhikari_1g/)
- [auひかり マンション](https://www.au.com/internet/mansion/)
- [au one net](https://www.au.com/internet/auonenet/)
- [お申し込み・コース変更](https://www.au.com/internet/application/)

[![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_pontapass_gray_51d343cd9cd339bd.png?fmt=png-alpha&scl=1)Pontaパス](https://www.au.com/pontapass/)![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_payment2_gray.png?fmt=png-alpha&scl=1)ポイント・決済


- [ポイント・決済 TOP](https://www.au.com/payment/)
- [Pontaポイント](https://www.au.com/payment/point/)
- [au PAY（コード支払い/ネット支払い）](https://www.au.com/payment/aupay/)
- [au PAY プリペイドカード](https://www.au.com/payment/prepaid/)
- [au PAY カード](https://www.au.com/payment/card/)
- [au PAY（auかんたん決済）](https://www.au.com/payment/easy/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_hoken_gray.png?fmt=png-alpha&scl=1)auの金融・保険サービス


- [auの金融・保険サービス TOP](https://www.au.com/finance/)
- [auの生命ほけん](https://www.au.com/finance/life-insurance/)
- [auの損害ほけん](https://www.au.com/finance/nonlife-insurance/)
- [auのiDeCo](https://www.au.com/finance/ideco/)
- [auの住宅ローン](https://www.au.com/finance/loan/housing/)
- [auじぶん銀行](https://www.au.com/finance/primebank/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_denki_gray.png?fmt=png-alpha&scl=1)auでんき・エネルギーサービス


- [auでんき・エネルギーサービス TOP](https://www.au.com/energy/)
- [料金プラン](https://www.au.com/energy/denki/merit/plan/)
- [ご契約者向けサポート](https://energy.auone.jp/denki/cs)
- [お引っ越しのご案内](https://energy.auone.jp/denki/merit/moving/)
- [ガスのご案内](https://www.au.com/energy/gas/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_contents_gray.png?fmt=png-alpha&scl=1)エンタメ


- [エンタメ TOP](https://www.au.com/entertainment/)
- [映像](https://www.au.com/entertainment/?tabopen=tab_video#anc_01)
- [音楽](https://www.au.com/entertainment/?tabopen=tab_music#anc_01)
- [書籍](https://www.au.com/entertainment/?tabopen=tab_book#anc_01)
- [ニュース](https://www.au.com/entertainment/newspass/)
- [クラウド](https://www.au.com/entertainment/googleone/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_home_gray.png?fmt=png-alpha&scl=1)くらしのサービス


- [くらしのサービス TOP](https://www.au.com/life/)
- [au HOME](https://www.au.com/life/auhome/)
- [auおうちあんしんサポート](https://www.au.com/life/ouchi-anshin/)
- [auわんにゃんサポート](https://pet.life-kurashi.au.com/)
- [au自転車サポート](https://www.au.com/life/bicycle-support/)
- [au PAY ふるさと納税](https://www.au.com/life/furusato-tax/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_wallet_gray.png?fmt=png-alpha&scl=1)ショッピング


- [ショッピング TOP](https://www.au.com/shopping/)
- [au PAY マーケット（総合通販）](https://www.au.com/shopping/wowma/)
- [au Online Shop](https://www.au.com/mobile/onlineshop/)

[![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_healthcare_gray.png?fmt=png-alpha&scl=1)ヘルスケア](https://wellness.auone.jp/?medid=au&serial=entertainment&srcid=banner)[サポート](https://www.au.com/support/)My au[My au TOP](https://my.au.com/aus/hc-cs/omt/OMT0010001.hc)[スマートフォン・携帯電話](https://my.au.com/aus/hc-cs/osm/OSM0000001.hc)[インターネット・電話](https://my.au.com/aus/hc-cs/oin/OIN0010001.hc)[au HOME](https://my.au.com/aus/WCV411001/WCE411001.hc)[エンタメ](https://my.au.com/aus/hc-cs/oct/OCT0010001.hc)[au PAY](https://my.au.com/aus/hc-cs/ocd/OCD0010001.hc)[ショッピング](https://my.au.com/aus/hc-cs/owm/OWM0010001.hc)[auでんき](https://my.au.com/aus/hc-cs/oet/OET0010001.hc)[auの金融・保険サービス](https://my.au.com/aus/hc-cs/oir/OIR0000001.hc)[ポイント](https://my.au.com/aus/au-cs1/AuHome?PageID=SSO&ActionID=POINT&agdt=2)[お知らせ](https://my.au.com/aus/hc-cs/ony/ONY0010001.hc)

- [![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_shop.png?fmt=png-alpha&scl=1)ショップ検索・来店予約](https://www.au.com/storelocator/)
- [![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_auonlineshop.png?fmt=png-alpha&scl=1)au Online Shop](https://www.au.com/mobile/onlineshop/)
- [ニュースセンター](https://www.au.com/information/)
  - [お問い合わせ](https://www.au.com/support/inquiry/)
  - [English](https://www.au.com/english/)
  - [企業情報](https://www.kddi.com/corporate/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
  - [サステナビリティ](https://www.kddi.com/corporate/sustainability/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
  - [投資家情報](https://www.kddi.com/corporate/ir/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
  - [採用情報](https://www.kddi.com/corporate/recruit/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
  - [法人のお客さま](https://biz.kddi.com/service/mobile/)

[スマートフォン・携帯電話](https://www.au.com/mobile/charge/application-ended/junior-smartphone/#)

- [スマートフォン・携帯電話](https://www.au.com/mobile/?bid=we-we-gn-2001)
- [スマートフォン・携帯電話 TOP](https://www.au.com/mobile/?bid=we-we-gn-2001)
  - [Android](https://www.au.com/mobile/product/smartphone/)
  - [iPhone](https://www.au.com/iphone/)
  - [料金・割引](https://www.au.com/mobile/charge/?bid=we-we-gn-2003)
  - [サービス・機能](https://www.au.com/mobile/service/?bid=we-we-gn-2004)
  - [エリア](https://www.au.com/mobile/area/?bid=we-we-gn-2005)
  - [キャンペーン](https://www.au.com/mobile/campaign/?bid=we-we-gn-2006)

[![Cart](https://www.au.com/etc.clientlibs/settings/wcm/designs/au-com/clientlib-site/resources/images/icon/icon_cart.png)0](https://www.au.com/cart/?bid=we-we-gn-2904)

1. [トップ](https://www.au.com/)
2. [スマートフォン・携帯電話](https://www.au.com/mobile/)
3. [料金・割引](https://www.au.com/mobile/charge/)
4. [お申し込み受付終了プラン](https://www.au.com/mobile/charge/application-ended/)
5. ジュニアスマートフォンプラン

# ジュニアスマートフォンプラン

2022年3月31日をもちまして、au携帯電話の契約解除料を廃止しました。

2019年9月30日をもって新規受付終了

[![サブスクぷらすポイント毎月対象サービス月額料金（税抜）の最大20%Pontaポイント還元](<Base64-Image-Removed>)](https://www.au.com/mobile/charge/smartphone/plan/service/)

ジュニアスマートフォン専用の料金プランです。3年以内の機種変更も安心のアップグレードプログラム（ジュニア）が無料でついています。小学生以下のお子さまが対象です。

## 概要

|     |     |     |
| --- | --- | --- |
| 月額基本使用料 | 「2年契約」適用時 | 4,202円（税込） |
| 各種割引サービス適用前 | 5,302円（税込） |
| 国内通話料 | au携帯電話宛 | 1時～21時は無料＊1<br>21時～翌1時は22円（税込）／30秒 |
| 他社携帯電話・固定電話など宛 | 終日22円（税込）／30秒＊2 |
| データ通信料 | 月間データ容量2GB (注1) が基本使用料に含まれます |
| 国内SMS利用料 | au携帯電話宛 | 送受信：無料 |
| 他社携帯電話・PHS宛 | 送信：3.3円（税込）／回<br>受信：無料 |

-
4G LTE (au VoLTE対応) Android™スマートフォンの「料金プラン」「データ（パケット）定額サービス」は名称に（V）がつきます。



[「auスマートバリュー」とセットでご利用料金がさらにおトク！詳しくはこちら。\\
\\
auスマートバリュー](https://www.au.com/mobile/charge/charge-discount/smartvalue/)

|     |     |
| --- | --- |
| お申し込み | 必要 |

## 対象機種・ご加入条件

実ご利用者がプランご加入時点で小学生以下の方で、「miraie f」、「miraie」ご購入時のみご加入いただけます。

ユニバーサルサービス制度について

ユニバーサルサービス制度の開始に伴い、au電話サービスをご契約のお客さまに2007年1月ご利用分から「ユニバーサルサービス料」のご負担をお願いしております。詳細のご確認はこちらから。

[ユニバーサルサービス制度について](http://www.kddi.com/corporate/kddi/kokai/universal/)

電話リレーサービス制度について

電話リレーサービス制度の開始に伴い、au携帯電話サービスをご契約のお客さまに2021年7月ご利用分から「電話リレーサービス料」のご負担をお願いしております。詳細のご確認はこちらから。

[電話リレーサービス制度について](https://www.kddi.com/corporate/kddi/public/telephonerelay/)

[**ご注意**](https://www.au.com/mobile/charge/application-ended/junior-smartphone/#)

**【ジュニアスマートフォンプランについて】**

-
対象機種以外でのご利用はできません。また、学割・エクストラオプションの対象外プランです。


-
新規加入時または機種変更時にお申し込みの場合は、加入日または変更日からの適用となります。月の途中でのご解約などの場合、日割りとならず、満額がかかります（「2年契約」未加入の場合、ご利用日数分の日割りとなります）。



-
1：21時および翌1時をまたがる通話の場合、時間帯をまたがる課金度数 (30秒間) は無料となります。留守番電話 (1417) などの各種特番宛の通話は、無料の対象外です。通話が連続して長時間におよぶなど、その他の通話に影響をおよぼすと当社が判断した場合には、当該通話を切断する場合があります。


-
2：他社が料金設定している番号への通話は除きます。



1. 【通信速度制限について】



-
当月ご利用の通信量が合計で月間データ容量を超えた場合、当月末までの通信速度が送受信最大128kbpsとなります (通信速度の制限は、翌月1日に順次解除されます)。


-
ネットワーク混雑回避のために、直近3日間 (当日を除く) に、ご利用の通信量が合計で6GB以上の場合、通信速度を終日制限させていただく場合があります。制限速度は混雑状況に応じて変動します。 (残データ容量に関わらず制限の対象となります)。


-
ご利用の通話料が高額となる場合は、一時的に回線を停止させていただく場合があります。



- 別途、オプション料、契約にかかる費用、ユニバーサルサービス料、電話リレーサービス料などがかかります。

## 関連情報

[**製品情報**\\
\\
auの製品情報についてご紹介します。\\
\\
* * *](https://www.au.com/mobile/product/)

[詳しく](https://www.au.com/mobile/product/)

[**スマホトクするプログラム**\\
\\
最新機種へおトクに機種変更しよう！\\
\\
* * *](https://www.au.com/mobile/tokusuru-program/)

[詳しく](https://www.au.com/mobile/tokusuru-program/)

[**下取りプログラム**\\
\\
今お使いの機種を下取りに出しておトクに最新機種を手に入れよう！\\
\\
* * *](https://www.au.com/mobile/trade-in/)

[詳しく](https://www.au.com/mobile/trade-in/)

### 購入をご検討中の  お客さま

お手続きのご案内とおトクな情報をご紹介します。

- [他社から乗りかえ](https://www.au.com/support/service/mobile/procedure/mnp/)
- [新規契約](https://www.au.com/support/service/mobile/procedure/subscription/)
- [機種変更](https://www.au.com/support/service/mobile/procedure/switch/)

[**au Ponta ポイントプログラム**\\
\\
毎月のau携帯電話などのご利用額に応じてポイントたまる！\\
\\
* * *](https://www.au.com/payment/point/)

[詳しく](https://www.au.com/payment/point/)

- 表記の金額は特に記載のある場合を除きすべて税込です。

- [サイトマップ](https://www.au.com/sitemap/)
- [au IDについて](https://www.au.com/au-id/)
- [au ブランドについて](https://www.au.com/brand/)
- [KDDIブランドについて](https://brand.kddi.com/)
- [サステナビリティ](https://www.kddi.com/corporate/sustainability/)
- [法人のお客さま](https://biz.kddi.com/)
- [企業情報](https://www.kddi.com/corporate/)
- [KDDIサイトマップ](https://www.kddi.com/sitemap/)

- [サイトポリシー](https://www.kddi.com/terms/sitepolicy/)
- [My au利用規約](https://www.au.com/my-au/terms/)
- [プライバシーポリシー](https://www.kddi.com/corporate/kddi/public/privacy/)
- [プライバシーポータル](https://www.kddi.com/corporate/kddi/public/privacy-portal/)
- [セキュリティポータル](https://www.kddi.com/corporate/kddi/public/security-portal/)
- [ソーシャルメディアポリシー](https://www.kddi.com/terms/social-media/)
- [動作環境・Cookie情報の利用について](https://www.kddi.com/terms/requirements/)
- [ウェブアクセシビリティの取り組み](https://www.au.com/accessibility/)
- [商標について](https://www.au.com/trademark/)

[![KDDI](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/footer_logo.png?fmt=png-alpha&scl=1)](https://www.kddi.com/)

COPYRIGHT © KDDI CORPORATION, ALL RIGHTS RESERVED.