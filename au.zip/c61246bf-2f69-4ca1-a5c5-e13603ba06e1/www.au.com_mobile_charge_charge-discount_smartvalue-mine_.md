---
url: "https://www.au.com/mobile/charge/charge-discount/smartvalue-mine/"
title: "auスマートバリュー mine | 料金・割引：スマートフォン・携帯電話 | au"
---

![メニュー](https://www.au.com/etc.clientlibs/settings/wcm/designs/au-com/clientlib-site/resources/images/icon/icon_menu_smp.png)[![おもしろい方の未来へ。 au](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/common/icon/au_logo_y.png?scl=1&fmt=png-alpha)](https://www.au.com/)

×

ログインすると、ポイントやお知らせの確認をはじめ、お客さまの契約内容に応じた表示ができます。

[My au利用規約](https://www.au.com/my-au/terms/)、 [My UQ mobile利用規約](https://www.kddi.com/extlib/files/corporate/kddi/kokai/keiyaku_yakkan/pdf/myuqmobile_service.pdf)、 [ID利用規約](https://id.auone.jp/id/pc/legal/auid_terms.html)、 [au Ponta ポイントプログラム規約](https://www.au.com/support/point/regulation-point/) および [アクセスデータの利用](https://www.kddi.com/terms/requirements/#a06) に同意の上、ログインしてください。

ログインすると、ポイントやお知らせの確認をはじめ、お客さまの契約内容に応じた表示ができます。

[My au利用規約](https://www.au.com/my-au/terms/)、 [My UQ mobile利用規約](https://www.kddi.com/extlib/files/corporate/kddi/kokai/keiyaku_yakkan/pdf/myuqmobile_service.pdf)、 [ID利用規約](https://id.auone.jp/id/sp/legal/auid_terms.html)、 [au Ponta ポイントプログラム規約](https://www.au.com/support/point/regulation-point/) および [アクセスデータの利用](https://www.kddi.com/terms/requirements/#a06) に同意の上、ログインしてください。

au IDでログイン

※ログインしない場合は、右上の｢×｣ボタンで本画面を閉じてください。

[![おもしろい方の未来へ。 au](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/common/icon/au_logo_t.png?scl=1&fmt=png-alpha)](https://www.au.com/)

- 商品・サービス
- [サポート](https://www.au.com/support/)
- [My au](https://my.au.com/)

- [![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_shop.png?fmt=png-alpha&scl=1)ショップ検索・\\
\\
来店予約](https://www.au.com/storelocator/)
- [![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_auonlineshop.png?fmt=png-alpha&scl=1)au Online Shop](https://www.au.com/mobile/onlineshop/)
- ![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_search.png?fmt=png-alpha&scl=1)


- [ニュースセンター](https://www.au.com/information/)
- [お問い合わせ](https://www.au.com/support/inquiry/)
- [English](https://www.au.com/english/)
- 企業情報

- [企業情報](https://www.kddi.com/corporate/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
- [サステナビリティ](https://www.kddi.com/corporate/sustainability/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
- [投資家情報](https://www.kddi.com/corporate/ir/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
- [採用情報](https://www.kddi.com/corporate/recruit/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
- [法人のお客さま](https://biz.kddi.com/service/mobile/)

- [企業情報トップ](https://www.kddi.com/corporate/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
- [サステナビリティ](https://www.kddi.com/corporate/sustainability/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
- [投資家情報](https://www.kddi.com/corporate/ir/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
- [採用情報](https://www.kddi.com/corporate/recruit/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
- [法人のお客さま](https://biz.kddi.com/service/mobile/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_smartphone_white.png?fmt=png-alpha&scl=1)

[スマートフォン・携帯電話 TOP](https://www.au.com/mobile/)

- [Android](https://www.au.com/mobile/product/smartphone/)
- [iPhone](https://www.au.com/iphone/)
- [iPad](https://www.au.com/ipad/)
- [料金・割引](https://www.au.com/mobile/charge/)
- [サービス・機能](https://www.au.com/mobile/service/)
- [エリア](https://www.au.com/mobile/area/)
- [キャンペーン](https://www.au.com/mobile/campaign/)
- [スマホ教室](https://school.au.com/?medid=au&serial=global_navi&srcid=074)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_internet_white.png?fmt=png-alpha&scl=1)

[インターネット回線 TOP](https://www.au.com/internet/)

- [auひかり ホーム10ギガ・5ギガ](https://www.au.com/internet/auhikari_10-5g/)
- [auひかり ホーム1ギガ](https://www.au.com/internet/auhikari_1g/)
- [auひかり マンション](https://www.au.com/internet/mansion/)
- [au one net](https://www.au.com/internet/auonenet/)
- [お申し込み・コース変更](https://www.au.com/internet/application/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_pontapass_white_68ca7486d78e8d37.png?fmt=png-alpha&scl=1)

[Pontaパス TOP](https://www.au.com/pontapass/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_payment2_white.png?fmt=png-alpha&scl=1)

[ポイント・決済 TOP](https://www.au.com/payment/)

- [Pontaポイント](https://www.au.com/payment/point/)
- [au PAY（コード支払い/ネット支払い）](https://www.au.com/payment/aupay/)
- [au PAY プリペイドカード](https://www.au.com/payment/prepaid/)
- [au PAY カード](https://www.au.com/payment/card/)
- [au PAY（auかんたん決済）](https://www.au.com/payment/easy/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_hoken_white.png?fmt=png-alpha&scl=1)

[auの金融・保険サービス TOP](https://www.au.com/finance/)

- [auの生命ほけん](https://www.au.com/finance/life-insurance/)
- [auの損害ほけん](https://www.au.com/finance/nonlife-insurance/)
- [auのiDeCo](https://www.au.com/finance/ideco/)
- [auの住宅ローン](https://www.au.com/finance/loan/housing/)
- [auじぶん銀行](https://www.au.com/finance/primebank/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_denki_white.png?fmt=png-alpha&scl=1)

[auでんき・エネルギーサービス TOP](https://www.au.com/energy/)

- [料金プラン](https://www.au.com/energy/denki/merit/plan/)
- [ご契約者向けサポート](https://energy.auone.jp/denki/cs)
- [お引っ越しのご案内](https://energy.auone.jp/denki/merit/moving/)
- [ガスのご案内](https://www.au.com/energy/gas/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_contents_white.png?fmt=png-alpha&scl=1)

[エンタメ TOP](https://www.au.com/entertainment/)

- [映像](https://www.au.com/entertainment/?tabopen=tab_video#anc_01)
- [音楽](https://www.au.com/entertainment/?tabopen=tab_music#anc_01)
- [書籍](https://www.au.com/entertainment/?tabopen=tab_book#anc_01)
- [ニュース](https://www.au.com/entertainment/newspass/)
- [クラウド](https://www.au.com/entertainment/googleone/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_home_white.png?fmt=png-alpha&scl=1)

[くらしのサービス TOP](https://www.au.com/life/)

- [au HOME](https://www.au.com/life/auhome/)
- [auおうちあんしんサポート](https://www.au.com/life/ouchi-anshin/)
- [auわんにゃんサポート](https://pet.life-kurashi.au.com/)
- [au自転車サポート](https://www.au.com/life/bicycle-support/)
- [au PAY ふるさと納税](https://www.au.com/life/furusato-tax/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_wallet_white.png?fmt=png-alpha&scl=1)

[ショッピング TOP](https://www.au.com/shopping/)

- [au PAY マーケット（総合通販）](https://www.au.com/shopping/wowma/)
- [au Online Shop](https://www.au.com/mobile/onlineshop/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_healthcare_white.png?fmt=png-alpha&scl=1)

[ヘルスケア TOP](https://wellness.auone.jp/?medid=au&serial=entertainment&srcid=banner)

x

[![閉じる](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_close_gray_large.png?fmt=png-alpha&scl=1)](https://www.au.com/mobile/charge/charge-discount/smartvalue-mine/#)

商品・サービス![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_smartphone_gray.png?fmt=png-alpha&scl=1)スマートフォン・携帯電話


- [スマートフォン・携帯電話 TOP](https://www.au.com/mobile/)
- [Android](https://www.au.com/mobile/product/smartphone/)
- [iPhone](https://www.au.com/iphone/)
- [iPad](https://www.au.com/ipad/)
- [料金・割引](https://www.au.com/mobile/charge/)
- [サービス・機能](https://www.au.com/mobile/service/)
- [エリア](https://www.au.com/mobile/area/)
- [キャンペーン](https://www.au.com/mobile/campaign/)
- [スマホ教室](https://school.au.com/?medid=au&serial=global_navi&srcid=074)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_internet_gray.png?fmt=png-alpha&scl=1)インターネット回線


- [インターネット回線 TOP](https://www.au.com/internet/)
- [auひかり ホーム10ギガ・5ギガ](https://www.au.com/internet/auhikari_10-5g/)
- [auひかり ホーム1ギガ](https://www.au.com/internet/auhikari_1g/)
- [auひかり マンション](https://www.au.com/internet/mansion/)
- [au one net](https://www.au.com/internet/auonenet/)
- [お申し込み・コース変更](https://www.au.com/internet/application/)

[![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_pontapass_gray_51d343cd9cd339bd.png?fmt=png-alpha&scl=1)Pontaパス](https://www.au.com/pontapass/)![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_payment2_gray.png?fmt=png-alpha&scl=1)ポイント・決済


- [ポイント・決済 TOP](https://www.au.com/payment/)
- [Pontaポイント](https://www.au.com/payment/point/)
- [au PAY（コード支払い/ネット支払い）](https://www.au.com/payment/aupay/)
- [au PAY プリペイドカード](https://www.au.com/payment/prepaid/)
- [au PAY カード](https://www.au.com/payment/card/)
- [au PAY（auかんたん決済）](https://www.au.com/payment/easy/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_hoken_gray.png?fmt=png-alpha&scl=1)auの金融・保険サービス


- [auの金融・保険サービス TOP](https://www.au.com/finance/)
- [auの生命ほけん](https://www.au.com/finance/life-insurance/)
- [auの損害ほけん](https://www.au.com/finance/nonlife-insurance/)
- [auのiDeCo](https://www.au.com/finance/ideco/)
- [auの住宅ローン](https://www.au.com/finance/loan/housing/)
- [auじぶん銀行](https://www.au.com/finance/primebank/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_denki_gray.png?fmt=png-alpha&scl=1)auでんき・エネルギーサービス


- [auでんき・エネルギーサービス TOP](https://www.au.com/energy/)
- [料金プラン](https://www.au.com/energy/denki/merit/plan/)
- [ご契約者向けサポート](https://energy.auone.jp/denki/cs)
- [お引っ越しのご案内](https://energy.auone.jp/denki/merit/moving/)
- [ガスのご案内](https://www.au.com/energy/gas/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_contents_gray.png?fmt=png-alpha&scl=1)エンタメ


- [エンタメ TOP](https://www.au.com/entertainment/)
- [映像](https://www.au.com/entertainment/?tabopen=tab_video#anc_01)
- [音楽](https://www.au.com/entertainment/?tabopen=tab_music#anc_01)
- [書籍](https://www.au.com/entertainment/?tabopen=tab_book#anc_01)
- [ニュース](https://www.au.com/entertainment/newspass/)
- [クラウド](https://www.au.com/entertainment/googleone/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_home_gray.png?fmt=png-alpha&scl=1)くらしのサービス


- [くらしのサービス TOP](https://www.au.com/life/)
- [au HOME](https://www.au.com/life/auhome/)
- [auおうちあんしんサポート](https://www.au.com/life/ouchi-anshin/)
- [auわんにゃんサポート](https://pet.life-kurashi.au.com/)
- [au自転車サポート](https://www.au.com/life/bicycle-support/)
- [au PAY ふるさと納税](https://www.au.com/life/furusato-tax/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_wallet_gray.png?fmt=png-alpha&scl=1)ショッピング


- [ショッピング TOP](https://www.au.com/shopping/)
- [au PAY マーケット（総合通販）](https://www.au.com/shopping/wowma/)
- [au Online Shop](https://www.au.com/mobile/onlineshop/)

[![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_healthcare_gray.png?fmt=png-alpha&scl=1)ヘルスケア](https://wellness.auone.jp/?medid=au&serial=entertainment&srcid=banner)[サポート](https://www.au.com/support/)My au[My au TOP](https://my.au.com/aus/hc-cs/omt/OMT0010001.hc)[スマートフォン・携帯電話](https://my.au.com/aus/hc-cs/osm/OSM0000001.hc)[インターネット・電話](https://my.au.com/aus/hc-cs/oin/OIN0010001.hc)[au HOME](https://my.au.com/aus/WCV411001/WCE411001.hc)[エンタメ](https://my.au.com/aus/hc-cs/oct/OCT0010001.hc)[au PAY](https://my.au.com/aus/hc-cs/ocd/OCD0010001.hc)[ショッピング](https://my.au.com/aus/hc-cs/owm/OWM0010001.hc)[auでんき](https://my.au.com/aus/hc-cs/oet/OET0010001.hc)[auの金融・保険サービス](https://my.au.com/aus/hc-cs/oir/OIR0000001.hc)[ポイント](https://my.au.com/aus/au-cs1/AuHome?PageID=SSO&ActionID=POINT&agdt=2)[お知らせ](https://my.au.com/aus/hc-cs/ony/ONY0010001.hc)

- [![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_shop.png?fmt=png-alpha&scl=1)ショップ検索・来店予約](https://www.au.com/storelocator/)
- [![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_auonlineshop.png?fmt=png-alpha&scl=1)au Online Shop](https://www.au.com/mobile/onlineshop/)
- [ニュースセンター](https://www.au.com/information/)
  - [お問い合わせ](https://www.au.com/support/inquiry/)
  - [English](https://www.au.com/english/)
  - [企業情報](https://www.kddi.com/corporate/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
  - [サステナビリティ](https://www.kddi.com/corporate/sustainability/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
  - [投資家情報](https://www.kddi.com/corporate/ir/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
  - [採用情報](https://www.kddi.com/corporate/recruit/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
  - [法人のお客さま](https://biz.kddi.com/service/mobile/)

[スマートフォン・携帯電話](https://www.au.com/mobile/charge/charge-discount/smartvalue-mine/#)

- [スマートフォン・携帯電話](https://www.au.com/mobile/?bid=we-we-gn-2001)
- [スマートフォン・携帯電話 TOP](https://www.au.com/mobile/?bid=we-we-gn-2001)
  - [Android](https://www.au.com/mobile/product/smartphone/)
  - [iPhone](https://www.au.com/iphone/)
  - [料金・割引](https://www.au.com/mobile/charge/?bid=we-we-gn-2003)
  - [サービス・機能](https://www.au.com/mobile/service/?bid=we-we-gn-2004)
  - [エリア](https://www.au.com/mobile/area/?bid=we-we-gn-2005)
  - [キャンペーン](https://www.au.com/mobile/campaign/?bid=we-we-gn-2006)

[![Cart](https://www.au.com/etc.clientlibs/settings/wcm/designs/au-com/clientlib-site/resources/images/icon/icon_cart.png)0](https://www.au.com/cart/?bid=we-we-gn-2904)

1. [トップ](https://www.au.com/)
2. [スマートフォン・携帯電話](https://www.au.com/mobile/)
3. [料金・割引](https://www.au.com/mobile/charge/)
4. auスマートバリュー mine

# auスマートバリュー mine

![auスマホ・auケータイ](https://www.au.com/content/dam/au-com/mobile/charge/charge-discount/smartvalue-mine/mb_smartvalue-mine_img_02_02.png)

auスマホ・auケータイで、指定の料金プランまたはデータ定額サービスにご加入

![＋](https://www.au.com/content/dam/au-com/mobile/charge/charge-discount/smartvalue-mine/mb_smartvalue-mine_img_plus.png)

![WiMAX 2+対応ルーター（Wi-Fi ルーター）](https://www.au.com/content/dam/au-com/mobile/charge/charge-discount/smartvalue-mine/mb_smartvalue-mine_img_03.png)

WiMAX 2+ 対応ルーターで「WiMAX 2+フラット for DATA EX（2年契約）（5,368円／月）」もしくは「WiMAX 2+ フラット for DATA（2年契約aまたは4年契約）」（4,615円／月）★1★2にご加入

**こんな方が対象です！**

![こんな方が対象です！](<Base64-Image-Removed>)

## 概要

Wi-Fiルーターとセットで、au携帯電話のご利用がおトクに！

auスマートバリュー mineとは、対象のデータ（パケット）定額サービスにご加入のauスマートフォン／auケータイとWi-Fiルーターとセットでのご利用で、お申し込み翌月から、auスマートフォン／auケータイのご利用料金から毎月最大1,100円（税込）を割り引くサービスです。

![Wi-Fiルーターとセットで、au携帯電話のご利用はおトクに！](<Base64-Image-Removed>)

1. 対象の料金プランまたはデータ（パケット）定額サービスごとに割引額が異なります。



## 対象のWi-Fiルーター

[![Speed Wi-Fi NEXT WX05](<Base64-Image-Removed>)\\
\\
**Speed Wi-Fi NEXT WX05**](https://www.au.com/mobile/product/data/wx05/)

[![Speed Wi-Fi NEXT W06](<Base64-Image-Removed>)\\
\\
**Speed Wi-Fi NEXT W06**](https://www.au.com/mobile/product/data/w06/)

-
以下機種も対象です。



[WiMAX HOME 01](https://www.au.com/mobile/product/data/home01/)

[Speed Wi-Fi NEXT W05](https://www.au.com/mobile/product/data/w05/)

[Speed Wi-Fi HOME L02](https://www.au.com/mobile/product/data/hws33/)

[Speed Wi-Fi HOME L01s](https://www.au.com/mobile/product/data/hws32/)

Speed Wi-Fi HOME L01

Speed Wi-Fi NEXT W04

Speed Wi-Fi NEXT W03

Speed Wi-Fi NEXT WX04（※1）

Speed Wi-Fi NEXT WX03（※1）

Speed Wi-Fi NEXT WX02（※1）

Speed Wi-Fi NEXT W01

Wi-Fi WALKER WiMAX 2+ HWD15

Wi-Fi WALKER WiMAX 2+ HWD14

※1： UQコミュニケーションズ（株）でご契約いただける機種です。

## 割引金額

### auスマートフォン

-
「新auピタットプラン」「新auピタットプランN」など、下記表に記載がないプランは対象外です。



|     |     |     |
| --- | --- | --- |
| - <br>受付終了プラン<br>   <br>   <br>[auピタットプランN（s）](https://www.au.com/mobile/campaign/fp-sp-wari-plus/200930/)<br>[auピタットプラン](https://www.au.com/mobile/charge/application-ended/pitatto/)<br>[auピタットプラン（s）](https://www.au.com/mobile/campaign/end/fp-sp-wari-s/) | 2GBまで<br>- <br>auピタットプラン（シンプル）の場合、1GBまで割引対象外となります。 | 翌月から<br>550円（税込）／月 OFF |
| 2GB超～20GBまで | 翌月から<br>1,100円（税込）／月 OFF |
| - <br>受付終了プラン<br>   <br>   <br>[auフラットプラン25 NetflixパックN](https://www.au.com/mobile/charge/smartphone/plan/flat25-netflix-n/)<br>[auフラットプラン20N](https://www.au.com/mobile/charge/smartphone/plan/flat20-n/)<br>[auフラットプラン30](https://www.au.com/mobile/charge/application-ended/flat30/)<br>[auフラットプラン25 Netflixパック](https://www.au.com/mobile/charge/application-ended/flat25-netflix/)<br>[auフラットプラン20](https://www.au.com/mobile/charge/application-ended/flat20/)<br>auフラットプラン5（学割専用） | 翌月から<br>1,100円（税込）／月 OFF |
| ※受付終了プラン<br>[データ定額5／8／10／13／20／30](https://www.au.com/mobile/charge/application-ended/data-teigaku/)<br>[データ定額5cp](https://www.au.com/mobile/charge/application-ended/data-teigaku-135cp/)<br>[U18データ定額20](https://www.au.com/mobile/campaign/gakuwari/spec/)<br>[LTEフラット](https://www.au.com/mobile/charge/application-ended/lte/) | 翌月から<br>1,027円（税込）／月 OFF |
| ※受付終了プラン<br>[データ定額2／3](https://www.au.com/mobile/charge/application-ended/data-teigaku/)<br>[データ定額3cp](https://www.au.com/mobile/charge/application-ended/data-teigaku-135cp/)<br>[ジュニアスマートフォンプラン](https://www.au.com/mobile/charge/application-ended/junior-smartphone/)<br>[シニアプラン](https://www.au.com/mobile/charge/application-ended/senior-plan/)<br>[LTEフラット cp（1GB）](https://www.au.com/mobile/charge/application-ended/lte-flat-cp/) | 翌月から<br>817円（税込）／月 OFF |
| ※受付終了プラン<br>[データ定額1](https://www.au.com/mobile/charge/application-ended/data-teigaku/) | 翌月から<br>550円（税込）／月 OFF |

-
4G LTE（au VoLTE対応）Android™スマートフォンの「料金プラン」「データ定額サービス」は名称に（V）がつきます。



### ケータイ（4G LTE）

|     |     |
| --- | --- |
| ※受付終了プラン<br>[データ定額5／8／10／13（ケータイ）](https://www.au.com/mobile/charge/application-ended/data-teigaku-k/) | 翌月から<br>1,027円（税込）／月 OFF |
| ※受付終了プラン<br>[データ定額2／3（ケータイ）](https://www.au.com/mobile/charge/application-ended/data-teigaku-k/) | 翌月から<br>817円（税込）／月 OFF |
| ※受付終了プラン<br>[データ定額1（ケータイ）](https://www.au.com/mobile/charge/application-ended/data-teigaku-k/) | 翌月から<br>550円（税込）／月 OFF |

**＜UQコミュニケーションズ（株）および、WiMAX提供事業者ご契約の場合＞**

WiMAX 2+ 対応ルーターご利用で、各提携事業者の対象料金プランにご加入の場合は以下をご確認ください。

[auスマートバリュー mine（Wi-FiルーターをUQコミュニケーションズ（株）および、WiMAX提供事業者でご契約の場合）](https://www.au.com/mobile/charge/charge-discount/smartvalue-mine/lp/)

## 対象のWi-Fiルーターの料金プラン

（2019年12月25日受付終了）

-
WiMAX 2+ フラット for DATA EX（2年契約）★3
-
WiMAX 2+ フラット for DATA（2年契約a）


-
WiMAX 2+ フラット for DATA（4年契約）



-
2017年秋以降に発売のWiMAX 2+対応ルーターは、プラン名称に（L）がつきます。



## Wi-Fiルーターの「ハイスピードモード」の月間データ容量（7GB）制限

|     |     |
| --- | --- |
| WiMAX 2+ フラット for DATA EX<br>（2年契約）（注2）<br>（5,368円／月） | 一部制限あり★4 |
| WiMAX 2+ フラット for DATA<br>（2年契約a）<br>（4,615円／月） | 制限あり |
| WiMAX 2+ フラット for DATA<br>（4年契約）<br>（4,615円／月） | 一部制限あり★4 |

1. 「WiMAX 2+ フラット for DATA EX（2年契約）」はほかのプランと比較すると、ご利用されるエリアの混雑状況により速度が低下する場合があります。






[そのほかご注意事項](https://www.au.com/mobile/charge/charge-discount/smartvalue-mine/#notes)


1. ハイスピードモードの「WiMAX 2+」通信は当月から月間データ容量制限なしとなります。ただし、ルーターに初期設定されているAPNを変更されますと、速度制限（月間7GB超）の対象となる場合があります。なお、ハイスピードプラスエリアモードの「WiMAX 2+」「4G LTE」の当月利用の通信量合計が7GBを超え、通信速度が送受信128kbpsとなった後はハイスピードモードの「WiMAX 2+」通信を含め、当月中は「WiMAX 2+」「4G LTE」通信の通信速度が送受信最大128kbpsとなります。ネットワーク混雑回避のために、直近3日間に「WiMAX 2+」「4G LTE」のご利用の通信料が合計で10GB以上の場合、ネットワーク混雑時間帯（18時～2時）の通信速度が概ね1Mbpsとなる制限を行います。残データ容量に関わらず制限の対象となります。「エクストラオプション」加入の場合も対象となります。ご利用の通信料が高額となる場合は、一時的に回線を停止させていただく場合があります。



## 通信モードについて

|     |     |     |
| --- | --- | --- |
| **ネットワーク** | **ハイスピードモード** | **ハイスピードプラスエリアモード** |
| 快適通信のWiMAX 2+ | ● | ● |
| エリアが広い4G LTE | - | ● |

auスマートバリューmineのお客さまなら

ハイスピードプラスエリアモードのオプション利用料無料★5！（通常1,105円／月）

### 通信速度制限

**【月間容量制限について】**

-
「WiMAX 2+」「4G LTE」当月ご利用の通信量が合計で7GBを超えた場合、当月末までの通信速度が送受信最大128kbpsとなります（通信速度の制限は、翌月1日に順次解除されます）。「エクストラオプション」をお申し込みの場合は、通信速度の制限なくご利用いただけます。



**【そのほかの通信制限について】**

-
ネットワーク混雑回避のために、直近3日間に「WiMAX 2+」「4G LTE」のご利用の通信量が合計で10GB以上の場合、ネットワーク混雑時間帯（18時～翌2時以降順次解除）の通信速度が概ね1Mbpsの制限を行います。残データ容量に関わらず制限の対象となります。「エクストラオプション」加入の場合も対象となります。


-
ご利用の通信料が高額となる場合は、一時的に回線を停止させていただく場合があります。



## 対象のWi-Fiルーターの料金プランの契約期間について

-
WiMAX 2+対応ルーターの料金プランの契約期間は2年または4年となり、廃止のお申し出がない限り、それぞれ2年または4年単位で自動更新されます。


-
2022年3月31日をもって、契約解除料を廃止しました。



[**ご注意事項はこちら**](https://www.au.com/mobile/charge/charge-discount/smartvalue-mine/#)

1. UQコミュニケーションズおよびそのほか提携事業者も対象となります。対象プランなど詳しくはauホームページでご確認ください。


2. 「2年契約」との併用はできません。すでに「2年契約」にご加入のお客さまが当サービスにお申し込みの場合、「2年契約」は自動で廃止されます（更新期間以外でも契約解除料はかかりません）。



1. 月の途中で「auスマートバリュー mine」へのご加入または解約があった場合、当月分のオプション利用料については無料とならない場合があります。ご利用月に1回でも「auスマートバリュー mine」の条件を満たさない日があった場合は対象外となることがあります。



1. KDDI以外でご契約の場合のWiMAX 2+対応ルーターの契約解除料については、各社にお問い合わせください。



**＜お申し込みについて＞**

-
au携帯電話とWiMAX 2+対応ルーターのご契約者が同一名義の場合にお申し込みいただけます。


-
WiMAX 2+ルーター1回線につき、au携帯電話1回線のみお申し込みいただけます。


-
「auスマートバリュー」とは別のお申し込みが必要です。また「auスマートバリュー」と重複してのお申し込みはできません。


-
Wi-Fiルーターの本対象プランは「2年契約」との併用はできません。既に「2年契約」にご加入のお客さまが当サービスにお申し込みの場合、「2年契約」は自動で廃止されます（更新期間以外でも契約解除料はかかりません）。



**＜au携帯電話の利用料割引について＞**

-
「auスマートバリュー mine」のお申し込み翌月から割引適用となります。


-
各種割引サービス適用後（「毎月割」含む）の基本使用料（「LTEプラン」除く）・国内通話料・国内通信料・オプション料・（「故障紛失サポート／故障紛失サポート with Apple Care Services」「アップグレードプログラムEX／アップグレードプログラムEX（a）」「アップグレードプログラム（a）／アップグレードプログラム」除く）の合計額から割引します。割引対象合計額が割引金額を下回る場合は、割引対象合計額を上限として割引します。


-
au携帯電話を解約・一時休止・譲渡された場合、割引の適用は解約・一時休止・譲渡月の当月をもって終了します。


-
WiMAX 2+対応ルーターを解約・一時休止された場合はお申し込み月の前月をもって、譲渡された場合は当月をもって割引の適用を終了します。


-
弊社が実施するほかの施策とは併用できない場合があります。



**＜ハイスピードプラスエリアモードのオプション利用料の割引について＞**

-
別途契約にかかる費用、ユニバーサルサービス料、電話リレーサービス料は店頭にてご確認ください。



## お申し込み方法

店頭またはKDDIお客さまセンターにてお申し込みいただけます。

[店頭で確認・申し込む（ショップ検索）](https://www.au.com/aushop/)

**お申し込みに必要なもの**

-
ご印鑑


-
ご本人さま確認書類（原本）



[ご本人さま確認書類](https://www.au.com/support/service/mobile/procedure/verifying/)

**KDDIお客さまセンター**

[auケータイ・スマートフォンに関するお問い合わせ](https://www.au.com/support/inquiry/mobile/)

-
お客さまセンターへのお問い合わせ時に、お客さまの契約電話番号を確認させていただくことがございます。












[データ通信端末 （モバイルルーター） の電話番号の確認方法](https://www.au.com/support/faq/view.k1672534391/)


### 「auスマートバリュー mine」に関するよくあるご質問

## 自宅でネットをお考えの方

[![auスマートバリュー](<Base64-Image-Removed>)](https://www.au.com/mobile/charge/charge-discount/smartvalue/)

## 関連情報

[**製品情報**\\
\\
auの製品情報についてご紹介します。\\
\\
* * *](https://www.au.com/mobile/product/)

[詳しく](https://www.au.com/mobile/product/)

[**スマホトクするプログラム**\\
\\
最新機種へおトクに機種変更しよう！\\
\\
* * *](https://www.au.com/mobile/tokusuru-program/)

[詳しく](https://www.au.com/mobile/tokusuru-program/)

[**下取りプログラム**\\
\\
今お使いの機種を下取りに出しておトクに最新機種を手に入れよう！\\
\\
* * *](https://www.au.com/mobile/trade-in/)

[詳しく](https://www.au.com/mobile/trade-in/)

### 購入をご検討中の  お客さま

お手続きのご案内とおトクな情報をご紹介します。

- [他社から乗りかえ](https://www.au.com/support/service/mobile/procedure/mnp/)
- [新規契約](https://www.au.com/support/service/mobile/procedure/subscription/)
- [機種変更](https://www.au.com/support/service/mobile/procedure/switch/)

[**au Ponta ポイントプログラム**\\
\\
毎月のau携帯電話などのご利用額に応じてポイントたまる！\\
\\
* * *](https://www.au.com/payment/point/)

[詳しく](https://www.au.com/payment/point/)

- 表記の金額は特に記載のある場合を除きすべて税込です。

- [サイトマップ](https://www.au.com/sitemap/)
- [au IDについて](https://www.au.com/au-id/)
- [au ブランドについて](https://www.au.com/brand/)
- [KDDIブランドについて](https://brand.kddi.com/)
- [サステナビリティ](https://www.kddi.com/corporate/sustainability/)
- [法人のお客さま](https://biz.kddi.com/)
- [企業情報](https://www.kddi.com/corporate/)
- [KDDIサイトマップ](https://www.kddi.com/sitemap/)

- [サイトポリシー](https://www.kddi.com/terms/sitepolicy/)
- [My au利用規約](https://www.au.com/my-au/terms/)
- [プライバシーポリシー](https://www.kddi.com/corporate/kddi/public/privacy/)
- [プライバシーポータル](https://www.kddi.com/corporate/kddi/public/privacy-portal/)
- [セキュリティポータル](https://www.kddi.com/corporate/kddi/public/security-portal/)
- [ソーシャルメディアポリシー](https://www.kddi.com/terms/social-media/)
- [動作環境・Cookie情報の利用について](https://www.kddi.com/terms/requirements/)
- [ウェブアクセシビリティの取り組み](https://www.au.com/accessibility/)
- [商標について](https://www.au.com/trademark/)

[![KDDI](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/footer_logo.png?fmt=png-alpha&scl=1)](https://www.kddi.com/)

COPYRIGHT © KDDI CORPORATION, ALL RIGHTS RESERVED.