---
url: "https://www.au.com/mobile/charge/charge-list/?bid=we-charge-b-0012"
title: "製品別の料金プラン"
---

![メニュー](https://www.au.com/etc.clientlibs/settings/wcm/designs/au-com/clientlib-site/resources/images/icon/icon_menu_smp.png)[![おもしろい方の未来へ。 au](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/common/icon/au_logo_y.png?scl=1&fmt=png-alpha)](https://www.au.com/)

×

ログインすると、ポイントやお知らせの確認をはじめ、お客さまの契約内容に応じた表示ができます。

[My au利用規約](https://www.au.com/my-au/terms/)、 [My UQ mobile利用規約](https://www.kddi.com/extlib/files/corporate/kddi/kokai/keiyaku_yakkan/pdf/myuqmobile_service.pdf)、 [ID利用規約](https://id.auone.jp/id/pc/legal/auid_terms.html)、 [au Ponta ポイントプログラム規約](https://www.au.com/support/point/regulation-point/) および [アクセスデータの利用](https://www.kddi.com/terms/requirements/#a06) に同意の上、ログインしてください。

ログインすると、ポイントやお知らせの確認をはじめ、お客さまの契約内容に応じた表示ができます。

[My au利用規約](https://www.au.com/my-au/terms/)、 [My UQ mobile利用規約](https://www.kddi.com/extlib/files/corporate/kddi/kokai/keiyaku_yakkan/pdf/myuqmobile_service.pdf)、 [ID利用規約](https://id.auone.jp/id/sp/legal/auid_terms.html)、 [au Ponta ポイントプログラム規約](https://www.au.com/support/point/regulation-point/) および [アクセスデータの利用](https://www.kddi.com/terms/requirements/#a06) に同意の上、ログインしてください。

au IDでログイン

※ログインしない場合は、右上の｢×｣ボタンで本画面を閉じてください。

[![おもしろい方の未来へ。 au](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/common/icon/au_logo_t.png?scl=1&fmt=png-alpha)](https://www.au.com/)

- 商品・サービス
- [サポート](https://www.au.com/support/)
- [My au](https://my.au.com/)

- [![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_shop.png?fmt=png-alpha&scl=1)ショップ検索・\\
\\
来店予約](https://www.au.com/storelocator/)
- [![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_auonlineshop.png?fmt=png-alpha&scl=1)au Online Shop](https://www.au.com/mobile/onlineshop/)
- ![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_search.png?fmt=png-alpha&scl=1)


- [ニュースセンター](https://www.au.com/information/)
- [お問い合わせ](https://www.au.com/support/inquiry/)
- [English](https://www.au.com/english/)
- 企業情報

- [企業情報](https://www.kddi.com/corporate/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
- [サステナビリティ](https://www.kddi.com/corporate/sustainability/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
- [投資家情報](https://www.kddi.com/corporate/ir/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
- [採用情報](https://www.kddi.com/corporate/recruit/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
- [法人のお客さま](https://biz.kddi.com/service/mobile/)

- [企業情報トップ](https://www.kddi.com/corporate/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
- [サステナビリティ](https://www.kddi.com/corporate/sustainability/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
- [投資家情報](https://www.kddi.com/corporate/ir/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
- [採用情報](https://www.kddi.com/corporate/recruit/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
- [法人のお客さま](https://biz.kddi.com/service/mobile/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_smartphone_white.png?fmt=png-alpha&scl=1)

[スマートフォン・携帯電話 TOP](https://www.au.com/mobile/)

- [Android](https://www.au.com/mobile/product/smartphone/)
- [iPhone](https://www.au.com/iphone/)
- [iPad](https://www.au.com/ipad/)
- [料金・割引](https://www.au.com/mobile/charge/)
- [サービス・機能](https://www.au.com/mobile/service/)
- [エリア](https://www.au.com/mobile/area/)
- [キャンペーン](https://www.au.com/mobile/campaign/)
- [スマホ教室](https://school.au.com/?medid=au&serial=global_navi&srcid=074)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_internet_white.png?fmt=png-alpha&scl=1)

[インターネット回線 TOP](https://www.au.com/internet/)

- [auひかり ホーム10ギガ・5ギガ](https://www.au.com/internet/auhikari_10-5g/)
- [auひかり ホーム1ギガ](https://www.au.com/internet/auhikari_1g/)
- [auひかり マンション](https://www.au.com/internet/mansion/)
- [au one net](https://www.au.com/internet/auonenet/)
- [お申し込み・コース変更](https://www.au.com/internet/application/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_pontapass_white_68ca7486d78e8d37.png?fmt=png-alpha&scl=1)

[Pontaパス TOP](https://www.au.com/pontapass/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_payment2_white.png?fmt=png-alpha&scl=1)

[ポイント・決済 TOP](https://www.au.com/payment/)

- [Pontaポイント](https://www.au.com/payment/point/)
- [au PAY（コード支払い/ネット支払い）](https://www.au.com/payment/aupay/)
- [au PAY プリペイドカード](https://www.au.com/payment/prepaid/)
- [au PAY カード](https://www.au.com/payment/card/)
- [au PAY（auかんたん決済）](https://www.au.com/payment/easy/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_hoken_white.png?fmt=png-alpha&scl=1)

[auの金融・保険サービス TOP](https://www.au.com/finance/)

- [auの生命ほけん](https://www.au.com/finance/life-insurance/)
- [auの損害ほけん](https://www.au.com/finance/nonlife-insurance/)
- [auのiDeCo](https://www.au.com/finance/ideco/)
- [auの住宅ローン](https://www.au.com/finance/loan/housing/)
- [auじぶん銀行](https://www.au.com/finance/primebank/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_denki_white.png?fmt=png-alpha&scl=1)

[auでんき・エネルギーサービス TOP](https://www.au.com/energy/)

- [料金プラン](https://www.au.com/energy/denki/merit/plan/)
- [ご契約者向けサポート](https://energy.auone.jp/denki/cs)
- [お引っ越しのご案内](https://energy.auone.jp/denki/merit/moving/)
- [ガスのご案内](https://www.au.com/energy/gas/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_contents_white.png?fmt=png-alpha&scl=1)

[エンタメ TOP](https://www.au.com/entertainment/)

- [映像](https://www.au.com/entertainment/?tabopen=tab_video#anc_01)
- [音楽](https://www.au.com/entertainment/?tabopen=tab_music#anc_01)
- [書籍](https://www.au.com/entertainment/?tabopen=tab_book#anc_01)
- [ニュース](https://www.au.com/entertainment/newspass/)
- [クラウド](https://www.au.com/entertainment/googleone/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_home_white.png?fmt=png-alpha&scl=1)

[くらしのサービス TOP](https://www.au.com/life/)

- [au HOME](https://www.au.com/life/auhome/)
- [auおうちあんしんサポート](https://www.au.com/life/ouchi-anshin/)
- [auわんにゃんサポート](https://pet.life-kurashi.au.com/)
- [au自転車サポート](https://www.au.com/life/bicycle-support/)
- [au PAY ふるさと納税](https://www.au.com/life/furusato-tax/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_wallet_white.png?fmt=png-alpha&scl=1)

[ショッピング TOP](https://www.au.com/shopping/)

- [au PAY マーケット（総合通販）](https://www.au.com/shopping/wowma/)
- [au Online Shop](https://www.au.com/mobile/onlineshop/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_healthcare_white.png?fmt=png-alpha&scl=1)

[ヘルスケア TOP](https://wellness.auone.jp/?medid=au&serial=entertainment&srcid=banner)

x

[![閉じる](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_close_gray_large.png?fmt=png-alpha&scl=1)](https://www.au.com/mobile/charge/charge-list/?bid=we-charge-b-0012#)

商品・サービス![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_smartphone_gray.png?fmt=png-alpha&scl=1)スマートフォン・携帯電話


- [スマートフォン・携帯電話 TOP](https://www.au.com/mobile/)
- [Android](https://www.au.com/mobile/product/smartphone/)
- [iPhone](https://www.au.com/iphone/)
- [iPad](https://www.au.com/ipad/)
- [料金・割引](https://www.au.com/mobile/charge/)
- [サービス・機能](https://www.au.com/mobile/service/)
- [エリア](https://www.au.com/mobile/area/)
- [キャンペーン](https://www.au.com/mobile/campaign/)
- [スマホ教室](https://school.au.com/?medid=au&serial=global_navi&srcid=074)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_internet_gray.png?fmt=png-alpha&scl=1)インターネット回線


- [インターネット回線 TOP](https://www.au.com/internet/)
- [auひかり ホーム10ギガ・5ギガ](https://www.au.com/internet/auhikari_10-5g/)
- [auひかり ホーム1ギガ](https://www.au.com/internet/auhikari_1g/)
- [auひかり マンション](https://www.au.com/internet/mansion/)
- [au one net](https://www.au.com/internet/auonenet/)
- [お申し込み・コース変更](https://www.au.com/internet/application/)

[![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_pontapass_gray_51d343cd9cd339bd.png?fmt=png-alpha&scl=1)Pontaパス](https://www.au.com/pontapass/)![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_payment2_gray.png?fmt=png-alpha&scl=1)ポイント・決済


- [ポイント・決済 TOP](https://www.au.com/payment/)
- [Pontaポイント](https://www.au.com/payment/point/)
- [au PAY（コード支払い/ネット支払い）](https://www.au.com/payment/aupay/)
- [au PAY プリペイドカード](https://www.au.com/payment/prepaid/)
- [au PAY カード](https://www.au.com/payment/card/)
- [au PAY（auかんたん決済）](https://www.au.com/payment/easy/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_hoken_gray.png?fmt=png-alpha&scl=1)auの金融・保険サービス


- [auの金融・保険サービス TOP](https://www.au.com/finance/)
- [auの生命ほけん](https://www.au.com/finance/life-insurance/)
- [auの損害ほけん](https://www.au.com/finance/nonlife-insurance/)
- [auのiDeCo](https://www.au.com/finance/ideco/)
- [auの住宅ローン](https://www.au.com/finance/loan/housing/)
- [auじぶん銀行](https://www.au.com/finance/primebank/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_denki_gray.png?fmt=png-alpha&scl=1)auでんき・エネルギーサービス


- [auでんき・エネルギーサービス TOP](https://www.au.com/energy/)
- [料金プラン](https://www.au.com/energy/denki/merit/plan/)
- [ご契約者向けサポート](https://energy.auone.jp/denki/cs)
- [お引っ越しのご案内](https://energy.auone.jp/denki/merit/moving/)
- [ガスのご案内](https://www.au.com/energy/gas/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_contents_gray.png?fmt=png-alpha&scl=1)エンタメ


- [エンタメ TOP](https://www.au.com/entertainment/)
- [映像](https://www.au.com/entertainment/?tabopen=tab_video#anc_01)
- [音楽](https://www.au.com/entertainment/?tabopen=tab_music#anc_01)
- [書籍](https://www.au.com/entertainment/?tabopen=tab_book#anc_01)
- [ニュース](https://www.au.com/entertainment/newspass/)
- [クラウド](https://www.au.com/entertainment/googleone/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_home_gray.png?fmt=png-alpha&scl=1)くらしのサービス


- [くらしのサービス TOP](https://www.au.com/life/)
- [au HOME](https://www.au.com/life/auhome/)
- [auおうちあんしんサポート](https://www.au.com/life/ouchi-anshin/)
- [auわんにゃんサポート](https://pet.life-kurashi.au.com/)
- [au自転車サポート](https://www.au.com/life/bicycle-support/)
- [au PAY ふるさと納税](https://www.au.com/life/furusato-tax/)

![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_wallet_gray.png?fmt=png-alpha&scl=1)ショッピング


- [ショッピング TOP](https://www.au.com/shopping/)
- [au PAY マーケット（総合通販）](https://www.au.com/shopping/wowma/)
- [au Online Shop](https://www.au.com/mobile/onlineshop/)

[![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_healthcare_gray.png?fmt=png-alpha&scl=1)ヘルスケア](https://wellness.auone.jp/?medid=au&serial=entertainment&srcid=banner)[サポート](https://www.au.com/support/)My au[My au TOP](https://my.au.com/aus/hc-cs/omt/OMT0010001.hc)[スマートフォン・携帯電話](https://my.au.com/aus/hc-cs/osm/OSM0000001.hc)[インターネット・電話](https://my.au.com/aus/hc-cs/oin/OIN0010001.hc)[au HOME](https://my.au.com/aus/WCV411001/WCE411001.hc)[エンタメ](https://my.au.com/aus/hc-cs/oct/OCT0010001.hc)[au PAY](https://my.au.com/aus/hc-cs/ocd/OCD0010001.hc)[ショッピング](https://my.au.com/aus/hc-cs/owm/OWM0010001.hc)[auでんき](https://my.au.com/aus/hc-cs/oet/OET0010001.hc)[auの金融・保険サービス](https://my.au.com/aus/hc-cs/oir/OIR0000001.hc)[ポイント](https://my.au.com/aus/au-cs1/AuHome?PageID=SSO&ActionID=POINT&agdt=2)[お知らせ](https://my.au.com/aus/hc-cs/ony/ONY0010001.hc)

- [![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_shop.png?fmt=png-alpha&scl=1)ショップ検索・来店予約](https://www.au.com/storelocator/)
- [![](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/icon_auonlineshop.png?fmt=png-alpha&scl=1)au Online Shop](https://www.au.com/mobile/onlineshop/)
- [ニュースセンター](https://www.au.com/information/)
  - [お問い合わせ](https://www.au.com/support/inquiry/)
  - [English](https://www.au.com/english/)
  - [企業情報](https://www.kddi.com/corporate/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
  - [サステナビリティ](https://www.kddi.com/corporate/sustainability/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
  - [投資家情報](https://www.kddi.com/corporate/ir/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
  - [採用情報](https://www.kddi.com/corporate/recruit/?utm_source=aucom&utm_medium=referral&utm_campaign=autop)
  - [法人のお客さま](https://biz.kddi.com/service/mobile/)

[スマートフォン・携帯電話](https://www.au.com/mobile/charge/charge-list/?bid=we-charge-b-0012#)

- [スマートフォン・携帯電話](https://www.au.com/mobile/?bid=we-we-gn-2001)
- [スマートフォン・携帯電話 TOP](https://www.au.com/mobile/?bid=we-we-gn-2001)
  - [Android](https://www.au.com/mobile/product/smartphone/)
  - [iPhone](https://www.au.com/iphone/)
  - [料金・割引](https://www.au.com/mobile/charge/?bid=we-we-gn-2003)
  - [サービス・機能](https://www.au.com/mobile/service/?bid=we-we-gn-2004)
  - [エリア](https://www.au.com/mobile/area/?bid=we-we-gn-2005)
  - [キャンペーン](https://www.au.com/mobile/campaign/?bid=we-we-gn-2006)

[![Cart](https://www.au.com/etc.clientlibs/settings/wcm/designs/au-com/clientlib-site/resources/images/icon/icon_cart.png)0](https://www.au.com/cart/?bid=we-we-gn-2904)

1. [トップ](https://www.au.com/)
2. [スマートフォン・携帯電話](https://www.au.com/mobile/)
3. [料金・割引](https://www.au.com/mobile/charge/)
4. 製品別の料金プラン

# 製品別の料金プラン

[![](https://www.au.com/content/dam/au-com/mobile/charge/images/icon-5g.png)\\
\\
**スマートフォンの料金プラン**](https://www.au.com/mobile/charge/charge-list/?bid=we-charge-b-0012#)

[**auバリューリンクプラン ALL STARパック**\\
\\
- \\
データ使い放題\\
\\
\\
- \\
テザリングなどのデータ容量合計100GB\\
\\
\\
- \\
月のデータ利用量合計1GB以下の場合1,650円割引\\
\\
\\
- \\
7つのエンタメサービスを含む\\
\\
［Netflix（広告つきスタンダードプラン）／Apple Music／YouTube Premium／TELASA／Amazonプライム／DAZN／ピッコマWEB］\\
\\
\\
- \\
料金プランに含まれるサービス\\
\\
［Pontaパス／au Starlink Direct（一部機種を除く）／au 5G Fast Lane（5G SA契約のみ）／au海外放題毎月15日分無料／サブスクぷらすポイント20％還元］](https://www.au.com/mobile/charge/smartphone/plan/auvaluelink-allstar/)

[**auバリューリンクプラン DAZNパック**\\
\\
- \\
データ使い放題\\
\\
\\
- \\
テザリングなどのデータ容量合計80GB\\
\\
\\
- \\
月のデータ利用量合計1GB以下の場合1,650円割引\\
\\
\\
- \\
DAZNのご利用料金を含む\\
\\
\\
- \\
料金プランに含まれるサービス\\
\\
［Pontaパス／au Starlink Direct（一部機種を除く）／au 5G Fast Lane（5G SA契約のみ）／au海外放題毎月15日分無料／サブスクぷらすポイント20％還元］](https://www.au.com/mobile/charge/smartphone/plan/auvaluelink-dazn/)

[**auバリューリンクプラン ドラマ・バラエティパック**\\
\\
- \\
データ使い放題\\
\\
\\
- \\
テザリングなどのデータ容量合計80GB\\
\\
\\
- \\
月のデータ利用量合計1GB以下の場合1,650円割引\\
\\
\\
- \\
3つのエンタメサービスを含む\\
\\
［TELASA／FODプレミアム／U-NEXT（Paraviベーシックプラン ドラマ・バラエティパック専用）］\\
\\
\\
- \\
料金プランに含まれるサービス\\
\\
［Pontaパス／au Starlink Direct（一部機種を除く）／au 5G Fast Lane（5G SA契約のみ）／au海外放題毎月15日分無料／サブスクぷらすポイント20％還元］](https://www.au.com/mobile/charge/smartphone/plan/auvaluelink-dmpack/)

[**auバリューリンクプラン Netflixパック（P）**\\
\\
- \\
データ使い放題\\
\\
\\
- \\
テザリングなどのデータ容量合計80GB\\
\\
\\
- \\
月のデータ利用量合計1GB以下の場合1,650円割引\\
\\
\\
- \\
3つのエンタメサービスを含む\\
\\
［Netflix（広告つきスタンダードプラン）／TELASA／Amazonプライム］\\
\\
\\
- \\
料金プランに含まれるサービス\\
\\
［Pontaパス／au Starlink Direct（一部機種を除く）／au 5G Fast Lane（5G SA契約のみ）／au海外放題毎月15日分無料／サブスクぷらすポイント20％還元］](https://www.au.com/mobile/charge/smartphone/plan/auvaluelink-netflix-p/)

[**auバリューリンクプラン Netflixパック**\\
\\
- \\
データ使い放題\\
\\
\\
- \\
テザリングなどのデータ容量合計80GB\\
\\
\\
- \\
月のデータ利用量合計1GB以下の場合1,650円割引\\
\\
\\
- \\
2つのエンタメサービスを含む\\
\\
［Netflix（広告つきスタンダードプラン）／TELASA］\\
\\
\\
- \\
料金プランに含まれるサービス\\
\\
［Pontaパス／au Starlink Direct（一部機種を除く）／au 5G Fast Lane（5G SA契約のみ）／au海外放題毎月15日分無料／サブスクぷらすポイント20％還元］](https://www.au.com/mobile/charge/smartphone/plan/auvaluelink-netflix/)

[**auバリューリンクプラン with Amazonプライム**\\
\\
- \\
データ使い放題\\
\\
\\
- \\
テザリングなどのデータ容量合計80GB\\
\\
\\
- \\
月のデータ利用量合計1GB以下の場合1,650円割引\\
\\
\\
- \\
2つのエンタメサービスを含む\\
\\
［Amazonプライム／TELASA］\\
\\
\\
- \\
料金プランに含まれるサービス\\
\\
［Pontaパス／au Starlink Direct（一部機種を除く）／au 5G Fast Lane（5G SA契約のみ）／au海外放題毎月15日分無料／サブスクぷらすポイント20％還元］](https://www.au.com/mobile/charge/smartphone/plan/auvaluelink-amazon/)

[**auバリューリンクプラン**\\
\\
- \\
データ使い放題\\
\\
\\
- \\
テザリングなどのデータ容量合計60GB\\
\\
\\
- \\
月のデータ利用量合計1GB以下の場合1,650円割引\\
\\
\\
- \\
料金プランに含まれるサービス\\
\\
［Pontaパス／au Starlink Direct（一部機種を除く）／au 5G Fast Lane（5G SA契約のみ）／au海外放題毎月15日分無料／サブスクぷらすポイント20％還元］](https://www.au.com/mobile/charge/smartphone/plan/auvaluelink/)

[**auマネ活バリューリンクプラン ALL STARパック**\\
\\
- \\
データ使い放題\\
\\
\\
- \\
テザリングなどのデータ容量合計100GB\\
\\
\\
\\
- \\
auの金融サービスとあわせて使うとおトク \\
\\
Pontaポイント毎月合計最大4,000円相当たまる！\\
\\
\\
\\
- \\
7つのエンタメサービスを含む\\
\\
［Netflix（広告つきスタンダードプラン）／Apple Music／YouTube Premium／TELASA／Amazonプライム／DAZN／ピッコマWEB］\\
\\
\\
- \\
料金プランに含まれるサービス\\
\\
［Pontaパス／au Starlink Direct（一部機種を除く）／au 5G Fast Lane（5G SA契約のみ）／au海外放題毎月15日分無料／サブスクぷらすポイント20％還元］](https://www.au.com/mobile/charge/smartphone/plan/auvaluelink-allstar-moneyact/)

[**auマネ活バリューリンクプラン DAZNパック**\\
\\
- \\
データ使い放題\\
\\
\\
- \\
テザリングなどのデータ容量合計80GB\\
\\
\\
\\
- \\
auの金融サービスとあわせて使うとおトク \\
\\
Pontaポイント毎月合計最大4,000円相当たまる！\\
\\
\\
\\
- \\
DAZNのご利用料金を含む\\
\\
\\
- \\
料金プランに含まれるサービス\\
\\
［Pontaパス／au Starlink Direct（一部機種を除く）／au 5G Fast Lane（5G SA契約のみ）／au海外放題毎月15日分無料／サブスクぷらすポイント20％還元］](https://www.au.com/mobile/charge/smartphone/plan/auvaluelink-dazn-moneyact/)

[**auマネ活バリューリンクプラン ドラマ・バラエティパック**\\
\\
- \\
データ使い放題\\
\\
\\
- \\
テザリングなどのデータ容量合計80GB\\
\\
\\
\\
- \\
auの金融サービスとあわせて使うとおトク \\
\\
Pontaポイント毎月合計最大4,000円相当たまる！\\
\\
\\
\\
- \\
3つのエンタメサービスを含む\\
\\
［TELASA／FODプレミアム／U-NEXT（Paraviベーシックプラン ドラマ・バラエティパック専用）］\\
\\
\\
- \\
料金プランに含まれるサービス\\
\\
［Pontaパス／au Starlink Direct（一部機種を除く）／au 5G Fast Lane（5G SA契約のみ）／au海外放題毎月15日分無料／サブスクぷらすポイント20％還元］](https://www.au.com/mobile/charge/smartphone/plan/auvaluelink-dmpack-moneyact/)

[**auマネ活バリューリンクプラン Netflixパック（P）**\\
\\
- \\
データ使い放題\\
\\
\\
- \\
テザリングなどのデータ容量合計80GB\\
\\
\\
\\
- \\
auの金融サービスとあわせて使うとおトク \\
\\
Pontaポイント毎月合計最大4,000円相当たまる！\\
\\
\\
\\
- \\
3つのエンタメサービスを含む\\
\\
［Netflix（広告つきスタンダードプラン）／TELASA／Amazonプライム］\\
\\
\\
- \\
料金プランに含まれるサービス\\
\\
［Pontaパス／au Starlink Direct（一部機種を除く）／au 5G Fast Lane（5G SA契約のみ）／au海外放題毎月15日分無料／サブスクぷらすポイント20％還元］](https://www.au.com/mobile/charge/smartphone/plan/auvaluelink-netflix-p-moneyact/)

[**auマネ活バリューリンクプラン Netflixパック**\\
\\
- \\
データ使い放題\\
\\
\\
- \\
テザリングなどのデータ容量合計80GB\\
\\
\\
\\
- \\
auの金融サービスとあわせて使うとおトク \\
\\
Pontaポイント毎月合計最大4,000円相当たまる！\\
\\
\\
\\
- \\
2つのエンタメサービスを含む\\
\\
［Netflix（広告つきスタンダードプラン）／TELASA］\\
\\
\\
- \\
料金プランに含まれるサービス\\
\\
［Pontaパス／au Starlink Direct（一部機種を除く）／au 5G Fast Lane（5G SA契約のみ）／au海外放題毎月15日分無料／サブスクぷらすポイント20％還元］](https://www.au.com/mobile/charge/smartphone/plan/auvaluelink-netflix-moneyact/)

[**auマネ活バリューリンクプラン with Amazonプライム**\\
\\
- \\
データ使い放題\\
\\
\\
- \\
テザリングなどのデータ容量合計80GB\\
\\
\\
\\
- \\
auの金融サービスとあわせて使うとおトク \\
\\
Pontaポイント毎月合計最大4,000円相当たまる！\\
\\
\\
\\
- \\
2つのエンタメサービスを含む\\
\\
［Amazonプライム／TELASA］\\
\\
\\
- \\
料金プランに含まれるサービス\\
\\
［Pontaパス／au Starlink Direct（一部機種を除く）／au 5G Fast Lane（5G SA契約のみ）／au海外放題毎月15日分無料／サブスクぷらすポイント20％還元］](https://www.au.com/mobile/charge/smartphone/plan/auvaluelink-amazon-moneyact/)

[**auマネ活バリューリンクプラン**\\
\\
- \\
データ使い放題\\
\\
\\
- \\
テザリングなどのデータ容量合計60GB\\
\\
\\
\\
- \\
auの金融サービスとあわせて使うとおトク \\
\\
Pontaポイント毎月合計最大4,000円相当たまる！\\
\\
\\
\\
- \\
料金プランに含まれるサービス\\
\\
［Pontaパス／au Starlink Direct（一部機種を除く）／au 5G Fast Lane（5G SA契約のみ）／au海外放題毎月15日分無料／サブスクぷらすポイント20％還元］](https://www.au.com/mobile/charge/smartphone/plan/auvaluelink-moneyact/)

[**使い放題MAX＋ 5G ALL STARパック**\\
\\
- \\
データ使い放題\\
\\
\\
- \\
テザリングなどのデータ容量合計100GB\\
\\
\\
- \\
月のデータ利用量合計1GB以下の場合1,650円割引\\
\\
\\
- \\
7つのエンタメサービスを含む\\
\\
［Netflix（広告つきスタンダードプラン）／Apple Music／YouTube Premium／TELASA／Amazonプライム／DAZN／ピッコマWEB］\\
\\
\\
- \\
料金プランに含まれるサービス\\
\\
［au Starlink Direct（一部機種を除く）／au 5G Fast Lane（5G SA契約のみ）／au海外放題毎月15日分無料／サブスクぷらすポイント20％還元］](https://www.au.com/mobile/charge/smartphone/plan/data-unlimited-plus-allstar/)

[**使い放題MAX＋ 5G／4G DAZNパック**\\
\\
- \\
データ使い放題\\
\\
\\
- \\
テザリングなどのデータ容量合計80GB\\
\\
\\
- \\
月のデータ利用量合計1GB以下の場合1,650円割引\\
\\
\\
- \\
DAZNのご利用料金を含む\\
\\
\\
- \\
料金プランに含まれるサービス\\
\\
［au Starlink Direct（一部機種を除く）／au 5G Fast Lane（5G SA契約のみ）／au海外放題毎月15日分無料／サブスクぷらすポイント20％還元］](https://www.au.com/mobile/charge/smartphone/plan/data-unlimited-plus-dazn/)

[**使い放題MAX＋ 5G／4G ドラマ・バラエティパック**\\
\\
- \\
データ使い放題\\
\\
\\
- \\
テザリングなどのデータ容量合計80GB\\
\\
\\
- \\
月のデータ利用量合計1GB以下の場合1,650円割引\\
\\
\\
- \\
3つのエンタメサービスを含む\\
\\
［TELASA／FODプレミアム／U-NEXT（Paraviベーシックプラン ドラマ・バラエティパック専用）］\\
\\
\\
- \\
料金プランに含まれるサービス\\
\\
［au Starlink Direct（一部機種を除く）／au 5G Fast Lane（5G SA契約のみ）／au海外放題毎月15日分無料／サブスクぷらすポイント20％還元］](https://www.au.com/mobile/charge/smartphone/plan/data-unlimited-plus-dmpack/)

[**使い放題MAX＋ 5G／4G Netflixパック（P）**\\
\\
- \\
データ使い放題\\
\\
\\
- \\
テザリングなどのデータ容量合計80GB\\
\\
\\
- \\
月のデータ利用量合計1GB以下の場合1,650円割引\\
\\
\\
- \\
3つのエンタメサービスを含む\\
\\
［Netflix（広告つきスタンダードプラン）／TELASA／Amazonプライム］\\
\\
\\
- \\
料金プランに含まれるサービス\\
\\
［au Starlink Direct（一部機種を除く）／au 5G Fast Lane（5G SA契約のみ）／au海外放題毎月15日分無料／サブスクぷらすポイント20％還元］](https://www.au.com/mobile/charge/smartphone/plan/data-unlimited-plus-netflix-p/)

[**使い放題MAX＋ 5G／4G Netflixパック**\\
\\
- \\
データ使い放題\\
\\
\\
- \\
テザリングなどのデータ容量合計80GB\\
\\
\\
- \\
月のデータ利用量合計1GB以下の場合1,650円割引\\
\\
\\
- \\
2つのエンタメサービスを含む\\
\\
［Netflix（広告つきスタンダードプラン）／TELASA］\\
\\
\\
- \\
料金プランに含まれるサービス\\
\\
［au Starlink Direct（一部機種を除く）／au 5G Fast Lane（5G SA契約のみ）／au海外放題毎月15日分無料／サブスクぷらすポイント20％還元］](https://www.au.com/mobile/charge/smartphone/plan/data-unlimited-plus-netflix/)

[**使い放題MAX＋ 5G with Amazonプライム**\\
\\
- \\
データ使い放題\\
\\
\\
- \\
テザリングなどのデータ容量合計80GB\\
\\
\\
- \\
月のデータ利用量合計1GB以下の場合1,650円割引\\
\\
\\
- \\
2つのエンタメサービスを含む\\
\\
［Amazonプライム／TELASA］\\
\\
\\
- \\
料金プランに含まれるサービス\\
\\
［au Starlink Direct（一部機種を除く）／au 5G Fast Lane（5G SA契約のみ）／au海外放題毎月15日分無料／サブスクぷらすポイント20％還元］](https://www.au.com/mobile/charge/smartphone/plan/data-unlimited-plus-amazon/)

[**使い放題MAX＋ 5G／4G**\\
\\
- \\
データ使い放題\\
\\
\\
- \\
テザリングなどのデータ容量合計60GB\\
\\
\\
- \\
月のデータ利用量合計1GB以下の場合1,650円割引\\
\\
\\
- \\
料金プランに含まれるサービス\\
\\
［au Starlink Direct（一部機種を除く）／au 5G Fast Lane（5G SA契約のみ）／au海外放題毎月15日分無料／サブスクぷらすポイント20％還元］](https://www.au.com/mobile/charge/smartphone/plan/data-unlimited-plus/)

[**auマネ活プラン＋ 5G ALL STARパック**\\
\\
- \\
データ使い放題\\
\\
\\
- \\
テザリングなどのデータ容量合計100GB\\
\\
\\
\\
- \\
auの金融サービスとあわせて使うとおトク \\
\\
Pontaポイント毎月合計最大4,000円相当たまる！\\
\\
\\
\\
- \\
7つのエンタメサービスを含む\\
\\
［Netflix（広告つきスタンダードプラン）／Apple Music／YouTube Premium／TELASA／Amazonプライム／DAZN／ピッコマWEB］\\
\\
\\
- \\
料金プランに含まれるサービス\\
\\
［au Starlink Direct（一部機種を除く）／au 5G Fast Lane（5G SA契約のみ）／au海外放題毎月15日分無料／サブスクぷらすポイント20％還元］](https://www.au.com/mobile/charge/smartphone/plan/data-unlimited-allstar-moneyact-plus/)

[**auマネ活プラン＋ 5G／4G DAZNパック**\\
\\
- \\
データ使い放題\\
\\
\\
- \\
テザリングなどのデータ容量合計80GB\\
\\
\\
\\
- \\
auの金融サービスとあわせて使うとおトク \\
\\
Pontaポイント毎月合計最大4,000円相当たまる！\\
\\
\\
\\
- \\
DAZNのご利用料金を含む\\
\\
\\
- \\
料金プランに含まれるサービス\\
\\
［au Starlink Direct（一部機種を除く）／au 5G Fast Lane（5G SA契約のみ）／au海外放題毎月15日分無料／サブスクぷらすポイント20％還元］](https://www.au.com/mobile/charge/smartphone/plan/data-unlimited-dazn-moneyact-plus/)

[**auマネ活プラン＋ 5G／4G ドラマ・バラエティパック**\\
\\
- \\
データ使い放題\\
\\
\\
- \\
テザリングなどのデータ容量合計80GB\\
\\
\\
\\
- \\
auの金融サービスとあわせて使うとおトク \\
\\
Pontaポイント毎月合計最大4,000円相当たまる！\\
\\
\\
\\
- \\
3つのエンタメサービスを含む\\
\\
［TELASA／FODプレミアム／U-NEXT（Paraviベーシックプラン ドラマ・バラエティパック専用）］\\
\\
\\
- \\
料金プランに含まれるサービス\\
\\
［au Starlink Direct（一部機種を除く）／au 5G Fast Lane（5G SA契約のみ）／au海外放題毎月15日分無料／サブスクぷらすポイント20％還元］](https://www.au.com/mobile/charge/smartphone/plan/data-unlimited-dmpack-moneyact-plus/)

[**auマネ活プラン＋ 5G／4G Netflixパック（P）**\\
\\
- \\
データ使い放題\\
\\
\\
- \\
テザリングなどのデータ容量合計80GB\\
\\
\\
\\
- \\
auの金融サービスとあわせて使うとおトク \\
\\
Pontaポイント毎月合計最大4,000円相当たまる！\\
\\
\\
\\
- \\
3つのエンタメサービスを含む\\
\\
［Netflix（広告つきスタンダードプラン）／TELASA／Amazonプライム］\\
\\
\\
- \\
料金プランに含まれるサービス\\
\\
［au Starlink Direct（一部機種を除く）／au 5G Fast Lane（5G SA契約のみ）／au海外放題毎月15日分無料／サブスクぷらすポイント20％還元］](https://www.au.com/mobile/charge/smartphone/plan/data-unlimited-netflix-p-moneyact-plus/)

[**auマネ活プラン＋ 5G／4G Netflixパック**\\
\\
- \\
データ使い放題\\
\\
\\
- \\
テザリングなどのデータ容量合計80GB\\
\\
\\
\\
- \\
auの金融サービスとあわせて使うとおトク \\
\\
Pontaポイント毎月合計最大4,000円相当たまる！\\
\\
\\
\\
- \\
2つのエンタメサービスを含む\\
\\
［Netflix（広告つきスタンダードプラン）／TELASA］\\
\\
\\
- \\
料金プランに含まれるサービス\\
\\
［au Starlink Direct（一部機種を除く）／au 5G Fast Lane（5G SA契約のみ）／au海外放題毎月15日分無料／サブスクぷらすポイント20％還元］](https://www.au.com/mobile/charge/smartphone/plan/data-unlimited-netflix-moneyact-plus/)

[**auマネ活プラン＋ 5G with Amazonプライム**\\
\\
- \\
データ使い放題\\
\\
\\
- \\
テザリングなどのデータ容量合計80GB\\
\\
\\
\\
- \\
auの金融サービスとあわせて使うとおトク \\
\\
Pontaポイント毎月合計最大4,000円相当たまる！\\
\\
\\
\\
- \\
2つのエンタメサービスを含む\\
\\
［Amazonプライム／TELASA］\\
\\
\\
- \\
料金プランに含まれるサービス\\
\\
［au Starlink Direct（一部機種を除く）／au 5G Fast Lane（5G SA契約のみ）／au海外放題毎月15日分無料／サブスクぷらすポイント20％還元］](https://www.au.com/mobile/charge/smartphone/plan/data-unlimited-amazon-moneyact-plus/)

[**auマネ活プラン＋ 5G／4G**\\
\\
- \\
データ使い放題\\
\\
\\
- \\
テザリングなどのデータ容量合計60GB\\
\\
\\
\\
- \\
auの金融サービスとあわせて使うとおトク \\
\\
Pontaポイント毎月合計最大4,000円相当たまる！\\
\\
\\
\\
- \\
料金プランに含まれるサービス\\
\\
［au Starlink Direct（一部機種を除く）／au 5G Fast Lane（5G SA契約のみ）／au海外放題毎月15日分無料／サブスクぷらすポイント20％還元］](https://www.au.com/mobile/charge/smartphone/plan/data-unlimited-moneyact-plus/)

[**スマホミニプラン＋ 5G／4G**\\
\\
- \\
データ通信を使った分だけお支払い\\
\\
\\
- \\
料金プランに含まれるサービス\\
\\
［au Starlink Direct（一部機種を除く）／サブスクぷらすポイント20％還元］](https://www.au.com/mobile/charge/smartphone/plan/sp-mini-plus/)

[**U12バリュープラン**\\
\\
- \\
5～12歳の方がご加入いただけるプラン\\
\\
\\
- \\
お子さまに適した通信速度で安心（送受信最大300kbps）\\
\\
\\
- \\
「コドマモ」「auキッズラボ」がコミコミ\\
\\
\\
- \\
料金プランに含まれるサービス［au Starlink Direct（一部機種を除く）］](https://www.au.com/mobile/charge/smartphone/plan/u12value/)

[**U16バリュープラン**\\
\\
- \\
5～16歳の方がご加入いただけるプラン\\
\\
\\
- \\
データ通信を使った分だけお支払い（20GBまで）\\
\\
\\
- \\
料金プランに含まれるサービス［au Starlink Direct（一部機種を除く）／サブスクぷらすポイント最大20％還元］](https://www.au.com/mobile/charge/smartphone/plan/u16value/)

[**シニアバリュープラン**\\
\\
- \\
60歳以上の方がご加入いただけるプラン\\
\\
\\
- \\
データ容量5GB\\
\\
\\
- \\
5分／回以内の国内通話がかけ放題\\
\\
\\
- \\
料金プランに含まれるサービス［au Starlink Direct（一部機種を除く）／サブスクぷらすポイント最大20％還元］](https://www.au.com/mobile/charge/smartphone/plan/seniorvalue/)

-
テザリング、データシェアのご利用には、データ容量の上限があります。上限を超えた場合、これらのサービスの通信速度は送受信最大128kbpsとなります（通信速度の制限は、翌月1日に順次解除されます）。


-
スマホスタートプランについては、月間データ容量を超えた場合、当月末までの通信速度が送受信最大300kbpsとなります（通信速度の制限は、翌月1日に順次解除されます）。


-
混雑時や大量のデータ通信のご利用があった場合などに通信速度の制限を行うことがあります。



### スマートフォンの通話オプション

[**通話定額2／通話定額ライト2**\\
\\
データ定額プランとあわせて別途お申し込みください。\\
\\
- \\
＋1,980円／月で国内通話が24時間かけ放題の「通話定額2」\\
\\
\\
- \\
＋880円／月で1回5分以内の国内通話が24時間かけ放題の「通話定額ライト2」](https://www.au.com/mobile/charge/smartphone/plan/calling-option2/)

[![](https://www.au.com/content/dam/au-com/mobile/charge/images/icon-featurephone.png)\\
\\
**ケータイの料金プラン**](https://www.au.com/mobile/charge/charge-list/?bid=we-charge-b-0012#)

### ケータイ（4G LTE）の料金プラン

[**ケータイプラン**\\
\\
- \\
通話のみでご利用の方にもおすすめ\\
\\
\\
- \\
データ通信をご利用の場合はLTE NET（330円／月）への加入が必要です（月間データ容量300MB）](https://www.au.com/mobile/charge/4glte-featurephone/plan/k-tai/)

### ケータイ（4G LTE）の通話オプション

[**通話定額2／通話定額ライト2**\\
\\
データ定額プランとあわせて別途お申し込みください。\\
\\
- \\
＋1,980円／月で国内通話が24時間かけ放題の「通話定額2」\\
\\
\\
- \\
＋880円／月で1回5分以内の国内通話が24時間かけ放題の「通話定額ライト2」](https://www.au.com/mobile/charge/smartphone/plan/calling-option2/)

[**通話定額／通話定額ライト**\\
\\
データ定額プランとあわせて別途お申し込みください。\\
\\
- \\
＋1,870円／月で国内通話が24時間かけ放題の「通話定額」\\
\\
\\
- \\
＋770円／月で1回5分以内の国内通話が24時間かけ放題の「通話定額ライト」](https://www.au.com/mobile/charge/smartphone/plan/calling-option/)

[![](https://www.au.com/content/dam/au-com/mobile/charge/images/icon-tablet.png)\\
\\
**iPad／タブレットの料金プラン**](https://www.au.com/mobile/charge/charge-list/?bid=we-charge-b-0012#)

### タブレットの料金プラン

[**タブレットシェアプラン 5G／4G**\\
\\
- \\
スマートフォンとセットでご利用いただくことで、スマートフォンのデータ容量をシェアできるプランです](https://www.au.com/mobile/charge/tablet/plan/tablet-share/)

[**タブレットプラン3 5G／4G**\\
\\
- \\
3GBのデータ容量をご利用いただけるプランです](https://www.au.com/mobile/charge/tablet/plan/tablet-3/)

[**タブレットプラン50 5G／4G**\\
\\
- \\
50GBのデータ容量をご利用いただけるプランです](https://www.au.com/mobile/charge/tablet/plan/tablet-50/)

### タブレットのプリペイドサービス

[**LTEデータプリペイド**\\
\\
- \\
データ容量をあらかじめチャージしていただくことで、月額基本使用料なし](https://www.au.com/mobile/charge/tablet/plan/data-prepaid/)

[**ウォッチナンバーの料金プラン**](https://www.au.com/mobile/charge/charge-list/?bid=we-charge-b-0012#)

[**ウォッチナンバープラン**\\
\\
- \\
Apple Watch向けプラン\\
\\
\\
- \\
Apple Watch専用の電話番号が利用可能](https://www.au.com/mobile/charge/watch-number/)

[![](https://www.au.com/content/dam/au-com/mobile/charge/images/icon-mobilerouter.png)\\
\\
**データ通信端末の料金プラン**](https://www.au.com/mobile/charge/charge-list/?bid=we-charge-b-0012#)

### WiMAX 2+／5G／4G LTE対応端末向け料金プラン

[**モバイルルータープラン 5G**\\
\\
- \\
5Gのモバイルルーター向け料金プラン\\
\\
\\
- \\
スタンダードモードご利用時　月間データ容量上限なし※](https://www.au.com/mobile/charge/data/plan/routerplan-5g/)

[**ホームルータープラン 5G**\\
\\
- \\
5Gの据え置きルーター向け料金プラン\\
\\
\\
- \\
スタンダードモードご利用時　月間データ容量上限なし※](https://www.au.com/mobile/charge/data/plan/homerouterplan-5g/)

-
モバイルルータープラン 5Gでプラスエリアモードご利用の場合、別途利用料がかかります。ホームルータープラン 5Gの場合、利用料はかかりません。プラスエリアモードご利用時に月間データ容量（モバイルルータープラン 5G、ホームルータープラン 5G いずれも30GB）を超えた場合、当月末までの通信速度が送受信最大128kbpsとなります。スタンダードモードご利用時は対象外です。



[詳しく\\
\\
\\
\\
**ルーターフラットプラン80（5G）**\\
\\
- \\
5G対応\\
\\
\\
- \\
データ容量80GB※\\
\\
詳しく](https://www.au.com/mobile/charge/data/plan/flatplan80/)

-
「5G」「4G LTE」「WiMAX 2+」の当月利用の通信量合計が80GBを超えた場合、当月中は「5G」「4G LTE」「WiMAX 2+」通信の通信速度が送受信最大128kbpsとなります。



### WiMAX 2+／4G LTE対応端末向け料金プラン

[**モバイルルータープラン／ホームルータープラン**\\
\\
- \\
ハイスピードモードご利用時　月間データ容量上限なし※](https://www.au.com/mobile/charge/data/plan/routerplan/)

-
ハイスピードプラスエリアモードご利用の場合、別途利用料がかかります。ルーターに初期設定されているAPNを変更されますと、速度制限（月間7GB超）の対象となる場合があります。なお、ハイスピードプラスエリアモードの「WiMAX 2+」「4G LTE」の当月利用の通信量合計が7GBを超えた場合、ハイスピードモードの「WiMAX 2+」通信を含め、当月中は「WiMAX 2+」「4G LTE」通信の通信速度が送受信最大128kbpsとなります。



### 無線LAN STICK向け料金プラン

[**無線LAN STICKプラン ds**\\
\\
- \\
無線LAN STICK専用プラン\\
\\
\\
- \\
スマートフォン（5G）／スマートフォン（4G LTE）※とセットでのご利用となります](https://www.au.com/mobile/charge/charge-list/data-iot-stickplan-ds/)

-
「シニアプラン」「ジュニアスマートフォンプラン」は（V）がつくプランのみ対象です。従量プランご加入の方は対象外です。



[![](https://www.au.com/content/dam/au-com/mobile/charge/images/icon-junior.png)\\
\\
**mamorinoの料金プラン**](https://www.au.com/mobile/charge/charge-list/?bid=we-charge-b-0012#)

[**ジュニアケータイプランME**\\
\\
- \\
小学生以下のお子様向けのプランです。](https://www.au.com/mobile/charge/juniorphone-me/)

[**ジュニアケータイプランN**\\
\\
- \\
小学生以下のお子様向けのプランです。](https://www.au.com/mobile/charge/juniorphone-n/)

-
小学生以下の条件を満たさない場合、ケータイプランをお選びいただくことで、「mamorino6」「mamorino5」「mamorino4」がご利用いただけます。



[![](https://www.au.com/content/dam/au-com/mobile/charge/images/icon-mamorinowatch.png)\\
\\
**mamorino Watchの料金プラン**](https://www.au.com/mobile/charge/charge-list/?bid=we-charge-b-0012#)

[**mamorino WatchプランN**\\
\\
- \\
小学生以下のお子様が対象の「mamorino Watch」専用のプラン](https://www.au.com/mobile/charge/mamorino_watch-n/)

[お申し込み受付終了プランはこちら](https://www.au.com/mobile/charge/application-ended/)

料金プランについて

理解できましたか？

- [はい](https://www.au.com/mobile/charge/charge-list/?bid=we-charge-b-0012#)
- [いいえ](https://www.au.com/mobile/charge/charge-list/?bid=we-charge-b-0012#plnsim)

自分にあった料金プランが

分からない人はこちら

[料金プランシミュレーション](https://www.au.com/mobile/simulation/plan/)

[**組み合わせて便利に！**\\
\\
オプション一覧を見る](https://www.au.com/mobile/charge/discount-option/#option)

[**組み合わせておトク！**\\
\\
割引一覧を見る](https://www.au.com/mobile/charge/discount-option/#discount)

[**今だけのおトク！**\\
\\
キャンペーン一覧を見る](https://www.au.com/mobile/campaign/)

[**もっと便利に！**\\
\\
サービス一覧を見る](https://www.au.com/mobile/service/)

- 表記の金額は特に記載のある場合を除きすべて税込です。

- [サイトマップ](https://www.au.com/sitemap/)
- [au IDについて](https://www.au.com/au-id/)
- [au ブランドについて](https://www.au.com/brand/)
- [KDDIブランドについて](https://brand.kddi.com/)
- [サステナビリティ](https://www.kddi.com/corporate/sustainability/)
- [法人のお客さま](https://biz.kddi.com/)
- [企業情報](https://www.kddi.com/corporate/)
- [KDDIサイトマップ](https://www.kddi.com/sitemap/)

- [サイトポリシー](https://www.kddi.com/terms/sitepolicy/)
- [My au利用規約](https://www.au.com/my-au/terms/)
- [プライバシーポリシー](https://www.kddi.com/corporate/kddi/public/privacy/)
- [プライバシーポータル](https://www.kddi.com/corporate/kddi/public/privacy-portal/)
- [セキュリティポータル](https://www.kddi.com/corporate/kddi/public/security-portal/)
- [ソーシャルメディアポリシー](https://www.kddi.com/terms/social-media/)
- [動作環境・Cookie情報の利用について](https://www.kddi.com/terms/requirements/)
- [ウェブアクセシビリティの取り組み](https://www.au.com/accessibility/)
- [商標について](https://www.au.com/trademark/)

[![KDDI](https://kddi-h.assetsadobe3.com/is/image/content/dam/au-com/designs/icon/footer_logo.png?fmt=png-alpha&scl=1)](https://www.kddi.com/)

COPYRIGHT © KDDI CORPORATION, ALL RIGHTS RESERVED.