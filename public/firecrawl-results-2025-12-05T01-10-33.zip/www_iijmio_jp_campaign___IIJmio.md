# おトク&キャンペーン情報 | IIJmio

URL: https://www.iijmio.jp/campaign/

---

IIJmio おトク&キャンペーン情報
===================

IIJmioのおトクな情報、キャンペーン情報を、ご購入・お申し込み内容ごとにご案内いたします。

*   [端末・セット](https://www.iijmio.jp/campaign/#)
    
*   [SIMのみ](https://www.iijmio.jp/campaign/#)
    
*   [その他](https://www.iijmio.jp/campaign/#)
    

お客様にオススメのキャンペーン情報
-----------------

*   いつもIIJmioをご利用いただきありがとうございます。  
    現在、お客様にオススメのキャンペーンは実施しておりません。
    

*   ログインすることで、お客様にオススメのキャンペーンを表示します。
    

お客様にオススメのキャンペーンを表示するためには、ログインが必要です。

[![会員ログイン](https://www.iijmio.jp/resources/WebContent/member/img/btn_menberLogin-mini.png)](https://www.iijmio.jp/auth/login/)

[※mioIDとパスワードをお忘れの時は](https://www.iijmio.jp/auth/forget/)

ようこそ  様

[![ログアウト](https://www.iijmio.jp/image/bLogout-btn.png)](https://www.iijmio.jp/auth/logout/)

### 端末・セット

[過去のキャンペーン一覧はこちら](https://www.iijmio.jp/campaign/archive/)
 

現在実施中のキャンペーンはございません。

### SIMのみ

[過去のキャンペーン一覧はこちら](https://www.iijmio.jp/campaign/archive/)
 

現在実施中のキャンペーンはございません。

### その他

[過去のキャンペーン一覧はこちら](https://www.iijmio.jp/campaign/archive/)
 

現在実施中のキャンペーンはございません。

※金額は全て税込で表記しています。  
※IIJmioは株式会社インターネットイニシアティブが提供する個人向けインターネットサービスです。

 [![ご購入・お申し込みはこちら](https://www.iijmio.jp/hdd/img/cvr-02-btn-04.png) ![ご購入・お申し込みはこちら](https://www.iijmio.jp/hdd/img/cvr-02-btn-04_sp.png)](https://www.iijmio.jp/mobile/signup/)

![ショッピングサイトで購入](https://www.iijmio.jp/hdd/img/cvr-02-btn-02.png) [![Amazon.co.jp](https://www.iijmio.jp/hdd/img/cvr-02-btn-03.png)](https://www.iijmio.jp/campaign/#)

店舗でも購入できます[IIJmio取り扱い店舗はこちら](https://www.iijmio.jp/hdd/shop/)

お近くのコンビニでも購入できます[IIJmioえらべるSIMカード](https://www.iijmio.jp/eraberu/)

  

*   [このサイトのご利用について](https://www.iijmio.jp/thissite/)
    
*   [情報セキュリティ基本方針](http://www.iij.ad.jp/securitypolicy/)
    
*   [サイトマップ](https://www.iijmio.jp/sitemap.html)
    
*   [初期契約解除について](https://www.iijmio.jp/member/cancellation/)
    

*   [個人情報保護ポリシー](http://www.iij.ad.jp/privacy/)
    
*   [「特定商取引に関する法律」「古物営業法」に基づく表示](https://www.iijmio.jp/tokusho/)
    
*   [お問い合わせ](https://www.iijmio.jp/contact.html)
    

[![プライバシーマーク](https://www.iijmio.jp/image/pmark.png)](https://privacymark.jp/)

[![page top](https://www.iijmio.jp/image/page-top.png)](https://www.iijmio.jp/campaign/#top)

[![IIJ](https://www.iijmio.jp/image/footer-logo.jpg)](http://www.iij.ad.jp/)

IIJmioは株式会社インターネットイニシアティブが提供する個人向けインターネットサービスです

[企業情報はこちら](http://www.iij.ad.jp/company/)

©2005-2025 Internet Initiative Japan Inc.

〒102-0071　東京都千代田区富士見2-10-2　飯田橋グラン・ブルーム  
届出番号(電気通信事業者)：第A-16-7006号  
代理店届出番号：第C2002871号

[![twitter](https://www.iijmio.jp/image/footer-sns-icon-01.jpg)](http://twitter.com/share?url=https://www.iijmio.jp/campaign/&amp;text=%E3%81%8A%E3%83%88%E3%82%AF&%E3%82%AD%E3%83%A3%E3%83%B3%E3%83%9A%E3%83%BC%E3%83%B3%E6%83%85%E5%A0%B1%20%7C%20IIJmio)
 [![hatena](https://www.iijmio.jp/image/footer-sns-icon-02.jpg)](http://b.hatena.ne.jp/append?https://www.iijmio.jp/campaign/)

©2005-2025 Internet Initiative Japan Inc.
