# Rakuten Hikari: Fast, Stable, and IPv6-Compatible Fiber Optic Internet

URL: https://network.mobile.rakuten.co.jp/hikari/

---

[![Rakuten Mobile](https://cdn.rmc.contents.rakuten.co.jp/block/d40535ac09aac0ef32f8a23b8bb8e04bc2e8f9d6b0981fa98a16d0382f558d83/d72cbeb1-1b70-4fb2-b7e5-cb3c0a24841f/card20k_enddate_pc_1440x50.png)](https://cdn.rex.contents.rakuten.co.jp/webcx-redirect-module/1.3.0/index.html?clientId=d40535ac09aac0ef32f8a23b8bb8e04bc2e8f9d6b0981fa98a16d0382f558d83&version=2.73.0&sessionId=677877e7-e546-4d8f-8de4-ac09813547d1&screen=WB&issueId=F01184-001256&campaignId=2aadf4f2-55c7-4337-8472-22f617277367&contentId=4382487a-283f-4306-b0d1-11d8c70206b1&replacementId=9354c015-1ef6-41d2-8298-0bf372a98402&impressionId=03aef761-ebc1-42fb-8b13-ec983012fb78&selector=mkdiv_header_pitari&redirect=aHR0cHM6Ly9yZC5yYWt1dGVuLmNvLmpwL3JhdD9SMj1odHRwczovL25ldHdvcmsubW9iaWxlLnJha3V0ZW4uY28uanAvY2FtcGFpZ24vY2FyZC1tb2JpbGUtbWFqaXRva3UvJTNGc2NpZCUzRHdpX3JtYl9ybWJfbWtkaXZfaGVhZGVyX3BpdGFyaV9jbW9fc3BfbmV3LWNhcmQtbm8td2ViY3hfY2FyZC1tb2JpbGUtbWFqaXRva3VfMjAyNTEyMDEmYWNjPTEzMTImYWlkPTEmZXR5cGU9Y2xpY2smc3NjPWNyb3NzdXNlX2NhbXBhaWduJnBnbj1jbW9fcGl0YXJpJnJlZj1odHRwczovL25ldHdvcmsubW9iaWxlLnJha3V0ZW4uY28uanAvaGlrYXJpLyZ0YXJnZXRfZWxlPW5ldy1jYXJkLW5vLXdlYmN4X2NhcmQtbW9iaWxlLW1haml0b2t1XzIwMjUxMjAx&origin=aHR0cHM6Ly9uZXR3b3JrLm1vYmlsZS5yYWt1dGVuLmNvLmpw)

[![Rakuten Mobile](https://network.mobile.rakuten.co.jp/assets/img/hikari/common-v2/header-logo-pink.svg)](https://network.mobile.rakuten.co.jp/?wovn=en&l-id=rhk_header_mno_01)

[Rakuten Mobile](https://network.mobile.rakuten.co.jp/?wovn=en&l-id=rhk_header_mno_02)
 ​ ​| ​ ​[Rakuten Turbo](https://network.mobile.rakuten.co.jp/internet/turbo/?wovn=en&l-id=rhk_header_mno_internet_turbo_01)
 ​ ​|

Language

*   日本語
*   English
*   简体中文
*   繁體中文
*   한국어
*   tiếng việt
*   Indonesia
*   português

[![Rakuten Hikari](https://network.mobile.rakuten.co.jp/assets/img/hikari/common-v2/header-logo-white.svg)](https://network.mobile.rakuten.co.jp/hikari/?wovn=en&l-id=rhk_gheader_top_01)

Search

[Member page](https://ms.fusioncom.co.jp/rbb/members/login?campaign=web-rakuten&l-id=rhk_gheader_ecare&_ebx=g1rjgkpzt4.1693291119.7s1i0ki)

[Apply Now](https://secure3.gol.com/mod-pl/rbb/rmch.cgi?scode=qngTI9rXJpRlc1l6roM&cpnkind=set2512h8&l-id=rhk_header_onb&ratck=Rp%3Dundefined)

Menu

*   Price
    
    *   [Price simulation](https://network.mobile.rakuten.co.jp/hikari/fee/simulation/?wovn=en&l-id=rhk_gheader_fee_simulation_01)
        
    *   [Price](https://network.mobile.rakuten.co.jp/hikari/fee/pricelist/?wovn=en&l-id=rhk_gheader_fee_pricelist_01)
        
    
*   Campaigns
    
    *   [Rakuten Hikari SAIKYO HOME Program](https://network.mobile.rakuten.co.jp/hikari/campaign/home-internet/?wovn=en&l-id=rhk_gheader_campaign_home-internet_01)
        
    *   [SPU (Super Point Up Program)](https://network.mobile.rakuten.co.jp/internet/turbo/campaign/spu/?wovn=en&l-id=rhk_gheader_mno_internet_turbo_campaign_spu_01)
        
    *   [Previous Campaign Rules](https://network.mobile.rakuten.co.jp/hikari/campaign/archive/?wovn=en&l-id=rhk_gheader_campaign_archive_01)
        
    
*   Those Considering Switching
    
    *   [Steps to Get Started](https://network.mobile.rakuten.co.jp/hikari/flow/?wovn=en&l-id=rhk_gheader_flow_01)
        
    *   [Speedy and stable](https://network.mobile.rakuten.co.jp/hikari/internet/?wovn=en&l-id=rhk_gheader_internet_01)
        
    
*   News & Support
    
    *   [News](https://network.mobile.rakuten.co.jp/hikari/information/?wovn=en&l-id=rhk_gheader_information_01)
        
    *   [Customer Support](https://network.mobile.rakuten.co.jp/hikari/support/?wovn=en&l-id=rhk_gheader_support_01)
        
    

よく検索されるワード
----------

検索履歴
----

[Apply](https://secure3.gol.com/mod-pl/rbb/rmch.cgi?scode=qngTI9rXJpRlc1l6roM&cpnkind=set2512h8&l-id=rhk_gmenu_onb&ratck=Rp%3Dundefined)
 ​ ​[Member page](https://ms.fusioncom.co.jp/rbb/members/login?campaign=web-rakuten&l-id=rhk_gmenu_ecare&_ebx=g1rjgkpzt4.1693291119.7s1i0ki)

*   Price
    
*   Campaigns
    
*   Those Considering Switching
    
*   News & Support
    
*   Language
    

[See Rakuten Turbo](https://network.mobile.rakuten.co.jp/internet/turbo/?wovn=en&l-id=rhk_gmenu_mno_internet_turbo_01)

[See Rakuten Mobile](https://network.mobile.rakuten.co.jp/?wovn=en&l-id=rhk_gmenu_mno_03)

Price

*   [Price simulation](https://network.mobile.rakuten.co.jp/hikari/fee/simulation/?wovn=en&l-id=rhk_gmenu_fee_simulation_01)
    
*   [Price](https://network.mobile.rakuten.co.jp/hikari/fee/pricelist/?wovn=en&l-id=rhk_gmenu_fee_pricelist_01)
    

Campaign

*   [Rakuten Hikari SAIKYO HOME Program](https://network.mobile.rakuten.co.jp/hikari/campaign/home-internet/?wovn=en&l-id=rhk_gmenu_campaign_home-internet_01)
    
*   [SPU (Super Point Up Program)](https://network.mobile.rakuten.co.jp/internet/turbo/campaign/spu/?wovn=en&l-id=rhk_gmenu_mno_internet_turbo_campaign_spu_01)
    
*   [Previous Campaign Rules](https://network.mobile.rakuten.co.jp/hikari/campaign/archive/?wovn=en&l-id=rhk_gmenu_campaign_archive_01)
    

Those Considering Switching

*   [Steps to Get Started](https://network.mobile.rakuten.co.jp/hikari/flow/?wovn=en&l-id=rhk_gmenu_flow_01)
    
*   [Speedy and stable](https://network.mobile.rakuten.co.jp/hikari/internet/?wovn=en&l-id=rhk_gmenu_internet_01)
    

News & 

*   [News](https://network.mobile.rakuten.co.jp/hikari/information/?wovn=en&l-id=rhk_gmenu_information_01)
    
*   [Customer Support](https://network.mobile.rakuten.co.jp/hikari/support/?wovn=en&l-id=rhk_gmenu_support_01)
    

Language

*   日本語
    
*   English
    
*   简体中文
    
*   繁體中文
    
*   한국어
    
*   tiếng việt
    
*   Indonesia
    
*   português
    

Choose your language for Rakuten Mobile !
-----------------------------------------

Our services are provided within the region and laws of Japan.

日本語 English 简体中文 繁體中文 한국어 tiếng việt Indonesia português

Select Language

Our services are provided within the region and laws of Japan and we provide translations for your convenience.  
The Japanese version of our websites and applications, in which include Rakuten Membership Rules, Privacy Policy or other terms and conditions, is the definitive version , unless otherwise indicated.  
If there are any discrepancies, the Japanese version shall prevail.  
We do not guarantee that we always provide translation.  
The Japanese versions of all terms and conditions, policies, and other notices are the definitive versions. Any dispute related to the terms and conditions, policies, or other notices will be under the jurisdiction of Japanese law, regardless of any conflicting laws or principles.  
Certain features or messages (including customer services) may not be available in the selected language.

Enjoy Rakuten Mobile in English!
--------------------------------

Our services are provided within the region and laws of Japan and we provide translations for your convenience.  
The Japanese version of our websites and applications, in which include Rakuten Membership Rules, Privacy Policy or other terms and conditions, is the definitive version , unless otherwise indicated.  
If there are any discrepancies, the Japanese version shall prevail.  
We do not guarantee that we always provide translation.  
The Japanese versions of all terms and conditions, policies, and other notices are the definitive versions. Any dispute related to the terms and conditions, policies, or other notices will be under the jurisdiction of Japanese law, regardless of any conflicting laws or principles.  
Certain features or messages (including customer services) may not be available in the selected language.

 ![High-speed & stable optical line! Monthly basic fee ¥3,800~[¥4,180 incl. tax]* Entry required Use with Rakuten Mobile to earn 7× Points on Rakuten Ichiba shopping for everyone, every day.*](https://network.mobile.rakuten.co.jp/assets/en/img/hikari/top/kv-pc-250730.png)

\*1 Apartment Plan ¥3,800 (¥4,180 incl. tax) / Family Plan ¥4,800 (¥5,280 incl. tax). \*2 1× for Rakuten membership, +2× for Rakuten Turbo or Rakuten Hikari contract. +4× for Rakuten Mobile usage (not applicable to Super Hodai, Combination Plan, or Comi Comi Plan). SPU (Super Point Up) requires entry.

News

October 3, 2025

[Notice of VDSL Service Termination and Transition to Optical Wiring](https://network.mobile.rakuten.co.jp/hikari/information/2025/1003_01/?wovn=en)

Great deals   
Now in progress!
-------------------------------

 [![Rakuten Hikari Internet and smartphone bundled for great savings! First time Hikari subscribers + Rakuten Mobile point rebates every month for life. * Time-limited points. Conditions apply.](https://network.mobile.rakuten.co.jp/assets/en/img/hikari/bnr/bnr-set-plan-hikari-1032-160-20250730.png)](https://network.mobile.rakuten.co.jp/hikari/campaign/home-internet/?wovn=en&l-id=rhk_hikari_hikari_campaign_home-internet_01)

High-speed & stable fiber optic line
====================================

Comfortable Anytime
-------------------

![](https://network.mobile.rakuten.co.jp/assets/img/hikari/top/kaiteki.png)

Speedy performance, even during peak hours  
like lunchtime and evening!

Comfortable Anywhere
--------------------

![](https://network.mobile.rakuten.co.jp/assets/img/hikari/top/dokodemo.png)

Smooth connectivity  
even in densely populated areas!

Stable communication
--------------------

![](https://network.mobile.rakuten.co.jp/assets/img/hikari/top/antei.png)

Binge-watching your favorite dramas?  
No interruptions!

Unlimited high-speed data
-------------------------

![](https://network.mobile.rakuten.co.jp/assets/img/hikari/top/tukaihoudai.png)

No need to worry about your data usage!  
​

[Learn More About Our High-Speed, Stable Fiber Optic Line](https://network.mobile.rakuten.co.jp/hikari/internet/?wovn=en&l-id=rhk_internet_01)

Monthly basic fee
-----------------

Apartment Plan (Multi-unit building)

![](https://network.mobile.rakuten.co.jp/assets/img/hikari/top/icon-apartment.svg)

3,800​ ​yen​ ​(incl. tax 4,180 yen)

Family Plan (House)

![](https://network.mobile.rakuten.co.jp/assets/img/hikari/top/icon-house.svg)

4,800​ ​yen​ ​(incl. tax 5,280 yen)

[See Details of Fees](https://network.mobile.rakuten.co.jp/hikari/fee/pricelist/?wovn=en&l-id=rhk_fee_pricelist_02)

[Price simulation](https://network.mobile.rakuten.co.jp/hikari/fee/simulation/?wovn=en&l-id=rhk_fee_simulation_01)

### Get More Value from  
Rakuten Hikari!

*   Value
    
    1
    
    ![SAIKYO HOME Program](https://network.mobile.rakuten.co.jp/assets/en/img/internet/turbo/inc/img-saikyo-ouchi-program-logo.png)
    
    Apply for Rakuten Hikari for the first time  
    \+ Use Rakuten Mobile
    
     ![1,000 point rebates every month for life](https://network.mobile.rakuten.co.jp/assets/en/img/internet/turbo/inc/img-point-rebate-pc.png)
    
    ※The 1,000 points awarded are valid for 6 months from the date of point award.  
    For details about Time-limited points, [click here](https://ichiba.faq.rakuten.net/detail/000006532?_ebx=t968irdq8c.1703661888.7zrpf2u)
     .
    
    [Learn More About SAIKYO HOME Program](https://network.mobile.rakuten.co.jp/hikari/campaign/home-internet/?wovn=en&l-id=rhk_campaign_home-internet_ouchi-program02)
    
*   Value
    
    2
    
    Campaign for 0 yen Construction Cost​
    
    Construction costs up to 22,000 yen
    
    Up to 916 yen/mo. for 24 installments  
    Earn points every month for 24 months
    
    Effective 0 yen
    
    [Learn More About the Campaign](https://network.mobile.rakuten.co.jp/hikari/campaign/home-internet/#anc02?wovn=en&l-id=rhk_campaign_home-internet_#anc02_hikari-cpn)
    

*   ※Points are awarded around the end of the second month after the month in which usage of "Rakuten Hikari" and "Rakuten SAIKYO Plan", "Rakuten SAIKYO Plan (Data Type)" or "Rakuten SAIKYO U-NEXT" is confirmed.
*   ※The installation cost may exceed 22,000 yen due to additional expenses for residential equipment conditions, time specifications, etc.
*   \*The "effective price" is the price that includes discounts and Point, and is different from the actual payment amount.
*   ※If you cancel your subscription during the point-earning period, the remaining points will not be awarded.
*   ※The first month is the month of Rakuten Hikari activation (line switch completed). The points are awarded in 24 installments starting from the end of the 3rd month. Full points are refunded in the 26th month after activation (932 points awarded in the first month only).

At Rakuten Ichiba  
Great savings on your shopping too!

 ![Entry required Use Rakuten Hikari and Rakuten Mobile together to earn 7× Points every day for all members. Rakuten members earn 1× Point by default, plus 2× Points for using Rakuten Hikari and 4× Points for using Rakuten Mobile.](https://network.mobile.rakuten.co.jp/assets/en/img/hikari/inc/i-spu-intro/spu-hikari-pc.png)

＼ Click here to enter ／

[Learn More About SPU](https://network.mobile.rakuten.co.jp/internet/turbo/campaign/spu/?wovn=en&tab-list=tab-menu2&l-id=rhk_mno_internet_turbo_campaign_spu_01)

\*1x points for Rakuten member, +2x points for Rakuten Hikari users. +4x points for Rakuten Mobile users (Super Hodai, Combination Plan, and Comi Comi Plan are not applicable) \* Rakuten Hikari does not qualify for benefits if you only have a contract with Rakuten Broadband as your provider.  
\*The monthly maximum points that can be earned are 1,000 points for Rakuten Hikari and 2,000 points for Rakuten Mobile. Both are Time-limited points. [For details click here](https://event.rakuten.co.jp/campaign/point-up/everyday/point/)

Steps to Get Started
--------------------

![](https://network.mobile.rakuten.co.jp/assets/img/hikari/top/sp-regist.png)

STEP1

Apply Now

![](https://network.mobile.rakuten.co.jp/assets/img/hikari/top/mail.png)

STEP2

Notice of Your Service Start Date

![](https://network.mobile.rakuten.co.jp/assets/img/hikari/top/routerprep.png)

STEP3

Router preparation

![](https://network.mobile.rakuten.co.jp/assets/img/hikari/top/setting.png)

STEP4

Activation work

![](https://network.mobile.rakuten.co.jp/assets/img/hikari/top/router.png)

Step 5

Set up and start using

※The process may vary depending on your usage situation and environment.

[See How to Start Using Rakuten Mobile in Detail](https://network.mobile.rakuten.co.jp/hikari/flow/?wovn=en&l-id=rhk_flow_inc-02)

[Check if your router is IPv6(Xpass) compatible](https://network.mobile.rakuten.co.jp/hikari/support/wifi-router/?wovn=en&l-id=rhk_support_wifi-router_inc-03)

Rakuten Hikari Service Area
---------------------------

Rakuten Hikari is available in areas where NTT East and NTT West FLET'S HIKARI lines are provided.  
Please check the available areas on the NTT FLET'S HIKARI 'S Hikari website.

![Japan map](https://network.mobile.rakuten.co.jp/assets/img/hikari/top/img-map.png)

NTT East

Hokkaido, Aomori, Iwate, Miyagi, Akita, Yamagata, Fukushima, Ibaraki, Tochigi, Gunma, Saitama, Chiba, Tokyo, Kanagawa, Niigata, Yamanashi, Nagano, Shizuoka (part of Atami and Susono)

[Check the NTT East FLET'S HIKARI service area](https://flets.com/flets-hikari/application/sim/)

NTT West

Toyama, Ishikawa, Fukui, Gifu, Shizuoka (excluding parts of Atami and Susono), Aichi, Mie, Shiga, Kyoto, Osaka, Hyogo, Nara, Wakayama, Tottori, Shimane, Okayama, Hiroshima, Yamaguchi, Tokushima, Kagawa, Ehime, Kochi, Fukuoka, Saga, Nagasaki, Kumamoto, Oita, Miyazaki, Kagoshima, Okinawa

[Check the NTT West FLET'S HIKARI service area](https://flets-w.com/area/)

Customer Support
----------------

![](https://network.mobile.rakuten.co.jp/assets/img/hikari/top/icon-support.png)

### Tailored to your needs  
Various types of support

[See Customer Support](https://network.mobile.rakuten.co.jp/hikari/support/?wovn=en&l-id=rhk_support_01)

![](https://network.mobile.rakuten.co.jp/assets/img/hikari/top/icon-setting2.png)

### Check plan & contract info,  
settings changes

[Login to the Members Page](https://ms.fusioncom.co.jp/rbb/members/login?campaign=web-rakuten&_ebx=6zl8wjjwg.1633393105.7lkfe8n/&l-id=rhk_ecare_01)

Both Rakuten Turbo and Hikari offer great deals!
------------------------------------------------

[![Join Rakuten Turbo & use Rakuten Mobile for a lifetime of 1,000 point rebates monthly※Time-limited points. Conditions apply.](https://network.mobile.rakuten.co.jp/assets/en/img/hikari/bnr/bnr-set-plan-turbo-328-185-20250730.png)](https://network.mobile.rakuten.co.jp/internet/turbo/campaign/home-internet/?wovn=en&l-id=rhk_hikari_internet_turbo_campaign_home-internet_02)

[![Get 1,000 point rebates every month for life when you apply for Rakuten Hikari for the first time & use Rakuten Mobile.※Time-limited points. Conditions apply.](https://network.mobile.rakuten.co.jp/assets/en/img/hikari/bnr/bnr-set-plan-hikari-328-185-20250730.png)](https://network.mobile.rakuten.co.jp/hikari/campaign/home-internet/?wovn=en&l-id=rhk_hikari_hikari_campaign_home-internet_02)

#### Rakuten Group Recommended Information

[![Rakuten Bank](https://network.mobile.rakuten.co.jp/assets/img/hikari/campaign/one-year-free/oneyear-banner-03.png)](https://www.rakuten-bank.co.jp/account/campaign/payment1000.html?scid=wi_rmb_hikari_cpn_footer)

[![Rakuten SEIYU Online Supermarket](https://network.mobile.rakuten.co.jp/assets/img/hikari/campaign/one-year-free/oneyear-banner-04.jpg)](https://sm.rakuten.co.jp/?scid=wi_rhk_mobile&xadid=wi_rhk_mobile)

[![Rakuten TV](https://network.mobile.rakuten.co.jp/assets/img/hikari/campaign/one-year-free/oneyear-banner-05.jpg)](https://tv.rakuten.co.jp/?scid=wi_rtv_rhikari_20220622)

[![Rakuten Card](https://network.mobile.rakuten.co.jp/assets/img/hikari/campaign/one-year-free/oneyear-banner-07-220921.gif)](https://ad2.trafficgate.net/t/r/13296/1441/99636_99636/)

[![Rakuten Insurance Referral Campaign](https://network.mobile.rakuten.co.jp/assets/img/hikari/campaign/one-year-free/oneyear-banner-08.png)](https://www.rakuten-insurance.co.jp/event/mgm/?scid=wi_hikari_2207_mgm&argument=bdhoDoBc&dmai=a62c65d0dd5b97)

[![Rakuten Books](https://network.mobile.rakuten.co.jp/assets/img/hikari/campaign/one-year-free/oneyear-banner-01.png)](https://books.rakuten.co.jp/)

[![More exclusive perks for Rakuten Mobile customers!](https://network.mobile.rakuten.co.jp/assets/img/hikari/bnr/tokuten_info_204-204_20241122.png)](https://service.link.link/lp/otoku/campaign.html?scid=wi_link_otoku_hikari)

[![Rakuten Super Mini Byte](https://network.mobile.rakuten.co.jp/assets/img/hikari/campaign/one-year-free/oneyear-banner-02.png)](https://minijob.rakuten.co.jp/?scid=wi_hikari_barter_pc&utm_source=hikari&utm_medium=banner&utm_campaign=barter)

[![Rakuten Bank](https://network.mobile.rakuten.co.jp/assets/img/hikari/campaign/one-year-free/oneyear-banner-03.png)](https://www.rakuten-bank.co.jp/account/campaign/payment1000.html?scid=wi_rmb_hikari_cpn_footer)

[![Rakuten SEIYU Online Supermarket](https://network.mobile.rakuten.co.jp/assets/img/hikari/campaign/one-year-free/oneyear-banner-04.jpg)](https://sm.rakuten.co.jp/?scid=wi_rhk_mobile&xadid=wi_rhk_mobile)

[![Rakuten TV](https://network.mobile.rakuten.co.jp/assets/img/hikari/campaign/one-year-free/oneyear-banner-05.jpg)](https://tv.rakuten.co.jp/?scid=wi_rtv_rhikari_20220622)

[![Rakuten Card](https://network.mobile.rakuten.co.jp/assets/img/hikari/campaign/one-year-free/oneyear-banner-07-220921.gif)](https://ad2.trafficgate.net/t/r/13296/1441/99636_99636/)

[![Rakuten Insurance Referral Campaign](https://network.mobile.rakuten.co.jp/assets/img/hikari/campaign/one-year-free/oneyear-banner-08.png)](https://www.rakuten-insurance.co.jp/event/mgm/?scid=wi_hikari_2207_mgm&argument=bdhoDoBc&dmai=a62c65d0dd5b97)

[![Rakuten Books](https://network.mobile.rakuten.co.jp/assets/img/hikari/campaign/one-year-free/oneyear-banner-01.png)](https://books.rakuten.co.jp/)

[![More exclusive perks for Rakuten Mobile customers!](https://network.mobile.rakuten.co.jp/assets/img/hikari/bnr/tokuten_info_204-204_20241122.png)](https://service.link.link/lp/otoku/campaign.html?scid=wi_link_otoku_hikari)

[![Rakuten Super Mini Byte](https://network.mobile.rakuten.co.jp/assets/img/hikari/campaign/one-year-free/oneyear-banner-02.png)](https://minijob.rakuten.co.jp/?scid=wi_hikari_barter_pc&utm_source=hikari&utm_medium=banner&utm_campaign=barter)

[![Rakuten Bank](https://network.mobile.rakuten.co.jp/assets/img/hikari/campaign/one-year-free/oneyear-banner-03.png)](https://www.rakuten-bank.co.jp/account/campaign/payment1000.html?scid=wi_rmb_hikari_cpn_footer)

[![Rakuten SEIYU Online Supermarket](https://network.mobile.rakuten.co.jp/assets/img/hikari/campaign/one-year-free/oneyear-banner-04.jpg)](https://sm.rakuten.co.jp/?scid=wi_rhk_mobile&xadid=wi_rhk_mobile)

[![Rakuten TV](https://network.mobile.rakuten.co.jp/assets/img/hikari/campaign/one-year-free/oneyear-banner-05.jpg)](https://tv.rakuten.co.jp/?scid=wi_rtv_rhikari_20220622)

[![Rakuten Card](https://network.mobile.rakuten.co.jp/assets/img/hikari/campaign/one-year-free/oneyear-banner-07-220921.gif)](https://ad2.trafficgate.net/t/r/13296/1441/99636_99636/)

[![Rakuten Insurance Referral Campaign](https://network.mobile.rakuten.co.jp/assets/img/hikari/campaign/one-year-free/oneyear-banner-08.png)](https://www.rakuten-insurance.co.jp/event/mgm/?scid=wi_hikari_2207_mgm&argument=bdhoDoBc&dmai=a62c65d0dd5b97)

PreviousNext

*   1
*   2
*   3
*   4
*   5
*   6
*   7
*   8

### Learn More About Rakuten Hikari

[![](https://network.mobile.rakuten.co.jp/assets/img/hikari/common-v2/footer-simulation.png)\
\
Price simulation](https://network.mobile.rakuten.co.jp/hikari/fee/simulation/?wovn=en&l-id=rhk_footer_fee_simulation_01)
[![](https://network.mobile.rakuten.co.jp/assets/img/hikari/common-v2/footer-speed.png)\
\
Speedy and stable  \
IPv6 communication](https://network.mobile.rakuten.co.jp/hikari/internet/?wovn=en&l-id=rhk_footer_internet_01)
[![](https://network.mobile.rakuten.co.jp/assets/img/hikari/common-v2/footer-flow.png)\
\
Steps to Get Started  \
​](https://network.mobile.rakuten.co.jp/hikari/flow/?wovn=en&l-id=rhk_footer_flow_01)
[![](https://network.mobile.rakuten.co.jp/assets/img/hikari/common-v2/footer-support.png)\
\
Customer Support](https://network.mobile.rakuten.co.jp/hikari/support/?wovn=en&l-id=rhk_footer_support_01)

このページはわかりやすかったですか？

1

2

3

4

5

わかりづらかった

わかりやすかった

[![](https://network.mobile.rakuten.co.jp/assets/img/hikari/common-v2/backtop.svg)\
\
Back to top](https://network.mobile.rakuten.co.jp/hikari/#)

*   [Company Overview](https://corp.mobile.rakuten.co.jp/)
    
*   [Handling of Personal Information](https://corp.mobile.rakuten.co.jp/guide/privacy/)
    
*   [Handling of Information Sent to External Parties](https://network.mobile.rakuten.co.jp/optout/?wovn=en&l-id=rhk_footer_mno_optout_01)
    
*   [Information Security Policy](https://corp.mobile.rakuten.co.jp/guide/security/)
    
*   [Trademarks and Registered Trademarks](https://corp.mobile.rakuten.co.jp/guide/trademark/)
    
*   [Terms of Use & important notices](https://network.mobile.rakuten.co.jp/hikari/terms/?wovn=en&l-id=rhk_footer_terms_01)
    
*   [Rakuten Group Customer Harassment Response Policy](https://corp.rakuten.co.jp/sustainability/human-rights/customer-harassment/)
    

© Rakuten Mobile, Inc.

[![Rakuten Mobile](https://cdn.rmc.contents.rakuten.co.jp/block/d40535ac09aac0ef32f8a23b8bb8e04bc2e8f9d6b0981fa98a16d0382f558d83/d72cbeb1-1b70-4fb2-b7e5-cb3c0a24841f/card20k_enddate_pc_1440x50.png)](https://cdn.rex.contents.rakuten.co.jp/webcx-redirect-module/1.3.0/index.html?clientId=d40535ac09aac0ef32f8a23b8bb8e04bc2e8f9d6b0981fa98a16d0382f558d83&version=2.73.0&sessionId=677877e7-e546-4d8f-8de4-ac09813547d1&screen=WB&issueId=F01184-001256&campaignId=2aadf4f2-55c7-4337-8472-22f617277367&contentId=4382487a-283f-4306-b0d1-11d8c70206b1&replacementId=81db9e56-ef96-4d72-a17a-b0e4899e9bca&impressionId=03aef761-ebc1-42fb-8b13-ec983012fb78&selector=mkdiv_footer_pitari&redirect=aHR0cHM6Ly9yZC5yYWt1dGVuLmNvLmpwL3JhdD9SMj1odHRwczovL25ldHdvcmsubW9iaWxlLnJha3V0ZW4uY28uanAvY2FtcGFpZ24vY2FyZC1tb2JpbGUtbWFqaXRva3UvJTNGc2NpZCUzRHdpX3JtYl9ybWJfbWtkaXZfZm9vdGVyX3BpdGFyaV9jbW9fc3BfbmV3LWNhcmQtbm8td2ViY3hfY2FyZC1tb2JpbGUtbWFqaXRva3VfMjAyNTEyMDEmYWNjPTEzMTImYWlkPTEmZXR5cGU9Y2xpY2smc3NjPWNyb3NzdXNlX2NhbXBhaWduJnBnbj1jbW9fcGl0YXJpJnJlZj1odHRwczovL25ldHdvcmsubW9iaWxlLnJha3V0ZW4uY28uanAvaGlrYXJpLyZ0YXJnZXRfZWxlPW5ldy1jYXJkLW5vLXdlYmN4X2NhcmQtbW9iaWxlLW1haml0b2t1XzIwMjUxMjAx&origin=aHR0cHM6Ly9uZXR3b3JrLm1vYmlsZS5yYWt1dGVuLmNvLmpw)

*   Rakuten Group
*   [Services](https://www.rakuten.co.jp/sitemap/)
    
*   [Contact (us, form, etc..) list](https://www.rakuten.co.jp/sitemap/inquiry.html)
    
*   [SUSTAINABILITY](https://corp.rakuten.co.jp/sustainability/)
    

[Apply for Rakuten Hikari](https://secure3.gol.com/mod-pl/rbb/rmch.cgi?scode=qngTI9rXJpRlc1l6roM&cpnkind=set2512h8&l-id=rhk_fixedbtn_onb_01&ratck=Rp%3Dundefined)

  

日本語

English
