# Service information | J:COM

URL: https://www.jcom.co.jp/service/

---

[![あたらしいを、あたりまえに。 J:COM](https://www.jcom.co.jp/common_v10/images/logo-jcom-white.svg)](https://www.jcom.co.jp/en/?sc_pid=common_jcomlogo_01)

*   [Why J:COM](https://www.jcom.co.jp/en/beginner/?sc_pid=globalnavi_beginner_01)
    
*   Current customers
*   [Online Shop](https://onlineshop.jcom.co.jp/?sc_pid=globalnavi_ols_01)
    

J:COM Customers

[Check/Update Contract  \
My page login](https://mypage.jcom.co.jp/?sc_pid=common_mypage_01)
 [Troubleshooting/FAQ  \
Customer Support](https://cs.myjcom.jp/?sc_pid=common_suppot_01)
 [Enjoy J:COM even more  \
TV program information/presents and benefits  \
Fun! J:COM](https://www.myjcom.jp/?sc_pid=common_myj_01)

    ![検索](https://www.jcom.co.jp/common_v10/images/snav-icn-search-submit.svg)

*   [To you  \
    notice](https://id.zaq.ne.jp/id/script/connect/authz_req/endpoint.seam?response_type=code&client_id=JCOM_COJP&redirect_uri=https%3A%2F%2Fwww.jcom.co.jp%2Fservice%2F&scope=http%3A%2F%2Fjcom.co.jp%2Fconnect%2Fprofile%2Fstandard_new&nonce=906133269&state=&prompt=)
    
*   [To you  \
    notice](https://www.jcom.co.jp/service/#)
    

Language

*   日本語
*   English
*   简体中文
*   한국어
*   Tiếng Việt
*   Português

*   Services
*   [Pricing](https://www.jcom.co.jp/en/price/)
    
*   [Promotions  \
    ​](https://www.jcom.co.jp/en/campaign/)
    
*   Sign Up /  
    Edit Account Info
*   Support
*   Company website

[Service Overview](https://www.jcom.co.jp/en/service/)

[TV,](https://www.jcom.co.jp/en/service/tv/)
 ​ ​[internet,](https://www.jcom.co.jp/en/service/net/)
 ​ ​[smartphone](https://www.jcom.co.jp/en/service/mobile/)
 [, electricity](https://www.jcom.co.jp/en/service/electricity/)
 ​ ​[Landline](https://www.jcom.co.jp/en/service/phone/)
 , [gas](https://www.jcom.co.jp/en/service/gas/)
 [,](https://www.jcom.co.jp/en/service/ssi/)
 insurance, [loan](https://www.jcom-financial.co.jp/)
 [, security camera,](https://www.jcom.co.jp/en/guide/starter/home_security/)
 ​ ​[Telemedicine](https://www.jcom.co.jp/en/service/telemedicine/)
 [, services for corporations and local governments![J:COM BUSINESS](https://www.jcom.co.jp/common_v10/images/logo_jcombusiness.webp)](https://business.jcom.co.jp/)

[Sign Up / Inquiries](https://www.jcom.co.jp/en/contactus/)

New customers

[New customers  \
Sign Up](https://onlineshop.jcom.co.jp/planSelect)

[New customers  \
Inquiries](https://www.jcom.co.jp/en/contactus/#entry)

J:COM Customers

[User  \
Various procedures](https://r.jcom.jp/eG4nLSC)

[Problems and inquiries  \
(chat)](https://prod8-live-chat.sprinklr.com/page?appId=67af27d73657336d345e4a96_app_9070639&did=CHAT_vivr_cojp_top&enableClose=true&skin=MODERN&userContext__c_679c8b53cb85b007fab0f6ea=DirectLink&utm_campaign=IVRSMS&utm_medium=referral&utm_source=did&webview=true&zoom=false)

Find the perfect plan for you

[Savings calculator](https://onlineshop.jcom.co.jp/Simulation/Simulation)

Some properties offer free or discounted options!

Covered areas & properties

[Company website](https://www.jcom.co.jp/en/corporate/)

[Corporate philosophy](https://www.jcom.co.jp/en/corporate/philosophy_brand/)

[Sustainability](https://www.jcom.co.jp/en/corporate/sustainability/)

[Medium-term management plan](https://www.jcom.co.jp/en/corporate/managementplan/)

[news release](https://newsreleases.jcom.co.jp/)

[Company Profile](https://www.jcom.co.jp/en/corporate/company/)

[Careers](https://recruit.jcom.co.jp/)

[Support Top](https://cs.myjcom.jp/)

[TV,](https://cs.myjcom.jp/categories/support/67ab976bf07f5244a208cb97)
 ​ ​[Internet,](https://cs.myjcom.jp/categories/support/67ab9788f07f5244a208cced)
 ​ ​[Smartphone](https://cs.myjcom.jp/categories/support/67ab979df07f5244a208cdc9)
 [, Electricity](https://cs.myjcom.jp/categories/support/67ab97b5f07f5244a208cec9)
 ​ ​[Landline](https://cs.myjcom.jp/categories/support/67ab97abf07f5244a208ce4e)
 [, Gas](https://cs.myjcom.jp/categories/support/67ab97b8f07f5244a208ceda)
 [, Insurance](https://cs.myjcom.jp/categories/support/67ab97c5f07f5244a208cf2f)
 ​ ​[Telemedicine](https://cs.myjcom.jp/categories/support/67ab97c2f07f5244a208cf1b)
 ​ ​[Home, IoT](https://cs.myjcom.jp/categories/support/67ab97bcf07f5244a208cee6)
 ​ ​[Security Camera](https://cs.myjcom.jp/categories/support/67ab97f5f07f5244a208d09b)

[J:COM STREAM](https://cs.myjcom.jp/categories/support/67ab97c9f07f5244a208cf49)

[Enkaku Support](https://cs.myjcom.jp/categories/support/67ab97faf07f5244a208d0c2)

[Home support](https://cs.myjcom.jp/categories/support/67ab97d4f07f5244a208cf92)

[Disaster prevention information service](https://cs.myjcom.jp/categories/support/67ab97d8f07f5244a208cfa0)

[Bicycle Life Support](https://cs.myjcom.jp/categories/support/67ab97e8f07f5244a208d023)

[J:COM Books](https://cs.myjcom.jp/categories/support/67ab97e4f07f5244a208d003)

[WiMAX](https://cs.myjcom.jp/categories/support/67ab97f1f07f5244a208d074)

[Trouble/maintenance information](https://information.myjcom.jp/maintenance_outage/)

Various procedures

[Personal ID](https://cs.myjcom.jp/categories/support/67ab9803f07f5244a208d113)

[Fees and Payment](https://cs.myjcom.jp/categories/support/67ab9805f07f5244a208d139)

[Moving and rebuilding](https://cs.myjcom.jp/categories/support/67ab980cf07f5244a208d184)

[Visits and counters](https://cs.myjcom.jp/categories/support/67ab980ff07f5244a208d1a4)

[Contract-related](https://cs.myjcom.jp/categories/support/67ab9806f07f5244a208d150)

[Suspension/cancellation](https://cs.myjcom.jp/categories/support/67ab980cf07f5244a208d188)

[Membership Benefits](https://cs.myjcom.jp/categories/support/67ab980df07f5244a208d18c)

[![あたらしいを、あたりまえに J:COM](https://www.jcom.co.jp/common_v10/images/logo-jcom-white.svg)](https://www.jcom.co.jp/en/?sc_pid=common_jcomlogo_01)

[![あたらしいを、あたりまえに J:COM](https://www.jcom.co.jp/common_v10/images/logo-jcom.svg)](https://www.jcom.co.jp/en/)

*   Services
*   [Pricing](https://www.jcom.co.jp/en/price/)
    
*   [Promotions  \
    ​](https://www.jcom.co.jp/en/campaign/)
    
*   Sign Up /  
    Edit Account Info
*   Support
*   Company website

![検索する](https://www.jcom.co.jp/common_v10/images/fixed-nav-icn-search.svg)

    ![検索](https://www.jcom.co.jp/common_v10/images/snav-icn-search-submit.svg)

[Service Overview](https://www.jcom.co.jp/en/service/)

[TV,](https://www.jcom.co.jp/en/service/tv/)
 ​ ​[internet,](https://www.jcom.co.jp/en/service/net/)
 ​ ​[smartphone](https://www.jcom.co.jp/en/service/mobile/)
 [, electricity](https://www.jcom.co.jp/en/service/electricity/)
 ​ ​[Landline](https://www.jcom.co.jp/en/service/phone/)
 , [gas](https://www.jcom.co.jp/en/service/gas/)
 [,](https://www.jcom.co.jp/en/service/ssi/)
 insurance, [loan](https://www.jcom-financial.co.jp/)
 [, security camera,](https://www.jcom.co.jp/en/guide/starter/home_security/)
 ​ ​[Telemedicine](https://www.jcom.co.jp/en/service/telemedicine/)
 [, services for corporations and local governments![J:COM BUSINESS](https://www.jcom.co.jp/common_v10/images/logo_jcombusiness.webp)](https://business.jcom.co.jp/)

[Sign Up / Inquiries](https://www.jcom.co.jp/en/contactus/)

New customers

[New customers  \
Sign Up](https://onlineshop.jcom.co.jp/planSelect)

[New customers  \
Inquiries](https://www.jcom.co.jp/en/contactus/#entry)

J:COM Customers

[User  \
Various procedures](https://r.jcom.jp/eG4nLSC)

[Problems and inquiries  \
(chat)](https://prod8-live-chat.sprinklr.com/page?appId=67af27d73657336d345e4a96_app_9070639&did=CHAT_vivr_cojp_top&enableClose=true&skin=MODERN&userContext__c_679c8b53cb85b007fab0f6ea=DirectLink&utm_campaign=IVRSMS&utm_medium=referral&utm_source=did&webview=true&zoom=false)

Find the perfect plan for you

[Savings calculator](https://onlineshop.jcom.co.jp/Simulation/Simulation)

Some properties offer free or discounted options!

Covered areas & properties

[Company website](https://www.jcom.co.jp/en/corporate/)

[Corporate philosophy](https://www.jcom.co.jp/en/corporate/philosophy_brand/)

[Sustainability](https://www.jcom.co.jp/en/corporate/sustainability/)

[Medium-term management plan](https://www.jcom.co.jp/en/corporate/managementplan/)

[news release](https://newsreleases.jcom.co.jp/)

[Company Profile](https://www.jcom.co.jp/en/corporate/company/)

[Careers](https://recruit.jcom.co.jp/)

[Support Top](https://cs.myjcom.jp/)

[TV,](https://cs.myjcom.jp/categories/support/67ab976bf07f5244a208cb97)
 ​ ​[Internet,](https://cs.myjcom.jp/categories/support/67ab9788f07f5244a208cced)
 ​ ​[Smartphone](https://cs.myjcom.jp/categories/support/67ab979df07f5244a208cdc9)
 [, Electricity](https://cs.myjcom.jp/categories/support/67ab97b5f07f5244a208cec9)
 ​ ​[Landline](https://cs.myjcom.jp/categories/support/67ab97abf07f5244a208ce4e)
 [, Gas](https://cs.myjcom.jp/categories/support/67ab97b8f07f5244a208ceda)
 [, Insurance](https://cs.myjcom.jp/categories/support/67ab97c5f07f5244a208cf2f)
 ​ ​[Telemedicine](https://cs.myjcom.jp/categories/support/67ab97c2f07f5244a208cf1b)
 ​ ​[Home, IoT](https://cs.myjcom.jp/categories/support/67ab97bcf07f5244a208cee6)
 ​ ​[Security Camera](https://cs.myjcom.jp/categories/support/67ab97f5f07f5244a208d09b)

[J:COM STREAM](https://cs.myjcom.jp/categories/support/67ab97c9f07f5244a208cf49)

[Enkaku Support](https://cs.myjcom.jp/categories/support/67ab97faf07f5244a208d0c2)

[Home support](https://cs.myjcom.jp/categories/support/67ab97d4f07f5244a208cf92)

[Disaster prevention information service](https://cs.myjcom.jp/categories/support/67ab97d8f07f5244a208cfa0)

[Bicycle Life Support](https://cs.myjcom.jp/categories/support/67ab97e8f07f5244a208d023)

[J:COM Books](https://cs.myjcom.jp/categories/support/67ab97e4f07f5244a208d003)

[WiMAX](https://cs.myjcom.jp/categories/support/67ab97f1f07f5244a208d074)

[Trouble/maintenance information](https://information.myjcom.jp/maintenance_outage/)

Various procedures

[Personal ID](https://cs.myjcom.jp/categories/support/67ab9803f07f5244a208d113)

[Fees and Payment](https://cs.myjcom.jp/categories/support/67ab9805f07f5244a208d139)

[Moving and rebuilding](https://cs.myjcom.jp/categories/support/67ab980cf07f5244a208d184)

[Visits and counters](https://cs.myjcom.jp/categories/support/67ab980ff07f5244a208d1a4)

[Contract-related](https://cs.myjcom.jp/categories/support/67ab9806f07f5244a208d150)

[Suspension/cancellation](https://cs.myjcom.jp/categories/support/67ab980cf07f5244a208d188)

[Membership Benefits](https://cs.myjcom.jp/categories/support/67ab980df07f5244a208d18c)

*   ![メニュー](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/text-menu.svg)
*   ![お申し込み](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/text-entry.svg)
*   ![テレビ](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/text-jcom-tv.svg)
*   ![ネット](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/text-jcom-net.svg)
*   ![スマホ](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/text-jcom-mobile.svg)
*   ![電気](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/text-jcom-electricity.svg)
*   ![その他のサービス](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/text-other.svg)
*   [![Support](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/text-support.svg)](https://cs.myjcom.jp/)
    

*   [![あたらしいを、あたりまえに　J:COM](https://www.jcom.co.jp/common_v10/images/logo-jcom-only-white.svg)](https://www.jcom.co.jp/en/)
     ![メニューを閉じる](https://www.jcom.co.jp/common_v10/images/sp-menu/menu-close-white.svg)
    
    [J:COM Services](https://www.jcom.co.jp/en/service/)
    
    *   [![テレビ](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-tv-item.svg)](https://www.jcom.co.jp/en/service/tv/)
        
    *   [![ネット](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-net-item.svg)](https://www.jcom.co.jp/en/service/net/)
        
    *   [![スマホ](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-mobile-item.svg)](https://www.jcom.co.jp/en/service/mobile/)
        
    
    *   [![電気](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-electricity-item.svg)](https://www.jcom.co.jp/en/service/electricity/)
        
    *   [![Landline](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-phone-item.svg)](https://www.jcom.co.jp/en/service/phone/)
        
    *   [![Gas](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-gas-item.svg)](https://www.jcom.co.jp/en/service/gas/)
        
    *   [![insurance](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-ssi-item.svg)](https://www.jcom.co.jp/en/service/ssi/)
        
    *   [loan](https://www.jcom-financial.co.jp/)
        
    *   [![Home IoT Solutions](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-home-item.svg)](https://www.jcom.co.jp/en/service/home/)
        
    *   [security cameras](https://www.jcom.co.jp/en/guide/starter/home_security/)
        
    *   [![Telemedicine](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-telemedicine-item.svg)](https://www.jcom.co.jp/en/service/telemedicine/)
        
    
    [Services for corporations and local governments  \
    ![J:COM BUSINESS](https://www.jcom.co.jp/common_v10/images/logo_jcombusiness.webp)](https://business.jcom.co.jp/)
    
    Service overview
    
    [Price List](https://www.jcom.co.jp/en/price/)
     [Promotions/Benefits](https://www.jcom.co.jp/en/campaign/)
     [Support](https://cs.myjcom.jp/)
     [Application/Various Changes](https://www.jcom.co.jp/en/contactus/)
    
        ![検索](https://www.jcom.co.jp/common_v10/images/snav-icn-search-submit-sp.svg)
    
    [J:COM Top](https://www.jcom.co.jp/en/)
    
    *   [Service Information](https://www.jcom.co.jp/en/)
        
    *   [Online  \
        Shop](https://onlineshop.jcom.co.jp/)
        
    *   [Support](https://cs.myjcom.jp/)
        
    *   [Fun! J:COM](https://www.myjcom.jp/)
        
    *   [My page](https://mypage.jcom.co.jp/)
        
    *   [Company website](https://www.jcom.co.jp/en/corporate/)
        
    
*   [Sign Up / Inquiries](https://www.jcom.co.jp/en/contactus/)
     ![メニューを閉じる](https://www.jcom.co.jp/common_v10/images/sp-menu/menu-close.svg)
    
    New customers
    
    [New Customers Sign Up](https://onlineshop.jcom.co.jp/planSelect)
     [New Customers Inquiries](https://www.jcom.co.jp/en/contactus/#entry)
    
    Find the perfect  
    plan for you
    
    Some properties offer free  
    or discounted options!
    
    [Savings  \
     calculator](https://onlineshop.jcom.co.jp/Simulation/Simulation)
    
    [Covered  \
    areas & properties](https://www.jcom.co.jp/service/#)
    
    J:COM Customers
    
    [User  \
    Various procedures](https://r.jcom.jp/eG4nLSC)
    
    [Troubleshooting/  \
    Inquiries](https://prod8-live-chat.sprinklr.com/page?appId=67af27d73657336d345e4a96_app_9070639&did=CHAT_vivr_cojp_top&enableClose=true&skin=MODERN&userContext__c_679c8b53cb85b007fab0f6ea=DirectLink&utm_campaign=IVRSMS&utm_medium=referral&utm_source=did&webview=true&zoom=false)
    
*   [![J:COM TV](https://www.jcom.co.jp/common_v10/images/icn-jcom-tv.svg)TV](https://www.jcom.co.jp/en/service/tv/)
     ![メニューを閉じる](https://www.jcom.co.jp/common_v10/images/sp-menu/menu-close.svg)
    
    [![](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom-tv/slide/menu/mv-middle.webp)\
    \
    Showing you what you want\
    \
    Back to top](https://www.jcom.co.jp/en/service/tv/)
    
    *   Plans & Pricing
        
        *   [Plans & Pricing Overview](https://www.jcom.co.jp/en/service/tv/course/)
            
        *   [J:COM TV Shin Standard](https://www.jcom.co.jp/en/service/tv/course/standard.html)
            
        *   [J:COM TV Shin Standard Plus](https://www.jcom.co.jp/en/service/tv/course/standard_plus.html)
            
        *   [J:COM TV Select](https://www.jcom.co.jp/en/service/tv/course/select.html)
            
        
    *   Content lineup
        
        *   [Content Lineup Overview](https://www.jcom.co.jp/en/service/tv/channel/)
            
        *   [Channels](https://www.jcom.co.jp/en/service/tv/channel/list/)
            
        *   [Optional channels](https://www.jcom.co.jp/en/service/tv/channel/option_ch/)
            
        *   [Channels by plan](https://www.jcom.co.jp/en/service/tv/channel/comparison/)
            
        
    *   [Streaming services](https://www.jcom.co.jp/en/service/tv/smart/ott.html)
        
    *   [Helpful features](https://www.jcom.co.jp/en/service/tv/smart/)
        
    *   Options
        
        *   [Options Overview](https://www.jcom.co.jp/en/service/tv/accessories/)
            
        *   [J:COM Netflix Set](https://www.jcom.co.jp/en/guide/starter/netflix/)
            
        *   [External hard drive](https://www.jcom.co.jp/en/service/tv/accessories/hdd/)
            
        *   [J:COM LINK mini](https://www.jcom.co.jp/en/service/tv/accessories/linkmini/)
            
        
    *   [How to apply](https://www.jcom.co.jp/en/service/tv/guide/)
        
    
*   [![J:COM NET](https://www.jcom.co.jp/common_v10/images/icn-jcom-net.svg)Internet](https://www.jcom.co.jp/en/service/net/)
     ![メニューを閉じる](https://www.jcom.co.jp/common_v10/images/sp-menu/menu-close-white.svg)
    
    [![](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom-net/slide/menu/mv-middle.webp)\
    \
    Faster and more comfortable\
    \
    Back to top](https://www.jcom.co.jp/en/service/net/)
    
    *   [Plans & Pricing](https://www.jcom.co.jp/en/service/net/course/)
        
    *   Options
        
        *   [Options Overview](https://www.jcom.co.jp/en/service/net/option/)
            
        *   [Messhu Wi-Fi](https://www.jcom.co.jp/en/service/net/option/mesh-wi-fi/)
            
        *   [J:COM LINK mini](https://www.jcom.co.jp/en/service/net/option/linkmini/)
            
        
    *   [Support](https://www.jcom.co.jp/en/service/net/support/)
        
    *   [How to apply](https://www.jcom.co.jp/en/service/net/guide/)
        
    
*   [![J:COM MOBILE](https://www.jcom.co.jp/common_v10/images/icn-jcom-mobile.svg)Smartphone](https://www.jcom.co.jp/en/service/mobile/)
     ![メニューを閉じる](https://www.jcom.co.jp/common_v10/images/sp-menu/menu-close-white.svg)
    
    [![](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom-mobile/slide/menu/mv-middle.webp)\
    \
    Continuous savings\
    \
    Back to top](https://www.jcom.co.jp/en/service/mobile/)
    
    *   Pricing
        
        *   [Price Top](https://www.jcom.co.jp/en/service/mobile/price/)
            
        *   [Call charges/SMS service charges](https://www.jcom.co.jp/en/service/mobile/price/detail/)
            
        *   [Data Mori](https://www.jcom.co.jp/en/service/mobile/price/datamori/)
            
        *   [Kids plan](https://www.jcom.co.jp/en/service/mobile/price/kids/)
            
        *   [Seniors plan](https://www.jcom.co.jp/en/service/mobile/campaign/senior/)
            
        *   [About 5G](https://www.jcom.co.jp/en/service/mobile/special/5g/)
            
        *   [Termination of 3G service](https://www.jcom.co.jp/en/service/mobile/special/3g/)
            
        
    *   Products
        
        *   [Product Top](https://www.jcom.co.jp/en/service/mobile/device/)
            
        *   [iPhone 16e](https://www.jcom.co.jp/en/service/mobile/device/iphone_16e/)
            
        *   [iPhone 15](https://www.jcom.co.jp/en/service/mobile/device/iphone_15/)
            
        *   [Google Pixel 8a](https://www.jcom.co.jp/en/service/mobile/device/pixel_8a/)
            
        *   [AQUOS sense10](https://www.jcom.co.jp/en/service/mobile/device/aquos_sense10/)
            
        *   [Samsung Galaxy A25 5G](https://www.jcom.co.jp/en/service/mobile/device/galaxy_a25_5g/)
            
        *   [BASIO active2](https://www.jcom.co.jp/en/service/mobile/device/basio_active2/)
            
        
    *   SIM
        
        *   [Low-cost SIM Top](https://www.jcom.co.jp/en/service/mobile/device/sim/)
            
        *   [eSIM](https://www.jcom.co.jp/en/service/mobile/device/sim/esim/)
            
        *   [Details](https://www.jcom.co.jp/en/service/mobile/device/sim/detail/)
            
        *   [Device compatibility check](https://www.jcom.co.jp/service/mobile/device/sim/detail/device.html)
            
        *   [Unlocking SIM Cards](https://www.jcom.co.jp/en/service/mobile/device/sim/detail/simunlock.html)
            
        
    *   Options
        
        *   [Options Overview](https://www.jcom.co.jp/en/service/mobile/option/)
            
        *   [Unlimited calls](https://www.jcom.co.jp/en/service/mobile/option/kakehodai/)
            
        *   [Block nuisance calls and messages](https://www.jcom.co.jp/en/service/mobile/option/block/)
            
        *   [Family smartphone insurance](https://www.jcom.co.jp/en/service/ssi/kazoku_sumaho/)
            
        *   [Secure device guarantee 60](https://www.jcom.co.jp/en/service/mobile/option/guaranty60/)
            
        *   [AppleCare+ for iPhone](https://www.jcom.co.jp/en/service/mobile/device/support/applecare.html)
            
        *   [Anshin Filter for J:COM](https://www.jcom.co.jp/en/service/mobile/option/anshin_filter/)
            
        *   [Purchase additional accessories](https://www.jcom.co.jp/en/service/mobile/option/accessories/add/)
            
        
    *   Initial Setup Support
        
        *   [Initial Setup Support Top](https://www.jcom.co.jp/en/service/mobile/support/)
            
        *   [FAQ](https://www.jcom.co.jp/en/service/mobile/support/faq/)
            
        *   [Transferring your smartphone Q&A](https://www.jcom.co.jp/en/service/mobile/support/qa/)
            
        
    *   [How to apply](https://www.jcom.co.jp/en/service/mobile/usage/)
        
    *   [User](https://cs.myjcom.jp/jcomMobile)
        
    *   [For corporations](https://business.jcom.co.jp/smb/mobile/)
        
    
*   [![J:COM Denki](https://www.jcom.co.jp/common_v10/images/icn-jcom-electricity.svg)electricity](https://www.jcom.co.jp/en/service/electricity/)
     ![メニューを閉じる](https://www.jcom.co.jp/common_v10/images/sp-menu/menu-close-white.svg)
    
    [![](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom-electricity/slide/menu/mv-middle.webp)\
    \
    Rest assured that the quality remains the same\
    \
    Back to top](https://www.jcom.co.jp/en/service/electricity/)
    
    *   Price menu
        
        *   [Price menu top](https://www.jcom.co.jp/en/service/electricity/price/)
            
        *   [TEPCO area](https://www.jcom.co.jp/en/service/electricity/price/tokyo_juryo.html)
            
        *   [Kansai Electric Power area](https://www.jcom.co.jp/en/service/electricity/price/kansai_juryo.html)
            
        *   [Tohoku Electric Power Area](https://www.jcom.co.jp/en/service/electricity/price/tohoku_juryo.html)
            
        *   [Chugoku Electric Power Area](https://www.jcom.co.jp/en/service/electricity/price/chugoku_juryo.html)
            
        *   [Kyushu Electric Power area](https://www.jcom.co.jp/en/service/electricity/price/kyushu_juryo.html)
            
        *   [Hokkaido Electric Power Area](https://www.jcom.co.jp/en/service/electricity/price/hokkaido_juryo.html)
            
        
    *   green menu
        
        *   [green menu top](https://www.jcom.co.jp/en/service/electricity/price/green/)
            
        *   [Pricing](https://www.jcom.co.jp/en/service/electricity/price/green/price_list/)
            
        
    *   [J:COM Electric  \
        How it works](https://www.jcom.co.jp/en/service/electricity/feature/)
        
    *   [How to apply](https://www.jcom.co.jp/en/service/electricity/flow/)
        
    *   [User](https://cs.myjcom.jp/ele)
        
    
*   [![あたらしいを、あたりまえに　J:COM](https://www.jcom.co.jp/common_v10/images/logo-jcom-only.svg)](https://www.jcom.co.jp/en/)
     ![メニューを閉じる](https://www.jcom.co.jp/common_v10/images/sp-menu/menu-close.svg)
    
    [Landline](https://www.jcom.co.jp/en/service/phone/)
     ​ ​[gas](https://www.jcom.co.jp/en/service/gas/)
     ​ ​[insurance](https://www.jcom.co.jp/en/service/ssi/)
     ​ ​[loan](https://www.jcom-financial.co.jp/)
     ​ ​[Home IoT](https://www.jcom.co.jp/en/service/home/)
     ​ ​[security cameras](https://www.jcom.co.jp/en/guide/starter/home_security/)
     ​ ​[online  \
    medical treatment](https://www.jcom.co.jp/en/service/telemedicine/)
    
    [Service overview](https://www.jcom.co.jp/en/service/)
    
    [Services for corporations and local governments  \
    ![J:COM BUSINESS](https://www.jcom.co.jp/common_v10/images/logo_jcombusiness.webp)](https://business.jcom.co.jp/)
    

Service introduction
====================

New customers

[New Customers  \
Sign Up](https://onlineshop.jcom.co.jp/planSelect)

[For new subscribers  \
inquiry](https://www.jcom.co.jp/service/#)

Current customers

[Current Customers  \
Various procedures](https://r.jcom.jp/eG4nLSC)

[Problems/  \
inquiry  \
(chat)](https://prod8-live-chat.sprinklr.com/page?appId=67af27d73657336d345e4a96_app_9070639&did=CHAT_vivr_cojp_top&enableClose=true&skin=MODERN&userContext__c_679c8b53cb85b007fab0f6ea=DirectLink&utm_campaign=IVRSMS&utm_medium=referral&utm_source=did&webview=true&zoom=false)

Find the perfect  
plan for you

[Savings  \
 calculator](https://onlineshop.jcom.co.jp/Simulation/Simulation)

Some properties offer free or discounted options!

Covered  
areas & properties

New customers

[Sign Up](https://onlineshop.jcom.co.jp/planSelect?sc_pid=common_upper_entry_02)

[![](https://www.jcom.co.jp/common_v10/images/icn-think-black.svg)Applications and Inquiries](https://www.jcom.co.jp/service/#)

[![](https://www.jcom.co.jp/common_v10/images/icn-think-black.svg)申请・咨询](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[电话咨询  \
050-1722-1733](tel:050-1722-1733)
 9:00-18:00【全年无休】／有翻译 [日本語での通話は  \
こちら](https://www.jcom.co.jp/service/#)

[![](https://www.jcom.co.jp/common_v10/images/icn-think-black.svg)신청·문의](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[신청·문의  \
050-1722-1733](tel:050-1722-1733)
 9:00-18:00【연중무휴】／통역 있음 [日本語での通話は  \
こちら](https://www.jcom.co.jp/service/#)

[![](https://www.jcom.co.jp/common_v10/images/icn-think-black.svg)Ứng dụng / Yêu cầu](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Ứng dụng / Yêu cầu  \
050-1722-1733](tel:050-1722-1733)
 9:00-18:00【mở cửa quanh năm】／có phiên dịch [日本語での通話は  \
こちら](https://www.jcom.co.jp/service/#)

[![](https://www.jcom.co.jp/common_v10/images/icn-think-black.svg)Solicitação/Consultas](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Solicitação/Consultas  \
050-1722-1733](tel:050-1722-1733)
 9:00-18:00【aberto todo o ano】／com intérprete [日本語での通話は  \
こちら](https://www.jcom.co.jp/service/#)

Current customers

[Check / Update  \
Your Contract  \
(JAPANESE ONLY)](https://www2.myjcom.jp/join/?ac_id=btm_change&sc_pid=common_upper_join_02)

[![](https://www.jcom.co.jp/common_v10/images/icn-member.svg)Inquiries](https://www.jcom.co.jp/service/#)

[![](https://www.jcom.co.jp/common_v10/images/icn-member.svg)联系我们](https://www.jcom.co.jp/service/#)

[![](https://www.jcom.co.jp/common_v10/images/icn-member.svg)문의](https://www.jcom.co.jp/service/#)

[![](https://www.jcom.co.jp/common_v10/images/icn-member.svg)Hỏi đáp](https://www.jcom.co.jp/service/#)

[![](https://www.jcom.co.jp/common_v10/images/icn-member.svg)Consultar](https://www.jcom.co.jp/service/#)

Find the perfect  
plan for you

[Savings  \
 calculator](https://onlineshop.jcom.co.jp/Simulation/Simulation?sc_pid=common_upper_simu_02)

Some properties offer free or discounted options!

Covered  
areas & properties

[](https://www.jcom.co.jp/service/#)

New Customers  
Inquiries

[Contact us online](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

J:COM will respond to you by email or phone.

Click here to contact us by phone (toll free)

[0120-989-970](tel:0120-989-970)

9:00-18:00 \[Open all year round\]

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

New Customers  
Inquiries

[Contact us online](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

J:COM will respond to you by email or phone.

Click here to contact us by phone (toll free)

[0120-989-970](tel:0120-989-970)

9:00-18:00 \[Open all year round\]

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

New Customers  
Inquiries

[Contact us online](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

J:COM will respond to you by email or phone.

Click here to contact us by phone (toll free)

[0120-989-970](tel:0120-989-970)

9:00-18:00 \[Open all year round\]

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

Current Customers  
Inquiries

Check / Update  
your contract here

[My page login](https://mypage.jcom.co.jp/)

* * *

Click here for  
Troubleshooting/FAQ

[Customer Support](https://cs.myjcom.jp/)

* * *

Click here to  
add or change service options

[Edit / Add to Your Plan](https://www2.myjcom.jp/join/)

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

Current Customers  
Inquiries

Check / Update  
your contract here

[My page login](https://mypage.jcom.co.jp/)

* * *

Click here for  
Troubleshooting/FAQ

[Customer Support](https://cs.myjcom.jp/)

* * *

Click here to  
add or change service options

[Edit / Add to Your Plan](https://www2.myjcom.jp/join/)

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

Current Customers  
Inquiries

Check / Update  
your contract here

[My page login](https://mypage.jcom.co.jp/)

* * *

Click here for  
Troubleshooting/FAQ

[Customer Support](https://cs.myjcom.jp/)

* * *

Click here to  
add or change service options

[Edit / Add to Your Plan](https://www2.myjcom.jp/join/)

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

User  
Application

For those who do not use J:COM TV

[J:COM TV  \
Shin Standard Plus  \
Application](https://r.jcom.jp/24KC2mS)

User J:COM TV

[J:COM TV  \
To Shin Standard Plus  \
Change of course](https://r.jcom.jp/0JLPOoy)

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

User  
Application

For those who do not use J:COM TV

[J:COM TV  \
Shin Standard Plus  \
Application](https://r.jcom.jp/24KC2mS)

User J:COM TV

[J:COM TV  \
To Shin Standard Plus  \
Change of course](https://r.jcom.jp/0JLPOoy)

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

User  
Application

For those who do not use J:COM TV

[J:COM TV  \
Shin Standard Plus  \
Application](https://r.jcom.jp/24KC2mS)

User J:COM TV

[J:COM TV  \
To Shin Standard Plus  \
Change of course](https://r.jcom.jp/0JLPOoy)

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

Confirming or changing the construction date

You can check, change, or cancel the schedule for on-site construction work on your My Page.

[My page login](https://mypage.jcom.co.jp/)

[Click here for instructions on how to check your My Page](https://cs.myjcom.jp/articles/support/6790bf45ad2e841b2e3362cf)

The installation date for J:COM NET Hikari (N) cannot be changed on My Page. Please contact [the customer center](https://www.jcom.co.jp/contactus/call_rgu.html#phone)
.

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

New Customers　  
Applications and Inquiries

[Applications and Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[0120-989-970](tel:0120-989-970)

Business hours: 9:00-18:00  
\[Open all year round\]

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

New Customers　  
Applications and Inquiries

[Applications and Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[0120-989-970](tel:0120-989-970)

Business hours: 9:00-18:00  
\[Open all year round\]

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

New Customers　  
Applications and Inquiries

[Applications and Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[0120-989-970](tel:0120-989-970)

Business hours: 9:00-18:00  
\[Open all year round\]

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

Current Customers　  
Inquiries

[Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[0120-989-970](tel:0120-989-970)

Business hours: 9:00-18:00  
\[Open all year round\]

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

Current Customers　  
Inquiries

[Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[0120-989-970](tel:0120-989-970)

Business hours: 9:00-18:00  
\[Open all year round\]

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

Current Customers　  
Inquiries

[Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[0120-989-970](tel:0120-989-970)

Business hours: 9:00-18:00  
\[Open all year round\]

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

新用户　  
申请・咨询

신규가입 고객　  
신청·문의

Đối với khách hàng mới tham gia　  
Ứng dụng / Yêu cầu

Novos assinantes　  
Solicitação/Consultas

电话咨询（有翻译）

전화 상담(통역 있음)

Tư vấn qua điện thoại (có phiên dịch)

Consulta por telefone (com intérprete)

[050-1722-1733](tel:050-1722-1733)

9:00-18:00 \[Open all year round\]

[日本語での通話はこちら](https://www.jcom.co.jp/service/#)

[申请・咨询](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[신청・문의](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Ứng dụng / Yêu cầu](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Solicitação/Consultas](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

新用户　  
申请・咨询

신규가입 고객　  
신청·문의

Đối với khách hàng mới tham gia　  
Ứng dụng / Yêu cầu

Novos assinantes　  
Solicitação/Consultas

电话咨询（有翻译）

전화 상담(통역 있음)

Tư vấn qua điện thoại (có phiên dịch)

Consulta por telefone (com intérprete)

[050-1722-1733](tel:050-1722-1733)

9:00-18:00 \[Open all year round\]

[日本語での通話はこちら](https://www.jcom.co.jp/service/#)

[申请・咨询](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[신청・문의](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Ứng dụng / Yêu cầu](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Solicitação/Consultas](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

新用户　  
申请・咨询

신규가입 고객　  
신청·문의

Đối với khách hàng mới tham gia　  
Ứng dụng / Yêu cầu

Novos assinantes　  
Solicitação/Consultas

电话咨询（有翻译）

전화 상담(통역 있음)

Tư vấn qua điện thoại (có phiên dịch)

Consulta por telefone (com intérprete)

[050-1722-1733](tel:050-1722-1733)

9:00-18:00 \[Open all year round\]

[日本語での通話はこちら](https://www.jcom.co.jp/service/#)

[申请・咨询](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[신청・문의](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Ứng dụng / Yêu cầu](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Solicitação/Consultas](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

会员　  
联系我们

이용 중인 고객　  
문의

Khách hàng đang sử dụng　  
Hỏi đáp

Utilizadores　  
Consultar

电话咨询（有翻译）

전화 상담(통역 있음)

Tư vấn qua điện thoại (có phiên dịch)

Consulta por telefone (com intérprete)

[050-1722-1733](tel:050-1722-1733)

9:00-18:00 \[Open all year round\]

[日本語での通話はこちら](https://www.jcom.co.jp/service/#)

[联系我们](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[문의](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[Hỏi đáp](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[Consultar](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

会员　  
联系我们

이용 중인 고객　  
문의

Khách hàng đang sử dụng　  
Hỏi đáp

Utilizadores　  
Consultar

电话咨询（有翻译）

전화 상담(통역 있음)

Tư vấn qua điện thoại (có phiên dịch)

Consulta por telefone (com intérprete)

[050-1722-1733](tel:050-1722-1733)

9:00-18:00 \[Open all year round\]

[日本語での通話はこちら](https://www.jcom.co.jp/service/#)

[联系我们](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[문의](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[Hỏi đáp](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[Consultar](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

会员　  
联系我们

이용 중인 고객　  
문의

Khách hàng đang sử dụng　  
Hỏi đáp

Utilizadores　  
Consultar

电话咨询（有翻译）

전화 상담(통역 있음)

Tư vấn qua điện thoại (có phiên dịch)

Consulta por telefone (com intérprete)

[050-1722-1733](tel:050-1722-1733)

9:00-18:00 \[Open all year round\]

[日本語での通話はこちら](https://www.jcom.co.jp/service/#)

[联系我们](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[문의](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[Hỏi đáp](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[Consultar](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

日本語でのお問い合わせ

[海外にお住まいの方](https://cs.myjcom.jp/knowledgeDetail?an=004897372)

[日本国内にお住まいの方](https://www.jcom.co.jp/contactus/call_rgu.html)

[閉じる](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

日本語でのお問い合わせ

[海外にお住まいの方](https://cs.myjcom.jp/knowledgeDetail?an=004897372)

[日本国内にお住まいの方](https://www.jcom.co.jp/contactus/call_rgu.html)

[閉じる](https://www.jcom.co.jp/service/#)

make life comfortable  
various services
----------------------------------------

[TV](https://www.jcom.co.jp/service/#tv)
 ​ ​ [Internet](https://www.jcom.co.jp/service/#net)
 ​ ​ [Smartphone](https://www.jcom.co.jp/service/#mobile)
 ​ ​ [Electricity](https://www.jcom.co.jp/service/#electricity)

[Landline](https://www.jcom.co.jp/service/#phone)
 ​ ​ [gas](https://www.jcom.co.jp/service/#gas)
 ​ ​ [insurance](https://www.jcom.co.jp/service/#ssi)
 ​ ​ [loan](https://www.jcom.co.jp/service/#loan)
 ​ ​ [Home IoT](https://www.jcom.co.jp/service/#home)
 ​ ​ [online  \
medical treatment](https://www.jcom.co.jp/service/#telemedicine)

[Other services are here.](https://www.jcom.co.jp/service/#kurashi)
 ​ ​[Security cameras are here.](https://www.jcom.co.jp/en/guide/starter/home_security/)

![テレビ](https://www.jcom.co.jp/common_v10/images/icn-jcom-tv.svg) tv set
-----------------------------------------------------------------------

Airing what you want to see

[J:COM TV Top](https://www.jcom.co.jp/en/service/tv/)

[Plans & Pricing\
\
Let's find the perfect course](https://www.jcom.co.jp/en/service/tv/course/)
[Diverse content\
\
I want to watch a lot of interesting programs](https://www.jcom.co.jp/en/service/tv/channel/)

[internet video\
\
lots of online videos  \
Enjoy on your big screen TV!](https://www.jcom.co.jp/en/service/tv/smart/ott.html)
[useful function](https://www.jcom.co.jp/en/service/tv/smart/)
[Options](https://www.jcom.co.jp/en/service/tv/accessories/)
[Application flow](https://www.jcom.co.jp/en/service/tv/guide/)

See more

![ネット](https://www.jcom.co.jp/common_v10/images/icn-jcom-net.svg) Net
---------------------------------------------------------------------

Faster and more comfortable

[J:COM NET Top](https://www.jcom.co.jp/en/service/net/)

[Plans & Pricing\
\
Let's find the perfect course](https://www.jcom.co.jp/en/service/net/course/)
[Options\
\
J:COM Wi-Fi and free use  \
Information on options.](https://www.jcom.co.jp/en/service/net/option/)

[Support](https://www.jcom.co.jp/en/service/net/support/)
[Application flow](https://www.jcom.co.jp/en/service/net/guide/)

See more

Wi-Fi that can be used on the go

[J:COM WiMAX\
\
High-speed internet on the go  \
Available](https://www.jcom.co.jp/en/service/wimax/)

![スマホ](https://www.jcom.co.jp/common_v10/images/icn-jcom-mobile.svg) smartphone
-------------------------------------------------------------------------------

Continuous savings

[J:COM MOBILE Top](https://www.jcom.co.jp/en/service/mobile/)

[Fees/Services\
\
Great monthly fee. with other services  \
Save even more by combining them.](https://www.jcom.co.jp/en/service/mobile/price/)
[product\
\
From 980 yen per month (1,078 yen including tax)  \
Usable smartphone and SIM](https://www.jcom.co.jp/en/service/mobile/device/)

[Low-cost SIM](https://www.jcom.co.jp/en/service/mobile/device/sim/)
[Options\
\
With a full range of optional services,  \
Conveniently and comfortably.](https://www.jcom.co.jp/en/service/mobile/option/)
[Support\
\
Leave the initial settings to J:COM](https://www.jcom.co.jp/en/service/mobile/support/)
[Application flow\
\
After applying online, the customer  \
Pick up at home.](https://www.jcom.co.jp/en/service/mobile/usage/)

See more

eSIM for international travel

[eSIM for overseas travel (by Airalo)\
\
Use the bonus code to save 15%  \
You can use an eSIM for international travel](https://www.jcom.co.jp/en/service/travelesim/)

![でんき](https://www.jcom.co.jp/common_v10/images/icn-jcom-electricity.svg) electricity
-------------------------------------------------------------------------------------

Rest assured that the quality remains the same

[J:COM Electric Top](https://www.jcom.co.jp/en/service/electricity/)

[Price menu\
\
Great deals by region  \
Introducing the price menu](https://www.jcom.co.jp/en/service/electricity/price/)
[Green menu\
\
Environmentally friendly electricity, a given.](https://www.jcom.co.jp/en/service/electricity/price/green/)

[How electricity works\
\
From the mechanism of safe electricity distribution  \
We will guide you through the power supply configuration.](https://www.jcom.co.jp/en/service/electricity/feature/)
[Application flow\
\
From application to switching to electricity,  \
Easy procedure.](https://www.jcom.co.jp/en/service/electricity/flow/)

See more

Solar panel and battery system

[J:COM Solar and Storage Battery\
\
Good for the earth and your wallet  \
Kanto area only](https://www.jcom.co.jp/en/service/electricity/solar/)

![Landline](https://www.jcom.co.jp/common_v10/images/icn-jcom-phone.svg) Landlines
----------------------------------------------------------------------------------

Save money with J:COM 's Landline!

[J:COM PHONE top](https://www.jcom.co.jp/en/service/phone/)

[24 hours free call\
\
I want to make free calls](https://www.jcom.co.jp/en/service/phone/free/)
[Basic charges/call charges\
\
Good basic price](https://www.jcom.co.jp/en/service/phone/charge/)

[au free call application\
\
If you use both J:COM PHONE Plus and au cell phone services, calls from J:COM PHONE Plus to au cell phones nationwide are free!](https://www.jcom.co.jp/en/service/phone/au/new/)
[Optional service](https://www.jcom.co.jp/en/service/phone/option/new/)

See more

![Gas](https://www.jcom.co.jp/common_v10/images/icn-jcom-gas.svg) Gas
---------------------------------------------------------------------

J:COM GAS!  
Currently available in the Kanto and Kansai areas.

[J:COM GAS Top](https://www.jcom.co.jp/en/service/gas/)

[supplied by Tokyo Gas\
\
Tokyo Gas city gas supply area](https://www.jcom.co.jp/en/service/gas/tokyogas/)
[supplied by Osaka Gas\
\
City gas supply area of Osaka Gas](https://www.jcom.co.jp/en/service/gas/osakagas/)
[supplied by Keiyo Gas\
\
Keiyo Gas city gas supply area](https://www.jcom.co.jp/en/service/gas/keiyogas/)

[Safe, secure, convenient\
\
Gas supply and safety work remain the same!](https://www.jcom.co.jp/en/service/gas/safety/)
[What is gas liberalization?](https://www.jcom.co.jp/en/service/gas/about/)

[Tokyo Gas for J:COM “Zuttomo Gas”](https://www.jcom.co.jp/en/service/tokyo_gas/)

Click here for customers using Tosai Gas or East Japan Gas in Saitama, Ibaraki, or Chiba prefectures.

See more

![insurance](https://www.jcom.co.jp/common_v10/images/icn-jcom-ssi.svg) insurance
---------------------------------------------------------------------------------

Comprehensive compensation and support  
protect you and your family

[J:COM Insurance Top](https://www.jcom.co.jp/en/service/ssi/)

[Family smartphone insurance\
\
Covers repair costs and replacement costs for smartphones and tablets that are malfunctioning, damaged, stolen, etc.](https://www.jcom.co.jp/en/service/ssi/kazoku_sumaho/)
[Net Anshin Insurance\
\
From rapidly increasing Internet troubles  \
protect you and your family.](https://www.jcom.co.jp/en/service/ssi/net/)

![loan](https://www.jcom.co.jp/common_v10/images/icn-jcom-loan.svg) loan
------------------------------------------------------------------------

A reliable ally who is close to your lifestyle.

[J:COM Premium Loan  \
top](https://www.jcom-financial.co.jp/)

[If you are using for the first time\
\
Introducing the service overview](https://www.jcom-financial.co.jp/guide/)
[How to borrow\
\
Even first-timers can feel at ease](https://www.jcom-financial.co.jp/borrow/flow/)
[Repayment\
\
You can also simulate the repayment amount.](https://www.jcom-financial.co.jp/repay/)

![Home IoT Solutions](https://www.jcom.co.jp/common_v10/images/icn-jcom-home.svg) Home IoT
------------------------------------------------------------------------------------------

more in life  
Plus safety, convenience and fun.

[J:COM HOME Top](https://www.jcom.co.jp/en/service/home/)

[security camera pack\
\
Reliable security at an affordable price](https://www.jcom.co.jp/en/service/home/security/)
[HOME pack\
\
For operating home appliances and watching over children and pets.](https://www.jcom.co.jp/en/service/home/iot/)
[Use scene\
\
Introducing usage examples tailored to your usage.](https://www.jcom.co.jp/en/service/home/features/)

![Telemedicine](https://www.jcom.co.jp/common_v10/images/icn-jcom-telemedicine.svg) Telemedicine
------------------------------------------------------------------------------------------------

Smartphones and TVs in the examination room

[J:COM Telemedicine  \
Top](https://www.jcom.co.jp/en/service/telemedicine/)

[Medical institution search\
\
Search for available medical institutions.](https://www.jcom.co.jp/en/service/telemedicine/clinic/)
[Medical treatment flow\
\
The flow of medical treatment when using a smartphone  \
I'll guide you.](https://www.jcom.co.jp/en/service/telemedicine/features/)

[New Customers  \
Sign Up](https://onlineshop.jcom.co.jp/planSelect)

[Current Customers  \
Various procedures](https://r.jcom.jp/eG4nLSC)

Find the perfect plan for you

[Savings  \
 calculator](https://onlineshop.jcom.co.jp/Simulation/Simulation)

[Sign Up](https://onlineshop.jcom.co.jp/planSelect?sc_pid=common_middle_entry_02)

[Check / Update  \
Your Contract  \
(JAPANESE ONLY)](https://www2.myjcom.jp/join/?ac_id=btm_change&sc_pid=common_middle_join_02)

Find the perfect plan for you

[Savings  \
 calculator](https://onlineshop.jcom.co.jp/Simulation/Simulation?sc_pid=common_middle_simu_02)

[](https://www.jcom.co.jp/service/#)

New Customers  
Inquiries

[Contact us online](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

J:COM will respond to you by email or phone.

Click here to contact us by phone (toll free)

[0120-989-970](tel:0120-989-970)

9:00-18:00 \[Open all year round\]

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

New Customers  
Inquiries

[Contact us online](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

J:COM will respond to you by email or phone.

Click here to contact us by phone (toll free)

[0120-989-970](tel:0120-989-970)

9:00-18:00 \[Open all year round\]

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

New Customers  
Inquiries

[Contact us online](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

J:COM will respond to you by email or phone.

Click here to contact us by phone (toll free)

[0120-989-970](tel:0120-989-970)

9:00-18:00 \[Open all year round\]

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

Current Customers  
Inquiries

Check / Update  
your contract here

[My page login](https://mypage.jcom.co.jp/)

* * *

Click here for  
Troubleshooting/FAQ

[Customer Support](https://cs.myjcom.jp/)

* * *

Click here to  
add or change service options

[Edit / Add to Your Plan](https://www2.myjcom.jp/join/)

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

Current Customers  
Inquiries

Check / Update  
your contract here

[My page login](https://mypage.jcom.co.jp/)

* * *

Click here for  
Troubleshooting/FAQ

[Customer Support](https://cs.myjcom.jp/)

* * *

Click here to  
add or change service options

[Edit / Add to Your Plan](https://www2.myjcom.jp/join/)

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

Current Customers  
Inquiries

Check / Update  
your contract here

[My page login](https://mypage.jcom.co.jp/)

* * *

Click here for  
Troubleshooting/FAQ

[Customer Support](https://cs.myjcom.jp/)

* * *

Click here to  
add or change service options

[Edit / Add to Your Plan](https://www2.myjcom.jp/join/)

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

User  
Application

For those who do not use J:COM TV

[J:COM TV  \
Shin Standard Plus  \
Application](https://r.jcom.jp/24KC2mS)

User J:COM TV

[J:COM TV  \
To Shin Standard Plus  \
Change of course](https://r.jcom.jp/0JLPOoy)

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

User  
Application

For those who do not use J:COM TV

[J:COM TV  \
Shin Standard Plus  \
Application](https://r.jcom.jp/24KC2mS)

User J:COM TV

[J:COM TV  \
To Shin Standard Plus  \
Change of course](https://r.jcom.jp/0JLPOoy)

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

User  
Application

For those who do not use J:COM TV

[J:COM TV  \
Shin Standard Plus  \
Application](https://r.jcom.jp/24KC2mS)

User J:COM TV

[J:COM TV  \
To Shin Standard Plus  \
Change of course](https://r.jcom.jp/0JLPOoy)

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

Confirming or changing the construction date

You can check, change, or cancel the schedule for on-site construction work on your My Page.

[My page login](https://mypage.jcom.co.jp/)

[Click here for instructions on how to check your My Page](https://cs.myjcom.jp/articles/support/6790bf45ad2e841b2e3362cf)

The installation date for J:COM NET Hikari (N) cannot be changed on My Page. Please contact [the customer center](https://www.jcom.co.jp/contactus/call_rgu.html#phone)
.

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

New Customers　  
Applications and Inquiries

[Applications and Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[0120-989-970](tel:0120-989-970)

Business hours: 9:00-18:00  
\[Open all year round\]

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

New Customers　  
Applications and Inquiries

[Applications and Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[0120-989-970](tel:0120-989-970)

Business hours: 9:00-18:00  
\[Open all year round\]

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

New Customers　  
Applications and Inquiries

[Applications and Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[0120-989-970](tel:0120-989-970)

Business hours: 9:00-18:00  
\[Open all year round\]

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

Current Customers　  
Inquiries

[Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[0120-989-970](tel:0120-989-970)

Business hours: 9:00-18:00  
\[Open all year round\]

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

Current Customers　  
Inquiries

[Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[0120-989-970](tel:0120-989-970)

Business hours: 9:00-18:00  
\[Open all year round\]

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

Current Customers　  
Inquiries

[Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[0120-989-970](tel:0120-989-970)

Business hours: 9:00-18:00  
\[Open all year round\]

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

新用户　  
申请・咨询

신규가입 고객　  
신청·문의

Đối với khách hàng mới tham gia　  
Ứng dụng / Yêu cầu

Novos assinantes　  
Solicitação/Consultas

电话咨询（有翻译）

전화 상담(통역 있음)

Tư vấn qua điện thoại (có phiên dịch)

Consulta por telefone (com intérprete)

[050-1722-1733](tel:050-1722-1733)

9:00-18:00 \[Open all year round\]

[日本語での通話はこちら](https://www.jcom.co.jp/service/#)

[申请・咨询](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[신청・문의](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Ứng dụng / Yêu cầu](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Solicitação/Consultas](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

新用户　  
申请・咨询

신규가입 고객　  
신청·문의

Đối với khách hàng mới tham gia　  
Ứng dụng / Yêu cầu

Novos assinantes　  
Solicitação/Consultas

电话咨询（有翻译）

전화 상담(통역 있음)

Tư vấn qua điện thoại (có phiên dịch)

Consulta por telefone (com intérprete)

[050-1722-1733](tel:050-1722-1733)

9:00-18:00 \[Open all year round\]

[日本語での通話はこちら](https://www.jcom.co.jp/service/#)

[申请・咨询](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[신청・문의](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Ứng dụng / Yêu cầu](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Solicitação/Consultas](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

新用户　  
申请・咨询

신규가입 고객　  
신청·문의

Đối với khách hàng mới tham gia　  
Ứng dụng / Yêu cầu

Novos assinantes　  
Solicitação/Consultas

电话咨询（有翻译）

전화 상담(통역 있음)

Tư vấn qua điện thoại (có phiên dịch)

Consulta por telefone (com intérprete)

[050-1722-1733](tel:050-1722-1733)

9:00-18:00 \[Open all year round\]

[日本語での通話はこちら](https://www.jcom.co.jp/service/#)

[申请・咨询](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[신청・문의](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Ứng dụng / Yêu cầu](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Solicitação/Consultas](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

会员　  
联系我们

이용 중인 고객　  
문의

Khách hàng đang sử dụng　  
Hỏi đáp

Utilizadores　  
Consultar

电话咨询（有翻译）

전화 상담(통역 있음)

Tư vấn qua điện thoại (có phiên dịch)

Consulta por telefone (com intérprete)

[050-1722-1733](tel:050-1722-1733)

9:00-18:00 \[Open all year round\]

[日本語での通話はこちら](https://www.jcom.co.jp/service/#)

[联系我们](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[문의](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[Hỏi đáp](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[Consultar](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

会员　  
联系我们

이용 중인 고객　  
문의

Khách hàng đang sử dụng　  
Hỏi đáp

Utilizadores　  
Consultar

电话咨询（有翻译）

전화 상담(통역 있음)

Tư vấn qua điện thoại (có phiên dịch)

Consulta por telefone (com intérprete)

[050-1722-1733](tel:050-1722-1733)

9:00-18:00 \[Open all year round\]

[日本語での通話はこちら](https://www.jcom.co.jp/service/#)

[联系我们](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[문의](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[Hỏi đáp](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[Consultar](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

会员　  
联系我们

이용 중인 고객　  
문의

Khách hàng đang sử dụng　  
Hỏi đáp

Utilizadores　  
Consultar

电话咨询（有翻译）

전화 상담(통역 있음)

Tư vấn qua điện thoại (có phiên dịch)

Consulta por telefone (com intérprete)

[050-1722-1733](tel:050-1722-1733)

9:00-18:00 \[Open all year round\]

[日本語での通話はこちら](https://www.jcom.co.jp/service/#)

[联系我们](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[문의](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[Hỏi đáp](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[Consultar](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

日本語でのお問い合わせ

[海外にお住まいの方](https://cs.myjcom.jp/knowledgeDetail?an=004897372)

[日本国内にお住まいの方](https://www.jcom.co.jp/contactus/call_rgu.html)

[閉じる](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

日本語でのお問い合わせ

[海外にお住まいの方](https://cs.myjcom.jp/knowledgeDetail?an=004897372)

[日本国内にお住まいの方](https://www.jcom.co.jp/contactus/call_rgu.html)

[閉じる](https://www.jcom.co.jp/service/#)

Entertainment
-------------

[![J:COM consolidated billing for Disney+](https://www.jcom.co.jp/service/images_v10/thum-disneyplus-service-v3.png)](https://www.jcom.co.jp/en/service/disneyplus/)

[J:COM consolidated billing for Disney+](https://www.jcom.co.jp/en/service/disneyplus/)

Consolidated billing for Disney's official video streaming service "Disney+" and J:COM service into one bill.

[![Consolidated billing (DAZN)](https://www.jcom.co.jp/service/images_v10/thum-dazn-service.png)](https://www.jcom.co.jp/en/service/dazn/)

[Consolidated billing (DAZN)](https://www.jcom.co.jp/en/service/dazn/)

DAZN, which offers a variety of domestic and international sports videos, and J:COM service billing are combined into one.

[![J:COM Books](https://www.jcom.co.jp/service/images_v10/thum-jcombooks.jpg)](https://www.jcom.co.jp/en/service/books/)

[J:COM Books](https://www.jcom.co.jp/en/service/books/)

The largest in Japan! J:COM Books is an “e-book unlimited reading service” that allows you to enjoy over 1,000 popular magazines and textbooks anytime, anywhere.

Support
-------

[![Enkaku support](https://www.jcom.co.jp/service/images_v10/thum-omasapo.jpg)](https://www.jcom.co.jp/en/service/omakase/)

[Enkaku support](https://www.jcom.co.jp/en/service/omakase/)

Easily solve your TV and Internet problems! For 500 yen per month (550 yen including tax), we provide Enkaku support 365 days a year!

[![Home support](https://www.jcom.co.jp/service/images_v10/thum-ouchisapo.jpg)](https://www.jcom.co.jp/en/service/uchisapo/)

[Home support](https://www.jcom.co.jp/en/service/uchisapo/)

Have peace of mind in case of emergency!  
For just 200 yen per month (220 yen including tax), we offer everything from plumbing, key and glass problems to house cleaning and housekeeping services!

[![Cyclist support](https://www.jcom.co.jp/service/images_v10/thum-bicycle.jpg)](https://www.jcom.co.jp/en/service/bicycle/)

[Cyclist support](https://www.jcom.co.jp/en/service/bicycle/)

Bicycle roadside service for breakdowns or dead batteries! You can have peace of mind knowing you’re covered by insurance for injuries and compensated if caught in an accident while riding a bicycle!

[![Disaster prevention information service](https://www.jcom.co.jp/service/images_v10/thum-kinkyuji.jpg)](https://www.jcom.co.jp/en/service/eew/)

[Disaster prevention information service](https://www.jcom.co.jp/en/service/eew/)

This service notifies you of earthquake early warnings and information about your area.

We provide emergency earthquake early warnings in areas not linked to the emergency broadcast system.

[![Heartful plan](https://www.jcom.co.jp/service/images_v10/thum-heartful.jpg)](https://www.jcom.co.jp/en/service/heartful_pack/)

[Heartful plan](https://www.jcom.co.jp/en/service/heartful_pack/)

We offer special prices to customers with disabilities who live in our service area.

See more

J:COM 's reputation and  
What are the reviews?
-----------------------------------------------

![J:COMの評判と口コミは？](https://www.jcom.co.jp/service/images_v10/img_satisfaction_thum.jpg)

Reviews and ratings from actual customers  
Introducing.

[Learn more](https://www.jcom.co.jp/en/service/satisfaction/)

Campaigns/benefits
------------------

 [![WEB限定スタート割](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_start.webp)](https://www.jcom.co.jp/en/campaign/start_jcom/)
[![青春22割・青春26割](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_u26.webp)](https://www.jcom.co.jp/en/campaign/u26/)
[![J:COM金利優遇割引](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_au_loan.webp)](https://www.jcom.co.jp/en/price/au_loan/)

[![WEB限定スタート割](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_start.webp)](https://www.jcom.co.jp/en/campaign/start_jcom/)

[![青春22割・青春26割](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_u26.webp)](https://www.jcom.co.jp/en/campaign/u26/)

[![J:COM金利優遇割引](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_au_loan.webp)](https://www.jcom.co.jp/en/price/au_loan/)

[Promotions/Benefits](https://www.jcom.co.jp/en/campaign/)

If you are considering signing up or adding services

### Sign Up information

New customers

[New Customers  \
Sign Up](https://onlineshop.jcom.co.jp/planSelect)

[For new subscribers  \
inquiry](https://www.jcom.co.jp/service/#)

Current customers

[Current Customers  \
Various procedures](https://r.jcom.jp/eG4nLSC)

[Problems/  \
inquiry  \
(chat)](https://prod8-live-chat.sprinklr.com/page?appId=67af27d73657336d345e4a96_app_9070639&did=CHAT_vivr_cojp_top&enableClose=true&skin=MODERN&userContext__c_679c8b53cb85b007fab0f6ea=DirectLink&utm_campaign=IVRSMS&utm_medium=referral&utm_source=did&webview=true&zoom=false)

Find the perfect  
plan for you

[Savings  \
 calculator](https://onlineshop.jcom.co.jp/Simulation/Simulation)

Some properties offer free or discounted options!

Covered  
areas & properties

If you are considering signing up or adding services

### Sign Up information

New customers

[Sign Up](https://onlineshop.jcom.co.jp/planSelect?sc_pid=common_bottom_entry_02)

[![](https://www.jcom.co.jp/common_v10/images/icn-think-black.svg)Applications and Inquiries](https://www.jcom.co.jp/service/#)

[![](https://www.jcom.co.jp/common_v10/images/icn-think-black.svg)申请・咨询](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[电话咨询  \
050-1722-1733](tel:050-1722-1733)
 9:00-18:00【全年无休】／有翻译 [日本語での通話は  \
こちら](https://www.jcom.co.jp/service/#)

[![](https://www.jcom.co.jp/common_v10/images/icn-think-black.svg)신청·문의](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[신청·문의  \
050-1722-1733](tel:050-1722-1733)
 9:00-18:00【연중무휴】／통역 있음 [日本語での通話は  \
こちら](https://www.jcom.co.jp/service/#)

[![](https://www.jcom.co.jp/common_v10/images/icn-think-black.svg)Ứng dụng / Yêu cầu](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Ứng dụng / Yêu cầu  \
050-1722-1733](tel:050-1722-1733)
 9:00-18:00【mở cửa quanh năm】／có phiên dịch [日本語での通話は  \
こちら](https://www.jcom.co.jp/service/#)

[![](https://www.jcom.co.jp/common_v10/images/icn-think-black.svg)Solicitação/Consultas](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Solicitação/Consultas  \
050-1722-1733](tel:050-1722-1733)
 9:00-18:00【aberto todo o ano】／com intérprete [日本語での通話は  \
こちら](https://www.jcom.co.jp/service/#)

Current customers

[Check / Update  \
Your Contract  \
(JAPANESE ONLY)](https://www2.myjcom.jp/join/?ac_id=btm_change&sc_pid=common_bottom_join_02)

[![](https://www.jcom.co.jp/common_v10/images/icn-member.svg)Inquiries](https://www.jcom.co.jp/service/#)

[![](https://www.jcom.co.jp/common_v10/images/icn-member.svg)联系我们](https://www.jcom.co.jp/service/#)

[![](https://www.jcom.co.jp/common_v10/images/icn-member.svg)문의](https://www.jcom.co.jp/service/#)

[![](https://www.jcom.co.jp/common_v10/images/icn-member.svg)Hỏi đáp](https://www.jcom.co.jp/service/#)

[![](https://www.jcom.co.jp/common_v10/images/icn-member.svg)Consultar](https://www.jcom.co.jp/service/#)

Find the perfect  
plan for you

[Savings  \
 calculator](https://onlineshop.jcom.co.jp/Simulation/Simulation?sc_pid=common_bottom_simu_02)

Some properties offer free or discounted options!

Covered  
areas & properties

[](https://www.jcom.co.jp/service/#)

New Customers  
Inquiries

[Contact us online](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

J:COM will respond to you by email or phone.

Click here to contact us by phone (toll free)

[0120-989-970](tel:0120-989-970)

9:00-18:00 \[Open all year round\]

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

New Customers  
Inquiries

[Contact us online](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

J:COM will respond to you by email or phone.

Click here to contact us by phone (toll free)

[0120-989-970](tel:0120-989-970)

9:00-18:00 \[Open all year round\]

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

New Customers  
Inquiries

[Contact us online](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

J:COM will respond to you by email or phone.

Click here to contact us by phone (toll free)

[0120-989-970](tel:0120-989-970)

9:00-18:00 \[Open all year round\]

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

Current Customers  
Inquiries

Check / Update  
your contract here

[My page login](https://mypage.jcom.co.jp/)

* * *

Click here for  
Troubleshooting/FAQ

[Customer Support](https://cs.myjcom.jp/)

* * *

Click here to  
add or change service options

[Edit / Add to Your Plan](https://www2.myjcom.jp/join/)

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

Current Customers  
Inquiries

Check / Update  
your contract here

[My page login](https://mypage.jcom.co.jp/)

* * *

Click here for  
Troubleshooting/FAQ

[Customer Support](https://cs.myjcom.jp/)

* * *

Click here to  
add or change service options

[Edit / Add to Your Plan](https://www2.myjcom.jp/join/)

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

Current Customers  
Inquiries

Check / Update  
your contract here

[My page login](https://mypage.jcom.co.jp/)

* * *

Click here for  
Troubleshooting/FAQ

[Customer Support](https://cs.myjcom.jp/)

* * *

Click here to  
add or change service options

[Edit / Add to Your Plan](https://www2.myjcom.jp/join/)

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

User  
Application

For those who do not use J:COM TV

[J:COM TV  \
Shin Standard Plus  \
Application](https://r.jcom.jp/24KC2mS)

User J:COM TV

[J:COM TV  \
To Shin Standard Plus  \
Change of course](https://r.jcom.jp/0JLPOoy)

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

User  
Application

For those who do not use J:COM TV

[J:COM TV  \
Shin Standard Plus  \
Application](https://r.jcom.jp/24KC2mS)

User J:COM TV

[J:COM TV  \
To Shin Standard Plus  \
Change of course](https://r.jcom.jp/0JLPOoy)

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

User  
Application

For those who do not use J:COM TV

[J:COM TV  \
Shin Standard Plus  \
Application](https://r.jcom.jp/24KC2mS)

User J:COM TV

[J:COM TV  \
To Shin Standard Plus  \
Change of course](https://r.jcom.jp/0JLPOoy)

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

Confirming or changing the construction date

You can check, change, or cancel the schedule for on-site construction work on your My Page.

[My page login](https://mypage.jcom.co.jp/)

[Click here for instructions on how to check your My Page](https://cs.myjcom.jp/articles/support/6790bf45ad2e841b2e3362cf)

The installation date for J:COM NET Hikari (N) cannot be changed on My Page. Please contact [the customer center](https://www.jcom.co.jp/contactus/call_rgu.html#phone)
.

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

New Customers　  
Applications and Inquiries

[Applications and Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[0120-989-970](tel:0120-989-970)

Business hours: 9:00-18:00  
\[Open all year round\]

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

New Customers　  
Applications and Inquiries

[Applications and Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[0120-989-970](tel:0120-989-970)

Business hours: 9:00-18:00  
\[Open all year round\]

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

New Customers　  
Applications and Inquiries

[Applications and Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[0120-989-970](tel:0120-989-970)

Business hours: 9:00-18:00  
\[Open all year round\]

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

Current Customers　  
Inquiries

[Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[0120-989-970](tel:0120-989-970)

Business hours: 9:00-18:00  
\[Open all year round\]

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

Current Customers　  
Inquiries

[Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[0120-989-970](tel:0120-989-970)

Business hours: 9:00-18:00  
\[Open all year round\]

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

Current Customers　  
Inquiries

[Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[0120-989-970](tel:0120-989-970)

Business hours: 9:00-18:00  
\[Open all year round\]

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

新用户　  
申请・咨询

신규가입 고객　  
신청·문의

Đối với khách hàng mới tham gia　  
Ứng dụng / Yêu cầu

Novos assinantes　  
Solicitação/Consultas

电话咨询（有翻译）

전화 상담(통역 있음)

Tư vấn qua điện thoại (có phiên dịch)

Consulta por telefone (com intérprete)

[050-1722-1733](tel:050-1722-1733)

9:00-18:00 \[Open all year round\]

[日本語での通話はこちら](https://www.jcom.co.jp/service/#)

[申请・咨询](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[신청・문의](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Ứng dụng / Yêu cầu](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Solicitação/Consultas](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

新用户　  
申请・咨询

신규가입 고객　  
신청·문의

Đối với khách hàng mới tham gia　  
Ứng dụng / Yêu cầu

Novos assinantes　  
Solicitação/Consultas

电话咨询（有翻译）

전화 상담(통역 있음)

Tư vấn qua điện thoại (có phiên dịch)

Consulta por telefone (com intérprete)

[050-1722-1733](tel:050-1722-1733)

9:00-18:00 \[Open all year round\]

[日本語での通話はこちら](https://www.jcom.co.jp/service/#)

[申请・咨询](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[신청・문의](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Ứng dụng / Yêu cầu](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Solicitação/Consultas](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

新用户　  
申请・咨询

신규가입 고객　  
신청·문의

Đối với khách hàng mới tham gia　  
Ứng dụng / Yêu cầu

Novos assinantes　  
Solicitação/Consultas

电话咨询（有翻译）

전화 상담(통역 있음)

Tư vấn qua điện thoại (có phiên dịch)

Consulta por telefone (com intérprete)

[050-1722-1733](tel:050-1722-1733)

9:00-18:00 \[Open all year round\]

[日本語での通話はこちら](https://www.jcom.co.jp/service/#)

[申请・咨询](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[신청・문의](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Ứng dụng / Yêu cầu](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Solicitação/Consultas](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

会员　  
联系我们

이용 중인 고객　  
문의

Khách hàng đang sử dụng　  
Hỏi đáp

Utilizadores　  
Consultar

电话咨询（有翻译）

전화 상담(통역 있음)

Tư vấn qua điện thoại (có phiên dịch)

Consulta por telefone (com intérprete)

[050-1722-1733](tel:050-1722-1733)

9:00-18:00 \[Open all year round\]

[日本語での通話はこちら](https://www.jcom.co.jp/service/#)

[联系我们](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[문의](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[Hỏi đáp](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[Consultar](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

会员　  
联系我们

이용 중인 고객　  
문의

Khách hàng đang sử dụng　  
Hỏi đáp

Utilizadores　  
Consultar

电话咨询（有翻译）

전화 상담(통역 있음)

Tư vấn qua điện thoại (có phiên dịch)

Consulta por telefone (com intérprete)

[050-1722-1733](tel:050-1722-1733)

9:00-18:00 \[Open all year round\]

[日本語での通話はこちら](https://www.jcom.co.jp/service/#)

[联系我们](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[문의](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[Hỏi đáp](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[Consultar](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

会员　  
联系我们

이용 중인 고객　  
문의

Khách hàng đang sử dụng　  
Hỏi đáp

Utilizadores　  
Consultar

电话咨询（有翻译）

전화 상담(통역 있음)

Tư vấn qua điện thoại (có phiên dịch)

Consulta por telefone (com intérprete)

[050-1722-1733](tel:050-1722-1733)

9:00-18:00 \[Open all year round\]

[日本語での通話はこちら](https://www.jcom.co.jp/service/#)

[联系我们](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[문의](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[Hỏi đáp](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[Consultar](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[Close](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

日本語でのお問い合わせ

[海外にお住まいの方](https://cs.myjcom.jp/knowledgeDetail?an=004897372)

[日本国内にお住まいの方](https://www.jcom.co.jp/contactus/call_rgu.html)

[閉じる](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

日本語でのお問い合わせ

[海外にお住まいの方](https://cs.myjcom.jp/knowledgeDetail?an=004897372)

[日本国内にお住まいの方](https://www.jcom.co.jp/contactus/call_rgu.html)

[閉じる](https://www.jcom.co.jp/service/#)

\[Notes\]

*   It may take more than four days depending on the details of your contract, traffic conditions, use of landline phone number portability services, etc. Please understand this in advance.

Close

[シェアする](https://www.jcom.co.jp/service/)

[Tweet](https://twitter.com/share?ref_src=twsrc%5Etfw)

\[About the amount including tax\]

*   The listed amounts include tax unless otherwise specified.
*   Consumption tax differences may occur due to changes in the consumption tax rounding method under the invoice system.

1.  [J:COM Top](https://www.jcom.co.jp/en/)
    
2.  Service introduction

[![ページ上部へ戻る](https://www.jcom.co.jp/common_v10/images/PageTop.webp)](https://www.jcom.co.jp/service/#header)

[Return to top of page](https://www.jcom.co.jp/service/#header)

[Service Information](https://www.jcom.co.jp/en/?sc_pid=common_footer_unav_service_01)

[Online Shop](https://onlineshop.jcom.co.jp/?sc_pid=common_footer_unav_ols_01)

[Support Troubleshooting/FAQ](https://cs.myjcom.jp/?sc_pid=common_footer_unav_csmyjcom_01)

[Fun! J:COM TV program information/presents and benefits](https://www.myjcom.jp/?sc_pid=common_footer_unav_myjcom_01)

[My page Confirm/change contract details](https://mypage.jcom.co.jp/?sc_pid=common_footer_unav_mypage_01)

[Company website](https://www.jcom.co.jp/en/corporate/?sc_pid=common_footer_unav_corporate_01)

*   [![Twitter](https://www.jcom.co.jp/common_v10/images/icn-x.svg)](https://twitter.com/jcom_info?sc_pid=common_footer_sns_twitter_01)
    
*   [![instagram](https://www.jcom.co.jp/common_v10/images/icn-instagram.svg)](https://www.instagram.com/jcom.official/?sc_pid=common_footer_sns_instagram_01)
    
*   [![Facebook](https://www.jcom.co.jp/common_v10/images/icn-facebook.svg)](https://www.facebook.com/JCOM.ZAQ?sc_pid=common_footer_sns_facebook_01)
    
*   [![LINE](https://www.jcom.co.jp/common_v10/images/icn-line.svg)](https://www.jcom.co.jp/en/social/campaign/line/?sc_pid=common_footer_sns_line_01)
    
*   [![note](https://www.jcom.co.jp/common_v10/images/icn-note.svg)](https://note.jcom.co.jp/?sc_pid=common_footer_sns_note_01)
    

[Account list](https://www.jcom.co.jp/en/service/social/?sc_pid=common_footer_sns_list_01)

[![J:COM J:COM ANNIVERSARY: Making Newness a Natural Thing](https://www.jcom.co.jp/common_v10/images/logo-jcom-horizontal.svg)](https://www.jcom.co.jp/en/special/30th/)

*   [Site map](https://www.jcom.co.jp/en/sitemap/?sc_pid=common_footer_sitemap)
    
*   [Privacy portal](https://www.jcom.co.jp/en/corporate/site_info/privacy-portal/?sc_pid=common_footer_privacybasic)
    
*   [Privacy policy](https://www.jcom.co.jp/en/corporate/site_info/privacy_policy/?sc_pid=common_footer_privacy)
    
*   [Web Accessibility Initiatives](https://www.jcom.co.jp/en/corporate/site_info/accessibility/?sc_pid=common_footer_accessibility)
    
*   [Security policy](https://www.jcom.co.jp/en/corporate/site_info/security_policy/?sc_pid=common_footer_security)
    
*   [Social media policy](https://www.jcom.co.jp/en/corporate/site_info/socialmedia_policy/?sc_pid=common_footer_social)
    
*   [Human Rights Policy](https://www.jcom.co.jp/en/corporate/sustainability/well_being/hrp/?sc_pid=common_footer_hrp#policy)
    
*   [Regarding the use of cookie information, advertisement distribution, etc.](https://www.jcom.co.jp/en/corporate/site_info/privacy_policy/cookie/?sc_pid=common_footer_cookie)
    
*   [Inquiries](https://www.jcom.co.jp/en/contactus/?sc_pid=common_footer_contactus)
    
*   [Company website](https://www.jcom.co.jp/en/corporate/?sc_pid=common_footer_corporate)
    
*   [Careers](https://recruit.jcom.co.jp/?sc_pid=common_footer_recruit)
    
*   [Corporate customers](https://business.jcom.co.jp/?sc_pid=common_footer_business)
    
*   [About This Site](https://www.jcom.co.jp/en/site_info/?sc_pid=common_footer_siteinfo)
    

Copyright © JCOM Co., Ltd. All Rights Reserved.

[](https://www.jcom.co.jp/service/#)

Configure area

Please enter your postal code.

〒

No hyphen (-) required

Please select your housing type.

![icon](https://www.jcom.co.jp/common_v10/images/icn-apartment.svg)Apartments

![icon](https://www.jcom.co.jp/common_v10/images/icn-house.svg)Houses

Please select the appropriate age.  
(The plans available will change.)

Age 27 or older

​Under 26 years old

​Under 22 years old

Next

[](https://www.jcom.co.jp/service/#)

Configure area

Please enter your postal code.

〒

 

Please select your housing type.

![icon](https://www.jcom.co.jp/common_v10/images/icn-apartment.svg)Apartments

![icon](https://www.jcom.co.jp/common_v10/images/icn-house.svg)Houses

Next

[](https://www.jcom.co.jp/service/#)

Configure area

Please enter your postal code.

〒

 

Please select your housing type.

![icon](https://www.jcom.co.jp/common_v10/images/icn-apartment.svg)Apartments

![icon](https://www.jcom.co.jp/common_v10/images/icn-house.svg)Houses

Next

[](https://www.jcom.co.jp/service/#)

Configure area

Please enter your postal code.

〒

No hyphen (-) required

Next

[](https://www.jcom.co.jp/service/#)

Configure area

Please enter your postal code.

〒

 

Please select your housing type.

![icon](https://www.jcom.co.jp/common_v10/images/icn-apartment.svg)Apartments

![icon](https://www.jcom.co.jp/common_v10/images/icn-house.svg)Houses

Next

[](https://www.jcom.co.jp/service/#)

Check service

Please enter the postal code of your new address.

〒

 

Next

[](https://www.jcom.co.jp/service/#)

J:COM Telemedicine coverage area check

Please enter your postal code.

〒

No hyphen (-) required

Please select your housing type.

![icon](https://www.jcom.co.jp/common_v10/images/icn-apartment.svg)Apartments

![icon](https://www.jcom.co.jp/common_v10/images/icn-house.svg)Houses

Next

[](https://www.jcom.co.jp/service/#)

Select prefecture

Required Select prefecture.

Hokkaido and Tohoku

[Hokkaido](https://www.jcom.co.jp/service/#)
 [Miyagi Prefecture](https://www.jcom.co.jp/service/#)

Kanto

[Tokyo](https://www.jcom.co.jp/service/#)
 [Kanagawa Prefecture](https://www.jcom.co.jp/service/#)
 [Chiba Prefecture](https://www.jcom.co.jp/service/#)
 [Saitama Prefecture](https://www.jcom.co.jp/service/#)
 [Gunma Prefecture](https://www.jcom.co.jp/service/#)
 [Ibaraki Prefecture](https://www.jcom.co.jp/service/#)

Kansai

[Osaka Prefecture](https://www.jcom.co.jp/service/#)
 [Kyoto Prefecture](https://www.jcom.co.jp/service/#)
 [Wakayama Prefecture](https://www.jcom.co.jp/service/#)
 [Hyogo Prefecture](https://www.jcom.co.jp/service/#)

Kyushu/Yamaguchi

[Fukuoka Prefecture](https://www.jcom.co.jp/service/#)
 [Kumamoto Prefecture](https://www.jcom.co.jp/service/#)
 [Oita Prefecture](https://www.jcom.co.jp/service/#)
 [Yamaguchi Prefecture](https://www.jcom.co.jp/service/#)

[Return](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

Select city/ward/town

Required Please select your city.

Current selection: Tokyo

*   A
*   Ka
*   Sa
*   Ta
*   Na
*   Ha
*   Ma
*   Ya
*   Ra
*   Wa

[Akishima City](https://www.jcom.co.jp/service/#)
 [Akiruno City](https://www.jcom.co.jp/service/#)
 [Adachi Ward](https://www.jcom.co.jp/service/#)
 [Itabashi Ward](https://www.jcom.co.jp/service/#)
 [Inagi City](https://www.jcom.co.jp/service/#)
 [Edogawa Ward](https://www.jcom.co.jp/service/#)
 [Ota Ward](https://www.jcom.co.jp/service/#)

Contents of “Ka”

Regions starting with “A”

[Akishima City](https://www.jcom.co.jp/service/#)
 [Akiruno City](https://www.jcom.co.jp/service/#)
 [Adachi Ward](https://www.jcom.co.jp/service/#)
 [Itabashi Ward](https://www.jcom.co.jp/service/#)
 [Inagi City](https://www.jcom.co.jp/service/#)
 [Edogawa Ward](https://www.jcom.co.jp/service/#)
 [Ota Ward](https://www.jcom.co.jp/service/#)

Regions starting with “Ka”

Regions starting with “Sa”

Regions starting with “Ta”

Regions starting with “Na”

[Return](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

Configure area

〒 1070052

There are several possible areas for the postal code you entered.  
Please select your address from the list below

Please select 1 2 3 text text text

Configure

[Return](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

Configure area

〒 \-------

Please select the following address information.

  

Please select 1 2 3 text text text

Next

[Return](https://www.jcom.co.jp/service/#)

[](https://www.jcom.co.jp/service/#)

Check Gig coverage area

〒 1070052 (J:COM Machida/Kawasaki)

This is the coverage area of the J:COM NET 1G plan  
​

\* "J:COM NET 1Gig plan" is a 1Gig service that can be used with cable TV lines.

This is the coverage area for Hikari 10G/5G/1G plan  
​

\* Hikari is not available in some areas (gradually expanding service areas) [For more information, please contact us here.](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

Hikari 10G/5G/1G plan \*1  
coverage area is currently being expanded.

J:COM NET 1G plan \*2  
coverage area.

\*1 Hikari is not available in some areas (gradually expanding service areas) [For more information, please contact us here.](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

\*2 "J:COM NET 1Gig plan" is a 1Gig service that can be used with cable TV lines.

Hikari 10G/5G/1G plan  
J:COM NET 1G plan  
coverage area.

\*Not available in some areas (gradually expanding service areas) [For more information, please contact us here.](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

\* "J:COM NET 1Gig plan" is a 1Gig service that can be used with cable TV lines.

Outside the J:COM NET 1G plan  
coverage area. (Sequentially expanding the coverage area)

is in the 320M plan  
coverage area.

is in the 320M plan  
coverage area.

The J:COM NET 1G plan coverage area is gradually expanding.

[For detailed information on the coverage area, contact us here.](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

This is the service area of J:COM Oita (Oita Cable Telecom Co., Ltd.).  
[Please refer to the J:COM Oita (Oita Cable Telecom Co., Ltd.) homepage.](https://wwwjcom.oct-net.ne.jp/)
​

This is the Yokohama Cable Vision (YCV) service area.  
[Please refer to the Yokohama Cable Vision (YCV) homepage.](https://www.catv-yokohama.ne.jp/)
​

[Sign Up](https://www.jcom.co.jp/sim_contact/entry_request.php?refresh=new&net_service=1)

[Check the sign up process](https://www.jcom.co.jp/en/service/guide/sdu/)

Some areas may be outside the coverage area.

[View prices/plans](https://www.jcom.co.jp/en/service/net/)

Return

[](https://www.jcom.co.jp/service/#)

Check Gig coverage area

〒 1070052 (Machida/Kawasaki)

Hikari 10G/5G/1G plan  
J:COM NET 1G plan  
coverage area.

\* "J:COM NET 1Gig plan" is a 1Gig service that can be used with cable TV lines.

Hikari 10G/5G/1G plan  
coverage area.

Hikari 1G plan  
J:COM NET 1G plan  
coverage area.

\* "J:COM NET 1Gig plan" is a 1Gig service that can be used with cable TV lines.

Hikari 1G plan  
coverage area.

is in the 320M plan  
coverage area.

[Sign Up](https://www.jcom.co.jp/sim_contact/entry_request.php?refresh=new&net_service=1)

[Check the sign up process](https://www.jcom.co.jp/en/service/guide/sdu/)

Some areas may be outside the coverage area.

View prices/plans

[Savings calculator](https://onlineshop.jcom.co.jp/Simulation/Simulation)

Return

[](https://www.jcom.co.jp/service/#)

Check Gig coverage area

〒 1070052 

is out of the J:COM NET  
coverage area.

is in the J:COM WiMAX  
coverage area.

[Sign Up](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=wimax2p)

[Check the sign up process](https://www.jcom.co.jp/en/service/guide/sdu/)

Some areas may be outside the coverage area.

[View prices/plans](https://www.jcom.co.jp/en/service/wimax/)

Return

[](https://www.jcom.co.jp/service/#)

Check coverage areas

〒 \------- 

This is the service area of J:COM Oita (Oita Cable Telecom Co., Ltd.).  
[Please refer to the J:COM Oita (Oita Cable Telecom Co., Ltd.) homepage.](https://wwwjcom.oct-net.ne.jp/)
​

This is the Yokohama Cable Vision (YCV) service area.  
[Please refer to the Yokohama Cable Vision (YCV) homepage.](https://www.catv-yokohama.ne.jp/)
​

The following services are available.

   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-mobile.svg) ![J:COM MOBILE](https://www.jcom.co.jp/common_v10/images/logo-jcom-mobile.svg)](https://www.jcom.co.jp/en/service/mobile/)   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-electricity.svg) ![J:COM Denki](https://www.jcom.co.jp/common_v10/images/logo-jcom-electricity.svg)](https://www.jcom.co.jp/en/service/electricity/)
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-gas.svg) ![J:COM GAS](https://www.jcom.co.jp/common_v10/images/logo-jcom-gas.svg)](https://www.jcom.co.jp/en/service/gas/)
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-ssi.svg) ![J:COM Insurance](https://www.jcom.co.jp/common_v10/images/logo-jcom-ssi.svg)](https://www.jcom.co.jp/en/service/ssi/)
  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-telemedicine.svg) ![J:COM Telemedicine](https://www.jcom.co.jp/common_v10/images/logo-jcom-telemedicine.svg)](https://www.jcom.co.jp/en/service/telemedicine/)

The following services are [Price simulation](https://onlineshop.jcom.co.jp/Simulation/Simulation)
 in  
Please check the area.

  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-net.svg)\
\
![J:COM NET](https://www.jcom.co.jp/common_v10/images/logo-jcom-net.svg) Optical 10G/Optical 1G](https://www.jcom.co.jp/en/price/hikari-n/)  ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-tv.svg) Terrestrial digital/BS digital  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-phone.svg) Hikari Denwa](https://www.jcom.co.jp/en/price/hikari-n/phone-op/)

J:COM NET is provided via NTT line.

[Sign Up](https://onlineshop.jcom.co.jp/planSelect)

[Savings calculator](https://onlineshop.jcom.co.jp/Simulation/Simulation)

If you want local cable TV ​ ​[here](https://www.catv-jcta.jp/search/index)

Return

Some services may not be available depending on your region.

[](https://www.jcom.co.jp/service/#)

Check service

〒 1070052​

This is the service area of J:COM Oita (Oita Cable Telecom Co., Ltd.). Please refer to the [J:COM Oita (Oita Cable Television Co., Ltd.) website to confirm what services](https://wwwjcom.oct-net.ne.jp/)
 are provided.

This is the Yokohama Cable Vision (YCV) service area.  
[Please refer to the Yokohama Cable Vision (YCV) homepage.](https://www.catv-yokohama.ne.jp/)
​

The following services are available.

   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-tv.svg) ![J:COM TV](https://www.jcom.co.jp/common_v10/images/logo-jcom-tv.svg)](https://www.jcom.co.jp/en/service/tv/)   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-net.svg) ![J:COM NET](https://www.jcom.co.jp/common_v10/images/logo-jcom-net.svg)](https://www.jcom.co.jp/en/service/net/)
  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-mobile.svg) ![J:COM MOBILE](https://www.jcom.co.jp/common_v10/images/logo-jcom-mobile.svg)](https://www.jcom.co.jp/en/service/mobile/)
  
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-phone.svg) ![J:COM PHONE](https://www.jcom.co.jp/common_v10/images/logo-jcom-phone.svg)](https://www.jcom.co.jp/en/service/phone/)   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-ssi.svg) ![J:COM Insurance](https://www.jcom.co.jp/common_v10/images/logo-jcom-ssi.svg)](https://www.jcom.co.jp/en/service/ssi/)
  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-telemedicine.svg) ![J:COM Telemedicine](https://www.jcom.co.jp/common_v10/images/logo-jcom-telemedicine.svg)](https://www.jcom.co.jp/en/service/telemedicine/)

[J:COMご加入中の方  \
お引越しのお手続き](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=contact_move)

Return to postal code input

[](https://www.jcom.co.jp/service/#)

Check coverage areas

〒 1070052 (J:COM Machida/Kawasaki)

The following services are available.

   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-tv.svg) ![J:COM TV](https://www.jcom.co.jp/common_v10/images/logo-jcom-tv.svg)](https://www.jcom.co.jp/en/service/tv/)   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-net.svg) ![J:COM NET](https://www.jcom.co.jp/common_v10/images/logo-jcom-net.svg)](https://www.jcom.co.jp/en/service/net/)
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-mobile.svg) ![J:COM MOBILE](https://www.jcom.co.jp/common_v10/images/logo-jcom-mobile.svg)](https://www.jcom.co.jp/en/service/mobile/)
  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-electricity.svg) ![J:COM Denki](https://www.jcom.co.jp/common_v10/images/logo-jcom-electricity.svg)](https://www.jcom.co.jp/en/service/electricity/)
  
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-phone.svg) ![J:COM PHONE](https://www.jcom.co.jp/common_v10/images/logo-jcom-phone.svg)](https://www.jcom.co.jp/en/service/phone/)   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-gas.svg) ![J:COM GAS](https://www.jcom.co.jp/common_v10/images/logo-jcom-gas.svg)](https://www.jcom.co.jp/en/service/gas/)
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-ssi.svg) ![J:COM Insurance](https://www.jcom.co.jp/common_v10/images/logo-jcom-ssi.svg)](https://www.jcom.co.jp/en/service/ssi/)
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-home.svg) ![J:COM HOME](https://www.jcom.co.jp/common_v10/images/logo-jcom-home.svg)](https://www.jcom.co.jp/en/service/home/)
  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-telemedicine.svg) ![J:COM Telemedicine](https://www.jcom.co.jp/common_v10/images/logo-jcom-telemedicine.svg)](https://www.jcom.co.jp/en/service/telemedicine/)

[Application](https://onlineshop.jcom.co.jp/planSelect)
 ​ ​[Application](https://onlineshop.jcom.co.jp/planSelect)

[Check the sign up process](https://www.jcom.co.jp/en/service/guide/sdu/)

Savings calculator

Return

[](https://www.jcom.co.jp/service/#)

Check service

〒 1070052 (J:COM Machida/Kawasaki)

The following services are available.

   ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-tv.svg) ![J:COM TV](https://www.jcom.co.jp/common_v10/images/logo-jcom-tv.svg) ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-net.svg) ![J:COM NET](https://www.jcom.co.jp/common_v10/images/logo-jcom-net.svg)  ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-mobile.svg) ![J:COM MOBILE](https://www.jcom.co.jp/common_v10/images/logo-jcom-mobile.svg)  ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-electricity.svg) ![J:COM Denki](https://www.jcom.co.jp/common_v10/images/logo-jcom-electricity.svg)  
   ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-phone.svg) ![J:COM PHONE](https://www.jcom.co.jp/common_v10/images/logo-jcom-phone.svg) ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-gas.svg) ![J:COM GAS](https://www.jcom.co.jp/common_v10/images/logo-jcom-gas.svg)  ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-home.svg) ![J:COM HOME](https://www.jcom.co.jp/common_v10/images/logo-jcom-home.svg)

[J:COMご加入中の方  \
お引越しのお手続き](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=contact_move)

Return to postal code input

[](https://www.jcom.co.jp/service/#)

Check coverage areas

Please select your service.

Get your TV and Internet together!

 ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-tv.svg)  
![J:COM TV](https://www.jcom.co.jp/common_v10/images/logo-jcom-tv.svg)![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-net.svg)  
![J:COM NET](https://www.jcom.co.jp/common_v10/images/logo-jcom-net.svg) ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-phone.svg)  
![J:COM PHONE](https://www.jcom.co.jp/common_v10/images/logo-jcom-phone.svg)

[Savings calculator](https://onlineshop.jcom.co.jp/Simulation/Simulation)

Save more money on your monthly smartphone bill.

![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-mobile.svg)  
![J:COM MOBILE](https://www.jcom.co.jp/common_v10/images/logo-jcom-mobile.svg)

[Savings calculator](https://www.jcom.co.jp/en/service/mobile/simulator/)

Return

[](https://www.jcom.co.jp/service/#)

Check J:COM GAS coverage area

〒 1070052  ( J:COM ---- )​

![](https://www.jcom.co.jp/common_form/img/common/logo/logo_gas_osaka.png)

coverage area.

Some areas may be outside the coverage area.

![](https://www.jcom.co.jp/common_form/img/common/logo/logo_gas_tokyo.png)

coverage area.

Some areas may be outside the coverage area.

![](https://www.jcom.co.jp/common_form/img/common/logo/logo_gas_keiyo.png)

coverage area.

Some areas may be outside the coverage area.

is out of the J:COM GAS  
coverage area.

Energy Uchuu Co., Ltd. \[Koshigaya/Kasukabe area/Hasuda Minami area\] \[Toride/Abiko area\]  
If you live in an area where city gas is supplied,

you can use the

Tokyo Gas for J:COM "ZUTTO Gas" service.

[Learn more](https://www.jcom.co.jp/en/service/tokyo_gas/)

is out of the J:COM GAS  
coverage area.

Return

[](https://www.jcom.co.jp/service/#)

J:COM Telemedicine coverage area check

〒 1070052  ( J:COM ---- )​

J:COM Telemedicine  
coverage area.

Some areas may be outside the coverage area.

[See list of medical institutions](https://www.jcom.co.jp/en/service/telemedicine/clinic/)

[See prices](https://www.jcom.co.jp/en/service/telemedicine/price/)

Outside the J:COM Telemedicine  
coverage area.

Return

    

[](https://www.jcom.co.jp/service/#)

Notice to you
-------------

[Logout](https://www.jcom.co.jp/en/common/logout.html)

日本語

English
