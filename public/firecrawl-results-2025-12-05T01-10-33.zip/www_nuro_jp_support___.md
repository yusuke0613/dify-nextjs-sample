# サポートトップ

URL: https://www.nuro.jp/support/

---

![SONY](https://www.nuro.jp/support/faq/img/icon/logo-sony.png)

[![NURO光](https://www.nuro.jp/support/faq/img/icon/logo-br.svg)](https://www.nuro.jp/)

[![](https://www.nuro.jp/support/faq/img/icon/mk-iconlogin.svg)ログイン](https://www.nuro.jp/app/mypage/login)
[![](https://www.nuro.jp/support/faq/img/icon/mk-iconlogout.svg)ログアウト](javascript:void(0))

[マイページ](https://www.nuro.jp/app/mypage/login)

メニュー

**NURO 光 サポートサイト**

*   [会員サポートトップ](https://www.nuro.jp/support/)
    
*   [マイページにログイン](https://www.nuro.jp/app/mypage/login)
    
*   [カテゴリー一覧から探す](https://www.nuro.jp/support/faq/category/index.html)
    
*   [AI チャットに質問する](https://www.nuro.jp/support/chatbot/index.html)
    
*   [FAQ を検索する](https://support.nuro.jp/faqsupport/nuro/web/knowledgeList.html)
    
*   [ネットワーク設備の増強](https://www.nuro.jp/quality/network_enhancement/)
    
*   [障害・メンテナンス情報](https://www.nuro.jp/emerge/)
    
*   [サイトマップ](https://www.nuro.jp/support/faq/sitemap.html)
    

[NURO 光 総合トップ 新規タブで開く](https://www.nuro.jp/)

メニューを閉じる

会員サポート
======

![](https://www.nuro.jp/support/faq/img/support/mv-1st-pc.jpg?20231114)

**障害情報**

[\_\_dummy\_\_ 新規タブで開く](https://www.nuro.jp/support/__dummy__)

**重要なお知らせ**

\_\_dummy\_\_

サービスに関する重要なお知らせ
---------------

11/5 更新 閉じる

*   [**自動口座振替サービス ご請求方法の変更について**](https://support.nuro.jp/faqsupport/nuro/web/knowledge11126.html)
    
*   [**インターネット接続ができない場合の対処法について**](https://support.nuro.jp/faqsupport/nuro/web/knowledge11125.html)
    

お客さま番号

|     |     |
| --- | --- |
| 回線プラン |     |
| ご利用状況 |     |
| ONU機種名 |     |
| ご利用料金（前月） |     |
| お支払い方法 |     |

適用されている特典・キャンペーン情報は[特典カテゴリーページ](https://www.nuro.jp/support/faq/category/discounts/index.html)
にてご確認いただけます。

メニュー
----

*   [お困りごとを解決したい方\
    \
    ![](https://www.nuro.jp/support/faq/img/icon/icon-1st-01.svg?20231114)](https://www.nuro.jp/support/#anc-01)
    
*   [各種お手続きをご希望の方\
    \
    ![](https://www.nuro.jp/support/faq/img/icon/icon-1st-02.svg?20231114)](https://www.nuro.jp/support/#anc-02)
    
*   [障害メンテナンス情報\
    \
    ![](https://www.nuro.jp/support/faq/img/icon/icon-1st-03.svg?20231114)](https://www.nuro.jp/emerge/)
    
*   [ネット接続に関するお困りごと\
    \
    ![](https://www.nuro.jp/support/faq/img/icon/icon-1st-04.svg?20231114)](https://www.nuro.jp/support/faq/category/network/index.html)
    
*   [マイページにログインする\
    \
    ![](https://www.nuro.jp/support/faq/img/icon/icon-mypage.svg?20231114)](https://www.nuro.jp/app/mypage/login)
    
*   [開通工事のよくある質問\
    \
    ![](https://www.nuro.jp/support/faq/img/icon/icon-1st-08.svg?20231114)](https://www.nuro.jp/support/faq/category/construction/index.html)
    
*   [サポート動画一覧\
    \
    ![](https://www.nuro.jp/support/faq/img/icon/icon-1st-09.svg)](https://www.nuro.jp/support/faq/search/movie/index.html)
    

よくあるご質問
-------

*   [![Question](https://www.nuro.jp/support/faq/img/icon/icon-faq-01.svg?20231114)マイページへログインできない 新規タブで開く](https://support.nuro.jp/faqsupport/nuro/web/knowledge11088.html)
    
*   [![Question](https://www.nuro.jp/support/faq/img/icon/icon-faq-01.svg?20231114)解約または機器交換時のレンタル機器返却について知りたい 新規タブで開く](https://www.nuro.jp/support/faq/category/kaiyaku/return/index.html)
    
*   [![Question](https://www.nuro.jp/support/faq/img/icon/icon-faq-01.svg?20231114)お支払い方法の登録・変更について知りたい 新規タブで開く](https://support.nuro.jp/faqsupport/nuro/web/knowledge6921.html)
    
*   [![Question](https://www.nuro.jp/support/faq/img/icon/icon-faq-01.svg)ユーザーID・パスワードを忘れた場合の確認方法と再設定方法を知りたい 新規タブで開く](https://support.nuro.jp/faqsupport/nuro/web/knowledge6985.html)
    
*   [![Question](https://www.nuro.jp/support/faq/img/icon/icon-faq-01.svg?20231114)申し込みから開通までの流れ・目安が知りたい 新規タブで開く](https://support.nuro.jp/faqsupport/nuro/web/knowledge6969.html)
    
*   [![Question](https://www.nuro.jp/support/faq/img/icon/icon-faq-01.svg?20231114)ONU / TA 返却日の確認・変更 新規タブで開く](https://support.nuro.jp/faqsupport/nuro/web/knowledge9286.html)
    
*   [![Question](https://www.nuro.jp/support/faq/img/icon/icon-faq-01.svg?20231114)ONU / TA お届け日の確認・変更 新規タブで開く](https://support.nuro.jp/faqsupport/nuro/web/knowledge10881.html)
    

[FAQ を検索する](https://support.nuro.jp/faqsupport/nuro/web/knowledgeList.html)

カテゴリーから探す
---------

 [![](https://www.nuro.jp/support/faq/img/icon/icon-1st-08.svg?20231114) 光回線の工事日の予約・進捗などよくある質問はこちら](https://www.nuro.jp/support/faq/category/construction/index.html)

*   [接続設定\
    \
    ![](https://www.nuro.jp/support/faq/img/icon/icon-1st-category-01.svg?20231114)](https://www.nuro.jp/support/faq/category/connect/index.html)
    
*   [ネットにつながらない\
    \
    ![](https://www.nuro.jp/support/faq/img/icon/icon-1st-category-02.svg?20231114)](https://www.nuro.jp/support/faq/category/network/index.html)
    
*   [契約確認・変更\
    \
    ![](https://www.nuro.jp/support/faq/img/icon/icon-1st-category-03.svg?20231114)](https://www.nuro.jp/support/faq/category/contract/index.html)
    
*   [料金・支払い\
    \
    ![](https://www.nuro.jp/support/faq/img/icon/icon-1st-category-04.svg?20231114)](https://www.nuro.jp/support/faq/category/payment/index.html)
    
*   [でんわ・テレビ\
    \
    ![](https://www.nuro.jp/support/faq/img/icon/icon-1st-category-05.svg?20231114)](https://www.nuro.jp/support/faq/category/phone_tv/index.html)
    
*   [その他オプション\
    \
    ![](https://www.nuro.jp/support/faq/img/icon/icon-1st-category-06.svg?20231114)](https://www.nuro.jp/support/faq/category/option/index.html)
    
*   [割引・特典・  \
    キャッシュバック\
    \
    ![](https://www.nuro.jp/support/faq/img/icon/icon-1st-category-07.svg?20231114)](https://www.nuro.jp/support/faq/category/discounts/index.html)
    
*   [キャンセル・解約\
    \
    ![](https://www.nuro.jp/support/faq/img/icon/icon-1st-category-08.svg?20231114)](https://www.nuro.jp/support/faq/category/kaiyaku/index.html)
    

[他の内容を確認する](https://www.nuro.jp/support/faq/category/index.html)

マイページでのお手続き
-----------

*   [**キャッシュバックの受け取り** 新規タブで開く](https://support.nuro.jp/faqsupport/nuro/web/knowledge6963.html)
    
*   [**支払い方法の登録・変更** 新規タブで開く](https://support.nuro.jp/faqsupport/nuro/web/knowledge6921.html)
    
*   [**解約のお手続き** 新規タブで開く](https://support.nuro.jp/faqsupport/nuro/web/knowledge6958.html)
    
*   [**ID / PW確認・再発行** 新規タブで開く](https://support.nuro.jp/faqsupport/nuro/web/knowledge6985.html)
    
*   [**10Gへのアップグレード** 新規タブで開く](https://support.nuro.jp/faqsupport/nuro/web/knowledge10403.html)
    
*   [**開通工事予約・日程変更** 新規タブで開く](https://support.nuro.jp/faqsupport/nuro/web/knowledge7083.html)
    
*   [**会員情報（住所 / 氏名 / 電話番号 / 生年月日）の確認と変更の方法を知りたい** 新規タブで開く](https://support.nuro.jp/faqsupport/nuro/web/knowledge8911.html)
    
*   [**機器の集荷日/集荷先住所を確認・変更したい** 新規タブで開く](https://support.nuro.jp/faqsupport/nuro/web/knowledge9286.html)
    

お知らせ
----

[**NURO 光からのお知らせ**](https://www.nuro.jp/news_release/)

[**サポートからのお知らせ** 新規タブで開く](https://support.nuro.jp/faqsupport/nuro/web/general225.html?sortType=3)

[各種お問い合わせ先](https://support.nuro.jp/faqsupport/nuro/web/knowledge6739.html)

![](https://www.nuro.jp/support/faq/img/movieandillustration/img-banner-05.jpg)[](https://apps.apple.com/jp/app/nuro-%E5%85%89/id1518953646)
[](https://play.google.com/store/apps/details?id=jp.nuro)

**NURO 光 サービスサイト**

*   [NURO 光 総合トップ 新規タブで開く](https://www.nuro.jp/)
    
*   [NURO 光 2ギガ/10ギガ 新規タブで開く](https://www.nuro.jp/hikari/)
    
*   [NURO 光 20G 新規タブで開く](https://www.nuro.jp/s_plan/20gs/)
    

*   [会社情報 新規タブで開く](https://www.sonynetwork.co.jp/corporation/company/)
    
*   [個人情報保護 / 情報セキュリティ 新規タブで開く](https://www.sonynetwork.co.jp/corporation/safety/)
    
*   [ウェブサイトご利用条件 新規タブで開く](https://www.nuro.jp/siteinfo/nuro/)
    
*   [サイトマップ 新規タブで開く](https://www.nuro.jp/support/faq/sitemap.html)
    

[TOP](https://www.nuro.jp/support/#top)

[![NURO光](https://www.nuro.jp/support/faq/img/icon/logo-wh.svg)](https://www.nuro.jp/brand/)
 © Sony Network Communications Inc.

閉じる ![](https://event-va1.pubmatic.com/?adv=26162&cb=1764896656182&ref=https%3A%2F%2Fwww.nuro.jp%2Fsupport%2F&page=https%3A%2F%2Fwww.nuro.jp%2Fsupport%2F&order_id={{order_id}}&item_count={{item_count}}&value={{value}}&gdpr_consent=${GDPR_CONSENT_76}&gdpr=${GDPR}&us_privacy=${US_PRIVACY})   

![](https://bat.bing.com/action/0?ti=97114800&Ver=2&mid=f73393c3-c49e-43db-bbb2-7286dc03af90&bo=1&sid=53cf7010d17611f0808d4d0855450dda&vid=53cfb190d17611f0a9be695a8827db59&vids=1&msclkid=N&pi=0&lg=en-US@posix&sw=1280&sh=800&sc=24&nwd=1&tl=%E3%82%B5%E3%83%9D%E3%83%BC%E3%83%88%E3%83%88%E3%83%83%E3%83%97&p=https%3A%2F%2Fwww.nuro.jp%2Fsupport%2F&r=&lt=2127&evt=pageLoad&sv=2&cdb=AQAQ&rn=39089)

![](https://bat.bing.com/action/0?ti=343048056&Ver=2&mid=5a201568-ea9a-4400-930f-2570a870f646&bo=1&sid=53cf7010d17611f0808d4d0855450dda&vid=53cfb190d17611f0a9be695a8827db59&vids=0&msclkid=N&pi=0&lg=en-US@posix&sw=1280&sh=800&sc=24&nwd=1&tl=%E3%82%B5%E3%83%9D%E3%83%BC%E3%83%88%E3%83%88%E3%83%83%E3%83%97&p=https%3A%2F%2Fwww.nuro.jp%2Fsupport%2F&r=&lt=2127&evt=pageLoad&sv=2&cdb=AQAQ&rn=210182)

![](https://bat.bing.com/action/0?ti=343062041&Ver=2&mid=8407c287-72ca-462b-872c-4760a3cb34da&bo=1&sid=53cf7010d17611f0808d4d0855450dda&vid=53cfb190d17611f0a9be695a8827db59&vids=0&msclkid=N&pi=0&lg=en-US@posix&sw=1280&sh=800&sc=24&nwd=1&tl=%E3%82%B5%E3%83%9D%E3%83%BC%E3%83%88%E3%83%88%E3%83%83%E3%83%97&p=https%3A%2F%2Fwww.nuro.jp%2Fsupport%2F&r=&lt=2127&evt=pageLoad&sv=2&cdb=AQAQ&rn=625543)

![](https://ib.adnxs.com/setuid?entity=315&code=qapI6XXvP4vet4JS2TxHBSRG93tYCm-bgk0PT3I9dD0&consent=1)![](https://aw.dw.impact-ad.jp/ut/rep?u=4934&v=1&r=https%3A%2F%2Fwww.nuro.jp%2Fsupport%2F&t=1437)
