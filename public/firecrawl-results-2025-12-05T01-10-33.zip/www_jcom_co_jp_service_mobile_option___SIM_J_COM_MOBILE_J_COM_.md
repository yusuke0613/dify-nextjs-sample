# 
			オプションサービス | 格安スマホ・格安SIMならJ:COM MOBILE | J:COM
		

URL: https://www.jcom.co.jp/service/mobile/option/

---

[![あたらしいを、あたりまえに。 J:COM](https://www.jcom.co.jp/common_v10/images/logo-jcom-white.svg)](https://www.jcom.co.jp/?sc_pid=common_jcomlogo_01)

*   [はじめての方へ](https://www.jcom.co.jp/beginner/?sc_pid=globalnavi_beginner_01)
    
*   ご利用中の方
*   [オンラインショップ](https://onlineshop.jcom.co.jp/?sc_pid=globalnavi_ols_01)
    

J:COMサービスご利用中の方

[ご契約内容確認・変更  \
マイページログイン](https://mypage.jcom.co.jp/?sc_pid=common_mypage_01)
 [お困りごと解決・よくあるご質問  \
お客さまサポート](https://cs.myjcom.jp/?sc_pid=common_suppot_01)
 [もっとJ:COMを楽しみたい  \
テレビ番組情報／プレゼント・優待  \
Fun! J:COM](https://www.myjcom.jp/?sc_pid=common_myj_01)

    ![検索](https://www.jcom.co.jp/common_v10/images/snav-icn-search-submit.svg)

*   [あなたへの  \
    お知らせ](https://id.zaq.ne.jp/id/script/connect/authz_req/endpoint.seam?response_type=code&client_id=JCOM_COJP&redirect_uri=https%3A%2F%2Fwww.jcom.co.jp%2Fservice%2Fmobile%2Foption%2F&scope=http%3A%2F%2Fjcom.co.jp%2Fconnect%2Fprofile%2Fstandard_new&nonce=314038293&state=&prompt=)
    
*   [あなたへの  \
    お知らせ](https://www.jcom.co.jp/service/mobile/option/#)
    

Language

*   日本語
*   English
*   简体中文
*   한국어
*   Tiếng Việt
*   Português

*   サービス
*   [料金一覧](https://www.jcom.co.jp/price/)
    
*   [キャンペーン・  \
    特典](https://www.jcom.co.jp/campaign/)
    
*   お申し込み・  
    各種変更
*   サポート
*   企業サイト

[サービス紹介 トップ](https://www.jcom.co.jp/service/)

[テレビ](https://www.jcom.co.jp/service/tv/)
 [ネット](https://www.jcom.co.jp/service/net/)
 [スマホ](https://www.jcom.co.jp/service/mobile/)
 [でんき](https://www.jcom.co.jp/service/electricity/)
 [固定電話](https://www.jcom.co.jp/service/phone/)
 [ガス](https://www.jcom.co.jp/service/gas/)
 [ほけん](https://www.jcom.co.jp/service/ssi/)
 [ローン](https://www.jcom-financial.co.jp/)
 [防犯カメラ](https://www.jcom.co.jp/guide/starter/home_security/)
 [オンライン診療](https://www.jcom.co.jp/service/telemedicine/)
 [法人・自治体向けサービス![J:COM BUSINESS](https://www.jcom.co.jp/common_v10/images/logo_jcombusiness.webp)](https://business.jcom.co.jp/)

[お申し込み・お問い合わせ](https://www.jcom.co.jp/contactus/)

新規ご加入の方

[新規ご加入の方  \
お申し込み](https://onlineshop.jcom.co.jp/planSelect)

[新規ご加入の方  \
お問い合わせ](https://www.jcom.co.jp/contactus/#entry)

J:COMサービスご利用中の方

[ご利用中の方  \
各種お手続き](https://r.jcom.jp/eG4nLSC)

[お困りごと・お問い合わせ  \
（チャット）](https://prod8-live-chat.sprinklr.com/page?appId=67af27d73657336d345e4a96_app_9070639&did=CHAT_vivr_cojp_top&enableClose=true&skin=MODERN&userContext__c_679c8b53cb85b007fab0f6ea=DirectLink&utm_campaign=IVRSMS&utm_medium=referral&utm_source=did&webview=true&zoom=false)

あなたにピッタリのプランがすぐわかる

[料金シミュレーション](https://onlineshop.jcom.co.jp/Simulation/Simulation)

無料・特別料金の物件も！

対応エリア・物件をご案内

[企業サイト](https://www.jcom.co.jp/corporate/)

[企業理念](https://www.jcom.co.jp/corporate/philosophy_brand/)

[サステナビリティ](https://www.jcom.co.jp/corporate/sustainability/)

[中期経営計画](https://www.jcom.co.jp/corporate/managementplan/)

[ニュースリリース](https://newsreleases.jcom.co.jp/)

[会社案内](https://www.jcom.co.jp/corporate/company/)

[採用情報](https://recruit.jcom.co.jp/)

[サポート トップ](https://cs.myjcom.jp/)

[テレビ](https://cs.myjcom.jp/categories/support/67ab976bf07f5244a208cb97)
 [ネット](https://cs.myjcom.jp/categories/support/67ab9788f07f5244a208cced)
 [スマホ](https://cs.myjcom.jp/categories/support/67ab979df07f5244a208cdc9)
 [でんき](https://cs.myjcom.jp/categories/support/67ab97b5f07f5244a208cec9)
 [固定電話](https://cs.myjcom.jp/categories/support/67ab97abf07f5244a208ce4e)
 [ガス](https://cs.myjcom.jp/categories/support/67ab97b8f07f5244a208ceda)
 [ほけん](https://cs.myjcom.jp/categories/support/67ab97c5f07f5244a208cf2f)
 [オンライン診療](https://cs.myjcom.jp/categories/support/67ab97c2f07f5244a208cf1b)
 [ホームIoT](https://cs.myjcom.jp/categories/support/67ab97bcf07f5244a208cee6)
 [防犯カメラ](https://cs.myjcom.jp/categories/support/67ab97f5f07f5244a208d09b)

[J:COM STREAM](https://cs.myjcom.jp/categories/support/67ab97c9f07f5244a208cf49)

[えんかくサポート](https://cs.myjcom.jp/categories/support/67ab97faf07f5244a208d0c2)

[おうちサポート](https://cs.myjcom.jp/categories/support/67ab97d4f07f5244a208cf92)

[防災情報サービス](https://cs.myjcom.jp/categories/support/67ab97d8f07f5244a208cfa0)

[自転車生活サポート](https://cs.myjcom.jp/categories/support/67ab97e8f07f5244a208d023)

[J:COMブックス](https://cs.myjcom.jp/categories/support/67ab97e4f07f5244a208d003)

[WiMAX](https://cs.myjcom.jp/categories/support/67ab97f1f07f5244a208d074)

[障害・メンテナンス情報](https://information.myjcom.jp/maintenance_outage/)

各種お手続き

[パーソナルID](https://cs.myjcom.jp/categories/support/67ab9803f07f5244a208d113)

[料金・支払い](https://cs.myjcom.jp/categories/support/67ab9805f07f5244a208d139)

[引越し・建替え](https://cs.myjcom.jp/categories/support/67ab980cf07f5244a208d184)

[訪問・窓口](https://cs.myjcom.jp/categories/support/67ab980ff07f5244a208d1a4)

[契約関連](https://cs.myjcom.jp/categories/support/67ab9806f07f5244a208d150)

[休止・解約](https://cs.myjcom.jp/categories/support/67ab980cf07f5244a208d188)

[加入特典](https://cs.myjcom.jp/categories/support/67ab980df07f5244a208d18c)

[![あたらしいを、あたりまえに J:COM](https://www.jcom.co.jp/common_v10/images/logo-jcom-white.svg)](https://www.jcom.co.jp/?sc_pid=common_jcomlogo_01)

[![J:COM MOBILE](https://www.jcom.co.jp/common_v10/images/logo-jcom-mobile-bk.svg)](https://www.jcom.co.jp/service/mobile/)

*   料金
*   製品
*   SIM
*   オプション
*   初期設定サポート
*   [お申し込みの流れ](https://www.jcom.co.jp/service/mobile/usage/)
    
*   [ご利用中の方](https://cs.myjcom.jp/jcomMobile)
    
*   [法人の方](https://business.jcom.co.jp/smb/mobile/)
    

[料金　トップ](https://www.jcom.co.jp/service/mobile/price/)

*   [通話料・SMS通信料](https://www.jcom.co.jp/service/mobile/price/detail/)
    
*   [データ盛](https://www.jcom.co.jp/service/mobile/price/datamori/)
    
*   [お子さま向けプラン](https://www.jcom.co.jp/service/mobile/price/kids/)
    
*   [シニア向けプラン](https://www.jcom.co.jp/service/mobile/campaign/senior/)
    
*   [5Gについて](https://www.jcom.co.jp/service/mobile/special/5g/)
    
*   [3Gサービス終了について](https://www.jcom.co.jp/service/mobile/special/3g/)
    

[製品　トップ](https://www.jcom.co.jp/service/mobile/device/)

*   [iPhone 16e](https://www.jcom.co.jp/service/mobile/device/iphone_16e/)
    
*   [iPhone 15](https://www.jcom.co.jp/service/mobile/device/iphone_15/)
    
*   [Google Pixel 8a](https://www.jcom.co.jp/service/mobile/device/pixel_8a/)
    
*   [AQUOS sense10](https://www.jcom.co.jp/service/mobile/device/aquos_sense10/)
    
*   [Samsung Galaxy A25 5G](https://www.jcom.co.jp/service/mobile/device/galaxy_a25_5g/)
    
*   [BASIO active2](https://www.jcom.co.jp/service/mobile/device/basio_active2/)
    

[格安SIM　トップ](https://www.jcom.co.jp/service/mobile/device/sim/)

*   [eSIM](https://www.jcom.co.jp/service/mobile/device/sim/esim/)
    
*   [詳細](https://www.jcom.co.jp/service/mobile/device/sim/detail/)
    
*   [動作確認端末チェッカー](https://www.jcom.co.jp/service/mobile/device/sim/detail/device.html)
    
*   [SIMロック解除について](https://www.jcom.co.jp/service/mobile/device/sim/detail/simunlock.html)
    

[オプション　トップ](https://www.jcom.co.jp/service/mobile/option/)

*   [かけ放題](https://www.jcom.co.jp/service/mobile/option/kakehodai/)
    
*   [迷惑電話・メッセージブロック](https://www.jcom.co.jp/service/mobile/option/block/)
    
*   [家族のスマホ保険](https://www.jcom.co.jp/service/ssi/kazoku_sumaho/)
    
*   [安心端末保証60](https://www.jcom.co.jp/service/mobile/option/guaranty60/)
    
*   [AppleCare+ for iPhone](https://www.jcom.co.jp/service/mobile/device/support/applecare.html)
    
*   [あんしんフィルター for J:COM](https://www.jcom.co.jp/service/mobile/option/anshin_filter/)
    
*   [アクセサリーの追加購入](https://www.jcom.co.jp/service/mobile/option/accessories/add/)
    

[初期設定サポート　トップ](https://www.jcom.co.jp/service/mobile/support/)

*   [よくある質問](https://www.jcom.co.jp/service/mobile/support/faq/)
    
*   [スマホ乗り換え Q&A](https://www.jcom.co.jp/service/mobile/support/qa/)
    

[![あたらしいを、あたりまえに J:COM](https://www.jcom.co.jp/common_v10/images/logo-jcom.svg)](https://www.jcom.co.jp/)

*   サービス

*   [お申し込み](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=mobile_web_entry)
    
*   [お問い合わせ](https://www.jcom.co.jp/contactus/)
    
*   [はじめて  \
    の方へ](https://www.jcom.co.jp/beginner/)
    
*   ご利用中  
    の方
*   [オンライン  \
    ショップ](https://onlineshop.jcom.co.jp/)
    
*   ![検索する](https://www.jcom.co.jp/common_v10/images/fixed-nav-icn-search.svg)

    ![検索](https://www.jcom.co.jp/common_v10/images/snav-icn-search-submit.svg)

J:COMサービスご利用中の方

[ご契約内容確認・変更  \
マイページログイン](https://mypage.jcom.co.jp/)
 [お困りごと解決・よくあるご質問  \
お客さまサポート](https://cs.myjcom.jp/)
 [もっとJ:COMを楽しみたい  \
テレビ番組情報／プレゼント・優待  \
Fun! J:COM](https://www.myjcom.jp/)

[サービス紹介 トップ](https://www.jcom.co.jp/service/)

[テレビ](https://www.jcom.co.jp/service/tv/)
 [ネット](https://www.jcom.co.jp/service/net/)
 [スマホ](https://www.jcom.co.jp/service/mobile/)
 [でんき](https://www.jcom.co.jp/service/electricity/)
 [固定電話](https://www.jcom.co.jp/service/phone/)
 [ガス](https://www.jcom.co.jp/service/gas/)
 [ほけん](https://www.jcom.co.jp/service/ssi/)
 [ローン](https://www.jcom-financial.co.jp/)
 [防犯カメラ](https://www.jcom.co.jp/guide/starter/home_security/)
 [オンライン診療](https://www.jcom.co.jp/service/telemedicine/)
 [法人・自治体向けサービス![J:COM BUSINESS](https://www.jcom.co.jp/common_v10/images/logo_jcombusiness.webp)](https://business.jcom.co.jp/)

[![J:COM MOBILE](https://www.jcom.co.jp/common_v10/images/logo-jcom-mobile-bk.svg)](https://www.jcom.co.jp/service/mobile/)

*   料金
*   製品
*   SIM
*   オプション
*   初期設定サポート
*   [お申し込みの流れ](https://www.jcom.co.jp/service/mobile/usage/)
    
*   [ご利用中の方](https://cs.myjcom.jp/jcomMobile)
    
*   [法人の方](https://business.jcom.co.jp/smb/mobile/)
    

[料金　トップ](https://www.jcom.co.jp/service/mobile/price/)

*   [通話料・SMS通信料](https://www.jcom.co.jp/service/mobile/price/detail/)
    
*   [データ盛](https://www.jcom.co.jp/service/mobile/price/datamori/)
    
*   [お子さま向けプラン](https://www.jcom.co.jp/service/mobile/price/kids/)
    
*   [シニア向けプラン](https://www.jcom.co.jp/service/mobile/campaign/senior/)
    
*   [5Gについて](https://www.jcom.co.jp/service/mobile/special/5g/)
    
*   [3Gサービス終了について](https://www.jcom.co.jp/service/mobile/special/3g/)
    

[製品　トップ](https://www.jcom.co.jp/service/mobile/device/)

*   [iPhone 16e](https://www.jcom.co.jp/service/mobile/device/iphone_16e/)
    
*   [iPhone 15](https://www.jcom.co.jp/service/mobile/device/iphone_15/)
    
*   [Google Pixel 8a](https://www.jcom.co.jp/service/mobile/device/pixel_8a/)
    
*   [AQUOS sense10](https://www.jcom.co.jp/service/mobile/device/aquos_sense10/)
    
*   [Samsung Galaxy A25 5G](https://www.jcom.co.jp/service/mobile/device/galaxy_a25_5g/)
    
*   [BASIO active2](https://www.jcom.co.jp/service/mobile/device/basio_active2/)
    

[格安SIM　トップ](https://www.jcom.co.jp/service/mobile/device/sim/)

*   [eSIM](https://www.jcom.co.jp/service/mobile/device/sim/esim/)
    
*   [詳細](https://www.jcom.co.jp/service/mobile/device/sim/detail/)
    
*   [動作確認端末チェッカー](https://www.jcom.co.jp/service/mobile/device/sim/detail/device.html)
    
*   [SIMロック解除について](https://www.jcom.co.jp/service/mobile/device/sim/detail/simunlock.html)
    

[オプション　トップ](https://www.jcom.co.jp/service/mobile/option/)

*   [かけ放題](https://www.jcom.co.jp/service/mobile/option/kakehodai/)
    
*   [迷惑電話・メッセージブロック](https://www.jcom.co.jp/service/mobile/option/block/)
    
*   [家族のスマホ保険](https://www.jcom.co.jp/service/ssi/kazoku_sumaho/)
    
*   [安心端末保証60](https://www.jcom.co.jp/service/mobile/option/guaranty60/)
    
*   [AppleCare+ for iPhone](https://www.jcom.co.jp/service/mobile/device/support/applecare.html)
    
*   [あんしんフィルター for J:COM](https://www.jcom.co.jp/service/mobile/option/anshin_filter/)
    
*   [アクセサリーの追加購入](https://www.jcom.co.jp/service/mobile/option/accessories/add/)
    

[初期設定サポート　トップ](https://www.jcom.co.jp/service/mobile/support/)

*   [よくある質問](https://www.jcom.co.jp/service/mobile/support/faq/)
    
*   [スマホ乗り換え Q&A](https://www.jcom.co.jp/service/mobile/support/qa/)
    

*   ![メニュー](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/text-menu.svg)
*   ![J:COM mobile メニュー](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom-mobile/text-menu.svg)
*   [![料金シミュレーション](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom-mobile/text-sim.svg)](https://www.jcom.co.jp/service/mobile/simulator/)
    
*   [![お申し込み](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom-mobile/text-entry.svg)](https://www.jcom.co.jp/sim_contact/entry_request.php?&form_type=mobile_web_entry)
    
*   [![よくある質問　お問い合わせ](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom-mobile/text-faq.svg)](https://www.jcom.co.jp/service/mobile/support/faq/)
    

*   [![あたらしいを、あたりまえに　J:COM](https://www.jcom.co.jp/common_v10/images/logo-jcom-only-white.svg)](https://www.jcom.co.jp/)
     ![メニューを閉じる](https://www.jcom.co.jp/common_v10/images/sp-menu/menu-close-white.svg)
    
    [J:COMのサービス](https://www.jcom.co.jp/service/)
    
    *   [![テレビ](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-tv-item.svg)](https://www.jcom.co.jp/service/tv/)
        
    *   [![ネット](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-net-item.svg)](https://www.jcom.co.jp/service/net/)
        
    *   [![スマホ](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-mobile-item.svg)](https://www.jcom.co.jp/service/mobile/)
        
    
    *   [![電気](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-electricity-item.svg)](https://www.jcom.co.jp/service/electricity/)
        
    *   [![固定電話](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-phone-item.svg)](https://www.jcom.co.jp/service/phone/)
        
    *   [![ガス](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-gas-item.svg)](https://www.jcom.co.jp/service/gas/)
        
    *   [![ほけん](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-ssi-item.svg)](https://www.jcom.co.jp/service/ssi/)
        
    *   [ローン](https://www.jcom-financial.co.jp/)
        
    *   [![ホームIoT](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-home-item.svg)](https://www.jcom.co.jp/service/home/)
        
    *   [防犯カメラ](https://www.jcom.co.jp/guide/starter/home_security/)
        
    *   [![オンライン診療](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-telemedicine-item.svg)](https://www.jcom.co.jp/service/telemedicine/)
        
    
    [法人・自治体向けサービス  \
    ![J:COM BUSINESS](https://www.jcom.co.jp/common_v10/images/logo_jcombusiness.webp)](https://business.jcom.co.jp/)
    
    サービス一覧
    
    [料金一覧](https://www.jcom.co.jp/price/)
     [キャンペーン・特典](https://www.jcom.co.jp/campaign/)
     [サポート](https://cs.myjcom.jp/jcomMobile)
     [お申し込み・各種変更](https://www.jcom.co.jp/contactus/)
    
        ![検索](https://www.jcom.co.jp/common_v10/images/snav-icn-search-submit-sp.svg)
    
    [J:COM トップ](https://www.jcom.co.jp/)
    
    *   [サービス情報](https://www.jcom.co.jp/)
        
    *   [オンライン  \
        ショップ](https://onlineshop.jcom.co.jp/)
        
    *   [サポート](https://cs.myjcom.jp/jcomMobile)
        
    *   [Fun! J:COM](https://www.myjcom.jp/)
        
    *   [マイページ](https://mypage.jcom.co.jp/)
        
    *   [企業サイト](https://www.jcom.co.jp/corporate/)
        
    
*   [![J:COM MOBILE](https://www.jcom.co.jp/common_v10/images/icn-jcom-mobile.svg)スマホ](https://www.jcom.co.jp/service/mobile/)
     ![メニューを閉じる](https://www.jcom.co.jp/common_v10/images/sp-menu/menu-close-white.svg)
    
    [![](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom-mobile/slide/menu/mv-middle.webp)\
    \
    ずーっとおトク\
    \
    トップ](https://www.jcom.co.jp/service/mobile/)
    
    *   料金
        
        *   [料金 トップ](https://www.jcom.co.jp/service/mobile/price/)
            
        *   [通話料・SMS通信料](https://www.jcom.co.jp/service/mobile/price/detail/)
            
        *   [データ盛](https://www.jcom.co.jp/service/mobile/price/datamori/)
            
        *   [お子さま向けプラン](https://www.jcom.co.jp/service/mobile/price/kids/)
            
        *   [シニア向けプラン](https://www.jcom.co.jp/service/mobile/campaign/senior/)
            
        *   [5Gについて](https://www.jcom.co.jp/service/mobile/special/5g/)
            
        *   [3Gサービス終了について](https://www.jcom.co.jp/service/mobile/special/3g/)
            
        
    *   製品
        
        *   [製品 トップ](https://www.jcom.co.jp/service/mobile/device/)
            
        *   [iPhone 16e](https://www.jcom.co.jp/service/mobile/device/iphone_16e/)
            
        *   [iPhone 15](https://www.jcom.co.jp/service/mobile/device/iphone_15/)
            
        *   [Google Pixel 8a](https://www.jcom.co.jp/service/mobile/device/pixel_8a/)
            
        *   [AQUOS sense10](https://www.jcom.co.jp/service/mobile/device/aquos_sense10/)
            
        *   [Samsung Galaxy A25 5G](https://www.jcom.co.jp/service/mobile/device/galaxy_a25_5g/)
            
        *   [BASIO active2](https://www.jcom.co.jp/service/mobile/device/basio_active2/)
            
        
    *   SIM
        
        *   [格安SIM トップ](https://www.jcom.co.jp/service/mobile/device/sim/)
            
        *   [eSIM](https://www.jcom.co.jp/service/mobile/device/sim/esim/)
            
        *   [詳細](https://www.jcom.co.jp/service/mobile/device/sim/detail/)
            
        *   [動作確認端末チェッカー](https://www.jcom.co.jp/service/mobile/device/sim/detail/device.html)
            
        *   [SIMロック解除について](https://www.jcom.co.jp/service/mobile/device/sim/detail/simunlock.html)
            
        
    *   オプション
        
        *   [オプション トップ](https://www.jcom.co.jp/service/mobile/option/)
            
        *   [かけ放題](https://www.jcom.co.jp/service/mobile/option/kakehodai/)
            
        *   [迷惑電話・メッセージブロック](https://www.jcom.co.jp/service/mobile/option/block/)
            
        *   [家族のスマホ保険](https://www.jcom.co.jp/service/ssi/kazoku_sumaho/)
            
        *   [安心端末保証60](https://www.jcom.co.jp/service/mobile/option/guaranty60/)
            
        *   [AppleCare+ for iPhone](https://www.jcom.co.jp/service/mobile/device/support/applecare.html)
            
        *   [あんしんフィルター for J:COM](https://www.jcom.co.jp/service/mobile/option/anshin_filter/)
            
        *   [アクセサリーの追加購入](https://www.jcom.co.jp/service/mobile/option/accessories/add/)
            
        
    *   初期設定サポート
        
        *   [初期設定サポート　トップ](https://www.jcom.co.jp/service/mobile/support/)
            
        *   [よくある質問](https://www.jcom.co.jp/service/mobile/support/faq/)
            
        *   [スマホ乗り換え Q&A](https://www.jcom.co.jp/service/mobile/support/qa/)
            
        
    *   [お申し込みの流れ](https://www.jcom.co.jp/service/mobile/usage/)
        
    *   [ご利用中の方](https://cs.myjcom.jp/jcomMobile)
        
    *   [法人の方](https://business.jcom.co.jp/smb/mobile/)
        
    

オプション・その他サービス
=============

[オプションサービス](https://www.jcom.co.jp/service/mobile/option/#option_services)

[通話オプション](https://www.jcom.co.jp/service/mobile/option/#call_options)

[データオプション](https://www.jcom.co.jp/service/mobile/option/#data_options)

[アクセサリー](https://www.jcom.co.jp/service/mobile/option/#accessories)

オプションサービス
---------

### かけ放題オプション

有料

1回あたり5分以内または60分以内の国内通話料金が、何度でも無料になるサービスです。

[かけ放題オプションについて  \
詳しくはこちら](https://www.jcom.co.jp/service/mobile/option/kakehodai/index.html)

### 迷惑電話・メッセージブロック

有料

月額300円（税込330円）

振り込め詐欺・悪質な営業などの迷惑電話や迷惑メッセージ（SMS）を警告表示するので、あんしんしてスマホをご利用いただけます。

[迷惑電話・メッセージブロックについて詳しくはこちら](https://www.jcom.co.jp/service/mobile/option/block/)

### 安心端末保証60

有料

Google Pixel 8a : 月額800円(税込880円)  
その他android端末★1 : 月額600円(税込660円)

故障、破損、水濡れなどの万が一のトラブルに、電話1本で交換機をお届けします。

*   J:COM MOBILE端末購入と同時のご加入が必要。
*   安心端末保証48とは対象端末、保証内容が異なります。

*   AQUOS sense10、Samsung Galaxy A25 5G、AQUOS sense9、AQUOS sense8、Galaxy A23 5G、BASIO active2が対象（BASIO active、AQUOS sense8、Galaxy A23 5Gは新規受付終了、AQUOS sense9は入荷待ちのため販売停止）

[安心端末保証60について  \
詳しくはこちら](https://www.jcom.co.jp/service/mobile/option/guaranty60/)

### 安心端末保証48

有料

月額500円（税込550円）

故障、破損、水濡れなどの万が一のトラブルに、電話1本で交換機をお届けします。

*   新規受付を終了いたしました。
*   安心端末保証60とは対象端末、保証内容が異なります。

[安心端末保証48について  \
詳しくはこちら](https://www.jcom.co.jp/service/mobile/option/guaranty/)

### AppleCare+ for iPhone

有料

あなたのiPhoneを守ろう。  
AppleCare+for iPhoneに加入すると、修理保証とテクニカルサポートがiPhoneの購入日から無期限に延長されます。さらに、過失や事故による損傷に対する修理などのサービスを、画面の損傷は1回につき3,400円（税込3,740円）、そのほかの損傷は1回につき11,800円（税込12,980円）のサービス料で最大2回まで受けることができます。

[AppleCare+ for iPhoneについて  \
詳しくはこちら](https://www.jcom.co.jp/service/mobile/device/support/applecare.html)

### 端末保証 for iPhone

有料

月額600円（税込660円）

故障、破損、水濡れなどの万が一のトラブルに、電話1本で交換機をお届けします。  
また、端末を紛失した際にJ:COMから遠隔操作による各種サポートを受けることができます。

端末1台につき

[端末保証 for iPhoneについて  \
詳しくはこちら](https://www.jcom.co.jp/service/mobile/option/guaranty/iphone/)

### あんしんフィルター for J:COM

無料

お子さまを危険なサイトやアプリから守るためのスマートフォン向けフィルタリングサービスです。月額無料でご利用いただけます。

[あんしんフィルター for J:COMについて詳しくはこちら](https://www.jcom.co.jp/service/mobile/option/anshin_filter/)

### データ通信カウントなしで動画視聴

無料

Wi-Fiがない外出先でも「J:COM STREAM」アプリ経由で動画視聴すれば、データ消費ゼロで動画を楽しむことができます。

[データ通信カウントなしで動画視聴について詳しくはこちら](https://www.jcom.co.jp/service/mobile/option/packet_free/)

通話オプション
-------

|     |     |     |
| --- | --- | --- |  
| サービス名称 |     | 料金  |
| 標準オプション  <br>（申し込み不要）<br><br>通話料・通信料は  <br>別途かかります。 | SMS※1 | 月額無料 |
| ボイスメール※2 | 無料  |
| 発信者番号表示サービス※3 | 無料  |
| 番号通知リクエストサービス※4 | 無料  |
| 着信転送サービス※5 | 無料  |
| 迷惑SMSブロック | 無料  |
| 有料オプション  <br>（申し込み必要） | 割込通話サービス※6 | 200円(税込220円)/月 |
| お留守番サービスEX※7 | 300円(税込330円)/月 |
| 迷惑電話撃退サービス※8 | 100円(税込110円)/月 |

J:COM MOBILEをご利用中の方

[オプション追加・変更](https://mypage.jcom.co.jp/)

データオプション
--------

|     |     |
| --- | --- | 
| サービス名称 | 料金  |
| 追加データ | 500MB：200円(税込220円)  <br>1GB    ：300円(税込330円)<br><br>使用有効期限は、<Aプランの場合>購入日を含む90日間となります。  <br><br>保有できるデータ容量には上限（100GB）あり。繰り越し上限に達した場合、データの追加購入は不可。 |
| 「J:COM STREAM」アプリ | データ通信量カウントなし※9 |
| メールアドレス | SMS（Gmail利用可能)<br><br>キャリアとしてのメールアドレスは提供していません。 |
| あんしんフィルター for J:COM※10 | 無料  |
| テザリング（テザリング機能搭載の端末が必要です。) | 無料<br><br>お持ちの端末にテザリング機能がある場合。 |
| ギガぞうWi-Fi | 無料（J:COM MOBILE特典）<br><br>※会員登録が必要となります。[詳しくはこちら](https://gigazo.jp/jcom/) |

アクセサリー
------

アクセサリーはスマホの初回購入時にWebからお申し込みいただけます。

アクセサリーの追加購入について

後から追加で購入いただくことも可能です。

後日追加購入いただく際は、お電話でのお申込みが必要。また、初回購入時と価格が異なる場合あり。

[アクセサリーの追加購入について詳細はこちら](https://www.jcom.co.jp/service/mobile/option/accessories/add/)

[J:COM MOBILEの端末  \
について  \
詳細はこちら](https://www.jcom.co.jp/service/mobile/device/)

[J:COM MOBILE お申し込み](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=mobile_web_entry&sc_pid=cv_mobile_entry_1)

[お電話でお問い合わせ（通話無料）0120-919-988](tel:0120-919-988)
 9:00～18:00［年中無休］

よくあるご質問
-------

契約や機種変更など、手続きが面倒。

WEBからかんたんにお申し込みいただけます。ご希望により訪問サポートを受けることもできます。

![](https://www.jcom.co.jp/service/mobile/usage/images/img_qa_02.jpg)

J:COM MOBILEは、WEBからお申し込み手続きができます。ご自宅にいながら手続きが完了するので、ショップに出向いて長時間待つ必要はありません。

スマホがお手元に届いてからは、ご希望の方には無料のサポートを受けていただくこともできます。初期設定はもちろん、スマホの使い方も丁寧に説明します。

[初期設定サポートについて](https://www.jcom.co.jp/service/mobile/support/)

*   「J:COM MOBILE Dプラン SIMカード」をお申し込みの方は対象外です。

領収書は発行してもらえますか？

ご契約時にかかる初期費用について、詳しくは下記リンク先をご覧ください。

[初期費用について はこちら](https://cs.myjcom.jp/knowledgeDetail?an=000004608#a2)

加入後のサポートを知りたい

お電話やチャットでのお問合せから、サポート情報が掲載されたホームページでのご案内など、幅広いお問合せ方法をご用意しております。また、えんかくサポート（月額 550円(税込)）にご加入いただくことで、オペレータによる遠隔操作での対応もご用意しております。

[えんかくサポートについて](https://www.jcom.co.jp/service/omakase/)

加入中のプランはどこで確認できますか？

J:COM MOBILEでご契約中のプランは、マイページで確認できます。

[マイページはこちら](https://mypage.jcom.co.jp/)

[マイページでの確認手順について](https://cs.myjcom.jp/knowledgeDetail?an=003068831)

通話明細はどこで確認できますか？

J:COM MOBILEの通話明細は、マイページで確認できます。

[マイページはこちら](https://mypage.jcom.co.jp/)

[マイページでの確認手順について](https://cs.myjcom.jp/knowledgeDetail?an=002465855)

電話帳などのデータを新しいスマホに移したいのですが、どうすればいいでしょうか？

難しい設定もご自宅で解決。スマホの初期設定は「えんかくサポート」でおまかせ！

J:COM MOBILEでは、ご希望の方には初期設定や電話帳データの移行、使い方説明などを、無料のサポートにて丁寧に説明します。

[詳細はこちら](https://www.jcom.co.jp/service/mobile/support/)

今使っているメールアドレスは、J:COM MOBILEのスマホでも引き続き使用できますか？

Gメールなどのフリーメールをお使いの場合、新しい端末からログイン、もしくは設定いただくことで引き続きご利用いただけます。

なお、一部の通信会社から発行されたメールアドレス（ドメイン）をお使いの場合は、ご利用いただけなくなります。

*   キャリアを解約後も、キャリアメールを引き続きご利用いただけるサービスがございます。詳しくは、[こちら](https://cs.myjcom.jp/knowledgeDetail?an=003423343)
    をご参照ください。

J:COM MOBILEでは、メールアドレスの発行は行っておりませんので、あらかじめGメールなどのフリーメールに移行いただくことをお勧めします。

使いきれなかったデータ通信量の繰り越しはできますか？

消費されなかったデータ通信量は翌月に自動繰り越しされます。

![](https://www.jcom.co.jp/service/mobile/price/images_v10/data_carry.webp)

※余った分は翌月末まで有効

上限超えた場合、ご加入のプランにより1Mbpsまたは200kbpsに制限されます。ご契約プランのデータ通信量だけではなく、追加購入したデータ通信量も翌月に繰り越しいただけます。

有効期限など、詳しくは[こちら](https://cs.myjcom.jp/knowledgeDetail?an=000002838)
をご確認ください。

新しい端末でもLINEを引き続き利用できますか？

適切に設定・お手続きいただくことで、新しい端末でも引き続きご利用いただけます。

アカウントの移行（引き継ぎ）方法につきましては、定期的にセキュリティが強化されておりますので、LINEの公式ブログより最新情報をご確認のうえ、お手続きください。  
（※機種変更前に設定が必要な場合がありますので、ご注意ください）

[LINEのアカウントを引き継ぐ方法（2017/7時点）](https://official-blog-ja.line.me/archives/53494977.html)

【注釈・注意事項】

*   長文SMS対応の一部機種では、文字数に応じてSMS送信料の変動あり。詳細は、「J:COM MOBILE契約約款」まで。長文SMSは、受信先の機種により分割受信となる場合や、宛先により送信不可となる場合あり。SMS送信は、一日あたり200通まで。
*   伝言の録音可能件数および、保持時間は、J:COMホームページまで。
*   非通知設定からの着信など、番号が表示されない場合あり。
*   サービス起動・停止など、ガイダンスへ接続された場合、通話料が発生。ご利用中でも、相手からの番号を接続する場合あり。
*   au国際電話および、一部の事業者での転送はご利用いただけない場合あり。「お留守番サービスEX」と同時のご利用は不可。ほかの電話機からの遠隔操作の「フル転送サービス開始」（090-4444-1428）について2022年5月13日（金）をもってサービス提供終了。
*   通話料は保留中も発生し、発信者側のご負担。「割込通話サービス」と「番号通知リクエストサービス」を同時に開始すると、非通知からの着信を受けた場合、「番号通知リクエストサービス」が優先。「割込通話サービス」と「迷惑電話撃退サービス」を同時に開始すると、「迷惑電話撃退サービス」が優先。
*   伝言の再生などを行った場合、通話料が発生。「お留守番サービスEX」はKDDI株式会社の登録商標。
*   一部登録できない番号あり。
*   各対象アプリ経由でのデータ通信時に限る(検索など、操作によっては一部通信量が発生する場合あり)。  
    「J:COM MOBILE Aプラン」およびJ:COM指定サービスへのご加入が必要。
*   青少年が安全に安心してインターネットを利用できる環境の整備等に関する法律」により、「J:COM MOBILE AプランST」の満18歳未満のお客さまのご利用にあたり、フィルタリングサービスの設定が必要。「J:COM MOBILE AプランSU」の場合、満18歳未満の方はご利用不可。

*   AプランSTご契約の場合、ご利用可能なオプションサービス。Dプランをご契約の場合、内容・料金などが異なる。

【ギガぞうについて】

*   株式会社ワイヤ・アンド・ワイヤレスとのご契約により利用可能。
*   端末によっては一部利用できない場合あり。
*   施設内でも利用可能な場所は限られる。また、店舗や車両などにより、利用できない場合あり。
*   別途利用登録が必要。

【迷惑電話・メッセージブロック】

*   本サービスは、対象端末への発着信についてトビラシステムズ㈱の提供するデータベースに基づき、当該発着信が迷惑電話、迷惑SMSの可能性の高い電話番号であるかの判定結果を提供。
*   ご利用には、インターネット接続環境、対応端末(Android 10.0以上またはiOS 15.0以上) 、J:COMパーソナルIDの作成、MY J:COMアプリのインストールおよび初期設定が必要。ご利用にかかる通信料はお客さま負担。
*   端末により、お使いいただける機能や画面イメージが異なる。接続環境等により、利用できない場合あり。
*   すべての迷惑電話等が正しく判定されること、公共施設や企業等の名称が正しく表示されることを保証するものではない。
*   発信者番号の通知がない場合(「非通知設定」、「公衆電話」、「通知不可能」等)は迷惑電話であるかの判定結果の提供不可。
*   トビラシステムズ（株）は、警察から提供された電話番号などの情報をもとに構築した迷惑電話番号リスト（警察提供の番号、利用者の拒否登録番号、トビラシステムズ（株）独自調査番号）を提供する会社。
*   ご利用にはJ:COM MOBILE AプランST/SUへご加入が必要。

閉じる

[シェアする](https://www.jcom.co.jp/service/mobile/option/)

[Tweet](https://twitter.com/share?ref_src=twsrc%5Etfw)

【税込金額について】

*   インボイス制度下における消費税の端数処理方法変更により消費税差額が生じる場合があります。

1.  [J:COM トップ](https://www.jcom.co.jp/)
    
2.  [サービス紹介](https://www.jcom.co.jp/service/)
    
3.  [格安スマホなら J:COM MOBILE（モバイル）](https://www.jcom.co.jp/service/mobile/)
    
4.  オプション・他（格安スマホ・格安SIM）

[![ページ上部へ戻る](https://www.jcom.co.jp/common_v10/images/PageTop.webp)](https://www.jcom.co.jp/service/mobile/option/#header)

[ページトップへ戻る](https://www.jcom.co.jp/service/mobile/option/#header)

[サービス情報](https://www.jcom.co.jp/?sc_pid=common_footer_unav_service_01)

[オンラインショップ](https://onlineshop.jcom.co.jp/?sc_pid=common_footer_unav_ols_01)

[サポートお困りごと解決・よくあるご質問](https://cs.myjcom.jp/?sc_pid=common_footer_unav_csmyjcom_01)

[Fun! J:COMテレビ番組情報／プレゼント・優待](https://www.myjcom.jp/?sc_pid=common_footer_unav_myjcom_01)

[マイページ契約内容確認・変更](https://mypage.jcom.co.jp/?sc_pid=common_footer_unav_mypage_01)

[企業サイト](https://www.jcom.co.jp/corporate/?sc_pid=common_footer_unav_corporate_01)

*   [![Twitter](https://www.jcom.co.jp/common_v10/images/icn-x.svg)](https://twitter.com/jcom_info?sc_pid=common_footer_sns_twitter_01)
    
*   [![instagram](https://www.jcom.co.jp/common_v10/images/icn-instagram.svg)](https://www.instagram.com/jcom.official/?sc_pid=common_footer_sns_instagram_01)
    
*   [![Facebook](https://www.jcom.co.jp/common_v10/images/icn-facebook.svg)](https://www.facebook.com/JCOM.ZAQ?sc_pid=common_footer_sns_facebook_01)
    
*   [![LINE](https://www.jcom.co.jp/common_v10/images/icn-line.svg)](https://www.jcom.co.jp/social/campaign/line/?sc_pid=common_footer_sns_line_01)
    
*   [![note](https://www.jcom.co.jp/common_v10/images/icn-note.svg)](https://note.jcom.co.jp/?sc_pid=common_footer_sns_note_01)
    

[アカウント一覧](https://www.jcom.co.jp/service/social/?sc_pid=common_footer_sns_list_01)

[![あたらしいを、あたりまえに J:COMはおかげさまで30周年。 J:COM 30th ANNIVERSARY](https://www.jcom.co.jp/common_v10/images/logo-jcom-horizontal.svg)](https://www.jcom.co.jp/special/30th/)

*   [サイトマップ](https://www.jcom.co.jp/sitemap/?sc_pid=common_footer_sitemap)
    
*   [プライバシーポータル](https://www.jcom.co.jp/corporate/site_info/privacy-portal/?sc_pid=common_footer_privacybasic)
    
*   [プライバシーポリシー](https://www.jcom.co.jp/corporate/site_info/privacy_policy/?sc_pid=common_footer_privacy)
    
*   [ウェブアクセシビリティの取り組み](https://www.jcom.co.jp/corporate/site_info/accessibility/?sc_pid=common_footer_accessibility)
    
*   [セキュリティーポリシー](https://www.jcom.co.jp/corporate/site_info/security_policy/?sc_pid=common_footer_security)
    
*   [ソーシャルメディアポリシー](https://www.jcom.co.jp/corporate/site_info/socialmedia_policy/?sc_pid=common_footer_social)
    
*   [人権方針](https://www.jcom.co.jp/corporate/sustainability/well_being/hrp/?sc_pid=common_footer_hrp#policy)
    
*   [Cookie情報の利用、広告配信などについて](https://www.jcom.co.jp/corporate/site_info/privacy_policy/cookie/?sc_pid=common_footer_cookie)
    
*   [お問い合わせ](https://www.jcom.co.jp/contactus/?sc_pid=common_footer_contactus)
    
*   [企業サイト](https://www.jcom.co.jp/corporate/?sc_pid=common_footer_corporate)
    
*   [採用情報](https://recruit.jcom.co.jp/?sc_pid=common_footer_recruit)
    
*   [法人のお客さま](https://business.jcom.co.jp/?sc_pid=common_footer_business)
    
*   [当サイトについて](https://www.jcom.co.jp/site_info/?sc_pid=common_footer_siteinfo)
    

Copyright © JCOM Co., Ltd. All Rights Reserved.

[](https://www.jcom.co.jp/service/mobile/option/#)

エリアを設定する

郵便番号を入力してください。

〒

ハイフン（-）は不要です

住居タイプを選択してください。

![icon](https://www.jcom.co.jp/common_v10/images/icn-apartment.svg)集合住宅

![icon](https://www.jcom.co.jp/common_v10/images/icn-house.svg)戸建住宅

該当する年齢を選択してください。  
（ご紹介できるプランが変わります。）

27歳以上

26歳以下

22歳以下

次へ

[](https://www.jcom.co.jp/service/mobile/option/#)

エリアを設定する

郵便番号を入力してください。

〒

 

住居タイプを選択してください。

![icon](https://www.jcom.co.jp/common_v10/images/icn-apartment.svg)集合住宅

![icon](https://www.jcom.co.jp/common_v10/images/icn-house.svg)戸建住宅

次へ

[](https://www.jcom.co.jp/service/mobile/option/#)

エリアを設定する

郵便番号を入力してください。

〒

 

住居タイプを選択してください。

![icon](https://www.jcom.co.jp/common_v10/images/icn-apartment.svg)集合住宅

![icon](https://www.jcom.co.jp/common_v10/images/icn-house.svg)戸建住宅

次へ

[](https://www.jcom.co.jp/service/mobile/option/#)

エリアを設定する

郵便番号を入力してください。

〒

ハイフン（-）は不要です

次へ

[](https://www.jcom.co.jp/service/mobile/option/#)

エリアを設定する

郵便番号を入力してください。

〒

 

住居タイプを選択してください。

![icon](https://www.jcom.co.jp/common_v10/images/icn-apartment.svg)集合住宅

![icon](https://www.jcom.co.jp/common_v10/images/icn-house.svg)戸建住宅

次へ

[](https://www.jcom.co.jp/service/mobile/option/#)

サービスの確認

転居先の郵便番号を入力してください。

〒

 

次へ

[](https://www.jcom.co.jp/service/mobile/option/#)

J:COM オンライン診療　提供エリアの確認

郵便番号を入力してください。

〒

ハイフン（-）は不要です

住居タイプを選択してください。

![icon](https://www.jcom.co.jp/common_v10/images/icn-apartment.svg)集合住宅

![icon](https://www.jcom.co.jp/common_v10/images/icn-house.svg)戸建住宅

次へ

[](https://www.jcom.co.jp/service/mobile/option/#)

都道府県を選択

必須都道府県を選択してください。

北海道・東北

[北海道](https://www.jcom.co.jp/service/mobile/option/#)
 [宮城県](https://www.jcom.co.jp/service/mobile/option/#)

関東

[東京都](https://www.jcom.co.jp/service/mobile/option/#)
 [神奈川県](https://www.jcom.co.jp/service/mobile/option/#)
 [千葉県](https://www.jcom.co.jp/service/mobile/option/#)
 [埼玉県](https://www.jcom.co.jp/service/mobile/option/#)
 [群馬県](https://www.jcom.co.jp/service/mobile/option/#)
 [茨城県](https://www.jcom.co.jp/service/mobile/option/#)

関西

[大阪府](https://www.jcom.co.jp/service/mobile/option/#)
 [京都府](https://www.jcom.co.jp/service/mobile/option/#)
 [和歌山県](https://www.jcom.co.jp/service/mobile/option/#)
 [兵庫県](https://www.jcom.co.jp/service/mobile/option/#)

九州・山口

[福岡県](https://www.jcom.co.jp/service/mobile/option/#)
 [熊本県](https://www.jcom.co.jp/service/mobile/option/#)
 [大分県](https://www.jcom.co.jp/service/mobile/option/#)
 [山口県](https://www.jcom.co.jp/service/mobile/option/#)

[戻る](https://www.jcom.co.jp/service/mobile/option/#)

[](https://www.jcom.co.jp/service/mobile/option/#)

市区町村を選択

必須市区町村を選択してください。

現在の選択：東京都

*   あ
*   か
*   さ
*   た
*   な
*   は
*   ま
*   や
*   ら
*   わ

[昭島市](https://www.jcom.co.jp/service/mobile/option/#)
 [あきる野市](https://www.jcom.co.jp/service/mobile/option/#)
 [足立区](https://www.jcom.co.jp/service/mobile/option/#)
 [板橋区](https://www.jcom.co.jp/service/mobile/option/#)
 [稲城市](https://www.jcom.co.jp/service/mobile/option/#)
 [江戸川区](https://www.jcom.co.jp/service/mobile/option/#)
 [大田区](https://www.jcom.co.jp/service/mobile/option/#)

「か」のコンテンツ内容

「あ」行から始まる地域

[昭島市](https://www.jcom.co.jp/service/mobile/option/#)
 [あきる野市](https://www.jcom.co.jp/service/mobile/option/#)
 [足立区](https://www.jcom.co.jp/service/mobile/option/#)
 [板橋区](https://www.jcom.co.jp/service/mobile/option/#)
 [稲城市](https://www.jcom.co.jp/service/mobile/option/#)
 [江戸川区](https://www.jcom.co.jp/service/mobile/option/#)
 [大田区](https://www.jcom.co.jp/service/mobile/option/#)

「か」行から始まる地域

「さ」行から始まる地域

「た」行から始まる地域

「な」行から始まる地域

[戻る](https://www.jcom.co.jp/service/mobile/option/#)

[](https://www.jcom.co.jp/service/mobile/option/#)

エリアを設定する

〒 1070052

ご入力いただいた郵便番号には、複数のエリア候補があります。  
以下のリストから住所を選択してください

選択して下さい 1 2 3 テキストテキストテキスト

設定する

[戻る](https://www.jcom.co.jp/service/mobile/option/#)

[](https://www.jcom.co.jp/service/mobile/option/#)

エリアを設定する

〒 \-------

続く住所情報を選択してください。

  

選択して下さい 1 2 3 テキストテキストテキスト

次へ

[戻る](https://www.jcom.co.jp/service/mobile/option/#)

[](https://www.jcom.co.jp/service/mobile/option/#)

ギガ提供エリアの確認

〒 1070052 (J:COM 町田・川崎)は

J:COM NET 1Gコース  
の提供エリアです。

※ 「J:COM NET 1Gコース」はケーブルテレビ回線でご利用いただける1ギガサービスです。

光10G・5G・1Gコース  
の提供エリアです。

※ 光は一部エリアで未提供（順次拡大）[詳しくはこちらよりお問い合わせください](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

光10G・5G・1Gコース※1  
の提供エリア拡大中です。

J:COM NET 1Gコース※2  
の提供エリアです。

※1 光は一部エリアで未提供（順次拡大）[詳しくはこちらよりお問い合わせください](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

※2 「J:COM NET 1Gコース」はケーブルテレビ回線でご利用いただける1ギガサービスです。

光10G・5G・1Gコース  
J:COM NET 1Gコース  
の提供エリアです。

※ 一部エリアで未提供（順次拡大）[詳しくはこちらよりお問い合わせください](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

※ 「J:COM NET 1Gコース」はケーブルテレビ回線でご利用いただける1ギガサービスです。

J:COM NET 1Gコース  
の提供エリア外です。（順次提供エリア拡大中）

320Mコース  
の提供エリアです。

320Mコース  
の提供エリアです。

J:COM NET 1Gコースの提供エリアは順次拡大中です。

[提供エリアの詳しい情報はこちらよりお問い合わせください](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

J:COM大分（大分ケーブルテレコム株式会社）のサービスエリアです。  
[J:COM大分（大分ケーブルテレコム株式会社）のホームページ](https://wwwjcom.oct-net.ne.jp/)
をご覧ください。

横浜ケーブルビジョン（YCV）のサービスエリアです。  
[横浜ケーブルビジョン（YCV）のホームページ](https://www.catv-yokohama.ne.jp/)
をご覧ください。

[お申し込み](https://www.jcom.co.jp/sim_contact/entry_request.php?refresh=new&net_service=1)

[お申し込みの流れを確認する](https://www.jcom.co.jp/service/guide/sdu/)

一部地域は提供エリア外の場合があります。

[料金・コースを見る](https://www.jcom.co.jp/service/net/)

戻る

[](https://www.jcom.co.jp/service/mobile/option/#)

ギガ提供エリアの確認

〒 1070052 (町田・川崎)は

光 10G・5G・1Gコース  
J:COM NET 1Gコース  
の提供エリアです。

※ 「J:COM NET 1Gコース」はケーブルテレビ回線でご利用いただける1ギガサービスです。

光 10G・5G・1Gコース  
の提供エリアです。

光 1Gコース  
J:COM NET 1Gコース  
の提供エリアです。

※ 「J:COM NET 1Gコース」はケーブルテレビ回線でご利用いただける1ギガサービスです。

光 1Gコース  
の提供エリアです。

320Mコース  
の提供エリアです。

[お申し込み](https://www.jcom.co.jp/sim_contact/entry_request.php?refresh=new&net_service=1)

[お申し込みの流れを確認する](https://www.jcom.co.jp/service/guide/sdu/)

一部地域は提供エリア外の場合があります。

料金・コースを見る

[料金シミュレーション](https://onlineshop.jcom.co.jp/Simulation/Simulation)

戻る

[](https://www.jcom.co.jp/service/mobile/option/#)

ギガ提供エリアの確認

〒 1070052 

J:COM NET  
の提供エリア外です。

J:COM WiMAX  
の提供エリアです。

[お申し込み](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=wimax2p)

[お申し込みの流れを確認する](https://www.jcom.co.jp/service/guide/sdu/)

一部地域は提供エリア外の場合があります。

[料金・コースを見る](https://www.jcom.co.jp/service/wimax/)

戻る

[](https://www.jcom.co.jp/service/mobile/option/#)

提供エリアの確認

〒 \------- 

J:COM大分（大分ケーブルテレコム株式会社）のサービスエリアです。  
[J:COM大分（大分ケーブルテレコム株式会社）のホームページ](https://wwwjcom.oct-net.ne.jp/)
をご覧ください。

横浜ケーブルビジョン（YCV）のサービスエリアです。  
[横浜ケーブルビジョン（YCV）のホームページ](https://www.catv-yokohama.ne.jp/)
をご覧ください。

以下のサービスをご利用いただけます。

   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-mobile.svg) ![J:COM MOBILE](https://www.jcom.co.jp/common_v10/images/logo-jcom-mobile.svg)](https://www.jcom.co.jp/service/mobile/)   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-electricity.svg) ![J:COM でんき](https://www.jcom.co.jp/common_v10/images/logo-jcom-electricity.svg)](https://www.jcom.co.jp/service/electricity/)
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-gas.svg) ![J:COM ガス](https://www.jcom.co.jp/common_v10/images/logo-jcom-gas.svg)](https://www.jcom.co.jp/service/gas/)
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-ssi.svg) ![J:COM ほけん](https://www.jcom.co.jp/common_v10/images/logo-jcom-ssi.svg)](https://www.jcom.co.jp/service/ssi/)
  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-telemedicine.svg) ![J:COM オンライン診療](https://www.jcom.co.jp/common_v10/images/logo-jcom-telemedicine.svg)](https://www.jcom.co.jp/service/telemedicine/)

以下サービスは[料金シミュレーション](https://onlineshop.jcom.co.jp/Simulation/Simulation)
で  
エリアをご確認ください。

  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-net.svg)\
\
![J:COM NET](https://www.jcom.co.jp/common_v10/images/logo-jcom-net.svg) 光10G/光1G](https://www.jcom.co.jp/price/hikari-n/)  ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-tv.svg) 地デジ・BSデジ  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-phone.svg) ひかり電話](https://www.jcom.co.jp/price/hikari-n/phone-op/)

J:COM NETは NTT回線でご提供となります。

[お申し込み](https://onlineshop.jcom.co.jp/planSelect)

[料金シミュレーション](https://onlineshop.jcom.co.jp/Simulation/Simulation)

地域のケーブルテレビをご希望の方は [こちら](https://www.catv-jcta.jp/search/index)

戻る

お住まいの地域によって、一部サービスがご利用いただけない場合がございます。

[](https://www.jcom.co.jp/service/mobile/option/#)

サービスの確認

〒 1070052 は

J:COM大分（大分ケーブルテレコム株式会社）のサービスエリアです。提供サービスの確認は、[J:COM大分（大分ケーブルテレコム株式会社）のホームページ](https://wwwjcom.oct-net.ne.jp/)
をご覧ください。

横浜ケーブルビジョン（YCV）のサービスエリアです。  
[横浜ケーブルビジョン（YCV）のホームページ](https://www.catv-yokohama.ne.jp/)
をご覧ください。

以下のサービスをご利用いただけます。

   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-tv.svg) ![J:COM TV](https://www.jcom.co.jp/common_v10/images/logo-jcom-tv.svg)](https://www.jcom.co.jp/service/tv/)   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-net.svg) ![J:COM NET](https://www.jcom.co.jp/common_v10/images/logo-jcom-net.svg)](https://www.jcom.co.jp/service/net/)
  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-mobile.svg) ![J:COM MOBILE](https://www.jcom.co.jp/common_v10/images/logo-jcom-mobile.svg)](https://www.jcom.co.jp/service/mobile/)
  
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-phone.svg) ![J:COM PHONE](https://www.jcom.co.jp/common_v10/images/logo-jcom-phone.svg)](https://www.jcom.co.jp/service/phone/)   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-ssi.svg) ![J:COM ほけん](https://www.jcom.co.jp/common_v10/images/logo-jcom-ssi.svg)](https://www.jcom.co.jp/service/ssi/)
  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-telemedicine.svg) ![J:COM オンライン診療](https://www.jcom.co.jp/common_v10/images/logo-jcom-telemedicine.svg)](https://www.jcom.co.jp/service/telemedicine/)

[J:COMご加入中の方  \
お引越しのお手続き](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=contact_move)

郵便番号入力に戻る

[](https://www.jcom.co.jp/service/mobile/option/#)

提供エリアの確認

〒 1070052 (J:COM 町田・川崎)は

以下のサービスをご利用いただけます。

   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-tv.svg) ![J:COM TV](https://www.jcom.co.jp/common_v10/images/logo-jcom-tv.svg)](https://www.jcom.co.jp/service/tv/)   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-net.svg) ![J:COM NET](https://www.jcom.co.jp/common_v10/images/logo-jcom-net.svg)](https://www.jcom.co.jp/service/net/)
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-mobile.svg) ![J:COM MOBILE](https://www.jcom.co.jp/common_v10/images/logo-jcom-mobile.svg)](https://www.jcom.co.jp/service/mobile/)
  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-electricity.svg) ![J:COM でんき](https://www.jcom.co.jp/common_v10/images/logo-jcom-electricity.svg)](https://www.jcom.co.jp/service/electricity/)
  
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-phone.svg) ![J:COM PHONE](https://www.jcom.co.jp/common_v10/images/logo-jcom-phone.svg)](https://www.jcom.co.jp/service/phone/)   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-gas.svg) ![J:COM ガス](https://www.jcom.co.jp/common_v10/images/logo-jcom-gas.svg)](https://www.jcom.co.jp/service/gas/)
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-ssi.svg) ![J:COM ほけん](https://www.jcom.co.jp/common_v10/images/logo-jcom-ssi.svg)](https://www.jcom.co.jp/service/ssi/)
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-home.svg) ![J:COM HOME](https://www.jcom.co.jp/common_v10/images/logo-jcom-home.svg)](https://www.jcom.co.jp/service/home/)
  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-telemedicine.svg) ![J:COM オンライン診療](https://www.jcom.co.jp/common_v10/images/logo-jcom-telemedicine.svg)](https://www.jcom.co.jp/service/telemedicine/)

[お申し込み](https://onlineshop.jcom.co.jp/planSelect)
 [お申し込み](https://onlineshop.jcom.co.jp/planSelect)

[お申し込みの流れを確認する](https://www.jcom.co.jp/service/guide/sdu/)

料金シミュレーション

戻る

[](https://www.jcom.co.jp/service/mobile/option/#)

サービスの確認

〒 1070052 (J:COM 町田・川崎)は

以下のサービスをご利用いただけます。

   ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-tv.svg) ![J:COM TV](https://www.jcom.co.jp/common_v10/images/logo-jcom-tv.svg) ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-net.svg) ![J:COM NET](https://www.jcom.co.jp/common_v10/images/logo-jcom-net.svg)  ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-mobile.svg) ![J:COM MOBILE](https://www.jcom.co.jp/common_v10/images/logo-jcom-mobile.svg)  ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-electricity.svg) ![J:COM でんき](https://www.jcom.co.jp/common_v10/images/logo-jcom-electricity.svg)  
   ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-phone.svg) ![J:COM PHONE](https://www.jcom.co.jp/common_v10/images/logo-jcom-phone.svg) ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-gas.svg) ![J:COM ガス](https://www.jcom.co.jp/common_v10/images/logo-jcom-gas.svg)  ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-home.svg) ![J:COM HOME](https://www.jcom.co.jp/common_v10/images/logo-jcom-home.svg)

[J:COMご加入中の方  \
お引越しのお手続き](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=contact_move)

郵便番号入力に戻る

[](https://www.jcom.co.jp/service/mobile/option/#)

提供エリアの確認

サービスをお選びください。

テレビとネットがセットでおトク！

 ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-tv.svg)  
![J:COM TV](https://www.jcom.co.jp/common_v10/images/logo-jcom-tv.svg)![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-net.svg)  
![J:COM NET](https://www.jcom.co.jp/common_v10/images/logo-jcom-net.svg) ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-phone.svg)  
![J:COM PHONE](https://www.jcom.co.jp/common_v10/images/logo-jcom-phone.svg)

[料金シミュレーション](https://onlineshop.jcom.co.jp/Simulation/Simulation)

月々のスマホ代をもっとおトクに。

![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-mobile.svg)  
![J:COM MOBILE](https://www.jcom.co.jp/common_v10/images/logo-jcom-mobile.svg)

[料金シミュレーション](https://www.jcom.co.jp/service/mobile/simulator/)

戻る

[](https://www.jcom.co.jp/service/mobile/option/#)

J:COM ガス提供エリアの確認

〒 1070052 (J:COM ----)は

![](https://www.jcom.co.jp/common_form/img/common/logo/logo_gas_osaka.png)

の提供エリアです。

一部地域は提供エリア外の場合があります。

![](https://www.jcom.co.jp/common_form/img/common/logo/logo_gas_tokyo.png)

の提供エリアです。

一部地域は提供エリア外の場合があります。

![](https://www.jcom.co.jp/common_form/img/common/logo/logo_gas_keiyo.png)

の提供エリアです。

一部地域は提供エリア外の場合があります。

J:COM ガス  
の提供エリア外です。

（株）エナジー宇宙の【越谷・春日部地区/蓮田南地区】【取手・我孫子地区】の  
都市ガス供給エリアにお住まいの方は

東京ガス for J:COM「ずっともガス」

がご利用いただけます。

[詳しく見る](https://www.jcom.co.jp/service/tokyo_gas/)

J:COM ガス  
の提供エリア外です。

戻る

[](https://www.jcom.co.jp/service/mobile/option/#)

J:COM オンライン診療　提供エリアの確認

〒 1070052 (J:COM ----)は

J:COM オンライン診療  
の提供エリアです。

一部地域は提供エリア外の場合があります。

[医療機関一覧を見る](https://www.jcom.co.jp/service/telemedicine/clinic/)

[料金を見る](https://www.jcom.co.jp/service/telemedicine/price/)

J:COM オンライン診療  
の提供エリア外です。

戻る

    

[](https://www.jcom.co.jp/service/mobile/option/#)

あなたへのお知らせ
---------

[ログアウト](https://www.jcom.co.jp/common/logout.html)
