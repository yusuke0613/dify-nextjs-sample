# For cheap smartphones and SIM cards, J:COM MOBILE | J:COM

URL: https://www.jcom.co.jp/service/mobile/

---

[![あたらしいを、あたりまえに。 J:COM](https://www.jcom.co.jp/common_v10/images/logo-jcom-white.svg)](https://www.jcom.co.jp/en/?sc_pid=common_jcomlogo_01)

*   [Why J:COM](https://www.jcom.co.jp/en/beginner/?sc_pid=globalnavi_beginner_01)
    
*   Current customers
*   [Online Shop](https://onlineshop.jcom.co.jp/?sc_pid=globalnavi_ols_01)
    

J:COM Customers

[Check/Update Contract  \
My page login](https://mypage.jcom.co.jp/?sc_pid=common_mypage_01)
 [Troubleshooting/FAQ  \
Customer Support](https://cs.myjcom.jp/?sc_pid=common_suppot_01)
 [Enjoy J:COM even more  \
TV program information/presents and benefits  \
Fun! J:COM](https://www.myjcom.jp/?sc_pid=common_myj_01)

    ![検索](https://www.jcom.co.jp/common_v10/images/snav-icn-search-submit.svg)

*   [あなたへの  \
    お知らせ](https://id.zaq.ne.jp/id/script/connect/authz_req/endpoint.seam?response_type=code&client_id=JCOM_COJP&redirect_uri=https%3A%2F%2Fwww.jcom.co.jp%2Fservice%2Fmobile%2F&scope=http%3A%2F%2Fjcom.co.jp%2Fconnect%2Fprofile%2Fstandard_new&nonce=398033787&state=&prompt=)
     [ ] あなたへのお知らせを見よう
*   [To you  \
    notice](https://www.jcom.co.jp/service/mobile/#)
    

Language

*   日本語
*   English
*   简体中文
*   한국어
*   Tiếng Việt
*   Português

*   Services
*   [Pricing](https://www.jcom.co.jp/en/price/)
    
*   [Promotions  \
    ​](https://www.jcom.co.jp/en/campaign/)
    
*   Sign Up /  
    Edit Account Info
*   Support
*   Company website

[Service Overview](https://www.jcom.co.jp/en/service/)

[TV,](https://www.jcom.co.jp/en/service/tv/)
 ​ ​[internet,](https://www.jcom.co.jp/en/service/net/)
 ​ ​[smartphone](https://www.jcom.co.jp/en/service/mobile/)
 [, electricity](https://www.jcom.co.jp/en/service/electricity/)
 ​ ​[Landline](https://www.jcom.co.jp/en/service/phone/)
 , [gas](https://www.jcom.co.jp/en/service/gas/)
 [,](https://www.jcom.co.jp/en/service/ssi/)
 insurance, [loan](https://www.jcom-financial.co.jp/)
 [, security camera,](https://www.jcom.co.jp/en/guide/starter/home_security/)
 ​ ​[Telemedicine](https://www.jcom.co.jp/en/service/telemedicine/)
 [, services for corporations and local governments![J:COM BUSINESS](https://www.jcom.co.jp/common_v10/images/logo_jcombusiness.webp)](https://business.jcom.co.jp/)

[Sign Up / Inquiries](https://www.jcom.co.jp/en/contactus/)

New customers

[New customers  \
Sign Up](https://onlineshop.jcom.co.jp/planSelect)

[New customers  \
Inquiries](https://www.jcom.co.jp/en/contactus/#entry)

J:COM Customers

[User  \
Various procedures](https://r.jcom.jp/eG4nLSC)

[Problems and inquiries  \
(chat)](https://prod8-live-chat.sprinklr.com/page?appId=67af27d73657336d345e4a96_app_9070639&did=CHAT_vivr_cojp_top&enableClose=true&skin=MODERN&userContext__c_679c8b53cb85b007fab0f6ea=DirectLink&utm_campaign=IVRSMS&utm_medium=referral&utm_source=did&webview=true&zoom=false)

Find the perfect plan for you

[Savings calculator](https://onlineshop.jcom.co.jp/Simulation/Simulation)

Some properties offer free or discounted options!

Covered areas & properties

[Company website](https://www.jcom.co.jp/en/corporate/)

[Corporate philosophy](https://www.jcom.co.jp/en/corporate/philosophy_brand/)

[Sustainability](https://www.jcom.co.jp/en/corporate/sustainability/)

[Medium-term management plan](https://www.jcom.co.jp/en/corporate/managementplan/)

[news release](https://newsreleases.jcom.co.jp/)

[Company Profile](https://www.jcom.co.jp/en/corporate/company/)

[Careers](https://recruit.jcom.co.jp/)

[Support Top](https://cs.myjcom.jp/)

[TV,](https://cs.myjcom.jp/categories/support/67ab976bf07f5244a208cb97)
 ​ ​[Internet,](https://cs.myjcom.jp/categories/support/67ab9788f07f5244a208cced)
 ​ ​[Smartphone](https://cs.myjcom.jp/categories/support/67ab979df07f5244a208cdc9)
 [, Electricity](https://cs.myjcom.jp/categories/support/67ab97b5f07f5244a208cec9)
 ​ ​[Landline](https://cs.myjcom.jp/categories/support/67ab97abf07f5244a208ce4e)
 [, Gas](https://cs.myjcom.jp/categories/support/67ab97b8f07f5244a208ceda)
 [, Insurance](https://cs.myjcom.jp/categories/support/67ab97c5f07f5244a208cf2f)
 ​ ​[Telemedicine](https://cs.myjcom.jp/categories/support/67ab97c2f07f5244a208cf1b)
 ​ ​[Home, IoT](https://cs.myjcom.jp/categories/support/67ab97bcf07f5244a208cee6)
 ​ ​[Security Camera](https://cs.myjcom.jp/categories/support/67ab97f5f07f5244a208d09b)

[J:COM STREAM](https://cs.myjcom.jp/categories/support/67ab97c9f07f5244a208cf49)

[Enkaku Support](https://cs.myjcom.jp/categories/support/67ab97faf07f5244a208d0c2)

[Home support](https://cs.myjcom.jp/categories/support/67ab97d4f07f5244a208cf92)

[Disaster prevention information service](https://cs.myjcom.jp/categories/support/67ab97d8f07f5244a208cfa0)

[Bicycle Life Support](https://cs.myjcom.jp/categories/support/67ab97e8f07f5244a208d023)

[J:COM Books](https://cs.myjcom.jp/categories/support/67ab97e4f07f5244a208d003)

[WiMAX](https://cs.myjcom.jp/categories/support/67ab97f1f07f5244a208d074)

[Trouble/maintenance information](https://information.myjcom.jp/maintenance_outage/)

Various procedures

[Personal ID](https://cs.myjcom.jp/categories/support/67ab9803f07f5244a208d113)

[Fees and Payment](https://cs.myjcom.jp/categories/support/67ab9805f07f5244a208d139)

[Moving and rebuilding](https://cs.myjcom.jp/categories/support/67ab980cf07f5244a208d184)

[Visits and counters](https://cs.myjcom.jp/categories/support/67ab980ff07f5244a208d1a4)

[Contract-related](https://cs.myjcom.jp/categories/support/67ab9806f07f5244a208d150)

[Suspension/cancellation](https://cs.myjcom.jp/categories/support/67ab980cf07f5244a208d188)

[Membership Benefits](https://cs.myjcom.jp/categories/support/67ab980df07f5244a208d18c)

[![あたらしいを、あたりまえに J:COM](https://www.jcom.co.jp/common_v10/images/logo-jcom-white.svg)](https://www.jcom.co.jp/en/?sc_pid=common_jcomlogo_01)

[![J:COM MOBILE](https://www.jcom.co.jp/common_v10/images/logo-jcom-mobile-bk.svg)](https://www.jcom.co.jp/en/service/mobile/)

*   Pricing
*   Products
*   SIM
*   Options
*   Initial Setup Support
*   [How to apply](https://www.jcom.co.jp/en/service/mobile/usage/)
    
*   [User](https://cs.myjcom.jp/jcomMobile)
    
*   [For corporations](https://business.jcom.co.jp/smb/mobile/)
    

[Price Top](https://www.jcom.co.jp/en/service/mobile/price/)

*   [Call charges/SMS service charges](https://www.jcom.co.jp/en/service/mobile/price/detail/)
    
*   [Data Mori](https://www.jcom.co.jp/en/service/mobile/price/datamori/)
    
*   [Kids plan](https://www.jcom.co.jp/en/service/mobile/price/kids/)
    
*   [Seniors plan](https://www.jcom.co.jp/en/service/mobile/campaign/senior/)
    
*   [About 5G](https://www.jcom.co.jp/en/service/mobile/special/5g/)
    
*   [Termination of 3G service](https://www.jcom.co.jp/en/service/mobile/special/3g/)
    

[Product Top](https://www.jcom.co.jp/en/service/mobile/device/)

*   [iPhone 16e](https://www.jcom.co.jp/en/service/mobile/device/iphone_16e/)
    
*   [iPhone 15](https://www.jcom.co.jp/en/service/mobile/device/iphone_15/)
    
*   [Google Pixel 8a](https://www.jcom.co.jp/en/service/mobile/device/pixel_8a/)
    
*   [AQUOS sense10](https://www.jcom.co.jp/en/service/mobile/device/aquos_sense10/)
    
*   [Samsung Galaxy A25 5G](https://www.jcom.co.jp/en/service/mobile/device/galaxy_a25_5g/)
    
*   [BASIO active2](https://www.jcom.co.jp/en/service/mobile/device/basio_active2/)
    

[Low-cost SIM Top](https://www.jcom.co.jp/en/service/mobile/device/sim/)

*   [eSIM](https://www.jcom.co.jp/en/service/mobile/device/sim/esim/)
    
*   [Details](https://www.jcom.co.jp/en/service/mobile/device/sim/detail/)
    
*   [Device compatibility check](https://www.jcom.co.jp/service/mobile/device/sim/detail/device.html)
    
*   [Unlocking SIM Cards](https://www.jcom.co.jp/en/service/mobile/device/sim/detail/simunlock.html)
    

[Options Overview](https://www.jcom.co.jp/en/service/mobile/option/)

*   [Unlimited calls](https://www.jcom.co.jp/en/service/mobile/option/kakehodai/)
    
*   [Block nuisance calls and messages](https://www.jcom.co.jp/en/service/mobile/option/block/)
    
*   [Family smartphone insurance](https://www.jcom.co.jp/en/service/ssi/kazoku_sumaho/)
    
*   [Secure device guarantee 60](https://www.jcom.co.jp/en/service/mobile/option/guaranty60/)
    
*   [AppleCare+ for iPhone](https://www.jcom.co.jp/en/service/mobile/device/support/applecare.html)
    
*   [Anshin Filter for J:COM](https://www.jcom.co.jp/en/service/mobile/option/anshin_filter/)
    
*   [Purchase additional accessories](https://www.jcom.co.jp/en/service/mobile/option/accessories/add/)
    

[Initial Setup Support Top](https://www.jcom.co.jp/en/service/mobile/support/)

*   [FAQ](https://www.jcom.co.jp/en/service/mobile/support/faq/)
    
*   [Transferring your smartphone Q&A](https://www.jcom.co.jp/en/service/mobile/support/qa/)
    

[![あたらしいを、あたりまえに J:COM](https://www.jcom.co.jp/common_v10/images/logo-jcom.svg)](https://www.jcom.co.jp/en/)

*   Services

*   [Sign Up](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=mobile_web_entry)
    
*   [Inquiries](https://www.jcom.co.jp/en/contactus/)
    
*   [For beginners  \
    ​](https://www.jcom.co.jp/en/beginner/)
    
*   User​  
    ​
*   [Online  \
    Shop](https://onlineshop.jcom.co.jp/)
    
*   ![検索する](https://www.jcom.co.jp/common_v10/images/fixed-nav-icn-search.svg)

    ![検索](https://www.jcom.co.jp/common_v10/images/snav-icn-search-submit.svg)

J:COM Customers

[Check/Update Contract  \
My page login](https://mypage.jcom.co.jp/)
 [Troubleshooting/FAQ  \
Customer Support](https://cs.myjcom.jp/)
 [Enjoy J:COM even more  \
TV program information/presents and benefits  \
Fun! J:COM](https://www.myjcom.jp/)

[Service Overview](https://www.jcom.co.jp/en/service/)

[TV,](https://www.jcom.co.jp/en/service/tv/)
 ​ ​[internet,](https://www.jcom.co.jp/en/service/net/)
 ​ ​[smartphone](https://www.jcom.co.jp/en/service/mobile/)
 [, electricity](https://www.jcom.co.jp/en/service/electricity/)
 ​ ​[Landline](https://www.jcom.co.jp/en/service/phone/)
 , [gas](https://www.jcom.co.jp/en/service/gas/)
 [,](https://www.jcom.co.jp/en/service/ssi/)
 insurance, [loan](https://www.jcom-financial.co.jp/)
 [, security camera,](https://www.jcom.co.jp/en/guide/starter/home_security/)
 ​ ​[Telemedicine](https://www.jcom.co.jp/en/service/telemedicine/)
 [, services for corporations and local governments![J:COM BUSINESS](https://www.jcom.co.jp/common_v10/images/logo_jcombusiness.webp)](https://business.jcom.co.jp/)

[![J:COM MOBILE](https://www.jcom.co.jp/common_v10/images/logo-jcom-mobile-bk.svg)](https://www.jcom.co.jp/en/service/mobile/)

*   Pricing
*   Products
*   SIM
*   Options
*   Initial Setup Support
*   [How to apply](https://www.jcom.co.jp/en/service/mobile/usage/)
    
*   [User](https://cs.myjcom.jp/jcomMobile)
    
*   [For corporations](https://business.jcom.co.jp/smb/mobile/)
    

[Price Top](https://www.jcom.co.jp/en/service/mobile/price/)

*   [Call charges/SMS service charges](https://www.jcom.co.jp/en/service/mobile/price/detail/)
    
*   [Data Mori](https://www.jcom.co.jp/en/service/mobile/price/datamori/)
    
*   [Kids plan](https://www.jcom.co.jp/en/service/mobile/price/kids/)
    
*   [Seniors plan](https://www.jcom.co.jp/en/service/mobile/campaign/senior/)
    
*   [About 5G](https://www.jcom.co.jp/en/service/mobile/special/5g/)
    
*   [Termination of 3G service](https://www.jcom.co.jp/en/service/mobile/special/3g/)
    

[Product Top](https://www.jcom.co.jp/en/service/mobile/device/)

*   [iPhone 16e](https://www.jcom.co.jp/en/service/mobile/device/iphone_16e/)
    
*   [iPhone 15](https://www.jcom.co.jp/en/service/mobile/device/iphone_15/)
    
*   [Google Pixel 8a](https://www.jcom.co.jp/en/service/mobile/device/pixel_8a/)
    
*   [AQUOS sense10](https://www.jcom.co.jp/en/service/mobile/device/aquos_sense10/)
    
*   [Samsung Galaxy A25 5G](https://www.jcom.co.jp/en/service/mobile/device/galaxy_a25_5g/)
    
*   [BASIO active2](https://www.jcom.co.jp/en/service/mobile/device/basio_active2/)
    

[Low-cost SIM Top](https://www.jcom.co.jp/en/service/mobile/device/sim/)

*   [eSIM](https://www.jcom.co.jp/en/service/mobile/device/sim/esim/)
    
*   [Details](https://www.jcom.co.jp/en/service/mobile/device/sim/detail/)
    
*   [Device compatibility check](https://www.jcom.co.jp/service/mobile/device/sim/detail/device.html)
    
*   [Unlocking SIM Cards](https://www.jcom.co.jp/en/service/mobile/device/sim/detail/simunlock.html)
    

[Options Overview](https://www.jcom.co.jp/en/service/mobile/option/)

*   [Unlimited calls](https://www.jcom.co.jp/en/service/mobile/option/kakehodai/)
    
*   [Block nuisance calls and messages](https://www.jcom.co.jp/en/service/mobile/option/block/)
    
*   [Family smartphone insurance](https://www.jcom.co.jp/en/service/ssi/kazoku_sumaho/)
    
*   [Secure device guarantee 60](https://www.jcom.co.jp/en/service/mobile/option/guaranty60/)
    
*   [AppleCare+ for iPhone](https://www.jcom.co.jp/en/service/mobile/device/support/applecare.html)
    
*   [Anshin Filter for J:COM](https://www.jcom.co.jp/en/service/mobile/option/anshin_filter/)
    
*   [Purchase additional accessories](https://www.jcom.co.jp/en/service/mobile/option/accessories/add/)
    

[Initial Setup Support Top](https://www.jcom.co.jp/en/service/mobile/support/)

*   [FAQ](https://www.jcom.co.jp/en/service/mobile/support/faq/)
    
*   [Transferring your smartphone Q&A](https://www.jcom.co.jp/en/service/mobile/support/qa/)
    

*   ![メニュー](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/text-menu.svg)
*   ![J:COM mobile メニュー](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom-mobile/text-menu.svg)
*   [![料金シミュレーション](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom-mobile/text-sim.svg)](https://www.jcom.co.jp/en/service/mobile/simulator/)
    
*   [![Sign Up](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom-mobile/text-entry.svg)](https://www.jcom.co.jp/sim_contact/entry_request.php?&form_type=mobile_web_entry)
    
*   [![よくある質問　お問い合わせ](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom-mobile/text-faq.svg)](https://www.jcom.co.jp/en/service/mobile/support/faq/)
    

*   [![あたらしいを、あたりまえに　J:COM](https://www.jcom.co.jp/common_v10/images/logo-jcom-only-white.svg)](https://www.jcom.co.jp/en/)
     ![メニューを閉じる](https://www.jcom.co.jp/common_v10/images/sp-menu/menu-close-white.svg)
    
    [J:COM Services](https://www.jcom.co.jp/en/service/)
    
    *   [![テレビ](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-tv-item.svg)](https://www.jcom.co.jp/en/service/tv/)
        
    *   [![ネット](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-net-item.svg)](https://www.jcom.co.jp/en/service/net/)
        
    *   [![スマホ](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-mobile-item.svg)](https://www.jcom.co.jp/en/service/mobile/)
        
    
    *   [![電気](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-electricity-item.svg)](https://www.jcom.co.jp/en/service/electricity/)
        
    *   [![固定電話](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-phone-item.svg)](https://www.jcom.co.jp/en/service/phone/)
        
    *   [![ガス](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-gas-item.svg)](https://www.jcom.co.jp/en/service/gas/)
        
    *   [![ほけん](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-ssi-item.svg)](https://www.jcom.co.jp/en/service/ssi/)
        
    *   [loan](https://www.jcom-financial.co.jp/)
        
    *   [![ホームIoT](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-home-item.svg)](https://www.jcom.co.jp/en/service/home/)
        
    *   [security cameras](https://www.jcom.co.jp/en/guide/starter/home_security/)
        
    *   [![オンライン診療](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-telemedicine-item.svg)](https://www.jcom.co.jp/en/service/telemedicine/)
        
    
    [Services for corporations and local governments  \
    ![J:COM BUSINESS](https://www.jcom.co.jp/common_v10/images/logo_jcombusiness.webp)](https://business.jcom.co.jp/)
    
    Service overview
    
    [Price List](https://www.jcom.co.jp/en/price/)
     [Promotions/Benefits](https://www.jcom.co.jp/en/campaign/)
     [Support](https://cs.myjcom.jp/jcomMobile)
     [Application/Various Changes](https://www.jcom.co.jp/en/contactus/)
    
        ![検索](https://www.jcom.co.jp/common_v10/images/snav-icn-search-submit-sp.svg)
    
    [J:COM Top](https://www.jcom.co.jp/en/)
    
    *   [Service Information](https://www.jcom.co.jp/en/)
        
    *   [Online  \
        Shop](https://onlineshop.jcom.co.jp/)
        
    *   [Support](https://cs.myjcom.jp/jcomMobile)
        
    *   [Fun! J:COM](https://www.myjcom.jp/)
        
    *   [My page](https://mypage.jcom.co.jp/)
        
    *   [Company website](https://www.jcom.co.jp/en/corporate/)
        
    
*   [![J:COM MOBILE](https://www.jcom.co.jp/common_v10/images/icn-jcom-mobile.svg)Smartphone](https://www.jcom.co.jp/en/service/mobile/)
     ![メニューを閉じる](https://www.jcom.co.jp/common_v10/images/sp-menu/menu-close-white.svg)
    
    [![](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom-mobile/slide/menu/mv-middle.webp)\
    \
    Continuous savings\
    \
    Back to top](https://www.jcom.co.jp/en/service/mobile/)
    
    *   Pricing
        
        *   [Price Top](https://www.jcom.co.jp/en/service/mobile/price/)
            
        *   [Call charges/SMS service charges](https://www.jcom.co.jp/en/service/mobile/price/detail/)
            
        *   [Data Mori](https://www.jcom.co.jp/en/service/mobile/price/datamori/)
            
        *   [Kids plan](https://www.jcom.co.jp/en/service/mobile/price/kids/)
            
        *   [Seniors plan](https://www.jcom.co.jp/en/service/mobile/campaign/senior/)
            
        *   [About 5G](https://www.jcom.co.jp/en/service/mobile/special/5g/)
            
        *   [Termination of 3G service](https://www.jcom.co.jp/en/service/mobile/special/3g/)
            
        
    *   Products
        
        *   [Product Top](https://www.jcom.co.jp/en/service/mobile/device/)
            
        *   [iPhone 16e](https://www.jcom.co.jp/en/service/mobile/device/iphone_16e/)
            
        *   [iPhone 15](https://www.jcom.co.jp/en/service/mobile/device/iphone_15/)
            
        *   [Google Pixel 8a](https://www.jcom.co.jp/en/service/mobile/device/pixel_8a/)
            
        *   [AQUOS sense10](https://www.jcom.co.jp/en/service/mobile/device/aquos_sense10/)
            
        *   [Samsung Galaxy A25 5G](https://www.jcom.co.jp/en/service/mobile/device/galaxy_a25_5g/)
            
        *   [BASIO active2](https://www.jcom.co.jp/en/service/mobile/device/basio_active2/)
            
        
    *   SIM
        
        *   [Low-cost SIM Top](https://www.jcom.co.jp/en/service/mobile/device/sim/)
            
        *   [eSIM](https://www.jcom.co.jp/en/service/mobile/device/sim/esim/)
            
        *   [Details](https://www.jcom.co.jp/en/service/mobile/device/sim/detail/)
            
        *   [Device compatibility check](https://www.jcom.co.jp/service/mobile/device/sim/detail/device.html)
            
        *   [Unlocking SIM Cards](https://www.jcom.co.jp/en/service/mobile/device/sim/detail/simunlock.html)
            
        
    *   Options
        
        *   [Options Overview](https://www.jcom.co.jp/en/service/mobile/option/)
            
        *   [Unlimited calls](https://www.jcom.co.jp/en/service/mobile/option/kakehodai/)
            
        *   [Block nuisance calls and messages](https://www.jcom.co.jp/en/service/mobile/option/block/)
            
        *   [Family smartphone insurance](https://www.jcom.co.jp/en/service/ssi/kazoku_sumaho/)
            
        *   [Secure device guarantee 60](https://www.jcom.co.jp/en/service/mobile/option/guaranty60/)
            
        *   [AppleCare+ for iPhone](https://www.jcom.co.jp/en/service/mobile/device/support/applecare.html)
            
        *   [Anshin Filter for J:COM](https://www.jcom.co.jp/en/service/mobile/option/anshin_filter/)
            
        *   [Purchase additional accessories](https://www.jcom.co.jp/en/service/mobile/option/accessories/add/)
            
        
    *   Initial Setup Support
        
        *   [Initial Setup Support Top](https://www.jcom.co.jp/en/service/mobile/support/)
            
        *   [FAQ](https://www.jcom.co.jp/en/service/mobile/support/faq/)
            
        *   [Transferring your smartphone Q&A](https://www.jcom.co.jp/en/service/mobile/support/qa/)
            
        
    *   [How to apply](https://www.jcom.co.jp/en/service/mobile/usage/)
        
    *   [User](https://cs.myjcom.jp/jcomMobile)
        
    *   [For corporations](https://business.jcom.co.jp/smb/mobile/)
        
    

![J:COM](https://www.jcom.co.jp/common_v10/images/icn-jcom-mobile.svg)

![MOBILE](https://www.jcom.co.jp/common_v10/images/logo-jcom-mobile.svg)

 [![iPhone 16e](https://www.jcom.co.jp/service/mobile/images_v10/index/hero-img-31.jpg)](https://www.jcom.co.jp/en/service/mobile/device/iphone_16e/)
[![esim](https://www.jcom.co.jp/service/mobile/images_v10/index/hero-img-12.jpg)](https://www.jcom.co.jp/en/service/mobile/device/sim/esim/)
[![iPhone 15](https://www.jcom.co.jp/service/mobile/images_v10/index/hero-img-26.jpg)](https://www.jcom.co.jp/en/service/mobile/device/iphone_15/)
[![3G停波](https://www.jcom.co.jp/service/mobile/special/3g/images/pc.jpg)](https://www.jcom.co.jp/en/service/mobile/special/3g/)
[![Galaxy A25 5G](https://www.jcom.co.jp/service/mobile/images_v10/index/hero-img-30.jpg)](https://www.jcom.co.jp/en/service/mobile/device/aquos_sense10/)
[![データ盛 5GB ずーっと980円 スマホとJCOMサービスセットでデータ増量](https://www.jcom.co.jp/service/mobile/images_v10/index/hero-img-1.jpg)](https://www.jcom.co.jp/en/service/mobile/price/datamori/)
[![iPhone 16e](https://www.jcom.co.jp/service/mobile/images_v10/index/hero-img-31.jpg)](https://www.jcom.co.jp/en/service/mobile/device/iphone_16e/)
[![esim](https://www.jcom.co.jp/service/mobile/images_v10/index/hero-img-12.jpg)](https://www.jcom.co.jp/en/service/mobile/device/sim/esim/)
[![iPhone 15](https://www.jcom.co.jp/service/mobile/images_v10/index/hero-img-26.jpg)](https://www.jcom.co.jp/en/service/mobile/device/iphone_15/)
[![3G停波](https://www.jcom.co.jp/service/mobile/special/3g/images/pc.jpg)](https://www.jcom.co.jp/en/service/mobile/special/3g/)
[![Galaxy A25 5G](https://www.jcom.co.jp/service/mobile/images_v10/index/hero-img-30.jpg)](https://www.jcom.co.jp/en/service/mobile/device/aquos_sense10/)
[![データ盛 5GB ずーっと980円 スマホとJCOMサービスセットでデータ増量](https://www.jcom.co.jp/service/mobile/images_v10/index/hero-img-1.jpg)](https://www.jcom.co.jp/en/service/mobile/price/datamori/)
[![iPhone 16e](https://www.jcom.co.jp/service/mobile/images_v10/index/hero-img-31.jpg)](https://www.jcom.co.jp/en/service/mobile/device/iphone_16e/)
[![esim](https://www.jcom.co.jp/service/mobile/images_v10/index/hero-img-12.jpg)](https://www.jcom.co.jp/en/service/mobile/device/sim/esim/)
[![iPhone 15](https://www.jcom.co.jp/service/mobile/images_v10/index/hero-img-26.jpg)](https://www.jcom.co.jp/en/service/mobile/device/iphone_15/)
[![3G停波](https://www.jcom.co.jp/service/mobile/special/3g/images/pc.jpg)](https://www.jcom.co.jp/en/service/mobile/special/3g/)
[![Galaxy A25 5G](https://www.jcom.co.jp/service/mobile/images_v10/index/hero-img-30.jpg)](https://www.jcom.co.jp/en/service/mobile/device/aquos_sense10/)
[![データ盛 5GB ずーっと980円 スマホとJCOMサービスセットでデータ増量](https://www.jcom.co.jp/service/mobile/images_v10/index/hero-img-1.jpg)](https://www.jcom.co.jp/en/service/mobile/price/datamori/)

[Why you should use  \
J:COM MOBILE](https://www.jcom.co.jp/service/mobile/#anc-section)

[Rate plan](https://www.jcom.co.jp/service/mobile/#anc-02)

[option](https://www.jcom.co.jp/service/mobile/#anc-option)

[Product/SIM](https://www.jcom.co.jp/service/mobile/#anc-03)

[Application flow](https://www.jcom.co.jp/service/mobile/#anc-flow)

[Customers with existing contracts](https://www.jcom.co.jp/service/mobile/#anc-05)

New customers

[New Customers  \
Sign Up](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=mobile_web_entry&sc_pid=cv_mobile_entry_1)

[Contact us by phone  \
(Free call)​ ​0120-989-970](tel:0120-989-970)
 ​ ​9:00-18:00 \[Open all year round\]

Current customers

[Current Customers  \
Various procedures](https://r.jcom.jp/AeOCUFb)

[Problems/  \
inquiry  \
(chat)](https://prod8-live-chat.sprinklr.com/page?appId=67af27d73657336d345e4a96_app_9070639&did=CHAT_vivr_cojp_mobile&enableClose=true&skin=MODERN&userContext__c_679c8b53cb85b007fab0f6ea=DirectLink&utm_campaign=IVRSMS&utm_medium=referral&utm_source=did&webview=true&zoom=false)

[Check it easily in 30 seconds! Smartphone fee simulation](https://www.jcom.co.jp/en/service/mobile/simulator/)

### ​Won two awards for communication quality satisfaction

![通信品質満足度No1](https://www.jcom.co.jp/service/mobile/images_v10/img_award_2511_01.png) ![格安SIMアワード2025最優秀賞](https://www.jcom.co.jp/service/mobile/images_v10/img_award_2511_02.png)

*   Source: MMD Research Institute's "September 2025 MVNO Market Share and Satisfaction Survey." A survey of main users (150 people each) of seven low-cost smartphone companies, comparing satisfaction scores for communication quality. Survey period: September 12th to September 21st, 2025.
*   Best communication speed (quality) category

New arrival!

 [![iPhone 16e](https://www.jcom.co.jp/service/mobile/images_v10/index/hero-img-31.jpg)](https://www.jcom.co.jp/en/service/mobile/device/iphone_16e/)
[![AQUOS sence10](https://www.jcom.co.jp/service/mobile/images_v10/index/hero-img-30.jpg)](https://www.jcom.co.jp/en/service/mobile/device/aquos_sense10/)

Why you should use J:COM MOBILE

*   [![スマホと他サービスをご契約で](https://www.jcom.co.jp/service/mobile/images_v10/recommend1.png)](https://www.jcom.co.jp/service/mobile/#recommend1)
    
*   [![全国エリアで快適につながる](https://www.jcom.co.jp/service/mobile/images_v10/recommend6_2511.png)](https://www.jcom.co.jp/service/mobile/#recommend2)
    
*   [![余ったデータ容量は繰り越し！](https://www.jcom.co.jp/service/mobile/images_v10/recommend2.png)](https://www.jcom.co.jp/service/mobile/#recommend3)
    
*   [![速度制限後も速い！](https://www.jcom.co.jp/service/mobile/images_v10/recommend3.png)](https://www.jcom.co.jp/service/mobile/#recommend4)
    

Rate plan
---------

5G for the same price!  
Always get more data with Data Mori!

|     |     |
| --- | --- |  
| Data capacity | Pricing |
| Popular<br><br>1GB<br><br>5GB | 980​ ​yen  <br>(1,078 yen including tax) |
| ​  <br>Recommended<br><br>5GB<br><br>10GB | 1,480​ ​yen  <br>(1,628 yen including tax) |
| attention!<br><br>10GB<br><br>20GB | 1,980​ ​yen  <br>(2,178 yen including tax) |
| 20GB<br><br>30GB | 2,480​ ​yen  <br>(2,728 yen including tax) |
| NEW<br><br>50 GB<br><br>60 GB | 3,480​ ​yen  <br>(3,828 yen including tax) |

*   With Date Mori, 1GB will be increased to 5GB, 5GB will be increased to 10GB, 10GB will be increased to 20GB, 20GB will be increased to 30GB, and 50GB will be increased to 60GB. [See here](https://www.jcom.co.jp/en/service/mobile/price/datamori/)
     for applicable conditions.
*   Separate universal service fees, telephone relay service fees, and call and SMS communication fees are required.

[View pricing plans](https://www.jcom.co.jp/en/service/mobile/price/)

＼Simple check of basic monthly fee and terminal fee／

[![](https://www.jcom.co.jp/common_v10/images/icn-simulation.svg)Smartphone savings calculator](https://www.jcom.co.jp/en/service/mobile/simulator/)

### Advantageous information

 [![J:COM MOBILE シニア60割](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_senior_kakeho.webp)](https://www.jcom.co.jp/en/service/mobile/campaign/senior/?sc_pid=common_campaign_senior_01)
[![J:COMモバイル 契約事務手数料無料](https://www.jcom.co.jp/campaign/images_v10/banner/camp_thumbnail3.webp)](https://www.jcom.co.jp/en/service/mobile/campaign/mobile_fee_0/?sc_pid=common_campaign_mobile_fee_0_01)

[Promotions/Benefits](https://www.jcom.co.jp/en/campaign/)

Options
-------

[![（イメージ）かけ放題](https://www.jcom.co.jp/service/mobile/images_v10/index/img_option_01.svg?3)\
\
Unlimited calls\
\
This is a service where domestic calls of up to 5 minutes or 60 minutes at a time can be made free of charge.](https://www.jcom.co.jp/en/service/mobile/option/kakehodai/)
[![（イメージ）端末保証](https://www.jcom.co.jp/service/mobile/images_v10/index/img_option_02.svg?3)\
\
Device warranty\
\
In the unlikely event of a malfunction, breakage, water leakage, etc., we will deliver a replacement unit with just one phone call.](https://www.jcom.co.jp/en/service/mobile/option/)

[See options](https://www.jcom.co.jp/en/service/mobile/option/)

Product/SIM
-----------

### Low-cost SIM

*   [Those that want to use  \
    a card-type SIM by inserting it into a device.\
    \
    ![SIMカード](https://www.jcom.co.jp/service/mobile/images_v10/index/img_sim.png)\
    \
    SIM card](https://www.jcom.co.jp/en/service/mobile/device/sim/)
    
*   [Those who want to start service on the same day  \
    with a built-in SIM in your smartphone\
    \
    ![eSIM](https://www.jcom.co.jp/service/mobile/images_v10/index/lineup_esim.png)\
    \
    eSIM](https://www.jcom.co.jp/en/service/mobile/device/sim/esim/)
    

### iPhone

*   [NEW  Recommended\
    \
    ![iPhone 16e](https://www.jcom.co.jp/service/mobile/device/images/thumb/iphone_16e.png)\
    \
    iPhone 16e](https://www.jcom.co.jp/en/service/mobile/device/iphone_16e/)
    

*   [NEW  Recommended\
    \
    ![iPhone 15](https://www.jcom.co.jp/service/mobile/device/images/thumb/iphone_15.png)\
    \
    iPhone 15](https://www.jcom.co.jp/en/service/mobile/device/iphone_15/)
    

### Android

*   [Recommend\
    \
    ![](https://www.jcom.co.jp/service/mobile/images_v10/index/img_sp-googlepixel8a.jpg)\
    \
    Google Pixel 8a](https://www.jcom.co.jp/en/service/mobile/device/pixel_8a/)
    
*   [NEW\
    \
    ![](https://www.jcom.co.jp/service/mobile/images_v10/index/img_sp-aquossense10.jpg)\
    \
    AQUOS sense10](https://www.jcom.co.jp/en/service/mobile/device/aquos_sense10/)
    
*    [![](https://www.jcom.co.jp/service/mobile/images_v10/index/img_sp-galaxya255g.jpg)\
    \
    Samsung Galaxy A25 5G](https://www.jcom.co.jp/en/service/mobile/device/galaxy_a25_5g/)
    
*    [![](https://www.jcom.co.jp/service/mobile/images_v10/index/img_sp-basio_active2.jpg)\
    \
    BASIO active2](https://www.jcom.co.jp/en/service/mobile/device/basio_active2/)
    
*   [Recommend\
    \
    ![](https://www.jcom.co.jp/service/mobile/images_v10/index/img_sp-googlepixel8a.jpg)\
    \
    Google Pixel 8a](https://www.jcom.co.jp/en/service/mobile/device/pixel_8a/)
    
*   [NEW\
    \
    ![](https://www.jcom.co.jp/service/mobile/images_v10/index/img_sp-aquossense10.jpg)\
    \
    AQUOS sense10](https://www.jcom.co.jp/en/service/mobile/device/aquos_sense10/)
    
*    [![](https://www.jcom.co.jp/service/mobile/images_v10/index/img_sp-galaxya255g.jpg)\
    \
    Samsung Galaxy A25 5G](https://www.jcom.co.jp/en/service/mobile/device/galaxy_a25_5g/)
    
*    [![](https://www.jcom.co.jp/service/mobile/images_v10/index/img_sp-basio_active2.jpg)\
    \
    BASIO active2](https://www.jcom.co.jp/en/service/mobile/device/basio_active2/)
    
*   [Recommend\
    \
    ![](https://www.jcom.co.jp/service/mobile/images_v10/index/img_sp-googlepixel8a.jpg)\
    \
    Google Pixel 8a](https://www.jcom.co.jp/en/service/mobile/device/pixel_8a/)
    
*   [NEW\
    \
    ![](https://www.jcom.co.jp/service/mobile/images_v10/index/img_sp-aquossense10.jpg)\
    \
    AQUOS sense10](https://www.jcom.co.jp/en/service/mobile/device/aquos_sense10/)
    
*    [![](https://www.jcom.co.jp/service/mobile/images_v10/index/img_sp-galaxya255g.jpg)\
    \
    Samsung Galaxy A25 5G](https://www.jcom.co.jp/en/service/mobile/device/galaxy_a25_5g/)
    
*    [![](https://www.jcom.co.jp/service/mobile/images_v10/index/img_sp-basio_active2.jpg)\
    \
    BASIO active2](https://www.jcom.co.jp/en/service/mobile/device/basio_active2/)
    

[See list of smartphones](https://www.jcom.co.jp/en/service/mobile/device/)

### eSIM for overseas travel (by Airalo)

[![eSIM for overseas travel (by Airalo)](https://www.jcom.co.jp/service/travelesim/images/hero.jpg)](https://www.jcom.co.jp/en/service/travelesim/)

J:COM MOBILE  
Reasons why we recommend it
------------------------------------------

Reason 1

Your price doesn’t change when you sign up for a smartphone and other services!  
​  
**Data Mori 5 GB 980 Yen/month ~** (Starting from 1,078 yen including tax)

[See more about Data Mori](https://www.jcom.co.jp/en/service/mobile/price/datamori/)

![ずーっとデータ増量！](https://www.jcom.co.jp/service/mobile/images_v10/recommend-point1.webp)

Reason 2

Because it supports au 5G/4G LTE  
**nationwide area  
comfortable connection**​ ​\*1

![au回線だから安心・快適！](https://www.jcom.co.jp/service/mobile/images_v10/recommend-point6_2511.png)

Reason 3

Remaining data capacity  
**without waste  
Carryover OK!**​ ​\*2

![ムダなくおトク！](https://www.jcom.co.jp/service/mobile/images_v10/recommend-point2.webp)

Reason 4

when data traffic is exceeded  
Even at speed limits  
**up to 1Mbps  
fast!**​ ​\*3

![動画や音楽、SNSもサクサク！](https://www.jcom.co.jp/service/mobile/images_v10/recommend-point3.webp)

Application flow
----------------

Sign Up

![Sign Up](https://www.jcom.co.jp/service/mobile/images_v10/index/img_webflow_01.png)

Pick up your device

![Pick up your device](https://www.jcom.co.jp/service/mobile/images_v10/index/img_webflow_02.png)

Perform initial setup

![(Image) Initial settings](https://www.jcom.co.jp/service/mobile/images_v10/index/img_webflow_03.png)

If you apply online, you don't have to go to the store and wait.  
The purchase process can be completed at your home.

[See more about the sign up process](https://www.jcom.co.jp/en/service/mobile/usage/)

[Initial settings and various support](https://www.jcom.co.jp/en/service/mobile/support/)

Customers with existing contracts
---------------------------------

[Support site information](https://cs.myjcom.jp/categories/support/67ab979df07f5244a208cdc9)

[Regarding various procedures  \
(Model change/plan change)](https://www.jcom.co.jp/en/service/mobile/user/)

You are currently logged in with your personal ID.

For User  
Introducing recommended information

[![ログイン](https://data.wovn.io/ImageValue/production/63c0b739b1e80445d40ae954/en/5bb00b0b2e2602f73298676023e7d029/login_b_en.png)](https://id.zaq.ne.jp/id/script/connect/authz_req/endpoint.seam?response_type=code&client_id=JCOM_COJP&redirect_uri=https%3A%2F%2Fwww.jcom.co.jp%2Fservice%2Fmobile%2F&scope=http%3A%2F%2Fjcom.co.jp%2Fconnect%2Fprofile%2Fstandard_new&nonce=398033787&state=&prompt=)

Recommended as a set/  
Popular services
----------------------------------------

 [![](https://www.jcom.co.jp/service/mobile/images_v10/common/img-service-ssi.webp)\
\
![](https://www.jcom.co.jp/common_v10/images/icn-jcom-ssi.svg) Insurance\
\
Breakdowns, damage, etc.  \
Prepare for smartphone emergencies](https://www.jcom.co.jp/en/service/ssi/kazoku_sumaho/?sc_pid=common_service_ssi_02)
 [![](https://www.jcom.co.jp/images_v10/img-service-net.webp)\
\
![](https://www.jcom.co.jp/common_v10/images/icn-jcom-net.svg) Net\
\
Super fast internet with optical fiber](https://www.jcom.co.jp/en/service/net/?sc_pid=common_service_net)
 [![](https://www.jcom.co.jp/images_v10/img-service-electricity.webp)\
\
![](https://www.jcom.co.jp/common_v10/images/icn-jcom-electricity.svg) electricity\
\
Convenient, all in one place](https://www.jcom.co.jp/en/service/electricity/?sc_pid=common_service_ele)

Campaigns/benefits
------------------

 [![J:COM MOBILE シニア60割](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_senior_kakeho.webp)](https://www.jcom.co.jp/en/service/mobile/campaign/senior/?sc_pid=common_campaign_senior_01)
[![J:COMモバイル 契約事務手数料無料](https://www.jcom.co.jp/campaign/images_v10/banner/camp_thumbnail3.webp)](https://www.jcom.co.jp/en/service/mobile/campaign/mobile_fee_0/?sc_pid=common_campaign_mobile_fee_0_01)

[Promotions/Benefits](https://www.jcom.co.jp/en/campaign/)

Customer feedback
-----------------

*   ### Cheap and connected  
    A safe smartphone
    
    I like J:COM MOBILE. Although the price is low, the connection is stable.
    
    20s/female
    
*   ### I signed a contract for my child.
    
    By subscribing to J:COM NET's Wi-Fi, I can enjoy the internet and games in the comfort of my home. Also, last month I signed up for a new smartphone for my child, and it's cheap so it's safe for my family budget. I am also considering switching to a carrier line for my family.
    
    40s/Female
    
*   ### I'm glad the data capacity has increased.
    
    The amount of data you can use on your smartphone (GB) has been increased for free starting from February. I'm very happy because I've been able to save on communication usage up until now.
    
    70s/female
    
*   ### Leave the troublesome initial settings to J:COM
    
    I switched my smartphone to J:COM and the charges are now half the price. J:COM came to my house and took care of all the data migration operations.
    
    60s/male
    
*   ### The line is stable and comfortable
    
    I am using my smartphone at J:COM. There are no slow connections during the day or evening, and I am very satisfied with the service.
    
    50s/Male
    
*   ### Music and videos on the go  
    Enjoy to the fullest
    
    The great thing about J:COM MOBILE is that you can use J:COM Music and J:COM STREAM from anywhere without incurring communication charges.
    
    40s/Male
    

 [![](https://data.wovn.io/ImageValue/production/63c0b739b1e80445d40ae954/en/1c96bc2b22afa0f2911f8ac6671abd01/voice_en_660%EF%BE%97260.png) ![](https://data.wovn.io/ImageValue/production/63c0b739b1e80445d40ae954/en/a506e0c2dcf10b95586a7de59ec2f068/voice_en_650%EF%BE%97150.png)](https://www.jcom.co.jp/en/service/voice/)

If you are considering signing up or adding services

### Sign Up information

New customers

[New Customers  \
Sign Up](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=mobile_web_entry&sc_pid=cv_mobile_entry_2)

[Contact us by phone  \
(Free call)​ ​0120-989-970](tel:0120-989-970)
 ​ ​9:00-18:00 \[Open all year round\]

Current customers

[Current Customers  \
Various procedures](https://r.jcom.jp/AeOCUFb)

[Problems/  \
inquiry  \
(chat)](https://prod8-live-chat.sprinklr.com/page?appId=67af27d73657336d345e4a96_app_9070639&did=CHAT_vivr_cojp_mobile&enableClose=true&skin=MODERN&userContext__c_679c8b53cb85b007fab0f6ea=DirectLink&utm_campaign=IVRSMS&utm_medium=referral&utm_source=did&webview=true&zoom=false)

[Check it easily in 30 seconds! Smartphone fee simulation](https://www.jcom.co.jp/en/service/mobile/simulator/)

FAQ
---

Procedures such as contracting and changing models are cumbersome.

You can easily apply online. Visiting support is also available upon request.

![](https://www.jcom.co.jp/service/mobile/usage/images/img_qa_02.jpg)

You can apply for J:COM MOBILE online. You can complete the process from the comfort of your own home, so there is no need to go to a store and wait for a long time.

Once you receive your smartphone, you can receive free support if you wish. We will provide detailed instructions on how to use your smartphone, as well as the initial settings.

[About initial setup support](https://www.jcom.co.jp/en/service/mobile/support/)

*   Those applying for "J:COM MOBILE D Plan SIM Card" are not eligible.

Can you issue a receipt?

Please refer to the link below for details on the initial costs incurred at the time of contract.

[Click here for initial cost](https://cs.myjcom.jp/knowledgeDetail?an=000004608#a2)

I want to know about support after joining

We offer a wide range of contact methods, from inquiries by phone or chat to guidance on our homepage with support information. In addition, by subscribing to Enkaku Support (550 yen per month (tax included)), you can receive remotely operated support from an operator.

[About Engaku Support](https://www.jcom.co.jp/en/service/omakase/)

Where can I check what plan I have?

You can check the plan you are subscribed to with J:COM MOBILE on My Page.

[Click here for my page](https://mypage.jcom.co.jp/)

[How to check on My Page](https://cs.myjcom.jp/knowledgeDetail?an=003068831)

Where can I see my call details?

You can check your J:COM MOBILE call details on My Page.

[Click here for my page](https://mypage.jcom.co.jp/)

[How to check on My Page](https://cs.myjcom.jp/knowledgeDetail?an=002465855)

I want to transfer data such as my phone book to a new smartphone, what should I do?

Solve difficult settings at home. Leave the initial settings of your smartphone to Enkaku Support!

J:COM MOBILE provides free support that provides detailed instructions on initial settings, migration of phonebook data, instructions on how to use the service, etc. for those who wish to do so.

[Click here for details](https://www.jcom.co.jp/en/service/mobile/support/)

Can I continue to use the email address I'm currently using on my J:COM MOBILE smartphone?

If you are using a free email service such as Gmail, you can continue to use it by logging in or setting up a new device.

Please note that if you are using an email address (domain) issued by some telecommunications companies, you will not be able to use it.

*   There are some services that allow you to continue using carrier mail even after canceling your carrier. Please refer [here](https://cs.myjcom.jp/knowledgeDetail?an=003423343)
     for details.

J:COM MOBILE does not issue email addresses, so we recommend that you switch to a free email such as G-mail in advance.

Can I carry over unused data usage?

Unused data traffic will be automatically carried over to the next month.

![](https://www.jcom.co.jp/service/mobile/price/images_v10/data_carry.webp)

\*The remaining amount is valid until the end of the following month.

If the upper limit is exceeded, the speed will be limited to 1Mbps or 200kbps depending on the plan you subscribe to. In addition to the data usage of your contract plan, you can also carry over any additional data usage you purchase to the next month.

Please check [here](https://cs.myjcom.jp/knowledgeDetail?an=000002838)
 for more information, including expiration dates.

Can I continue to use LINE on my new device?

By completing the appropriate settings and procedures, you can continue to use the service on your new device.

Regarding account migration (handover) procedures, security is regularly strengthened, so please check the latest information on LINE's official blog before proceeding.  
(\*Please note that settings may be required before changing the model)

[How to transfer your LINE account (as of July 2017)](https://official-blog-ja.line.me/archives/53494977.html)

Useful column
-------------

![Useful column](https://www.jcom.co.jp/service/mobile/images_v10/img_colum_oyakudachi.jpg)

We provide various information related to smartphones.

[Learn more](https://www.jcom.co.jp/service/mobile/column/)

\[Notes\]

*   Both voice calls and data communications can be used in au's 4G LTE area (some areas are 5G compatible). 3G communications cannot be used.  
    Even within the service area, communication may not be possible or communication speeds may be slow.  
    In addition, it may not be possible to use the device even if you are on a high floor of a high-rise building or apartment building with a good view.  
    Please check the au website for the latest area information. Communication speeds are best-effort services.  
    We do not guarantee a fixed speed, and it may vary depending on your environment.
*   The remaining amount is valid until the end of the following month.
*   For 10GB/20GB/50GB (20GB/30GB/60GB after increase) plans

*   The displayed communication speed is the maximum value according to technical standards and does not guarantee a constant speed. It varies depending on the usage environment.

Close

[シェアする](https://www.jcom.co.jp/service/mobile/)

[Tweet](https://twitter.com/share?ref_src=twsrc%5Etfw)

\[About the amount including tax\]

*   Consumption tax differences may occur due to changes in the consumption tax rounding method under the invoice system.

[Display is based on the Secondhand Goods Business Law](https://www.jcom.co.jp/en/service/kobutu/?sc_pid=newtop_other_kobutu)

1.  [J:COM Top](https://www.jcom.co.jp/en/)
    
2.  [Our Service](https://www.jcom.co.jp/en/service/)
    
3.  For low-cost smartphones, try J:COM MOBILE

[![ページ上部へ戻る](https://www.jcom.co.jp/common_v10/images/PageTop.webp)](https://www.jcom.co.jp/service/mobile/#header)

[Return to top of page](https://www.jcom.co.jp/service/mobile/#header)

[Service Information](https://www.jcom.co.jp/en/?sc_pid=common_footer_unav_service_01)

[Online Shop](https://onlineshop.jcom.co.jp/?sc_pid=common_footer_unav_ols_01)

[Support Troubleshooting/FAQ](https://cs.myjcom.jp/?sc_pid=common_footer_unav_csmyjcom_01)

[Fun! J:COM TV program information/presents and benefits](https://www.myjcom.jp/?sc_pid=common_footer_unav_myjcom_01)

[My page Confirm/change contract details](https://mypage.jcom.co.jp/?sc_pid=common_footer_unav_mypage_01)

[Company website](https://www.jcom.co.jp/en/corporate/?sc_pid=common_footer_unav_corporate_01)

*   [![Twitter](https://www.jcom.co.jp/common_v10/images/icn-x.svg)](https://twitter.com/jcom_info?sc_pid=common_footer_sns_twitter_01)
    
*   [![instagram](https://www.jcom.co.jp/common_v10/images/icn-instagram.svg)](https://www.instagram.com/jcom.official/?sc_pid=common_footer_sns_instagram_01)
    
*   [![Facebook](https://www.jcom.co.jp/common_v10/images/icn-facebook.svg)](https://www.facebook.com/JCOM.ZAQ?sc_pid=common_footer_sns_facebook_01)
    
*   [![LINE](https://www.jcom.co.jp/common_v10/images/icn-line.svg)](https://www.jcom.co.jp/en/social/campaign/line/?sc_pid=common_footer_sns_line_01)
    
*   [![note](https://www.jcom.co.jp/common_v10/images/icn-note.svg)](https://note.jcom.co.jp/?sc_pid=common_footer_sns_note_01)
    

[Account list](https://www.jcom.co.jp/en/service/social/?sc_pid=common_footer_sns_list_01)

[![J:COM J:COM ANNIVERSARY: Making Newness a Natural Thing](https://www.jcom.co.jp/common_v10/images/logo-jcom-horizontal.svg)](https://www.jcom.co.jp/en/special/30th/)

*   [Site map](https://www.jcom.co.jp/en/sitemap/?sc_pid=common_footer_sitemap)
    
*   [Privacy portal](https://www.jcom.co.jp/en/corporate/site_info/privacy-portal/?sc_pid=common_footer_privacybasic)
    
*   [Privacy policy](https://www.jcom.co.jp/en/corporate/site_info/privacy_policy/?sc_pid=common_footer_privacy)
    
*   [Web Accessibility Initiatives](https://www.jcom.co.jp/en/corporate/site_info/accessibility/?sc_pid=common_footer_accessibility)
    
*   [Security policy](https://www.jcom.co.jp/en/corporate/site_info/security_policy/?sc_pid=common_footer_security)
    
*   [Social media policy](https://www.jcom.co.jp/en/corporate/site_info/socialmedia_policy/?sc_pid=common_footer_social)
    
*   [Human Rights Policy](https://www.jcom.co.jp/en/corporate/sustainability/well_being/hrp/?sc_pid=common_footer_hrp#policy)
    
*   [Regarding the use of cookie information, advertisement distribution, etc.](https://www.jcom.co.jp/en/corporate/site_info/privacy_policy/cookie/?sc_pid=common_footer_cookie)
    
*   [Inquiries](https://www.jcom.co.jp/en/contactus/?sc_pid=common_footer_contactus)
    
*   [Company website](https://www.jcom.co.jp/en/corporate/?sc_pid=common_footer_corporate)
    
*   [Careers](https://recruit.jcom.co.jp/?sc_pid=common_footer_recruit)
    
*   [Corporate customers](https://business.jcom.co.jp/?sc_pid=common_footer_business)
    
*   [About This Site](https://www.jcom.co.jp/en/site_info/?sc_pid=common_footer_siteinfo)
    

Copyright © JCOM Co., Ltd. All Rights Reserved.

[](https://www.jcom.co.jp/service/mobile/#)

Configure area

Please enter your postal code.

〒

No hyphen (-) required

Please select your housing type.

![icon](https://www.jcom.co.jp/common_v10/images/icn-apartment.svg)Apartments

![icon](https://www.jcom.co.jp/common_v10/images/icn-house.svg)Houses

Please select the appropriate age.  
(The plans available will change.)

Age 27 or older

​Under 26 years old

​Under 22 years old

Next

[](https://www.jcom.co.jp/service/mobile/#)

Configure area

Please enter your postal code.

〒

 

Please select your housing type.

![icon](https://www.jcom.co.jp/common_v10/images/icn-apartment.svg)Apartments

![icon](https://www.jcom.co.jp/common_v10/images/icn-house.svg)Houses

Next

[](https://www.jcom.co.jp/service/mobile/#)

Configure area

Please enter your postal code.

〒

 

Please select your housing type.

![icon](https://www.jcom.co.jp/common_v10/images/icn-apartment.svg)Apartments

![icon](https://www.jcom.co.jp/common_v10/images/icn-house.svg)Houses

Next

[](https://www.jcom.co.jp/service/mobile/#)

Configure area

Please enter your postal code.

〒

No hyphen (-) required

Next

[](https://www.jcom.co.jp/service/mobile/#)

Configure area

Please enter your postal code.

〒

 

Please select your housing type.

![icon](https://www.jcom.co.jp/common_v10/images/icn-apartment.svg)Apartments

![icon](https://www.jcom.co.jp/common_v10/images/icn-house.svg)Houses

Next

[](https://www.jcom.co.jp/service/mobile/#)

Check service

Please enter the postal code of your new address.

〒

 

Next

[](https://www.jcom.co.jp/service/mobile/#)

J:COM Telemedicine coverage area check

Please enter your postal code.

〒

No hyphen (-) required

Please select your housing type.

![icon](https://www.jcom.co.jp/common_v10/images/icn-apartment.svg)Apartments

![icon](https://www.jcom.co.jp/common_v10/images/icn-house.svg)Houses

Next

[](https://www.jcom.co.jp/service/mobile/#)

Select prefecture

Required Select prefecture.

Hokkaido and Tohoku

[Hokkaido](https://www.jcom.co.jp/service/mobile/#)
 [Miyagi Prefecture](https://www.jcom.co.jp/service/mobile/#)

Kanto

[Tokyo](https://www.jcom.co.jp/service/mobile/#)
 [Kanagawa Prefecture](https://www.jcom.co.jp/service/mobile/#)
 [Chiba Prefecture](https://www.jcom.co.jp/service/mobile/#)
 [Saitama Prefecture](https://www.jcom.co.jp/service/mobile/#)
 [Gunma Prefecture](https://www.jcom.co.jp/service/mobile/#)
 [Ibaraki Prefecture](https://www.jcom.co.jp/service/mobile/#)

Kansai

[Osaka Prefecture](https://www.jcom.co.jp/service/mobile/#)
 [Kyoto Prefecture](https://www.jcom.co.jp/service/mobile/#)
 [Wakayama Prefecture](https://www.jcom.co.jp/service/mobile/#)
 [Hyogo Prefecture](https://www.jcom.co.jp/service/mobile/#)

Kyushu/Yamaguchi

[Fukuoka Prefecture](https://www.jcom.co.jp/service/mobile/#)
 [Kumamoto Prefecture](https://www.jcom.co.jp/service/mobile/#)
 [Oita Prefecture](https://www.jcom.co.jp/service/mobile/#)
 [Yamaguchi Prefecture](https://www.jcom.co.jp/service/mobile/#)

[Return](https://www.jcom.co.jp/service/mobile/#)

[](https://www.jcom.co.jp/service/mobile/#)

Select city/ward/town

Required Please select your city.

Current selection: Tokyo

*   A
*   Ka
*   Sa
*   Ta
*   Na
*   Ha
*   Ma
*   Ya
*   Ra
*   Wa

[Akishima City](https://www.jcom.co.jp/service/mobile/#)
 [Akiruno City](https://www.jcom.co.jp/service/mobile/#)
 [Adachi Ward](https://www.jcom.co.jp/service/mobile/#)
 [Itabashi Ward](https://www.jcom.co.jp/service/mobile/#)
 [Inagi City](https://www.jcom.co.jp/service/mobile/#)
 [Edogawa Ward](https://www.jcom.co.jp/service/mobile/#)
 [Ota Ward](https://www.jcom.co.jp/service/mobile/#)

Contents of “Ka”

Regions starting with “A”

[Akishima City](https://www.jcom.co.jp/service/mobile/#)
 [Akiruno City](https://www.jcom.co.jp/service/mobile/#)
 [Adachi Ward](https://www.jcom.co.jp/service/mobile/#)
 [Itabashi Ward](https://www.jcom.co.jp/service/mobile/#)
 [Inagi City](https://www.jcom.co.jp/service/mobile/#)
 [Edogawa Ward](https://www.jcom.co.jp/service/mobile/#)
 [Ota Ward](https://www.jcom.co.jp/service/mobile/#)

Regions starting with “Ka”

Regions starting with “Sa”

Regions starting with “Ta”

Regions starting with “Na”

[Return](https://www.jcom.co.jp/service/mobile/#)

[](https://www.jcom.co.jp/service/mobile/#)

Configure area

〒 1070052

There are several possible areas for the postal code you entered.  
Please select your address from the list below

Please select 1 2 3 text text text

Configure

[Return](https://www.jcom.co.jp/service/mobile/#)

[](https://www.jcom.co.jp/service/mobile/#)

Configure area

〒 \-------

Please select the following address information.

  

Please select 1 2 3 text text text

Next

[Return](https://www.jcom.co.jp/service/mobile/#)

[](https://www.jcom.co.jp/service/mobile/#)

Check Gig coverage area

〒 1070052 (J:COM Machida/Kawasaki)

This is the coverage area of the J:COM NET 1G plan  
​

\* "J:COM NET 1Gig plan" is a 1Gig service that can be used with cable TV lines.

This is the coverage area for Hikari 10G/5G/1G plan  
​

\* Hikari is not available in some areas (gradually expanding service areas) [For more information, please contact us here.](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

Hikari 10G/5G/1G plan \*1  
coverage area is currently being expanded.

J:COM NET 1G plan \*2  
coverage area.

\*1 Hikari is not available in some areas (gradually expanding service areas) [For more information, please contact us here.](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

\*2 "J:COM NET 1Gig plan" is a 1Gig service that can be used with cable TV lines.

Hikari 10G/5G/1G plan  
J:COM NET 1G plan  
coverage area.

\*Not available in some areas (gradually expanding service areas) [For more information, please contact us here.](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

\* "J:COM NET 1Gig plan" is a 1Gig service that can be used with cable TV lines.

Outside the J:COM NET 1G plan  
coverage area. (Sequentially expanding the coverage area)

is in the 320M plan  
coverage area.

is in the 320M plan  
coverage area.

The J:COM NET 1G plan coverage area is gradually expanding.

[For detailed information on the coverage area, contact us here.](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

This is the service area of J:COM Oita (Oita Cable Telecom Co., Ltd.).  
[Please refer to the J:COM Oita (Oita Cable Telecom Co., Ltd.) homepage.](https://wwwjcom.oct-net.ne.jp/)
​

This is the Yokohama Cable Vision (YCV) service area.  
[Please refer to the Yokohama Cable Vision (YCV) homepage.](https://www.catv-yokohama.ne.jp/)
​

[Sign Up](https://www.jcom.co.jp/sim_contact/entry_request.php?refresh=new&net_service=1)

[Check the sign up process](https://www.jcom.co.jp/en/service/guide/sdu/)

Some areas may be outside the coverage area.

[View prices/plans](https://www.jcom.co.jp/en/service/net/)

Return

[](https://www.jcom.co.jp/service/mobile/#)

Check Gig coverage area

〒 1070052 (Machida/Kawasaki)

Hikari 10G/5G/1G plan  
J:COM NET 1G plan  
coverage area.

\* "J:COM NET 1Gig plan" is a 1Gig service that can be used with cable TV lines.

Hikari 10G/5G/1G plan  
coverage area.

Hikari 1G plan  
J:COM NET 1G plan  
coverage area.

\* "J:COM NET 1Gig plan" is a 1Gig service that can be used with cable TV lines.

Hikari 1G plan  
coverage area.

is in the 320M plan  
coverage area.

[Sign Up](https://www.jcom.co.jp/sim_contact/entry_request.php?refresh=new&net_service=1)

[Check the sign up process](https://www.jcom.co.jp/en/service/guide/sdu/)

Some areas may be outside the coverage area.

View prices/plans

[Savings calculator](https://onlineshop.jcom.co.jp/Simulation/Simulation)

Return

[](https://www.jcom.co.jp/service/mobile/#)

Check Gig coverage area

〒 1070052 

is out of the J:COM NET  
coverage area.

is in the J:COM WiMAX  
coverage area.

[Sign Up](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=wimax2p)

[Check the sign up process](https://www.jcom.co.jp/en/service/guide/sdu/)

Some areas may be outside the coverage area.

[View prices/plans](https://www.jcom.co.jp/en/service/wimax/)

Return

[](https://www.jcom.co.jp/service/mobile/#)

Check coverage areas

〒 \------- 

This is the service area of J:COM Oita (Oita Cable Telecom Co., Ltd.).  
[Please refer to the J:COM Oita (Oita Cable Telecom Co., Ltd.) homepage.](https://wwwjcom.oct-net.ne.jp/)
​

This is the Yokohama Cable Vision (YCV) service area.  
[Please refer to the Yokohama Cable Vision (YCV) homepage.](https://www.catv-yokohama.ne.jp/)
​

The following services are available.

   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-mobile.svg) ![J:COM MOBILE](https://www.jcom.co.jp/common_v10/images/logo-jcom-mobile.svg)](https://www.jcom.co.jp/en/service/mobile/)   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-electricity.svg) ![J:COM Denki](https://www.jcom.co.jp/common_v10/images/logo-jcom-electricity.svg)](https://www.jcom.co.jp/en/service/electricity/)
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-gas.svg) ![J:COM GAS](https://www.jcom.co.jp/common_v10/images/logo-jcom-gas.svg)](https://www.jcom.co.jp/en/service/gas/)
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-ssi.svg) ![J:COM Insurance](https://www.jcom.co.jp/common_v10/images/logo-jcom-ssi.svg)](https://www.jcom.co.jp/en/service/ssi/)
  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-telemedicine.svg) ![J:COM Telemedicine](https://www.jcom.co.jp/common_v10/images/logo-jcom-telemedicine.svg)](https://www.jcom.co.jp/en/service/telemedicine/)

The following services are [Price simulation](https://onlineshop.jcom.co.jp/Simulation/Simulation)
 in  
Please check the area.

  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-net.svg)\
\
![J:COM NET](https://www.jcom.co.jp/common_v10/images/logo-jcom-net.svg) Optical 10G/Optical 1G](https://www.jcom.co.jp/en/price/hikari-n/)  ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-tv.svg) Terrestrial digital/BS digital  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-phone.svg) Hikari Denwa](https://www.jcom.co.jp/en/price/hikari-n/phone-op/)

J:COM NET is provided via NTT line.

[Sign Up](https://onlineshop.jcom.co.jp/planSelect)

[Savings calculator](https://onlineshop.jcom.co.jp/Simulation/Simulation)

If you want local cable TV ​ ​[here](https://www.catv-jcta.jp/search/index)

Return

Some services may not be available depending on your region.

[](https://www.jcom.co.jp/service/mobile/#)

Check service

〒 1070052​

This is the service area of J:COM Oita (Oita Cable Telecom Co., Ltd.). Please refer to the [J:COM Oita (Oita Cable Television Co., Ltd.) website to confirm what services](https://wwwjcom.oct-net.ne.jp/)
 are provided.

This is the Yokohama Cable Vision (YCV) service area.  
[Please refer to the Yokohama Cable Vision (YCV) homepage.](https://www.catv-yokohama.ne.jp/)
​

The following services are available.

   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-tv.svg) ![J:COM TV](https://www.jcom.co.jp/common_v10/images/logo-jcom-tv.svg)](https://www.jcom.co.jp/en/service/tv/)   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-net.svg) ![J:COM NET](https://www.jcom.co.jp/common_v10/images/logo-jcom-net.svg)](https://www.jcom.co.jp/en/service/net/)
  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-mobile.svg) ![J:COM MOBILE](https://www.jcom.co.jp/common_v10/images/logo-jcom-mobile.svg)](https://www.jcom.co.jp/en/service/mobile/)
  
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-phone.svg) ![J:COM PHONE](https://www.jcom.co.jp/common_v10/images/logo-jcom-phone.svg)](https://www.jcom.co.jp/en/service/phone/)   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-ssi.svg) ![J:COM Insurance](https://www.jcom.co.jp/common_v10/images/logo-jcom-ssi.svg)](https://www.jcom.co.jp/en/service/ssi/)
  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-telemedicine.svg) ![J:COM Telemedicine](https://www.jcom.co.jp/common_v10/images/logo-jcom-telemedicine.svg)](https://www.jcom.co.jp/en/service/telemedicine/)

[J:COMご加入中の方  \
お引越しのお手続き](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=contact_move)

Return to postal code input

[](https://www.jcom.co.jp/service/mobile/#)

Check coverage areas

〒 1070052 (J:COM Machida/Kawasaki)

The following services are available.

   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-tv.svg) ![J:COM TV](https://www.jcom.co.jp/common_v10/images/logo-jcom-tv.svg)](https://www.jcom.co.jp/en/service/tv/)   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-net.svg) ![J:COM NET](https://www.jcom.co.jp/common_v10/images/logo-jcom-net.svg)](https://www.jcom.co.jp/en/service/net/)
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-mobile.svg) ![J:COM MOBILE](https://www.jcom.co.jp/common_v10/images/logo-jcom-mobile.svg)](https://www.jcom.co.jp/en/service/mobile/)
  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-electricity.svg) ![J:COM Denki](https://www.jcom.co.jp/common_v10/images/logo-jcom-electricity.svg)](https://www.jcom.co.jp/en/service/electricity/)
  
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-phone.svg) ![J:COM PHONE](https://www.jcom.co.jp/common_v10/images/logo-jcom-phone.svg)](https://www.jcom.co.jp/en/service/phone/)   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-gas.svg) ![J:COM GAS](https://www.jcom.co.jp/common_v10/images/logo-jcom-gas.svg)](https://www.jcom.co.jp/en/service/gas/)
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-ssi.svg) ![J:COM Insurance](https://www.jcom.co.jp/common_v10/images/logo-jcom-ssi.svg)](https://www.jcom.co.jp/en/service/ssi/)
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-home.svg) ![J:COM HOME](https://www.jcom.co.jp/common_v10/images/logo-jcom-home.svg)](https://www.jcom.co.jp/en/service/home/)
  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-telemedicine.svg) ![J:COM Telemedicine](https://www.jcom.co.jp/common_v10/images/logo-jcom-telemedicine.svg)](https://www.jcom.co.jp/en/service/telemedicine/)

[Application](https://onlineshop.jcom.co.jp/planSelect)
 ​ ​[Application](https://onlineshop.jcom.co.jp/planSelect)

[Check the sign up process](https://www.jcom.co.jp/en/service/guide/sdu/)

Savings calculator

Return

[](https://www.jcom.co.jp/service/mobile/#)

Check service

〒 1070052 (J:COM Machida/Kawasaki)

The following services are available.

   ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-tv.svg) ![J:COM TV](https://www.jcom.co.jp/common_v10/images/logo-jcom-tv.svg) ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-net.svg) ![J:COM NET](https://www.jcom.co.jp/common_v10/images/logo-jcom-net.svg)  ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-mobile.svg) ![J:COM MOBILE](https://www.jcom.co.jp/common_v10/images/logo-jcom-mobile.svg)  ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-electricity.svg) ![J:COM Denki](https://www.jcom.co.jp/common_v10/images/logo-jcom-electricity.svg)  
   ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-phone.svg) ![J:COM PHONE](https://www.jcom.co.jp/common_v10/images/logo-jcom-phone.svg) ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-gas.svg) ![J:COM GAS](https://www.jcom.co.jp/common_v10/images/logo-jcom-gas.svg)  ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-home.svg) ![J:COM HOME](https://www.jcom.co.jp/common_v10/images/logo-jcom-home.svg)

[J:COMご加入中の方  \
お引越しのお手続き](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=contact_move)

Return to postal code input

[](https://www.jcom.co.jp/service/mobile/#)

Check coverage areas

Please select your service.

Get your TV and Internet together!

 ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-tv.svg)  
![J:COM TV](https://www.jcom.co.jp/common_v10/images/logo-jcom-tv.svg)![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-net.svg)  
![J:COM NET](https://www.jcom.co.jp/common_v10/images/logo-jcom-net.svg) ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-phone.svg)  
![J:COM PHONE](https://www.jcom.co.jp/common_v10/images/logo-jcom-phone.svg)

[Savings calculator](https://onlineshop.jcom.co.jp/Simulation/Simulation)

Save more money on your monthly smartphone bill.

![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-mobile.svg)  
![J:COM MOBILE](https://www.jcom.co.jp/common_v10/images/logo-jcom-mobile.svg)

[Savings calculator](https://www.jcom.co.jp/en/service/mobile/simulator/)

Return

[](https://www.jcom.co.jp/service/mobile/#)

Check J:COM GAS coverage area

〒 1070052  ( J:COM ---- )​

![](https://www.jcom.co.jp/common_form/img/common/logo/logo_gas_osaka.png)

coverage area.

Some areas may be outside the coverage area.

![](https://www.jcom.co.jp/common_form/img/common/logo/logo_gas_tokyo.png)

coverage area.

Some areas may be outside the coverage area.

![](https://www.jcom.co.jp/common_form/img/common/logo/logo_gas_keiyo.png)

coverage area.

Some areas may be outside the coverage area.

is out of the J:COM GAS  
coverage area.

Energy Uchuu Co., Ltd. \[Koshigaya/Kasukabe area/Hasuda Minami area\] \[Toride/Abiko area\]  
If you live in an area where city gas is supplied,

you can use the

Tokyo Gas for J:COM "ZUTTO Gas" service.

[Learn more](https://www.jcom.co.jp/en/service/tokyo_gas/)

is out of the J:COM GAS  
coverage area.

Return

[](https://www.jcom.co.jp/service/mobile/#)

J:COM Telemedicine coverage area check

〒 1070052  ( J:COM ---- )​

J:COM Telemedicine  
coverage area.

Some areas may be outside the coverage area.

[See list of medical institutions](https://www.jcom.co.jp/en/service/telemedicine/clinic/)

[See prices](https://www.jcom.co.jp/en/service/telemedicine/price/)

Outside the J:COM Telemedicine  
coverage area.

Return

    

[](https://www.jcom.co.jp/service/mobile/#)

Notice to you
-------------

[Logout](https://www.jcom.co.jp/en/common/logout.html)

日本語

English
