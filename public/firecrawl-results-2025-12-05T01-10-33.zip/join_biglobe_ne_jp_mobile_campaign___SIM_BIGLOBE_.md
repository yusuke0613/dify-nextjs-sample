# キャンペーン一覧｜格安SIM/スマホのBIGLOBEモバイル

URL: https://join.biglobe.ne.jp/mobile/campaign/

---

*   サービス
    
    サービス
    
    *   [![BIGLOBE光](https://top.bcdn.jp/images/ImgService-1.png)](https://join.biglobe.ne.jp/ftth/hikari/?cl=global_header_hikari_logo)
        
    *   [![BIGLOBE mobile](https://top.bcdn.jp/images/ImgService-2.png)](https://join.biglobe.ne.jp/mobile/?cl=global_header_mobile_logo)
        
    *   [![BIGLOBE WiMAX](https://top.bcdn.jp/images/ImgService-3.png)](https://join.biglobe.ne.jp/mobile/wimax/?cl=global_header_wimax_logo)
        
    *   [![BIGLOBE biz](https://top.bcdn.jp/images/ImgService-4.png)](https://biz.biglobe.ne.jp/index.html)
        
    
    通信サービス
    
    *   [BIGLOBE光](https://join.biglobe.ne.jp/ftth/hikari/?cl=global_header_hikari_text)
        
    *   [auひかり](https://join.biglobe.ne.jp/ftth/one/?cl=global_header_one_text)
        
    *   [BIGLOBEモバイル](https://join.biglobe.ne.jp/mobile/?cl=global_header_mobile_text)
        
    *   [BIGLOBE WiMAX](https://join.biglobe.ne.jp/mobile/wimax/?cl=global_header_wimax_text)
        
    
    オプションサービス
    
    *   [お助けサポート＋](https://otasuke.biglobe.ne.jp/otasuke_plus/)
        
    *   [インターネット端末保証サービス](https://service.biglobe.ne.jp/internethosho/)
        
    *   [トータル・ネットセキュリティ](https://security.biglobe.ne.jp/tns/)
        
    *   [U-NEXT for BIGLOBE](https://vod.biglobe.ne.jp/unext/)
        
    *   [その他オプション](https://service.biglobe.ne.jp/)
        
    
    Webメディア
    
    *   [温泉大賞](https://biz.biglobe.ne.jp/onsen/award/)
        
    *   [しむぐらし](https://join.biglobe.ne.jp/mobile/sim/gurashi/)
        
    *   [あしたメディア](https://ashita.biglobe.co.jp/)
        
    
    法人のお客さま
    
    *   [BIGLOBE biz.](https://biz.biglobe.ne.jp/index.html)
        
    
*   企業情報
    
    企業情報
    
    *   [![](https://top.bcdn.jp/images/ImgCompany-1.png)\
        \
        企業情報トップ](https://www.biglobe.co.jp/outline)
        
    *   [![](https://top.bcdn.jp/images/ImgCompany-2.png)\
        \
        採用情報](https://www.biglobe.co.jp/recruit)
        
    *   [![](https://top.bcdn.jp/images/ImgCompany-3.png)\
        \
        ブランド](https://www.biglobe.co.jp/outline/brand)
        
    
*   [](https://mypage.sso.biglobe.ne.jp/?cl=global_header_mypage)
    

[メニュー 閉じる](https://join.biglobe.ne.jp/mobile/campaign/)

[![BIGLOBE mobile](https://join.biglobe.ne.jp/v4/image/header/logo_mobile.svg?v=69e3c7748a)](https://join.biglobe.ne.jp/mobile/?cl=head_logo_mobile)

詳細を確認して

[お申し込み](https://join.biglobe.ne.jp/mobile/prepare/?cl=head_mobile_order)

*   [BIGLOBEモバイルTOP](https://join.biglobe.ne.jp/mobile/?cl=head_mobile_top)
    
*   料金プラン
    
    *   [料金プラン](https://join.biglobe.ne.jp/mobile/plan/?cl=head_mobile_plan_list)
        
    *   [BIGLOBE家族割](https://join.biglobe.ne.jp/mobile/plan/family/?cl=head_mobile_family)
        
    *   [シェアSIM](https://join.biglobe.ne.jp/mobile/plan/share-sim/?cl=head_mobile_share-sim)
        
    *   [ぴったりプラン診断](https://join.biglobe.ne.jp/mobile/plan/navigator/?cl=head_mobile_navigator)
        
*   端末
    
    *   [端末一覧](https://join.biglobe.ne.jp/mobile/device/?cl=head_mobile_device)
        
    *   [機種変更](https://join.biglobe.ne.jp/mobile/device/change.html?cl=head_mobile_change)
        
*   [動作確認端末](https://join.biglobe.ne.jp/mobile/device/compatibility.html?cl=head_mobile_device_comp)
    
*   オプション
    
    *   [オプション一覧](https://join.biglobe.ne.jp/mobile/option/?cl=head_mobile_option_list)
        
    *   [エンタメフリー・オプション](https://join.biglobe.ne.jp/mobile/option/entamefree.html?cl=head_mobile_option_entame)
        
    *   [選べる通話オプション](https://join.biglobe.ne.jp/mobile/option/bigtel.html?cl=head_mobile_option_call)
        
    *   [SIM端末保証サービス](https://join.biglobe.ne.jp/mobile/option/simhosho.html?cl=head_mobile_option_simhosho)
        
    *   [セキュリティセット・プレミアム](https://join.biglobe.ne.jp/mobile/option/security_set.html?cl=head_mobile_option_security_set)
        
*   [キャンペーン](https://join.biglobe.ne.jp/mobile/campaign/?cl=head_mobile_campaign)
    
*   申込ガイド
    
    *   [申込ガイド](https://join.biglobe.ne.jp/mobile/support/?cl=head_mobile_support_list)
        
    *   [まるわかりガイド](https://join.biglobe.ne.jp/mobile/support/guide/?cl=head_mobile_support_guide)
        
    *   [よくある質問](https://join.biglobe.ne.jp/mobile/support/faq.html?cl=head_mobile_support_faq)
        
    *   [ご利用までの流れ](https://join.biglobe.ne.jp/mobile/prepare/?cl=head_mobile_support_prepare#prepare_flow)
        
    *   [他社からのお乗り換え(MNP)](https://join.biglobe.ne.jp/mobile/prepare/mnp.html?cl=head_mobile_support_mnp)
        
*   店舗
    
    *   [店舗のご紹介](https://join.biglobe.ne.jp/mobile/shop/?cl=head_mobile_shop_info)
        
    *   [店舗検索](https://join.biglobe.ne.jp/mobile/shop/search.html?cl=head_mobile_shop_search)
        
*   詳細を確認して
    
    [詳細を確認してお申し込み](https://join.biglobe.ne.jp/mobile/prepare/?cl=head_mobile_order)
    

格安SIM/スマホのキャンペーン一覧

BIGLOBEモバイルの格安SIM/スマホのおトクなキャンペーン情報をご紹介します。

*   [開催中のキャンペーン情報](https://join.biglobe.ne.jp/mobile/campaign/#osusume)
    
*   [BIGLOBE会員向けのおトクな情報](https://join.biglobe.ne.jp/mobile/campaign/#otoku)
    

開催中のキャンペーン情報
------------

*   特典の条件など、詳細は特典ページでご確認ください。

[![エンタメフリー・オプション 音声SIM最大2カ月無料(初回申込)](https://join.biglobe.ne.jp/v4/image/mobile/option/entamefree/main_smp.png?v=d148915322)](https://join.biglobe.ne.jp/mobile/option/entamefree.html?cl=mobile_campaign_enta)

#### エンタメフリー・オプション初回申込特典

YouTube など対象の動画や音楽が楽しみ放題！最大2カ月無料

対象者

音声通話SIMご利用で本オプションを初めてお申し込みの方

期間

2023年10月2日 〜

[詳細をみる](https://join.biglobe.ne.jp/mobile/option/entamefree.html?cl=mobile_campaign_enta)

[![セキュリティセット・プレミアム初回申込特典](https://join.biglobe.ne.jp/v4/image/mobile/option/security_set/bnr_campaign.png?v=e2c0881280)](https://join.biglobe.ne.jp/mobile/option/security_set.html?cl=mobile_campaign_sspr)

#### セキュリティセット・プレミアム基本ライセンス 最大2カ月無料特典

スマホとパソコン最大3台まで利用可能

対象者

本オプションを初めてお申し込みの方

[詳細をみる](https://join.biglobe.ne.jp/mobile/option/security_set.html?cl=mobile_campaign_sspr)

BIGLOBEモバイルのお申し込みはこちら

[料金プラン](https://join.biglobe.ne.jp/mobile/plan/)
をご確認ください。

[SIMのプランを選ぶ](https://join.biglobe.ne.jp/select/?preset=sim_open/)

[スマホを選ぶ](https://join.biglobe.ne.jp/select/?preset=all_open&productType=SMP&reset=true/#/plan)

BIGLOBE会員向けのおトクな情報
------------------

BIGLOBEサービスをご利用になっている方向けのサービス情報をご紹介します。

[![家族みんなで乗り換えよう！2回線目以降、毎月ずーっと200円割引でおトクに使えます。](https://join.biglobe.ne.jp/v4/image/mobile/plan/family/index/main_smp.png?v=60e3567bd5)](https://join.biglobe.ne.jp/mobile/plan/family/?cl=mobile_campaign_kazoku)

#### BIGLOBE家族割

家族みんなで乗り換えよう！2回線目以降、毎月ずーっと200円割引でおトクに使えます。

対象者

家族会員(家族ID)で、BIGLOBEモバイルを申し込まれた方

[詳細をみる](https://join.biglobe.ne.jp/mobile/plan/family/?cl=mobile_campaign_kazoku)

[![クーポンにエントリーのうえBIGLOBEモバイルの端末をご購入いただくと、2,000Ｇポイントを進呈！](https://join.biglobe.ne.jp/v4/image/mobile/campaign/bnr_model_change_cp.png?v=44719b5a81)](https://member.sso.biglobe.ne.jp/loyalty/coupon?cl=mobile_campaign_change)

#### 端末申込クーポン

クーポンにエントリーして、BIGLOBEモバイル端末を購入すると、2,000Ｇポイント進呈！

対象者

BIGLOBEモバイル(音声通話SIM)をご利用の方

[詳細をみる](https://member.sso.biglobe.ne.jp/loyalty/coupon?cl=mobile_campaign_change)

[![つかいみちたっぷり、交換もカンタン！Ｇポイントはいろんな提携先と交換できます](https://join.biglobe.ne.jp/v4/image/mobile/campaign/bnr_gpoint.png?v=1cdbfa38fa)](https://join.biglobe.ne.jp/ftth/hikari/gpoint/?cl=mobile_campaign_gp)

#### Ｇポイント

BIGLOBEサービスの利用料金に応じて毎年Ｇポイントがもらえます。

対象者

BIGLOBEのサービスをご利用の方

[詳細をみる](https://join.biglobe.ne.jp/ftth/hikari/gpoint/?cl=mobile_campaign_gp)

よくある質問
------

*   [![](https://join.biglobe.ne.jp/v4/image/mobile/icon/icon_q.svg?v=30e24e98f4)\
    \
    キャンペーン・特典はありますか？](https://join.biglobe.ne.jp/mobile/campaign/#faq_campaign)
    
    BIGLOBEモバイルでは格安SIM/スマホをおトクに申し込めるキャンペーンをご用意しています。期間限定の特典や会員向けのおトク情報も満載。ぜひチェックしてみてください。
    
*   [![](https://join.biglobe.ne.jp/v4/image/mobile/icon/icon_q.svg?v=30e24e98f4)\
    \
    Ｇポイントとは何ですか？](https://join.biglobe.ne.jp/mobile/campaign/#faq_gpoint)
    
    「[Ｇポイント](https://join.biglobe.ne.jp/mobile/contents/gpoint/)
    」とはBIGLOBEのポイントプログラムで、1Ｇ＝1円相当でBIGLOBE利用料金(税抜)のお支払いにポイントを使えたり、さまざまな提携先のポイントやギフト券、現金などと交換できます。
    
    *   交換レート・交換手数料は[こちら](https://pmall.gpoint.co.jp/shopsearch/?penservice=gtop)
        
    
    ＧポイントはBIGLOBEの接続サービスのご利用、各種サービス・コンテンツの購入や、ネットショッピング・ゲーム参加など、さまざまな方法で貯めることができます。
    
*   [![](https://join.biglobe.ne.jp/v4/image/mobile/icon/icon_q.svg?v=30e24e98f4)\
    \
    家族割引はありますか？](https://join.biglobe.ne.jp/mobile/campaign/#faq_family_discount)
    
    ご家族でBIGLOBEモバイルを2回線目以降ご契約いただくと、毎月200円割引でお使いいただけます。BIGLOBE会員に加え、家族会員は最大4人まで登録できます。  
    たとえば、5人家族で契約した場合、家族会員4人分×200円割引で毎月800円お安く使えます。  
    [「BIGLOBE家族割」](https://join.biglobe.ne.jp/mobile/plan/family/)
    

[もっとみる](https://join.biglobe.ne.jp/mobile/support/faq.html?cl=mobile_cp_faqmore#category)

BIGLOBEモバイルで格安SIMをはじめよう

[料金プラン](https://join.biglobe.ne.jp/mobile/plan/)
をご確認ください。

[Webでお申し込み](https://join.biglobe.ne.jp/mobile/prepare/?cl=mobile_footcv_signup)

1.  ![home](https://join.biglobe.ne.jp/v4/image/icon/icon_home.svg)
2.  [BIGLOBEモバイルTOP](https://join.biglobe.ne.jp/mobile/)
    
3.  格安SIM/スマホのキャンペーン一覧
    ==================
    

[サイトマップ](https://join.biglobe.ne.jp/sitemap.html)

[](https://www.biglobe.co.jp/outline/brand/bipple)

[](https://www.biglobe.ne.jp/)

*   [](https://twitter.com/biglobe)
    
*   [](https://www.instagram.com/biglobe_official/)
    
*   [](https://www.facebook.com/BIGLOBE)
    
*   [](https://www.youtube.com/user/BIGLOBEchannel)
    

個人のお客さま

通信サービス

*   [BIGLOBE光](https://join.biglobe.ne.jp/ftth/hikari/?cl=global_footer_hikari)
    
*   [auひかり](https://join.biglobe.ne.jp/ftth/one/?cl=global_footer_one)
    
*   [BIGLOBEモバイル](https://join.biglobe.ne.jp/mobile/?cl=global_footer_mobile)
    
*   [BIGLOBE WiMAX](https://join.biglobe.ne.jp/mobile/wimax/?cl=global_footer_wimax)
    

オプションサービス

*   [お助けサポート＋](https://otasuke.biglobe.ne.jp/otasuke_plus/)
    
*   [インターネット端末保証サービス](https://service.biglobe.ne.jp/internethosho/)
    
*   [トータル・ネットセキュリティ](https://security.biglobe.ne.jp/tns/)
    
*   [U-NEXT for BIGLOBE](https://vod.biglobe.ne.jp/unext/)
    
*   [その他オプション](https://service.biglobe.ne.jp/)
    

Webメディア

*   [温泉大賞](https://biz.biglobe.ne.jp/onsen/award/)
    
*   [しむぐらし](https://join.biglobe.ne.jp/mobile/sim/gurashi/)
    
*   [あしたメディア](https://ashita.biglobe.co.jp/)
    

法人のお客さま

*   [BIGLOBE biz.](https://biz.biglobe.ne.jp/index.html)
    
*   [BIGLOBE光](https://biz.biglobe.ne.jp/hikari/index.html)
    
*   [フレッツ光](https://biz.biglobe.ne.jp/flets/index.html)
    
*   [プロバイダサービス](https://biz.biglobe.ne.jp/member/office/provider.html)
    
*   [光回線用 固定IPアドレス](https://biz.biglobe.ne.jp/ip/index.html)
    
*   [BIGLOBEモバイル](https://biz.biglobe.ne.jp/sim/index.html)
    
*   [BIGLOBE WiMAX](https://biz.biglobe.ne.jp/wimax/index.html)
    
*   [IPトランジット](https://biz.biglobe.ne.jp/transit/index.html)
    
*   [マカフィー®マルチ アクセス](https://biz.biglobe.ne.jp/mma/index.html)
    
*   [法人向け独自ドメイン](https://biz.biglobe.ne.jp/domain/index.html)
    
*   [ONSENWORK](https://workation.biglobe.ne.jp/onsen/)
    

企業情報

*   [企業情報](https://www.biglobe.co.jp/outline)
    
*   [トップメッセージ](https://www.biglobe.co.jp/outline/message)
    
*   [ブランド](https://www.biglobe.co.jp/outline/brand)
    
*   [サステナビリティ](https://www.biglobe.co.jp/sustainability)
    
*   [ニュース](https://www.biglobe.co.jp/pressroom)
    
*   [採用情報](https://www.biglobe.co.jp/recruit)
    
*   [BIGLOBE Style](https://style.biglobe.co.jp/)
    
*   [ソーシャルメディア](https://www.biglobe.co.jp/social)
    

ご利用中の方

*   [マイページ](https://mypage.sso.biglobe.ne.jp/?cl=global_footer_mypage)
    
*   [メール](https://auth.sso.biglobe.ne.jp/mail/?cl=global_footer_mail)
    
*   [会員サポート](https://support.biglobe.ne.jp/?cl=global_footer_support)
    

*   [お問い合わせ](https://www.biglobe.co.jp/inquire)
    
*   [消費税の表示](https://support.biglobe.ne.jp/salestax.html)
    
*   [ウェブアクセシビリティの取り組み](https://support.biglobe.ne.jp/accessibility/)
    
*   [個人情報保護ポリシー](https://www.biglobe.ne.jp/privacy.html)
    
*   [プライバシーポータル](https://www.biglobe.ne.jp/privacy-portal.html)
    
*   [Cookieポリシー](https://www.biglobe.ne.jp/cookie.html)
    
*   [特定商取引法に基づく表記](https://support.biglobe.ne.jp/tokusyo.html)
    
*   [古物営業法に基づく表記](https://support.biglobe.ne.jp/kobutsusyo.html)
    
*   [情報セキュリティ基本方針](https://www.biglobe.co.jp/security)
    
*   [商標について](https://join.biglobe.ne.jp/trademark/)
    
*   [BIGLOBEトップ](https://www.biglobe.ne.jp/)
    

[![プライバシーマーク](https://top.bcdn.jp/images/PrivacyMark.png)](https://privacymark.jp/)

[![セキュリティ認証](https://top.bcdn.jp/images/ISP.png)](https://www.biglobe.ne.jp/safesecurity.html)

[![ETOCマーク](https://top.bcdn.jp/images/ETOC.png)](https://www.etoc.jp/elite/0037)

Copyright ©BIGLOBE Inc. 2025. All rights reserved.

[ページトップへ](https://join.biglobe.ne.jp/mobile/campaign/#)
