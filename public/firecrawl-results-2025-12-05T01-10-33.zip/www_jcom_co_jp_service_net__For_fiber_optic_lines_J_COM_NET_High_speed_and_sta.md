# For fiber optic lines J:COM NET | High-speed and stable internet line | J:COM

URL: https://www.jcom.co.jp/service/net/

---

[![Making the new a normal thing. J:COM](https://www.jcom.co.jp/common_v10/images/logo-jcom-white.svg)](https://www.jcom.co.jp/en/?sc_pid=common_jcomlogo_01)

*   [Why J:COM](https://www.jcom.co.jp/en/beginner/?sc_pid=globalnavi_beginner_01)
    
*   Current customers
*   [Online Shop](https://onlineshop.jcom.co.jp/?sc_pid=globalnavi_ols_01)
    

J:COM Customers

[Check/Update Contract  \
My page login](https://mypage.jcom.co.jp/?sc_pid=common_mypage_01)
 [Troubleshooting/FAQ  \
Customer Support](https://cs.myjcom.jp/?sc_pid=common_suppot_01)
 [Enjoy J:COM even more  \
TV program information/presents and benefits  \
Fun! J:COM](https://www.myjcom.jp/?sc_pid=common_myj_01)

    ![Search](https://www.jcom.co.jp/common_v10/images/snav-icn-search-submit.svg)

*   [To you  \
    notice](https://id.zaq.ne.jp/id/script/connect/authz_req/endpoint.seam?response_type=code&client_id=JCOM_COJP&redirect_uri=https%3A%2F%2Fwww.jcom.co.jp%2Fservice%2Fnet%2F&scope=http%3A%2F%2Fjcom.co.jp%2Fconnect%2Fprofile%2Fstandard_new&nonce=343268882&state=&prompt=)
    
*   [To you  \
    notice](https://www.jcom.co.jp/service/net/#)
    

Language

*   日本語
*   English
*   简体中文
*   한국어
*   Tiếng Việt
*   Português

*   Services
*   [Pricing](https://www.jcom.co.jp/en/price/)
    
*   [Promotions  \
    ​](https://www.jcom.co.jp/en/campaign/)
    
*   Sign Up /  
    Edit Account Info
*   Support
*   Company website

[Service Overview](https://www.jcom.co.jp/en/service/)

[TV,](https://www.jcom.co.jp/en/service/tv/)
 ​ ​[internet,](https://www.jcom.co.jp/en/service/net/)
 ​ ​[smartphone](https://www.jcom.co.jp/en/service/mobile/)
 [, electricity](https://www.jcom.co.jp/en/service/electricity/)
 ​ ​[Landline](https://www.jcom.co.jp/en/service/phone/)
 , [gas](https://www.jcom.co.jp/en/service/gas/)
 [,](https://www.jcom.co.jp/en/service/ssi/)
 insurance, [loan](https://www.jcom-financial.co.jp/)
 [, security camera,](https://www.jcom.co.jp/en/guide/starter/home_security/)
 ​ ​[Telemedicine](https://www.jcom.co.jp/en/service/telemedicine/)
 [, services for corporations and local governments![J:COM BUSINESS](https://www.jcom.co.jp/common_v10/images/logo_jcombusiness.webp)](https://business.jcom.co.jp/)

[Sign Up / Inquiries](https://www.jcom.co.jp/en/contactus/)

New customers

[New customers  \
Sign Up](https://onlineshop.jcom.co.jp/planSelect)

[New customers  \
Inquiries](https://www.jcom.co.jp/en/contactus/#entry)

J:COM Customers

[User  \
Various procedures](https://r.jcom.jp/eG4nLSC)

[Problems and inquiries  \
(chat)](https://prod8-live-chat.sprinklr.com/page?appId=67af27d73657336d345e4a96_app_9070639&did=CHAT_vivr_cojp_top&enableClose=true&skin=MODERN&userContext__c_679c8b53cb85b007fab0f6ea=DirectLink&utm_campaign=IVRSMS&utm_medium=referral&utm_source=did&webview=true&zoom=false)

Find the perfect plan for you

[Savings calculator](https://onlineshop.jcom.co.jp/Simulation/Simulation)

Some properties offer free or discounted options!

Covered areas & properties

[Company website](https://www.jcom.co.jp/en/corporate/)

[Corporate philosophy](https://www.jcom.co.jp/en/corporate/philosophy_brand/)

[Sustainability](https://www.jcom.co.jp/en/corporate/sustainability/)

[Medium-term management plan](https://www.jcom.co.jp/en/corporate/managementplan/)

[news release](https://newsreleases.jcom.co.jp/)

[Company Profile](https://www.jcom.co.jp/en/corporate/company/)

[Careers](https://recruit.jcom.co.jp/)

[Support Top](https://cs.myjcom.jp/)

[TV,](https://cs.myjcom.jp/categories/support/67ab976bf07f5244a208cb97)
 ​ ​[Internet,](https://cs.myjcom.jp/categories/support/67ab9788f07f5244a208cced)
 ​ ​[Smartphone](https://cs.myjcom.jp/categories/support/67ab979df07f5244a208cdc9)
 [, Electricity](https://cs.myjcom.jp/categories/support/67ab97b5f07f5244a208cec9)
 ​ ​[Landline](https://cs.myjcom.jp/categories/support/67ab97abf07f5244a208ce4e)
 [, Gas](https://cs.myjcom.jp/categories/support/67ab97b8f07f5244a208ceda)
 [, Insurance](https://cs.myjcom.jp/categories/support/67ab97c5f07f5244a208cf2f)
 ​ ​[Telemedicine](https://cs.myjcom.jp/categories/support/67ab97c2f07f5244a208cf1b)
 ​ ​[Home, IoT](https://cs.myjcom.jp/categories/support/67ab97bcf07f5244a208cee6)
 ​ ​[Security Camera](https://cs.myjcom.jp/categories/support/67ab97f5f07f5244a208d09b)

[J:COM STREAM](https://cs.myjcom.jp/categories/support/67ab97c9f07f5244a208cf49)

[Enkaku Support](https://cs.myjcom.jp/categories/support/67ab97faf07f5244a208d0c2)

[Home support](https://cs.myjcom.jp/categories/support/67ab97d4f07f5244a208cf92)

[Disaster prevention information service](https://cs.myjcom.jp/categories/support/67ab97d8f07f5244a208cfa0)

[Bicycle Life Support](https://cs.myjcom.jp/categories/support/67ab97e8f07f5244a208d023)

[J:COM Books](https://cs.myjcom.jp/categories/support/67ab97e4f07f5244a208d003)

[WiMAX](https://cs.myjcom.jp/categories/support/67ab97f1f07f5244a208d074)

[Trouble/maintenance information](https://information.myjcom.jp/maintenance_outage/)

Various procedures

[Personal ID](https://cs.myjcom.jp/categories/support/67ab9803f07f5244a208d113)

[Fees and Payment](https://cs.myjcom.jp/categories/support/67ab9805f07f5244a208d139)

[Moving and rebuilding](https://cs.myjcom.jp/categories/support/67ab980cf07f5244a208d184)

[Visits and counters](https://cs.myjcom.jp/categories/support/67ab980ff07f5244a208d1a4)

[Contract-related](https://cs.myjcom.jp/categories/support/67ab9806f07f5244a208d150)

[Suspension/cancellation](https://cs.myjcom.jp/categories/support/67ab980cf07f5244a208d188)

[Membership Benefits](https://cs.myjcom.jp/categories/support/67ab980df07f5244a208d18c)

[![The newest just makes sense: J:COM](https://www.jcom.co.jp/common_v10/images/logo-jcom-white.svg)](https://www.jcom.co.jp/en/?sc_pid=common_jcomlogo_01)

[![J:COM NET](https://www.jcom.co.jp/common_v10/images/logo-jcom-net-bk.svg)](https://www.jcom.co.jp/en/service/net/)

*   [Plans & Pricing](https://www.jcom.co.jp/en/service/net/course/)
    
*   Options
*   [Support](https://www.jcom.co.jp/en/service/net/support/)
    
*   [How to apply](https://www.jcom.co.jp/en/service/net/guide/)
    

[Options Overview](https://www.jcom.co.jp/en/service/net/option/)

*   [Messhu Wi-Fi](https://www.jcom.co.jp/en/service/net/option/mesh-wi-fi/)
    
*   [J:COM LINK mini](https://www.jcom.co.jp/en/service/net/option/linkmini/)
    

[![The newest just makes sense: J:COM](https://www.jcom.co.jp/common_v10/images/logo-jcom.svg)](https://www.jcom.co.jp/en/)

*   Services

*   [Sign Up](https://onlineshop.jcom.co.jp/planSelect)
    
*   [Inquiries](https://www.jcom.co.jp/en/contactus/)
    
*   [For beginners  \
    ​](https://www.jcom.co.jp/en/beginner/)
    
*   User​  
    ​
*   [Online  \
    Shop](https://onlineshop.jcom.co.jp/)
    
*   ![Search](https://www.jcom.co.jp/common_v10/images/fixed-nav-icn-search.svg)

    ![Search](https://www.jcom.co.jp/common_v10/images/snav-icn-search-submit.svg)

J:COM Customers

[Check/Update Contract  \
My page login](https://mypage.jcom.co.jp/)
 [Troubleshooting/FAQ  \
Customer Support](https://cs.myjcom.jp/)
 [Enjoy J:COM even more  \
TV program information/presents and benefits  \
Fun! J:COM](https://www.myjcom.jp/)

[Service Overview](https://www.jcom.co.jp/en/service/)

[TV,](https://www.jcom.co.jp/en/service/tv/)
 ​ ​[internet,](https://www.jcom.co.jp/en/service/net/)
 ​ ​[smartphone](https://www.jcom.co.jp/en/service/mobile/)
 [, electricity](https://www.jcom.co.jp/en/service/electricity/)
 ​ ​[Landline](https://www.jcom.co.jp/en/service/phone/)
 , [gas](https://www.jcom.co.jp/en/service/gas/)
 [,](https://www.jcom.co.jp/en/service/ssi/)
 insurance, [loan](https://www.jcom-financial.co.jp/)
 [, security camera,](https://www.jcom.co.jp/en/guide/starter/home_security/)
 ​ ​[Telemedicine](https://www.jcom.co.jp/en/service/telemedicine/)
 [, services for corporations and local governments![J:COM BUSINESS](https://www.jcom.co.jp/common_v10/images/logo_jcombusiness.webp)](https://business.jcom.co.jp/)

[![J:COM NET](https://www.jcom.co.jp/common_v10/images/logo-jcom-net-bk.svg)](https://www.jcom.co.jp/en/service/net/)

*   [Plans & Pricing](https://www.jcom.co.jp/en/service/net/course/)
    
*   Options
*   [Support](https://www.jcom.co.jp/en/service/net/support/)
    
*   [How to apply](https://www.jcom.co.jp/en/service/net/guide/)
    

[Options Overview](https://www.jcom.co.jp/en/service/net/option/)

*   [Messhu Wi-Fi](https://www.jcom.co.jp/en/service/net/option/mesh-wi-fi/)
    
*   [J:COM LINK mini](https://www.jcom.co.jp/en/service/net/option/linkmini/)
    

*   ![Menu](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/text-menu.svg)
*   ![J:COM NET Menu](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom-net/text-menu.svg)
*   [![Savings calculator](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom-net/text-sim.svg)](https://onlineshop.jcom.co.jp/Simulation/Simulation)
    
*   [![Sign Up](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom-net/text-entry.svg)](https://onlineshop.jcom.co.jp/planSelect)
    
*   [![FAQ Contact Us](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom-net/text-faq.svg)](https://cs.myjcom.jp/categorySearch?cg=ServiceOutside&c=net)
    

*   [![The newest just makes sense: J:COM](https://www.jcom.co.jp/common_v10/images/logo-jcom-only-white.svg)](https://www.jcom.co.jp/en/)
     ![Close menu](https://www.jcom.co.jp/common_v10/images/sp-menu/menu-close-white.svg)
    
    [J:COM Services](https://www.jcom.co.jp/en/service/)
    
    *   [![TV](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-tv-item.svg)](https://www.jcom.co.jp/en/service/tv/)
        
    *   [![Internet](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-net-item.svg)](https://www.jcom.co.jp/en/service/net/)
        
    *   [![Mobile](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-mobile-item.svg)](https://www.jcom.co.jp/en/service/mobile/)
        
    
    *   [![Electricity](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-electricity-item.svg)](https://www.jcom.co.jp/en/service/electricity/)
        
    *   [![Landline](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-phone-item.svg)](https://www.jcom.co.jp/en/service/phone/)
        
    *   [![Gas](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-gas-item.svg)](https://www.jcom.co.jp/en/service/gas/)
        
    *   [![insurance](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-ssi-item.svg)](https://www.jcom.co.jp/en/service/ssi/)
        
    *   [loan](https://www.jcom-financial.co.jp/)
        
    *   [![Home IoT Solutions](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-home-item.svg)](https://www.jcom.co.jp/en/service/home/)
        
    *   [security cameras](https://www.jcom.co.jp/en/guide/starter/home_security/)
        
    *   [![Telemedicine](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-telemedicine-item.svg)](https://www.jcom.co.jp/en/service/telemedicine/)
        
    
    [Services for corporations and local governments  \
    ![J:COM BUSINESS](https://www.jcom.co.jp/common_v10/images/logo_jcombusiness.webp)](https://business.jcom.co.jp/)
    
    Service overview
    
    [Price List](https://www.jcom.co.jp/en/price/)
     [Promotions/Benefits](https://www.jcom.co.jp/en/campaign/)
     [Support](https://cs.myjcom.jp/)
     [Application/Various Changes](https://www.jcom.co.jp/en/contactus/)
    
        ![Search](https://www.jcom.co.jp/common_v10/images/snav-icn-search-submit-sp.svg)
    
    [J:COM Top](https://www.jcom.co.jp/en/)
    
    *   [Service Information](https://www.jcom.co.jp/en/)
        
    *   [Online  \
        Shop](https://onlineshop.jcom.co.jp/)
        
    *   [Support](https://cs.myjcom.jp/)
        
    *   [Fun! J:COM](https://www.myjcom.jp/)
        
    *   [My page](https://mypage.jcom.co.jp/)
        
    *   [Company website](https://www.jcom.co.jp/en/corporate/)
        
    
*   [![J:COM NET](https://www.jcom.co.jp/common_v10/images/icn-jcom-net.svg)Internet](https://www.jcom.co.jp/en/service/net/)
     ![Close menu](https://www.jcom.co.jp/common_v10/images/sp-menu/menu-close-white.svg)
    
    [![](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom-net/slide/menu/mv-middle.webp)\
    \
    Faster and more comfortable\
    \
    Back to top](https://www.jcom.co.jp/en/service/net/)
    
    *   [Plans & Pricing](https://www.jcom.co.jp/en/service/net/course/)
        
    *   Options
        
        *   [Options Overview](https://www.jcom.co.jp/en/service/net/option/)
            
        *   [Messhu Wi-Fi](https://www.jcom.co.jp/en/service/net/option/mesh-wi-fi/)
            
        *   [J:COM LINK mini](https://www.jcom.co.jp/en/service/net/option/linkmini/)
            
        
    *   [Support](https://www.jcom.co.jp/en/service/net/support/)
        
    *   [How to apply](https://www.jcom.co.jp/en/service/net/guide/)
        
    

The new J:COM Hikari service, featuring the world's fastest Wi-Fi 7 standard, is here.
======================================================================================

 ![](https://www.jcom.co.jp/service/net/images_v10/wifi7/title_wifi7.webp)

[![](https://www.jcom.co.jp/service/net/images_v10/wifi7/img_cm_wifi7.webp)](https://www.jcom.co.jp/service/net/#)

[Close](https://www.jcom.co.jp/service/net/#)

Wi-Fi 7 "Thoughts are faster than light."  
Movie now available (37 seconds)

The theoretical maximum speed ratio of the Wi-Fi communication standard.  
Not available depending on course/area  
There may be cases.

[Five points](https://www.jcom.co.jp/service/net/#anc-recommend)

[Plans & Pricing](https://www.jcom.co.jp/service/net/#anc-price)

[Flow to start using](https://www.jcom.co.jp/service/net/#anc-step)

[Promotions/Benefits](https://www.jcom.co.jp/service/net/#anc-campaign)

New customers

[New Customers  \
Sign Up](https://onlineshop.jcom.co.jp/planSelect)

[![](https://www.jcom.co.jp/common_v10/images/icn-think-black.svg)New Customers  \
Contact us online](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

[New subscribers  \
0120-989-970](tel:0120-989-970)
 ​ ​9:00-18:00 \[Open all year round\]

Current customers

[Current Customers  \
Various procedures](https://r.jcom.jp/SEMrYrB)

[Problems/  \
inquiry  \
(chat)](https://prod8-live-chat.sprinklr.com/page?appId=67af27d73657336d345e4a96_app_9070639&did=CHAT_vivr_cojp_net&enableClose=true&skin=MODERN&userContext__c_679c8b53cb85b007fab0f6ea=DirectLink&utm_campaign=IVRSMS&utm_medium=referral&utm_source=did&webview=true&zoom=false)

Click here for Internet plans  
and prices

[Savings  \
 calculator](https://onlineshop.jcom.co.jp/Simulation/Simulation)

Some properties offer free or discounted options!

Covered  
areas & properties

[If you live in Oita, please click here](http://wwwjcom.oct-net.ne.jp/)

New customers

[Sign Up](https://onlineshop.jcom.co.jp/planSelect?sc_pid=common_upper_entry_02)

[![](https://www.jcom.co.jp/common_v10/images/icn-think-black.svg)Applications and Inquiries](https://www.jcom.co.jp/service/net/#)

[![](https://www.jcom.co.jp/common_v10/images/icn-think-black.svg)申请・咨询](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[电话咨询  \
050-1722-1733](tel:050-1722-1733)
 9:00-18:00【全年无休】／有翻译 [日本語での通話は  \
こちら](https://www.jcom.co.jp/service/net/#)

[![](https://www.jcom.co.jp/common_v10/images/icn-think-black.svg)신청·문의](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[신청·문의  \
050-1722-1733](tel:050-1722-1733)
 9:00-18:00【연중무휴】／통역 있음 [日本語での通話は  \
こちら](https://www.jcom.co.jp/service/net/#)

[![](https://www.jcom.co.jp/common_v10/images/icn-think-black.svg)Ứng dụng / Yêu cầu](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Ứng dụng / Yêu cầu  \
050-1722-1733](tel:050-1722-1733)
 9:00-18:00【mở cửa quanh năm】／có phiên dịch [日本語での通話は  \
こちら](https://www.jcom.co.jp/service/net/#)

[![](https://www.jcom.co.jp/common_v10/images/icn-think-black.svg)Solicitação/Consultas](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Solicitação/Consultas  \
050-1722-1733](tel:050-1722-1733)
 9:00-18:00【aberto todo o ano】／com intérprete [日本語での通話は  \
こちら](https://www.jcom.co.jp/service/net/#)

Current customers

[Check / Update  \
Your Contract  \
(JAPANESE ONLY)](https://www.jcom.co.jp/service/net/#)

[![](https://www.jcom.co.jp/common_v10/images/icn-member.svg)Inquiries](https://www.jcom.co.jp/service/net/#)

[![](https://www.jcom.co.jp/common_v10/images/icn-member.svg)联系我们](https://www.jcom.co.jp/service/net/#)

[![](https://www.jcom.co.jp/common_v10/images/icn-member.svg)문의](https://www.jcom.co.jp/service/net/#)

[![](https://www.jcom.co.jp/common_v10/images/icn-member.svg)Hỏi đáp](https://www.jcom.co.jp/service/net/#)

[![](https://www.jcom.co.jp/common_v10/images/icn-member.svg)Consultar](https://www.jcom.co.jp/service/net/#)

Find the perfect  
plan for you

[Savings  \
 calculator](https://onlineshop.jcom.co.jp/Simulation/Simulation?sc_pid=common_upper_simu_02)

Some properties offer free or discounted options!

Covered  
areas & properties

![Five points about J:COM Hikari!](https://www.jcom.co.jp/service/net/images_v10/wifi7/title_point.webp)
--------------------------------------------------------------------------------------------------------

World's fastest standard ★ Wi-Fi 7,  
Support your home communication environment at any time  
Living with the Internet  
Faster and more comfortable

★Theoretical maximum speed ratio of Wi-Fi communication standards.  
May not be available depending on the course and area.

![](https://www.jcom.co.jp/service/net/images_v10/wifi7/graph_point.webp)

*   ![Speed and stability](https://www.jcom.co.jp/service/net/images_v10/wifi7/graph_point_text01.svg)
*   ![uniqueness](https://www.jcom.co.jp/service/net/images_v10/wifi7/graph_point_text02.svg)
*   ![Great Value](https://www.jcom.co.jp/service/net/images_v10/wifi7/graph_point_text03.svg)
*   ![security](https://www.jcom.co.jp/service/net/images_v10/wifi7/graph_point_text04.svg)
*   ![Support](https://www.jcom.co.jp/service/net/images_v10/wifi7/graph_point_text05.svg)

[](https://www.jcom.co.jp/service/net/#)

![POINT 01](https://www.jcom.co.jp/service/net/images_v10/wifi7/text_modal_point_01.svg)

Watch videos with 10GB fiber optic and Wi-Fi 7  
Of course  
Data  
Upload too Crisp and comfortable

![](https://www.jcom.co.jp/service/net/images_v10/wifi7/img_point01_01.webp)

World's fastest standard ★ Wi-Fi 7  
J:COM Hikari now supports Wi-Fi 7!  
The wide bandwidth of the 6GHz band is available, providing high speed and stability.

![](https://www.jcom.co.jp/service/net/images_v10/wifi7/img_modal_6GHz.webp)

J:COM is the next generation AI Wi-Fi in  
More comfortable and stable  
Available.

AI learns optimal usage and automatically adjusts.  
Efficiently uses 6GHz.

[see more](https://www.jcom.co.jp/en/service/net/wifi7/)

[see more](https://www.jcom.co.jp/en/service/net/wifi7/)

![](https://www.jcom.co.jp/service/net/images_v10/wifi7/img_point01_wifi.webp)

Devices differs depending on the service.

Optional Messhu Wi-Fi  
Expanded Wi-Fi coverage area

Even if you move around inside the house  
AI automatically switches to the best Wi-Fi for the location

[see more](https://www.jcom.co.jp/en/service/net/option/mesh-wi-fi/)

[see more](https://www.jcom.co.jp/en/service/net/option/mesh-wi-fi/)

Theoretical maximum speed ratio of Wi-Fi communication standards (see "Comparison of Wi-Fi Certified Standards" below). May not be available depending on the course or area. A compatible device is required to use Wi-Fi 7 features.

\[Comparison of Wi-Fi certified standards\]

 ![](https://www.jcom.co.jp/service/net/images_v10/wifi7/table_point01_wifi.webp)

[Source: Ministry of Internal Affairs and Communications, December 2023, "Introduction of IEEE 802.11be (Wi-Fi 7)"](https://www.soumu.go.jp/main_content/000918948.pdf)

[](https://www.jcom.co.jp/service/net/#)

![POINT 02](https://www.jcom.co.jp/service/net/images_v10/wifi7/text_modal_point_02.svg)

The world's fastest standard, Wi-Fi 7​  
J:COM uses AI for optimization  
The more you use it, the more comfortable it becomes

![](https://www.jcom.co.jp/service/net/images_v10/wifi7/dec_point02_ai.webp)

Depending on the communication situation  
Automatic frequency band switching.  
Furthermore, AI analyzes past usage and  
For a more comfortable Wi-Fi environment.

Efficiently uses high-speed frequency band (6GHz).  
AI automatically adjusts to the optimal Wi-Fi zone.

![](https://www.jcom.co.jp/service/net/images_v10/wifi7/img_modal_6GHz.webp)

The AI learns based on usage.  
The more you use it, the less likely it is to experience delays.  
Enjoy a comfortable Wi-Fi environment.

![](https://www.jcom.co.jp/service/net/images_v10/wifi7/img_point02_ai.webp)

Theoretical maximum speed ratio of Wi-Fi communication standards. May not be available depending on the course or area. A compatible device is required to use Wi-Fi 7 features.

[see more](https://www.jcom.co.jp/en/service/net/wifi7/)

[](https://www.jcom.co.jp/service/net/#)

![POINT 03](https://www.jcom.co.jp/service/net/images_v10/wifi7/text_modal_point_03.svg)

10Giga optical fiber and Wi-Fi 7 compatible  
Next generation AI Wi-Fi

6 months

effective monthly

![0](https://www.jcom.co.jp/service/net/images_v10/wifi7/img_price_0.svg)

circle ※

For detached houses. WEB Gentei Start Wari and cashback of 20,000 yen is converted into a monthly amount, starting from 6,160 yen (tax included) per month from the 7th month. Not available in some areas. 2-year contract, automatically renewed. Cancellation during the contract period will incur a cancellation fee.

![](https://www.jcom.co.jp/service/net/images_v10/wifi7/dec_modal_plus.svg)

What's more, the basic construction cost is essentially 0 yen!

[see more](https://www.jcom.co.jp/en/guide/starter/shinlife/price/?ad=sdu01#anc-net-charm)

[](https://www.jcom.co.jp/service/net/#)

![POINT 04](https://www.jcom.co.jp/service/net/images_v10/wifi7/text_modal_point_04.svg)

To ensure you can enjoy the service safely and securely  
Internet security too free

![](https://www.jcom.co.jp/service/net/images_v10/wifi7/img_point04_01.webp)

to the network  
Prevent intrusion

Of course, PCs and smartphones  
In traditional security  
Unable to protect  
Smart TVs and  
Safe for devices such as game consoles

![](https://www.jcom.co.jp/service/net/images_v10/wifi7/img_point04_02.webp)

Security software too  
No additional costs

Protecting your computer  
Comprehensive security software  
"McAfee for ZAQ"  
Provided at no additional cost.

[see more](https://www.jcom.co.jp/en/service/net/security.html)

[](https://www.jcom.co.jp/service/net/#)

![POINT 05](https://www.jcom.co.jp/service/net/images_v10/wifi7/text_modal_point_05.svg)

Manage your home's communication environment with the app  
anytime support

![](https://www.jcom.co.jp/service/net/images_v10/wifi7/dec_point05_01.webp)

Easy operation  
Diagnosis can be made 24 hours a day,  
Safe even at night.

![](https://www.jcom.co.jp/service/net/images_v10/wifi7/img_point05_01.webp)

Notification function provides information on faults and maintenance,  
Get instant notification of any network problems.  
The app will automatically notify you,  
There is no need to search for the cause of the problem yourself.

Diagnosis is limited to J:COM services. It is not available for "J:COM NET Hikari on au Hikari"/" J:COM NET Hikari (N)". For details, please contact J:COM.

[see more](https://www.jcom.co.jp/en/service/net/support/)

Previous

### security

Viruses and unauthorized access  
Prevent and respond to threats  
Full security is free.

[Learn more](https://www.jcom.co.jp/service/net/#)

### Support

Manage your home's communication environment with the app  
Diagnostics and support available at any time

*   Diagnosis is limited to J:COM services.  
    "J:COM NET Hikari on au Hikari"/  
    Not available with "J:COM NET Hikari (N)".  
    For more information, please contact J:COM.

[Learn more](https://www.jcom.co.jp/service/net/#)

### Speed and stability

10Giga Optical Fiber and the world's fastest standard \*1  
With Wi-Fi 7,  
The whole house is smooth and comfortable.  
For a stable communication environment.

*   Source: Ministry of Internal Affairs and Communications IEEE 802.11be (Wi-Fi 7)  
    of  
    Regarding implementation: "Comparison of Wi-Fi certified standards"

[Learn more](https://www.jcom.co.jp/service/net/#)

### uniqueness

The world's fastest Wi-Fi 7 standard  
J:COM uses AI to optimize.  
The more you use it, the more comfortable it becomes!

[Learn more](https://www.jcom.co.jp/service/net/#)

### Great Value

10GB fiber optic cable for 6 months at 0 yen per month  
Next-generation AI Wi-Fi compatible with Wi-Fi 7  
Available at no additional cost!

[Learn more](https://www.jcom.co.jp/service/net/#)

### security

Viruses and unauthorized access  
Prevent and respond to threats  
Full security is free.

[Learn more](https://www.jcom.co.jp/service/net/#)

### Support

Manage your home's communication environment with the app  
Diagnostics and support available at any time

*   Diagnosis is limited to J:COM services.  
    "J:COM NET Hikari on au Hikari"/  
    Not available with "J:COM NET Hikari (N)".  
    For more information, please contact J:COM.

[Learn more](https://www.jcom.co.jp/service/net/#)

### Speed and stability

10Giga Optical Fiber and the world's fastest standard \*1  
With Wi-Fi 7,  
The whole house is smooth and comfortable.  
For a stable communication environment.

*   Source: Ministry of Internal Affairs and Communications IEEE 802.11be (Wi-Fi 7)  
    of  
    Regarding implementation: "Comparison of Wi-Fi certified standards"

[Learn more](https://www.jcom.co.jp/service/net/#)

### uniqueness

The world's fastest Wi-Fi 7 standard  
J:COM uses AI to optimize.  
The more you use it, the more comfortable it becomes!

[Learn more](https://www.jcom.co.jp/service/net/#)

### Great Value

10GB fiber optic cable for 6 months at 0 yen per month  
Next-generation AI Wi-Fi compatible with Wi-Fi 7  
Available at no additional cost!

[Learn more](https://www.jcom.co.jp/service/net/#)

### security

Viruses and unauthorized access  
Prevent and respond to threats  
Full security is free.

[Learn more](https://www.jcom.co.jp/service/net/#)

### Support

Manage your home's communication environment with the app  
Diagnostics and support available at any time

*   Diagnosis is limited to J:COM services.  
    "J:COM NET Hikari on au Hikari"/  
    Not available with "J:COM NET Hikari (N)".  
    For more information, please contact J:COM.

[Learn more](https://www.jcom.co.jp/service/net/#)

Next

pause ​ ​play

*   1
*   2
*   3
*   4
*   5

Fiber optic and Wi-Fi!  
Why choose J:COM Hikari?
-------------------------------------------------

[![J:COM Hikari 10 Gigabit](https://www.jcom.co.jp/service/net/images_v10/wifi7/img_reason_hikari.png)\
\
effective monthly\
\
6 months\
\
![0](https://www.jcom.co.jp/service/net/images_v10/wifi7/img_price_0.svg) yen\
\
See details](https://www.jcom.co.jp/en/guide/starter/shinlife/price/?ad=sdu01)

[![](https://www.jcom.co.jp/service/net/images_v10/wifi7/img_reason_hikari_pc.webp)\
\
![J:COM Hikari 10 Gigabit](https://www.jcom.co.jp/service/net/images_v10/wifi7/logo_hikari10.webp)\
\
effective monthly\
\
6 months\
\
![0](https://www.jcom.co.jp/service/net/images_v10/wifi7/img_price_0.svg) yen\
\
See details](https://www.jcom.co.jp/en/guide/starter/shinlife/price/?ad=sdu01)

 [![](https://www.jcom.co.jp/service/net/images_v10/wifi7/img_reason_01.webp)\
\
World's fastest standard ★  \
Wi-Fi 7 compatible\
\
Next-generation AI Wi-Fi​  \
The more you use it, the more comfortable it becomes\
\
See details](https://www.jcom.co.jp/en/service/net/wifi7/)
 [![](https://www.jcom.co.jp/service/net/images_v10/wifi7/img_reason_02.webp)\
\
Reassuring  \
Communication environment support\
\
See details](https://www.jcom.co.jp/en/service/net/support/)

Theoretical maximum speed ratio of Wi-Fi communication standards. May not be available depending on the course or area.

Topics
------

[![J:COM Hikari 10 Gigabit - 0 yen per month for 6 months (For detached homes). From the 7th month onwards, the price starts from 6,710 yen/month. For more information, click here.](https://www.jcom.co.jp/images_v10/topics_newlife_sp_v3.webp)](https://www.jcom.co.jp/en/guide/starter/shinlife/price/?ad=sdu01)

[![NETFLIX - Happiness you can immerse yourself in. New J:COM Netflix Set now available - 330 yen/month discount](https://www.jcom.co.jp/images_v10/topics_netflix_sp.webp)](https://www.jcom.co.jp/en/guide/starter/netflix/)

[![Disney Plus is free for up to 3 months at J:COM](https://www.jcom.co.jp/service/net/images_v10/topics_dplus_sp_v2.webp)](https://www.jcom.co.jp/en/service/disneyplus/lp/)

[![J:COM Hikari 10 Gigabit - 0 yen per month for 6 months (For detached homes). From the 7th month onwards, the price starts from 6,710 yen/month. For more information, click here.](https://www.jcom.co.jp/images_v10/topics_newlife_sp_v3.webp)](https://www.jcom.co.jp/en/guide/starter/shinlife/price/?ad=sdu01)

[![NETFLIX - Happiness you can immerse yourself in. New J:COM Netflix Set now available - 330 yen/month discount](https://www.jcom.co.jp/images_v10/topics_netflix_sp.webp)](https://www.jcom.co.jp/en/guide/starter/netflix/)

[![Disney Plus is free for up to 3 months at J:COM](https://www.jcom.co.jp/service/net/images_v10/topics_dplus_sp_v2.webp)](https://www.jcom.co.jp/en/service/disneyplus/lp/)

Fiber optic line/Internet  
Monthly fees and course information
---------------------------------------------------------------

A course that lets you enjoy using the internet at great value  
Information.

*   For those living in detached houses
*   For those living in apartment complexes

High-capacity, ultra-high-speed internet of  
For those who want to get started at a great price!

![light 10 giga](https://www.jcom.co.jp/service/net/images_v10/wifi7/text_price_hikari10.webp)

![](https://www.jcom.co.jp/service/net/images_v10/wifi7/dec_plus_bk.svg)

Standard equipment

![Wi-Fi 7](https://www.jcom.co.jp/service/net/images_v10/wifi7/text_price_wifi7.webp)

[Learn more](https://www.jcom.co.jp/en/service/net/wifi7/)

Effectively 0​ ​yen per month for 6 months \*1 (tax included)  
(After discount ends: 6,160 yen including tax)

[View prices in detail](https://www.jcom.co.jp/en/guide/starter/shinlife/price/?ad=sdu01)

*   WEB Gentei Start Wari and cashback of 20,000 yen per month. 2-year contract, automatically renewed. Cancellation midway requires a cancellation fee.

The basic installation fee is essentially free. For details, click [here](https://www.jcom.co.jp/en/campaign/kojihi/)
. A separate contract administration fee is required.

[See the list of fees and courses](https://www.jcom.co.jp/en/service/net/course/)

Click here for more detailed prices

[![icon](https://www.jcom.co.jp/common_v10/images/icn-simulation.svg)Savings calculator](https://onlineshop.jcom.co.jp/Simulation/Simulation)

High-speed internet with Wi-Fi of  
For those who want to get started at a great price!

![light 1 giga](https://www.jcom.co.jp/service/net/images_v10/wifi7/text_price_hikari1.webp)

![](https://www.jcom.co.jp/service/net/images_v10/wifi7/dec_plus_bk.svg)

![Wi-Fi](https://www.jcom.co.jp/service/net/images_v10/wifi7/text_price_wifi.webp.webp)

[Learn more](https://www.jcom.co.jp/en/service/net/wifi-advanced/function.html)

​0​ ​yen per month for 3 months \*1 (tax included)  
(After discount ends: 5,258 yen including tax)

Plus 10,000 yen cash back

*   The displayed service does not support "Wi-Fi 7." If you would like to use "Wi-Fi 7," [please contact us here.](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)
    
*   Wi-Fi 7 support varies by property, and is being gradually expanded.

[View prices in detail](https://www.jcom.co.jp/en/guide/starter/shinlife/price/)

10G + Wi-Fi  
3 months: 1,628 yen (tax included)​ ​\*1  
(After discount ends: 6,886 yen including tax)  
Plus 10,000 yen cash back   
[Learn more](https://www.jcom.co.jp/en/guide/starter/shinlife/price/)

*   WEB Gentei Start Wari applies. 2-year contract, automatically renewed. Cancellation during the contract period will incur a cancellation fee.

The basic installation fee is essentially free. For details, click [here](https://www.jcom.co.jp/en/campaign/kojihi/)
. A separate contract administration fee is required.

[See the list of fees and courses](https://www.jcom.co.jp/en/service/net/course/)

Click here for more detailed prices

[![icon](https://www.jcom.co.jp/common_v10/images/icn-simulation.svg)Savings calculator](https://onlineshop.jcom.co.jp/Simulation/Simulation)

### J:COM In My Room Exclusive! Special Plan

[![J:COM In My Room](https://www.jcom.co.jp/service/net/images_v10/index/icoLogo-01.png)\
\
\[Internet and TV are free  \
Or special rates】\
\
J:COM In My Room is a property  \
with low rates for tenants.\
\
Check the property and prices here](https://onlineshop.jcom.co.jp/Simulation/Simulation)\
\
[What is J:COM In My Room?](https://www.jcom.co.jp/en/service/guide/mdu/inmyroom.html)\
\
[New Customers  \
Sign Up](https://onlineshop.jcom.co.jp/planSelect)\
\
[Current Customers  \
Various procedures](https://r.jcom.jp/SEMrYrB)\
\
Click here for Internet plans  \
and prices\
\
[Savings  \
 calculator](https://onlineshop.jcom.co.jp/Simulation/Simulation)\
\
Some properties offer free or discounted options!\
\
Covered  \
areas & properties\
\
Options/Peripherals\
-------------------\
\
[![](https://www.jcom.co.jp/service/net/images_v10/wifi7/img_option_wifi.webp)\
\
Mesh Wi-Fi\
\
Expanded Wi-Fi coverage area\
\
See details](https://www.jcom.co.jp/en/service/net/option/mesh-wi-fi/)\
[![](https://www.jcom.co.jp/service/net/images_v10/wifi7/img_option_linkmini.webp)\
\
J:COM LINK mini\
\
Enjoy online videos on the big screen\
\
See details](https://www.jcom.co.jp/en/service/net/option/linkmini/)\
\
[Extras/Peripheral equipment](https://www.jcom.co.jp/en/service/net/option/)\
\
Fiber optic line/Internet  \
How to apply and how to start using the service\
---------------------------------------------------------------------------\
\
### Easy in 3 steps  \
Start using in as little as 4 days​ ​\*\
\
[Peace of mind until the opening!](javascript:void(0);)\
\
[](javascript:void(0);)\
\
Peace of mind until the opening!\
\
### Even before the opening of the light  \
You can use the internet!\
\
Not limited to J:COM, it often takes about a month to open an optical line from the time of application. In the case of J:COM, you can also use the internet via cable line until the fiber optic service opens \*. If you wish, please let the staff know during "Step 2. Adjustment of construction date, etc."\
\
If you apply for J:COM NET Hikari (N), we will lend WiMAX free of charge for up to 3 months to customers who are waiting for the service to open.\
\
[Close](javascript:void(0);)\
\
![STEP 1](https://www.jcom.co.jp/service/net/images_v10/wifi7/text_step_1.webp)\
\
![](https://www.jcom.co.jp/service/net/images_v10/wifi7/img_step_app.webp)\
\
Sign Up\
\
![STEP 2](https://www.jcom.co.jp/service/net/images_v10/wifi7/text_step_2.webp)\
\
![](https://www.jcom.co.jp/service/net/images_v10/wifi7/img_step_schedule.webp)\
\
Adjustment of construction date and time\
\
![STEP 3](https://www.jcom.co.jp/service/net/images_v10/wifi7/text_step_3.webp)\
\
![](https://www.jcom.co.jp/service/net/images_v10/wifi7/img_step_setting.webp)\
\
construction, equipment  \
Installation/setting\
\
![](https://www.jcom.co.jp/service/net/images_v10/wifi7/img_step_app.webp)\
\
![STEP 1](https://www.jcom.co.jp/service/net/images_v10/wifi7/text_step_1.webp)\
\
Sign Up\
\
![](https://www.jcom.co.jp/service/net/images_v10/wifi7/img_step_schedule.webp)\
\
![STEP 2](https://www.jcom.co.jp/service/net/images_v10/wifi7/text_step_2.webp)\
\
Adjustment of construction date and time\
\
![](https://www.jcom.co.jp/service/net/images_v10/wifi7/img_step_setting.webp)\
\
![STEP 3](https://www.jcom.co.jp/service/net/images_v10/wifi7/text_step_3.webp)\
\
Construction, equipment installation and setup\
\
Depending on the contract details and congestion situation,  \
It may not be possible to accommodate your desired schedule.\
\
[Application flow](https://www.jcom.co.jp/en/service/net/guide/)\
\
Campaigns/benefits\
------------------\
\
*   [![WEB Gentei Start Wari](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_start.webp)](https://www.jcom.co.jp/en/campaign/start_jcom/)\
    \
*   [![Seishun 22 Wari, Seishun 26 Wari](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_u26.webp)](https://www.jcom.co.jp/en/campaign/u26/)\
    \
*   [![au Smart Value](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_newreduce.webp)](https://www.jcom.co.jp/en/price/au/)\
    \
*   [![J:COM金利優遇割](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_au_loan.webp)](https://www.jcom.co.jp/en/price/au_loan/)\
    \
*   [![WEB Gentei Start Wari](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_start.webp)](https://www.jcom.co.jp/en/campaign/start_jcom/)\
    \
*   [![Seishun 22 Wari, Seishun 26 Wari](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_u26.webp)](https://www.jcom.co.jp/en/campaign/u26/)\
    \
*   [![au Smart Value](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_newreduce.webp)](https://www.jcom.co.jp/en/price/au/)\
    \
*   [![J:COM金利優遇割](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_au_loan.webp)](https://www.jcom.co.jp/en/price/au_loan/)\
    \
*   [![WEB Gentei Start Wari](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_start.webp)](https://www.jcom.co.jp/en/campaign/start_jcom/)\
    \
*   [![Seishun 22 Wari, Seishun 26 Wari](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_u26.webp)](https://www.jcom.co.jp/en/campaign/u26/)\
    \
*   [![au Smart Value](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_newreduce.webp)](https://www.jcom.co.jp/en/price/au/)\
    \
*   [![J:COM金利優遇割](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_au_loan.webp)](https://www.jcom.co.jp/en/price/au_loan/)\
    \
\
[Promotions/Benefits](https://www.jcom.co.jp/en/campaign/)\
\
Recommended as a set/  \
Popular services\
----------------------------------------\
\
 [![](https://www.jcom.co.jp/images_v10/img-service-tv.jpg)\
\
![](https://www.jcom.co.jp/common_v10/images/icn-jcom-tv.svg) tv set\
\
Specialty channels  \
Make your "want to see" come true.](https://www.jcom.co.jp/en/service/tv/?sc_pid=common_service_tv)\
 [![](https://www.jcom.co.jp/images_v10/img-service-electricity.jpg)\
\
![](https://www.jcom.co.jp/common_v10/images/icn-jcom-electricity.svg) electricity\
\
Convenient, all in one place](https://www.jcom.co.jp/en/service/electricity/?sc_pid=common_service_ele)\
[![](https://www.jcom.co.jp/service/tv/images_v10/common/service-img-security.jpg)\
\
Security cameras\
\
Affordable price,  \
Peace of mind with security](https://www.jcom.co.jp/en/service/home/security/?sc_pid=common_service_home)\
\
Customer feedback\
-----------------\
\
Fiber optic and other internet  \
Introducing reviews\
\
*   ### student friendly  \
    internet\
    \
    I'm still a student and there are a lot of students around me, but if I have friends who are worried about the high internet costs, I immediately recommend J:COM. It's really helpful that the student discount continues for four years.\
    \
    20s/female\
    \
*   ### Because I have support  \
    Can be used with confidence\
    \
    Occasionally, I will call Enkaku Support for help when I have trouble operating my computer or when it stops working. I would like to thank you very much for your kind and accurate response to the problem, even if it was simple.\
    \
    70s/Male\
    \
*   ### For a comfortable internet environment  \
    satisfaction\
    \
    I changed my internet speed to 1G course last year. The line is fast and stable, and I am very satisfied. I'm glad I made the change.\
    \
    30s/Male\
    \
*   ### Security software  \
    I'm glad it's free to use\
    \
    We recommend that the McAfee usage fee is included in the internet service. It cannot be replaced by any other provider.\
    \
    30s/Male\
    \
*   ### Remote support even when you are in trouble  \
    solved on the spot\
    \
    I am subscribed to Enkaku Support. When I have something I don't understand about a computer, I immediately contact them, and they are able to provide detailed instructions via remote control, which is very helpful.\
    \
    60s/female\
    \
*   ### J:COM対応マンションで  \
    Great Value\
    \
    The apartment I live in is compatible with J:COM, so I can use TV, internet, and smartphones at a great price. The line speed is also stable.\
    \
    50s/Male\
    \
\
  [![Customer feedback now available](https://data.wovn.io/ImageValue/production/63c0b739b1e80445d40ae954/en/01094b5de3f4c7162a2d3910eac39040/voice_en_650%EF%BE%97150.png)](https://www.jcom.co.jp/en/service/voice/)\
\
If you are considering signing up or adding services\
\
### Sign Up information\
\
New customers\
\
[New Customers  \
Sign Up](https://onlineshop.jcom.co.jp/planSelect)\
\
[For new subscribers  \
inquiry](https://www.jcom.co.jp/service/net/#)\
\
Current customers\
\
[Current Customers  \
Various procedures](https://r.jcom.jp/SEMrYrB)\
\
[Problems/  \
inquiry  \
(chat)](https://prod8-live-chat.sprinklr.com/page?appId=67af27d73657336d345e4a96_app_9070639&did=CHAT_vivr_cojp_net&enableClose=true&skin=MODERN&userContext__c_679c8b53cb85b007fab0f6ea=DirectLink&utm_campaign=IVRSMS&utm_medium=referral&utm_source=did&webview=true&zoom=false)\
\
Click here for Internet plans  \
and prices\
\
[Savings  \
 calculator](https://onlineshop.jcom.co.jp/Simulation/Simulation)\
\
Some properties offer free or discounted options!\
\
Covered  \
areas & properties\
\
If you are considering signing up or adding services\
\
### Sign Up information\
\
New customers\
\
[Sign Up](https://onlineshop.jcom.co.jp/planSelect?sc_pid=common_bottom_entry_02)\
\
[![](https://www.jcom.co.jp/common_v10/images/icn-think-black.svg)Applications and Inquiries](https://www.jcom.co.jp/service/net/#)\
\
[![](https://www.jcom.co.jp/common_v10/images/icn-think-black.svg)申请・咨询](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)\
\
[电话咨询  \
050-1722-1733](tel:050-1722-1733)\
 9:00-18:00【全年无休】／有翻译 [日本語での通話は  \
こちら](https://www.jcom.co.jp/service/net/#)\
\
[![](https://www.jcom.co.jp/common_v10/images/icn-think-black.svg)신청·문의](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)\
\
[신청·문의  \
050-1722-1733](tel:050-1722-1733)\
 9:00-18:00【연중무휴】／통역 있음 [日本語での通話は  \
こちら](https://www.jcom.co.jp/service/net/#)\
\
[![](https://www.jcom.co.jp/common_v10/images/icn-think-black.svg)Ứng dụng / Yêu cầu](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)\
\
[Ứng dụng / Yêu cầu  \
050-1722-1733](tel:050-1722-1733)\
 9:00-18:00【mở cửa quanh năm】／có phiên dịch [日本語での通話は  \
こちら](https://www.jcom.co.jp/service/net/#)\
\
[![](https://www.jcom.co.jp/common_v10/images/icn-think-black.svg)Solicitação/Consultas](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)\
\
[Solicitação/Consultas  \
050-1722-1733](tel:050-1722-1733)\
 9:00-18:00【aberto todo o ano】／com intérprete [日本語での通話は  \
こちら](https://www.jcom.co.jp/service/net/#)\
\
Current customers\
\
[Check / Update  \
Your Contract  \
(JAPANESE ONLY)](https://www.jcom.co.jp/service/net/#)\
\
[![](https://www.jcom.co.jp/common_v10/images/icn-member.svg)Inquiries](https://www.jcom.co.jp/service/net/#)\
\
[![](https://www.jcom.co.jp/common_v10/images/icn-member.svg)联系我们](https://www.jcom.co.jp/service/net/#)\
\
[![](https://www.jcom.co.jp/common_v10/images/icn-member.svg)문의](https://www.jcom.co.jp/service/net/#)\
\
[![](https://www.jcom.co.jp/common_v10/images/icn-member.svg)Hỏi đáp](https://www.jcom.co.jp/service/net/#)\
\
[![](https://www.jcom.co.jp/common_v10/images/icn-member.svg)Consultar](https://www.jcom.co.jp/service/net/#)\
\
Find the perfect  \
plan for you\
\
[Savings  \
 calculator](https://onlineshop.jcom.co.jp/Simulation/Simulation?sc_pid=common_bottom_simu_02)\
\
Some properties offer free or discounted options!\
\
Covered  \
areas & properties\
\
FAQ\
---\
\
Can you do the initial settings for connecting to the internet?\
\
Up until the end of the month following the completion of J:COM NET installation work, you can have one PC's initial settings (connection settings, e-mail settings, and security settings) performed free of charge.\
\
Can I use my current email address?\
\
If you have a free email such as Gmail, you can use it with no problems. There are services from each company that allow you to continue using the email address of your current provider even after canceling your contract. Please contact your current provider for details.\
\
Do Seishun 22 Wari and Seishun 26 Wari discounts apply if the user is of the target age?\
\
The age of the contract holder, not the user, must be the eligible age. For example, if you are already using J:COM and would like to apply for Seishun 22 Wari discount, your contract holder must be 22 years old or younger.\
\
Do I need to sign a contract with a provider?\
\
J:COM NET comes with a line and provider as a set, so there is no need to sign a separate contract with a provider.\
\
[](https://www.jcom.co.jp/service/net/#)\
\
New Customers  \
Inquiries\
\
[Contact us online](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)\
\
J:COM will respond to you by email or phone.\
\
Click here to contact us by phone (toll free)\
\
[0120-989-970](tel:0120-989-970)\
\
9:00-18:00 \[Open all year round\]\
\
[Close](https://www.jcom.co.jp/service/net/#)\
\
[](https://www.jcom.co.jp/service/net/#)\
\
New Customers  \
Inquiries\
\
[Contact us online](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)\
\
J:COM will respond to you by email or phone.\
\
Click here to contact us by phone (toll free)\
\
[0120-989-970](tel:0120-989-970)\
\
9:00-18:00 \[Open all year round\]\
\
[Close](https://www.jcom.co.jp/service/net/#)\
\
[](https://www.jcom.co.jp/service/net/#)\
\
New Customers  \
Inquiries\
\
[Contact us online](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)\
\
J:COM will respond to you by email or phone.\
\
Click here to contact us by phone (toll free)\
\
[0120-989-970](tel:0120-989-970)\
\
9:00-18:00 \[Open all year round\]\
\
[Close](https://www.jcom.co.jp/service/net/#)\
\
[](https://www.jcom.co.jp/service/net/#)\
\
Current Customers  \
Inquiries\
\
Check / Update  \
your contract here\
\
[My page login](https://mypage.jcom.co.jp/)\
\
* * *\
\
Click here for  \
Troubleshooting/FAQ\
\
[Customer Support](https://cs.myjcom.jp/)\
\
* * *\
\
Click here to  \
add or change service options\
\
[Edit / Add to Your Plan](https://www2.myjcom.jp/join/)\
\
[Close](https://www.jcom.co.jp/service/net/#)\
\
[](https://www.jcom.co.jp/service/net/#)\
\
Current Customers  \
Inquiries\
\
Check / Update  \
your contract here\
\
[My page login](https://mypage.jcom.co.jp/)\
\
* * *\
\
Click here for  \
Troubleshooting/FAQ\
\
[Customer Support](https://cs.myjcom.jp/)\
\
* * *\
\
Click here to  \
add or change service options\
\
[Edit / Add to Your Plan](https://www2.myjcom.jp/join/)\
\
[Close](https://www.jcom.co.jp/service/net/#)\
\
[](https://www.jcom.co.jp/service/net/#)\
\
Current Customers  \
Inquiries\
\
Check / Update  \
your contract here\
\
[My page login](https://mypage.jcom.co.jp/)\
\
* * *\
\
Click here for  \
Troubleshooting/FAQ\
\
[Customer Support](https://cs.myjcom.jp/)\
\
* * *\
\
Click here to  \
add or change service options\
\
[Edit / Add to Your Plan](https://www2.myjcom.jp/join/)\
\
[Close](https://www.jcom.co.jp/service/net/#)\
\
[](https://www.jcom.co.jp/service/net/#)\
\
User  \
Application\
\
For those who do not use J:COM TV\
\
[J:COM TV  \
Shin Standard Plus  \
Application](https://r.jcom.jp/24KC2mS)\
\
User J:COM TV\
\
[J:COM TV  \
To Shin Standard Plus  \
Change of course](https://r.jcom.jp/0JLPOoy)\
\
[Close](https://www.jcom.co.jp/service/net/#)\
\
[](https://www.jcom.co.jp/service/net/#)\
\
User  \
Application\
\
For those who do not use J:COM TV\
\
[J:COM TV  \
Shin Standard Plus  \
Application](https://r.jcom.jp/24KC2mS)\
\
User J:COM TV\
\
[J:COM TV  \
To Shin Standard Plus  \
Change of course](https://r.jcom.jp/0JLPOoy)\
\
[Close](https://www.jcom.co.jp/service/net/#)\
\
[](https://www.jcom.co.jp/service/net/#)\
\
User  \
Application\
\
For those who do not use J:COM TV\
\
[J:COM TV  \
Shin Standard Plus  \
Application](https://r.jcom.jp/24KC2mS)\
\
User J:COM TV\
\
[J:COM TV  \
To Shin Standard Plus  \
Change of course](https://r.jcom.jp/0JLPOoy)\
\
[Close](https://www.jcom.co.jp/service/net/#)\
\
[](https://www.jcom.co.jp/service/net/#)\
\
Confirming or changing the construction date\
\
You can check, change, or cancel the schedule for on-site construction work on your My Page.\
\
[My page login](https://mypage.jcom.co.jp/)\
\
[Click here for instructions on how to check your My Page](https://cs.myjcom.jp/articles/support/6790bf45ad2e841b2e3362cf)\
\
The installation date for J:COM NET Hikari (N) cannot be changed on My Page. Please contact [the customer center](https://www.jcom.co.jp/contactus/call_rgu.html#phone)\
.\
\
[Close](https://www.jcom.co.jp/service/net/#)\
\
[](https://www.jcom.co.jp/service/net/#)\
\
New Customers　  \
Applications and Inquiries\
\
[Applications and Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)\
\
[0120-989-970](tel:0120-989-970)\
\
Business hours: 9:00-18:00  \
\[Open all year round\]\
\
[Close](https://www.jcom.co.jp/service/net/#)\
\
[](https://www.jcom.co.jp/service/net/#)\
\
New Customers　  \
Applications and Inquiries\
\
[Applications and Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)\
\
[0120-989-970](tel:0120-989-970)\
\
Business hours: 9:00-18:00  \
\[Open all year round\]\
\
[Close](https://www.jcom.co.jp/service/net/#)\
\
[](https://www.jcom.co.jp/service/net/#)\
\
New Customers　  \
Applications and Inquiries\
\
[Applications and Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)\
\
[0120-989-970](tel:0120-989-970)\
\
Business hours: 9:00-18:00  \
\[Open all year round\]\
\
[Close](https://www.jcom.co.jp/service/net/#)\
\
[](https://www.jcom.co.jp/service/net/#)\
\
Current Customers　  \
Inquiries\
\
[Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)\
\
[0120-989-970](tel:0120-989-970)\
\
Business hours: 9:00-18:00  \
\[Open all year round\]\
\
[Close](https://www.jcom.co.jp/service/net/#)\
\
[](https://www.jcom.co.jp/service/net/#)\
\
Current Customers　  \
Inquiries\
\
[Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)\
\
[0120-989-970](tel:0120-989-970)\
\
Business hours: 9:00-18:00  \
\[Open all year round\]\
\
[Close](https://www.jcom.co.jp/service/net/#)\
\
[](https://www.jcom.co.jp/service/net/#)\
\
Current Customers　  \
Inquiries\
\
[Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)\
\
[0120-989-970](tel:0120-989-970)\
\
Business hours: 9:00-18:00  \
\[Open all year round\]\
\
[Close](https://www.jcom.co.jp/service/net/#)\
\
[](https://www.jcom.co.jp/service/net/#)\
\
新用户　  \
申请・咨询\
\
신규가입 고객　  \
신청·문의\
\
Đối với khách hàng mới tham gia　  \
Ứng dụng / Yêu cầu\
\
Novos assinantes　  \
Solicitação/Consultas\
\
电话咨询（有翻译）\
\
전화 상담(통역 있음)\
\
Tư vấn qua điện thoại (có phiên dịch)\
\
Consulta por telefone (com intérprete)\
\
[050-1722-1733](tel:050-1722-1733)\
\
9:00-18:00 \[Open all year round\]\
\
[日本語での通話はこちら](https://www.jcom.co.jp/service/net/#)\
\
[申请・咨询](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)\
\
[신청・문의](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)\
\
[Ứng dụng / Yêu cầu](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)\
\
[Solicitação/Consultas](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)\
\
[Close](https://www.jcom.co.jp/service/net/#)\
\
[](https://www.jcom.co.jp/service/net/#)\
\
新用户　  \
申请・咨询\
\
신규가입 고객　  \
신청·문의\
\
Đối với khách hàng mới tham gia　  \
Ứng dụng / Yêu cầu\
\
Novos assinantes　  \
Solicitação/Consultas\
\
电话咨询（有翻译）\
\
전화 상담(통역 있음)\
\
Tư vấn qua điện thoại (có phiên dịch)\
\
Consulta por telefone (com intérprete)\
\
[050-1722-1733](tel:050-1722-1733)\
\
9:00-18:00 \[Open all year round\]\
\
[日本語での通話はこちら](https://www.jcom.co.jp/service/net/#)\
\
[申请・咨询](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)\
\
[신청・문의](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)\
\
[Ứng dụng / Yêu cầu](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)\
\
[Solicitação/Consultas](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)\
\
[Close](https://www.jcom.co.jp/service/net/#)\
\
[](https://www.jcom.co.jp/service/net/#)\
\
新用户　  \
申请・咨询\
\
신규가입 고객　  \
신청·문의\
\
Đối với khách hàng mới tham gia　  \
Ứng dụng / Yêu cầu\
\
Novos assinantes　  \
Solicitação/Consultas\
\
电话咨询（有翻译）\
\
전화 상담(통역 있음)\
\
Tư vấn qua điện thoại (có phiên dịch)\
\
Consulta por telefone (com intérprete)\
\
[050-1722-1733](tel:050-1722-1733)\
\
9:00-18:00 \[Open all year round\]\
\
[日本語での通話はこちら](https://www.jcom.co.jp/service/net/#)\
\
[申请・咨询](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)\
\
[신청・문의](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)\
\
[Ứng dụng / Yêu cầu](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)\
\
[Solicitação/Consultas](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)\
\
[Close](https://www.jcom.co.jp/service/net/#)\
\
[](https://www.jcom.co.jp/service/net/#)\
\
会员　  \
联系我们\
\
이용 중인 고객　  \
문의\
\
Khách hàng đang sử dụng　  \
Hỏi đáp\
\
Utilizadores　  \
Consultar\
\
电话咨询（有翻译）\
\
전화 상담(통역 있음)\
\
Tư vấn qua điện thoại (có phiên dịch)\
\
Consulta por telefone (com intérprete)\
\
[050-1722-1733](tel:050-1722-1733)\
\
9:00-18:00 \[Open all year round\]\
\
[日本語での通話はこちら](https://www.jcom.co.jp/service/net/#)\
\
[联系我们](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)\
\
[문의](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)\
\
[Hỏi đáp](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)\
\
[Consultar](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)\
\
[Close](https://www.jcom.co.jp/service/net/#)\
\
[](https://www.jcom.co.jp/service/net/#)\
\
会员　  \
联系我们\
\
이용 중인 고객　  \
문의\
\
Khách hàng đang sử dụng　  \
Hỏi đáp\
\
Utilizadores　  \
Consultar\
\
电话咨询（有翻译）\
\
전화 상담(통역 있음)\
\
Tư vấn qua điện thoại (có phiên dịch)\
\
Consulta por telefone (com intérprete)\
\
[050-1722-1733](tel:050-1722-1733)\
\
9:00-18:00 \[Open all year round\]\
\
[日本語での通話はこちら](https://www.jcom.co.jp/service/net/#)\
\
[联系我们](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)\
\
[문의](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)\
\
[Hỏi đáp](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)\
\
[Consultar](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)\
\
[Close](https://www.jcom.co.jp/service/net/#)\
\
[](https://www.jcom.co.jp/service/net/#)\
\
会员　  \
联系我们\
\
이용 중인 고객　  \
문의\
\
Khách hàng đang sử dụng　  \
Hỏi đáp\
\
Utilizadores　  \
Consultar\
\
电话咨询（有翻译）\
\
전화 상담(통역 있음)\
\
Tư vấn qua điện thoại (có phiên dịch)\
\
Consulta por telefone (com intérprete)\
\
[050-1722-1733](tel:050-1722-1733)\
\
9:00-18:00 \[Open all year round\]\
\
[日本語での通話はこちら](https://www.jcom.co.jp/service/net/#)\
\
[联系我们](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)\
\
[문의](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)\
\
[Hỏi đáp](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)\
\
[Consultar](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)\
\
[Close](https://www.jcom.co.jp/service/net/#)\
\
[](https://www.jcom.co.jp/service/net/#)\
\
日本語でのお問い合わせ\
\
[海外にお住まいの方](https://cs.myjcom.jp/knowledgeDetail?an=004897372)\
\
[日本国内にお住まいの方](https://www.jcom.co.jp/contactus/call_rgu.html)\
\
[閉じる](https://www.jcom.co.jp/service/net/#)\
\
[](https://www.jcom.co.jp/service/net/#)\
\
日本語でのお問い合わせ\
\
[海外にお住まいの方](https://cs.myjcom.jp/knowledgeDetail?an=004897372)\
\
[日本国内にお住まいの方](https://www.jcom.co.jp/contactus/call_rgu.html)\
\
[閉じる](https://www.jcom.co.jp/service/net/#)\
\
[](https://www.jcom.co.jp/service/net/#)\
\
Current Customers  \
Edit / Add to Your Plan\
\
Click here  \
to add to / edit J:COM NET plan\
\
If you’re not a J:COM NET customer\
\
[Add  \
J:COM NET](https://www.jcom.co.jp/sim_contact/entry_request.php?contract=1&sc_pid=common_upper_entry_request04)\
\
J:COM NET Customers\
\
[J:COM NET  \
Plan Change](https://www2.myjcom.jp/special/redirect/wdo_net_service_change/?sc_pid=common_upper_net_change04)\
\
* * *\
\
J:COM NET extras (Mesh Wi-Fi Routers, etc.)  \
Click here to add\
\
[My page login](https://mypage.jcom.co.jp/service?service=net&sc_pid=common_upper_mypage_net04)\
\
[Click here to sign up for J:COM LINK mini](https://www2.myjcom.jp/join/?sc_pid=common_upper_join_net04#anc0301)\
\
* * *\
\
Click here  \
to add or change other services\
\
[Edit / Add to Your Plan](https://support.myjcom.jp/app/vivr_cont/service_contract.php)\
\
[Close](https://www.jcom.co.jp/service/net/#)\
\
[](https://www.jcom.co.jp/service/net/#)\
\
Current Customers  \
Edit / Add to Your Plan\
\
Click here  \
to add to / edit J:COM NET plan\
\
If you’re not a J:COM NET customer\
\
[Add  \
J:COM NET](https://www.jcom.co.jp/sim_contact/entry_request.php?contract=1&sc_pid=common_bottom_entry_request04)\
\
J:COM NET Customers\
\
[J:COM NET  \
Plan Change](https://www2.myjcom.jp/special/redirect/wdo_net_service_change/?sc_pid=common_bottom_net_change04)\
\
* * *\
\
J:COM NET extras (Mesh Wi-Fi Routers, etc.)  \
Click here to add\
\
[My page login](https://mypage.jcom.co.jp/service?service=net&sc_pid=common_bottom_mypage_net04)\
\
[Click here to sign up for J:COM LINK mini](https://www2.myjcom.jp/join/?sc_pid=common_bottom_join_net04#anc0301)\
\
* * *\
\
Click here  \
to add or change other services\
\
[Edit / Add to Your Plan](https://support.myjcom.jp/app/vivr_cont/service_contract.php)\
\
[Close](https://www.jcom.co.jp/service/net/#)\
\
[](https://www.jcom.co.jp/service/net/#)\
\
Current Customers  \
Edit / Add to Your Plan\
\
Click here  \
to add to / edit J:COM NET plan\
\
If you’re not a J:COM NET customer\
\
[Add  \
J:COM NET](https://www.jcom.co.jp/sim_contact/entry_request.php?contract=1&sc_pid=common_middle_entry_request04)\
\
J:COM NET Customers\
\
[J:COM NET  \
Plan Change](https://www2.myjcom.jp/special/redirect/wdo_net_service_change/?sc_pid=common_middle_net_change04)\
\
* * *\
\
J:COM NET extras (Mesh Wi-Fi Routers, etc.)  \
Click here to add\
\
[My page login](https://mypage.jcom.co.jp/service?service=net&sc_pid=common_middle_mypage_net04)\
\
[Click here to sign up for J:COM LINK mini](https://www2.myjcom.jp/join/?sc_pid=common_middle_join_net04#anc0301)\
\
* * *\
\
Click here  \
to add or change other services\
\
[Edit / Add to Your Plan](https://support.myjcom.jp/app/vivr_cont/service_contract.php)\
\
[Close](https://www.jcom.co.jp/service/net/#)\
\
Topics\
------\
\
*   2022.10.31\
    \
    Sequential expansion of service area to Teine Ward, Kita Ward, and Nishi Ward, Sapporo City [Click here for details](https://www.jcom.co.jp/en/service/enshin/sapporo/)\
    \
\
Fiber optic and Internet-related columns\
----------------------------------------\
\
We provide a variety of information related to the Internet, such as how to choose a router, where to install it, and what to do when you can't connect.\
\
What is fiber optic line?  \
Easy-to-understand explanation of advantages and disadvantages and how to choose\
\
![](https://www.jcom.co.jp/service/net/column/images/index05_mv.jpg)\
\
Release date: May 31, 2024\
\
Many people who are looking for an internet connection may be considering signing up for an optical line after hearing that "optical lines are faster." the internet…\
\
[read more](https://www.jcom.co.jp/service/net/column/005.html)\
\
Introducing how to switch fiber optic lines!  \
An easy-to-understand explanation of the procedure, the period until opening, and points to note\
\
![](https://www.jcom.co.jp/service/net/column/images/index23_mv.jpg)\
\
Release date: February 29, 2024\
\
If you switch to a fiber-optic line, you may be able to enjoy benefits such as lower fees and a more comfortable internet connection.\
\
[read more](https://www.jcom.co.jp/service/net/column/023.html)\
\
What is the speed of the fiber optic line?  \
Introducing average speeds and how to measure them right now\
\
![](https://www.jcom.co.jp/service/net/column/images/index21_mv.jpg)\
\
Release date: January 31, 2024\
\
Some people may be wondering what the normal speed of optical fiber is. The maximum speed of optical fiber is about 1 to 10 Gbps. In actual measurements, the maximum speed is…\
\
[read more](https://www.jcom.co.jp/service/net/column/021.html)\
\
[Column List](https://www.jcom.co.jp/service/net/column/)\
\
\[Notes\]\
\
*   Communication speed may decrease depending on the usage environment and device used.\
*   To use Wi-Fi, you need a device such as a computer, smartphone, or tablet that supports the standard.\
*   McAfee, and the McAfee logo are trademarks or registered trademarks of McAfee, LLC or its subsidiaries in the United States and other countries. Other trademarks and brands may be claimed by others.\
\
\[J:COM NET Hikari\]\
\
*   Delivery speed varies depending on the area and course.\
\
\[Next-generation AI Wi-Fi (high-performance Wi-Fi 7)\]\
\
*   IEEE802.11a/b/g/n/ac/ax/be standard. To achieve 10G communication speeds, you must connect the ONU with a compatible device (10GBASE-T) or wired LAN (Category 6A, 6e, or higher). Cannot be used in conjunction with commercially available wireless repeaters.\
*   Some apartment complexes may not be able to provide this service. For details, please contact J:COM.\
\
\[J:COM NET Hikari 10G/1G Course (J:COM Line)\]\
\
If your device (one device) is Wi-Fi 7 compatible and has a 2x2 antenna and 6GHz, the maximum speed according to the technical standard when connected wirelessly is approximately 11.5Gbps.\
\
\[J:COM NET Hikari 10G/1G Course on au Hikari\]\
\
If your device (one device) is Wi-Fi 7 compatible and has a 2x2 antenna and 6GHz, the maximum speed according to the technical standard when connected wirelessly is approximately 11.5Gbps.\
\
\[J:COM NET Hikari (N)\]\
\
*   IEEE802.11a/b/g/n/ac/ax standard. To achieve 10G communication speeds, you must connect the ONU with a compatible device (10GBASE-T) or wired LAN (Category 6A, 6e, or higher). Cannot be used in conjunction with commercially available wireless repeaters.\
*   To use it, you need to subscribe to a service specified by J:COM.\
\
Close\
\
[シェアする](https://www.jcom.co.jp/service/net/)\
\
[Tweet](https://twitter.com/share?ref_src=twsrc%5Etfw)\
\
\[About the amount including tax\]\
\
*   The listed amounts include tax unless otherwise specified.\
*   Consumption tax differences may occur due to changes in the consumption tax rounding method under the invoice system.\
\
1.  [J:COM Top](https://www.jcom.co.jp/en/)\
    \
2.  [Our Service](https://www.jcom.co.jp/en/service/)\
    \
3.  For fiber optic lines, J:COM NET (internet line)\
\
[![Back to top of page](https://www.jcom.co.jp/common_v10/images/PageTop.webp)](https://www.jcom.co.jp/service/net/#header)\
\
[Return to top of page](https://www.jcom.co.jp/service/net/#header)\
\
[Service Information](https://www.jcom.co.jp/en/?sc_pid=common_footer_unav_service_01)\
\
[Online Shop](https://onlineshop.jcom.co.jp/?sc_pid=common_footer_unav_ols_01)\
\
[Support Troubleshooting/FAQ](https://cs.myjcom.jp/?sc_pid=common_footer_unav_csmyjcom_01)\
\
[Fun! J:COM TV program information/presents and benefits](https://www.myjcom.jp/?sc_pid=common_footer_unav_myjcom_01)\
\
[My page Confirm/change contract details](https://mypage.jcom.co.jp/?sc_pid=common_footer_unav_mypage_01)\
\
[Company website](https://www.jcom.co.jp/en/corporate/?sc_pid=common_footer_unav_corporate_01)\
\
*   [![Twitter](https://www.jcom.co.jp/common_v10/images/icn-x.svg)](https://twitter.com/jcom_info?sc_pid=common_footer_sns_twitter_01)\
    \
*   [![instagram](https://www.jcom.co.jp/common_v10/images/icn-instagram.svg)](https://www.instagram.com/jcom.official/?sc_pid=common_footer_sns_instagram_01)\
    \
*   [![Facebook](https://www.jcom.co.jp/common_v10/images/icn-facebook.svg)](https://www.facebook.com/JCOM.ZAQ?sc_pid=common_footer_sns_facebook_01)\
    \
*   [![LINE](https://www.jcom.co.jp/common_v10/images/icn-line.svg)](https://www.jcom.co.jp/en/social/campaign/line/?sc_pid=common_footer_sns_line_01)\
    \
*   [![note](https://www.jcom.co.jp/common_v10/images/icn-note.svg)](https://note.jcom.co.jp/?sc_pid=common_footer_sns_note_01)\
    \
\
[Account list](https://www.jcom.co.jp/en/service/social/?sc_pid=common_footer_sns_list_01)\
\
[![J:COM J:COM ANNIVERSARY: Making Newness a Natural Thing](https://www.jcom.co.jp/common_v10/images/logo-jcom-horizontal.svg)](https://www.jcom.co.jp/en/special/30th/)\
\
*   [Site map](https://www.jcom.co.jp/en/sitemap/?sc_pid=common_footer_sitemap)\
    \
*   [Privacy portal](https://www.jcom.co.jp/en/corporate/site_info/privacy-portal/?sc_pid=common_footer_privacybasic)\
    \
*   [Privacy policy](https://www.jcom.co.jp/en/corporate/site_info/privacy_policy/?sc_pid=common_footer_privacy)\
    \
*   [Web Accessibility Initiatives](https://www.jcom.co.jp/en/corporate/site_info/accessibility/?sc_pid=common_footer_accessibility)\
    \
*   [Security policy](https://www.jcom.co.jp/en/corporate/site_info/security_policy/?sc_pid=common_footer_security)\
    \
*   [Social media policy](https://www.jcom.co.jp/en/corporate/site_info/socialmedia_policy/?sc_pid=common_footer_social)\
    \
*   [Human Rights Policy](https://www.jcom.co.jp/en/corporate/sustainability/well_being/hrp/?sc_pid=common_footer_hrp#policy)\
    \
*   [Regarding the use of cookie information, advertisement distribution, etc.](https://www.jcom.co.jp/en/corporate/site_info/privacy_policy/cookie/?sc_pid=common_footer_cookie)\
    \
*   [Inquiries](https://www.jcom.co.jp/en/contactus/?sc_pid=common_footer_contactus)\
    \
*   [Company website](https://www.jcom.co.jp/en/corporate/?sc_pid=common_footer_corporate)\
    \
*   [Careers](https://recruit.jcom.co.jp/?sc_pid=common_footer_recruit)\
    \
*   [Corporate customers](https://business.jcom.co.jp/?sc_pid=common_footer_business)\
    \
*   [About This Site](https://www.jcom.co.jp/en/site_info/?sc_pid=common_footer_siteinfo)\
    \
\
Copyright © JCOM Co., Ltd. All Rights Reserved.\
\
[](https://www.jcom.co.jp/service/net/#)\
\
Configure area\
\
Please enter your postal code.\
\
〒\
\
No hyphen (-) required\
\
Please select your housing type.\
\
![icon](https://www.jcom.co.jp/common_v10/images/icn-apartment.svg)Apartments\
\
![icon](https://www.jcom.co.jp/common_v10/images/icn-house.svg)Houses\
\
Please select the appropriate age.  \
(The plans available will change.)\
\
Age 27 or older\
\
​Under 26 years old\
\
​Under 22 years old\
\
Next\
\
[](https://www.jcom.co.jp/service/net/#)\
\
Configure area\
\
Please enter your postal code.\
\
〒\
\
 \
\
Please select your housing type.\
\
![icon](https://www.jcom.co.jp/common_v10/images/icn-apartment.svg)Apartments\
\
![icon](https://www.jcom.co.jp/common_v10/images/icn-house.svg)Houses\
\
Next\
\
[](https://www.jcom.co.jp/service/net/#)\
\
Configure area\
\
Please enter your postal code.\
\
〒\
\
 \
\
Please select your housing type.\
\
![icon](https://www.jcom.co.jp/common_v10/images/icn-apartment.svg)Apartments\
\
![icon](https://www.jcom.co.jp/common_v10/images/icn-house.svg)Houses\
\
Next\
\
[](https://www.jcom.co.jp/service/net/#)\
\
Configure area\
\
Please enter your postal code.\
\
〒\
\
No hyphen (-) required\
\
Next\
\
[](https://www.jcom.co.jp/service/net/#)\
\
Configure area\
\
Please enter your postal code.\
\
〒\
\
 \
\
Please select your housing type.\
\
![icon](https://www.jcom.co.jp/common_v10/images/icn-apartment.svg)Apartments\
\
![icon](https://www.jcom.co.jp/common_v10/images/icn-house.svg)Houses\
\
Next\
\
[](https://www.jcom.co.jp/service/net/#)\
\
Check service\
\
Please enter the postal code of your new address.\
\
〒\
\
 \
\
Next\
\
[](https://www.jcom.co.jp/service/net/#)\
\
J:COM Telemedicine coverage area check\
\
Please enter your postal code.\
\
〒\
\
No hyphen (-) required\
\
Please select your housing type.\
\
![icon](https://www.jcom.co.jp/common_v10/images/icn-apartment.svg)Apartments\
\
![icon](https://www.jcom.co.jp/common_v10/images/icn-house.svg)Houses\
\
Next\
\
[](https://www.jcom.co.jp/service/net/#)\
\
Select prefecture\
\
Required Select prefecture.\
\
Hokkaido and Tohoku\
\
[Hokkaido](https://www.jcom.co.jp/service/net/#)\
 [Miyagi Prefecture](https://www.jcom.co.jp/service/net/#)\
\
Kanto\
\
[Tokyo](https://www.jcom.co.jp/service/net/#)\
 [Kanagawa Prefecture](https://www.jcom.co.jp/service/net/#)\
 [Chiba Prefecture](https://www.jcom.co.jp/service/net/#)\
 [Saitama Prefecture](https://www.jcom.co.jp/service/net/#)\
 [Gunma Prefecture](https://www.jcom.co.jp/service/net/#)\
 [Ibaraki Prefecture](https://www.jcom.co.jp/service/net/#)\
\
Kansai\
\
[Osaka Prefecture](https://www.jcom.co.jp/service/net/#)\
 [Kyoto Prefecture](https://www.jcom.co.jp/service/net/#)\
 [Wakayama Prefecture](https://www.jcom.co.jp/service/net/#)\
 [Hyogo Prefecture](https://www.jcom.co.jp/service/net/#)\
\
Kyushu/Yamaguchi\
\
[Fukuoka Prefecture](https://www.jcom.co.jp/service/net/#)\
 [Kumamoto Prefecture](https://www.jcom.co.jp/service/net/#)\
 [Oita Prefecture](https://www.jcom.co.jp/service/net/#)\
 [Yamaguchi Prefecture](https://www.jcom.co.jp/service/net/#)\
\
[Return](https://www.jcom.co.jp/service/net/#)\
\
[](https://www.jcom.co.jp/service/net/#)\
\
Select city/ward/town\
\
Required Please select your city.\
\
Current selection: Tokyo\
\
*   A\
*   Ka\
*   Sa\
*   Ta\
*   Na\
*   Ha\
*   Ma\
*   Ya\
*   Ra\
*   Wa\
\
[Akishima City](https://www.jcom.co.jp/service/net/#)\
 [Akiruno City](https://www.jcom.co.jp/service/net/#)\
 [Adachi Ward](https://www.jcom.co.jp/service/net/#)\
 [Itabashi Ward](https://www.jcom.co.jp/service/net/#)\
 [Inagi City](https://www.jcom.co.jp/service/net/#)\
 [Edogawa Ward](https://www.jcom.co.jp/service/net/#)\
 [Ota Ward](https://www.jcom.co.jp/service/net/#)\
\
Contents of “Ka”\
\
Regions starting with “A”\
\
[Akishima City](https://www.jcom.co.jp/service/net/#)\
 [Akiruno City](https://www.jcom.co.jp/service/net/#)\
 [Adachi Ward](https://www.jcom.co.jp/service/net/#)\
 [Itabashi Ward](https://www.jcom.co.jp/service/net/#)\
 [Inagi City](https://www.jcom.co.jp/service/net/#)\
 [Edogawa Ward](https://www.jcom.co.jp/service/net/#)\
 [Ota Ward](https://www.jcom.co.jp/service/net/#)\
\
Regions starting with “Ka”\
\
Regions starting with “Sa”\
\
Regions starting with “Ta”\
\
Regions starting with “Na”\
\
[Return](https://www.jcom.co.jp/service/net/#)\
\
[](https://www.jcom.co.jp/service/net/#)\
\
Configure area\
\
〒 1070052\
\
There are several possible areas for the postal code you entered.  \
Please select your address from the list below\
\
Please select 1 2 3 text text text\
\
Configure\
\
[Return](https://www.jcom.co.jp/service/net/#)\
\
[](https://www.jcom.co.jp/service/net/#)\
\
Configure area\
\
〒 \-------\
\
Please select the following address information.\
\
  \
\
Please select 1 2 3 text text text\
\
Next\
\
[Return](https://www.jcom.co.jp/service/net/#)\
\
[](https://www.jcom.co.jp/service/net/#)\
\
Check Gig coverage area\
\
〒 1070052 (J:COM Machida/Kawasaki)\
\
This is the coverage area of the J:COM NET 1G plan  \
​\
\
\* "J:COM NET 1Gig plan" is a 1Gig service that can be used with cable TV lines.\
\
This is the coverage area for Hikari 10G/5G/1G plan  \
​\
\
\* Hikari is not available in some areas (gradually expanding service areas) [For more information, please contact us here.](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)\
\
Hikari 10G/5G/1G plan \*1  \
coverage area is currently being expanded.\
\
J:COM NET 1G plan \*2  \
coverage area.\
\
\*1 Hikari is not available in some areas (gradually expanding service areas) [For more information, please contact us here.](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)\
\
\*2 "J:COM NET 1Gig plan" is a 1Gig service that can be used with cable TV lines.\
\
Hikari 10G/5G/1G plan  \
J:COM NET 1G plan  \
coverage area.\
\
\*Not available in some areas (gradually expanding service areas) [For more information, please contact us here.](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)\
\
\* "J:COM NET 1Gig plan" is a 1Gig service that can be used with cable TV lines.\
\
Outside the J:COM NET 1G plan  \
coverage area. (Sequentially expanding the coverage area)\
\
is in the 320M plan  \
coverage area.\
\
is in the 320M plan  \
coverage area.\
\
The J:COM NET 1G plan coverage area is gradually expanding.\
\
[For detailed information on the coverage area, contact us here.](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)\
\
This is the service area of J:COM Oita (Oita Cable Telecom Co., Ltd.).  \
[Please refer to the J:COM Oita (Oita Cable Telecom Co., Ltd.) homepage.](https://wwwjcom.oct-net.ne.jp/)\
​\
\
This is the Yokohama Cable Vision (YCV) service area.  \
[Please refer to the Yokohama Cable Vision (YCV) homepage.](https://www.catv-yokohama.ne.jp/)\
​\
\
[Sign Up](https://www.jcom.co.jp/sim_contact/entry_request.php?refresh=new&net_service=1)\
\
[Check the sign up process](https://www.jcom.co.jp/en/service/guide/sdu/)\
\
Some areas may be outside the coverage area.\
\
[View prices/plans](https://www.jcom.co.jp/en/service/net/)\
\
Return\
\
[](https://www.jcom.co.jp/service/net/#)\
\
Check Gig coverage area\
\
〒 1070052 (Machida/Kawasaki)\
\
Hikari 10G/5G/1G plan  \
J:COM NET 1G plan  \
coverage area.\
\
\* "J:COM NET 1Gig plan" is a 1Gig service that can be used with cable TV lines.\
\
Hikari 10G/5G/1G plan  \
coverage area.\
\
Hikari 1G plan  \
J:COM NET 1G plan  \
coverage area.\
\
\* "J:COM NET 1Gig plan" is a 1Gig service that can be used with cable TV lines.\
\
Hikari 1G plan  \
coverage area.\
\
is in the 320M plan  \
coverage area.\
\
[Sign Up](https://www.jcom.co.jp/sim_contact/entry_request.php?refresh=new&net_service=1)\
\
[Check the sign up process](https://www.jcom.co.jp/en/service/guide/sdu/)\
\
Some areas may be outside the coverage area.\
\
View prices/plans\
\
[Savings calculator](https://onlineshop.jcom.co.jp/Simulation/Simulation)\
\
Return\
\
[](https://www.jcom.co.jp/service/net/#)\
\
Check Gig coverage area\
\
〒 1070052 \
\
is out of the J:COM NET  \
coverage area.\
\
is in the J:COM WiMAX  \
coverage area.\
\
[Sign Up](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=wimax2p)\
\
[Check the sign up process](https://www.jcom.co.jp/en/service/guide/sdu/)\
\
Some areas may be outside the coverage area.\
\
[View prices/plans](https://www.jcom.co.jp/en/service/wimax/)\
\
Return\
\
[](https://www.jcom.co.jp/service/net/#)\
\
Check coverage areas\
\
〒 \------- \
\
This is the service area of J:COM Oita (Oita Cable Telecom Co., Ltd.).  \
[Please refer to the J:COM Oita (Oita Cable Telecom Co., Ltd.) homepage.](https://wwwjcom.oct-net.ne.jp/)\
​\
\
This is the Yokohama Cable Vision (YCV) service area.  \
[Please refer to the Yokohama Cable Vision (YCV) homepage.](https://www.catv-yokohama.ne.jp/)\
​\
\
The following services are available.\
\
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-mobile.svg) ![J:COM MOBILE](https://www.jcom.co.jp/common_v10/images/logo-jcom-mobile.svg)](https://www.jcom.co.jp/en/service/mobile/)   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-electricity.svg) ![J:COM Denki](https://www.jcom.co.jp/common_v10/images/logo-jcom-electricity.svg)](https://www.jcom.co.jp/en/service/electricity/)\
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-gas.svg) ![J:COM GAS](https://www.jcom.co.jp/common_v10/images/logo-jcom-gas.svg)](https://www.jcom.co.jp/en/service/gas/)\
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-ssi.svg) ![J:COM Insurance](https://www.jcom.co.jp/common_v10/images/logo-jcom-ssi.svg)](https://www.jcom.co.jp/en/service/ssi/)\
  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-telemedicine.svg) ![J:COM Telemedicine](https://www.jcom.co.jp/common_v10/images/logo-jcom-telemedicine.svg)](https://www.jcom.co.jp/en/service/telemedicine/)\
\
The following services are [Price simulation](https://onlineshop.jcom.co.jp/Simulation/Simulation)\
 in  \
Please check the area.\
\
  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-net.svg)\
\
![J:COM NET](https://www.jcom.co.jp/common_v10/images/logo-jcom-net.svg) Optical 10G/Optical 1G](https://www.jcom.co.jp/en/price/hikari-n/)  ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-tv.svg) Terrestrial digital/BS digital  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-phone.svg) Hikari Denwa](https://www.jcom.co.jp/en/price/hikari-n/phone-op/)\
\
J:COM NET is provided via NTT line.\
\
[Sign Up](https://onlineshop.jcom.co.jp/planSelect)\
\
[Savings calculator](https://onlineshop.jcom.co.jp/Simulation/Simulation)\
\
If you want local cable TV ​ ​[here](https://www.catv-jcta.jp/search/index)\
\
Return\
\
Some services may not be available depending on your region.\
\
[](https://www.jcom.co.jp/service/net/#)\
\
Check service\
\
〒 1070052​\
\
This is the service area of J:COM Oita (Oita Cable Telecom Co., Ltd.). Please refer to the [J:COM Oita (Oita Cable Television Co., Ltd.) website to confirm what services](https://wwwjcom.oct-net.ne.jp/)\
 are provided.\
\
This is the Yokohama Cable Vision (YCV) service area.  \
[Please refer to the Yokohama Cable Vision (YCV) homepage.](https://www.catv-yokohama.ne.jp/)\
​\
\
The following services are available.\
\
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-tv.svg) ![J:COM TV](https://www.jcom.co.jp/common_v10/images/logo-jcom-tv.svg)](https://www.jcom.co.jp/en/service/tv/)   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-net.svg) ![J:COM NET](https://www.jcom.co.jp/common_v10/images/logo-jcom-net.svg)](https://www.jcom.co.jp/en/service/net/)\
  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-mobile.svg) ![J:COM MOBILE](https://www.jcom.co.jp/common_v10/images/logo-jcom-mobile.svg)](https://www.jcom.co.jp/en/service/mobile/)\
  \
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-phone.svg) ![J:COM PHONE](https://www.jcom.co.jp/common_v10/images/logo-jcom-phone.svg)](https://www.jcom.co.jp/en/service/phone/)   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-ssi.svg) ![J:COM Insurance](https://www.jcom.co.jp/common_v10/images/logo-jcom-ssi.svg)](https://www.jcom.co.jp/en/service/ssi/)\
  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-telemedicine.svg) ![J:COM Telemedicine](https://www.jcom.co.jp/common_v10/images/logo-jcom-telemedicine.svg)](https://www.jcom.co.jp/en/service/telemedicine/)\
\
[J:COMご加入中の方  \
お引越しのお手続き](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=contact_move)\
\
Return to postal code input\
\
[](https://www.jcom.co.jp/service/net/#)\
\
Check coverage areas\
\
〒 1070052 (J:COM Machida/Kawasaki)\
\
The following services are available.\
\
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-tv.svg) ![J:COM TV](https://www.jcom.co.jp/common_v10/images/logo-jcom-tv.svg)](https://www.jcom.co.jp/en/service/tv/)   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-net.svg) ![J:COM NET](https://www.jcom.co.jp/common_v10/images/logo-jcom-net.svg)](https://www.jcom.co.jp/en/service/net/)\
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-mobile.svg) ![J:COM MOBILE](https://www.jcom.co.jp/common_v10/images/logo-jcom-mobile.svg)](https://www.jcom.co.jp/en/service/mobile/)\
  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-electricity.svg) ![J:COM Denki](https://www.jcom.co.jp/common_v10/images/logo-jcom-electricity.svg)](https://www.jcom.co.jp/en/service/electricity/)\
  \
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-phone.svg) ![J:COM PHONE](https://www.jcom.co.jp/common_v10/images/logo-jcom-phone.svg)](https://www.jcom.co.jp/en/service/phone/)   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-gas.svg) ![J:COM GAS](https://www.jcom.co.jp/common_v10/images/logo-jcom-gas.svg)](https://www.jcom.co.jp/en/service/gas/)\
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-ssi.svg) ![J:COM Insurance](https://www.jcom.co.jp/common_v10/images/logo-jcom-ssi.svg)](https://www.jcom.co.jp/en/service/ssi/)\
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-home.svg) ![J:COM HOME](https://www.jcom.co.jp/common_v10/images/logo-jcom-home.svg)](https://www.jcom.co.jp/en/service/home/)\
  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-telemedicine.svg) ![J:COM Telemedicine](https://www.jcom.co.jp/common_v10/images/logo-jcom-telemedicine.svg)](https://www.jcom.co.jp/en/service/telemedicine/)\
\
[Application](https://onlineshop.jcom.co.jp/planSelect)\
 ​ ​[Application](https://onlineshop.jcom.co.jp/planSelect)\
\
[Check the sign up process](https://www.jcom.co.jp/en/service/guide/sdu/)\
\
Savings calculator\
\
Return\
\
[](https://www.jcom.co.jp/service/net/#)\
\
Check service\
\
〒 1070052 (J:COM Machida/Kawasaki)\
\
The following services are available.\
\
   ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-tv.svg) ![J:COM TV](https://www.jcom.co.jp/common_v10/images/logo-jcom-tv.svg) ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-net.svg) ![J:COM NET](https://www.jcom.co.jp/common_v10/images/logo-jcom-net.svg)  ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-mobile.svg) ![J:COM MOBILE](https://www.jcom.co.jp/common_v10/images/logo-jcom-mobile.svg)  ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-electricity.svg) ![J:COM Denki](https://www.jcom.co.jp/common_v10/images/logo-jcom-electricity.svg)  \
   ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-phone.svg) ![J:COM PHONE](https://www.jcom.co.jp/common_v10/images/logo-jcom-phone.svg) ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-gas.svg) ![J:COM GAS](https://www.jcom.co.jp/common_v10/images/logo-jcom-gas.svg)  ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-home.svg) ![J:COM HOME](https://www.jcom.co.jp/common_v10/images/logo-jcom-home.svg)\
\
[J:COMご加入中の方  \
お引越しのお手続き](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=contact_move)\
\
Return to postal code input\
\
[](https://www.jcom.co.jp/service/net/#)\
\
Check coverage areas\
\
Please select your service.\
\
Get your TV and Internet together!\
\
 ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-tv.svg)  \
![J:COM TV](https://www.jcom.co.jp/common_v10/images/logo-jcom-tv.svg)![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-net.svg)  \
![J:COM NET](https://www.jcom.co.jp/common_v10/images/logo-jcom-net.svg) ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-phone.svg)  \
![J:COM PHONE](https://www.jcom.co.jp/common_v10/images/logo-jcom-phone.svg)\
\
[Savings calculator](https://onlineshop.jcom.co.jp/Simulation/Simulation)\
\
Save more money on your monthly smartphone bill.\
\
![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-mobile.svg)  \
![J:COM MOBILE](https://www.jcom.co.jp/common_v10/images/logo-jcom-mobile.svg)\
\
[Savings calculator](https://www.jcom.co.jp/en/service/mobile/simulator/)\
\
Return\
\
[](https://www.jcom.co.jp/service/net/#)\
\
Check J:COM GAS coverage area\
\
〒 1070052  ( J:COM ---- )​\
\
![](https://www.jcom.co.jp/common_form/img/common/logo/logo_gas_osaka.png)\
\
coverage area.\
\
Some areas may be outside the coverage area.\
\
![](https://www.jcom.co.jp/common_form/img/common/logo/logo_gas_tokyo.png)\
\
coverage area.\
\
Some areas may be outside the coverage area.\
\
![](https://www.jcom.co.jp/common_form/img/common/logo/logo_gas_keiyo.png)\
\
coverage area.\
\
Some areas may be outside the coverage area.\
\
is out of the J:COM GAS  \
coverage area.\
\
Energy Uchuu Co., Ltd. \[Koshigaya/Kasukabe area/Hasuda Minami area\] \[Toride/Abiko area\]  \
If you live in an area where city gas is supplied,\
\
you can use the\
\
Tokyo Gas for J:COM "ZUTTO Gas" service.\
\
[Learn more](https://www.jcom.co.jp/en/service/tokyo_gas/)\
\
is out of the J:COM GAS  \
coverage area.\
\
Return\
\
[](https://www.jcom.co.jp/service/net/#)\
\
J:COM Telemedicine coverage area check\
\
〒 1070052  ( J:COM ---- )​\
\
J:COM Telemedicine  \
coverage area.\
\
Some areas may be outside the coverage area.\
\
[See list of medical institutions](https://www.jcom.co.jp/en/service/telemedicine/clinic/)\
\
[See prices](https://www.jcom.co.jp/en/service/telemedicine/price/)\
\
Outside the J:COM Telemedicine  \
coverage area.\
\
Return\
\
    \
\
[](https://www.jcom.co.jp/service/net/#)\
\
Notice to you\
-------------\
\
[Logout](https://www.jcom.co.jp/en/common/logout.html)\
\
日本語\
\
English
