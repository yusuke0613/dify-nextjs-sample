# BIGLOBE（ビッグローブ）

URL: https://www.biglobe.ne.jp/

---

*   サービス
    
    サービス
    
    *   [![BIGLOBE光](https://www.biglobe.ne.jp/images/ImgService-1.png)](https://join.biglobe.ne.jp/ftth/hikari/?cl=global_header_hikari_logo)
        
    *   [![BIGLOBE mobile](https://www.biglobe.ne.jp/images/ImgService-2.png)](https://join.biglobe.ne.jp/mobile/?cl=global_header_mobile_logo)
        
    *   [![BIGLOBE WiMAX](https://www.biglobe.ne.jp/images/ImgService-3.png)](https://join.biglobe.ne.jp/mobile/wimax/?cl=global_header_wimax_logo)
        
    *   [![BIGLOBE biz](https://www.biglobe.ne.jp/images/ImgService-4.png)](https://biz.biglobe.ne.jp/index.html)
        
    
    通信サービス
    
    *   [BIGLOBE光](https://join.biglobe.ne.jp/ftth/hikari/?cl=global_header_hikari_text)
        
    *   [auひかり](https://join.biglobe.ne.jp/ftth/one/?cl=global_header_one_text)
        
    *   [BIGLOBEモバイル](https://join.biglobe.ne.jp/mobile/?cl=global_header_mobile_text)
        
    *   [BIGLOBE WiMAX](https://join.biglobe.ne.jp/mobile/wimax/?cl=global_header_wimax_text)
        
    
    オプションサービス
    
    *   [お助けサポート＋](https://otasuke.biglobe.ne.jp/otasuke_plus/)
        
    *   [インターネット端末保証サービス](https://service.biglobe.ne.jp/internethosho/)
        
    *   [トータル・ネットセキュリティ](https://security.biglobe.ne.jp/tns/)
        
    *   [U-NEXT for BIGLOBE](https://vod.biglobe.ne.jp/unext/)
        
    *   [その他オプション](https://service.biglobe.ne.jp/)
        
    
    Webメディア
    
    *   [温泉大賞](https://biz.biglobe.ne.jp/onsen/award/)
        
    *   [しむぐらし](https://join.biglobe.ne.jp/mobile/sim/gurashi/)
        
    *   [あしたメディア](https://ashita.biglobe.co.jp/)
        
    
    法人のお客さま
    
    *   [BIGLOBE biz.](https://biz.biglobe.ne.jp/index.html)
        
    
*   企業情報
    
    企業情報
    
    *   [![](https://www.biglobe.ne.jp/images/ImgCompany-1.png)\
        \
        企業情報トップ](https://www.biglobe.co.jp/outline)
        
    *   [![](https://www.biglobe.ne.jp/images/ImgCompany-2.png)\
        \
        採用情報](https://www.biglobe.co.jp/recruit)
        
    *   [![](https://www.biglobe.ne.jp/images/ImgCompany-3.png)\
        \
        ブランド](https://www.biglobe.co.jp/outline/brand)
        
    
*   [](https://mypage.sso.biglobe.ne.jp/?cl=global_header_mypage)
    

[メール・Ｇポイントへのアクセス方法について](https://www.biglobe.ne.jp/topics/0001/)

[「BIGLOBEトップページ」サイトリニューアル、一部コンテンツ終了のお知らせ](https://www.biglobe.ne.jp/topics/0002/)

[![おうちのネット回線「BIGLOBE光」CM放映中！ 10ギガ高速回線*で動画もゲームもスムーズ *10ギガは一部エリアでの提供、対応ルーターが必要。利用機器・宅内配線・回線混雑などにより速度低下あり。](https://www.biglobe.ne.jp/images/top/mv/KV1.webp)](https://join.biglobe.ne.jp/ftth/hikari/?cl=btop_mv_hikari_cm)

＊10ギガは一部エリアでの提供、対応ルーターが必要。利用機器・宅内配線・回線混雑などにより速度低下あり。

![通信事業40年目の信頼 選ばれ続ける安心の証](https://www.biglobe.ne.jp/images/top/mv/KV2.webp)

![人とAIでよりそう安心のサポート体制](https://www.biglobe.ne.jp/images/top/mv/KV3.webp)

![技術への飽くなき探究心で快適なネットワークを支える](https://www.biglobe.ne.jp/images/top/mv/KV4.webp)

障害情報・重要なお知らせ
------------

4

*   [【重要】BIGLOBEを騙るフィッシングサイト・フィッシングメールにご注意ください](https://support.biglobe.ne.jp/news/phishing.html)
    

*   [緊急/災害2025/11/19 09:53令和７年11月18日大分市佐賀関の大規模火災に対するBIGLOBEの支援について](https://support.biglobe.ne.jp/saigai/index.html#400010060)
    
*   [緊急/災害2025/10/08 22:49令和７年台風第22号に伴う災害に対するBIGLOBEの支援について](https://support.biglobe.ne.jp/saigai/index.html#400010059)
    
*   [緊急/災害2025/09/13 04:18令和７年９月12日からの大雨に伴う災害に対するBIGLOBEの支援について](https://support.biglobe.ne.jp/saigai/index.html#400010058)
    

すべてを表示 閉じる

BIGLOBEのサービス
------------

![](https://www.biglobe.ne.jp/images/top/internet.webp)

高速通信で快適なネット生活

インターネット
-------

*   [BIGLOBE光](https://join.biglobe.ne.jp/ftth/hikari/?cl=btop_service_hikari)
    
*   [auひかり](https://join.biglobe.ne.jp/ftth/one/?cl=btop_service_one)
    

![](https://www.biglobe.ne.jp/images/top/mobile.webp)

場所にとらわれない便利さ

モバイル
----

*   [BIGLOBEモバイル](https://join.biglobe.ne.jp/mobile/?cl=btop_service_mobile)
    
*   [BIGLOBE WiMAX](https://join.biglobe.ne.jp/mobile/wimax/?cl=btop_service_wimax)
    

![](https://www.biglobe.ne.jp/images/top/support.webp)

ネット生活を安心・便利に

サポート・オプション
----------

*   [お助けサポート＋](https://otasuke.biglobe.ne.jp/otasuke_plus/)
    
*   [U-NEXT for BIGLOBE](https://vod.biglobe.ne.jp/unext/)
    

法人のお客さま
-------

[![](https://www.biglobe.ne.jp/images/top/biz.webp)\
\
法人向けサービスポータルサイト\
\
BIGLOBE biz.\
------------](https://biz.biglobe.ne.jp/index.html)

おトクな情報・特典
---------

[![BIGLOBE光 10ギガ 2年プラン(自動更新・違約金あり) 6カ月間 月額0円＊1 さらにキャッシュバックつき！※初期費用・工事費、対応ルーター別。7カ月目以降月額6,270円。＊1 特典適用時。さまざまな特典企画を常時実施。本特典は現在有効なもの。予告なく、特典を増減・変更、終了する場合あり。※10ギガは一部エリアでの提供となります。※通信速度はご利用機器、宅内配線、回線混雑等により低下します。](https://www.biglobe.ne.jp/images/top/campaign/bihikari_640x360_20251001.png)\
\
BIGLOBE光 新規＆乗り換え特典](https://join.biglobe.ne.jp/ftth/hikari/?cl=btop_campaign_hikari)
[![5G対応 データ容量無制限！＊工事不要 BIGLOBEは初月からなが～くおトク！初月0円 ※初月解約時を除く 値引き特典により1～24カ月目までずーっと2,980円（税込3,278円）/月 ※手数料・オプション料別、ルーター代別。25カ月目以降は4,928円（税込）/月 契約解除料なし！ルーター送料0円！最低利用期間なし！](https://www.biglobe.ne.jp/images/top/campaign/wimax_640x360_20251001.webp)\
\
BIGLOBE WiMAX](https://join.biglobe.ne.jp/mobile/wimax/5g/?cl=btop_campaign_wimax)
[![法人向けBIGLOBE光 個人事業主でも契約可能 おトクな特典で初期費用を軽減！訪問サポートで設定もスムーズ！※弊社所定の審査が必要です。](https://www.biglobe.ne.jp/images/top/campaign/biz_bhikari_640x360_251127.png)\
\
法人向けBIGLOBE光](https://biz.biglobe.ne.jp/hikari/index.html?utm_source=btop&utm_medium=cpv&utm_campaign=202511_campaign)
[![エンタメフリー・オプション　動画・音楽たのしみまくり！音声通話SIM限定 初回申込のみ 最大2カ月無料](https://www.biglobe.ne.jp/images/top/campaign/entamefree_640x360_20251001.webp)\
\
エンタメフリー・オプション](https://join.biglobe.ne.jp/mobile/option/entamefree.html?cl=btop_campaign_entamefree)
[![トータル・ネットセキュリティ　ウイルスや詐欺SMSなどパソコン・スマホまとめてセキュリティ対策　特典で最大2カ月無料](https://www.biglobe.ne.jp/images/top/campaign/tns_640x360_20251001.png)\
\
トータル・ネットセキュリティ](https://security.biglobe.ne.jp/tns/index.html?ccode=mp39&hinfo1=ncdmp039&utm_source=btop&utm_medium=banner&utm_campaign=tns-btop-20251001)
[![U-NEXT for BIGLOBE 初回31日間無料ではじめる](https://www.biglobe.ne.jp/images/top/campaign/u-next_640x360_20251001.png)\
\
U-NEXT for BIGLOBE](https://vod.biglobe.ne.jp/unext/index.html?hinfo1=ncdun023&utm_source=btop&utm_medium=banner&utm_campaign=unext-btop-20251001)
[![【初回初月無料】フル機能・最新版のPCソフト100本超が使い放題！超ホーダイ for BIGLOBE](https://www.biglobe.ne.jp/images/top/campaign/pchoudai_640x360_20251001.png)\
\
超ホーダイ for BIGLOBE](https://pchoudai.biglobe.ne.jp/index.html?hinfo1=ncdbp)
[![BIGLOBE光 10ギガ 2年プラン(自動更新・違約金あり) 6カ月間 月額0円＊1 さらにキャッシュバックつき！※初期費用・工事費、対応ルーター別。7カ月目以降月額6,270円。＊1 特典適用時。さまざまな特典企画を常時実施。本特典は現在有効なもの。予告なく、特典を増減・変更、終了する場合あり。※10ギガは一部エリアでの提供となります。※通信速度はご利用機器、宅内配線、回線混雑等により低下します。](https://www.biglobe.ne.jp/images/top/campaign/bihikari_640x360_20251001.png)\
\
BIGLOBE光 新規＆乗り換え特典](https://join.biglobe.ne.jp/ftth/hikari/?cl=btop_campaign_hikari)
[![5G対応 データ容量無制限！＊工事不要 BIGLOBEは初月からなが～くおトク！初月0円 ※初月解約時を除く 値引き特典により1～24カ月目までずーっと2,980円（税込3,278円）/月 ※手数料・オプション料別、ルーター代別。25カ月目以降は4,928円（税込）/月 契約解除料なし！ルーター送料0円！最低利用期間なし！](https://www.biglobe.ne.jp/images/top/campaign/wimax_640x360_20251001.webp)\
\
BIGLOBE WiMAX](https://join.biglobe.ne.jp/mobile/wimax/5g/?cl=btop_campaign_wimax)
[![法人向けBIGLOBE光 個人事業主でも契約可能 おトクな特典で初期費用を軽減！訪問サポートで設定もスムーズ！※弊社所定の審査が必要です。](https://www.biglobe.ne.jp/images/top/campaign/biz_bhikari_640x360_251127.png)\
\
法人向けBIGLOBE光](https://biz.biglobe.ne.jp/hikari/index.html?utm_source=btop&utm_medium=cpv&utm_campaign=202511_campaign)
[![エンタメフリー・オプション　動画・音楽たのしみまくり！音声通話SIM限定 初回申込のみ 最大2カ月無料](https://www.biglobe.ne.jp/images/top/campaign/entamefree_640x360_20251001.webp)\
\
エンタメフリー・オプション](https://join.biglobe.ne.jp/mobile/option/entamefree.html?cl=btop_campaign_entamefree)
[![トータル・ネットセキュリティ　ウイルスや詐欺SMSなどパソコン・スマホまとめてセキュリティ対策　特典で最大2カ月無料](https://www.biglobe.ne.jp/images/top/campaign/tns_640x360_20251001.png)\
\
トータル・ネットセキュリティ](https://security.biglobe.ne.jp/tns/index.html?ccode=mp39&hinfo1=ncdmp039&utm_source=btop&utm_medium=banner&utm_campaign=tns-btop-20251001)
[![U-NEXT for BIGLOBE 初回31日間無料ではじめる](https://www.biglobe.ne.jp/images/top/campaign/u-next_640x360_20251001.png)\
\
U-NEXT for BIGLOBE](https://vod.biglobe.ne.jp/unext/index.html?hinfo1=ncdun023&utm_source=btop&utm_medium=banner&utm_campaign=unext-btop-20251001)
[![【初回初月無料】フル機能・最新版のPCソフト100本超が使い放題！超ホーダイ for BIGLOBE](https://www.biglobe.ne.jp/images/top/campaign/pchoudai_640x360_20251001.png)\
\
超ホーダイ for BIGLOBE](https://pchoudai.biglobe.ne.jp/index.html?hinfo1=ncdbp)

[BIGLOBEブランドについて](https://www.biglobe.co.jp/outline/brand)

![](https://www.biglobe.ne.jp/_astro/bipple-initiative.BwitABzf.svg)

BIGLOBEについて
-----------

[![エンジニアリング](https://www.biglobe.ne.jp/images/top/network-technology.webp)\
\
### エンジニアリング\
\
快適・安全なインターネットを支える技術](https://www.biglobe.co.jp/engineering)
[![サステナビリティ](https://www.biglobe.ne.jp/images/top/sustainability.webp)\
\
### サステナビリティ\
\
地球にやさしいインターネットの提供](https://www.biglobe.co.jp/sustainability)
[![ブランド](https://www.biglobe.ne.jp/images/top/brand.webp)\
\
### ブランド\
\
コーポレートロゴを変更してブランドイメージを一新](https://www.biglobe.co.jp/outline/brand)

[](https://www.biglobe.ne.jp/)

*   [](https://twitter.com/biglobe)
    
*   [](https://www.instagram.com/biglobe_official/)
    
*   [](https://www.facebook.com/BIGLOBE)
    
*   [](https://www.youtube.com/user/BIGLOBEchannel)
    

個人のお客さま

通信サービス

*   [BIGLOBE光](https://join.biglobe.ne.jp/ftth/hikari/?cl=global_footer_hikari)
    
*   [auひかり](https://join.biglobe.ne.jp/ftth/one/?cl=global_footer_one)
    
*   [BIGLOBEモバイル](https://join.biglobe.ne.jp/mobile/?cl=global_footer_mobile)
    
*   [BIGLOBE WiMAX](https://join.biglobe.ne.jp/mobile/wimax/?cl=global_footer_wimax)
    

オプションサービス

*   [お助けサポート＋](https://otasuke.biglobe.ne.jp/otasuke_plus/)
    
*   [インターネット端末保証サービス](https://service.biglobe.ne.jp/internethosho/)
    
*   [トータル・ネットセキュリティ](https://security.biglobe.ne.jp/tns/)
    
*   [U-NEXT for BIGLOBE](https://vod.biglobe.ne.jp/unext/)
    
*   [その他オプション](https://service.biglobe.ne.jp/)
    

Webメディア

*   [温泉大賞](https://biz.biglobe.ne.jp/onsen/award/)
    
*   [しむぐらし](https://join.biglobe.ne.jp/mobile/sim/gurashi/)
    
*   [あしたメディア](https://ashita.biglobe.co.jp/)
    

法人のお客さま

*   [BIGLOBE biz.](https://biz.biglobe.ne.jp/index.html)
    
*   [BIGLOBE光](https://biz.biglobe.ne.jp/hikari/index.html)
    
*   [フレッツ光](https://biz.biglobe.ne.jp/flets/index.html)
    
*   [プロバイダサービス](https://biz.biglobe.ne.jp/member/office/provider.html)
    
*   [光回線用 固定IPアドレス](https://biz.biglobe.ne.jp/ip/index.html)
    
*   [BIGLOBEモバイル](https://biz.biglobe.ne.jp/sim/index.html)
    
*   [BIGLOBE WiMAX](https://biz.biglobe.ne.jp/wimax/index.html)
    
*   [IPトランジット](https://biz.biglobe.ne.jp/transit/index.html)
    
*   [マカフィー®マルチ アクセス](https://biz.biglobe.ne.jp/mma/index.html)
    
*   [法人向け独自ドメイン](https://biz.biglobe.ne.jp/domain/index.html)
    
*   [ONSENWORK](https://workation.biglobe.ne.jp/onsen/)
    

企業情報

*   [企業情報](https://www.biglobe.co.jp/outline)
    
*   [トップメッセージ](https://www.biglobe.co.jp/outline/message)
    
*   [ブランド](https://www.biglobe.co.jp/outline/brand)
    
*   [サステナビリティ](https://www.biglobe.co.jp/sustainability)
    
*   [ニュース](https://www.biglobe.co.jp/pressroom)
    
*   [採用情報](https://www.biglobe.co.jp/recruit)
    
*   [BIGLOBE Style](https://style.biglobe.co.jp/)
    
*   [ソーシャルメディア](https://www.biglobe.co.jp/social)
    

ご利用中の方

*   [マイページ](https://mypage.sso.biglobe.ne.jp/?cl=global_footer_mypage)
    
*   [メール](https://auth.sso.biglobe.ne.jp/mail/?cl=global_footer_mail)
    
*   [会員サポート](https://support.biglobe.ne.jp/?cl=global_footer_support)
    

*   [お問い合わせ](https://www.biglobe.co.jp/inquire)
    
*   [消費税の表示](https://support.biglobe.ne.jp/salestax.html)
    
*   [ウェブアクセシビリティの取り組み](https://support.biglobe.ne.jp/accessibility/)
    
*   [個人情報保護ポリシー](https://www.biglobe.ne.jp/privacy.html)
    
*   [プライバシーポータル](https://www.biglobe.ne.jp/privacy-portal.html)
    
*   [Cookieポリシー](https://www.biglobe.ne.jp/cookie.html)
    
*   [特定商取引法に基づく表記](https://support.biglobe.ne.jp/tokusyo.html)
    
*   [古物営業法に基づく表記](https://support.biglobe.ne.jp/kobutsusyo.html)
    
*   [情報セキュリティ基本方針](https://www.biglobe.co.jp/security)
    
*   [商標について](https://join.biglobe.ne.jp/trademark/)
    
*   [BIGLOBEトップ](https://www.biglobe.ne.jp/)
    

[![プライバシーマーク](https://www.biglobe.ne.jp/images/PrivacyMark.png)](https://privacymark.jp/)

[![セキュリティ認証](https://www.biglobe.ne.jp/images/ISP.png)](https://www.biglobe.ne.jp/safesecurity.html)

[![ETOCマーク](https://www.biglobe.ne.jp/images/ETOC.png)](https://www.etoc.jp/elite/0037)

Copyright ©BIGLOBE Inc. 2025. All rights reserved.
