# ギガプラン | 格安SIM/格安スマホのIIJmio

URL: https://www.iijmio.jp/gigaplan/

---

[![IIJmioロゴ](https://www.iijmio.jp/image/logo.jpg)](https://www.iijmio.jp/)

  

*   [![IPv6接続状態](https://www.iijmio.jp/image/hn_ipv4.gif)](https://www.iijmio.jp/guide/outline/ipv6/icon/)
    

[![メッセージあり](https://www.iijmio.jp/image/message.jpg)](https://www.iijmio.jp/auth/message/welcome/)
 [![ログアウト](https://www.iijmio.jp/image/logout-btn.jpg)](https://www.iijmio.jp/auth/logout/)

[![ログイン](https://www.iijmio.jp/image/login-btn.jpg)](https://www.iijmio.jp/auth/login/)

*   [会員専用ページ](https://www.iijmio.jp/member/)
    
*   [キャンペーン](https://www.iijmio.jp/campaign/)
    
*   [外国人の方 English](https://www.iijmio.jp/hdc/visitors/)
    
*   [取り扱い店舗](https://www.iijmio.jp/hdd/shop/)
    

*     [![料金・プラン](https://www.iijmio.jp/image/global_menu/icon_plan.png) ![料金・プラン](https://www.iijmio.jp/image/global_menu/icon_plan_on.png) 料金プラン](https://www.iijmio.jp/hdc/spec/)
    
*     [![SIM・eSIM](https://www.iijmio.jp/image/global_menu/icon_sim.png) ![SIM・eSIM](https://www.iijmio.jp/image/global_menu/icon_sim_on.png) SIM / eSIM](javascript:void(0);)
    *   ラインアップ
        
        [ギガプラン](https://www.iijmio.jp/gigaplan/)
        
        [ギガプラン 音声eSIM](https://www.iijmio.jp/gigaplan/esim/phone/)
        
        [従量制プラン](https://www.iijmio.jp/juryo.html)
        
        [eSIM（データプラン ゼロ）](https://www.iijmio.jp/esim/)
        
        [えらべるSIMカード](https://www.iijmio.jp/eraberu/)
        
        [プリペイドSIM](https://s.iijmio.jp/prepaid/)
        
        [クーポンカード](https://s.iijmio.jp/couponcard/)
        
        [Japan Travel SIM  \
        （訪日外国人向けSIM）](https://tr.iijmio.jp/)
        
        [BIC SIM](https://bicsim.com/)
        
    *   オプション
        
        [通話定額オプション  \
        （5分、10分、かけ放題）](https://www.iijmio.jp/mobile/voicefree/)
        
        [U-NEXT for スマートシネマ](https://www.iijmio.jp/mop/u-next/)
        
        [オプションサービス](https://www.iijmio.jp/hdd/option/)
        
        [セーフティメールサービス](https://www.iijmio.jp/mm/)
        
    *   ご購入ガイド
        
        [格安SIMガイド](https://www.iijmio.jp/simguide/)
        
        [お申し込みの流れ](https://www.iijmio.jp/hdc/guide/norikae.html)
        
        [データシェア・プレゼント機能とは](https://www.iijmio.jp/gigaplan/dataoption/)
        
        [国際電話](https://www.iijmio.jp/intlcall/)
        
        [動作確認済み端末一覧](https://www.iijmio.jp/hdd/devices/)
        
        [SIM設定手順（APN設定）](https://www.iijmio.jp/hdc/guide/setting/)
        
        [機種変更ガイド](https://www.iijmio.jp/hdc/guide/switch/)
        
        [乗り換えガイド](https://www.iijmio.jp/hdc/guide/norikae.html)
        
*     [![端末・セット](https://www.iijmio.jp/image/global_menu/icon_device.png) ![端末・セット](https://www.iijmio.jp/image/global_menu/icon_device_on.png) 端末セット](javascript:void(0);)
    *   [端末ラインアップ](https://www.iijmio.jp/device/)
        
        [動作確認済み端末](https://www.iijmio.jp/hdd/devices/)
        
        メーカーから探す
        
        [Xiaomi](https://www.iijmio.jp/device/?SearchKeyword=Xiaomi)
        
        [OPPO](https://www.iijmio.jp/device/?SearchKeyword=OPPO)
        
        [motorola](https://www.iijmio.jp/device/?SearchKeyword=motorola)
        
        [Nothing](https://www.iijmio.jp/device/?SearchKeyword=Nothing)
        
        [ASUS](https://www.iijmio.jp/device/?SearchKeyword=ASUS)
        
    *   ブランドから探す
        
        [中古 iPhone＆iPad](https://www.iijmio.jp/device/iphone.html)
        
        [中古 Androidスマホ](https://www.iijmio.jp/device/usedandroid.html)
        
        [arrows](https://www.iijmio.jp/device/?SearchKeyword=arrows)
        
        [AQUOS](https://www.iijmio.jp/device/?SearchKeyword=AQUOS)
        
        [Xperia](https://www.iijmio.jp/device/?SearchKeyword=Xperia)
        
        [nubia](https://www.iijmio.jp/device/?SearchKeyword=nubia)
        
    *   [ノートPC](https://www.iijmio.jp/device/?DeviceType=ntpc)
        
        [SIMフリータブレット](https://www.iijmio.jp/device/?DeviceType=t)
        
        [IoT機器](https://www.iijmio.jp/device/?DeviceType=i)
        
        [WiFiルータ](https://www.iijmio.jp/device/?DeviceType=r&DeviceType2=hikari)
        
        その他
        
        [端末補償（IIJmioで新品端末購入）](https://www.iijmio.jp/device/option/)
        
        [端末補償（IIJmioで中古端末購入）](https://www.iijmio.jp/device/option/used.html)
        
        [端末保証（お手持ちのスマホ対象）](https://www.iijmio.jp/hdd/option/tsunagaru/)
        
*     [![mioひかり](https://www.iijmio.jp/image/global_menu/icon_hikari.png) ![SIM・eSIM](https://www.iijmio.jp/image/global_menu/icon_hikari_on.png) mioひかり](https://www.iijmio.jp/imh/)
    
*     [![サポート・取扱店舗](https://www.iijmio.jp/image/global_menu/icon_sup.png) ![サポート・取扱店舗](https://www.iijmio.jp/image/global_menu/icon_sup_on.png) サポート  \
    FAQ](javascript:void(0);)
    *   [FAQホーム](https://help.iijmio.jp/)
        
        [お問い合わせ](https://www.iijmio.jp/contact.html)
        
          
        
        ご購入ガイド
        
        [SIM設定手順（APN設定）](https://www.iijmio.jp/hdc/guide/setting/)
        
        [機種変更ガイド](https://www.iijmio.jp/hdc/guide/switch/)
        
        [乗り換えガイド](https://www.iijmio.jp/hdc/guide/norikae.html)
        
*     [![法人の客様](https://www.iijmio.jp/image/global_menu/icon_biz.png) ![法人の客様](https://www.iijmio.jp/image/global_menu/icon_biz_on.png) 法人のお客様](https://www.iijmio.jp/biz/)
    
*   [![ご購入・お申し込み](https://www.iijmio.jp/image/sr-nav6.jpg)](https://www.iijmio.jp/mobile/signup/)
    

[![IIJmio](https://www.iijmio.jp/image/header-logo.png)](https://www.iijmio.jp/)
 [English](https://www.iijmio.jp/hdc/visitors/)

[![IPv6接続状態](https://www.iijmio.jp/image/hn_ipv4.gif)](https://www.iijmio.jp/guide/outline/ipv6/icon/)

[![法人のお客様](https://www.iijmio.jp/image/biz-icon_sp.png)法人の  \
お客様](https://www.iijmio.jp/biz/)

[![会員専用ページ](https://www.iijmio.jp/image/icon_member.png)会員専用  \
ページ](https://www.iijmio.jp/member/)

[![キャンペーン](https://www.iijmio.jp/image/icon_campaign.png)キャンペーン](https://www.iijmio.jp/campaign/)

[![取り扱い店舗](https://www.iijmio.jp/image/icon_store.png)取り扱い  \
店舗](https://www.iijmio.jp/hdd/shop/)

![SIM/eSIM](https://www.iijmio.jp/image/icon_sim2.png)

SIM/eSIM

月額サービス

*   [ギガプラン](https://www.iijmio.jp/gigaplan/)
    
*   [ギガプラン 音声eSIM](https://www.iijmio.jp/gigaplan/esim/phone/)
    
*   [従量制プラン](https://www.iijmio.jp/juryo.html)
    
*   [えらべるSIMカード](https://www.iijmio.jp/eraberu/)
    
*   [BIC SIM](https://bicsim.com/)
    

その他サービス

*   [プリペイドSIM](https://s.iijmio.jp/prepaid/)
    
*   [クーポンカード](https://s.iijmio.jp/couponcard/)
    
*   [Japan Travel SIM  \
    (訪日外国人向けSIM)](https://tr.iijmio.jp/)
    
*   [通話定額オプション  \
    (5分、10分、かけ放題)](https://www.iijmio.jp/mobile/voicefree/)
    
*   [U-NEXT for スマートシネマ](https://www.iijmio.jp/mop/u-next/)
    
*   [オプションサービス](https://www.iijmio.jp/hdd/option/)
    

お役立ちガイド

*   [格安SIMガイド](https://www.iijmio.jp/simguide/)
    
*   [お申し込みの流れ  \
    (事前準備～初期設定)](https://www.iijmio.jp/hdc/guide/)
    
*   [データシェアとは](https://www.iijmio.jp/gigaplan/dataoption/)
    
*   [データプレゼントとは](https://www.iijmio.jp/gigaplan/dataoption/?id=tab2)
    
*   [国際電話](https://www.iijmio.jp/intlcall/)
    
*   [動作確認済み端末一覧](https://www.iijmio.jp/hdd/devices/)
    

![サポート/FAQ](https://www.iijmio.jp/image/icon_support.png)

サポート/FAQ

*   [FAQホーム](https://help.iijmio.jp/)
    
*   [お問い合わせ](https://www.iijmio.jp/contact.html)
    
*   [SIM 設定手順  \
    (APN設定)](https://www.iijmio.jp/hdc/guide/setting/)
    
*   [機種変更ガイド](https://www.iijmio.jp/hdc/guide/switch/)
    
*   [乗り換えガイド](https://www.iijmio.jp/hdc/guide/norikae.html)
    

*   [![料金](https://www.iijmio.jp/image/icon_price2.png)\
    \
    料金](https://www.iijmio.jp/hdc/spec/)
    
*   [![SIM/eSIM](https://www.iijmio.jp/image/icon_sim2.png)\
    \
    SIM/eSIM](https://www.iijmio.jp/gigaplan/#sim-esim)
    
*   [![端末](https://www.iijmio.jp/image/icon_set.png)\
    \
    端末](https://www.iijmio.jp/device/)
    
*   [![mioひかり](https://www.iijmio.jp/image/icon_imh.png)\
    \
    mioひかり](https://www.iijmio.jp/imh/)
    
*   [![サポート](https://www.iijmio.jp/image/icon_support.png)\
    \
    サポート](https://www.iijmio.jp/gigaplan/#support-shop)
    

[ホーム](https://www.iijmio.jp/)
![　](https://www.iijmio.jp/image/list.gif)

ギガプラン

※1,2

※3

![IIJmioモバイルサービス ギガプラン](https://www.iijmio.jp/gigaplan/img/main_sp.png) ![IIJmioモバイルサービス ギガプラン](https://www.iijmio.jp/gigaplan/img/main_sp.png) 

![IIJmioモバイルサービス ギガプラン](https://www.iijmio.jp/gigaplan/img/main_sp.png)

*   [![](https://www.iijmio.jp/gigaplan/img/icon_price.png)料金](https://www.iijmio.jp/gigaplan/#simplan)
    
*   [![](https://www.iijmio.jp/gigaplan/img/icon_feature.png)特長](https://www.iijmio.jp/gigaplan/#combination)
    
*   [![](https://www.iijmio.jp/gigaplan/img/icon_share.png)\
    \
    データシェア  \
    /プレゼント](https://www.iijmio.jp/gigaplan/#data_share_detail_link)
    
*   [![](https://www.iijmio.jp/gigaplan/img/icon_esim_nav.png)eSIM](https://www.iijmio.jp/gigaplan/esim/)
    
*   [![](https://www.iijmio.jp/gigaplan/img/icon_step.png)申込の流れ](https://www.iijmio.jp/gigaplan/#inc_step)
    
*   [![](https://www.iijmio.jp/gigaplan/img/icon_qa.png)Q&A](https://www.iijmio.jp/gigaplan/#gigaplan_qa)
    

*   15ギガプラン1,800円に本キャンペーン(10GBデータ増量・月額900円割引・通話定額オプション割引)を適用した場合。初月のデータ量・料金は、利用開始日ごとに異なります。
*   0570（ナビダイヤル）への特番通話、国際電話などは対象外です。定額時間を超過した場合、11円／30秒の通話料が別途かかります。
*   15ギガプランをお申し込みの場合。増量するデータ量と割引金額はプランによって異なります。

＼eSIMの申し込みならおトク！／  
初期費用が1,100円割引！

 [![ご購入・お申込みはこちら](https://www.iijmio.jp/gigaplan/img/btn.png) ![ご購入・お申込みはこちら](https://www.iijmio.jp/gigaplan/img/btn_sp.png)](https://www.iijmio.jp/mobile/signup/)

[キャンペーン概要](https://www.iijmio.jp/gigaplan/#otoku_gaiyo)
をご確認の上、お申し込みください。

※eSIM初期費用割引キャンペーンは、音声eSIM・データeSIMの申込につきそれぞれ1契約者様（mioID）あたり1回までの適用です。

 [![ご購入・お申込みはこちら](https://www.iijmio.jp/gigaplan/img/btn.png) ![ご購入・お申込みはこちら](https://www.iijmio.jp/gigaplan/img/btn_sp.png)](https://www.iijmio.jp/mobile/signup/)

[キャンペーン概要](https://www.iijmio.jp/gigaplan/#otoku_gaiyo)
をご確認の上、お申し込みください。

※eSIM初期費用割引キャンペーンは、音声eSIM・データeSIMの申込につきそれぞれ1契約者様（mioID）あたり1回までの適用です。   [![IIJmio x mouse 限定特典](https://www.iijmio.jp/gigaplan/img/mouse/main_id_tieup.png) ![IIJmio x mouse 限定特典](https://www.iijmio.jp/gigaplan/img/mouse/main_id_tieup_sp.png)](https://www.iijmio.jp/gigaplan/#otoku_gaiyo)
[![ご購入・お申込みはこちら](https://www.iijmio.jp/gigaplan/img/btn.png) ![ご購入・お申込みはこちら](https://www.iijmio.jp/gigaplan/img/btn_sp.png)](https://www.iijmio.jp/mobile/signup/)

[キャンペーン概要](https://www.iijmio.jp/gigaplan/#otoku_gaiyo)
をご確認の上、お申し込みください。  
※データeSIMは除く。

キャンペーン期間
--------

2025年11月21日（金）2025年12月1日（月）～終了日時未定

※本キャンペーンの内容は予告なく変更または終了する場合があります。

※eSIM初期費用割引キャンペーンは2026年1月21日23:59までです。

キャンペーン中

新たに申し込み

キャンペーン中

旧プラン※から変更

通常料金

![](https://www.iijmio.jp/gigaplan/img/voice-icon.png)

音声SIM

![](https://www.iijmio.jp/gigaplan/esim/phone/img/voice-esim-icon.png)

音声eSIM

他社から乗り換え（音声）  
※新しく電話番号を取得する場合もこちら

月額割引＆データ増量キャンペーン実施中！

音声月額料金

|     | 1回線でご利用  <br>（通常価格） | 2回線以上ご利用で  <br>家族割引-100円 |
| --- | --- | --- |
| 2ギガ | 税込850円 | 税込750円 |
| 5ギガ | 月額料金 150円割引 最大3ヵ月間<br><br>税込950円<br><br>税込800円 | 税込850円<br><br>税込700円 |
| 10ギガ | 月額料金 150円割引 最大3ヵ月間<br><br>税込1,400円<br><br>税込1,250円 | 税込1,300円<br><br>税込1,150円 |
| 10GBデータ増量 最大3ヵ月間<br><br>15ギガ<br><br>25ギガ | 月額料金 900円割引 最大3ヵ月間<br><br>税込1,800円<br><br>税込900円 | 税込1,700円<br><br>税込800円 |
| 25ギガ<br><br>35ギガ | 税込2,000円 | 税込1,900円 |
| 35ギガ<br><br>45ギガ | 税込2,400円 | 税込2,300円 |
| 45ギガ<br><br>55ギガ | 税込3,300円 | 税込3,200円 |
| 55ギガ<br><br>65ギガ | 税込3,900円 | 税込3,800円 |

ご利用開始月のプラン月額料金・データ量は日割りとなります。

![](https://www.iijmio.jp/mobile/voicefree/img/icon_tel.png) 通話定額  
オプション

通話定額割引

通話定額5分+

税込500円

0円

最大3ヵ月間

通話定額10分+

税込700円

0円

最大3ヵ月間

かけ放題+

税込1,400円

0円

最大3ヵ月間

[通話定額](https://www.iijmio.jp/mobile/voicefree/)

オプションなしでもおトク！  
家族の通話料が20％OFF！※1

U-NEXT for スマートシネマとギガプランがセットで 220円割引！ [詳しくはこちら](https://www.iijmio.jp/mop/u-next/)

IIJmioひかりとセットで660円割引！【mio割】※2 ※3

[![IIJmioひかり キャンペーン](https://www.iijmio.jp/imh/img/bnr_hikaricp_pc.png)](https://www.iijmio.jp/campaign/imh/hikaricp.html)

|     | ![](https://www.iijmio.jp/gigaplan/img/esim-icon.png)<br><br>データeSIM<br><br>ドコモ網のみ | ![](https://www.iijmio.jp/gigaplan/img/data-icon.png)<br><br>データ<br><br>タイプDのみ | ![](https://www.iijmio.jp/gigaplan/img/sms-icon.png)<br><br>SMS |
| --- | --- | --- | --- |
| 2ギガ | 税込440円 | 税込740円 | 税込820円 |
| 5ギガ | 税込650円 | 税込860円 | 税込930円 |
| 10ギガ | 税込1,050円 | 税込1,300円 | 税込1,370円 |
| 15ギガ | 税込1,430円 | 税込1,730円 | 税込1,780円 |
| 25ギガ | 税込1,650円 | 税込1,950円 | 税込1,980円 |
| 35ギガ | 税込2,240円 | 税込2,340円 | 税込2,380円 |
| 45ギガ | 税込2,940円 | 税込3,240円 | 税込3,280円 |
| 55ギガ | 税込3,540円 | 税込3,840円 | 税込3,880円 |

ご利用開始月のプラン月額料金・データ量は日割りとなります。

*   ※別途、020番号(M2M等専用番号)を除き[ユニバーサルサービス料](https://www.iijmio.jp/hdd/care/universal.html)
    、[電話リレーサービス料](https://www.iijmio.jp/hdd/care/telephonerelay.html)
    がSIMカードごとに加算されます。SIMカードごとに、ユニバーサルサービス料は利用開始月の翌月、電話リレーサービス料は利用開始月の当月より請求いたします。
*   ※ミニマムスタートプラン・ライトスタートプラン・ファミリーシェアプラン等の月額料金については、[こちら](https://www.iijmio.jp/hdd/spec/)
    をご確認ください。
*   ※利用開始月の月額料金とデータ量は日割となります。また、解約希望日にかかわらず解約月の月末までの料金が発生します。
*   ※音声の月額料金に、通話料金は含まれておりません。
*   ※[IIJmio eSIMサービス（データプラン ゼロ）](https://www.iijmio.jp/esim/)
    へのお申し込みも可能です。

*   ※1 同一のmioID内でご契約中の音声通話SIM同士で通話する場合に適用されます。日本国内から発信する通話のみに限ります。国際ローミング時は適用されません。
*   ※2 IIJmioのSIMサービスをご利用の方がIIJmioひかりもご利用いただくと[mio割](https://www.iijmio.jp/imh/miowari.html)
    が適用され、IIJmioひかりの月額料金から毎月税込660円割引されます。mio割はIIJmioひかりとIIJmioのSIMサービスそれぞれ1契約ずつを1セットとして、セットごとに適用となります。（IIJmioひかりを1契約、IIJmioのSIMサービスを2契約の場合、適用されるmio割は1セット分です。また、IIJmioひかりを2契約、IIJmioのSIMサービスを2契約の場合、適用されるmio割は2セット分です。）
*   ※3 別途IIJmioひかりの月額料金がかかります。IIJmioのSIMサービスとIIJmioひかりの利用開始日が異なる場合、月の請求額が記載の実質負担金額とならない場合がございます。

 [![U-NEXT for スマートシネマ](https://www.iijmio.jp/image/banner/bnr_u-next_sp.png) ![U-NEXT for スマートシネマ](https://www.iijmio.jp/image/banner/bnr_u-next.png)](https://www.iijmio.jp/mop/u-next/)

 [![U-NEXT for スマートシネマ](https://www.iijmio.jp/image/banner/bnr_u-next_sp.png) ![U-NEXT for スマートシネマ](https://www.iijmio.jp/image/banner/bnr_u-next.png)](https://www.iijmio.jp/mop/u-next/)

初期費用
----

eSIM限定 初期費用割引！  
（2026年1月21日まで）

![](https://www.iijmio.jp/gigaplan/img/icon_voice_esim.png)音声eSIM

税込3,300円  
税込2,200円

![](https://www.iijmio.jp/gigaplan/img/voice-icon.png)音声SIM

![](https://www.iijmio.jp/gigaplan/img/sms-icon.png)SMS SIM

![](https://www.iijmio.jp/gigaplan/img/data-icon.png)データ SIM  
タイプDのみ

税込3,300円

eSIM限定 初期費用割引！  
（2026年1月21日まで）

![](https://www.iijmio.jp/gigaplan/img/icon_voice_esim.png)音声eSIM

![](https://www.iijmio.jp/gigaplan/img/esim-icon.png)データeSIM  
ドコモ網のみ

キャンペーン実施中！

税込3,300円  
税込2,200円

![](https://www.iijmio.jp/gigaplan/img/voice-icon.png)音声SIM

![](https://www.iijmio.jp/gigaplan/img/sms-icon.png)SMS SIM

![](https://www.iijmio.jp/gigaplan/img/data-icon.png)データ SIM  
タイプDのみ

税込3,300円

eSIM限定 初期費用割引！  
（2026年1月21日まで）

![](https://www.iijmio.jp/gigaplan/img/icon_voice_esim.png)音声eSIM

![](https://www.iijmio.jp/gigaplan/img/esim-icon.png)データeSIM  
ドコモ網のみ

キャンペーン実施中！

税込3,300円  
税込2,200円

*   ※eSIMの新規お申し込み時に限り、初期費用を1,100円割引します。キャンペーン適用は音声eSIM・データeSIMのお申込につきそれぞれ1契約者様（mioID）あたり1回までとなります。
*   ※既にIIJmioモバイルサービスをご利用中の方が、プラン変更にてギガプランへ変更する場合、初期費用は発生しません。 プラン変更詳細は[こちら](https://www.iijmio.jp/gigaplan/#miouser)
    をご覧ください。 プラン変更詳細は[こちら](https://www.iijmio.jp/gigaplan/#miouser)
    をご覧ください。

eSIM初期費用割引キャンペーン

### 

eSIM初期費用割引キャンペーン

|     |     |
| --- | --- |
| 受付期間 | 2025年11月21日～2026年1月21日 23時59分まで  <br>※本キャンペーンは予告なく終了する場合があります。 |
| 適用条件 | 以下に定める条件をすべて満たしたお客様が適用対象となります。  <br><br>*   受付期間中にIIJmioのWEBサイトから、IIJmioモバイルサービス ギガプランを「音声eSIM」または「データeSIM」を新規お申し込みいただくこと<br>*   お申し込み完了後、回線をご利用開始いただくこと |
| 特典内容 | 適用条件をすべて満たした場合に次の特典を提供します。  <br>  <br>初期費用割引特典：初期費用から1,100円(税込)を割引します  <br>※IIJmioギガプランのeSIM以外（音声SIMカード/SMS回線/データ回線）をお申し込みの場合、割引は適用されません。 |
| 注意事項 | *   本キャンペーンは音声eSIMとデータeSIM回線がそれぞれ「お一人様（mioID）あたり1回線まで」の適用です。<br>*   受付期間中のお申し込みの場合、ご利用開始（もしくはeSIMプロファイルの到着）がキャンペーン期間外でも適用対象です。<br>*   以下のいずれかに該当するお申し込みは本キャンペーンの対象外となります。  <br>    1)IIJmioのWEBサイトを経由せずに音声eSIMまたはデータeSIMをお申し込みいただいた場合  <br>    2)受付期間中に音声eSIMで本キャンペーン適用済みの方が、2回線目以降音声eSIMをお申し込みいただく場合  <br>    3)受付期間中にデータeSIMで本キャンペーン適用済みの方が、2回線目以降データeSIMをお申し込みいただく場合  <br>    4)家電量販店やネットショップなどで購入したパッケージ（エントリーコード・パスコード）を利用してのお申し込みの場合<br>*   当社とのお取引関係上、著しく問題があったお客様には、特典の適用をお断りする場合があります。<br>*   契約いただく場合には別途SIMプロファイル発行手数料が必要です。  <br>    \-音声eSIM タイプD：433.4円  <br>    \-音声eSIM タイプA／データeSIM：220円 |

eSIM初期費用割引キャンペーン

### 

eSIM初期費用割引キャンペーン

|     |     |
| --- | --- |
| 受付期間 | 2025年12月1日～2026年1月21日 23時59分まで  <br>※本キャンペーンは予告なく終了する場合があります。 |
| 適用条件 | 以下に定める条件をすべて満たしたお客様が適用対象となります。  <br><br>*   受付期間中にIIJmioのWEBサイトから、IIJmioモバイルサービス ギガプランを「音声eSIM」または「データeSIM」を新規お申し込みいただくこと<br>*   お申し込み完了後、回線をご利用開始いただくこと |
| 特典内容 | 適用条件をすべて満たした場合に次の特典を提供します。  <br>  <br>初期費用割引特典：初期費用から1,100円(税込)を割引します  <br>※IIJmioギガプランのeSIM以外（音声SIMカード/SMS回線/データ回線）をお申し込みの場合、割引は適用されません。 |
| 注意事項 | *   本キャンペーンは音声eSIMとデータeSIM回線がそれぞれ「お一人様（mioID）あたり1回線まで」の適用です。<br>*   受付期間中のお申し込みの場合、ご利用開始（もしくはeSIMプロファイルの到着）がキャンペーン期間外でも適用対象です。<br>*   以下のいずれかに該当するお申し込みは本キャンペーンの対象外となります。  <br>    1)IIJmioのWEBサイトを経由せずに音声eSIMまたはデータeSIMをお申し込みいただいた場合  <br>    2)受付期間中に音声eSIMで本キャンペーン適用済みの方が、2回線目以降音声eSIMをお申し込みいただく場合  <br>    3)受付期間中にデータeSIMで本キャンペーン適用済みの方が、2回線目以降データeSIMをお申し込みいただく場合  <br>    4)家電量販店やネットショップなどで購入したパッケージ（エントリーコード・パスコード）を利用してのお申し込みの場合<br>*   当社とのお取引関係上、著しく問題があったお客様には、特典の適用をお断りする場合があります。<br>*   契約いただく場合には別途SIMプロファイル発行手数料が必要です。  <br>    \-音声eSIM タイプD：433.4円  <br>    \-音声eSIM タイプA／データeSIM：220円 |

[ご利用料金詳細はこちら](https://www.iijmio.jp/hdc/spec/)

基本仕様

提供回線

ドコモ網（タイプD）/au網（タイプA）

SIMカード/  
SIMプロファイル

1枚

*   ・本プランでは、SIMカード/SIMプロファイルの追加はできません。複数SIMをご契約いただき、データシェア機能を利用することで、複数枚でのデータ容量シェアが出来ます。
  
*   【タイプＤの場合】NTTドコモの5G、LTE(4G)及び3G網に対応したSIMカード、またはSIMプロファイルを提供します。
*   【タイプAの場合】auの5G及び4G LTE網に対応したSIMカード、またはSIMプロファイルを提供します。
*   【データeSIMの場合】NTTドコモの4G（LTE）/3G網に対応したSIMプロファイルを提供します。

データ容量

2ギガプラン/5ギガプラン/10ギガプラン/15ギガプラン/25ギガプラン/  
35ギガプラン/45ギガプラン/55ギガプラン

*   ・有効期限はデータ容量が付与された月の翌月末日までです。
*   ・利用開始月のみ、日割での付与となります。

データ容量超過後の通信速度

最大300kbps ※データ容量を利用したくないときに、高速データ通信OFFした場合、こちらの速度で利用可能です。

通信規制

最直近3日間あたり低速通信利用で366MB超過時は速度規制がかかります

音声契約条件

期間拘束条件なし・音声通話機能解除調定金0円・MNP転出手数料0円

最低利用期間

利用開始月の翌月末日まで

プラン変更  
（データ容量の変更）

無料

*   ・プラン変更は、翌月1日より適用となります。毎月末日は申し込み受付を停止します。

データ容量シェア機能

無料

*   ・同一mioID内でのギガプランのみ最大10回線までデータ容量をシェアすることができます。

データ容量プレゼント機能

無料

*   ・同一mioID内での別回線へデータ容量を移すことができます。

5Gオプション

無料

*   ※データeSIM、SMS機能付きSIM(タイプD)ではご利用いただけません。

ギガプラン専用追加データ量

1ギガ 税込220円

My IIJmio  
（ギガプラン専用アプリ）

無料

*   ・データ残量照会、利用量確認、データ容量の高速通信ON/OFFなど照会できます。

＼eSIMの申し込みならおトク！／  
初期費用が1,100円割引！

 [![ご購入・お申込みはこちら](https://www.iijmio.jp/gigaplan/img/btn.png) ![ご購入・お申込みはこちら](https://www.iijmio.jp/gigaplan/img/btn_sp.png)](https://www.iijmio.jp/mobile/signup/)

[キャンペーン概要](https://www.iijmio.jp/gigaplan/#otoku_gaiyo)
 をご確認の上、お申し込みください。

 [![ご購入・お申込みはこちら](https://www.iijmio.jp/gigaplan/img/btn_end.png) ![ご購入・お申込みはこちら](https://www.iijmio.jp/gigaplan/img/btn_end_sp.png)](https://www.iijmio.jp/mobile/signup/)

[キャンペーン概要](https://www.iijmio.jp/gigaplan/#otoku_gaiyo)
 をご確認の上、お申し込みください。

かけ放題がついても  
こんなにおトク！
--------------------

[](https://www.iijmio.jp/mobile/voicefree/)

![](https://www.iijmio.jp/mobile/voicefree/img/men.png)

かけ放題プランも自由に選べる！  
専用アプリ不要！標準電話アプリからの発信で通話オプション対象！
-------------------------------------------------

![](https://www.iijmio.jp/mobile/voicefree/img/girl.png)

### 通話定額5分+

1回5分以内の  
国内通話無料 税込500円

0円

最大3ヵ月間

### 通話定額10分+

1回10分以内の  
国内通話無料 税込700円

0円

最大3ヵ月間

### かけ放題+

無制限で  
国内通話無料 税込1,400円

0円

最大3ヵ月間

通話定額オプション割引キャンペーン

![選べる通話オプション](https://www.iijmio.jp/mobile/voicefree/img/eraberu_option_obi.png)

[![詳しい料金表はこちら](https://www.iijmio.jp/gigaplan/img/price-linkbtn.png)](https://www.iijmio.jp/hdc/spec/)

[![既存プランと新プラン（ギガプラン）の料金比較](https://www.iijmio.jp/gigaplan/img/gigaplan-spec-linkbtn.png)](https://www.iijmio.jp/gigaplan/hikaku.html)

本タイアップサイト限定特典で

＼eSIMの申し込みならおトク！／  
初期費用が1,100円割引！

 [![ご購入・お申込みはこちら](https://www.iijmio.jp/gigaplan/img/btn.png) ![ご購入・お申込みはこちら](https://www.iijmio.jp/gigaplan/img/btn_sp.png)](https://www.iijmio.jp/mobile/signup/)

[キャンペーン概要](https://www.iijmio.jp/gigaplan/#otoku_gaiyo)
 をご確認の上、お申し込みください。

 [![ご購入・お申込みはこちら](https://www.iijmio.jp/gigaplan/img/btn.png) ![ご購入・お申込みはこちら](https://www.iijmio.jp/gigaplan/img/btn_sp.png)](https://www.iijmio.jp/mobile/signup/)

[キャンペーン概要](https://www.iijmio.jp/gigaplan/#otoku_gaiyo)
 をご確認の上、お申し込みください。

  

[![ギガプランシュミレーター](https://www.iijmio.jp/gigaplan/img/gigaSimulator2/btn_simulation.png)](https://www.iijmio.jp/gigaplan/#giga_simulator)

![料金プランかんたん診断](https://www.iijmio.jp/gigaplan/img/gigaSimulator2/title_pc.png) ![料金プランかんたん診断](https://www.iijmio.jp/gigaplan/img/gigaSimulator2/title_sp.png)

最大6つの質問に答えるだけで、  
あなたにピッタリな料金プランをご提案！

診断開始

Q

U-NEXT for スマートシネマを申し込みますか？

申し込む

申し込まない

Q

電話番号（090等）は必要ですか？

必要

（お乗り換えの方はこちら）

不要

Q

他社からのりかえでの申し込みですか？

のりかえ（MNP）

新規（新たに電話番号を取得）

Q

ご利用になるSIMの形状を教えてください

SIMカード

（カード型）

eSIM※

※eSIMご利用にはeSIM対応機種が必要です。  
未対応の場合はご利用できませんので、「SIMカード」を選択してください。

[![音声eSIMとは？](https://www.iijmio.jp/gigaplan/img/gigaSimulator2/voiceesim_btn.png)](https://www.iijmio.jp/gigaplan/esim/phone/)

Q

通話定額を使いますか？

セール

通話定額5分+

1回5分以内の国内通話無料

税込500円

0円

セール

通話定額10分+

1回10分以内の国内通話無料

税込700円

0円

セール

かけ放題+

無制限で国内通話無料

税込1,400円

0円

通話定額は使わない

Q

SMSを使いますか？

SMSを使う

SMSは使わない

Q

データeSIMを使いますか？

データeSIMを使う

データeSIMは使わない

[![データeSIMとは？](https://www.iijmio.jp/gigaplan/img/gigaSimulator2/esim_btn.png)](https://www.iijmio.jp/simguide/esim/)

Q

データ通信は毎月どのくらいご利用ですか？

家のWi-Fi利用が中心  
外出先でネットはあまり使わない

オススメ!

外出先のSNS利用やネット閲覧が中心

外出先でゲームアプリを使う

外出先で動画を視聴しネットもよく使う

通勤・通学時間などで動画をよく視聴する

25GBだと毎月不足気味

テザリングをよく使う（タブレットやPCなどと接続）

おうちのWi-Fiが無くてもギガを気にせず使いたい

Q

スマホもセットで申し込みますか？

スマホもセットで申し込む

回線のみ申し込む

Q

U-NEXT for スマートシネマを申し込みますか？

申し込む

申し込まない

Q

電話番号（090等）は必要ですか？

必要

（お乗り換えの方はこちら）

不要

前の設問にもどる

![診断結果](https://www.iijmio.jp/gigaplan/img/gigaSimulator2/diagnosis_title_pc.png) ![診断結果](https://www.iijmio.jp/gigaplan/img/gigaSimulator2/diagnosis_title_sp.png)

診断結果をすべて削除

IIJmioのご契約は最大10回線までです。  
追加で診断を行う場合は「診断結果の内訳」欄からプランを削除してください。

1回線目を診断する

 [![ご購入・お申込みはこちら](https://www.iijmio.jp/gigaplan/img/btn.png) ![ご購入・お申込みはこちら](https://www.iijmio.jp/gigaplan/img/btn_sp.png)](https://www.iijmio.jp/mobile/signup/)

※上記費用には、SIMカード発行手数料、ユニバーサルサービス料、電話リレーサービス料は含まれておりません。

※消費税の端数処理により実際の請求額が異なる場合があります。

※シミュレーション結果は目安です。ご契約条件やご請求額を保証するものではありませんので、あらかじめご了承の上ご利用ください。

 [![IIJmioひかり キャンペーン](https://www.iijmio.jp/imh/img/bnr_hikaricp_pc.png) ![IIJmioひかり キャンペーン](https://www.iijmio.jp/imh/img/bnr_hikaricp_sp.png)](https://www.iijmio.jp/campaign/imh/hikaricp.html)

選べる「自由」な組み合わせ

使いたい機能に応じて「SIMの機能」と「データ量」を自由に組み合わせ  
回線もドコモ網・au網から選択可能。

![選べる「自由」な組み合わせ画像](https://www.iijmio.jp/gigaplan/img/eraberu_gb_plan.png)

組み合わせの例

![例1](https://www.iijmio.jp/gigaplan/img/example1.png) 音声通話がメインで、ネットもWi-Fiが中心。

![](https://www.iijmio.jp/gigaplan/img/example_1_hito.png)

![5ギガ](https://www.iijmio.jp/image/5gb-icon.png)

![音声SIM](https://www.iijmio.jp/image/voice-icon.png)

\=

950

(税込)

円/月

5ギガ / 音声SIM

![例2](https://www.iijmio.jp/gigaplan/img/example2.png) 外出先でもタブレットでネットを使いたい。

![](https://www.iijmio.jp/gigaplan/img/example_2_hito.png)

![2ギガ](https://www.iijmio.jp/image/2gb-icon.png)

![データeSIM](https://www.iijmio.jp/image/esim-icon.png)

\=

440

(税込)

円/月

2ギガ / データeSIM

本タイアップサイト限定特典で

＼eSIMの申し込みならおトク！／  
初期費用が1,100円割引！

 [![ご購入・お申込みはこちら](https://www.iijmio.jp/gigaplan/img/btn.png) ![ご購入・お申込みはこちら](https://www.iijmio.jp/gigaplan/img/btn_sp.png)](https://www.iijmio.jp/mobile/signup/)

[キャンペーン概要](https://www.iijmio.jp/gigaplan/#otoku_gaiyo)
 をご確認の上、お申し込みください。

 [![ご購入・お申込みはこちら](https://www.iijmio.jp/gigaplan/img/btn.png) ![ご購入・お申込みはこちら](https://www.iijmio.jp/gigaplan/img/btn_sp.png)](https://www.iijmio.jp/mobile/signup/)

[キャンペーン概要](https://www.iijmio.jp/gigaplan/#otoku_gaiyo)
 をご確認の上、お申し込みください。

 [![ご購入・お申込みはこちら](https://www.iijmio.jp/gigaplan/img/btn.png) ![ご購入・お申込みはこちら](https://www.iijmio.jp/gigaplan/img/btn_sp.png)](https://www.iijmio.jp/mobile/signup/)

[キャンペーン概要](https://www.iijmio.jp/gigaplan/#otoku_gaiyo)
 をご確認の上、お申し込みください。

データ量を無駄なく使える
------------

### 余ったデータ量は無駄なく  
翌月繰り越しが可能！

![翌月にプラス！無くなっても1ギガ220円で追加可能](https://www.iijmio.jp/gigaplan/img/data-share-1.png)

### 機能やデータ量が違っても  
データシェアが可能！

![家族みんなのデータ量を分け合える](https://www.iijmio.jp/gigaplan/img/data-share-2.png)

![IIJmioだけ](https://www.iijmio.jp/gigaplan/img/only_iijmio_sp.png)

![IIJmioだけ](https://www.iijmio.jp/gigaplan/img/only_iijmio.png)データ容量シェア＆データ容量プレゼントとは？
-------------------------------------------------------------------------------------

![データ容量シェア＆データ容量プレゼントとは？](https://www.iijmio.jp/gigaplan/img/img_datashare.png) [詳しくはこちら](https://www.iijmio.jp/gigaplan/dataoption/)

![IIJmioだけ](https://www.iijmio.jp/gigaplan/img/only_iijmio_sp.png)

![IIJmioだけ](https://www.iijmio.jp/gigaplan/img/only_iijmio.png)データシェア機能でデータ量を無駄なく使える！  
ライフスタイルに合わせて様々な使い方ができるデータシェア
--------------------------------------------------------------------------------------------------------------------

![ライフスタイルに合わせて様々な使い方ができるデータシェア](https://www.iijmio.jp/gigaplan/dataoption/img/case.png) ![ライフスタイルに合わせて様々な使い方ができるデータシェア](https://www.iijmio.jp/gigaplan/dataoption/img/case_sp.png)

### 「シンプル」な料金設定

![1回線目からお得ですっと同じ料金の「シンプル」な料金設定](https://www.iijmio.jp/gigaplan/img/price-setting.png)

### 大容量のギガも選べる

![大容量プラン](https://www.iijmio.jp/gigaplan/img/large_capa_icon.png)

動画もゲームも思い切り楽しみたい人も安心。  
大容量の55GBなども選べる！

### 5G無料

![5Gが使える](https://www.iijmio.jp/gigaplan/img/price-5g.png) ![5Gが使える](https://www.iijmio.jp/gigaplan/img/price-5g-sp.png)

5G通信と4G通信のON/OFF切替が可能。  
※データeSIMとSMS SIM（タイプD）は5G非対応です。  
[詳細はこちら](https://www.iijmio.jp/mobile/5g/)

IIJmioご愛顧感謝特典
-------------

![IIJmioご愛顧感謝特典](https://www.iijmio.jp/goaiko/img/benefits_main.png) ![IIJmioご愛顧感謝特典](https://www.iijmio.jp/goaiko/img/benefits_main_sp.png)

### mio優待券

2024年6月21日開始

#### スマホ割引券プレゼント！

ご契約内容に応じて、スマホ割引券（mio優待券）をプレゼント！  
端末単体での購入時にご利用が可能です。

![スマホ割引](https://www.iijmio.jp/goaiko/img/tokuten1.png)

### 家族割引

2024年10月1日開始

#### 音声回線利用で月額割引！

ギガプランの音声SIM/音声eSIMが対象！  
複数回線ご利用で、1回線あたり月額100円割引します。

![音声回線利用で月額割引！](https://www.iijmio.jp/goaiko/img/tokuten2.png)

### mio長特  
（長期利用特典）

2025年1月23日開始

#### ご契約期間に応じて、  
おトクな特典をプレゼント！

データ量や各種手数料割引など特典をプレゼント！  
特典は今後も追加予定！

![ご契約期間に応じて、おトクな特典をプレゼント！](https://www.iijmio.jp/goaiko/img/tokuten3.png)

[ご愛顧感謝特典の詳細はこちら](https://www.iijmio.jp/goaiko/)

ギガプランをご利用中の方へ  
IIJmioご愛顧感謝特典

mio優待券
------

2024年6月21日開始

### スマホ割引券プレゼント！

ご契約内容に応じて、スマホ割引券（mio優待券）を  
プレゼント！  
端末単体での購入時にご利用が可能です。

![スマホ割引](https://www.iijmio.jp/goaiko/img/tokuten1.png)

![例えばこんな使い方](https://www.iijmio.jp/goaiko/img/ex_howto_tag.png)

![お子様のスマホ購入](https://www.iijmio.jp/goaiko/img/ex_howto1.png)

#### お子様のスマホ購入

スマホ単体で購入するときに利用できるので、  
お子様のスマホを購入するときにおトクにご購入いただけます。

家族割引
----

2024年10月1日開始

### 音声回線利用で月額割引！

ギガプランの音声SIM/音声eSIMが対象！  
複数回線ご利用で、1回線あたり月額100円割引します。

![音声回線利用で月額割引！](https://www.iijmio.jp/goaiko/img/tokuten2.png)

![例えばこんな使い方](https://www.iijmio.jp/goaiko/img/ex_howto_tag.png)

*   同居
    
    夫
    
    ![夫](https://www.iijmio.jp/hdc/kazokuwaribiki/img/father_02.png)
    
    10GB
    
    月額
    
    1,400  
    (税込)
    
    円
    
    妻
    
    ![妻](https://www.iijmio.jp/hdc/kazokuwaribiki/img/mother_02.png)
    
    10GB
    
    月額
    
    1,400  
    (税込)
    
    円
    
    別居
    
    子
    
    ![子](https://www.iijmio.jp/hdc/kazokuwaribiki/img/daughter_02.png)
    
    10GB
    
    月額
    
    1,400  
    (税込)
    
    円
    
    別居
    
    親
    
    ![親](https://www.iijmio.jp/hdc/kazokuwaribiki/img/grandfather_02.png)
    
    2GB
    
    月額
    
    850  
    (税込)
    
    円
    
    家族割引
    
    \-100円
    
    家族割引
    
    \-100円
    
    家族割引
    
    \-100円
    
    家族割引
    
    \-100円
    
    合計
    
    32GB
    
    5,050円
    
    月額
    
    4,650
    
    (税込)
    
    円
    

#### 家族4人みんなでIIJmio

1回線ごとに月額100円割引になるので、4人で使えば月400円割引に！  
しかも離れて暮らしていても同一mioIDならずーっと割引！

※家族割引は、会員専用ページより同意お申込みが必要です。

mio長特  
（長期利用特典）
----------------

2025年1月23日開始

### ご契約期間に応じて、  
おトクな特典をプレゼント！

ギガプランのご契約期間に応じて、データ量プレゼントや各種手数料割引など特典をプレゼント！  
特典は今後も追加予定！

![ご契約期間に応じて、おトクな特典をプレゼント！](https://www.iijmio.jp/goaiko/img/tokuten3.png)

![eSIMも選べる！](https://www.iijmio.jp/gigaplan/img/esim_id_title.png) ![eSIMも選べる！](https://www.iijmio.jp/gigaplan/img/esim_id_title_sp.png)

契約から開通まで、オンラインで簡単に。  
iPhoneやiPadをお使いの方におすすめです。

#### 契約、開通手続きがオンラインで簡単に！

![eSIM](https://www.iijmio.jp/gigaplan/img/esim_online.png)

WEB上からのお申し込みで完結。SIMカードの到着を待つこともなく、ご契約後すぐにインターネットをご利用いただけます。

#### 通信障害など、万が一の場合も2社の回線なら安心

![万が一でもドコモ網au網両方使える](https://www.iijmio.jp/gigaplan/img/img_esim_anzen.png)

eSIM でデュアル SIM を活用すればスマホ1台で2社回線持つことも！  
2つの電話番号を使い分けもできて万が一の時も安心・便利です。

 [![IIJmioひかり キャンペーン](https://www.iijmio.jp/imh/img/bigbnr_hikaricp_202502_pc.png) ![IIJmioひかり キャンペーン](https://www.iijmio.jp/imh/img/bigbnr_hikaricp_202502_sp.png)](https://www.iijmio.jp/campaign/imh/hikaricp.html)

公式アプリ  
「My IIJmio」

アプリを使えば、データ残量の確認やデータ量の購入も簡単！  
iPhoneの方は、構成プロファイルダウンロードも！各種設定がすぐに変えられます！

![公式アプリMy IIJmio](https://www.iijmio.jp/gigaplan/img/app_icon_phone.png)

TOPIC

2024.6.26

さらに快適にご利用いただくため、下記改善を行いました。

*   生体認証（指紋・顔など）によるアプリログインを可能に
*   電話番号のマスキングの解除を可能に（要 生体認証ON）
*   データシェアをデータ量タブから簡単に申し込み可能に
*   ログイン画面のUI改善
*   ミニマムスタートプラン、ライトスタートプラン、ファミリーシェアプランなど各プランに対応

アプリをダウンロード

![](https://www.iijmio.jp/gigaplan/img/dl_appstore_qr.png)

iOS(iPhone/iPad)

[![App Storeからダウンロード](https://www.iijmio.jp/hdd/coupon/img/dl_appstore.png)](https://apps.apple.com/jp/app/id1574157265)

![](https://www.iijmio.jp/gigaplan/img/dl_googleplay_qr.png)

Android

[![Google playで手に入れよう](https://www.iijmio.jp/hdd/coupon/img/dl_googleplay.png)](https://play.google.com/store/apps/details?id=jp.ad.iij.myiijmio)

[アプリマニュアルはこちら](https://www.iijmio.jp/gigaplan/manual/)

今なら人気スマホがお得！2026/2/2まで

ギガプラン音声SIM／音声eSIMとセットで  
人気スマホがお得！
------------------------------------------------------------

![eSIM対応](https://www.iijmio.jp/image/icon_esim_ok.svg)

5G対応

OPPO

OPPO Reno11 A SUPERVOOC急速充電器SET

![](https://www.iijmio.jp/device/img/OPPO_Reno11_A.png)

D

A

のりかえ  
(MNP)

［一括支払い］

税込36,800円

税込24,800円

［24回払い］

税込1,534円

税込1,035円

新規契約

［一括支払い］

税込36,800円

［24回払い］

税込1,534円

[お申し込みはこちら](https://www.iijmio.jp/device/detail.html?key=OPPO_Reno11_A)
[詳しくはこちら](https://www.iijmio.jp/device/oppo/reno11_a_charger_set.html)

![eSIM対応](https://www.iijmio.jp/image/icon_esim_ok.svg)

5G対応

motorola

motorola edge 60 pro

![](https://www.iijmio.jp/device/img/motorola_edge_60_pro.png)

D

A

のりかえ  
(MNP)

［一括支払い］

税込57,800円

税込39,800円

［24回払い］

税込2,410円

税込1,659円

新規契約

［一括支払い］

税込57,800円

［24回払い］

税込2,410円

[お申し込みはこちら](https://www.iijmio.jp/device/detail.html?key=motorola_edge_60_pro)
[詳しくはこちら](https://www.iijmio.jp/device/motorola/edge60-pro.html)

![eSIM対応](https://www.iijmio.jp/image/icon_esim_ok.svg)

5G対応

SHARP

AQUOS sense10 \[6GB/128GB\]

![](https://www.iijmio.jp/device/img/AQUOS_sense10_6GB_128GB.png)

D

A

のりかえ  
(MNP)

［一括支払い］

税込61,000円

税込44,800円

［24回払い］

税込2,553円

税込1,867円

新規契約

［一括支払い］

税込61,000円

［24回払い］

税込2,553円

[お申し込みはこちら](https://www.iijmio.jp/device/detail.html?key=AQUOS_sense10_6GB_128GB)
[詳しくはこちら](https://www.iijmio.jp/device/sharp/sense10.html)

[全ての端末を見る](https://www.iijmio.jp/campaign/mio.html?cptype=devicecp)

[のりかえ価格をお申し込みの前に](https://www.iijmio.jp/gigaplan/#overview_cp_sp_sale)

![MM総研](https://www.iijmio.jp/gigaplan/img/logo_mmri.png)

### 

IIJのモバイルサービス  
SIMカード契約数 シェアNo.1

国内MVNO市場の2025年3月末時点の実績から、独自サービス型SIM（MVNE提供分含む）の保有回線数においてインターネットイニシアティブがシェア1位を獲得しました。  
出典：MM総研　国内MVNO市場調査（2025年3月末時点）

![IIJmioの取り組み](https://www.iijmio.jp/gigaplan/img/message.png) ![IIJmioの取り組み](https://www.iijmio.jp/gigaplan/img/message_sp.png)

### あなたのスマホが使えるかチェック！

本ページに記載した内容は、すべて弊社で独自に調査した結果です。その内容を保証・サポートするものではありません。

×

検索

#### 検索が多いキーワード

*   iPhone
*   iPad
*   Pixel
*   OPPO
*   楽天モバイル

新規お申し込み方法
---------

ご自宅でカンタンに手続き完了！

*   ### お申し込み前に
    
    下記をご用意ください。
    
    ![](https://www.iijmio.jp/gigaplan/img/card-icon.png)
    
    本人名義の  
    クレジットカード
    
    ![](https://www.iijmio.jp/gigaplan/img/pc-icon.png)
    
    インターネット環境と  
    パソコンなど
    
    ![](https://www.iijmio.jp/gigaplan/img/mail-icon.png)
    
    メールアドレス
    
    ![](https://www.iijmio.jp/campaign/share_no1/img/step01_img2.png)
    
    音声SIM、音声eSIM、SMS SIMの方は本人確認書類  
    [詳細はこちら](https://www.iijmio.jp/hdd/miofone/verify.html)
    
    ![](https://www.iijmio.jp/campaign/share_no1/img/step01_img3.jpg)
    
    お使いのスマホの番号のまま乗り換えの方は、MNP予約番号が必要な場合があります。
    
    SIMの種類によってSIMロック解除が必要な場合があります。  
    [詳細はこちら](https://help.iijmio.jp/answer/601287ccdb86270011219f19/)
    
    [\[docomo\] SIMロック解除方法](https://www.iijmio.jp/esim/simunlockdocomo.html)
      
    [\[au\] SIMロック解除方法](https://www.iijmio.jp/esim/simunlockau.html)
      
    [\[SoftBank\] SIMロック解除方法](https://www.iijmio.jp/esim/simunlocksoftbank.html)
      
    
*   ### WEBで申し込み
    
    #### 利用するデータ量・SIMの機能・ご利用される方のお名前などをご登録の上、本サイトから直接お申し込みください。
    
    複数回線を申し込む場合お申し込み画面内で「もう１枚申し込む」をご選択いただくと、まとめて複数回線をお申し込みいただけます。
    
    ![](https://www.iijmio.jp/campaign/family/img/step_02_img.png)
    
    家族割引適用には家族割引を適用するには、条件をご確認のうえ、同意する必要があります。  
    同意確認ページについては、10/1よりIIJmio会員専用サイト内でご覧いただけます。
    
*   ### SIMの設定・ご利用開始
    
    お手続きの完了後、最短3～4日程度(※)で SIMカードをお届けします。  
    ※一部離島・土日祝を除く。  
      
    eSIM（音声/データ）の場合、お申し込み完了後に登録されたメールアドレス宛にお申し込み完了のメールが届きます。メールの内容に従い、初期設定を行ってください。
    
    [\[iPhone\] eSIM初期設定](https://www.iijmio.jp/hdd/esim/flow/iphone.html)
      
    [\[Android\] eSIM初期設定](https://www.iijmio.jp/hdd/esim/flow/android.html)
      
    [\[iPad\] eSIM初期設定](https://www.iijmio.jp/hdd/esim/flow/ipad.html)
    

*   ### お申し込み前に
    
    下記をご用意ください。
    
    ![](https://www.iijmio.jp/gigaplan/img/card-icon.png)
    
    本人名義の  
    クレジットカード
    
    ![](https://www.iijmio.jp/gigaplan/img/pc-icon.png)
    
    インターネット環境と  
    パソコンなど
    
    ![](https://www.iijmio.jp/gigaplan/img/mail-icon.png)
    
    メールアドレス
    
    ![](https://www.iijmio.jp/campaign/share_no1/img/step01_img2.png)
    
    音声SIM、音声eSIM、SMS SIMの方は本人確認書類
    
    ![](https://www.iijmio.jp/campaign/share_no1/img/step01_img3.jpg)
    
    お使いのスマホの番号のまま乗り換えの方は、MNP予約番号が必要な場合があります。
    
    SIMの種類によってSIMロック解除が必要な場合があります。
    
*   ### WEBで申し込み
    
    #### 利用するデータ量・SIMの機能・ご利用される方のお名前などをご登録の上、本サイトから直接お申し込みください。
    
*   ### SIMの設定・ご利用開始
    
    お手続きの完了後、最短3～4日程度(※)で SIMカードをお届けします。  
    ※一部離島・土日祝を除く。  
      
    eSIM（音声/データ）の場合、お申し込み完了後に登録されたメールアドレス宛にお申し込み完了のメールが届きます。メールの内容に従い、初期設定を行ってください。
    

![MNPワンストップ](https://www.iijmio.jp/image/banner/bnr_onestop_id.png) ![MNPワンストップ](https://www.iijmio.jp/image/banner/bnr_onestop_sp_id.png)

 [![MNPワンストップ](https://www.iijmio.jp/image/banner/bnr_onestop.png) ![MNPワンストップ](https://www.iijmio.jp/image/banner/bnr_onestop_sp.png)](https://www.iijmio.jp/hdc/guide/mnp.html#mnp_onestop)

ギガプランへのプラン変更方法※
---------------

※既にIIJmioモバイルサービスを利用中の方

*   ### お申し込み前に
    
    プラン変更できるサービスかどうかご確認ください。
    
    ・ミニマムスタート  
    ・ライトスタート  
    ・ファミリーシェア  
    ・ケータイ  
    ・eSIMベータ版  
    ・従量制プラン  
    ・エコプラン  
    
*   ### 会員専用ページで  
    申し込み
    
    「ギガプランへ変更する」ボタンよりオンラインで申し込んでください。
    
    [ギガプランへ変更する](https://www.iijmio.jp/service/setup/hdd/process/migrateservice/input/)
    
    ※お申し込み方法は[動画](https://www.youtube.com/embed/MbPIMlado0M?rel=0)
    でもご覧いただけます。
    
    ※ログインには、mioIDとmioパスワードが必要です。
    
*   ### 即時ギガプランに変更完了
    
    手数料無料！SIMも電話番号もそのまま。  
    設定変更なしにそのままご利用できます。
    

取り扱い店舗
------

IIJmioモバイルサービス ギガプランは、店舗でもご購入いただけます。

*   ![ロゴ](https://www.iijmio.jp/gigaplan/img/logo.png) ![ロゴ](https://www.iijmio.jp/gigaplan/img/logo_sp.png)

[取り扱い店舗一覧はこちら](https://shop.iijmio.jp/?c=%E9%9F%B3%E5%A3%B0SIM%20%E5%8D%B3%E6%97%A5%E9%96%8B%E9%80%9A,%E3%82%AE%E3%82%AC%E3%83%97%E3%83%A9%E3%83%B3%E3%83%91%E3%83%83%E3%82%B1%E3%83%BC%E3%82%B8%20%EF%BC%88%E3%82%A8%E3%83%B3%E3%83%88%E3%83%AA%E3%83%BC%E3%82%B3%E3%83%BC%E3%83%89%EF%BC%89%E5%8F%96%E3%82%8A%E6%89%B1%E3%81%84)

 [![ギガプラン音声SIM即日開通店舗検索](https://www.iijmio.jp/image/banner/store_reception_bnr.png) ![ギガプラン音声SIM即日開通店舗検索](https://www.iijmio.jp/image/banner/store_reception_bnr_sp.png)](https://shop.iijmio.jp/?c=%E9%9F%B3%E5%A3%B0SIM%20%E5%8D%B3%E6%97%A5%E9%96%8B%E9%80%9A)

よくあるご質問
-------

その他、ギガプランに関するよくあるお問い合わせは、  
[ギガプランFAQ](https://help.iijmio.jp/search/?q=%E3%82%AE%E3%82%AC%E3%83%97%E3%83%A9%E3%83%B3)
をご確認ください。

 

初めてIIJmioを  
お申し込みされる方 ギガプランへの  
プラン変更される方

どうしてこんなに安いの？縛りとかはないの？

多くのお客様に安く、かつわかりやすいプランを提供するためです。  
2年縛りや違約金などもありません。

どの端末でも使用できるの？キャリア端末使ってるけど使えるの？

タイプD  
NTTドコモから発売された端末はそのままご利用いただけます。SIMフリー端末については、[動作確認済端末一覧](https://www.iijmio.jp/hdd/devices/)
をご確認ください。  
タイプA  
2017年8月以降にauから発売された端末はそのままご利用いただけます。SIMフリー端末については、[動作確認済端末一覧](https://www.iijmio.jp/hdd/devices/)
をご確認ください。  
eSIM  
SIMロックされていないeSIM対応端末でご利用いただけます。弊社が動作確認している端末については、[動作確認済端末一覧](https://www.iijmio.jp/hdd/devices/)
をご確認ください。

私にはなんギガが向いているの？なんギガがお得なの？

約半数のお客様は2GBも使用していないとの調査結果があります。動画閲覧をしたり、音楽ストリーミングサービスをご利用の方でも、ご自宅に居る時はWi-Fiを使うことで、ギガ消費を抑えることも可能です。  
どのギガプランでも、余ったデータ容量は翌月末日まで繰り越せますので、無駄なくご利用いただけます。  
データ量のシェア機能により、ご家族でギガを分け合うことも可能です。

使えるエリアはどうなの？地方でも繋がるの？

NTTドコモまたはauの設備を使っているので、郊外でも都心部でも、広いエリアで安定した品質で通話できます。  
※対応エリアは利用する端末により異なります。

契約したいです、キャリアメール使えるかどうかなど、注意点を教えてください。

キャリアのアドレスは別途キャリアにて「メール持ち運び」のご契約をしていただくことで継続してご利用いただけます※。  
もちろん、GmailやYahoo!メールなどのフリーメールサービスもご利用いただけます。  
注意事項などは[こちら](https://www.iijmio.jp/hdd/guide/beginner.html)
に乗り換えガイドをご用意していますのでご参照ください。  
また、ビックカメラやヨドバシカメラなどの量販店でもご契約が可能です。  
即日開通店舗は[こちら](https://shop.iijmio.jp/?c=%E9%9F%B3%E5%A3%B0%20%E5%8D%B3%E6%97%A5%E9%96%8B%E9%80%9A)
からご確認ください  
※メール持ち運びの詳細は各キャリアにお尋ねください。

かけ放題の機能はありますか？

はい、ございます。  
かけ放題プランは、通話時間によって選べる「[通話定額オプション](https://www.iijmio.jp/mobile/voicefree/)
」を用意しておりますので、こちらをご覧ください。

ギガプランへ変更したい。変更できるプランを教えてほしい。

下記記載のプランをご契約中の場合はギガプランへの変更が可能です。記載がないプランは変更ができません。

*   ・ミニマムスタートプラン
*   ・ライトスタートプラン
*   ・ファミリーシェアプラン
*   ・ケータイプラン
*   ・eSIMプラン（ベータ版）
*   ・従量制プラン
*   ・エコプラン
*   ※ギガプランへのプラン変更時に、SIM機能（音声/SMS/データ）やを同時に変更することは出来ません。なお、音声SIMのみeSIMへの形状変更を同時に行えます。

eSIMデータプランゼロはギガプランに変更できないの？

eSIMデータプランゼロの対応については検討をしていますが、時期は未定です。  
決定しましたら追ってお知らせへ掲載いたします。

契約中のプランを残したまま、新たにギガプランを契約できるの？契約中のプランは使えなくなるの？

現在の契約を残したまま、ギガプランも一緒にご契約いただけます。ミニマムスタートプラン、ライトスタートプラン、ファミリーシェアプラン、従量制プラン、エコプランの場合、1回線のみをギガプランへ変更することも可能です。  
また、新プランに変更しなくても現在ご契約中のプランはそのままご利用いただけます。

長得は継続されるの？

ギガプランは[長得](https://www.iijmio.jp/chotoku/)
（IIJmioモバイルサービスなど旧プラン向けの長期利用特典）の対象外となります。  
長得対象のプランをギガプランへ変更した場合、変更したプランは長得の特典をご利用いただけなくなります。  
特典の発行や、発行された「データ容量1GB分×3枚プレゼント」のクーポンコードの確認もできなくなります。もしプラン変更を予定されている特典対象者の方でまだクーポンコードの発行されてない場合、ギガプランが適用される前にクーポンコードを発行をしコードをご自身で保管ください。  
なお、ギガプランへ変更後13ヵ月以上ご契約いただくと、「mio長特」をご利用できます。特典内容などは[mio長特とは](https://www.iijmio.jp/hdc/choki-riyotokuten/)
をご覧ください。

ギガプランに変更後は、今契約しているプランのクーポン（データ量）の残量はどうなるの？

今契約しているプランのクーポン（データ量）はギガプランへ引き継げません。

2枚目以降のSIMカードをギガプランに変更できますか？

はい、可能です。ギガプランは合計10回線まで契約できます。  
データ量のシェアもできます。

ギガプランへの変更方法を教えてください。

会員専用ページよりお手続きができます。  
お手続きの流れは[ギガプランへのプラン変更方法](https://www.iijmio.jp/gigaplan/#inc_step)
をご覧ください。

ギガプランへの変更に手数料はかかるの？

いいえ、手数料はかかりません。

注意事項
----

*   ・音声SIMと音声eSIMの場合、18歳未満の方はご契約できません。お申し込みできる回線数はプランを問わず合計5回線までです。
*   ・お申し込み内容により、携帯電話不正利用防止法に基づく本人確認のため、運転免許証・マイナンバーカードなどの[本人確認書類](https://www.iijmio.jp/hdd/miofone/verify.html)
    が必要です。
*   ・各種アプリによるSMS送受信の動作確認は行っておりません。また、端末側のSMS送受信機能の有無についても、弊社にて確認は行っておりません。端末の提供元へお問い合わせください。
*   ・NTTドコモやauなど、各キャリアが提供するサービスを利用することはできません。
*   ・キャリアのメールアドレスは別途キャリアにて「メール持ち運び」のご契約をしていただくことで継続してご利用いただけます。メール持ち運びの詳細は各キャリアにお問い合わせください。
*   ・一般社団法人インターネットコンテンツセーフティ協会（ICSA）が提供するリストに該当するサイトへアクセスした際に、DNSサーバ側でこの閲覧要求をブロックし、[閲覧を規制している旨のメッセージ画面](https://www.iijmio.jp/guide/blocking/)
    を表示します。

よくあるご質問
-------

どうしてこんなに安いの？縛りとかはないの？

多くのお客様に安く、かつわかりやすいプランを提供するためです。  
2年縛りや違約金などもありません。

私にはなんギガが向いているの？なんギガがお得なの？

約半数のお客様は2GBも使用していないとの調査結果があります。動画閲覧をしたり、音楽ストリーミングサービスをご利用の方でも、ご自宅に居る時はWi-Fiを使うことで、ギガ消費を抑えることも可能です。  
どのギガプランでも、余ったデータ容量は翌月末日まで繰り越せますので、無駄なくご利用いただけます。  
データ量のシェア機能により、ご家族でギガを分け合うことも可能です。

使えるエリアはどうなの？地方でも繋がるの？

NTTドコモまたはauの設備を使っているので、郊外でも都心部でも、広いエリアで安定した品質で通話できます。  
※対応エリアは利用する端末により異なります。

契約したいです、キャリアメール使えるかどうかなど、注意点を教えてください。

キャリアのアドレスは別途キャリアにて「メール持ち運び」のご契約をしていただくことで継続してご利用いただけます※。  
もちろん、GmailやYahoo!メールなどのフリーメールサービスもご利用いただけます。  
※メール持ち運びの詳細は各キャリアにお尋ねください。

かけ放題の機能はありますか？

はい、ございます。  
かけ放題プランは、通話時間によって選べる「通話定額オプション」を用意しております。

注意事項
----

*   ・音声SIMと音声eSIMの場合、18歳未満の方はご契約できません。お申し込みできる回線数はプランを問わず合計5回線までです。
*   ・お申し込み内容により、携帯電話不正利用防止法に基づく本人確認のため、運転免許証・マイナンバーカードなどの本人確認書類が必要です。
*   ・各種アプリによるSMS送受信の動作確認は行っておりません。また、端末側のSMS送受信機能の有無についても、弊社にて確認は行っておりません。端末の提供元へお問い合わせください。
*   ・NTTドコモやauなど、各キャリアが提供するサービスを利用することはできません。
*   ・キャリアのメールアドレスは別途キャリアにて「メール持ち運び」のご契約をしていただくことで継続してご利用いただけます。メール持ち運びの詳細は各キャリアにお問い合わせください。
*   ・一般社団法人インターネットコンテンツセーフティ協会（ICSA）が提供するリストに該当するサイトへアクセスした際に、DNSサーバ側でこの閲覧要求をブロックし、[閲覧を規制している旨のメッセージ画面](https://www.iijmio.jp/guide/blocking/)
    を表示します。

キャンペーン概要
--------

契約内容や契約状況に応じて、おトクな特典を提供します。

キャンペーンは予告なく変更・終了させていただく場合がございます。

当社とのお取引関係上、著しく問題があったお客様には、その理由を問わず特典の提供をお断りする場合がございます。

新たに申し込み

初めての契約や追加契約する場合

旧プラン※から変更

旧プランからギガプランへ変更する場合

ギガプランを利用中

契約内容を変更する場合

ミニマムスタートプラン、ライトスタートプラン、ファミリーシェアプラン、従量制プランからギガプランへ変更の場合

### 適用される特典

### 

eSIM初期費用割引キャンペーン

|     |     |
| --- | --- |
| 受付期間 | 2025年11月21日～2026年1月21日 23時59分まで  <br>※本キャンペーンは予告なく終了する場合があります。 |
| 適用条件 | 以下に定める条件をすべて満たしたお客様が適用対象となります。  <br><br>*   受付期間中にIIJmioのWEBサイトから、IIJmioモバイルサービス ギガプランを「音声eSIM」または「データeSIM」を新規お申し込みいただくこと<br>*   お申し込み完了後、回線をご利用開始いただくこと |
| 特典内容 | 適用条件をすべて満たした場合に次の特典を提供します。  <br>  <br>初期費用割引特典：初期費用から1,100円(税込)を割引します  <br>※IIJmioギガプランのeSIM以外（音声SIMカード/SMS回線/データ回線）をお申し込みの場合、割引は適用されません。 |
| 注意事項 | *   本キャンペーンは音声eSIMとデータeSIM回線がそれぞれ「お一人様（mioID）あたり1回線まで」の適用です。<br>*   受付期間中のお申し込みの場合、ご利用開始（もしくはeSIMプロファイルの到着）がキャンペーン期間外でも適用対象です。<br>*   以下のいずれかに該当するお申し込みは本キャンペーンの対象外となります。  <br>    1)IIJmioのWEBサイトを経由せずに音声eSIMまたはデータeSIMをお申し込みいただいた場合  <br>    2)受付期間中に音声eSIMで本キャンペーン適用済みの方が、2回線目以降音声eSIMをお申し込みいただく場合  <br>    3)受付期間中にデータeSIMで本キャンペーン適用済みの方が、2回線目以降データeSIMをお申し込みいただく場合  <br>    4)家電量販店やネットショップなどで購入したパッケージ（エントリーコード・パスコード）を利用してのお申し込みの場合<br>*   当社とのお取引関係上、著しく問題があったお客様には、特典の適用をお断りする場合があります。<br>*   契約いただく場合には別途SIMプロファイル発行手数料が必要です。  <br>    \-音声eSIM タイプD：433.4円  <br>    \-音声eSIM タイプA／データeSIM：220円 |

### 

ハッピースマイルキャンペーン【音声SIM割引特典】

|     |     |
| --- | --- |
| 受付期間 | 2025年11月21日～終了日未定  <br>※本キャンペーンは予告なく終了する場合があります。 |
| 適用条件 | 以下に定める条件をすべて満たしたお客様が適用対象となります。  <br><br>*   受付期間中にIIJmioモバイルサービス ギガプラン「音声SIM」または「音声eSIM」を新規お申し込みいただくこと<br>*   5ギガ／10ギガ／15ギガプランをお申し込みいただくこと  <br>    ※お申し込みプランにより割引額が異なります。 |
| 特典内容 | ご利用開始月から最大3ヵ月間月額基本料金を割引します。  <br><br>*   5ギガプラン：150円（税込）×最大3ヵ月間<br>*   10ギガプラン：150円（税込）×最大3ヵ月間<br>*   15ギガプラン：900円（税込）×最大3ヵ月間<br><br>※本キャンペーンは1回線につき1回のみ適用いたします。 |
| 注意事項 | *   ギガプランのご利用開始後、お申込時とは異なるデータ容量プランに変更した場合はキャンペーンの対象外となります。<br>*   IIJmioのWEBサイト以外(JALモバイル・BIC SIMなど)からお申し込みの場合は、本キャンペーンの対象外となります。<br>*   ご利用開始月の月額料金は日割となりますが、本キャンペーンは月中のご利用開始でも割引を満額適用いたします。日割の月額料金が割引額を下回る場合は、日割の月額料金と同額を上限として割引いたします。 |
| よくある質問 | **Q1**：申込後、利用開始（もしくはSIMもしくはeSIMプロファイルの到着）がキャンペーン期間外となりました。  <br>**A1**：キャンペーン期間内の申込であれば、特典の対象となります。  <br><br>* * *<br><br>**Q2**：キャンペーン対象プランの利用開始後、別のプランに容量変更しました。  <br>**A2**：容量変更が完了した月から、特典の対象外となります。5ギガ・10ギガ・15ギガ間のプラン変更の場合も特典の対象外となります。  <br><br>* * *<br><br>**Q3**：キャンペーン対象外のSIM機能（データ・SMS）に変更しました。  <br>**A3**：対象外SIMへの変更が完了した月から、特典の対象外となります。  <br><br>* * *<br><br>**Q4**：15ギガプランを申し込み後、11/21に利用開始しました。当月の料金はいくらになりますか。  <br>**A4**：15ギガプラン月額料金の日割分600円（通常1,800円の10日間分）に、本キャンペーンの割引が日割り分と同額の600円適用され、0円となります。 |

### 

ハッピースマイルキャンペーン【音声SIM割引特典】

|     |     |
| --- | --- |
| 受付期間 | 2025年11月21日～終了日未定  <br>※本キャンペーンは予告なく終了する場合があります。 |
| 適用条件 | 以下に定める条件をすべて満たしたお客様が適用対象となります。  <br><br>*   受付期間中にIIJmioモバイルサービス旧プラン「音声SIM」の回線を、ギガプラン「音声SIM」へ変更お申し込みいただくこと<br>*   5ギガ／10ギガ／15ギガプランをお申し込みいただくこと  <br>    ※お申し込みプランにより割引額が異なります。 |
| 特典内容 | ギガプランへの変更完了月から最大3ヵ月間月額基本料金を割引します。  <br><br>*   5ギガプラン：150円（税込）×最大3ヵ月間<br>*   10ギガプラン：150円（税込）×最大3ヵ月間<br>*   15ギガプラン：900円（税込）×最大3ヵ月間<br><br>※本キャンペーンは1回線につき1回のみの適用いたします。 |
| 注意事項 | *   ギガプランのご利用開始後、お申込時とは異なるデータ容量プランに変更した場合はキャンペーンの対象外となります。<br>*   ご利用開始月の月額料金は日割となりますが、本キャンペーンは月中のご利用開始でも割引を満額適用いたします。日割の月額料金が割引額を下回る場合は、日割の月額料金と同額を上限として割引いたします。 |
| よくある質問 | **Q1**：キャンペーン対象プランの利用開始後、別のプランに容量変更しました。  <br>**A1**：容量変更が完了した月から、特典の対象外となります。5ギガ・10ギガ・15ギガ間のプラン変更の場合も特典の対象外となります。  <br><br>* * *<br><br>**Q2**：キャンペーン対象外のSIM機能（データ・SMS）に変更しました。  <br>**A2**：対象外SIMへの変更が完了した月から、特典の対象外となります。  <br><br>* * *<br><br>**Q3**：15ギガプランを申し込み後、11/21に利用開始しました。当月の料金はいくらになりますか。  <br>**A3**：15ギガプラン月額料金の日割分600円（通常1,800円の10日間分）に、本キャンペーンの割引が日割り分と同額の600円適用され、0円となります。 |

### 

15ギガプランお試し割

|     |     |
| --- | --- |
| 受付期間 | 2025年11月21日～2026年1月21日 23時59分まで  <br>※本キャンペーンは予告なく終了する場合があります。 |
| 適用条件 | 以下に定める条件をすべて満たしたお客様が適用対象となります。  <br><br>*   IIJmioモバイルサービス ギガプラン「音声SIM」または「音声eSIM」（15ギガプランを除く）をご利用中の回線であること<br>*   受付期間中にご利用中の回線を15ギガプランにプラン変更お申し込みをいただくこと  <br>    ※お申し込みいただいたプラン変更は、翌月１日より適用となります。  <br>    ※毎月末日はプラン変更をお申し込みいただくことが出来ません。 |
| 特典内容 | 容量変更完了月から、月額基本料金を割引します。  <br><br>*   15ギガプラン：400円（税込）×最大3ヵ月間<br><br>※本キャンペーンは1回線につき1回のみの適用となります。 |
| 注意事項 | *   15ギガプランのご利用開始後、別のプランに容量変更した場合はキャンペーンの対象外となります。<br>*   ハッピースマイルキャンペーン（2025年11月21日～終了日未定）【音声SIM割引】（15ギガプラン900円割引）が適用済の回線は、キャンペーン期間中に再度15ギガプランに変更してもキャンペーンは再適用されません。（初回の一度のみ適用） |
| よくある質問 | **Q1**：キャンペーン対象プランの利用開始後、別のプランに容量変更しました。  <br>**A1**：容量変更が完了した月から、特典の対象外となります。  <br><br>* * *<br><br>**Q2**：キャンペーン対象外のSIM機能（データ・SMS）に変更しました。  <br>**A2**：対象外SIMへの変更が完了した月から、特典の対象外となります。 |

### 

ハッピースマイルキャンペーン【音声SIM データ増量特典】

|     |     |
| --- | --- |
| 受付期間 | 2025年11月21日～終了日未定  <br>※本キャンペーンは予告なく終了する場合があります。 |
| 適用条件 | 以下の条件をすべて満たした場合にキャンペーン適用いたします。  <br><br>*   受付期間中にIIJmioモバイルサービス ギガプランの「音声SIM」または「音声eSIM」を新規お申し込みいただくこと<br>*   15ギガ／25ギガ／35ギガ／45ギガ／55ギガプランをお申し込みいただくこと |
| 特典内容 | ご利用開始月からデータ容量10GBを3ヵ月間増量します。  <br><br>*   15ギガプラン：10GBデータ増量×最大3ヵ月<br>*   25ギガプラン：10GBデータ増量×最大3ヵ月<br>*   35ギガプラン：10GBデータ増量×最大3ヵ月<br>*   45ギガプラン：10GBデータ増量×最大3ヵ月<br>*   55ギガプラン：10GBデータ増量×最大3ヵ月<br><br>※本キャンペーンは1回線につき1回のみの適用となります。  <br>  <br>＜ギガプランのデータシェア機能ご利用時の場合＞  <br>データ増量特典はキャンペーン対象の各回線に対して付与いたします。  <br>増量されたデータ容量をデータシェア機能を用いて複数回線でご利用いただく場合、データプレゼント機能からシェアグループへの移行お手続きが必要です。  <br>データシェア・データプレゼントの詳細は[こちら](https://www.iijmio.jp/gigaplan/dataoption/) |
| 注意事項 | *   IIJmioのWEBサイト以外(JALモバイル・BIC SIMなど)からお申し込みの場合は、本キャンペーンの対象外となります。<br>*   ご利用開始月のデータ量および本キャンペーンの10GBデータ増量は、それぞれ日割適用となります。 |
| よくある質問 | **Q1**：申込後、利用開始（もしくはSIMもしくはeSIMプロファイルの到着）がキャンペーン期間外となりました。  <br>**A1**：キャンペーン期間内の申込であれば、特典の対象となります。  <br><br>* * *<br><br>**Q2**：キャンペーン対象プランの利用開始後、別のプランに容量変更しました。  <br>**A2**：本特典は容量変更されても継続して適用いたします。2ギガ・5ギガへの変更の場合も継続されます。  <br><br>* * *<br><br>**Q3**：15ギガプランを申し込み後、11/21に利用開始しました。当月のデータ量は何GBになりますか。  <br>**A3**：15ギガプランの日割分5GB（通常15GBの10日間分）に、本キャンペーンの増量分3GB割引（通常10GBの10日間分）が加算され、8GBとなります。 |

### 

ハッピースマイルキャンペーン【音声SIM データ増量特典】

|     |     |
| --- | --- |
| 受付期間 | 2025年11月21日～終了日未定  <br>※本キャンペーンは予告なく終了する場合があります。 |
| 適用条件 | 以下の条件をすべて満たした場合にキャンペーン適用いたします。  <br><br>*   受付期間中にIIJmioモバイルサービス旧プラン「音声SIM」の回線を、ギガプラン「音声SIM」へ変更お申し込みいただくこと<br>*   15ギガ／25ギガ／35ギガ／45ギガ／55ギガプランをお申し込みいただくこと |
| 特典内容 | ギガプランへの変更完了月からデータ容量10GBを3ヵ月間増量します。  <br><br>*   15ギガプラン：10GBデータ増量×最大3ヵ月<br>*   25ギガプラン：10GBデータ増量×最大3ヵ月<br>*   35ギガプラン：10GBデータ増量×最大3ヵ月<br>*   45ギガプラン：10GBデータ増量×最大3ヵ月<br>*   55ギガプラン：10GBデータ増量×最大3ヵ月<br><br>※本キャンペーンは1回線につき1回のみの適用となります。  <br>  <br>＜ギガプランのデータシェア機能ご利用時の場合＞  <br>データ増量特典はキャンペーン対象の各回線に対して付与いたします。  <br>増量されたデータ容量をデータシェア機能を用いて複数回線でご利用いただく場合、データプレゼント機能からシェアグループへの移行お手続きが必要です。  <br>データシェア・データプレゼントの詳細は[こちら](https://www.iijmio.jp/gigaplan/dataoption/) |
| 注意事項 | *   ご利用開始月のデータ量および本キャンペーンの10GBデータ増量は、それぞれ日割適用となります。 |
| よくある質問 | **Q1**：キャンペーン対象プランの利用開始後、別のプランに容量変更しました。  <br>**A1**：本特典は容量変更されても継続して適用いたします。2ギガ・5ギガへの変更の場合も継続されます。  <br><br>* * *<br><br>**Q2**：15ギガプランを申し込み後、11/21に利用開始しました。当月のデータ量は何GBになりますか。  <br>**A2**：15ギガプランの日割分5GB（通常15GBの10日間分）に、本キャンペーンの増量分3GB割引（通常10GBの10日間分）が加算され、8GBとなります。 |

### 

ハッピースマイルキャンペーン【通話定額オプション割引特典】

|     |     |
| --- | --- |
| 受付期間 | 2025年11月21日～終了日未定  <br>※本キャンペーンは予告なく終了する場合があります。 |
| 適用条件 | 以下に定める条件をすべて満たしたお客様が適用対象となります。  <br><br>*   受付期間中にIIJmioモバイルサービス ギガプランを新規お申し込みいただくこと<br>*   通話定額オプションを同時にお申し込みいただくこと |
| 特典内容 | 各通話定額オプションのご利用開始月から最大3ヵ月間 オプション月額料金を割引します。  <br><br>*   通話定額5分+：500円（税込）×最大3ヵ月間 割引<br>*   通話定額10分+：700円（税込）×最大3ヵ月間 割引<br>*   かけ放題＋：1,400円（税込）×最大3ヵ月間 割引<br><br>※特典適用は1回線につき、各通話定額オプションの内いずれか1回までです。重複適用はできません。 |
| 注意事項 | *   キャンペーンが適用中の通話定額オプションを別の通話定額オプションへ変更された場合、キャンペーンの適用対象外となります。<br>*   IIJmioのWEBサイト以外(JALモバイル・BIC SIMなど)から新規お申し込みの際に通話定額オプションをお申し込みいただいた場合はキャンペーンの対象外となります。 |
| よくある質問 | **Q1**：本キャンペーンが適用中の通話定額オプションを、別の通話定額プランに変更することを検討しています。  <br>**A1**：別の通話定額オプションに変更された場合、キャンペーン対象外となります。 |

### 

ハッピースマイルキャンペーン【通話定額オプション割引特典】

|     |     |
| --- | --- |
| 受付期間 | 2025年11月21日～終了日未定  <br>※本キャンペーンは予告なく終了する場合があります。 |
| 適用条件 | 以下に定める条件をすべて満たしたお客様が適用対象となります。  <br><br>*   受付期間中にIIJmioモバイルサービス旧プラン「音声SIM」の回線をギガプランへ変更お申し込みいただくこと<br>*   ギガプランへ変更完了後、通話定額オプションの追加お申し込み(※)いただくこと<br><br>※会員専用ページの[通話定額・かけ放題オプションの申込・変更](https://www.iijmio.jp/service/mobile/process/calloption/select/)<br>よりお申し込みいただけます。 |
| 特典内容 | 各通話定額オプションのご利用開始月から最大3ヵ月間 オプション月額料金を割引します。  <br><br>*   通話定額5分+：500円（税込）×最大3ヵ月間 割引<br>*   通話定額10分+：700円（税込）×最大3ヵ月間 割引<br>*   かけ放題＋：1,400円（税込）×最大3ヵ月間 割引<br><br>※特典適用は1回線につき、各通話定額オプションの内いずれか1回までです。重複適用はできません。 |
| 注意事項 | *   キャンペーンが適用中の通話定額オプションを別の通話定額オプションへ変更された場合、キャンペーンの適用対象外となります。 |
| よくある質問 | **Q1**：旧プランを利用中のまま、通話定額オプションのみ契約を考えています。  <br>**A1**：旧プランのままでは通話定額オプションをお申し込みいただいてもキャンペーン対象外となります。ギガプランへの変更もご検討ください。  <br><br>* * *<br><br>**Q2**：キャンペーンが適用中の通話定額オプションを、別の通話定額プランに変更することを検討しています。  <br>**A2**：別の通話定額オプションに変更された場合、キャンペーン対象外となります。 |

### 

ハッピースマイルキャンペーン【通話定額オプション割引特典】

|     |     |
| --- | --- |
| 受付期間 | 2025年11月21日～終了日未定  <br>※本キャンペーンは予告なく終了する場合があります。 |
| 適用条件 | 以下に定める条件をすべて満たしたお客様が適用対象となります。  <br><br>*   既にギガプランの音声回線をご利用中であること<br>*   受付期間中に通話定額オプションの追加お申し込み(※)いただくこと<br><br>※会員専用ページの[通話定額・かけ放題オプションの申込・変更](https://www.iijmio.jp/service/mobile/process/calloption/select/)<br>よりお申し込みいただけます。  <br>※既に通話定額オプションをご利用中の方は、会員専用ページの[通話定額・かけ放題オプションの申込・変更](https://www.iijmio.jp/service/mobile/process/calloption/select/)<br>より変更申し込みいただけます。 |
| 特典内容 | 各通話定額オプションのご利用開始月から最大3ヵ月間 オプション月額料金を割引します。  <br><br>*   通話定額5分+：500円（税込）×最大3ヵ月間 割引<br>*   通話定額10分+：700円（税込）×最大3ヵ月間 割引<br>*   かけ放題＋：1,400円（税込）×最大3ヵ月間 割引<br><br>※特典適用は1回線につき、各通話定額オプションの内いずれか1回までです。重複適用はできません。 |
| 注意事項 | *   キャンペーンが適用中の通話定額オプションを別の通話定額オプションへ変更された場合、キャンペーンの対象外となります。<br>*   過去1年以内に通話定額オプションを割引するキャンペーンをご利用された場合、キャンペーンの対象外となります。  <br>    キャンペーン例※下記に記載の無いキャンペーンをご利用された場合も含みます。  <br>    （2024年9月3日～2025年2月3日）トクトクキャンペーン【通話定額オプション割引】  <br>    （2025年2月4日～2025年6月2日）トクトクキャンペーン+【通話定額オプション割引】  <br>    （2025年6月3日～2025年8月31日）サマーキャンペーン【通話定額オプション割引】  <br>    （2025年9月1日～2025年11月20日）ハッピーオータムキャンペーン【通話定額オプション割引】  <br>    （2025年11月21日～終了日未定）ハッピースマイルキャンペーン【通話定額オプション割引】 |
| よくある質問 | **Q1**：既に通話定額オプションを利用しており、別の通話定額プランに変更を考えています。  <br>**A1**：通話定額オプションを変更する場合でもキャンペーン対象となります。ただし、過去1年以内に通話定額オプション割引が適用済の回線は対象外となるためご注意ください。  <br><br>* * *<br><br>**Q2**：本キャンペーンが適用中の通話定額オプションを、別の通話定額プランに変更することを検討しています。  <br>**A2**：別の通話定額オプションに変更された場合、キャンペーン対象外となります。 |

### 

スマホ大特価セール・のりかえ価格

|     |     |
| --- | --- |
| 条件  | #### IIJmioモバイルサービス ギガプランの「音声SIM」または「音声eSIM」をMNP転入（※1）にて、かつ対象端末を同時にお申し込みいただいた場合  <br>※1 他社から乗り換え（MNP（携帯電話番号ポータビリティ））にて、現在ご利用の携帯電話番号を引き継いでのお申し込み。 |
| 内容  | #### 「1契約者様（mioID）あたり1台まで」対象端末をのりかえ価格で提供します。<br><br>・のりかえ価格の一覧は[こちら](https://www.iijmio.jp/info/iij/1755476367.html)<br>  <br>  <br><br>#### **また、一部機種ののりかえ価格は「スマホ大特価セール（2025/11/21～2026/2/2 21:59）」として期間限定での提供****となります。**<br><br>・スマホ大特価セール（2025/11/21～2026/2/2 21:59）の一覧は[こちら](https://www.iijmio.jp/info/iij/1763432854.html)<br>  <br>  <br>※ のりかえ価格・\[期間限定\]のりかえ価格いずれかの端末の中から1台に限り適用となります。  <br>※ 同時に複数台をお申し込みの場合は、最も割引額が大きい端末ののりかえ価格が適用となります。  <br>※のりかえ価格は、予告なく変更・終了させていただく場合があります。 |
| 注意事項 | *   既にmioIDをお持ちの方が別のmioIDを取得してお申し込みの場合は、のりかえ価格の適用をお断りします。<br>*   音声eSIM（タイプD）にてお申し込みの場合、本人確認完了後30日以内に開通手続きが完了しない場合は回線のお申し込みがキャンセルとなり、のりかえ価格の適用を取り消し又は、支払い済ののりかえ価格と通常価格の差額を請求します。<br>*   お申し込み完了後、回線が利用開始されない等お客様の事由により契約が成立しない場合、のりかえ価格の適用を取り消し又は、支払い済ののりかえ価格と通常価格の差額を請求します。<br><br>  <br><br>#### 【キャンペーン対象外となるお申し込み】<br><br>*   量販店やネットショップなどで購入したパッケージ（エントリーコード・パスコード）を利用してお申し込みされた場合。<br>*   JALモバイルをお申し込みされた場合。<br>*   価格.comおよびBIC SIM.comを経由してお申し込みをされた場合。<br>*   お申込日より過去1年の間に、「MNP回線と対象端末をセット申込で特別価格（キャンペーン含む）」が適用済の場合。他キャンペーンで実施中の”MNP回線と対象端末をセット申込で特別価格”とも併用できません。<br>*   初期契約解除制度を利用し、契約解除をした場合。 |
| その他 | *   転売目的のご購入と判断し得る場合、申込をお断りさせていただくことがございます。また、申込完了後であっても当社はのりかえ価格の提供を取消し、割引相当額を別途請求させていただくことがございます。  <br>    （例）お申し込み日からの直近1年以内に、音声SIM/音声eSIMを多回線解約されている場合など。  <br>    （例）同一世帯・ 同一住所に属する複数人の方がそれぞれ複数の端末を購入される場合など。 |
| よくある質問 | #### 端末を複数台購入される場合<br><br>**Q1**：MNP転入の音声SIMを2回線とのりかえ価格の対象端末を2台、同時に申し込もうと思います。1回線目と2回線目を異なる「SIM利用者（名義）」で申し込む場合、2台とも割引は適用されますか。  <br>**A1**：いいえ。割引の適用はご契約者「お一人（mioID）様あたり1台まで」となります。割引額が大きい端末をのりかえ価格でご購入いただけます。  <br><br>* * *<br><br>**Q2**：MNP転入の音声SIMとのりかえ価格の対象端末【1台目】を同時に申し込みました。その後、より割引額の大きいのりかえ価格の対象端末【2台目】をMNP転入の音声SIM同時に申し込みました。どちらの割引が適用されますか。  <br>**A2**：【1台目】の割引が適用されます。【1台目】のお申込みが完了した時点で、「お一人（mioID）様あたり1台まで」の条件が適用されたものといたします。  <br><br>* * *<br><br>**Q3**：すでにIIJmioのサイトでスマートフォンを購入したことがあります。追加契約でMNP転入の音声SIMとのりかえ価格の対象端末を同時に申し込む場合、割引は適用されますか。  <br>**A3**：お申し込み日より過去1年の間に、「MNP転入の音声SIMとセットで特別価格」のキャンペーンまたはのりかえ価格を利用してお申し込みいただいたことがある方はのりかえ価格の対象外となります。（端末のみ購入の際の割引や、端末購入でギフト券プレゼント等、MNP転入の音声SIMが申込条件となっていないキャンペーンのみ適用された方は、割引が適用されます。）  <br>  <br><br>#### パッケージやIIJmioサイト以外より購入される場合<br><br>**Q1**：量販店やネットショップなどで購入したパッケージを使ってMNP転入の音声SIMと対象端末を申し込んだ場合、端末をのりかえ価格で購入することはできますか。  <br>**A1**：いいえ、できません。対象端末をのりかえ価格で購入するには、パッケージを利用せずにIIJmioのWebサイトからMNP転入の音声SIMと対象端末を同時に購入する必要があります。  <br><br>* * *<br><br>**Q2**：量販店やIIJmio以外のネットショップで対象端末と同機種を購入した場合、のりかえ価格は適用されますか。  <br>**A2**：いいえ。 IIJmioのWebサイトで対象端末を購入（※）した場合のみ、のりかえ価格が適用されます。  <br>※IIJmioサプライサービス  <br>  <br><br>#### 既にIIJmioモバイルサービスをご利用中の場合<br><br>**Q1**：現在IIJmioのMNP転入の音声SIMを契約中です。のりかえ価格の対象端末のみ購入する場合、割引は適用されますか。  <br>**A1**：いいえ。のりかえ価格でご購入いただくには、新規にご契約されるMNP転入の音声SIMと対象端末を同時にお申し込みいただく必要があります。  <br><br>* * *<br><br>**Q2**：「データSIM」から「MNP転入の音声SIM」へのSIMカード変更と同時に、のりかえ価格対象端末を購入しようと思います。対象端末は割引されますか。  <br>**A2**：いいえ。SIMカード変更と対象端末の購入ではのりかえ価格の対象にはなりません。  <br><br>* * *<br><br>**Q3**：既に持っているmioIDで新たに契約した場合、割引は適用されますか。  <br>**A3**：既にお持ちのmioIDでログインした上で、新しくMNP転入の音声SIMと対象端末をセットで購入された場合、割引は適用されます。  <br>※既にmioIDをお持ちの方が新しいmioIDを発行してお申し込みの場合は、のりかえ価格の対象外となります。 |

*   ※金額は全て税込で表記しています。
*   ※記載されている商品名、会社名等は各会社の商号、商標または登録商標です。本文中では™、®マークは表記しておりません。
*   ※Apple、Appleのロゴ、iPhone、iPad、iPad Pro、AppleCare、AppleCare+は米国およびその他の国々で登録されたApple Inc.の商標です。 iPhone 商標は、アイホン株式会社のライセンスに基づき使用されています。
*   ※Amazon、Amazonのロゴ、Amazon.co.jp、Amazon.co.jpのロゴは、Amazon.com,Inc.またはその関連会社の商標です。
*   ※「キャッチホン」はNTT株式会社の商標登録です。

*   [![IIJmioの申込にあたってのご注意](https://www.iijmio.jp/image/topbnr/footer-caution.png)](https://www.iijmio.jp/hdd/care/)
    
*   [![IIJmioが選ばれる6つの理由](https://www.iijmio.jp/image/topbnr/footer-03_B.jpg)](https://www.iijmio.jp/hdd/award/)
    
*   [![通話定額オプション](https://www.iijmio.jp/image/topbnr/footer-voicefree.png)](https://www.iijmio.jp/mobile/voicefree/)
    
*   [![Happy mio Life](https://www.iijmio.jp/image/topbnr/footer-happymiolife.png)](https://www.iijmio.jp/hml/)
    

*   [このサイトのご利用について](https://www.iijmio.jp/thissite/)
    
*   [情報セキュリティ基本方針](http://www.iij.ad.jp/securitypolicy/)
    
*   [サイトマップ](https://www.iijmio.jp/sitemap.html)
    
*   [初期契約解除について](https://www.iijmio.jp/member/cancellation/)
    

*   [個人情報保護ポリシー](http://www.iij.ad.jp/privacy/)
    
*   [「特定商取引に関する法律」「古物営業法」に基づく表示](https://www.iijmio.jp/tokusho/)
    
*   [お問い合わせ](https://www.iijmio.jp/contact.html)
    

[![プライバシーマーク](https://www.iijmio.jp/image/pmark.png)](https://privacymark.jp/)

[![page top](https://www.iijmio.jp/image/page-top.png)](https://www.iijmio.jp/gigaplan/#top)

[![IIJ](https://www.iijmio.jp/image/footer-logo.jpg)](http://www.iij.ad.jp/)

IIJmioは株式会社インターネットイニシアティブが提供する個人向けインターネットサービスです

[企業情報はこちら](http://www.iij.ad.jp/company/)

©2005-2025 Internet Initiative Japan Inc.

〒102-0071　東京都千代田区富士見2-10-2　飯田橋グラン・ブルーム  
届出番号(電気通信事業者)：第A-16-7006号  
代理店届出番号：第C2002871号

[![twitter](https://www.iijmio.jp/image/footer-sns-icon-01.jpg)](http://twitter.com/share?url=https://www.iijmio.jp/gigaplan/&amp;text=%E3%82%AE%E3%82%AC%E3%83%97%E3%83%A9%E3%83%B3%20%7C%20%E6%A0%BC%E5%AE%89SIM/%E6%A0%BC%E5%AE%89%E3%82%B9%E3%83%9E%E3%83%9B%E3%81%AEIIJmio)
 [![hatena](https://www.iijmio.jp/image/footer-sns-icon-02.jpg)](http://b.hatena.ne.jp/append?https://www.iijmio.jp/gigaplan/)

©2005-2025 Internet Initiative Japan Inc.

    

![](https://s3.karakuri.ai/images/iijmio/card-52fd33cb-6907-4471-8187-01add79eda52.png?w=200)
