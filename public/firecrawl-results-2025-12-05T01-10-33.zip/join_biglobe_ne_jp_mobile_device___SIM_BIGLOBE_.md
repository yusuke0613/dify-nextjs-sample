# 端末一覧｜格安SIM/スマホのBIGLOBEモバイル

URL: https://join.biglobe.ne.jp/mobile/device/

---

*   サービス
    
    サービス
    
    *   [![BIGLOBE光](https://top.bcdn.jp/images/ImgService-1.png)](https://join.biglobe.ne.jp/ftth/hikari/?cl=global_header_hikari_logo)
        
    *   [![BIGLOBE mobile](https://top.bcdn.jp/images/ImgService-2.png)](https://join.biglobe.ne.jp/mobile/?cl=global_header_mobile_logo)
        
    *   [![BIGLOBE WiMAX](https://top.bcdn.jp/images/ImgService-3.png)](https://join.biglobe.ne.jp/mobile/wimax/?cl=global_header_wimax_logo)
        
    *   [![BIGLOBE biz](https://top.bcdn.jp/images/ImgService-4.png)](https://biz.biglobe.ne.jp/index.html)
        
    
    通信サービス
    
    *   [BIGLOBE光](https://join.biglobe.ne.jp/ftth/hikari/?cl=global_header_hikari_text)
        
    *   [auひかり](https://join.biglobe.ne.jp/ftth/one/?cl=global_header_one_text)
        
    *   [BIGLOBEモバイル](https://join.biglobe.ne.jp/mobile/?cl=global_header_mobile_text)
        
    *   [BIGLOBE WiMAX](https://join.biglobe.ne.jp/mobile/wimax/?cl=global_header_wimax_text)
        
    
    オプションサービス
    
    *   [お助けサポート＋](https://otasuke.biglobe.ne.jp/otasuke_plus/)
        
    *   [インターネット端末保証サービス](https://service.biglobe.ne.jp/internethosho/)
        
    *   [トータル・ネットセキュリティ](https://security.biglobe.ne.jp/tns/)
        
    *   [U-NEXT for BIGLOBE](https://vod.biglobe.ne.jp/unext/)
        
    *   [その他オプション](https://service.biglobe.ne.jp/)
        
    
    Webメディア
    
    *   [温泉大賞](https://biz.biglobe.ne.jp/onsen/award/)
        
    *   [しむぐらし](https://join.biglobe.ne.jp/mobile/sim/gurashi/)
        
    *   [あしたメディア](https://ashita.biglobe.co.jp/)
        
    
    法人のお客さま
    
    *   [BIGLOBE biz.](https://biz.biglobe.ne.jp/index.html)
        
    
*   企業情報
    
    企業情報
    
    *   [![](https://top.bcdn.jp/images/ImgCompany-1.png)\
        \
        企業情報トップ](https://www.biglobe.co.jp/outline)
        
    *   [![](https://top.bcdn.jp/images/ImgCompany-2.png)\
        \
        採用情報](https://www.biglobe.co.jp/recruit)
        
    *   [![](https://top.bcdn.jp/images/ImgCompany-3.png)\
        \
        ブランド](https://www.biglobe.co.jp/outline/brand)
        
    
*   [](https://mypage.sso.biglobe.ne.jp/?cl=global_header_mypage)
    

[メニュー 閉じる](https://join.biglobe.ne.jp/mobile/device/)

[![BIGLOBE mobile](https://join.biglobe.ne.jp/v4/image/header/logo_mobile.svg?v=69e3c7748a)](https://join.biglobe.ne.jp/mobile/?cl=head_logo_mobile)

詳細を確認して

[お申し込み](https://join.biglobe.ne.jp/mobile/prepare/?cl=head_mobile_order)

*   [BIGLOBEモバイルTOP](https://join.biglobe.ne.jp/mobile/?cl=head_mobile_top)
    
*   料金プラン
    
    *   [料金プラン](https://join.biglobe.ne.jp/mobile/plan/?cl=head_mobile_plan_list)
        
    *   [BIGLOBE家族割](https://join.biglobe.ne.jp/mobile/plan/family/?cl=head_mobile_family)
        
    *   [シェアSIM](https://join.biglobe.ne.jp/mobile/plan/share-sim/?cl=head_mobile_share-sim)
        
    *   [ぴったりプラン診断](https://join.biglobe.ne.jp/mobile/plan/navigator/?cl=head_mobile_navigator)
        
*   端末
    
    *   [端末一覧](https://join.biglobe.ne.jp/mobile/device/?cl=head_mobile_device)
        
    *   [機種変更](https://join.biglobe.ne.jp/mobile/device/change.html?cl=head_mobile_change)
        
*   [動作確認端末](https://join.biglobe.ne.jp/mobile/device/compatibility.html?cl=head_mobile_device_comp)
    
*   オプション
    
    *   [オプション一覧](https://join.biglobe.ne.jp/mobile/option/?cl=head_mobile_option_list)
        
    *   [エンタメフリー・オプション](https://join.biglobe.ne.jp/mobile/option/entamefree.html?cl=head_mobile_option_entame)
        
    *   [選べる通話オプション](https://join.biglobe.ne.jp/mobile/option/bigtel.html?cl=head_mobile_option_call)
        
    *   [SIM端末保証サービス](https://join.biglobe.ne.jp/mobile/option/simhosho.html?cl=head_mobile_option_simhosho)
        
    *   [セキュリティセット・プレミアム](https://join.biglobe.ne.jp/mobile/option/security_set.html?cl=head_mobile_option_security_set)
        
*   [キャンペーン](https://join.biglobe.ne.jp/mobile/campaign/?cl=head_mobile_campaign)
    
*   申込ガイド
    
    *   [申込ガイド](https://join.biglobe.ne.jp/mobile/support/?cl=head_mobile_support_list)
        
    *   [まるわかりガイド](https://join.biglobe.ne.jp/mobile/support/guide/?cl=head_mobile_support_guide)
        
    *   [よくある質問](https://join.biglobe.ne.jp/mobile/support/faq.html?cl=head_mobile_support_faq)
        
    *   [ご利用までの流れ](https://join.biglobe.ne.jp/mobile/prepare/?cl=head_mobile_support_prepare#prepare_flow)
        
    *   [他社からのお乗り換え(MNP)](https://join.biglobe.ne.jp/mobile/prepare/mnp.html?cl=head_mobile_support_mnp)
        
*   店舗
    
    *   [店舗のご紹介](https://join.biglobe.ne.jp/mobile/shop/?cl=head_mobile_shop_info)
        
    *   [店舗検索](https://join.biglobe.ne.jp/mobile/shop/search.html?cl=head_mobile_shop_search)
        
*   詳細を確認して
    
    [詳細を確認してお申し込み](https://join.biglobe.ne.jp/mobile/prepare/?cl=head_mobile_order)
    

端末一覧

BIGLOBEモバイルの販売端末一覧です。端末はすべて24回の分割払いとなります。

SIMとセット購入

[機種変更  \
(端末のみ購入)](https://join.biglobe.ne.jp/mobile/device/change.html)

[![](https://join.biglobe.ne.jp/v4/image/mobile/icon/search.svg)\
\
端末を絞り込む\
-------\
\
詳細絞り込み](https://join.biglobe.ne.jp/mobile/device/#form)

並び替え

*    オススメ順
*    発売日順
*    料金順
*    メーカー順

機能

*   [ ]  電池持ち
*   [ ]  フルHD以上
*   [ ]  防水
*   [ ]  5G
*   [ ]  おサイフケータイ＊
*   [ ]  デュアルスタンバイ

該当端末数1件

*   おサイフケータイ機能またはApple Pay機能対応

*   [スマートフォン](https://join.biglobe.ne.jp/mobile/device/#android)
    
*   [タブレット・ルーター](https://join.biglobe.ne.jp/mobile/device/#tablet_router)
    
*   [メーカー別](https://join.biglobe.ne.jp/mobile/device/#maker_list)
    

 [![](https://join.biglobe.ne.jp/v4/image/mobile/icon/pdf.svg?v=828cb90325) 端末比較一覧 PDF ![](https://join.biglobe.ne.jp/v4/image/mobile/icon/download.svg?v=1927b62dc2)](https://join.biglobe.ne.jp/mobile/device/doc/product_lineup.pdf)
 

スマートフォン
-------

![NEW](https://join.biglobe.ne.jp/v4/image/mobile/device/common/ribbon_new.svg?v=e9538c089f) ![販売終了](https://join.biglobe.ne.jp/v4/image/mobile/device/common/ribbon_end.svg?v=603bef4b15) ![入荷待ち](https://join.biglobe.ne.jp/v4/image/mobile/device/common/ribbon_waiting.svg?v=8650632115) ![発売予定](https://join.biglobe.ne.jp/v4/image/mobile/device/common/ribbon_ready.svg?v=fa176389ec)[*   A\
*   D\
\
![OPPO Reno13 A](https://join.biglobe.ne.jp/v4/image/mobile/device/oppo_reno13_a/list@2x.png?v=28e71cc220)\
\
OPPO Reno13 A\
\
*   ![カメラ5000万画素](https://join.biglobe.ne.jp/v4/image/mobile/device/common/spec/resolution-5000.svg?v=eb0d6ccd7b)\
*   ![大容量バッテリー](https://join.biglobe.ne.jp/v4/image/mobile/device/common/spec/battery.svg?v=ada1798a5c)\
*   ![デュアルスタンバイ](https://join.biglobe.ne.jp/v4/image/mobile/device/common/spec/dsds.svg?v=f0c31c7265)\
*   ![防水](https://join.biglobe.ne.jp/v4/image/mobile/device/common/spec/waterproof.svg?v=2446583e41)\
*   ![おサイフ](https://join.biglobe.ne.jp/v4/image/mobile/device/common/spec/wallet.svg?v=5f3852fb8d)\
*   ![5G](https://join.biglobe.ne.jp/v4/image/mobile/device/common/spec/5g.svg?v=c1c5df2971)\
\
24回払い  \
1,840円 (税込2,024円)\
\
総額 44,160円 (税込48,576円)](https://join.biglobe.ne.jp/mobile/device/oppo_reno13_a.html)

![NEW](https://join.biglobe.ne.jp/v4/image/mobile/device/common/ribbon_new.svg?v=e9538c089f) ![販売終了](https://join.biglobe.ne.jp/v4/image/mobile/device/common/ribbon_end.svg?v=603bef4b15) ![入荷待ち](https://join.biglobe.ne.jp/v4/image/mobile/device/common/ribbon_waiting.svg?v=8650632115) ![発売予定](https://join.biglobe.ne.jp/v4/image/mobile/device/common/ribbon_ready.svg?v=fa176389ec)[*   A\
*   D\
\
![Redmi Note 14 Pro 5G](https://join.biglobe.ne.jp/v4/image/mobile/device/redmi_note_14_pro_5g/list@2x.png?v=3bffa946e9)\
\
Redmi Note 14 Pro 5G\
\
*   ![カメラ20000万画素](https://join.biglobe.ne.jp/v4/image/mobile/device/common/spec/resolution-20000.svg?v=e1e6bdafdb)\
*   ![大容量バッテリー](https://join.biglobe.ne.jp/v4/image/mobile/device/common/spec/battery.svg?v=ada1798a5c)\
*   ![デュアルスタンバイ](https://join.biglobe.ne.jp/v4/image/mobile/device/common/spec/dsds.svg?v=f0c31c7265)\
*   ![防水](https://join.biglobe.ne.jp/v4/image/mobile/device/common/spec/waterproof.svg?v=2446583e41)\
*   ![5G](https://join.biglobe.ne.jp/v4/image/mobile/device/common/spec/5g.svg?v=c1c5df2971)\
\
24回払い  \
1,740円 (税込1,914円)\
\
総額 41,760円 (税込45,936円)](https://join.biglobe.ne.jp/mobile/device/redmi_note_14_pro_5g.html)

![NEW](https://join.biglobe.ne.jp/v4/image/mobile/device/common/ribbon_new.svg?v=e9538c089f) ![販売終了](https://join.biglobe.ne.jp/v4/image/mobile/device/common/ribbon_end.svg?v=603bef4b15) ![入荷待ち](https://join.biglobe.ne.jp/v4/image/mobile/device/common/ribbon_waiting.svg?v=8650632115) ![発売予定](https://join.biglobe.ne.jp/v4/image/mobile/device/common/ribbon_ready.svg?v=fa176389ec)[*   A\
*   D\
\
![moto g05](https://join.biglobe.ne.jp/v4/image/mobile/device/moto_g05/list@2x.png?v=a421c1ec63)\
\
moto g05\
\
*   ![カメラ5000万画素](https://join.biglobe.ne.jp/v4/image/mobile/device/common/spec/resolution-5000.svg?v=eb0d6ccd7b)\
*   ![大容量バッテリー](https://join.biglobe.ne.jp/v4/image/mobile/device/common/spec/battery.svg?v=ada1798a5c)\
*   ![デュアルスタンバイ](https://join.biglobe.ne.jp/v4/image/mobile/device/common/spec/dsds.svg?v=f0c31c7265)\
\
24回払い  \
780円 (税込858円)\
\
総額 18,720円 (税込20,592円)](https://join.biglobe.ne.jp/mobile/device/moto_g05.html)

![販売終了](https://join.biglobe.ne.jp/v4/image/mobile/device/common/ribbon_end.svg?v=603bef4b15) ![入荷待ち](https://join.biglobe.ne.jp/v4/image/mobile/device/common/ribbon_waiting.svg?v=8650632115) ![発売予定](https://join.biglobe.ne.jp/v4/image/mobile/device/common/ribbon_ready.svg?v=fa176389ec)[*   A\
*   D\
\
![AQUOS sense9](https://join.biglobe.ne.jp/v4/image/mobile/device/aquos_sense9/list@2x.png?v=5d32002428)\
\
AQUOS sense9\
\
*   ![カメラ5030万画素](https://join.biglobe.ne.jp/v4/image/mobile/device/common/spec/resolution-5030.svg?v=c885f81e0b)\
*   ![大容量バッテリー](https://join.biglobe.ne.jp/v4/image/mobile/device/common/spec/battery.svg?v=ada1798a5c)\
*   ![デュアルスタンバイ](https://join.biglobe.ne.jp/v4/image/mobile/device/common/spec/dsds.svg?v=f0c31c7265)\
*   ![防水](https://join.biglobe.ne.jp/v4/image/mobile/device/common/spec/waterproof.svg?v=2446583e41)\
*   ![おサイフ](https://join.biglobe.ne.jp/v4/image/mobile/device/common/spec/wallet.svg?v=5f3852fb8d)\
*   ![5G](https://join.biglobe.ne.jp/v4/image/mobile/device/common/spec/5g.svg?v=c1c5df2971)\
\
24回払い  \
2,200円 (税込2,420円)\
\
総額 52,800円 (税込58,080円)](https://join.biglobe.ne.jp/mobile/device/aquos_sense9.html)

![販売終了](https://join.biglobe.ne.jp/v4/image/mobile/device/common/ribbon_end.svg?v=603bef4b15) ![入荷待ち](https://join.biglobe.ne.jp/v4/image/mobile/device/common/ribbon_waiting.svg?v=8650632115) ![発売予定](https://join.biglobe.ne.jp/v4/image/mobile/device/common/ribbon_ready.svg?v=fa176389ec)[*   A\
*   D\
\
![Xperia 10 VI](https://join.biglobe.ne.jp/v4/image/mobile/device/xperia10m6/list@2x.png?v=1133c60a25)\
\
Xperia 10 VI\
\
*   ![カメラ4800万画素](https://join.biglobe.ne.jp/v4/image/mobile/device/common/spec/resolution-4800.svg?v=28ab835ed5)\
*   ![大容量バッテリー](https://join.biglobe.ne.jp/v4/image/mobile/device/common/spec/battery.svg?v=ada1798a5c)\
*   ![デュアルスタンバイ](https://join.biglobe.ne.jp/v4/image/mobile/device/common/spec/dsds.svg?v=f0c31c7265)\
*   ![防水](https://join.biglobe.ne.jp/v4/image/mobile/device/common/spec/waterproof.svg?v=2446583e41)\
*   ![おサイフ](https://join.biglobe.ne.jp/v4/image/mobile/device/common/spec/wallet.svg?v=5f3852fb8d)\
*   ![5G](https://join.biglobe.ne.jp/v4/image/mobile/device/common/spec/5g.svg?v=c1c5df2971)\
\
24回払い  \
2,620円 (税込2,882円)\
\
総額 62,880円 (税込69,168円)](https://join.biglobe.ne.jp/mobile/device/xperia10m6.html)

![販売終了](https://join.biglobe.ne.jp/v4/image/mobile/device/common/ribbon_end.svg?v=603bef4b15) ![入荷待ち](https://join.biglobe.ne.jp/v4/image/mobile/device/common/ribbon_waiting.svg?v=8650632115) ![発売予定](https://join.biglobe.ne.jp/v4/image/mobile/device/common/ribbon_ready.svg?v=fa176389ec)[*   A\
*   D\
\
![Redmi 12 5G](https://join.biglobe.ne.jp/v4/image/mobile/device/redmi_12_5g/list@2x.png?v=83bfb7d30d)\
\
Redmi 12 5G\
\
*   ![カメラ5000万画素](https://join.biglobe.ne.jp/v4/image/mobile/device/common/spec/resolution-5000.svg?v=eb0d6ccd7b)\
*   ![大容量バッテリー](https://join.biglobe.ne.jp/v4/image/mobile/device/common/spec/battery.svg?v=ada1798a5c)\
*   ![デュアルスタンバイ](https://join.biglobe.ne.jp/v4/image/mobile/device/common/spec/dsds.svg?v=f0c31c7265)\
*   ![おサイフ](https://join.biglobe.ne.jp/v4/image/mobile/device/common/spec/wallet.svg?v=5f3852fb8d)\
*   ![5G](https://join.biglobe.ne.jp/v4/image/mobile/device/common/spec/5g.svg?v=c1c5df2971)\
\
24回払い  \
1,300円 (税込1,430円)\
\
総額 31,200円 (税込34,320円)](https://join.biglobe.ne.jp/mobile/device/redmi_12_5g.html)

該当する製品がありません。

タブレット・SIMフリールーター
----------------

![販売終了](https://join.biglobe.ne.jp/v4/image/mobile/device/common/ribbon_end.svg?v=603bef4b15) ![入荷待ち](https://join.biglobe.ne.jp/v4/image/mobile/device/common/ribbon_waiting.svg?v=8650632115) ![発売予定](https://join.biglobe.ne.jp/v4/image/mobile/device/common/ribbon_ready.svg?v=fa176389ec)[*   D\
\
![Aterm MR10LN　SW](https://join.biglobe.ne.jp/v4/image/mobile/device/aterm_mr10ln_sw/list@2x.png?v=6b88fc3fd0)\
\
Aterm MR10LN　SW\
\
*   ![大容量バッテリー](https://join.biglobe.ne.jp/v4/image/mobile/device/common/spec/battery.svg?v=ada1798a5c)\
\
24回払い  \
822円 (税込904円)\
\
総額 19,728円 (税込21,700円)](https://join.biglobe.ne.jp/mobile/device/aterm_mr10ln_sw.html)

該当する製品がありません。

*   支払期間25カ月・実質年率0%。機種変更/解約/退会時の残金については[こちら](https://join.biglobe.ne.jp/mobile/device/#balance_modal_0)
    

機種変更/解約/退会時の残金について

機種変更またはBIGLOBEモバイルを解約された場合も月々残金のお支払いが引き続き必要です。  
ただし、BIGLOBEを退会された場合は残金一括でのお支払いとなります。

閉じる

メーカー一覧
------

*   [Apple](https://join.biglobe.ne.jp/mobile/device/apple/)
    
*   [ASUS](https://join.biglobe.ne.jp/mobile/device/asus/)
    
*   [HUAWEI](https://join.biglobe.ne.jp/mobile/device/huawei/)
    
*   [LGエレクトロニクス](https://join.biglobe.ne.jp/mobile/device/lg/)
    
*   [MAYA SYSTEM](https://join.biglobe.ne.jp/mobile/device/mayasystem/)
    
*   [Motorola](https://join.biglobe.ne.jp/mobile/device/motorola/)
    
*   [NECプラットフォームズ](https://join.biglobe.ne.jp/mobile/device/nec/)
    
*   [OPPO](https://join.biglobe.ne.jp/mobile/device/oppo/)
    
*   [TCLコミュニケーション](https://join.biglobe.ne.jp/mobile/device/tcl/)
    
*   [Unihertz](https://join.biglobe.ne.jp/mobile/device/unihertz/)
    
*   [VAIO](https://join.biglobe.ne.jp/mobile/device/vaio/)
    
*   [Xiaomi](https://join.biglobe.ne.jp/mobile/device/xiaomi/)
    
*   [Xperia](https://join.biglobe.ne.jp/mobile/device/xperia/)
    
*   [シャープ](https://join.biglobe.ne.jp/mobile/device/sharp/)
    
*   [富士通コネクテッドテクノロジーズ](https://join.biglobe.ne.jp/mobile/device/fujitsu/)
    

[![5G 追加料金なしでご利用いただけます。※一部非対応。5Gは一部エリアとなります。5G対応端末とお手続きが必要です。](https://join.biglobe.ne.jp/v4/image/mobile/device/common/bnr_5g.png?v=8cea2fa194)](https://join.biglobe.ne.jp/mobile/area/?cl=mobile_device_index_5g)

よくある質問
------

*   [![](https://join.biglobe.ne.jp/v4/image/mobile/icon/icon_q.svg?v=30e24e98f4)\
    \
    今使っているSIMで新しい端末に変えたいです](https://join.biglobe.ne.jp/mobile/device/#faq_sim_continue)
    
    その場合は「機種変更」でのお申し込みとなります。  
    機種変更ページから購入したい端末を選び、「機種変更(端末のみ購入)」のボタンからお申し込みください。  
    お申し込みの際はお手持ちのSIMカードサイズをご確認ください。
    
    *   eSIMでご利用の場合は、eSIM対応の端末をお選びください。
    *   eSIMでご利用の端末を機種変更する際は、eSIMプロファイルの再発行手続きが必要となります。
    
    [機種変更 (BIGLOBEモバイル会員向け)](https://join.biglobe.ne.jp/mobile/device/change.html)
    
*   [![](https://join.biglobe.ne.jp/v4/image/mobile/icon/icon_q.svg?v=30e24e98f4)\
    \
    格安スマホでもテザリングはできますか？](https://join.biglobe.ne.jp/mobile/device/#faq_tethering)
    
    お手持ちの端末をご利用の場合
    
    大手携帯キャリアと同様にテザリングをご利用いただけます。  
    古いスマホなど一部の機種やOSのバージョンによっては利用できない場合もありますので、[動作確認端末](https://join.biglobe.ne.jp/mobile/device/compatibility.html)
    で対応状況をご確認ください。
    
    BIGLOBE販売端末の場合
    
    [BIGLOBEで販売中の端末](https://join.biglobe.ne.jp/mobile/device/)
    では、全端末テザリングをご利用いただけます。
    
*   [![](https://join.biglobe.ne.jp/v4/image/mobile/icon/icon_q.svg?v=30e24e98f4)\
    \
    BIGLOBEモバイルで購入した端末の保証はありますか？](https://join.biglobe.ne.jp/mobile/device/#faq_device_repair)
    
    はい、BIGLOBEモバイルでご購入いただいた端末は、すべてメーカー保証がついています。メーカー保証に関しては、端末ページ内にあるアフターサポートのメーカー窓口よりお問い合わせください。
    
    また、端末修理や保証などを受けられるオプションもご用意しています。
    
    *   BIGLOBE SIM端末保証サービス
        
        月額500円(税込550円)で、端末が破損や水没などで通信できなくなった際に、修理・交換費用を保証します(年2回まで)。中古端末もOK！
        
        *   交換対応はAndroid端末のみとなり、負担金あり。
        
        [BIGLOBE SIM端末保証サービスの詳細](https://join.biglobe.ne.jp/mobile/option/simhosho.html)
        
    

[もっとみる](https://join.biglobe.ne.jp/mobile/support/faq.html?cl=device_index_faqmore#category)

BIGLOBEモバイルで格安SIMをはじめよう

[料金プラン](https://join.biglobe.ne.jp/mobile/plan/)
をご確認ください。

[Webでお申し込み](https://join.biglobe.ne.jp/mobile/prepare/?cl=mobile_footcv_signup)

1.  ![home](https://join.biglobe.ne.jp/v4/image/icon/icon_home.svg)
2.  [BIGLOBEモバイルTOP](https://join.biglobe.ne.jp/mobile/)
    
3.  端末一覧
    ====
    

[サイトマップ](https://join.biglobe.ne.jp/sitemap.html)

[](https://www.biglobe.co.jp/outline/brand/bipple)

[](https://www.biglobe.ne.jp/)

*   [](https://twitter.com/biglobe)
    
*   [](https://www.instagram.com/biglobe_official/)
    
*   [](https://www.facebook.com/BIGLOBE)
    
*   [](https://www.youtube.com/user/BIGLOBEchannel)
    

個人のお客さま

通信サービス

*   [BIGLOBE光](https://join.biglobe.ne.jp/ftth/hikari/?cl=global_footer_hikari)
    
*   [auひかり](https://join.biglobe.ne.jp/ftth/one/?cl=global_footer_one)
    
*   [BIGLOBEモバイル](https://join.biglobe.ne.jp/mobile/?cl=global_footer_mobile)
    
*   [BIGLOBE WiMAX](https://join.biglobe.ne.jp/mobile/wimax/?cl=global_footer_wimax)
    

オプションサービス

*   [お助けサポート＋](https://otasuke.biglobe.ne.jp/otasuke_plus/)
    
*   [インターネット端末保証サービス](https://service.biglobe.ne.jp/internethosho/)
    
*   [トータル・ネットセキュリティ](https://security.biglobe.ne.jp/tns/)
    
*   [U-NEXT for BIGLOBE](https://vod.biglobe.ne.jp/unext/)
    
*   [その他オプション](https://service.biglobe.ne.jp/)
    

Webメディア

*   [温泉大賞](https://biz.biglobe.ne.jp/onsen/award/)
    
*   [しむぐらし](https://join.biglobe.ne.jp/mobile/sim/gurashi/)
    
*   [あしたメディア](https://ashita.biglobe.co.jp/)
    

法人のお客さま

*   [BIGLOBE biz.](https://biz.biglobe.ne.jp/index.html)
    
*   [BIGLOBE光](https://biz.biglobe.ne.jp/hikari/index.html)
    
*   [フレッツ光](https://biz.biglobe.ne.jp/flets/index.html)
    
*   [プロバイダサービス](https://biz.biglobe.ne.jp/member/office/provider.html)
    
*   [光回線用 固定IPアドレス](https://biz.biglobe.ne.jp/ip/index.html)
    
*   [BIGLOBEモバイル](https://biz.biglobe.ne.jp/sim/index.html)
    
*   [BIGLOBE WiMAX](https://biz.biglobe.ne.jp/wimax/index.html)
    
*   [IPトランジット](https://biz.biglobe.ne.jp/transit/index.html)
    
*   [マカフィー®マルチ アクセス](https://biz.biglobe.ne.jp/mma/index.html)
    
*   [法人向け独自ドメイン](https://biz.biglobe.ne.jp/domain/index.html)
    
*   [ONSENWORK](https://workation.biglobe.ne.jp/onsen/)
    

企業情報

*   [企業情報](https://www.biglobe.co.jp/outline)
    
*   [トップメッセージ](https://www.biglobe.co.jp/outline/message)
    
*   [ブランド](https://www.biglobe.co.jp/outline/brand)
    
*   [サステナビリティ](https://www.biglobe.co.jp/sustainability)
    
*   [ニュース](https://www.biglobe.co.jp/pressroom)
    
*   [採用情報](https://www.biglobe.co.jp/recruit)
    
*   [BIGLOBE Style](https://style.biglobe.co.jp/)
    
*   [ソーシャルメディア](https://www.biglobe.co.jp/social)
    

ご利用中の方

*   [マイページ](https://mypage.sso.biglobe.ne.jp/?cl=global_footer_mypage)
    
*   [メール](https://auth.sso.biglobe.ne.jp/mail/?cl=global_footer_mail)
    
*   [会員サポート](https://support.biglobe.ne.jp/?cl=global_footer_support)
    

*   [お問い合わせ](https://www.biglobe.co.jp/inquire)
    
*   [消費税の表示](https://support.biglobe.ne.jp/salestax.html)
    
*   [ウェブアクセシビリティの取り組み](https://support.biglobe.ne.jp/accessibility/)
    
*   [個人情報保護ポリシー](https://www.biglobe.ne.jp/privacy.html)
    
*   [プライバシーポータル](https://www.biglobe.ne.jp/privacy-portal.html)
    
*   [Cookieポリシー](https://www.biglobe.ne.jp/cookie.html)
    
*   [特定商取引法に基づく表記](https://support.biglobe.ne.jp/tokusyo.html)
    
*   [古物営業法に基づく表記](https://support.biglobe.ne.jp/kobutsusyo.html)
    
*   [情報セキュリティ基本方針](https://www.biglobe.co.jp/security)
    
*   [商標について](https://join.biglobe.ne.jp/trademark/)
    
*   [BIGLOBEトップ](https://www.biglobe.ne.jp/)
    

[![プライバシーマーク](https://top.bcdn.jp/images/PrivacyMark.png)](https://privacymark.jp/)

[![セキュリティ認証](https://top.bcdn.jp/images/ISP.png)](https://www.biglobe.ne.jp/safesecurity.html)

[![ETOCマーク](https://top.bcdn.jp/images/ETOC.png)](https://www.etoc.jp/elite/0037)

Copyright ©BIGLOBE Inc. 2025. All rights reserved.

[ページトップへ](https://join.biglobe.ne.jp/mobile/device/#)
