# List of campaigns and benefits | J:COM

URL: https://www.jcom.co.jp/service/mobile/campaign/

---

[![あたらしいを、あたりまえに。 J:COM](https://www.jcom.co.jp/common_v10/images/logo-jcom-white.svg)](https://www.jcom.co.jp/en/?sc_pid=common_jcomlogo_01)

*   [Why J:COM](https://www.jcom.co.jp/en/beginner/?sc_pid=globalnavi_beginner_01)
    
*   Current customers
*   [Online Shop](https://onlineshop.jcom.co.jp/?sc_pid=globalnavi_ols_01)
    

J:COM Customers

[Check/Update Contract  \
My page login](https://mypage.jcom.co.jp/?sc_pid=common_mypage_01)
 [Troubleshooting/FAQ  \
Customer Support](https://cs.myjcom.jp/?sc_pid=common_suppot_01)
 [Enjoy J:COM even more  \
TV program information/presents and benefits  \
Fun! J:COM](https://www.myjcom.jp/?sc_pid=common_myj_01)

    ![検索](https://www.jcom.co.jp/common_v10/images/snav-icn-search-submit.svg)

*   [To you  \
    notice](https://id.zaq.ne.jp/id/script/connect/authz_req/endpoint.seam?response_type=code&client_id=JCOM_COJP&redirect_uri=https%3A%2F%2Fwww.jcom.co.jp%2Fcampaign%2F&scope=http%3A%2F%2Fjcom.co.jp%2Fconnect%2Fprofile%2Fstandard_new&nonce=1622199932&state=&prompt=)
    
*   [To you  \
    notice](https://www.jcom.co.jp/service/mobile/campaign/#)
    

Language

*   日本語
*   English
*   简体中文
*   한국어
*   Tiếng Việt
*   Português

*   Services
*   [Pricing](https://www.jcom.co.jp/en/price/)
    
*   [Promotions  \
    ​](https://www.jcom.co.jp/en/campaign/)
    
*   Sign Up /  
    Edit Account Info
*   Support
*   Company website

[Service Overview](https://www.jcom.co.jp/en/service/)

[TV,](https://www.jcom.co.jp/en/service/tv/)
 ​ ​[internet,](https://www.jcom.co.jp/en/service/net/)
 ​ ​[smartphone](https://www.jcom.co.jp/en/service/mobile/)
 [, electricity](https://www.jcom.co.jp/en/service/electricity/)
 ​ ​[Landline](https://www.jcom.co.jp/en/service/phone/)
 , [gas](https://www.jcom.co.jp/en/service/gas/)
 [,](https://www.jcom.co.jp/en/service/ssi/)
 insurance, [loan](https://www.jcom-financial.co.jp/)
 [, security camera,](https://www.jcom.co.jp/en/guide/starter/home_security/)
 ​ ​[Telemedicine](https://www.jcom.co.jp/en/service/telemedicine/)
 [, services for corporations and local governments![J:COM BUSINESS](https://www.jcom.co.jp/common_v10/images/logo_jcombusiness.webp)](https://business.jcom.co.jp/)

[Sign Up / Inquiries](https://www.jcom.co.jp/en/contactus/)

New customers

[New customers  \
Sign Up](https://onlineshop.jcom.co.jp/planSelect)

[New customers  \
Inquiries](https://www.jcom.co.jp/en/contactus/#entry)

J:COM Customers

[User  \
Various procedures](https://r.jcom.jp/eG4nLSC)

[Problems and inquiries  \
(chat)](https://prod8-live-chat.sprinklr.com/page?appId=67af27d73657336d345e4a96_app_9070639&did=CHAT_vivr_cojp_top&enableClose=true&skin=MODERN&userContext__c_679c8b53cb85b007fab0f6ea=DirectLink&utm_campaign=IVRSMS&utm_medium=referral&utm_source=did&webview=true&zoom=false)

Find the perfect plan for you

[Savings calculator](https://onlineshop.jcom.co.jp/Simulation/Simulation)

Some properties offer free or discounted options!

Covered areas & properties

[Company website](https://www.jcom.co.jp/en/corporate/)

[Corporate philosophy](https://www.jcom.co.jp/en/corporate/philosophy_brand/)

[Sustainability](https://www.jcom.co.jp/en/corporate/sustainability/)

[Medium-term management plan](https://www.jcom.co.jp/en/corporate/managementplan/)

[news release](https://newsreleases.jcom.co.jp/)

[Company Profile](https://www.jcom.co.jp/en/corporate/company/)

[Careers](https://recruit.jcom.co.jp/)

[Support Top](https://cs.myjcom.jp/)

[TV,](https://cs.myjcom.jp/categories/support/67ab976bf07f5244a208cb97)
 ​ ​[Internet,](https://cs.myjcom.jp/categories/support/67ab9788f07f5244a208cced)
 ​ ​[Smartphone](https://cs.myjcom.jp/categories/support/67ab979df07f5244a208cdc9)
 [, Electricity](https://cs.myjcom.jp/categories/support/67ab97b5f07f5244a208cec9)
 ​ ​[Landline](https://cs.myjcom.jp/categories/support/67ab97abf07f5244a208ce4e)
 [, Gas](https://cs.myjcom.jp/categories/support/67ab97b8f07f5244a208ceda)
 [, Insurance](https://cs.myjcom.jp/categories/support/67ab97c5f07f5244a208cf2f)
 ​ ​[Telemedicine](https://cs.myjcom.jp/categories/support/67ab97c2f07f5244a208cf1b)
 ​ ​[Home, IoT](https://cs.myjcom.jp/categories/support/67ab97bcf07f5244a208cee6)
 ​ ​[Security Camera](https://cs.myjcom.jp/categories/support/67ab97f5f07f5244a208d09b)

[J:COM STREAM](https://cs.myjcom.jp/categories/support/67ab97c9f07f5244a208cf49)

[Enkaku Support](https://cs.myjcom.jp/categories/support/67ab97faf07f5244a208d0c2)

[Home support](https://cs.myjcom.jp/categories/support/67ab97d4f07f5244a208cf92)

[Disaster prevention information service](https://cs.myjcom.jp/categories/support/67ab97d8f07f5244a208cfa0)

[Bicycle Life Support](https://cs.myjcom.jp/categories/support/67ab97e8f07f5244a208d023)

[J:COM Books](https://cs.myjcom.jp/categories/support/67ab97e4f07f5244a208d003)

[WiMAX](https://cs.myjcom.jp/categories/support/67ab97f1f07f5244a208d074)

[Trouble/maintenance information](https://information.myjcom.jp/maintenance_outage/)

Various procedures

[Personal ID](https://cs.myjcom.jp/categories/support/67ab9803f07f5244a208d113)

[Fees and Payment](https://cs.myjcom.jp/categories/support/67ab9805f07f5244a208d139)

[Moving and rebuilding](https://cs.myjcom.jp/categories/support/67ab980cf07f5244a208d184)

[Visits and counters](https://cs.myjcom.jp/categories/support/67ab980ff07f5244a208d1a4)

[Contract-related](https://cs.myjcom.jp/categories/support/67ab9806f07f5244a208d150)

[Suspension/cancellation](https://cs.myjcom.jp/categories/support/67ab980cf07f5244a208d188)

[Membership Benefits](https://cs.myjcom.jp/categories/support/67ab980df07f5244a208d18c)

[![あたらしいを、あたりまえに J:COM](https://www.jcom.co.jp/common_v10/images/logo-jcom-white.svg)](https://www.jcom.co.jp/en/?sc_pid=common_jcomlogo_01)

[![あたらしいを、あたりまえに J:COM](https://www.jcom.co.jp/common_v10/images/logo-jcom.svg)](https://www.jcom.co.jp/en/)

*   Services
*   [Pricing](https://www.jcom.co.jp/en/price/)
    
*   [Promotions  \
    ​](https://www.jcom.co.jp/en/campaign/)
    
*   Sign Up /  
    Edit Account Info
*   Support
*   Company website

![検索する](https://www.jcom.co.jp/common_v10/images/fixed-nav-icn-search.svg)

    ![検索](https://www.jcom.co.jp/common_v10/images/snav-icn-search-submit.svg)

[Service Overview](https://www.jcom.co.jp/en/service/)

[TV,](https://www.jcom.co.jp/en/service/tv/)
 ​ ​[internet,](https://www.jcom.co.jp/en/service/net/)
 ​ ​[smartphone](https://www.jcom.co.jp/en/service/mobile/)
 [, electricity](https://www.jcom.co.jp/en/service/electricity/)
 ​ ​[Landline](https://www.jcom.co.jp/en/service/phone/)
 , [gas](https://www.jcom.co.jp/en/service/gas/)
 [,](https://www.jcom.co.jp/en/service/ssi/)
 insurance, [loan](https://www.jcom-financial.co.jp/)
 [, security camera,](https://www.jcom.co.jp/en/guide/starter/home_security/)
 ​ ​[Telemedicine](https://www.jcom.co.jp/en/service/telemedicine/)
 [, services for corporations and local governments![J:COM BUSINESS](https://www.jcom.co.jp/common_v10/images/logo_jcombusiness.webp)](https://business.jcom.co.jp/)

[Sign Up / Inquiries](https://www.jcom.co.jp/en/contactus/)

New customers

[New customers  \
Sign Up](https://onlineshop.jcom.co.jp/planSelect)

[New customers  \
Inquiries](https://www.jcom.co.jp/en/contactus/#entry)

J:COM Customers

[User  \
Various procedures](https://r.jcom.jp/eG4nLSC)

[Problems and inquiries  \
(chat)](https://prod8-live-chat.sprinklr.com/page?appId=67af27d73657336d345e4a96_app_9070639&did=CHAT_vivr_cojp_top&enableClose=true&skin=MODERN&userContext__c_679c8b53cb85b007fab0f6ea=DirectLink&utm_campaign=IVRSMS&utm_medium=referral&utm_source=did&webview=true&zoom=false)

Find the perfect plan for you

[Savings calculator](https://onlineshop.jcom.co.jp/Simulation/Simulation)

Some properties offer free or discounted options!

Covered areas & properties

[Company website](https://www.jcom.co.jp/en/corporate/)

[Corporate philosophy](https://www.jcom.co.jp/en/corporate/philosophy_brand/)

[Sustainability](https://www.jcom.co.jp/en/corporate/sustainability/)

[Medium-term management plan](https://www.jcom.co.jp/en/corporate/managementplan/)

[news release](https://newsreleases.jcom.co.jp/)

[Company Profile](https://www.jcom.co.jp/en/corporate/company/)

[Careers](https://recruit.jcom.co.jp/)

[Support Top](https://cs.myjcom.jp/)

[TV,](https://cs.myjcom.jp/categories/support/67ab976bf07f5244a208cb97)
 ​ ​[Internet,](https://cs.myjcom.jp/categories/support/67ab9788f07f5244a208cced)
 ​ ​[Smartphone](https://cs.myjcom.jp/categories/support/67ab979df07f5244a208cdc9)
 [, Electricity](https://cs.myjcom.jp/categories/support/67ab97b5f07f5244a208cec9)
 ​ ​[Landline](https://cs.myjcom.jp/categories/support/67ab97abf07f5244a208ce4e)
 [, Gas](https://cs.myjcom.jp/categories/support/67ab97b8f07f5244a208ceda)
 [, Insurance](https://cs.myjcom.jp/categories/support/67ab97c5f07f5244a208cf2f)
 ​ ​[Telemedicine](https://cs.myjcom.jp/categories/support/67ab97c2f07f5244a208cf1b)
 ​ ​[Home, IoT](https://cs.myjcom.jp/categories/support/67ab97bcf07f5244a208cee6)
 ​ ​[Security Camera](https://cs.myjcom.jp/categories/support/67ab97f5f07f5244a208d09b)

[J:COM STREAM](https://cs.myjcom.jp/categories/support/67ab97c9f07f5244a208cf49)

[Enkaku Support](https://cs.myjcom.jp/categories/support/67ab97faf07f5244a208d0c2)

[Home support](https://cs.myjcom.jp/categories/support/67ab97d4f07f5244a208cf92)

[Disaster prevention information service](https://cs.myjcom.jp/categories/support/67ab97d8f07f5244a208cfa0)

[Bicycle Life Support](https://cs.myjcom.jp/categories/support/67ab97e8f07f5244a208d023)

[J:COM Books](https://cs.myjcom.jp/categories/support/67ab97e4f07f5244a208d003)

[WiMAX](https://cs.myjcom.jp/categories/support/67ab97f1f07f5244a208d074)

[Trouble/maintenance information](https://information.myjcom.jp/maintenance_outage/)

Various procedures

[Personal ID](https://cs.myjcom.jp/categories/support/67ab9803f07f5244a208d113)

[Fees and Payment](https://cs.myjcom.jp/categories/support/67ab9805f07f5244a208d139)

[Moving and rebuilding](https://cs.myjcom.jp/categories/support/67ab980cf07f5244a208d184)

[Visits and counters](https://cs.myjcom.jp/categories/support/67ab980ff07f5244a208d1a4)

[Contract-related](https://cs.myjcom.jp/categories/support/67ab9806f07f5244a208d150)

[Suspension/cancellation](https://cs.myjcom.jp/categories/support/67ab980cf07f5244a208d188)

[Membership Benefits](https://cs.myjcom.jp/categories/support/67ab980df07f5244a208d18c)

*   ![メニュー](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/text-menu.svg)
*   ![お申し込み](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/text-entry.svg)
*   ![テレビ](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/text-jcom-tv.svg)
*   ![ネット](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/text-jcom-net.svg)
*   ![スマホ](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/text-jcom-mobile.svg)
*   ![電気](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/text-jcom-electricity.svg)
*   ![その他のサービス](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/text-other.svg)
*   [![サポート](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/text-support.svg)](https://cs.myjcom.jp/)
    

*   [![あたらしいを、あたりまえに　J:COM](https://www.jcom.co.jp/common_v10/images/logo-jcom-only-white.svg)](https://www.jcom.co.jp/en/)
     ![メニューを閉じる](https://www.jcom.co.jp/common_v10/images/sp-menu/menu-close-white.svg)
    
    [J:COM Services](https://www.jcom.co.jp/en/service/)
    
    *   [![テレビ](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-tv-item.svg)](https://www.jcom.co.jp/en/service/tv/)
        
    *   [![ネット](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-net-item.svg)](https://www.jcom.co.jp/en/service/net/)
        
    *   [![スマホ](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-mobile-item.svg)](https://www.jcom.co.jp/en/service/mobile/)
        
    
    *   [![電気](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-electricity-item.svg)](https://www.jcom.co.jp/en/service/electricity/)
        
    *   [![固定電話](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-phone-item.svg)](https://www.jcom.co.jp/en/service/phone/)
        
    *   [![ガス](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-gas-item.svg)](https://www.jcom.co.jp/en/service/gas/)
        
    *   [![ほけん](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-ssi-item.svg)](https://www.jcom.co.jp/en/service/ssi/)
        
    *   [loan](https://www.jcom-financial.co.jp/)
        
    *   [![ホームIoT](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-home-item.svg)](https://www.jcom.co.jp/en/service/home/)
        
    *   [security cameras](https://www.jcom.co.jp/en/guide/starter/home_security/)
        
    *   [![オンライン診療](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-telemedicine-item.svg)](https://www.jcom.co.jp/en/service/telemedicine/)
        
    
    [Services for corporations and local governments  \
    ![J:COM BUSINESS](https://www.jcom.co.jp/common_v10/images/logo_jcombusiness.webp)](https://business.jcom.co.jp/)
    
    Service overview
    
    [Price List](https://www.jcom.co.jp/en/price/)
     [Promotions/Benefits](https://www.jcom.co.jp/en/campaign/)
     [Support](https://cs.myjcom.jp/)
     [Application/Various Changes](https://www.jcom.co.jp/en/contactus/)
    
        ![検索](https://www.jcom.co.jp/common_v10/images/snav-icn-search-submit-sp.svg)
    
    [J:COM Top](https://www.jcom.co.jp/en/)
    
    *   [Service Information](https://www.jcom.co.jp/en/)
        
    *   [Online  \
        Shop](https://onlineshop.jcom.co.jp/)
        
    *   [Support](https://cs.myjcom.jp/)
        
    *   [Fun! J:COM](https://www.myjcom.jp/)
        
    *   [My page](https://mypage.jcom.co.jp/)
        
    *   [Company website](https://www.jcom.co.jp/en/corporate/)
        
    
*   [Sign Up / Inquiries](https://www.jcom.co.jp/en/contactus/)
     ![メニューを閉じる](https://www.jcom.co.jp/common_v10/images/sp-menu/menu-close.svg)
    
    New customers
    
    [New Customers Sign Up](https://onlineshop.jcom.co.jp/planSelect)
     [New Customers Inquiries](https://www.jcom.co.jp/en/contactus/#entry)
    
    Find the perfect  
    plan for you
    
    Some properties offer free  
    or discounted options!
    
    [Savings  \
     calculator](https://onlineshop.jcom.co.jp/Simulation/Simulation)
    
    [Covered  \
    areas & properties](https://www.jcom.co.jp/service/mobile/campaign/#)
    
    J:COM Customers
    
    [User  \
    Various procedures](https://r.jcom.jp/eG4nLSC)
    
    [Troubleshooting/  \
    Inquiries](https://prod8-live-chat.sprinklr.com/page?appId=67af27d73657336d345e4a96_app_9070639&did=CHAT_vivr_cojp_top&enableClose=true&skin=MODERN&userContext__c_679c8b53cb85b007fab0f6ea=DirectLink&utm_campaign=IVRSMS&utm_medium=referral&utm_source=did&webview=true&zoom=false)
    
*   [![J:COM TV](https://www.jcom.co.jp/common_v10/images/icn-jcom-tv.svg)TV](https://www.jcom.co.jp/en/service/tv/)
     ![メニューを閉じる](https://www.jcom.co.jp/common_v10/images/sp-menu/menu-close.svg)
    
    [![](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom-tv/slide/menu/mv-middle.webp)\
    \
    Showing you what you want\
    \
    Back to top](https://www.jcom.co.jp/en/service/tv/)
    
    *   Plans & Pricing
        
        *   [Plans & Pricing Overview](https://www.jcom.co.jp/en/service/tv/course/)
            
        *   [J:COM TV Shin Standard](https://www.jcom.co.jp/en/service/tv/course/standard.html)
            
        *   [J:COM TV Shin Standard Plus](https://www.jcom.co.jp/en/service/tv/course/standard_plus.html)
            
        *   [J:COM TV Select](https://www.jcom.co.jp/en/service/tv/course/select.html)
            
        
    *   Content lineup
        
        *   [Content Lineup Overview](https://www.jcom.co.jp/en/service/tv/channel/)
            
        *   [Channels](https://www.jcom.co.jp/en/service/tv/channel/list/)
            
        *   [Optional channels](https://www.jcom.co.jp/en/service/tv/channel/option_ch/)
            
        *   [Channels by plan](https://www.jcom.co.jp/en/service/tv/channel/comparison/)
            
        
    *   [Streaming services](https://www.jcom.co.jp/en/service/tv/smart/ott.html)
        
    *   [Helpful features](https://www.jcom.co.jp/en/service/tv/smart/)
        
    *   Options
        
        *   [Options Overview](https://www.jcom.co.jp/en/service/tv/accessories/)
            
        *   [J:COM Netflix Set](https://www.jcom.co.jp/en/guide/starter/netflix/)
            
        *   [External hard drive](https://www.jcom.co.jp/en/service/tv/accessories/hdd/)
            
        *   [J:COM LINK mini](https://www.jcom.co.jp/en/service/tv/accessories/linkmini/)
            
        
    *   [How to apply](https://www.jcom.co.jp/en/service/tv/guide/)
        
    
*   [![J:COM NET](https://www.jcom.co.jp/common_v10/images/icn-jcom-net.svg)Internet](https://www.jcom.co.jp/en/service/net/)
     ![メニューを閉じる](https://www.jcom.co.jp/common_v10/images/sp-menu/menu-close-white.svg)
    
    [![](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom-net/slide/menu/mv-middle.webp)\
    \
    Faster and more comfortable\
    \
    Back to top](https://www.jcom.co.jp/en/service/net/)
    
    *   [Plans & Pricing](https://www.jcom.co.jp/en/service/net/course/)
        
    *   Options
        
        *   [Options Overview](https://www.jcom.co.jp/en/service/net/option/)
            
        *   [Messhu Wi-Fi](https://www.jcom.co.jp/en/service/net/option/mesh-wi-fi/)
            
        *   [J:COM LINK mini](https://www.jcom.co.jp/en/service/net/option/linkmini/)
            
        
    *   [Support](https://www.jcom.co.jp/en/service/net/support/)
        
    *   [How to apply](https://www.jcom.co.jp/en/service/net/guide/)
        
    
*   [![J:COM MOBILE](https://www.jcom.co.jp/common_v10/images/icn-jcom-mobile.svg)Smartphone](https://www.jcom.co.jp/en/service/mobile/)
     ![メニューを閉じる](https://www.jcom.co.jp/common_v10/images/sp-menu/menu-close-white.svg)
    
    [![](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom-mobile/slide/menu/mv-middle.webp)\
    \
    Continuous savings\
    \
    Back to top](https://www.jcom.co.jp/en/service/mobile/)
    
    *   Pricing
        
        *   [Price Top](https://www.jcom.co.jp/en/service/mobile/price/)
            
        *   [Call charges/SMS service charges](https://www.jcom.co.jp/en/service/mobile/price/detail/)
            
        *   [Data Mori](https://www.jcom.co.jp/en/service/mobile/price/datamori/)
            
        *   [Kids plan](https://www.jcom.co.jp/en/service/mobile/price/kids/)
            
        *   [Seniors plan](https://www.jcom.co.jp/en/service/mobile/campaign/senior/)
            
        *   [About 5G](https://www.jcom.co.jp/en/service/mobile/special/5g/)
            
        *   [Termination of 3G service](https://www.jcom.co.jp/en/service/mobile/special/3g/)
            
        
    *   Products
        
        *   [Product Top](https://www.jcom.co.jp/en/service/mobile/device/)
            
        *   [iPhone 16e](https://www.jcom.co.jp/en/service/mobile/device/iphone_16e/)
            
        *   [iPhone 15](https://www.jcom.co.jp/en/service/mobile/device/iphone_15/)
            
        *   [Google Pixel 8a](https://www.jcom.co.jp/en/service/mobile/device/pixel_8a/)
            
        *   [AQUOS sense10](https://www.jcom.co.jp/en/service/mobile/device/aquos_sense10/)
            
        *   [Samsung Galaxy A25 5G](https://www.jcom.co.jp/en/service/mobile/device/galaxy_a25_5g/)
            
        *   [BASIO active2](https://www.jcom.co.jp/en/service/mobile/device/basio_active2/)
            
        
    *   SIM
        
        *   [Low-cost SIM Top](https://www.jcom.co.jp/en/service/mobile/device/sim/)
            
        *   [eSIM](https://www.jcom.co.jp/en/service/mobile/device/sim/esim/)
            
        *   [Details](https://www.jcom.co.jp/en/service/mobile/device/sim/detail/)
            
        *   [Device compatibility check](https://www.jcom.co.jp/service/mobile/device/sim/detail/device.html)
            
        *   [Unlocking SIM Cards](https://www.jcom.co.jp/en/service/mobile/device/sim/detail/simunlock.html)
            
        
    *   Options
        
        *   [Options Overview](https://www.jcom.co.jp/en/service/mobile/option/)
            
        *   [Unlimited calls](https://www.jcom.co.jp/en/service/mobile/option/kakehodai/)
            
        *   [Block nuisance calls and messages](https://www.jcom.co.jp/en/service/mobile/option/block/)
            
        *   [Family smartphone insurance](https://www.jcom.co.jp/en/service/ssi/kazoku_sumaho/)
            
        *   [Secure device guarantee 60](https://www.jcom.co.jp/en/service/mobile/option/guaranty60/)
            
        *   [AppleCare+ for iPhone](https://www.jcom.co.jp/en/service/mobile/device/support/applecare.html)
            
        *   [Anshin Filter for J:COM](https://www.jcom.co.jp/en/service/mobile/option/anshin_filter/)
            
        *   [Purchase additional accessories](https://www.jcom.co.jp/en/service/mobile/option/accessories/add/)
            
        
    *   Initial Setup Support
        
        *   [Initial Setup Support Top](https://www.jcom.co.jp/en/service/mobile/support/)
            
        *   [FAQ](https://www.jcom.co.jp/en/service/mobile/support/faq/)
            
        *   [Transferring your smartphone Q&A](https://www.jcom.co.jp/en/service/mobile/support/qa/)
            
        
    *   [How to apply](https://www.jcom.co.jp/en/service/mobile/usage/)
        
    *   [User](https://cs.myjcom.jp/jcomMobile)
        
    *   [For corporations](https://business.jcom.co.jp/smb/mobile/)
        
    
*   [![J:COM Denki](https://www.jcom.co.jp/common_v10/images/icn-jcom-electricity.svg)electricity](https://www.jcom.co.jp/en/service/electricity/)
     ![メニューを閉じる](https://www.jcom.co.jp/common_v10/images/sp-menu/menu-close-white.svg)
    
    [![](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom-electricity/slide/menu/mv-middle.webp)\
    \
    Rest assured that the quality remains the same\
    \
    Back to top](https://www.jcom.co.jp/en/service/electricity/)
    
    *   Price menu
        
        *   [Price menu top](https://www.jcom.co.jp/en/service/electricity/price/)
            
        *   [TEPCO area](https://www.jcom.co.jp/en/service/electricity/price/tokyo_juryo.html)
            
        *   [Kansai Electric Power area](https://www.jcom.co.jp/en/service/electricity/price/kansai_juryo.html)
            
        *   [Tohoku Electric Power Area](https://www.jcom.co.jp/en/service/electricity/price/tohoku_juryo.html)
            
        *   [Chugoku Electric Power Area](https://www.jcom.co.jp/en/service/electricity/price/chugoku_juryo.html)
            
        *   [Kyushu Electric Power area](https://www.jcom.co.jp/en/service/electricity/price/kyushu_juryo.html)
            
        *   [Hokkaido Electric Power Area](https://www.jcom.co.jp/en/service/electricity/price/hokkaido_juryo.html)
            
        
    *   green menu
        
        *   [green menu top](https://www.jcom.co.jp/en/service/electricity/price/green/)
            
        *   [Pricing](https://www.jcom.co.jp/en/service/electricity/price/green/price_list/)
            
        
    *   [J:COM Electric  \
        How it works](https://www.jcom.co.jp/en/service/electricity/feature/)
        
    *   [How to apply](https://www.jcom.co.jp/en/service/electricity/flow/)
        
    *   [User](https://cs.myjcom.jp/ele)
        
    
*   [![あたらしいを、あたりまえに　J:COM](https://www.jcom.co.jp/common_v10/images/logo-jcom-only.svg)](https://www.jcom.co.jp/en/)
     ![メニューを閉じる](https://www.jcom.co.jp/common_v10/images/sp-menu/menu-close.svg)
    
    [Landline](https://www.jcom.co.jp/en/service/phone/)
     ​ ​[gas](https://www.jcom.co.jp/en/service/gas/)
     ​ ​[insurance](https://www.jcom.co.jp/en/service/ssi/)
     ​ ​[loan](https://www.jcom-financial.co.jp/)
     ​ ​[Home IoT](https://www.jcom.co.jp/en/service/home/)
     ​ ​[security cameras](https://www.jcom.co.jp/en/guide/starter/home_security/)
     ​ ​[online  \
    medical treatment](https://www.jcom.co.jp/en/service/telemedicine/)
    
    [Service overview](https://www.jcom.co.jp/en/service/)
    
    [Services for corporations and local governments  \
    ![J:COM BUSINESS](https://www.jcom.co.jp/common_v10/images/logo_jcombusiness.webp)](https://business.jcom.co.jp/)
    

List of campaigns and benefits
==============================

Campaign filter

###### Customer contract status

For new subscribers

User

###### Related services

tv set

Net

smartphone

others

###### Customer's age

Under 22 years old

Under 26

over 60

###### Housing form

housing complex

Detached houses

[View refinement results](https://www.jcom.co.jp/service/mobile/campaign/#camp-result)

Close

service  
Applicants
--------------------

great deals  
・Search for benefits

[![icon](https://www.jcom.co.jp/common_v10/images/icn-simulation.svg)Toll simulator  \
ration](https://www.jcom.co.jp/service/mobile/campaign/#)

free or  
Properties with special rates!

[Covered  \
areas & properties](https://www.jcom.co.jp/service/mobile/campaign/#)

[Click here for procedures User](https://mypage.jcom.co.jp/)

[](https://www.jcom.co.jp/service/mobile/campaign/#)

Savings calculator

choose a service

Get your TV and Internet together!

![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-tv.svg)  
![J:COM TV](https://www.jcom.co.jp/common_v10/images/logo-jcom-tv.svg)

![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-net.svg)  
![J:COM NET](https://www.jcom.co.jp/common_v10/images/logo-jcom-net.svg)

![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-phone.svg)  
![J:COM PHONE](https://www.jcom.co.jp/common_v10/images/logo-jcom-phone.svg)

[![icon](https://www.jcom.co.jp/common_v10/images/icn-simulation.svg)Savings calculator](https://onlineshop.jcom.co.jp/Simulation/Simulation)

Save more money on your monthly smartphone bill.

![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-mobile.svg)  
![J:COM MOBILE](https://www.jcom.co.jp/common_v10/images/logo-jcom-mobile.svg)

[![icon](https://www.jcom.co.jp/common_v10/images/icn-simulation.svg)Savings calculator](https://www.jcom.co.jp/en/service/mobile/simulator/)

[Close](https://www.jcom.co.jp/service/mobile/campaign/#)

[WEB Gentei Start Wari\
\
![WEB Gentei Start Wari](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_start.webp)\
\
Start your J:COM service at a great price!  \
Sign up for an eligible plan and receive a discount on your monthly J:COM usage fee.\
\
tv set\
\
Net\
\
discount\
\
For new members\
\
User](https://www.jcom.co.jp/en/campaign/start_jcom/)
[Cashback\
\
![Cashback](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_quo_present.webp)\
\
Get up to 40,000 yen cash back by signing up for eligible services!\
\
tv set\
\
Net\
\
Cashback\
\
For new members\
\
User](https://www.jcom.co.jp/en/campaign/cashback/)
[Basic installation fee for new subscribers is effectively 0 yen\
\
![Basic construction cost is actually 0 yen](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_kojihi.webp)\
\
No initial cost.  \
By applying for the target service, the basic construction cost is actually 0 yen!\
\
Special handling tax is needed.\
\
tv set\
\
Net\
\
free\
\
For new members\
\
User](https://www.jcom.co.jp/en/campaign/kojihi/)
[Seishun 22 Wari, Seishun 26 Wari\
\
![Seishun 22 Wari, Seishun 26 Wari](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_u26.webp)\
\
Supporting campus life and the start of your new life! We offer special discount plans exclusively for customers under the age of 26.\
\
tv set\
\
Net\
\
discount\
\
For new members\
\
User](https://www.jcom.co.jp/en/campaign/u26/)
[UR limited special plan\
\
![UR limited special plan](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_ur.webp)\
\
A special discount plan is available for customers living in UR rental housing.\
\
tv set\
\
Net\
\
discount\
\
For new members\
\
User](https://www.jcom.co.jp/en/campaign/ur/)
[J:COM TV Shin Standard  \
No service change fee\
\
![There is no charge for changing your plan to J:COM TV Thin Standard or Thin Standard Plus!](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_course_change.webp)\
\
If you change your current TV plan to J:COM TV Thin Standard or J:COM TV Thin Standard Plus, there will be no change fee.\
\
tv set\
\
discount\
\
User](https://www.jcom.co.jp/en/campaign/course_change/)
[J:COM LINK replacement construction fee free of charge\
\
![User J:COM TV, the installation fee for switching to J:COM LINK is free!](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_charge_free.webp)\
\
If you are a J:COM TV subscriber and exchange your device to J:COM LINK, the replacement work will be free of charge.\
\
tv set\
\
discount\
\
User](https://www.jcom.co.jp/en/campaign/charge_free/)
[Additional terrestrial digital / BS digital course free\
\
![Additional terrestrial digital / BS digital course free](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_kodate_BS_free.webp)\
\
If you apply to J:COM TV, you will receive a free tuner exclusively for terrestrial digital and BS digital broadcasts! (Maximum 3 units)\
\
tv set\
\
free\
\
For new members\
\
User](https://www.jcom.co.jp/en/service/tv/dgbs/)
[Senior 60 wari  \
(Kakeho/Support/Spam Block)\
\
![Senior 60 wari (Unlimited Calls/Support/Block Spam)](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_senior_kakeho.webp)\
\
Exclusively for customers aged 60 and over!  \
New customers signing up for an eligible plan will receive Unlimited calls, support, and nuisance call and message blocking for three months free of charge.\
\
smartphone\
\
discount\
\
For new members\
\
User](https://www.jcom.co.jp/en/service/mobile/campaign/senior/)
[\[Only for online applications\]  \
J:COM MOBILE  \
Contract administration fee free\
\
![[WEB application only] J:COM MOBILE contract administration fee free](https://www.jcom.co.jp/campaign/images_v10/banner/camp_thumbnail3.webp)\
\
Online application only!  \
If you apply for the J:COM MOBILE A plan as a new member, the contract administration fee will be waived.\
\
smartphone\
\
free\
\
For new members](https://www.jcom.co.jp/en/service/mobile/campaign/mobile_fee_0/)
[Security cameras for single-family homes  \
Basic construction fee discount\
\
![Discount on basic installation fee for security cameras for detached houses](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_construction_discount_sp_v2.webp)\
\
If you are currently subscribed to or newly subscribe to J:COM NET320M or higher/fiber optic line plan, when you apply for a security camera, you will receive a discount of 5,500 yen (tax included) on the basic installation fee.\
\
Others\
\
discount\
\
For new members\
\
User](https://www.jcom.co.jp/en/campaign/home_security/)
[Limited time offer for Samsung Galaxy A25 5G devices when upgrading your device\
\
![Limited time offer for Samsung Galaxy A25 5G devices when upgrading your device](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_galaxy_a25_5g.webp)\
\
Limited to those upgrading their phone model. Discount on the price of the Samsung Galaxy A25 5G device.\
\
smartphone\
\
discount\
\
User](https://www.jcom.co.jp/en/campaign/galaxy_a25_5g/)
[J:COM Electricity Start Discount  \
\[Kansai only\]\
\
![J:COM Electricity Starter Discount [Kansai only]](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_ele_start.webp)\
\
Limited to the Kansai area. New applicants will receive a 12-month discount on their monthly electricity bill.\
\
Electricity\
\
discount\
\
For new members\
\
Application period: Monday, December 1, 2025 - Sunday, May 31, 2026](https://www.jcom.co.jp/en/campaign/ele_start/)

option  
Applicants
-------------------

Search for advantageous campaigns and benefits

[![icon](https://www.jcom.co.jp/common_v10/images/icn-simulation.svg)Savings calculator](https://www.jcom.co.jp/service/mobile/campaign/#)

[Click here for procedures User](https://mypage.jcom.co.jp/)

[](https://www.jcom.co.jp/service/mobile/campaign/#)

Savings calculator

choose a service

Get your TV and Internet together!

![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-tv.svg)  
![J:COM TV](https://www.jcom.co.jp/common_v10/images/logo-jcom-tv.svg)

![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-net.svg)  
![J:COM NET](https://www.jcom.co.jp/common_v10/images/logo-jcom-net.svg)

![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-phone.svg)  
![J:COM PHONE](https://www.jcom.co.jp/common_v10/images/logo-jcom-phone.svg)

[![icon](https://www.jcom.co.jp/common_v10/images/icn-simulation.svg)Savings calculator](https://onlineshop.jcom.co.jp/Simulation/Simulation)

Save more money on your monthly smartphone bill.

![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-mobile.svg)  
![J:COM MOBILE](https://www.jcom.co.jp/common_v10/images/logo-jcom-mobile.svg)

[![icon](https://www.jcom.co.jp/common_v10/images/icn-simulation.svg)Savings calculator](https://www.jcom.co.jp/en/service/mobile/simulator/)

[Close](https://www.jcom.co.jp/service/mobile/campaign/#)

[hard disk for recording  \
(J:COM LINK only) 3 months discount\
\
![3 months discount on recording hard disk (J:COM LINK only)](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_hdd_155_90.webp)\
\
If you apply for the target service, the monthly usage fee of 880 yen (tax included) will be discounted for 3 months!\
\
tv set\
\
discount\
\
For new members\
\
User](https://www.jcom.co.jp/en/campaign/hdd/)
[Disney plus  \
Up to 3 months free\
\
![Disney Plus up to 3 months free](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_disneyplus_v2.webp)\
\
By signing up for the applicable service, you can get up to 3 months of Disney +'s monthly fee of 1,520 yen (tax included) free!\
\
tv set\
\
Net\
\
free\
\
For new members\
\
User](https://www.jcom.co.jp/en/service/disneyplus/lp/)
[Messhu Wi-Fi  \
Up to 2 months free\
\
![Messhu Wi-Fi for up to 2 months free](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_mesh-wi-fi_v3.webp)\
\
Make your home Wi-Fi comfortable.  \
Apply for the target service and get up to 2 months free!\
\
Net\
\
discount\
\
For new members\
\
User](https://www.jcom.co.jp/en/campaign/add_pod/)
[Messhu Wi-Fi  \
Free shipping and handling fee\
\
![Messhu Wi-Fi free shipping fee](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_296_172_meshwifi_v2.webp)\
\
If you set up your Messhu Wi-Fi yourself, there will be no delivery fee for the device!\
\
Net\
\
free\
\
For new members\
\
User](https://www.jcom.co.jp/en/campaign/add_pod_self/)
[nuisance call auto block  \
2 months free\
\
![Spam call auto block 2 months free](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_meiwaku-block_v3.webp)\
\
Apply for the target service and get 2 months free!\
\
Others\
\
For new members\
\
User](https://www.jcom.co.jp/en/campaign/meiwaku-block/)
[BS10 Premium  \
Price discount campaign\
\
![BS10 Premium Fee Discount Campaign](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_bs10_premium.webp)\
\
You can watch it now for free for the first month and then for 980 yen for the next two months (1,078 yen including tax).\
\
tv set\
\
discount\
\
For new members\
\
User\
\
Application period: Saturday, September 20, 2025 to Wednesday, December 31, 2025\
\
Customers who started watching between Wednesday, October 1, 2025 and Thursday, January 15, 2026.](https://www2.myjcom.jp/special/campaign/star/)
[Toei Channel HD  \
Price discount campaign\
\
![Toei Channel HD price discount campaign](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_toei.webp)\
\
Now you can watch up to 3 months for the price of 1 month.\
\
tv set\
\
discount\
\
For new members\
\
User\
\
Application period: Monday, October 20, 2025 to Wednesday, December 31, 2025\
\
Customers who started watching between Saturday, November 1, 2025 and Thursday, January 15, 2026.](https://www2.myjcom.jp/special/campaign/toeich/)

Advantageous information
------------------------

[J:COM金利優遇割\
\
![Detached house limited J:COM interest rate discount](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_au_loan.webp)\
\
If you sign up for an au Jibun Bank home loan with eligible J:COM services, you can receive up to a 0.05% annual reduction from the applicable home loan interest rate!\
\
Others\
\
For new members\
\
User](https://www.jcom.co.jp/en/price/au_loan/)
[au Smart Value\
\
![au Smart Value](https://data.wovn.io/ImageValue/production/63c0b739b1e80445d40ae954/en/efcd620bb0efa17348440dbc386ab2b6/63c0b739b1e80445d40ae954.776164097.1697545538958.png)\
\
Get a great deal on au smartphones when combined with J:COM.  \
Get a discount on your monthly fee when you use an au smartphone!\
\
discount\
\
For new members\
\
User](https://www.jcom.co.jp/en/price/au/)
[UQ mobile home set discount\
\
![UQ mobile home set discount](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_uq-smartphone.webp)\
\
Get a great deal on UQ Smartphone when combined with J:COM.  \
If you sign up for an eligible UQ mobile plan, you will receive a discount on your monthly fee!\
\
discount\
\
For new members\
\
User](https://www.jcom.co.jp/en/price/uq/)
[Referral discount! Refer a friend bonus\
\
![Referral discount! Refer a friend bonus](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_isyo.webp)\
\
If you introduce a friend, you and your friend will receive a total discount of 5,500 yen (including tax)!\
\
discount\
\
User](https://www.jcom.co.jp/en/campaign/shokai/)
[\[Cable TV even when you move\]  \
The installation cost is practically 0 yen!\
\
![[Cable TV even when you move] Installation cost is practically 0 yen!](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_moving.webp)\
\
When moving between J:COM or J:COM affiliated company areas, the installation cost at the new location is virtually 0 yen! ! ※Special handling tax is needed.\
\
free\
\
User](https://www.jcom.co.jp/en/service/moving/kojihi.html)

##### Match the narrowing conditions  
There were no campaigns.

Check your filters  
Please narrow down again.

#### J:COMご利用中の方へ

You can also check here for useful information for User.

[Application & Participation Free  \
event gift](https://c.myjcom.jp/user/)

[We introduce advantageous special treatment and discount information  \
subscriber benefits](https://www2.myjcom.jp/yutai/)

\[Notes\]

*   It may take more than four days depending on the details of your contract, traffic conditions, use of landline phone number portability services, etc. Please understand this in advance.

Close

[シェアする](https://www.jcom.co.jp/service/mobile/campaign/)

[Tweet](https://twitter.com/share?ref_src=twsrc%5Etfw)

\[About the amount including tax\]

*   The listed amounts include tax unless otherwise specified.
*   Consumption tax differences may occur due to changes in the consumption tax rounding method under the invoice system.

1.  [J:COM Top](https://www.jcom.co.jp/en/)
    
2.  List of campaigns and benefits

[![ページ上部へ戻る](https://www.jcom.co.jp/common_v10/images/PageTop.webp)](https://www.jcom.co.jp/service/mobile/campaign/#header)

[Return to top of page](https://www.jcom.co.jp/service/mobile/campaign/#header)

[Service Information](https://www.jcom.co.jp/en/?sc_pid=common_footer_unav_service_01)

[Online Shop](https://onlineshop.jcom.co.jp/?sc_pid=common_footer_unav_ols_01)

[Support Troubleshooting/FAQ](https://cs.myjcom.jp/?sc_pid=common_footer_unav_csmyjcom_01)

[Fun! J:COM TV program information/presents and benefits](https://www.myjcom.jp/?sc_pid=common_footer_unav_myjcom_01)

[My page Confirm/change contract details](https://mypage.jcom.co.jp/?sc_pid=common_footer_unav_mypage_01)

[Company website](https://www.jcom.co.jp/en/corporate/?sc_pid=common_footer_unav_corporate_01)

*   [![Twitter](https://www.jcom.co.jp/common_v10/images/icn-x.svg)](https://twitter.com/jcom_info?sc_pid=common_footer_sns_twitter_01)
    
*   [![instagram](https://www.jcom.co.jp/common_v10/images/icn-instagram.svg)](https://www.instagram.com/jcom.official/?sc_pid=common_footer_sns_instagram_01)
    
*   [![Facebook](https://www.jcom.co.jp/common_v10/images/icn-facebook.svg)](https://www.facebook.com/JCOM.ZAQ?sc_pid=common_footer_sns_facebook_01)
    
*   [![LINE](https://www.jcom.co.jp/common_v10/images/icn-line.svg)](https://www.jcom.co.jp/en/social/campaign/line/?sc_pid=common_footer_sns_line_01)
    
*   [![note](https://www.jcom.co.jp/common_v10/images/icn-note.svg)](https://note.jcom.co.jp/?sc_pid=common_footer_sns_note_01)
    

[Account list](https://www.jcom.co.jp/en/service/social/?sc_pid=common_footer_sns_list_01)

[![J:COM J:COM ANNIVERSARY: Making Newness a Natural Thing](https://www.jcom.co.jp/common_v10/images/logo-jcom-horizontal.svg)](https://www.jcom.co.jp/en/special/30th/)

*   [Site map](https://www.jcom.co.jp/en/sitemap/?sc_pid=common_footer_sitemap)
    
*   [Privacy portal](https://www.jcom.co.jp/en/corporate/site_info/privacy-portal/?sc_pid=common_footer_privacybasic)
    
*   [Privacy policy](https://www.jcom.co.jp/en/corporate/site_info/privacy_policy/?sc_pid=common_footer_privacy)
    
*   [Web Accessibility Initiatives](https://www.jcom.co.jp/en/corporate/site_info/accessibility/?sc_pid=common_footer_accessibility)
    
*   [Security policy](https://www.jcom.co.jp/en/corporate/site_info/security_policy/?sc_pid=common_footer_security)
    
*   [Social media policy](https://www.jcom.co.jp/en/corporate/site_info/socialmedia_policy/?sc_pid=common_footer_social)
    
*   [Human Rights Policy](https://www.jcom.co.jp/en/corporate/sustainability/well_being/hrp/?sc_pid=common_footer_hrp#policy)
    
*   [Regarding the use of cookie information, advertisement distribution, etc.](https://www.jcom.co.jp/en/corporate/site_info/privacy_policy/cookie/?sc_pid=common_footer_cookie)
    
*   [Inquiries](https://www.jcom.co.jp/en/contactus/?sc_pid=common_footer_contactus)
    
*   [Company website](https://www.jcom.co.jp/en/corporate/?sc_pid=common_footer_corporate)
    
*   [Careers](https://recruit.jcom.co.jp/?sc_pid=common_footer_recruit)
    
*   [Corporate customers](https://business.jcom.co.jp/?sc_pid=common_footer_business)
    
*   [About This Site](https://www.jcom.co.jp/en/site_info/?sc_pid=common_footer_siteinfo)
    

Copyright © JCOM Co., Ltd. All Rights Reserved.

[](https://www.jcom.co.jp/service/mobile/campaign/#)

Configure area

Please enter your postal code.

〒

No hyphen (-) required

Please select your housing type.

![icon](https://www.jcom.co.jp/common_v10/images/icn-apartment.svg)Apartments

![icon](https://www.jcom.co.jp/common_v10/images/icn-house.svg)Houses

Please select the appropriate age.  
(The plans available will change.)

Age 27 or older

​Under 26 years old

​Under 22 years old

Next

[](https://www.jcom.co.jp/service/mobile/campaign/#)

Configure area

Please enter your postal code.

〒

 

Please select your housing type.

![icon](https://www.jcom.co.jp/common_v10/images/icn-apartment.svg)Apartments

![icon](https://www.jcom.co.jp/common_v10/images/icn-house.svg)Houses

Next

[](https://www.jcom.co.jp/service/mobile/campaign/#)

Configure area

Please enter your postal code.

〒

 

Please select your housing type.

![icon](https://www.jcom.co.jp/common_v10/images/icn-apartment.svg)Apartments

![icon](https://www.jcom.co.jp/common_v10/images/icn-house.svg)Houses

Next

[](https://www.jcom.co.jp/service/mobile/campaign/#)

Configure area

Please enter your postal code.

〒

No hyphen (-) required

Next

[](https://www.jcom.co.jp/service/mobile/campaign/#)

Configure area

Please enter your postal code.

〒

 

Please select your housing type.

![icon](https://www.jcom.co.jp/common_v10/images/icn-apartment.svg)Apartments

![icon](https://www.jcom.co.jp/common_v10/images/icn-house.svg)Houses

Next

[](https://www.jcom.co.jp/service/mobile/campaign/#)

Check service

Please enter the postal code of your new address.

〒

 

Next

[](https://www.jcom.co.jp/service/mobile/campaign/#)

J:COM Telemedicine coverage area check

Please enter your postal code.

〒

No hyphen (-) required

Please select your housing type.

![icon](https://www.jcom.co.jp/common_v10/images/icn-apartment.svg)Apartments

![icon](https://www.jcom.co.jp/common_v10/images/icn-house.svg)Houses

Next

[](https://www.jcom.co.jp/service/mobile/campaign/#)

Select prefecture

Required Select prefecture.

Hokkaido and Tohoku

[Hokkaido](https://www.jcom.co.jp/service/mobile/campaign/#)
 [Miyagi Prefecture](https://www.jcom.co.jp/service/mobile/campaign/#)

Kanto

[Tokyo](https://www.jcom.co.jp/service/mobile/campaign/#)
 [Kanagawa Prefecture](https://www.jcom.co.jp/service/mobile/campaign/#)
 [Chiba Prefecture](https://www.jcom.co.jp/service/mobile/campaign/#)
 [Saitama Prefecture](https://www.jcom.co.jp/service/mobile/campaign/#)
 [Gunma Prefecture](https://www.jcom.co.jp/service/mobile/campaign/#)
 [Ibaraki Prefecture](https://www.jcom.co.jp/service/mobile/campaign/#)

Kansai

[Osaka Prefecture](https://www.jcom.co.jp/service/mobile/campaign/#)
 [Kyoto Prefecture](https://www.jcom.co.jp/service/mobile/campaign/#)
 [Wakayama Prefecture](https://www.jcom.co.jp/service/mobile/campaign/#)
 [Hyogo Prefecture](https://www.jcom.co.jp/service/mobile/campaign/#)

Kyushu/Yamaguchi

[Fukuoka Prefecture](https://www.jcom.co.jp/service/mobile/campaign/#)
 [Kumamoto Prefecture](https://www.jcom.co.jp/service/mobile/campaign/#)
 [Oita Prefecture](https://www.jcom.co.jp/service/mobile/campaign/#)
 [Yamaguchi Prefecture](https://www.jcom.co.jp/service/mobile/campaign/#)

[Return](https://www.jcom.co.jp/service/mobile/campaign/#)

[](https://www.jcom.co.jp/service/mobile/campaign/#)

Select city/ward/town

Required Please select your city.

Current selection: Tokyo

*   A
*   Ka
*   Sa
*   Ta
*   Na
*   Ha
*   Ma
*   Ya
*   Ra
*   Wa

[Akishima City](https://www.jcom.co.jp/service/mobile/campaign/#)
 [Akiruno City](https://www.jcom.co.jp/service/mobile/campaign/#)
 [Adachi Ward](https://www.jcom.co.jp/service/mobile/campaign/#)
 [Itabashi Ward](https://www.jcom.co.jp/service/mobile/campaign/#)
 [Inagi City](https://www.jcom.co.jp/service/mobile/campaign/#)
 [Edogawa Ward](https://www.jcom.co.jp/service/mobile/campaign/#)
 [Ota Ward](https://www.jcom.co.jp/service/mobile/campaign/#)

Contents of “Ka”

Regions starting with “A”

[Akishima City](https://www.jcom.co.jp/service/mobile/campaign/#)
 [Akiruno City](https://www.jcom.co.jp/service/mobile/campaign/#)
 [Adachi Ward](https://www.jcom.co.jp/service/mobile/campaign/#)
 [Itabashi Ward](https://www.jcom.co.jp/service/mobile/campaign/#)
 [Inagi City](https://www.jcom.co.jp/service/mobile/campaign/#)
 [Edogawa Ward](https://www.jcom.co.jp/service/mobile/campaign/#)
 [Ota Ward](https://www.jcom.co.jp/service/mobile/campaign/#)

Regions starting with “Ka”

Regions starting with “Sa”

Regions starting with “Ta”

Regions starting with “Na”

[Return](https://www.jcom.co.jp/service/mobile/campaign/#)

[](https://www.jcom.co.jp/service/mobile/campaign/#)

Configure area

〒 1070052

There are several possible areas for the postal code you entered.  
Please select your address from the list below

Please select 1 2 3 text text text

Configure

[Return](https://www.jcom.co.jp/service/mobile/campaign/#)

[](https://www.jcom.co.jp/service/mobile/campaign/#)

Configure area

〒 \-------

Please select the following address information.

  

Please select 1 2 3 text text text

Next

[Return](https://www.jcom.co.jp/service/mobile/campaign/#)

[](https://www.jcom.co.jp/service/mobile/campaign/#)

Check Gig coverage area

〒 1070052 (J:COM Machida/Kawasaki)

This is the coverage area of the J:COM NET 1G plan  
​

\* "J:COM NET 1Gig plan" is a 1Gig service that can be used with cable TV lines.

This is the coverage area for Hikari 10G/5G/1G plan  
​

\* Hikari is not available in some areas (gradually expanding service areas) [For more information, please contact us here.](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

Hikari 10G/5G/1G plan \*1  
coverage area is currently being expanded.

J:COM NET 1G plan \*2  
coverage area.

\*1 Hikari is not available in some areas (gradually expanding service areas) [For more information, please contact us here.](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

\*2 "J:COM NET 1Gig plan" is a 1Gig service that can be used with cable TV lines.

Hikari 10G/5G/1G plan  
J:COM NET 1G plan  
coverage area.

\*Not available in some areas (gradually expanding service areas) [For more information, please contact us here.](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

\* "J:COM NET 1Gig plan" is a 1Gig service that can be used with cable TV lines.

Outside the J:COM NET 1G plan  
coverage area. (Sequentially expanding the coverage area)

is in the 320M plan  
coverage area.

is in the 320M plan  
coverage area.

The J:COM NET 1G plan coverage area is gradually expanding.

[For detailed information on the coverage area, contact us here.](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

This is the service area of J:COM Oita (Oita Cable Telecom Co., Ltd.).  
[Please refer to the J:COM Oita (Oita Cable Telecom Co., Ltd.) homepage.](https://wwwjcom.oct-net.ne.jp/)
​

This is the Yokohama Cable Vision (YCV) service area.  
[Please refer to the Yokohama Cable Vision (YCV) homepage.](https://www.catv-yokohama.ne.jp/)
​

[Sign Up](https://www.jcom.co.jp/sim_contact/entry_request.php?refresh=new&net_service=1)

[Check the sign up process](https://www.jcom.co.jp/en/service/guide/sdu/)

Some areas may be outside the coverage area.

[View prices/plans](https://www.jcom.co.jp/en/service/net/)

Return

[](https://www.jcom.co.jp/service/mobile/campaign/#)

Check Gig coverage area

〒 1070052 (Machida/Kawasaki)

Hikari 10G/5G/1G plan  
J:COM NET 1G plan  
coverage area.

\* "J:COM NET 1Gig plan" is a 1Gig service that can be used with cable TV lines.

Hikari 10G/5G/1G plan  
coverage area.

Hikari 1G plan  
J:COM NET 1G plan  
coverage area.

\* "J:COM NET 1Gig plan" is a 1Gig service that can be used with cable TV lines.

Hikari 1G plan  
coverage area.

is in the 320M plan  
coverage area.

[Sign Up](https://www.jcom.co.jp/sim_contact/entry_request.php?refresh=new&net_service=1)

[Check the sign up process](https://www.jcom.co.jp/en/service/guide/sdu/)

Some areas may be outside the coverage area.

View prices/plans

[Savings calculator](https://onlineshop.jcom.co.jp/Simulation/Simulation)

Return

[](https://www.jcom.co.jp/service/mobile/campaign/#)

Check Gig coverage area

〒 1070052 

is out of the J:COM NET  
coverage area.

is in the J:COM WiMAX  
coverage area.

[Sign Up](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=wimax2p)

[Check the sign up process](https://www.jcom.co.jp/en/service/guide/sdu/)

Some areas may be outside the coverage area.

[View prices/plans](https://www.jcom.co.jp/en/service/wimax/)

Return

[](https://www.jcom.co.jp/service/mobile/campaign/#)

Check coverage areas

〒 \------- 

This is the service area of J:COM Oita (Oita Cable Telecom Co., Ltd.).  
[Please refer to the J:COM Oita (Oita Cable Telecom Co., Ltd.) homepage.](https://wwwjcom.oct-net.ne.jp/)
​

This is the Yokohama Cable Vision (YCV) service area.  
[Please refer to the Yokohama Cable Vision (YCV) homepage.](https://www.catv-yokohama.ne.jp/)
​

The following services are available.

   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-mobile.svg) ![J:COM MOBILE](https://www.jcom.co.jp/common_v10/images/logo-jcom-mobile.svg)](https://www.jcom.co.jp/en/service/mobile/)   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-electricity.svg) ![J:COM Denki](https://www.jcom.co.jp/common_v10/images/logo-jcom-electricity.svg)](https://www.jcom.co.jp/en/service/electricity/)
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-gas.svg) ![J:COM GAS](https://www.jcom.co.jp/common_v10/images/logo-jcom-gas.svg)](https://www.jcom.co.jp/en/service/gas/)
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-ssi.svg) ![J:COM Insurance](https://www.jcom.co.jp/common_v10/images/logo-jcom-ssi.svg)](https://www.jcom.co.jp/en/service/ssi/)
  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-telemedicine.svg) ![J:COM Telemedicine](https://www.jcom.co.jp/common_v10/images/logo-jcom-telemedicine.svg)](https://www.jcom.co.jp/en/service/telemedicine/)

The following services are [Price simulation](https://onlineshop.jcom.co.jp/Simulation/Simulation)
 in  
Please check the area.

  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-net.svg)\
\
![J:COM NET](https://www.jcom.co.jp/common_v10/images/logo-jcom-net.svg) Optical 10G/Optical 1G](https://www.jcom.co.jp/en/price/hikari-n/)  ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-tv.svg) Terrestrial digital/BS digital  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-phone.svg) Hikari Denwa](https://www.jcom.co.jp/en/price/hikari-n/phone-op/)

J:COM NET is provided via NTT line.

[Sign Up](https://onlineshop.jcom.co.jp/planSelect)

[Savings calculator](https://onlineshop.jcom.co.jp/Simulation/Simulation)

If you want local cable TV ​ ​[here](https://www.catv-jcta.jp/search/index)

Return

Some services may not be available depending on your region.

[](https://www.jcom.co.jp/service/mobile/campaign/#)

Check service

〒 1070052​

This is the service area of J:COM Oita (Oita Cable Telecom Co., Ltd.). Please refer to the [J:COM Oita (Oita Cable Television Co., Ltd.) website to confirm what services](https://wwwjcom.oct-net.ne.jp/)
 are provided.

This is the Yokohama Cable Vision (YCV) service area.  
[Please refer to the Yokohama Cable Vision (YCV) homepage.](https://www.catv-yokohama.ne.jp/)
​

The following services are available.

   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-tv.svg) ![J:COM TV](https://www.jcom.co.jp/common_v10/images/logo-jcom-tv.svg)](https://www.jcom.co.jp/en/service/tv/)   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-net.svg) ![J:COM NET](https://www.jcom.co.jp/common_v10/images/logo-jcom-net.svg)](https://www.jcom.co.jp/en/service/net/)
  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-mobile.svg) ![J:COM MOBILE](https://www.jcom.co.jp/common_v10/images/logo-jcom-mobile.svg)](https://www.jcom.co.jp/en/service/mobile/)
  
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-phone.svg) ![J:COM PHONE](https://www.jcom.co.jp/common_v10/images/logo-jcom-phone.svg)](https://www.jcom.co.jp/en/service/phone/)   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-ssi.svg) ![J:COM Insurance](https://www.jcom.co.jp/common_v10/images/logo-jcom-ssi.svg)](https://www.jcom.co.jp/en/service/ssi/)
  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-telemedicine.svg) ![J:COM Telemedicine](https://www.jcom.co.jp/common_v10/images/logo-jcom-telemedicine.svg)](https://www.jcom.co.jp/en/service/telemedicine/)

[J:COMご加入中の方  \
お引越しのお手続き](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=contact_move)

Return to postal code input

[](https://www.jcom.co.jp/service/mobile/campaign/#)

Check coverage areas

〒 1070052 (J:COM Machida/Kawasaki)

The following services are available.

   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-tv.svg) ![J:COM TV](https://www.jcom.co.jp/common_v10/images/logo-jcom-tv.svg)](https://www.jcom.co.jp/en/service/tv/)   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-net.svg) ![J:COM NET](https://www.jcom.co.jp/common_v10/images/logo-jcom-net.svg)](https://www.jcom.co.jp/en/service/net/)
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-mobile.svg) ![J:COM MOBILE](https://www.jcom.co.jp/common_v10/images/logo-jcom-mobile.svg)](https://www.jcom.co.jp/en/service/mobile/)
  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-electricity.svg) ![J:COM Denki](https://www.jcom.co.jp/common_v10/images/logo-jcom-electricity.svg)](https://www.jcom.co.jp/en/service/electricity/)
  
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-phone.svg) ![J:COM PHONE](https://www.jcom.co.jp/common_v10/images/logo-jcom-phone.svg)](https://www.jcom.co.jp/en/service/phone/)   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-gas.svg) ![J:COM GAS](https://www.jcom.co.jp/common_v10/images/logo-jcom-gas.svg)](https://www.jcom.co.jp/en/service/gas/)
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-ssi.svg) ![J:COM Insurance](https://www.jcom.co.jp/common_v10/images/logo-jcom-ssi.svg)](https://www.jcom.co.jp/en/service/ssi/)
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-home.svg) ![J:COM HOME](https://www.jcom.co.jp/common_v10/images/logo-jcom-home.svg)](https://www.jcom.co.jp/en/service/home/)
  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-telemedicine.svg) ![J:COM Telemedicine](https://www.jcom.co.jp/common_v10/images/logo-jcom-telemedicine.svg)](https://www.jcom.co.jp/en/service/telemedicine/)

[Application](https://onlineshop.jcom.co.jp/planSelect)
 ​ ​[Application](https://onlineshop.jcom.co.jp/planSelect)

[Check the sign up process](https://www.jcom.co.jp/en/service/guide/sdu/)

Savings calculator

Return

[](https://www.jcom.co.jp/service/mobile/campaign/#)

Check service

〒 1070052 (J:COM Machida/Kawasaki)

The following services are available.

   ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-tv.svg) ![J:COM TV](https://www.jcom.co.jp/common_v10/images/logo-jcom-tv.svg) ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-net.svg) ![J:COM NET](https://www.jcom.co.jp/common_v10/images/logo-jcom-net.svg)  ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-mobile.svg) ![J:COM MOBILE](https://www.jcom.co.jp/common_v10/images/logo-jcom-mobile.svg)  ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-electricity.svg) ![J:COM Denki](https://www.jcom.co.jp/common_v10/images/logo-jcom-electricity.svg)  
   ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-phone.svg) ![J:COM PHONE](https://www.jcom.co.jp/common_v10/images/logo-jcom-phone.svg) ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-gas.svg) ![J:COM GAS](https://www.jcom.co.jp/common_v10/images/logo-jcom-gas.svg)  ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-home.svg) ![J:COM HOME](https://www.jcom.co.jp/common_v10/images/logo-jcom-home.svg)

[J:COMご加入中の方  \
お引越しのお手続き](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=contact_move)

Return to postal code input

[](https://www.jcom.co.jp/service/mobile/campaign/#)

Check coverage areas

Please select your service.

Get your TV and Internet together!

 ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-tv.svg)  
![J:COM TV](https://www.jcom.co.jp/common_v10/images/logo-jcom-tv.svg)![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-net.svg)  
![J:COM NET](https://www.jcom.co.jp/common_v10/images/logo-jcom-net.svg) ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-phone.svg)  
![J:COM PHONE](https://www.jcom.co.jp/common_v10/images/logo-jcom-phone.svg)

[Savings calculator](https://onlineshop.jcom.co.jp/Simulation/Simulation)

Save more money on your monthly smartphone bill.

![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-mobile.svg)  
![J:COM MOBILE](https://www.jcom.co.jp/common_v10/images/logo-jcom-mobile.svg)

[Savings calculator](https://www.jcom.co.jp/en/service/mobile/simulator/)

Return

[](https://www.jcom.co.jp/service/mobile/campaign/#)

Check J:COM GAS coverage area

〒 1070052  ( J:COM ---- )​

![](https://www.jcom.co.jp/common_form/img/common/logo/logo_gas_osaka.png)

coverage area.

Some areas may be outside the coverage area.

![](https://www.jcom.co.jp/common_form/img/common/logo/logo_gas_tokyo.png)

coverage area.

Some areas may be outside the coverage area.

![](https://www.jcom.co.jp/common_form/img/common/logo/logo_gas_keiyo.png)

coverage area.

Some areas may be outside the coverage area.

is out of the J:COM GAS  
coverage area.

Energy Uchuu Co., Ltd. \[Koshigaya/Kasukabe area/Hasuda Minami area\] \[Toride/Abiko area\]  
If you live in an area where city gas is supplied,

you can use the

Tokyo Gas for J:COM "ZUTTO Gas" service.

[Learn more](https://www.jcom.co.jp/en/service/tokyo_gas/)

is out of the J:COM GAS  
coverage area.

Return

[](https://www.jcom.co.jp/service/mobile/campaign/#)

J:COM Telemedicine coverage area check

〒 1070052  ( J:COM ---- )​

J:COM Telemedicine  
coverage area.

Some areas may be outside the coverage area.

[See list of medical institutions](https://www.jcom.co.jp/en/service/telemedicine/clinic/)

[See prices](https://www.jcom.co.jp/en/service/telemedicine/price/)

Outside the J:COM Telemedicine  
coverage area.

Return

    

[](https://www.jcom.co.jp/service/mobile/campaign/#)

Notice to you
-------------

[Logout](https://www.jcom.co.jp/en/common/logout.html)

日本語

English
