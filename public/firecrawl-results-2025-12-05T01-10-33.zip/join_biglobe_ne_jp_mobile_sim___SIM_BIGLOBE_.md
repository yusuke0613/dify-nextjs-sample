# 【公式】格安SIM・格安スマホならBIGLOBEモバイル

URL: https://join.biglobe.ne.jp/mobile/sim/

---

*   サービス
    
    サービス
    
    *   [![BIGLOBE光](https://top.bcdn.jp/images/ImgService-1.png)](https://join.biglobe.ne.jp/ftth/hikari/?cl=global_header_hikari_logo)
        
    *   [![BIGLOBE mobile](https://top.bcdn.jp/images/ImgService-2.png)](https://join.biglobe.ne.jp/mobile/?cl=global_header_mobile_logo)
        
    *   [![BIGLOBE WiMAX](https://top.bcdn.jp/images/ImgService-3.png)](https://join.biglobe.ne.jp/mobile/wimax/?cl=global_header_wimax_logo)
        
    *   [![BIGLOBE biz](https://top.bcdn.jp/images/ImgService-4.png)](https://biz.biglobe.ne.jp/index.html)
        
    
    通信サービス
    
    *   [BIGLOBE光](https://join.biglobe.ne.jp/ftth/hikari/?cl=global_header_hikari_text)
        
    *   [auひかり](https://join.biglobe.ne.jp/ftth/one/?cl=global_header_one_text)
        
    *   [BIGLOBEモバイル](https://join.biglobe.ne.jp/mobile/?cl=global_header_mobile_text)
        
    *   [BIGLOBE WiMAX](https://join.biglobe.ne.jp/mobile/wimax/?cl=global_header_wimax_text)
        
    
    オプションサービス
    
    *   [お助けサポート＋](https://otasuke.biglobe.ne.jp/otasuke_plus/)
        
    *   [インターネット端末保証サービス](https://service.biglobe.ne.jp/internethosho/)
        
    *   [トータル・ネットセキュリティ](https://security.biglobe.ne.jp/tns/)
        
    *   [U-NEXT for BIGLOBE](https://vod.biglobe.ne.jp/unext/)
        
    *   [その他オプション](https://service.biglobe.ne.jp/)
        
    
    Webメディア
    
    *   [温泉大賞](https://biz.biglobe.ne.jp/onsen/award/)
        
    *   [しむぐらし](https://join.biglobe.ne.jp/mobile/sim/gurashi/)
        
    *   [あしたメディア](https://ashita.biglobe.co.jp/)
        
    
    法人のお客さま
    
    *   [BIGLOBE biz.](https://biz.biglobe.ne.jp/index.html)
        
    
*   企業情報
    
    企業情報
    
    *   [![](https://top.bcdn.jp/images/ImgCompany-1.png)\
        \
        企業情報トップ](https://www.biglobe.co.jp/outline)
        
    *   [![](https://top.bcdn.jp/images/ImgCompany-2.png)\
        \
        採用情報](https://www.biglobe.co.jp/recruit)
        
    *   [![](https://top.bcdn.jp/images/ImgCompany-3.png)\
        \
        ブランド](https://www.biglobe.co.jp/outline/brand)
        
    
*   [](https://mypage.sso.biglobe.ne.jp/?cl=global_header_mypage)
    

[メニュー 閉じる](https://join.biglobe.ne.jp/mobile/sim/)

[![BIGLOBE mobile](https://join.biglobe.ne.jp/v4/image/header/logo_mobile.svg?v=69e3c7748a)](https://join.biglobe.ne.jp/mobile/?cl=head_logo_mobile)

詳細を確認して

[お申し込み](https://join.biglobe.ne.jp/mobile/prepare/?cl=head_mobile_order)

*   [BIGLOBEモバイルTOP](https://join.biglobe.ne.jp/mobile/?cl=head_mobile_top)
    
*   料金プラン
    
    *   [料金プラン](https://join.biglobe.ne.jp/mobile/plan/?cl=head_mobile_plan_list)
        
    *   [BIGLOBE家族割](https://join.biglobe.ne.jp/mobile/plan/family/?cl=head_mobile_family)
        
    *   [シェアSIM](https://join.biglobe.ne.jp/mobile/plan/share-sim/?cl=head_mobile_share-sim)
        
    *   [ぴったりプラン診断](https://join.biglobe.ne.jp/mobile/plan/navigator/?cl=head_mobile_navigator)
        
*   端末
    
    *   [端末一覧](https://join.biglobe.ne.jp/mobile/device/?cl=head_mobile_device)
        
    *   [機種変更](https://join.biglobe.ne.jp/mobile/device/change.html?cl=head_mobile_change)
        
*   [動作確認端末](https://join.biglobe.ne.jp/mobile/device/compatibility.html?cl=head_mobile_device_comp)
    
*   オプション
    
    *   [オプション一覧](https://join.biglobe.ne.jp/mobile/option/?cl=head_mobile_option_list)
        
    *   [エンタメフリー・オプション](https://join.biglobe.ne.jp/mobile/option/entamefree.html?cl=head_mobile_option_entame)
        
    *   [選べる通話オプション](https://join.biglobe.ne.jp/mobile/option/bigtel.html?cl=head_mobile_option_call)
        
    *   [SIM端末保証サービス](https://join.biglobe.ne.jp/mobile/option/simhosho.html?cl=head_mobile_option_simhosho)
        
    *   [セキュリティセット・プレミアム](https://join.biglobe.ne.jp/mobile/option/security_set.html?cl=head_mobile_option_security_set)
        
*   [キャンペーン](https://join.biglobe.ne.jp/mobile/campaign/?cl=head_mobile_campaign)
    
*   申込ガイド
    
    *   [申込ガイド](https://join.biglobe.ne.jp/mobile/support/?cl=head_mobile_support_list)
        
    *   [まるわかりガイド](https://join.biglobe.ne.jp/mobile/support/guide/?cl=head_mobile_support_guide)
        
    *   [よくある質問](https://join.biglobe.ne.jp/mobile/support/faq.html?cl=head_mobile_support_faq)
        
    *   [ご利用までの流れ](https://join.biglobe.ne.jp/mobile/prepare/?cl=head_mobile_support_prepare#prepare_flow)
        
    *   [他社からのお乗り換え(MNP)](https://join.biglobe.ne.jp/mobile/prepare/mnp.html?cl=head_mobile_support_mnp)
        
*   店舗
    
    *   [店舗のご紹介](https://join.biglobe.ne.jp/mobile/shop/?cl=head_mobile_shop_info)
        
    *   [店舗検索](https://join.biglobe.ne.jp/mobile/shop/search.html?cl=head_mobile_shop_search)
        
*   詳細を確認して
    
    [詳細を確認してお申し込み](https://join.biglobe.ne.jp/mobile/prepare/?cl=head_mobile_order)
    

格安SIM/スマホ
=========

Previous

[![選べる通話オプション。10分かけ放題/3分かけ放題、または、90分/60分の通話定額パック。量と使い方で選べます。](https://join.biglobe.ne.jp/v3/image/mobile/slide/bigtel.png?v=558af63bfa)](https://join.biglobe.ne.jp/mobile/option/bigtel.html?cl=mobile_top_MVbigtel)

[![OPPO Reno13 A：24回払い1,840円(税込2,024円)/月](https://join.biglobe.ne.jp/v3/image/mobile/slide/oppo_reno13_a.png?v=f20a741998)](https://join.biglobe.ne.jp/mobile/device/oppo_reno13_a.html?cl=mobile_top_MVoppo_reno13_a)

[![エンタメフリー・オプション 音声SIM最大2カ月無料(初回申込)](https://join.biglobe.ne.jp/v4/image/mobile/option/entamefree/main_smp.png?v=d148915322)](https://join.biglobe.ne.jp/mobile/option/entamefree.html?cl=mobile_top_MVcpenta)

[![AQUOS sense9：24回払い2,200円(税込2,420円)/月](https://join.biglobe.ne.jp/v3/image/mobile/slide/aquos_sense9.png?v=17aa1c3a3b)](https://join.biglobe.ne.jp/mobile/device/aquos_sense9.html?cl=mobile_top_MVaquos_sense9)

[![BIGLOBE家族割 2回線目以降は全プランずーっと毎月200円割引](https://join.biglobe.ne.jp/v4/image/mobile/plan/family/index/main_smp.png?v=60e3567bd5)](https://join.biglobe.ne.jp/mobile/plan/family/?cl=mobile_top_MVfamily)

[![選べる通話オプション。10分かけ放題/3分かけ放題、または、90分/60分の通話定額パック。量と使い方で選べます。](https://join.biglobe.ne.jp/v3/image/mobile/slide/bigtel.png?v=558af63bfa)](https://join.biglobe.ne.jp/mobile/option/bigtel.html?cl=mobile_top_MVbigtel)

[![OPPO Reno13 A：24回払い1,840円(税込2,024円)/月](https://join.biglobe.ne.jp/v3/image/mobile/slide/oppo_reno13_a.png?v=f20a741998)](https://join.biglobe.ne.jp/mobile/device/oppo_reno13_a.html?cl=mobile_top_MVoppo_reno13_a)

[![エンタメフリー・オプション 音声SIM最大2カ月無料(初回申込)](https://join.biglobe.ne.jp/v4/image/mobile/option/entamefree/main_smp.png?v=d148915322)](https://join.biglobe.ne.jp/mobile/option/entamefree.html?cl=mobile_top_MVcpenta)

[![AQUOS sense9：24回払い2,200円(税込2,420円)/月](https://join.biglobe.ne.jp/v3/image/mobile/slide/aquos_sense9.png?v=17aa1c3a3b)](https://join.biglobe.ne.jp/mobile/device/aquos_sense9.html?cl=mobile_top_MVaquos_sense9)

Next

*   1
*   2
*   3
*   4
*   5

[![](https://join.biglobe.ne.jp/v4/image/mobile/index/nav/icon_yen.svg?v=ca1e6be027)\
\
料金プラン](https://join.biglobe.ne.jp/mobile/plan/)
[![](https://join.biglobe.ne.jp/v4/image/mobile/index/nav/icon_mobile-all.svg?v=ec37fae581)\
\
端末一覧](https://join.biglobe.ne.jp/mobile/device/)
[![](https://join.biglobe.ne.jp/v4/image/mobile/index/nav/icon_search.svg?v=fcd4caa4a8)\
\
動作確認端末](https://join.biglobe.ne.jp/mobile/device/compatibility.html)
[![](https://join.biglobe.ne.jp/v4/image/mobile/index/nav/icon_option.svg?v=f3ff186bc3)\
\
オプション](https://join.biglobe.ne.jp/mobile/option/)
[![](https://join.biglobe.ne.jp/v4/image/mobile/index/nav/icon_beginner.svg?v=bece4d2e6b)\
\
申込ガイド](https://join.biglobe.ne.jp/mobile/support/)
[![](https://join.biglobe.ne.jp/v4/image/mobile/index/nav/icon_shop.svg?v=495f86796f)\
\
店舗](https://join.biglobe.ne.jp/mobile/shop/)
[![](https://join.biglobe.ne.jp/v4/image/mobile/index/nav/icon_present.svg?v=82633c3324)\
\
キャンペーン](https://join.biglobe.ne.jp/mobile/campaign/)
[![](https://join.biglobe.ne.jp/v4/image/mobile/index/nav/icon_pen.svg?v=6c80cecbe9)\
\
ご利用の流れ](https://join.biglobe.ne.jp/mobile/prepare/#prepare_flow)

[料金プラン](https://join.biglobe.ne.jp/mobile/plan/)
をご確認ください。

[格安SIM･スマホを申し込む](https://join.biglobe.ne.jp/select/?preset=all_open&cl=mobile_top_bt01)

BIGLOBEモバイルなら！
--------------

### YouTube など  
ギガを気にせず  
楽しみ放題！

![音声通話プラン+エンタメフリー月額1,386円(税込)～](https://join.biglobe.ne.jp/v4/image/mobile/index/feature/1386yen.svg?v=bc042eecaa)

人気No.1オプションを組み合わせれば  
対象サービスの通信量ノーカウント＊1

初回 最大2カ月無料！

![エンタメフリー・オプション](https://join.biglobe.ne.jp/v4/image/mobile/index/feature/entame.svg?v=f8bc2fd5e9)

308円/月

[詳細](https://join.biglobe.ne.jp/mobile/option/entamefree.html?cl=mobile_top_plan-enta)

 ![](https://join.biglobe.ne.jp/v4/image/mobile/index/feature/service_pc.svg?v=3e41d7dfe5)

各種プラン初月無料！  
余った容量は翌月に繰り越しOK

*   ![1gb](https://join.biglobe.ne.jp/v4/image/mobile/index/feature/icon_1gb.svg?v=6e92b22224)
    
    プランＳ  
    （１ギガ）
    
    1,078円/月
    
    [申し込む](https://join.biglobe.ne.jp/select/?preset=all_open&planType=VOICE&planSize=START&entame=on&reset=true&cl=mobile_top_plan-1#/plan)
    
*   ![3gb](https://join.biglobe.ne.jp/v4/image/mobile/index/feature/icon_3gb.svg?v=ff076d6a8f)
    
    プランＲ  
    （３ギガ）
    
    1,320円/月
    
    [申し込む](https://join.biglobe.ne.jp/select/?preset=all_open&planType=VOICE&planSize=THREE_GIGA&entame=on&reset=true&cl=mobile_top_plan-3#/plan)
    
*   ![6gb](https://join.biglobe.ne.jp/v4/image/mobile/index/feature/icon_6gb.svg?v=69a1e81e09)
    
    プランＭ  
    （６ギガ）
    
    1,870円/月
    
    [申し込む](https://join.biglobe.ne.jp/select/?preset=all_open&planType=VOICE&planSize=SIX_GIGA&entame=on&reset=true&cl=mobile_top_plan-6#/plan)
    

![POINT](https://join.biglobe.ne.jp/v4/image/mobile/index/feature/icon_point.svg?v=85ab6edab4)

1GBなのに動画を見ても大丈夫？

たとえば「毎月 YouTube で10GBくらいギガを使っていて、それ以外の用途は1GB未満」の場合、エンタメフリー・オプションをつければ、1GBのプランにラクラク収まります！

*   1 一部機能・広告等除く

*   初期費用・通話料別。初月解約時は月額費用がかかります。繰り越し容量に上限あり。

*   [料金プランをみる](https://join.biglobe.ne.jp/mobile/plan/?cl=mobile_top_bt10)
    
*   [ぴったりプランを診断する](https://join.biglobe.ne.jp/mobile/plan/navigator/?cl=mobile_top_bt09)
    

[BIGLOBEモバイルが  \
選ばれる理由](https://join.biglobe.ne.jp/mobile/contents/award/?cl=mobile_top_award)

目的から探す
------

[他社から  \
乗り換えたい(MNP)](https://join.biglobe.ne.jp/mobile/prepare/mnp.html?cl=mobile_top_ab_01)
[家族でおトクに  \
使いたい](https://join.biglobe.ne.jp/mobile/plan/family/?cl=mobile_top_ab_03)
[通話料を  \
安くしたい](https://join.biglobe.ne.jp/mobile/option/bigtel.html?cl=mobile_top_ab_02)
[お近くの店舗  \
を探す](https://join.biglobe.ne.jp/mobile/shop/search.html?cl=mobile_top_ab_07)

お手持ちのスマホでも､  
新しく購入でもOK
-----------------------

*   端末とセットで購入する
    
    [![](https://join.biglobe.ne.jp/v4/image/mobile/index/choice/OPPO_Reno13_A.png?v=ada66769bd)](https://join.biglobe.ne.jp/mobile/device/?cl=mobile_top_06device)
    
    [端末一覧](https://join.biglobe.ne.jp/mobile/device/?cl=mobile_top_06device)
    
*   お持ちの端末を利用する
    
    [![](https://join.biglobe.ne.jp/v4/image/mobile/index/choice/sim.png?v=32c748985a)](https://join.biglobe.ne.jp/mobile/device/compatibility.html?cl=mobile_top_bt04)
    
    [動作確認端末](https://join.biglobe.ne.jp/mobile/device/compatibility.html?cl=mobile_top_bt04)
    

[端末とセットで購入する\
\
![](https://join.biglobe.ne.jp/v4/image/mobile/index/choice/OPPO_Reno13_A.png?v=ada66769bd)](https://join.biglobe.ne.jp/mobile/device/?cl=mobile_top_06device)
[お持ちの端末を利用する\
\
![](https://join.biglobe.ne.jp/v4/image/mobile/index/choice/sim.png?v=32c748985a)](https://join.biglobe.ne.jp/mobile/device/compatibility.html?cl=mobile_top_bt04)

[料金プラン](https://join.biglobe.ne.jp/mobile/plan/)
をご確認ください。

[格安SIMを選ぶ](https://join.biglobe.ne.jp/select/?preset=sim_open&cl=mobile_top_04cvsim/#!/plan)

[スマホセットを選ぶ](https://join.biglobe.ne.jp/select/?preset=all_open&productType=SMP&reset=true&cl=mobile_top_04cvsp/#/plan)

豊富なオプションで  
あなた好みに
------------------

*   [![](https://join.biglobe.ne.jp/v4/image/mobile/common/dummy.png?v=ed7b2e2e87)\
    \
    セキュリティ対策](https://join.biglobe.ne.jp/mobile/option/security_set.html?cl=mobile_top_07op_sec)
    
*   [![](https://join.biglobe.ne.jp/v4/image/mobile/common/dummy.png?v=ed7b2e2e87)\
    \
    エンタメフリー・オプション](https://join.biglobe.ne.jp/mobile/option/entamefree.html?cl=mobile_top_07op_entame)
    
*   [![](https://join.biglobe.ne.jp/v4/image/mobile/common/dummy.png?v=ed7b2e2e87)\
    \
    お助け  \
    サポート＋](https://join.biglobe.ne.jp/mobile/option/?cl=mobile_top_07op_otasuke#otasuke_plus)
    
*   [![](https://join.biglobe.ne.jp/v4/image/mobile/common/dummy.png?v=ed7b2e2e87)\
    \
    SIM端末保証サービス](https://join.biglobe.ne.jp/mobile/option/?cl=mobile_top_07op_simhosho#simhosho)
    

[オプション一覧](https://join.biglobe.ne.jp/mobile/option/?cl=mobile_top_07option)

はじめての格安SIM･スマホなび
----------------

[![](https://join.biglobe.ne.jp/v4/image/mobile/common/dummy.png?v=ed7b2e2e87)\
\
格安SIMとは？\
\
![](https://join.biglobe.ne.jp/v4/image/mobile/icon/question_blue.svg?v=b031c234dc)](https://join.biglobe.ne.jp/mobile/sim/#what_sim)

### 格安SIMとは？

SIM(格安SIM)とは、スマホの中に入っている通話やデータ通信をするために必要な小さなICカード(SIMカード)、もしくは、スマホ内に組み込まれている端末一体型のSIM(eSIM)のことです。電話番号や契約者情報なども記録されています。  
  
お持ちのスマホのSIMをBIGLOBEモバイルのSIMに交換することで、格安スマホとしておトクに通話やデータ通信が楽しめます。  
  
BIGLOBEモバイルでは、タイプA(au回線)とタイプD(ドコモ回線)のマルチキャリアに対応しており、また「音声通話SIM」と「データSIM」の2つのSIM種別から選ぶことができます。  
  
[BIGLOBEモバイルの共通プラン仕様](https://join.biglobe.ne.jp/mobile/plan/#plan_spec)

閉じる

[![](https://join.biglobe.ne.jp/v4/image/mobile/common/dummy.png?v=ed7b2e2e87)\
\
格安SIMは  \
なぜ安い？\
\
![](https://join.biglobe.ne.jp/v4/image/mobile/icon/question_blue.svg?v=b031c234dc)](https://join.biglobe.ne.jp/mobile/sim/#low_cost)

### 格安SIMはなぜ安い？

「格安SIM」が安い理由は、大手携帯電話会社とくらべて大幅にコストが抑えられているからです。「格安SIM」「格安スマホ」はMVNOと呼ばれる事業者が提供しており、BIGLOBEモバイルもその一つです。  
  
BIGLOBEモバイルでは、ドコモやauといった大手携帯電話会社の回線を借りて、通信サービスを提供しています。そのため、基地局の設置から回線設備の管理・維持、メンテナンス等にかかる莫大なコストが、格安SIMならかかりません。  
  
また、シンプルな料金体系やネット中心で販売／サポートをするなど、料金を抑える工夫がなされており、「格安SIM」「格安スマホ」はお客さまに安く安定したサービスを提供できているのです。

閉じる

[![](https://join.biglobe.ne.jp/v4/image/mobile/common/dummy.png?v=ed7b2e2e87)\
\
格安SIMにしたときの  \
通信速度は  \
変わりますか？\
\
![](https://join.biglobe.ne.jp/v4/image/mobile/icon/question_blue.svg?v=b031c234dc)](https://join.biglobe.ne.jp/mobile/sim/#speed)

### 格安SIMにしたときの通信速度は変わりますか？

混み合う時間帯は通信速度が遅くなる場合がありますが、LINEやSNS、Webサイトの閲覧であれば十分な速度です。

[通信速度・エリア](https://join.biglobe.ne.jp/mobile/area/?cl=mobile_faq_area)

閉じる

[![](https://join.biglobe.ne.jp/v4/image/mobile/common/dummy.png?v=ed7b2e2e87)\
\
音声通話SIMと  \
データSIMの  \
違いは？\
\
![](https://join.biglobe.ne.jp/v4/image/mobile/icon/question_blue.svg?v=b031c234dc)](https://join.biglobe.ne.jp/mobile/sim/#sim_type)

### 音声通話SIMとデータSIMの違いは？

SIMには大きく分けて、音声通話SIMとデータSIMの2種類の種別があります。

音声通話SIM(格安スマホにはじめて乗り換える方にオススメ)

音声通話もデータ通信(インターネット)もSMSもできるSIMです。MNPを利用して電話番号をそのまま＊引き継ぐこともできます。

*   衛星携帯電話、データ専用プランを除く

データSIM(ネット利用のみ。動画・ゲームを楽しみたい方にオススメ)

データ通信(インターネット)のみに特化したSIMです。

閉じる

[![](https://join.biglobe.ne.jp/v4/image/mobile/common/dummy.png?v=ed7b2e2e87)\
\
格安スマホにすると、  \
できなくなることはありますか？\
\
![](https://join.biglobe.ne.jp/v4/image/mobile/icon/question_blue.svg?v=b031c234dc)](https://join.biglobe.ne.jp/mobile/sim/#become_unable)

### 格安スマホにすると、できなくなることはありますか？

ご利用中のau、ドコモ、SoftBankのキャリアメールアドレス(@docomo.ne.jpなど)は、携帯電話会社を乗り換えると使えなくなります。BIGLOBEメール、GmailのメールアドレスやSNSアプリなど無料のサービスをご利用ください。LINEなどのアプリは引き続きご利用いただけます。

閉じる

格安SIM･格安スマホのよくある質問
------------------

*   [![](https://join.biglobe.ne.jp/v4/image/mobile/icon/icon_q.svg?v=30e24e98f4)\
    \
    支払方法はどういったものがありますか？](https://join.biglobe.ne.jp/mobile/sim/#payment)
    
    BIGLOBEモバイルのお支払方法は、次のとおりです。
    
    音声通話SIM、またはSIMとスマホのセットをお申し込みの場合
    
    ご本人名義のクレジットカードのみとなります。
    
    データSIMのみをお申し込みの場合
    
    ご本人名義のクレジットカード、または口座振替もご利用いただけます。
    
    *   利用可能なクレジットカードは[こちら](https://support.biglobe.ne.jp/jimu/keiyaku/paychg/siyou-card.html)
        
    *   お支払方法は「[KDDI請求](https://support.biglobe.ne.jp/jimu/keiyaku/paychg/kddi_seikyu.html)
        」となります。
    
*   [![](https://join.biglobe.ne.jp/v4/image/mobile/icon/icon_q.svg?v=30e24e98f4)\
    \
    今のスマホのまま格安SIMに変更できますか？](https://join.biglobe.ne.jp/mobile/sim/#keep_smartphone)
    
    変更できます。  
    今のスマホをそのまま利用する場合、写真やアプリ・SNSなどのデータを移行する手間がなくて安心です。詳しくは、格安SIM乗り換えのページをご覧ください。  
    [他社からのお乗り換え(MNP)](https://join.biglobe.ne.jp/mobile/prepare/mnp.html)
    
*   [![](https://join.biglobe.ne.jp/v4/image/mobile/icon/icon_q.svg?v=30e24e98f4)\
    \
    今使っている電話番号はそのまま引き継げますか？](https://join.biglobe.ne.jp/mobile/sim/#tel_number)
    
    MNP(携帯電話番号ポータビリティ)をご利用いただくと、お使いの電話番号をそのままBIGLOBEモバイルに引き継ぐことができます。
    
    *   衛星携帯電話、データ専用プランを除く。
    
    [MNPのご利用の流れ](https://join.biglobe.ne.jp/mobile/prepare/#prepare_flow)
    
*   [![](https://join.biglobe.ne.jp/v4/image/mobile/icon/icon_q.svg?v=30e24e98f4)\
    \
    iPhoneも格安SIMにできますか？](https://join.biglobe.ne.jp/mobile/sim/#iphone)
    
    iPhoneでも格安SIMをご利用いただけます。  
    ご契約中の携帯会社によっては、転出の際にSIMロック解除のお手続きが必要な場合があります。  
    詳しい対応状況は、動作確認端末ページをご覧ください。  
    [動作確認端末](https://join.biglobe.ne.jp/mobile/device/compatibility.html)
    
*   [![](https://join.biglobe.ne.jp/v4/image/mobile/icon/icon_q.svg?v=30e24e98f4)\
    \
    通話かけ放題プランはありますか？](https://join.biglobe.ne.jp/mobile/sim/#tel_service)
    
    国内通話が半額＊になる通話アプリ「[BIGLOBEでんわ](https://support.biglobe.ne.jp/mobile/bigtel/option.html)
    」アプリを利用した「3分/10分かけ放題」と「通話パック60/90」で合計4つの通話オプションがあります。
    
    「3分/10分かけ放題」
    
    3分または10分以内の国内通話が何度でもかけ放題
    
    *   「3分かけ放題」月額600円(税込660円)
    *   「10分かけ放題」月額830円(税込913円)
    
    「通話パック60/90」
    
    一定料金分まで国内通話が可能
    
    *   1,188円分(税込・最大60分)利用できる「通話パック60」月額600円(税込660円)
    *   1,782円分(税込・最大90分)利用できる「通話パック90」月額830円(税込913円)
    
    [「選べる通話オプション」はこちら](https://join.biglobe.ne.jp/mobile/option/bigtel.html)
    
    *   「BIGLOBEでんわ」専用アプリからの発信で国内通話料 9.9円(税込)/30秒で利用できます。標準国内通話料 22円(税込)/30秒との比較。
    
    *   「3分/10分かけ放題」、「通話パック」は「BIGLOBEでんわ」アプリより発信した国内通話のみに適用されます。「3分/10分かけ放題」と「通話パック」の併用はできません。
    *   超過する通話には9.9円(税込)/30秒の通話料がかかります。
    

[もっとみる](https://join.biglobe.ne.jp/mobile/support/faq.html?cl=mobile_top_tx01)

よく読まれている記事
----------

*   [![](https://join.biglobe.ne.jp/mobile/sim/gurashi/wp-content/uploads/2017/11/simrock_top-375x375.jpg)\
    \
    格安SIMへ移行するときSIMロック解除は必ず必要？確認方法を解説](https://join.biglobe.ne.jp/mobile/sim/gurashi/simrock171130/)
    
*   [![](https://join.biglobe.ne.jp/mobile/sim/gurashi/wp-content/uploads/2017/12/tethering_top-375x375.jpg)\
    \
    テザリングとは？Android・iPhone別にやり方と機能を解説](https://join.biglobe.ne.jp/mobile/sim/gurashi/android_tethering171214/)
    

[しむぐらしを見る](https://join.biglobe.ne.jp/mobile/sim/gurashi/)

お知らせ
----

*   2025年9月26日[「iPhone 17 Pro」の動作確認ができました](https://join.biglobe.ne.jp/mobile/device/compatibility.html)
    
*   2025年9月19日[「iPhone 17」「iPhone Air」の動作確認ができました](https://join.biglobe.ne.jp/mobile/device/compatibility.html)
    
*   2025年7月22日[新端末 OPPO Reno13 A / Redmi Note 14 Pro 5G/ moto g05 を販売開始](https://join.biglobe.ne.jp/mobile/device/?cl=mobile_top_info2_device)
    
*   2025年2月28日[「iPhone 16e」の動作確認ができました](https://join.biglobe.ne.jp/mobile/device/compatibility.html)
    
*   2024年11月21日[新端末 AQUOS sense9 / OPPO Reno11 A / Xperia 10 VI を販売開始](https://join.biglobe.ne.jp/mobile/device/?cl=mobile_top_info2_device)
    

[お知らせ一覧を見る](https://join.biglobe.ne.jp/mobile/news/)

BIGLOBEモバイルで格安SIMをはじめよう

[料金プラン](https://join.biglobe.ne.jp/mobile/plan/)
をご確認ください。

[Webでお申し込み](https://join.biglobe.ne.jp/mobile/prepare/?cl=mobile_footcv_signup)

1.  ![home](https://join.biglobe.ne.jp/v4/image/icon/icon_home.svg)
2.  BIGLOBEモバイルTOP
    ==============
    

[サイトマップ](https://join.biglobe.ne.jp/sitemap.html)

[](https://www.biglobe.co.jp/outline/brand/bipple)

[](https://www.biglobe.ne.jp/)

*   [](https://twitter.com/biglobe)
    
*   [](https://www.instagram.com/biglobe_official/)
    
*   [](https://www.facebook.com/BIGLOBE)
    
*   [](https://www.youtube.com/user/BIGLOBEchannel)
    

個人のお客さま

通信サービス

*   [BIGLOBE光](https://join.biglobe.ne.jp/ftth/hikari/?cl=global_footer_hikari)
    
*   [auひかり](https://join.biglobe.ne.jp/ftth/one/?cl=global_footer_one)
    
*   [BIGLOBEモバイル](https://join.biglobe.ne.jp/mobile/?cl=global_footer_mobile)
    
*   [BIGLOBE WiMAX](https://join.biglobe.ne.jp/mobile/wimax/?cl=global_footer_wimax)
    

オプションサービス

*   [お助けサポート＋](https://otasuke.biglobe.ne.jp/otasuke_plus/)
    
*   [インターネット端末保証サービス](https://service.biglobe.ne.jp/internethosho/)
    
*   [トータル・ネットセキュリティ](https://security.biglobe.ne.jp/tns/)
    
*   [U-NEXT for BIGLOBE](https://vod.biglobe.ne.jp/unext/)
    
*   [その他オプション](https://service.biglobe.ne.jp/)
    

Webメディア

*   [温泉大賞](https://biz.biglobe.ne.jp/onsen/award/)
    
*   [しむぐらし](https://join.biglobe.ne.jp/mobile/sim/gurashi/)
    
*   [あしたメディア](https://ashita.biglobe.co.jp/)
    

法人のお客さま

*   [BIGLOBE biz.](https://biz.biglobe.ne.jp/index.html)
    
*   [BIGLOBE光](https://biz.biglobe.ne.jp/hikari/index.html)
    
*   [フレッツ光](https://biz.biglobe.ne.jp/flets/index.html)
    
*   [プロバイダサービス](https://biz.biglobe.ne.jp/member/office/provider.html)
    
*   [光回線用 固定IPアドレス](https://biz.biglobe.ne.jp/ip/index.html)
    
*   [BIGLOBEモバイル](https://biz.biglobe.ne.jp/sim/index.html)
    
*   [BIGLOBE WiMAX](https://biz.biglobe.ne.jp/wimax/index.html)
    
*   [IPトランジット](https://biz.biglobe.ne.jp/transit/index.html)
    
*   [マカフィー®マルチ アクセス](https://biz.biglobe.ne.jp/mma/index.html)
    
*   [法人向け独自ドメイン](https://biz.biglobe.ne.jp/domain/index.html)
    
*   [ONSENWORK](https://workation.biglobe.ne.jp/onsen/)
    

企業情報

*   [企業情報](https://www.biglobe.co.jp/outline)
    
*   [トップメッセージ](https://www.biglobe.co.jp/outline/message)
    
*   [ブランド](https://www.biglobe.co.jp/outline/brand)
    
*   [サステナビリティ](https://www.biglobe.co.jp/sustainability)
    
*   [ニュース](https://www.biglobe.co.jp/pressroom)
    
*   [採用情報](https://www.biglobe.co.jp/recruit)
    
*   [BIGLOBE Style](https://style.biglobe.co.jp/)
    
*   [ソーシャルメディア](https://www.biglobe.co.jp/social)
    

ご利用中の方

*   [マイページ](https://mypage.sso.biglobe.ne.jp/?cl=global_footer_mypage)
    
*   [メール](https://auth.sso.biglobe.ne.jp/mail/?cl=global_footer_mail)
    
*   [会員サポート](https://support.biglobe.ne.jp/?cl=global_footer_support)
    

*   [お問い合わせ](https://www.biglobe.co.jp/inquire)
    
*   [消費税の表示](https://support.biglobe.ne.jp/salestax.html)
    
*   [ウェブアクセシビリティの取り組み](https://support.biglobe.ne.jp/accessibility/)
    
*   [個人情報保護ポリシー](https://www.biglobe.ne.jp/privacy.html)
    
*   [プライバシーポータル](https://www.biglobe.ne.jp/privacy-portal.html)
    
*   [Cookieポリシー](https://www.biglobe.ne.jp/cookie.html)
    
*   [特定商取引法に基づく表記](https://support.biglobe.ne.jp/tokusyo.html)
    
*   [古物営業法に基づく表記](https://support.biglobe.ne.jp/kobutsusyo.html)
    
*   [情報セキュリティ基本方針](https://www.biglobe.co.jp/security)
    
*   [商標について](https://join.biglobe.ne.jp/trademark/)
    
*   [BIGLOBEトップ](https://www.biglobe.ne.jp/)
    

[![プライバシーマーク](https://top.bcdn.jp/images/PrivacyMark.png)](https://privacymark.jp/)

[![セキュリティ認証](https://top.bcdn.jp/images/ISP.png)](https://www.biglobe.ne.jp/safesecurity.html)

[![ETOCマーク](https://top.bcdn.jp/images/ETOC.png)](https://www.etoc.jp/elite/0037)

Copyright ©BIGLOBE Inc. 2025. All rights reserved.

[ページトップへ](https://join.biglobe.ne.jp/mobile/sim/#)
