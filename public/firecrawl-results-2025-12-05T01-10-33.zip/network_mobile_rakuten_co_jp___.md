# 楽天モバイル

URL: https://network.mobile.rakuten.co.jp/

---

![](https://secure.rat.rakuten.co.jp/?cpkg_none=%7B%22acc%22%3A1312%2C%22aid%22%3A1%2C%22bid%22%3A%2217648966840609a5b0a74%22%2C%22url%22%3A%22https%3A%2F%2Fnetwork.mobile.rakuten.co.jp%2F%22%2C%22ua%22%3A%22Mozilla%2F5.0%20(iPhone%3B%20CPU%20iPhone%20OS%2018_7%20like%20Mac%20OS%20X)%20AppleWebKit%2F605.1.15%20(KHTML%2C%20like%20Gecko)%20Version%2F26.0.1%20Mobile%2F15E148%20Safari%2F604.1%22%2C%22etype%22%3A%22async%22%2C%22phoenix_pattern%22%3A%22network.mobile.rakuten.co.jp%7C%2F%7Cmnoprj_hikari_responsive%7Cdefault%22%2C%22cp%22%3A%7B%22phxcampaign%22%3A%22mnoprj_hikari_responsive%22%2C%22phxexperiment%22%3A20687%2C%22phxpattern%22%3A%22default%22%2C%22phxbanditpattern%22%3A%22default%22%2C%22phxversion%22%3A%223.2.3%22%2C%22phxcmpruntime%22%3A0.004%2C%22phxapiresptime%22%3A0.001%2C%22phxpatternloadtime%22%3A0%7D%7D)![](https://secure.rat.rakuten.co.jp/?cpkg_none=%7B%22acc%22%3A1312%2C%22aid%22%3A1%2C%22bid%22%3A%221764896684062b5ce3e54%22%2C%22url%22%3A%22https%3A%2F%2Fnetwork.mobile.rakuten.co.jp%2F%22%2C%22ua%22%3A%22Mozilla%2F5.0%20(iPhone%3B%20CPU%20iPhone%20OS%2018_7%20like%20Mac%20OS%20X)%20AppleWebKit%2F605.1.15%20(KHTML%2C%20like%20Gecko)%20Version%2F26.0.1%20Mobile%2F15E148%20Safari%2F604.1%22%2C%22etype%22%3A%22async%22%2C%22phoenix_pattern%22%3A%22network.mobile.rakuten.co.jp%7C%2F%7Cmnoprj_gadget_top_responsive%7Ctarget__root__non_login%22%2C%22cp%22%3A%7B%22phxcampaign%22%3A%22mnoprj_gadget_top_responsive%22%2C%22phxexperiment%22%3A15239%2C%22phxpattern%22%3A%22target__root__non_login%22%2C%22phxbanditpattern%22%3A%22target__86236__276802%22%2C%22phxversion%22%3A%223.2.3%22%2C%22phxcmpruntime%22%3A0.001%2C%22phxapiresptime%22%3A0%2C%22phxpatternloadtime%22%3A0%7D%7D)![](https://secure.rat.rakuten.co.jp/?cpkg_none=%7B%22acc%22%3A1312%2C%22aid%22%3A1%2C%22bid%22%3A%22176489668406322b3b21a%22%2C%22url%22%3A%22https%3A%2F%2Fnetwork.mobile.rakuten.co.jp%2F%22%2C%22ua%22%3A%22Mozilla%2F5.0%20(iPhone%3B%20CPU%20iPhone%20OS%2018_7%20like%20Mac%20OS%20X)%20AppleWebKit%2F605.1.15%20(KHTML%2C%20like%20Gecko)%20Version%2F26.0.1%20Mobile%2F15E148%20Safari%2F604.1%22%2C%22etype%22%3A%22async%22%2C%22phoenix_pattern%22%3A%22network.mobile.rakuten.co.jp%7C%2F%7Cmnoprj_gadget_simulation_responsive%7Ctarget__root__non_login%22%2C%22cp%22%3A%7B%22phxcampaign%22%3A%22mnoprj_gadget_simulation_responsive%22%2C%22phxexperiment%22%3A21892%2C%22phxpattern%22%3A%22target__root__non_login%22%2C%22phxbanditpattern%22%3A%22target__119440__364091%22%2C%22phxversion%22%3A%223.2.3%22%2C%22phxcmpruntime%22%3A0.001%2C%22phxapiresptime%22%3A0%2C%22phxpatternloadtime%22%3A0%7D%7D)![](https://secure.rat.rakuten.co.jp/?cpkg_none=%7B%22acc%22%3A1312%2C%22aid%22%3A1%2C%22bid%22%3A%221764896684064f1692ccc%22%2C%22url%22%3A%22https%3A%2F%2Fnetwork.mobile.rakuten.co.jp%2F%22%2C%22ua%22%3A%22Mozilla%2F5.0%20(iPhone%3B%20CPU%20iPhone%20OS%2018_7%20like%20Mac%20OS%20X)%20AppleWebKit%2F605.1.15%20(KHTML%2C%20like%20Gecko)%20Version%2F26.0.1%20Mobile%2F15E148%20Safari%2F604.1%22%2C%22etype%22%3A%22async%22%2C%22phoenix_pattern%22%3A%22network.mobile.rakuten.co.jp%7C%2F%7Cmnoprj_prefectures_pc%7Ctarget__root__nonlogin%22%2C%22cp%22%3A%7B%22phxcampaign%22%3A%22mnoprj_prefectures_pc%22%2C%22phxexperiment%22%3A16441%2C%22phxpattern%22%3A%22target__root__nonlogin%22%2C%22phxbanditpattern%22%3A%22target__93080__296297%22%2C%22phxversion%22%3A%223.2.3%22%2C%22phxcmpruntime%22%3A0.001%2C%22phxapiresptime%22%3A0%2C%22phxpatternloadtime%22%3A0%7D%7D)![](https://secure.rat.rakuten.co.jp/?cpkg_none=%7B%22acc%22%3A1312%2C%22aid%22%3A1%2C%22bid%22%3A%221764896684065bc29a6%22%2C%22url%22%3A%22https%3A%2F%2Fnetwork.mobile.rakuten.co.jp%2F%22%2C%22ua%22%3A%22Mozilla%2F5.0%20(iPhone%3B%20CPU%20iPhone%20OS%2018_7%20like%20Mac%20OS%20X)%20AppleWebKit%2F605.1.15%20(KHTML%2C%20like%20Gecko)%20Version%2F26.0.1%20Mobile%2F15E148%20Safari%2F604.1%22%2C%22etype%22%3A%22async%22%2C%22phoenix_pattern%22%3A%22network.mobile.rakuten.co.jp%7C%2F%7Cmnoprj_fintechkyc_mno_top_responsive%7Ctarget__root__non_login%22%2C%22cp%22%3A%7B%22phxcampaign%22%3A%22mnoprj_fintechkyc_mno_top_responsive%22%2C%22phxexperiment%22%3A16254%2C%22phxpattern%22%3A%22target__root__non_login%22%2C%22phxbanditpattern%22%3A%22target__92270__294044%22%2C%22phxversion%22%3A%223.2.3%22%2C%22phxcmpruntime%22%3A0%2C%22phxapiresptime%22%3A0%2C%22phxpatternloadtime%22%3A0%7D%7D)![](https://secure.rat.rakuten.co.jp/?cpkg_none=%7B%22acc%22%3A1312%2C%22aid%22%3A1%2C%22bid%22%3A%2217648966840666f83ed3c%22%2C%22url%22%3A%22https%3A%2F%2Fnetwork.mobile.rakuten.co.jp%2F%22%2C%22ua%22%3A%22Mozilla%2F5.0%20(iPhone%3B%20CPU%20iPhone%20OS%2018_7%20like%20Mac%20OS%20X)%20AppleWebKit%2F605.1.15%20(KHTML%2C%20like%20Gecko)%20Version%2F26.0.1%20Mobile%2F15E148%20Safari%2F604.1%22%2C%22etype%22%3A%22async%22%2C%22phoenix_pattern%22%3A%22network.mobile.rakuten.co.jp%7C%2F%7Cmnoprj_common_mnoholder_responsive%7Ctarget__root__non_login%22%2C%22cp%22%3A%7B%22phxcampaign%22%3A%22mnoprj_common_mnoholder_responsive%22%2C%22phxexperiment%22%3A21978%2C%22phxpattern%22%3A%22target__root__non_login%22%2C%22phxbanditpattern%22%3A%22target__120927__367874%22%2C%22phxversion%22%3A%223.2.3%22%2C%22phxcmpruntime%22%3A0.001%2C%22phxapiresptime%22%3A0%2C%22phxpatternloadtime%22%3A0%7D%7D)![](https://secure.rat.rakuten.co.jp/?cpkg_none=%7B%22acc%22%3A1312%2C%22aid%22%3A1%2C%22bid%22%3A%221764896684067f25cc73a%22%2C%22url%22%3A%22https%3A%2F%2Fnetwork.mobile.rakuten.co.jp%2F%22%2C%22ua%22%3A%22Mozilla%2F5.0%20(iPhone%3B%20CPU%20iPhone%20OS%2018_7%20like%20Mac%20OS%20X)%20AppleWebKit%2F605.1.15%20(KHTML%2C%20like%20Gecko)%20Version%2F26.0.1%20Mobile%2F15E148%20Safari%2F604.1%22%2C%22etype%22%3A%22async%22%2C%22phoenix_pattern%22%3A%22network.mobile.rakuten.co.jp%7C%2F%7Cmnoprj_top_plan_component_responsive%7Cdefault%22%2C%22cp%22%3A%7B%22phxcampaign%22%3A%22mnoprj_top_plan_component_responsive%22%2C%22phxexperiment%22%3A25874%2C%22phxpattern%22%3A%22default%22%2C%22phxbanditpattern%22%3A%22default%22%2C%22phxversion%22%3A%223.2.3%22%2C%22phxcmpruntime%22%3A0%2C%22phxapiresptime%22%3A0%2C%22phxpatternloadtime%22%3A0%7D%7D)   

*   個人のお客様
*   [法人のお客様](https://business.mobile.rakuten.co.jp/?scid=wi_rmb_pers_header)
    
*   Language
    
    *   日本語
    *   English
    *   简体中文
    *   繁體中文
    *   한국어
    *   tiếng việt
    *   Indonesia
    *   português
    

[Rakuten Mobile](https://network.mobile.rakuten.co.jp/?l-id=gnavi_logo_b)

==========================================================================

 [![おかげさまで950万回線](https://network.mobile.rakuten.co.jp/assets/img/common/logo-thankyou-950.png) ![おかげさまで950万回線](https://network.mobile.rakuten.co.jp/assets/img/common/logo-thankyou-950-magenta.svg)](https://network.mobile.rakuten.co.jp/feature/why-rakuten-mobile/?l-id=gnavi_banner_why-rakuten-mobile_b)

*   プラン・  
    製品
    
    スマートフォン
    
    *   [Rakuten最強プラン](https://network.mobile.rakuten.co.jp/fee/saikyo-plan/?l-id=gnavi_fee_saikyo-plan_b)
        *   [データタイプ](https://network.mobile.rakuten.co.jp/fee/saikyo-plan/data-type/?l-id=gnavi_fee_saikyo-plan_data-type_b)
            
    *   [![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-unext.svg)Rakuten最強U-NEXT](https://network.mobile.rakuten.co.jp/fee/unext/?l-id=gnavi_fee_unext_b)
        
        ![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-reduction.svg)割引プログラム
        
        *   [最強家族割\
            \
            家族でトクしたい方に](https://network.mobile.rakuten.co.jp/fee/family/?l-id=gnavi_fee_family_b)
            
        *   [最強こども割\
            \
            12歳までとーってもおトク](https://network.mobile.rakuten.co.jp/fee/kids/?l-id=gnavi_fee_kids_b)
            
        *   [最強青春割\
            \
            22歳までずーっとおトク](https://network.mobile.rakuten.co.jp/fee/youth/?l-id=gnavi_fee_youth_b)
            
        *   [最強シニアプログラム\
            \
            65歳以上から  \
            ずーっと安心&おトク](https://network.mobile.rakuten.co.jp/fee/senior/?l-id=gnavi_fee_senior_b)
            
        
    
    *   [![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-fee-simulation.svg)料金シミュレーション](https://network.mobile.rakuten.co.jp/fee/simulation/?l-id=gnavi_fee_un-limit_simulation_b)
        
    *   [製品](https://network.mobile.rakuten.co.jp/product/?l-id=gnavi_product_b)
        *   [iPhone](https://network.mobile.rakuten.co.jp/product/iphone/?l-id=gnavi_product_iphone_b)
            
        *   [Apple Watch](https://network.mobile.rakuten.co.jp/product/apple-watch/?l-id=gnavi_product_apple-watch_b)
            
        *   [Android](https://network.mobile.rakuten.co.jp/product/smartphone/?l-id=gnavi_product_smartphone_b)
            
        *   [Wi-Fiルーター](https://network.mobile.rakuten.co.jp/product/internet/?l-id=gnavi_product_internet_b)
            
        *   [アクセサリ](https://network.mobile.rakuten.co.jp/product/accessory/?l-id=gnavi_product_accessory_b)
            
        *   [その他オススメ製品](https://network.mobile.rakuten.co.jp/product/ichiba-recommended/?l-id=gnavi_product_ichiba-recommended_b)
            
    *   [オプションサービス](https://network.mobile.rakuten.co.jp/service/?l-id=gnavi_service_b)
        
    
    *   [![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-sim.svg?230731)SIM](https://network.mobile.rakuten.co.jp/product/sim/?l-id=gnavi_product_sim_b)
        *   [eSIM](https://network.mobile.rakuten.co.jp/product/sim/esim/?l-id=gnavi_product_sim_esim_b)
            
        *   [デュアルSIM](https://network.mobile.rakuten.co.jp/product/sim/dual-sim/?l-id=gnavi_product_sim_dual-sim_b)
            
        *   [ご利用製品の対応確認](https://network.mobile.rakuten.co.jp/product/byod/?l-id=gnavi_product_byod_b)
            
    
    インターネット・電気
    
    *   [Rakuten Turbo](https://network.mobile.rakuten.co.jp/internet/turbo/?l-id=gnavi_internet_turbo_b)
        *   [料金プラン](https://network.mobile.rakuten.co.jp/internet/turbo/fee/?l-id=gnavi_internet_turbo_fee_b)
            
    
    *   [楽天ひかり](https://network.mobile.rakuten.co.jp/hikari/?l-id=gnavi_hikari_b)
        *   [料金プラン](https://network.mobile.rakuten.co.jp/hikari/fee/pricelist/?l-id=gnavi_hikari_fee_b)
            
    
    *   [![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-energy.svg)楽天でんき](https://energy.rakuten.co.jp/electricity/?scid=wi_rmb_gnavi_top)
        *   [料金プラン](https://energy.rakuten.co.jp/electricity/fee/?scid=wi_rmb_gnavi_plan)
            
    
    スマホとセットでおトク
    
    *   [![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-saikyo-program.svg)最強おうちプログラム](https://network.mobile.rakuten.co.jp/campaign/home-internet/?l-id=gnavi_campaign_home-internet_b)
        *   [スマホ＋Rakuten Turbo\
            \
            Rakuten Turbo 初めて申し込みで毎月1,000ポイント還元](https://network.mobile.rakuten.co.jp/internet/turbo/campaign/home-internet/?l-id=gnavi_internet_turbo_campaign_home-internet_b)
            
        *   [スマホ＋楽天ひかり\
            \
            楽天ひかり初めて申し込みで毎月1,000ポイント還元](https://network.mobile.rakuten.co.jp/hikari/campaign/home-internet/?l-id=gnavi_hikari_campaign_home-internet_b)
            
    
*   通信エリア・  
    店舗
    
    通信エリア
    
    *   [スマートフォン](https://network.mobile.rakuten.co.jp/area/?l-id=gnavi_area_b)
        
    *   [Rakuten Turbo](https://network.mobile.rakuten.co.jp/internet/turbo/area/?l-id=gnavi_internet_turbo_area_b)
        
    
    ご来店のお客様へ
    
    *   [ショップ（店舗）](https://network.mobile.rakuten.co.jp/shop/?l-id=gnavi_shop_b)
        
    
*   キャンペーン
    
    キャンペーン
    
    *   [スマートフォン](https://network.mobile.rakuten.co.jp/campaign/?l-id=gnavi_campaign_b)
        
    *   [Rakuten Turbo](https://network.mobile.rakuten.co.jp/internet/turbo/campaign/home-internet/?l-id=gnavi_internet_turbo_campaign_home-internet_b)
        
    *   [楽天ひかり](https://network.mobile.rakuten.co.jp/hikari/campaign/home-internet/?l-id=gnavi_hikari_campaign_home-internet_b)
        
    *   [![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-energy.svg)楽天でんき](https://energy.rakuten.co.jp/campaign/lp/mobilelink/?scid=wi_rmb_gnavi_cpn)
        
    
*   お知らせ・  
    サポート
    
    お知らせ・その他
    
    *   [お知らせ](https://network.mobile.rakuten.co.jp/information/?l-id=gnavi_info_b)
        *   [スーパーホーダイ／組み合わせプランを  \
            ご利用中の方](https://mobile.rakuten.co.jp/mvno/?l-id=gnavi_mvno_b)
            
    
    ご検討中の方へ
    
    *   [![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-new-user.svg)お申し込みガイド](https://network.mobile.rakuten.co.jp/guide/procedure/?l-id=gnavi_guide_procedure_b)
        
    *   [なぜ今楽天モバイルなのか](https://network.mobile.rakuten.co.jp/feature/why-rakuten-mobile/?l-id=gnavi_feature_why-rakuten-mobile_b)
        
    *   [お客様の声](https://network.mobile.rakuten.co.jp/uservoice/?l-id=gnavi_uservoice_b)
        
    *   [スマホ活用術を学ぶ](https://network.mobile.rakuten.co.jp/sumakatsu/?l-id=gnavi_sumakatsu_b)
        
    
    お客様サポート
    
    *   [楽天モバイル](https://network.mobile.rakuten.co.jp/support/?l-id=gnavi_support_b)
        
    *   [Rakuten Turbo](https://network.mobile.rakuten.co.jp/internet/turbo/support/?l-id=gnavi_internet_turbo_support_b)
        
    *   [楽天ひかり](https://network.mobile.rakuten.co.jp/hikari/support/?l-id=gnavi_hikari_support_b)
        
    *   [![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-energy.svg)楽天でんき](https://energy.rakuten.co.jp/faq/?scid=wi_rmb_gnavi_qa)
        
    

メニュー

検索

[my 楽天モバイル](https://portal.mobile.rakuten.co.jp/ja/my-rakuten-mobile?l-id=network_gnavi_ecare_b)

[お申し込み](https://network.mobile.rakuten.co.jp/guide/application/?ref=header&lid-r=gnavi_onboarding_b)

 

よく検索されるワード
----------

検索履歴
----

[お申し込み](https://network.mobile.rakuten.co.jp/guide/application/?ref=header&lid-r=burger_onboarding_b)
 [my 楽天モバイル](https://portal.mobile.rakuten.co.jp/ja/my-rakuten-mobile?l-id=network_burger_ecare_b)

*   ご検討中の方へ
    
*   料金プラン・製品
    
*   通信エリア
    
*   [ショップ（店舗）](https://network.mobile.rakuten.co.jp/shop/?l-id=burger_shop_b)
    
*   キャンペーン
    
*   [お知らせ](https://network.mobile.rakuten.co.jp/information/?l-id=burger_info_b)
    
*   お客様サポート
    

Language

日本語

*   日本語
*   English
*   简体中文
*   繁體中文
*   한국어
*   tiếng việt
*   Indonesia
*   português

[スーパーホーダイ／組み合わせプランをご利用中の方](https://mobile.rakuten.co.jp/mvno/?l-id=burger_mvno_b)

[法人のお客様](https://business.mobile.rakuten.co.jp/?scid=wi_rmb_pers_burger)

料金プラン・製品

スマートフォン

*   料金プラン
    
*   [![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-fee-simulation.svg)料金シミュレーション](https://network.mobile.rakuten.co.jp/fee/simulation/?l-id=burger_fee_un-limit_simulation_b)
    
*   [オプションサービス](https://network.mobile.rakuten.co.jp/service/?l-id=burger_service_b)
    
*   製品
    
*   ![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-sim.svg?230731)SIM
    

おトクな割引・還元プログラムも必見

[![最強家族割](https://network.mobile.rakuten.co.jp/assets/img/common/img-family-251118.png)](https://network.mobile.rakuten.co.jp/fee/family/?l-id=burger_banner_fee-family_b)

[![最強こども割](https://network.mobile.rakuten.co.jp/assets/img/common/img-kids-251118.png)](https://network.mobile.rakuten.co.jp/fee/kids/?l-id=burger_banner_fee-kids_b)

[![最強青春割](https://network.mobile.rakuten.co.jp/assets/img/common/img-youth-251118.png)](https://network.mobile.rakuten.co.jp/fee/youth/?l-id=burger_banner_fee-youth_b)

[![最強シニアプログラム](https://network.mobile.rakuten.co.jp/assets/img/common/img-senior-251118.png)](https://network.mobile.rakuten.co.jp/fee/senior/?l-id=burger_banner_fee_senior_b)

インターネット・電気

*   Rakuten Turbo
    
*   楽天ひかり
    
*   ![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-energy.svg)楽天でんき
    

スマホとセットでおトク

*   ![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-saikyo-program.svg)最強おうちプログラム
    

製品

*   [製品トップ](https://network.mobile.rakuten.co.jp/product/?l-id=burger_product_b)
    
*   [iPhone](https://network.mobile.rakuten.co.jp/product/iphone/?l-id=burger_product_iphone_b)
    
*   [Apple Watch](https://network.mobile.rakuten.co.jp/product/apple-watch/?l-id=burger_product_apple-watch_b)
    
*   [Android](https://network.mobile.rakuten.co.jp/product/smartphone/?l-id=burger_product_smartphone_b)
    
*   [Wi-Fiルーター](https://network.mobile.rakuten.co.jp/product/internet/?l-id=burger_product_internet_b)
    
*   [アクセサリ](https://network.mobile.rakuten.co.jp/product/accessory/?l-id=burger_product_accessory_b)
    
*   [その他オススメ製品](https://network.mobile.rakuten.co.jp/product/ichiba-recommended/?l-id=burger_product_ichiba-recommended_b)
    

料金プラン

料金プラン

*   [Rakuten最強プラン\
    \
    シンプルで使いやすいプラン](https://network.mobile.rakuten.co.jp/fee/saikyo-plan/?l-id=burger_fee_saikyo-plan_b)
    
*   [Rakuten最強プラン データタイプ\
    \
    データ通信のみ必要な方に](https://network.mobile.rakuten.co.jp/fee/saikyo-plan/data-type/?l-id=burger_fee_saikyo-plan_data-type_b)
    
*   [Rakuten最強U-NEXT\
    \
    動画や雑誌も楽しみたい方に](https://network.mobile.rakuten.co.jp/fee/unext/?l-id=burger_fee_unext_b)
    

割引プログラム

*   [最強家族割\
    \
    家族でトクしたい方に](https://network.mobile.rakuten.co.jp/fee/family/?l-id=burger_fee_family_b)
    
*   [最強こども割\
    \
    12歳までとーってもおトク](https://network.mobile.rakuten.co.jp/fee/kids/?l-id=burger_fee_kids_b)
    
*   [最強青春割\
    \
    22歳までずーっとおトク](https://network.mobile.rakuten.co.jp/fee/youth/?l-id=burger_fee_youth_b)
    
*   [最強シニアプログラム\
    \
    65歳以上からずーっと安心＆おトク](https://network.mobile.rakuten.co.jp/fee/senior/?l-id=burger_fee_senior_b)
    

![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-sim.svg?230731)SIM

*   [SIM](https://network.mobile.rakuten.co.jp/product/sim/?l-id=burger_product_sim_b)
    
*   [eSIM](https://network.mobile.rakuten.co.jp/product/sim/esim/?l-id=burger_product_sim_esim_b)
    
*   [デュアルSIM](https://network.mobile.rakuten.co.jp/product/sim/dual-sim/?l-id=burger_product_sim_dual-sim_b)
    
*   [ご利用製品の対応確認](https://network.mobile.rakuten.co.jp/product/byod/?l-id=burger_product_byod_b)
    

Rakuten Turbo

*   [トップ](https://network.mobile.rakuten.co.jp/internet/turbo/?l-id=burger_internet_turbo_b)
    
*   [料金プラン](https://network.mobile.rakuten.co.jp/internet/turbo/fee/?l-id=burger_internet_turbo_fee_b)
    

楽天ひかり

*   [トップ](https://network.mobile.rakuten.co.jp/hikari/?l-id=burger_hikari_b)
    
*   [料金プラン](https://network.mobile.rakuten.co.jp/hikari/fee/pricelist/?l-id=burger_hikari_fee_b)
    

![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-energy.svg)楽天でんき

*   [トップ](https://energy.rakuten.co.jp/electricity/?scid=wi_rmb_gnavi_top)
    
*   [料金プラン](https://energy.rakuten.co.jp/electricity/fee/?scid=wi_rmb_gnavi_plan)
    

![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-saikyo-program.svg)最強おうちプログラム

*   [トップ](https://network.mobile.rakuten.co.jp/campaign/home-internet/?l-id=burger_campaign_home-internet_b)
    
*   [スマホ＋Rakuten Turbo\
    \
    Rakuten Turbo 初めて申し込みで毎月1,000ポイント還元](https://network.mobile.rakuten.co.jp/internet/turbo/campaign/home-internet/?l-id=burger_internet_turbo_campaign_home-internet_b)
    
*   [スマホ＋楽天ひかり\
    \
    楽天ひかり初めて申し込みで毎月1,000ポイント還元](https://network.mobile.rakuten.co.jp/hikari/campaign/home-internet/?l-id=burger_hikari_campaign_home-internet_b)
    

通信エリア

*   [スマートフォン](https://network.mobile.rakuten.co.jp/area/?l-id=burger_area_b)
    
*   [Rakuten Turbo](https://network.mobile.rakuten.co.jp/internet/turbo/area/?l-id=burger_internet_turbo_area_b)
    

キャンペーン

*   [スマートフォン](https://network.mobile.rakuten.co.jp/campaign/?l-id=burger_campaign_b)
    
*   [Rakuten Turbo](https://network.mobile.rakuten.co.jp/internet/turbo/campaign/home-internet/?l-id=burger_internet_turbo_campaign_home-internet_b)
    
*   [楽天ひかり](https://network.mobile.rakuten.co.jp/hikari/campaign/home-internet/?l-id=burger_hikari_campaign_home-internet_b)
    
*   [楽天でんき](https://energy.rakuten.co.jp/campaign/lp/mobilelink/?scid=wi_rmb_gnavi_cpn)
    

ご検討中の方へ

*   [お申し込みガイド](https://network.mobile.rakuten.co.jp/guide/procedure/?l-id=burger_guide_procedure_b)
    
*   [なぜ今楽天モバイルなのか](https://network.mobile.rakuten.co.jp/feature/why-rakuten-mobile/?l-id=burger_feature_why-rakuten-mobile_b)
    
*   [お客様の声](https://network.mobile.rakuten.co.jp/uservoice/?l-id=burger_uservoice_b)
    
*   [スマホ活用術を学ぶ](https://network.mobile.rakuten.co.jp/sumakatsu/?l-id=burger_sumakatsu_b)
    

お客様サポート

*   [楽天モバイル](https://network.mobile.rakuten.co.jp/support/?l-id=burger_support_b)
    
*   [Rakuten Turbo](https://network.mobile.rakuten.co.jp/internet/turbo/support/?l-id=burger_internet_turbo_support_b)
    
*   [楽天ひかり](https://network.mobile.rakuten.co.jp/hikari/support/?l-id=burger_hikari_support_b)
    
*   [楽天でんき](https://energy.rakuten.co.jp/faq/?scid=wi_rmb_gnavi_qa)
    

Choose your language for Rakuten Mobile !
-----------------------------------------

Our services are provided within the region and laws of Japan.

日本語 English 简体中文 繁體中文 한국어 tiếng việt Indonesia português

Select Language

Our services are provided within the region and laws of Japan and we provide translations for your convenience.  
The Japanese version of our websites and applications, in which include Rakuten Membership Rules, Privacy Policy or other terms and conditions, is the definitive version , unless otherwise indicated.  
If there are any discrepancies, the Japanese version shall prevail.  
We do not guarantee that we always provide translation.  
The Japanese versions of all terms and conditions, policies, and other notices are the definitive versions. Any dispute related to the terms and conditions, policies, or other notices will be under the jurisdiction of Japanese law, regardless of any conflicting laws or principles.  
Certain features or messages (including customer services) may not be available in the selected language.

Enjoy Rakuten Mobile in English!
--------------------------------

Our services are provided within the region and laws of Japan and we provide translations for your convenience.  
The Japanese version of our websites and applications, in which include Rakuten Membership Rules, Privacy Policy or other terms and conditions, is the definitive version , unless otherwise indicated.  
If there are any discrepancies, the Japanese version shall prevail.  
We do not guarantee that we always provide translation.  
The Japanese versions of all terms and conditions, policies, and other notices are the definitive versions. Any dispute related to the terms and conditions, policies, or other notices will be under the jurisdiction of Japanese law, regardless of any conflicting laws or principles.  
Certain features or messages (including customer services) may not be available in the selected language.

 [![iPhone17 最新のiPhone販売中！](https://network.mobile.rakuten.co.jp/assets/img/top/pc-mnp-banner-250919.png)](https://network.mobile.rakuten.co.jp/product/iphone/?l-id=top_header_mno_product_iphone)

 [![iPhone17 最新のiPhone販売中！](https://network.mobile.rakuten.co.jp/assets/img/top/pc-mnp-banner-250919.png)](https://network.mobile.rakuten.co.jp/product/iphone/?l-id=top_header_non-mno_1-entry_non-6months_product_iphone)

 [![iPhone17 最新のiPhone販売中！](https://network.mobile.rakuten.co.jp/assets/img/top/pc-mnp-banner-250919.png)](https://network.mobile.rakuten.co.jp/product/iphone/?l-id=top_header_non_login_product_iphone)

 [![iPhone17 最新のiPhone販売中！](https://network.mobile.rakuten.co.jp/assets/img/top/pc-mnp-banner-250919.png)](https://network.mobile.rakuten.co.jp/product/iphone/?l-id=top_header_else_product_iphone)

 [![iPhone17 最新のiPhone販売中！](https://network.mobile.rakuten.co.jp/assets/img/top/pc-mnp-banner-250919.png)](https://network.mobile.rakuten.co.jp/product/iphone/?l-id=top_header_non-mno_non-entry_product_iphone)

 [![iPhone17 最新のiPhone販売中！](https://network.mobile.rakuten.co.jp/assets/img/top/pc-mnp-banner-250919.png)](https://network.mobile.rakuten.co.jp/product/iphone/?l-id=top_header_non-mno_1-entry_product_iphone)

 [![iPhone17 最新のiPhone販売中！](https://network.mobile.rakuten.co.jp/assets/img/top/pc-mnp-banner-250919.png)](https://network.mobile.rakuten.co.jp/product/iphone/?l-id=top_header_non-mno_2-entry_product_iphone)

災害用伝言板 提供中

パソコンや携帯電話からもご利用できます。  
[ご利用方法はこちら](https://network.mobile.rakuten.co.jp/service/disaster_board/)

[安否情報を確認・登録する](https://public-safety.mobile.rakuten.co.jp/?lang=ja)
 [\[ENG\] Disaster Message Board](https://public-safety.mobile.rakuten.co.jp/?lang=en)

災害用伝言板 体験サービス実施中

*   [体験サービスの詳細を見る](https://network.mobile.rakuten.co.jp/service/disaster_board/#trial-services)
    

ようこそ楽天モバイルへ

[ログイン](https://grp03.id.rakuten.co.jp/rms/nid/login?service_id=rm005&client_id=rmn_app_web&redirect_uri=https%3A%2F%2Fnetwork.mobile.rakuten.co.jp%2F&err_redirect_uri=https%3A%2F%2Fnetwork.mobile.rakuten.co.jp%2F&scope=memberinfo_read_safebulk%2Cmemberinfo_read_point%2Cmemberinfo_get_card_token%2C30days%40Access%2C90days%40Refresh&contact_info_required=false&rae_service_id=rm005)
 / [会員登録](https://grp01.id.rakuten.co.jp/rms/nid/registfwd?service_id=rm005)

 ![楽天ポイントご利用であなたのスマホ代がタダ（データ3GBまで）になることも！](https://network.mobile.rakuten.co.jp/assets/img/common/login/txt-non-member-pc-230116.png)

 [![ご利用可能なポイントを確認](https://network.mobile.rakuten.co.jp/assets/img/common/login/btn-non-member-pc.png)](https://grp03.id.rakuten.co.jp/rms/nid/login?service_id=rm005&client_id=rmn_app_web&redirect_uri=https%3A%2F%2Fnetwork.mobile.rakuten.co.jp%2F&err_redirect_uri=https%3A%2F%2Fnetwork.mobile.rakuten.co.jp%2F&scope=memberinfo_read_safebulk%2Cmemberinfo_read_point%2Cmemberinfo_get_card_token%2C30days%40Access%2C90days%40Refresh&contact_info_required=false&rae_service_id=rm005)

※プラン料金データ3GB(1,078円/月)を全額楽天ポイントで支払時。端末割賦料金を除く

[](https://my.rakuten.co.jp/)
さん

ポイント

 ![あと](https://network.mobile.rakuten.co.jp/assets/img/common/login/text-01.png)![ポイント獲得すると](https://network.mobile.rakuten.co.jp/assets/img/common/login/text-02.png)

 [![料金プランを詳しくみる](https://network.mobile.rakuten.co.jp/assets/img/common/login/btn-plan-detail-pc.png?221129)](https://network.mobile.rakuten.co.jp/#)

[ログアウト](https://network.mobile.rakuten.co.jp/logout/)

[](https://my.rakuten.co.jp/)
さん

ポイント

[ログアウト](https://network.mobile.rakuten.co.jp/logout/)

ようこそ楽天モバイルへ

あなた向けの情報をログインしてチェック！

[ログイン](https://grp03.id.rakuten.co.jp/rms/nid/login?service_id=rm005&client_id=rmn_app_web&redirect_uri=https%3A%2F%2Fnetwork.mobile.rakuten.co.jp%2F&err_redirect_uri=https%3A%2F%2Fnetwork.mobile.rakuten.co.jp%2F&scope=memberinfo_read_safebulk%2Cmemberinfo_read_point%2Cmemberinfo_get_card_token%2C30days%40Access%2C90days%40Refresh&contact_info_required=false&rae_service_id=rm005)
 [会員登録](https://grp01.id.rakuten.co.jp/rms/nid/registfwd?service_id=rm005)

あなた向けの情報をログインしてチェック！

ご契約中はSPU+4倍!

ポイントでスマホ代も支払える!

[さん](https://my.rakuten.co.jp/)

ポイント

[ログアウト](https://network.mobile.rakuten.co.jp/logout/)

![ギガ無制限でつながる!※1](https://network.mobile.rakuten.co.jp/assets/img/top/img-prefecutre-giga-txt.png)

![](https://network.mobile.rakuten.co.jp/assets/img/top/prefecture/bg-saitama.png)

さんがお住まいの

埼玉県

は人口カバー率

99.98%

※11

[あなたの生活圏のつながるを確認](https://network.mobile.rakuten.co.jp/area/saitama/?l-id=top_area_saitama_inhouse_non-login_1-2&s-id=top_area_saitama_all)

[店舗検索](https://network.mobile.rakuten.co.jp/shop/search/?l-id=top_shop_search_saitama_inhouse_non-login_1-2&s-id=top_shop_search_saitama_all&prefecture=%E5%9F%BC%E7%8E%89%E7%9C%8C&city=&type=gadget)

 

[](https://my.rakuten.co.jp/)
さん

ポイント

au をご利用中のお客様

NTTドコモ をご利用中のお客様

SoftBank をご利用中のお客様

Y!mobile をご利用中のお客様

UQ mobile をご利用中のお客様

[ログアウト](https://network.mobile.rakuten.co.jp/logout/)

ようこそ楽天モバイルへ

[ログイン](https://grp03.id.rakuten.co.jp/rms/nid/login?service_id=rm005&client_id=rmn_app_web&redirect_uri=https%3A%2F%2Fnetwork.mobile.rakuten.co.jp%2F&err_redirect_uri=https%3A%2F%2Fnetwork.mobile.rakuten.co.jp%2F&scope=memberinfo_read_safebulk%2Cmemberinfo_read_point%2Cmemberinfo_get_card_token%2C30days%40Access%2C90days%40Refresh&contact_info_required=false&rae_service_id=rm005)

![スマホ料金毎月いくら払ってますか？](https://network.mobile.rakuten.co.jp/assets/img/top/login-gadget/title-simulation-241213.png)

 ![カンタン10秒チェック](https://network.mobile.rakuten.co.jp/assets/img/top/login-gadget/img-circle-241214.png)

約11,000円/月以上 約10,000円/月 約9,000円/月 約8,000円/月 約7,000円/月 約6,000円/月 約5,000円/月 約4,000円/月 約3,000円/月 約2,000円/月 約1,000円/月

[どれだけおトクか見てみよう](https://network.mobile.rakuten.co.jp/fee/mnp-simulation/result/?price=6000&carrier=non-login&l-id=mnp-simulation_gadget_fee_mnp-simulation-result_non-login_1-2)

※上記以外の携帯電話会社をご利用の場合は[こちら](https://network.mobile.rakuten.co.jp/fee/simulation/?l-id=mnp-simulation_gadget_fee_simulation_non-login_1-2)

[![最強青春割 22歳まではずーっとおトク！家族割引併用時、データ3GB780円（税込858円）](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-fee-youth-1032-300-251126.png)](https://network.mobile.rakuten.co.jp/fee/youth/?l-id=top_carousel_none_fee_youth)

[![最強おうちプログラム　ネットとスマホ、セットでおトク！楽天モバイル＋Rakuten Turbo初めてお申し込みで永年毎月1,000ポイント還元 製品代48回払い分の867円/月をプラン料金から割引 48カ月間のご利用でRakutenTurbo5G製品代（41,580円）実質0円](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-turbo-1032-300-250806.png)](https://network.mobile.rakuten.co.jp/internet/turbo/campaign/home-internet/?l-id=top_carousel_none_internet_turbo_campaign_home-internet)

[![今年最後!楽天マジ得フェスティバル 楽天カード会員様対象 楽天モバイル初めてのお申し込みで20,000ポイント※期間限定ポイントなど条件あり](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-card-mobile-majitoku-1032-300-251201.png)](https://network.mobile.rakuten.co.jp/campaign/card-mobile-majitoku/?l-id=top_carousel_none_campaign_card-mobile-majitoku)

[![「Rakuten最強U-NEXT」はギガもアプリ通話も無制限＆映画もアニメも見放題！スタート記念の特別価格で2,880円（税込3,168円）](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-unext-1032-300-251121.png)](https://network.mobile.rakuten.co.jp/fee/unext/?l-id=top_carousel_none_fee_unext)

[![【要エントリー】楽天モバイル初めてお申し込みキャンペーンでお乗り換えは10,000ポイント・新規お申し込みは7,000ポイントプレゼント! ](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-mnp-1032-300-251201-1400.png)](https://network.mobile.rakuten.co.jp/campaign/mnp/?l-id=top_carousel_none_campaign_mnp)

[![iPhone 17 Pro 楽天モバイルで販売中](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-iphone-17-pro-led-1032-300-250919.png)](https://network.mobile.rakuten.co.jp/product/iphone/?l-id=top_carousel_none_product_iphone)

[![iPhone 16e（128GB）がおトク！他社から電話番号そのまま乗り換え＋楽天カード48回払いで1円/月～！（1～24回目まで、25回目以降4,365円/月～）](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-iphone-point-iphone-16e-1032-300-251128.png)](https://network.mobile.rakuten.co.jp/campaign/iphone-point-iphone-16e/?l-id=top_carousel_none_campaign_iphone-point-iphone-16e)

[![楽天モバイル初めてのお申し込み＋他社から電話番号そのまま乗り換え＋楽天市場でのお買い物で最大14,000ポイントGET！](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-shop-limited-application-1032-300-250919.png)](https://network.mobile.rakuten.co.jp/campaign/shop-limited-application/?l-id=top_carousel_none_campaign_shop-limited-application)

[![【要エントリー】最新機種のiPhone 17やiPhone 17 Proなどが対象！対象iPhoneを購入+楽天モバイルへ初めて申し込み+他社から電話番号そのまま乗り換え+対象iPhone下取りで最大21,000ポイント！](https://network.mobile.rakuten.co.jp/assets/img/bnr/iphone-point-iphone-17-1032-300-250912.png)](https://network.mobile.rakuten.co.jp/campaign/iphone-point-iphone-17/?l-id=top_carousel_none_campaign_iphone-point-iphone-17)

[![楽天モバイル申し込み＋他社から電話番号そのまま乗り換え＋対象製品購入で1円！](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-android-discount-1032-300-251202.png)](https://network.mobile.rakuten.co.jp/campaign/android-discount/?l-id=top_carousel_none_campaign_android-discount)

[![iPhone Air 楽天モバイルで販売中](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-iphone-air-led-1032-300-250919.png)](https://network.mobile.rakuten.co.jp/product/iphone/iphone-air/?l-id=top_carousel_none_product_iphone_iphone-air)

[![Rakuten WiFi Pocket Platinumが楽天モバイルお申し込みで1円](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-rakuten-wifi-pocket-platinum-1032-300-250930.png)](https://network.mobile.rakuten.co.jp/product/internet/rakuten-wifi-pocket-platinum/?l-id=top_carousel_none_product_internet_rakuten-wifi-pocket-platinum)

[![楽天モバイル紹介キャンペーン！紹介1人につき7,000ポイント、紹介される方も最大13,000ポイントプレゼント！](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-referral-1032-300-250905.png)](https://network.mobile.rakuten.co.jp/campaign/referral/?l-id=top_carousel_none_campaign_referral)

[![電話番号そのまま！MNP予約番号なしで乗り換えできる！MNPワンストップ  Webでの申し込みがさらに簡単に。乗り換えるなら楽天モバイル](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-fast-convert-1032-300-250707.png)](https://network.mobile.rakuten.co.jp/guide/mnp/fast-convert/?l-id=top_carousel_none_guide_mnp_fast-convert)

[![【要エントリー】楽天モバイルへ初めてお申し込み＋他社から電話番号そのまま乗り換え＋arrows Alphaご購入で最大26,000円ポイント還元!](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-arrows-alpha-1032-300-251121.png)](https://network.mobile.rakuten.co.jp/product/smartphone/arrows-alpha/?l-id=top_carousel_none_product_arrows-alpha)

[![Google Pixel 9a 月々なんと!買い替え超トクプログラム48回払い750円/月～](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-product-smartphone-google-pixel-9a-1032-300-251201.png)](https://network.mobile.rakuten.co.jp/product/smartphone/google-pixel-9a/?l-id=top_carousel_none_product_google-pixel-9a)

[![Apple Watch Series 11 心に届くギフトを。Apple Watch。](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-apple-watch-series11-1032-300-251126.png)](https://network.mobile.rakuten.co.jp/product/apple-watch/apple-watch-series11/?l-id=top_carousel_none_product_apple-watch)

[![最強家族割は データ3GB（家族割引のみ適用時）全キャリア最安880円/月～（税込968円～）！ 紹介キャンペーン活用で合計10万ポイント獲得のチャンス！！](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-saikyo-family-program-1032-300-251126.png)](https://network.mobile.rakuten.co.jp/fee/family/?l-id=top_carousel_none_fee_family)

[![最強青春割 22歳まではずーっとおトク！家族割引併用時、データ3GB780円（税込858円）](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-fee-youth-1032-300-251126.png)](https://network.mobile.rakuten.co.jp/fee/youth/?l-id=top_carousel_none_fee_youth)

[![最強おうちプログラム　ネットとスマホ、セットでおトク！楽天モバイル＋Rakuten Turbo初めてお申し込みで永年毎月1,000ポイント還元 製品代48回払い分の867円/月をプラン料金から割引 48カ月間のご利用でRakutenTurbo5G製品代（41,580円）実質0円](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-turbo-1032-300-250806.png)](https://network.mobile.rakuten.co.jp/internet/turbo/campaign/home-internet/?l-id=top_carousel_none_internet_turbo_campaign_home-internet)

[![今年最後!楽天マジ得フェスティバル 楽天カード会員様対象 楽天モバイル初めてのお申し込みで20,000ポイント※期間限定ポイントなど条件あり](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-card-mobile-majitoku-1032-300-251201.png)](https://network.mobile.rakuten.co.jp/campaign/card-mobile-majitoku/?l-id=top_carousel_none_campaign_card-mobile-majitoku)

[![「Rakuten最強U-NEXT」はギガもアプリ通話も無制限＆映画もアニメも見放題！スタート記念の特別価格で2,880円（税込3,168円）](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-unext-1032-300-251121.png)](https://network.mobile.rakuten.co.jp/fee/unext/?l-id=top_carousel_none_fee_unext)

[![【要エントリー】楽天モバイル初めてお申し込みキャンペーンでお乗り換えは10,000ポイント・新規お申し込みは7,000ポイントプレゼント! ](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-mnp-1032-300-251201-1400.png)](https://network.mobile.rakuten.co.jp/campaign/mnp/?l-id=top_carousel_none_campaign_mnp)

[![iPhone 17 Pro 楽天モバイルで販売中](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-iphone-17-pro-led-1032-300-250919.png)](https://network.mobile.rakuten.co.jp/product/iphone/?l-id=top_carousel_none_product_iphone)

[![iPhone 16e（128GB）がおトク！他社から電話番号そのまま乗り換え＋楽天カード48回払いで1円/月～！（1～24回目まで、25回目以降4,365円/月～）](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-iphone-point-iphone-16e-1032-300-251128.png)](https://network.mobile.rakuten.co.jp/campaign/iphone-point-iphone-16e/?l-id=top_carousel_none_campaign_iphone-point-iphone-16e)

[![楽天モバイル初めてのお申し込み＋他社から電話番号そのまま乗り換え＋楽天市場でのお買い物で最大14,000ポイントGET！](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-shop-limited-application-1032-300-250919.png)](https://network.mobile.rakuten.co.jp/campaign/shop-limited-application/?l-id=top_carousel_none_campaign_shop-limited-application)

[![【要エントリー】最新機種のiPhone 17やiPhone 17 Proなどが対象！対象iPhoneを購入+楽天モバイルへ初めて申し込み+他社から電話番号そのまま乗り換え+対象iPhone下取りで最大21,000ポイント！](https://network.mobile.rakuten.co.jp/assets/img/bnr/iphone-point-iphone-17-1032-300-250912.png)](https://network.mobile.rakuten.co.jp/campaign/iphone-point-iphone-17/?l-id=top_carousel_none_campaign_iphone-point-iphone-17)

[![楽天モバイル申し込み＋他社から電話番号そのまま乗り換え＋対象製品購入で1円！](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-android-discount-1032-300-251202.png)](https://network.mobile.rakuten.co.jp/campaign/android-discount/?l-id=top_carousel_none_campaign_android-discount)

[![iPhone Air 楽天モバイルで販売中](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-iphone-air-led-1032-300-250919.png)](https://network.mobile.rakuten.co.jp/product/iphone/iphone-air/?l-id=top_carousel_none_product_iphone_iphone-air)

[![Rakuten WiFi Pocket Platinumが楽天モバイルお申し込みで1円](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-rakuten-wifi-pocket-platinum-1032-300-250930.png)](https://network.mobile.rakuten.co.jp/product/internet/rakuten-wifi-pocket-platinum/?l-id=top_carousel_none_product_internet_rakuten-wifi-pocket-platinum)

[![楽天モバイル紹介キャンペーン！紹介1人につき7,000ポイント、紹介される方も最大13,000ポイントプレゼント！](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-referral-1032-300-250905.png)](https://network.mobile.rakuten.co.jp/campaign/referral/?l-id=top_carousel_none_campaign_referral)

[![電話番号そのまま！MNP予約番号なしで乗り換えできる！MNPワンストップ  Webでの申し込みがさらに簡単に。乗り換えるなら楽天モバイル](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-fast-convert-1032-300-250707.png)](https://network.mobile.rakuten.co.jp/guide/mnp/fast-convert/?l-id=top_carousel_none_guide_mnp_fast-convert)

[![【要エントリー】楽天モバイルへ初めてお申し込み＋他社から電話番号そのまま乗り換え＋arrows Alphaご購入で最大26,000円ポイント還元!](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-arrows-alpha-1032-300-251121.png)](https://network.mobile.rakuten.co.jp/product/smartphone/arrows-alpha/?l-id=top_carousel_none_product_arrows-alpha)

[![Google Pixel 9a 月々なんと!買い替え超トクプログラム48回払い750円/月～](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-product-smartphone-google-pixel-9a-1032-300-251201.png)](https://network.mobile.rakuten.co.jp/product/smartphone/google-pixel-9a/?l-id=top_carousel_none_product_google-pixel-9a)

[![Apple Watch Series 11 心に届くギフトを。Apple Watch。](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-apple-watch-series11-1032-300-251126.png)](https://network.mobile.rakuten.co.jp/product/apple-watch/apple-watch-series11/?l-id=top_carousel_none_product_apple-watch)

[![最強家族割は データ3GB（家族割引のみ適用時）全キャリア最安880円/月～（税込968円～）！ 紹介キャンペーン活用で合計10万ポイント獲得のチャンス！！](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-saikyo-family-program-1032-300-251126.png)](https://network.mobile.rakuten.co.jp/fee/family/?l-id=top_carousel_none_fee_family)

[![最強青春割 22歳まではずーっとおトク！家族割引併用時、データ3GB780円（税込858円）](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-fee-youth-1032-300-251126.png)](https://network.mobile.rakuten.co.jp/fee/youth/?l-id=top_carousel_none_fee_youth)

[![最強おうちプログラム　ネットとスマホ、セットでおトク！楽天モバイル＋Rakuten Turbo初めてお申し込みで永年毎月1,000ポイント還元 製品代48回払い分の867円/月をプラン料金から割引 48カ月間のご利用でRakutenTurbo5G製品代（41,580円）実質0円](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-turbo-1032-300-250806.png)](https://network.mobile.rakuten.co.jp/internet/turbo/campaign/home-internet/?l-id=top_carousel_none_internet_turbo_campaign_home-internet)

PreviousNext

 [![今年最後!楽天マジ得フェスティバル 楽天カード会員様対象 楽天モバイル初めてのお申し込みで20,000ポイント※期間限定ポイントなど条件あり](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-card-mobile-majitoku-343-330-251201.png)](https://network.mobile.rakuten.co.jp/campaign/card-mobile-majitoku/?l-id=top_carousel_none_campaign_card-mobile-majitoku)
[](https://network.mobile.rakuten.co.jp/fee/unext/?l-id=top_carousel_none_fee_unext)
[](https://network.mobile.rakuten.co.jp/campaign/mnp/?l-id=top_carousel_none_campaign_mnp)
[](https://network.mobile.rakuten.co.jp/product/iphone/?l-id=top_carousel_none_product_iphone)
[](https://network.mobile.rakuten.co.jp/campaign/iphone-point-iphone-16e/?l-id=top_carousel_none_campaign_iphone-point-iphone-16e)
[](https://network.mobile.rakuten.co.jp/campaign/shop-limited-application/?l-id=top_carousel_none_campaign_shop-limited-application)
[](https://network.mobile.rakuten.co.jp/campaign/iphone-point-iphone-17/?l-id=top_carousel_none_campaign_iphone-point-iphone-17)
[](https://network.mobile.rakuten.co.jp/campaign/android-discount/?l-id=top_carousel_none_campaign_android-discount)
[](https://network.mobile.rakuten.co.jp/product/iphone/iphone-air/?l-id=top_carousel_none_product_iphone_iphone-air)
[](https://network.mobile.rakuten.co.jp/product/internet/rakuten-wifi-pocket-platinum/?l-id=top_carousel_none_product_internet_rakuten-wifi-pocket-platinum)
[](https://network.mobile.rakuten.co.jp/campaign/referral/?l-id=top_carousel_none_campaign_referral)
[](https://network.mobile.rakuten.co.jp/guide/mnp/fast-convert/?l-id=top_carousel_none_guide_mnp_fast-convert)
[](https://network.mobile.rakuten.co.jp/product/smartphone/arrows-alpha/?l-id=top_carousel_none_product_arrows-alpha)
[](https://network.mobile.rakuten.co.jp/product/smartphone/google-pixel-9a/?l-id=top_carousel_none_product_google-pixel-9a)
[](https://network.mobile.rakuten.co.jp/product/apple-watch/apple-watch-series11/?l-id=top_carousel_none_product_apple-watch)
[](https://network.mobile.rakuten.co.jp/fee/family/?l-id=top_carousel_none_fee_family)
[](https://network.mobile.rakuten.co.jp/fee/youth/?l-id=top_carousel_none_fee_youth)
[](https://network.mobile.rakuten.co.jp/internet/turbo/campaign/home-internet/?l-id=top_carousel_none_internet_turbo_campaign_home-internet)

 [![今年最後!楽天マジ得フェスティバル 楽天カード会員様対象 楽天モバイル初めてのお申し込みで20,000ポイント※期間限定ポイントなど条件あり](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-card-mobile-majitoku-1032-300-251201.png)](https://network.mobile.rakuten.co.jp/campaign/card-mobile-majitoku/?l-id=top_carousel_campaign_card-mobile-majitoku)
[![iPhone 17 Pro 楽天モバイルで販売中](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-iphone-17-pro-led-1032-300-250919.png)](https://network.mobile.rakuten.co.jp/product/iphone/?l-id=top_carousel_product_iphone)
[](https://network.mobile.rakuten.co.jp/service/replacement-program/?l-id=top_carousel_service_replacement-program)
[](https://network.mobile.rakuten.co.jp/fee/unext/?l-id=top_carousel_fee_unext)
[](https://network.mobile.rakuten.co.jp/campaign/iphone-point-iphone-16e/?l-id=top_carousel_campaign_iphone-point-iphone-16e)
[](https://network.mobile.rakuten.co.jp/campaign/android-discount/?l-id=top_carousel_campaign_android-discount)
[](https://network.mobile.rakuten.co.jp/product/iphone/iphone-17/?l-id=top_carousel_product_iphone_iphone-17)
[](https://network.mobile.rakuten.co.jp/product/iphone/iphone-air/?l-id=top_carousel_product_iphone_iphone-air)
[](https://network.mobile.rakuten.co.jp/product/apple-watch/apple-watch-series11/?l-id=top_carousel_product_apple-watch)
[](https://network.mobile.rakuten.co.jp/campaign/iphone-point-iphone-17/?l-id=top_carousel_campaign_iphone-point-iphone-17)
[](https://network.mobile.rakuten.co.jp/product/internet/rakuten-wifi-pocket-platinum/?l-id=top_carousel_product_internet_rakuten-wifi-pocket-platinum)
[](https://network.mobile.rakuten.co.jp/campaign/referral/?l-id=top_carousel_campaign_referral)
[](https://network.mobile.rakuten.co.jp/product/smartphone/arrows-alpha/?l-id=top_carousel_product_arrows-alpha)
[](https://event.rakuten.co.jp/campaign/supersale/?scid=wi_rmb_ich_mkdiv_mno-top-carousel_ichicpn-ss_20251205)
[](https://network.mobile.rakuten.co.jp/fee/family/?l-id=top_carousel_fee_family)
[](https://network.mobile.rakuten.co.jp/campaign/data3g/?l-id=top_carousel_campaign_data3g)
[](https://service.link.link/lp/card-payment-setting/index.html?scid=wi_rlk_mno_top)
[![最強おうちプログラム　ネットとスマホ、セットでおトク！楽天モバイル＋Rakuten Turbo初めてお申し込みで永年毎月1,000ポイント還元 製品代48回払い分の867円/月をプラン料金から割引 48カ月間のご利用でRakutenTurbo5G製品代（41,580円）実質0円](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-turbo-1032-300-250806.png)](https://network.mobile.rakuten.co.jp/internet/turbo/campaign/home-internet/?l-id=top_carousel_internet_turbo_campaign_home-internet)

 [![今年最後!楽天マジ得フェスティバル 楽天カード会員様対象 楽天モバイル初めてのお申し込みで20,000ポイント※期間限定ポイントなど条件あり](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-card-mobile-majitoku-343-330-251201.png)](https://network.mobile.rakuten.co.jp/campaign/card-mobile-majitoku/?l-id=top_carousel_campaign_card-mobile-majitoku)
[](https://network.mobile.rakuten.co.jp/product/iphone/?l-id=top_carousel_product_iphone)
[](https://network.mobile.rakuten.co.jp/service/replacement-program/?l-id=top_carousel_service_replacement-program)
[](https://network.mobile.rakuten.co.jp/fee/unext/?l-id=top_carousel_fee_unext)
[](https://network.mobile.rakuten.co.jp/campaign/iphone-point-iphone-16e/?l-id=top_carousel_campaign_iphone-point-iphone-16e)
[](https://network.mobile.rakuten.co.jp/campaign/android-discount/?l-id=top_carousel_campaign_android-discount)
[](https://network.mobile.rakuten.co.jp/product/iphone/iphone-17/?l-id=top_carousel_product_iphone_iphone-17)
[](https://network.mobile.rakuten.co.jp/product/iphone/iphone-air/?l-id=top_carousel_product_iphone_iphone-air)
[](https://network.mobile.rakuten.co.jp/product/apple-watch/apple-watch-series11/?l-id=top_carousel_product_apple-watch)
[](https://network.mobile.rakuten.co.jp/campaign/iphone-point-iphone-17/?l-id=top_carousel_campaign_iphone-point-iphone-17)
[](https://network.mobile.rakuten.co.jp/product/internet/rakuten-wifi-pocket-platinum/?l-id=top_carousel_product_internet_rakuten-wifi-pocket-platinum)
[](https://network.mobile.rakuten.co.jp/campaign/referral/?l-id=top_carousel_campaign_referral)
[](https://network.mobile.rakuten.co.jp/product/smartphone/arrows-alpha/?l-id=top_carousel_product_arrows-alpha)
[](https://event.rakuten.co.jp/campaign/supersale/?scid=wi_rmb_ich_mkdiv_mno-top-carousel_ichicpn-ss_20251205)
[](https://network.mobile.rakuten.co.jp/fee/family/?l-id=top_carousel_fee_family)
[](https://network.mobile.rakuten.co.jp/campaign/data3g/?l-id=top_carousel_campaign_data3g)
[](https://service.link.link/lp/card-payment-setting/index.html?scid=wi_rlk_mno_top)
[](https://network.mobile.rakuten.co.jp/internet/turbo/campaign/home-internet/?l-id=top_carousel_internet_turbo_campaign_home-internet)

[キャンペーン一覧を見る](https://network.mobile.rakuten.co.jp/campaign/?l-id=top_carousel_campaign)

[新規／乗り換え（MNP）お申し込み](https://network.mobile.rakuten.co.jp/guide/application/?type=pitari&l-id=top_button_guide)

[お近くのショップを探す・来店予約](https://network.mobile.rakuten.co.jp/shop/?l-id=top_shop01)

[楽天モバイル (ドコモ回線・au回線) からの変更手続き](https://members-station.mobile.rakuten.co.jp/members/rmb/login?language=J&campaign=web-rakuten&l-id=top_ms&mno_migration=1)

[電話で相談しながらお申し込み手続き](https://network.mobile.rakuten.co.jp/guide/application-support/?l-id=top_guide_application-support01)

au をご利用中のお客様へ

NTTドコモ をご利用中のお客様へ

SoftBank をご利用中のお客様へ

Y!mobile をご利用中のお客様へ

UQ mobile をご利用中のお客様へ

![スマホ料金毎月いくら払ってますか？](https://network.mobile.rakuten.co.jp/assets/img/top/login-gadget/title-simulation-241213.png)

 ![カンタン10秒チェック](https://network.mobile.rakuten.co.jp/assets/img/top/login-gadget/img-circle-241214.png)

約11,000円/月以上 約10,000円/月 約9,000円/月 約8,000円/月 約7,000円/月 約6,000円/月 約5,000円/月 約4,000円/月 約3,000円/月 約2,000円/月 約1,000円/月

[どれだけおトクか見てみよう](https://network.mobile.rakuten.co.jp/fee/mnp-simulation/result/?price=6000&carrier=&l-id=mnp-simulation_gadget_fee_mnp-simulation-result)

※上記以外の携帯電話会社をご利用の場合は[こちら](https://network.mobile.rakuten.co.jp/fee/simulation/?l-id=mnp-simulation_gadget_fee_simulation)

 [![「Rakuten最強U-NEXT」はギガもアプリ通話も無制限＆映画もアニメも見放題！スタート記念の特別価格で2,880円（税込3,168円）](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-unext-1032-160-251121.png)](https://network.mobile.rakuten.co.jp/fee/unext/?l-id=top_fee_unext)

### あなたにおすすめ情報

 [![楽天モバイル初めてのお申し込みで20,000ポイント※条件あり](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-card-mobile-majitoku-1032-78-251201.png)](https://network.mobile.rakuten.co.jp/campaign/card-mobile-majitoku/?l-id=top_pitari-banner_non-login_ip_campaign_card-mobile-majitoku)

重要なお知らせ

[災害に伴う支援措置について](https://network.mobile.rakuten.co.jp/information/news/other/3435/)

 ![Rakuten 最強プラン Rakuten 最強U-NEXT 使い方に合わせて選べてギガも通話も無制限で最安！ ※2025年6月時点。4キャリアのギガ無制限プランの料金で比較](https://network.mobile.rakuten.co.jp/assets/img/top-ex/img-plan-kv-pc-251028.png)

  ![NEW ギガ無制限で映画もアニメも見放題](https://network.mobile.rakuten.co.jp/assets/img/top-ex/img-saikyo-plan-copy-pc-251028.png) ![Rakuten 最強U-NEXT](https://network.mobile.rakuten.co.jp/assets/img/top-ex/img-unext-plan-title-pc-250930.png)

 ![ギガ無制限※1 × 見放題※2 家族割引適用時3,880円/月 税込4,268円/月 アプリ利用で国内通話無料※3 スタート記念の特別価格！今なら家族割引適用時2,880円/月 税込3,168円/月 2026年2月1日以降は3,880円(税込4,268円)](https://network.mobile.rakuten.co.jp/assets/img/top-ex/img-saikyo-plan-detail-pc-251028.png)

[Rakuten最強U-NEXTの詳細を見る](https://network.mobile.rakuten.co.jp/fee/unext/?l-id=top_fee_unext01)

※1 混雑時等公平なサービス提供のため速度制御する場合有。通話料等別 ※2 別途有料作品等あり ※3一部対象外番号あり

  ![使った分だけお支払い](https://network.mobile.rakuten.co.jp/assets/img/top-ex/img-unext-plan-copy-pc-251028.png) ![Rakuten 最強プラン](https://network.mobile.rakuten.co.jp/assets/img/top-ex/img-saikyo-plan-title-pc-250930.png)

 ![20GB超過後ギガ無制限2,880円/月税込3,168円/月。20GBまで1,880円/月税込2,068円/月。3GBまで880円/月税込968円/月](https://network.mobile.rakuten.co.jp/assets/img/top-ex/img-unext-plan-detail-pc-251118.png)

[Rakuten最強プランの詳細を見る](https://network.mobile.rakuten.co.jp/fee/saikyo-plan/?l-id=top_fee_saikyo-plan01)

※1 混雑時等公平なサービス提供のため速度制御する場合有。通話料等別 ※3一部対象外番号あり。

割引・プログラムでおトクに
-------------

 [![最強家族割 毎月ずーっと110円引き](https://network.mobile.rakuten.co.jp/assets/img/top-ex/img-program-family-pc-251118.png)](https://network.mobile.rakuten.co.jp/fee/family/?l-id=top_fee_family)

![+](https://network.mobile.rakuten.co.jp/assets/img/top-ex/icon-plus.svg)

### 年齢に応じて  
さらに安くなる※4

 [![12歳まで 最強こども割 毎月最大440円引き ※3GBまで](https://network.mobile.rakuten.co.jp/assets/img/top-ex/img-program-kids-pc-251118.png)](https://network.mobile.rakuten.co.jp/fee/kids/?l-id=top_fee_kids)
[![22歳まで 最強青春割 毎月最大110円引き](https://network.mobile.rakuten.co.jp/assets/img/top-ex/img-program-youth-pc-251118.png)](https://network.mobile.rakuten.co.jp/fee/youth/?l-id=top_youth)
[![65歳以上 最強シニアプログラム 毎月最大1,210ポイント還元 15分かけ放題&安心パック併用時※5](https://network.mobile.rakuten.co.jp/assets/img/top-ex/img-program-senior-pc-251118.png)](https://network.mobile.rakuten.co.jp/fee/senior/?l-id=top_fee_senior)

 [![65歳以上限定 敬老キャンペーン！「最強シニアプログラム」加入＆初めて申し込みでポイント還元、さらにオプションサービスもおトク！](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-senior-pointback-1032-160-251024.png)](https://network.mobile.rakuten.co.jp/campaign/senior-pointback/?l-id=top_campaign_senior-pointback)

[料金プランを見る](https://network.mobile.rakuten.co.jp/fee/saikyo-plan/?l-id=top_fee_saikyo-plan01)

※4 要申し込み/エントリー ※5 期間限定ポイント。国内通話対象（一部番号対象外）。他条件有

### Rakuten最強プランはココもおトク！

 [![](https://network.mobile.rakuten.co.jp/assets/img/top-ex/img-01-pc-250509.png)\
\
#### アプリ利用で国内通話無料\
\
*   ![](https://network.mobile.rakuten.co.jp/assets/img/top-ex/check-icon-250509.png)お使いの電話番号そのまま！\
*   ![](https://network.mobile.rakuten.co.jp/assets/img/top-ex/check-icon-250509.png)他社の携帯電話／固定電話にかけても無料](https://network.mobile.rakuten.co.jp/service/rakuten-link/?l-id=top_service_rakuten-link)

※一部対象外番号あり

 [![](https://network.mobile.rakuten.co.jp/assets/img/top-ex/img-02-pc-25014.png)\
\
#### 追加設定なしで海外でも使える\
\
*   ![](https://network.mobile.rakuten.co.jp/assets/img/top-ex/check-icon-250509.png)90以上の国と地域で毎月2GB無料\
*   ![](https://network.mobile.rakuten.co.jp/assets/img/top-ex/check-icon-250509.png)追加料金なし！  \
    対象航空会社・機体で機内ローミング開始](https://network.mobile.rakuten.co.jp/service/global/overseas/?l-id=top_service_global_overseas)

※プランデータ利用量に加算。 通話料等別

### 豪華な特典も盛りだくさん

 [![](https://network.mobile.rakuten.co.jp/assets/img/top-ex/luxuary-01-pc-250514.png)\
\
楽天市場のお買い物で  \
楽天ポイントが  \
毎日全員5倍※6](https://network.mobile.rakuten.co.jp/campaign/spu/?l-id=top_campaign_spu)
 [![](https://network.mobile.rakuten.co.jp/assets/img/top-ex/luxuary-02-pc-250801.png)\
\
パ・リーグ、  \
ミュージック、マガジンが  \
追加料金0円※7](https://network.mobile.rakuten.co.jp/campaign/digital-contents/?l-id=top_campaign_digital-contents)
 [![](https://network.mobile.rakuten.co.jp/assets/img/top-ex/luxuary-03-pc-250514.png)\
\
データのバックアップに！  \
クラウドストレージが  \
50GB無料※8](https://network.mobile.rakuten.co.jp/service/rakuten-drive/?l-id=top_service_rakuten-drive)

※6 要エントリー。獲得ポイントに上限あり ※7 ミュージックは30日ごとに10時間無料。マガジンは1カ月ごとに3冊無料 ※8 サービスのご利用には別途通信料が発生。その他条件は[こちら](https://network.mobile.rakuten.co.jp/#caution5)

 [![どれだけおトクか料金をシミュレーション！今すぐチェック](https://network.mobile.rakuten.co.jp/assets/img/top-ex/bnr-fee-simulation-pc.png)](https://network.mobile.rakuten.co.jp/fee/simulation/?l-id=top_fee_simulation)

[料金プランを見る](https://network.mobile.rakuten.co.jp/fee/saikyo-plan/?l-id=top_fee_saikyo-plan02)

つながりやすさも最強へ。※9  
“プラチナバンド”拡大中※10
--------------------------------

[![](https://network.mobile.rakuten.co.jp/assets/img/top-ex/prefecture/img-saitama.png)\
\
### 埼玉県でも  \
人口カバー率  \
99.98% ※11\
\
あなたの生活圏の「つながる」を確認\
\
日本全国の通信エリアどこでも使える\
\
### 人口カバー率 99.9% ※11\
\
あなたの生活圏の「つながる」を確認](https://network.mobile.rakuten.co.jp/area/saitama/?l-id=top_area_saitama_inhouse_non-login_1-2&s-id=top_area_saitama_all)

※9 楽天モバイルは、つながりやすさでも最強を目指します  
※10 主要都市部から順次拡大予定

[他のエリアをマップで確認する](https://network.mobile.rakuten.co.jp/area/?l-id=top_area)

製品購入もおトク
--------

[### iPhone\
\
 ![iPhone 17 最大21,000ポイント *1](https://network.mobile.rakuten.co.jp/assets/img/top-ex/img-iphone-pc-250912.png)](https://network.mobile.rakuten.co.jp/product/iphone/?l-id=top_product_iphone)
  [### Android\
\
 ![Android 22,000円値引き](https://network.mobile.rakuten.co.jp/assets/img/top-ex/img-android-pc-250801.png)](https://network.mobile.rakuten.co.jp/product/smartphone/?l-id=top_product_smartphone)
  

[nubia S2R\
\
 ![NEW](https://network.mobile.rakuten.co.jp/assets/img/top-ex/icon-new.svg)\
\
![nubia S2R](https://network.mobile.rakuten.co.jp/assets/img/product/nubia-s2r/rank-thumb.png)\
\
12月4日新発売](https://network.mobile.rakuten.co.jp/product/smartphone/nubia-s2r/?l-id=product-recommendation_product_smartphone_nubia-s2r)
[OPPO A5 5G\
\
 ![NEW](https://network.mobile.rakuten.co.jp/assets/img/top-ex/icon-new.svg)\
\
![OPPO A5 5G](https://network.mobile.rakuten.co.jp/assets/img/product/a5-5g/rank-thumb.png)\
\
12月4日新発売](https://network.mobile.rakuten.co.jp/product/smartphone/a5-5g/?l-id=product-recommendation_product_smartphone_a5-5g)
[arrows Alpha\
\
 ![NEW](https://network.mobile.rakuten.co.jp/assets/img/top-ex/icon-new.svg)\
\
![arrows Alpha](https://network.mobile.rakuten.co.jp/assets/img/product/arrows-alpha/rank-thumb.png)\
\
11月21日新発売](https://network.mobile.rakuten.co.jp/product/smartphone/arrows-alpha/?l-id=product-recommendation_product_smartphone_arrows-alpha)
[iPhone 16e\
\
 ![オススメ](https://network.mobile.rakuten.co.jp/assets/img/top-ex/icon-osusume.svg)\
\
![iPhone 16e](https://network.mobile.rakuten.co.jp/assets/img/product/iphone/iphone-16e/rank-thumb.png?250220)\
\
キャンペーン中](https://network.mobile.rakuten.co.jp/product/iphone/iphone-16e/?l-id=product-recommendation_product_iphone_iphone-16e)

\*1 キャンペーンの[詳細はこちら](https://network.mobile.rakuten.co.jp/#note)
  
\*2 一部対象外製品あり。[詳細はこちら](https://network.mobile.rakuten.co.jp/#note)

[製品カテゴリを見る](https://network.mobile.rakuten.co.jp/product/?l-id=top_product)

[ランキングを見る](https://network.mobile.rakuten.co.jp/product/ranking/?l-id=top_product_ranking)

おすすめのキャンペーン
-----------

 [![楽天モバイル紹介キャンペーン！紹介1人につき7,000ポイント、紹介される方も最大13,000ポイントプレゼント！](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-referral-328-185-250630.png)](https://network.mobile.rakuten.co.jp/campaign/referral/?l-id=top_campaign-banner_campaign_referral)
[![【要エントリー】楽天モバイル初めてお申し込みキャンペーンでお乗り換えは10,000ポイント・新規お申し込みは7,000ポイントプレゼント!](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-mnp-328-185-251201.png)](https://network.mobile.rakuten.co.jp/campaign/mnp/?l-id=top_campaign-banner_campaign_mnp)
[![【要エントリー】最新機種のiPhone 17やiPhone 17 Proなどが対象！対象iPhoneを購入+楽天モバイルへ初めて申し込み+他社から電話番号そのまま乗り換え+対象iPhone下取りで最大21,000ポイント！](https://network.mobile.rakuten.co.jp/assets/img/bnr/iphone-point-iphone-17-328-185-250912.png)](https://network.mobile.rakuten.co.jp/campaign/iphone-point-iphone-17/?l-id=top_campaign-banner_campaign_iphone-point-iphone-17)
[![iPhone 16e（128GB）がおトク！他社から電話番号そのまま乗り換え＋楽天カード48回払いで1円/月～！（1～24回目まで、25回目以降4,365円/月～）](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-iphone-point-iphone-16e-328-185-251128.png)](https://network.mobile.rakuten.co.jp/campaign/iphone-point-iphone-16e/?l-id=top_campaign-banner_campaign_iphone-point-iphone-16e)
[](https://service.link.link/lp/card-payment-setting/index.html?scid=wi_rlk_mno_top)
[](https://network.mobile.rakuten.co.jp/campaign/android-discount/?l-id=top_campaign-banner_campaign_android-discount)
[](https://network.mobile.rakuten.co.jp/campaign/iphone-pointback/?l-id=top_campaign-banner_campaign_iphone-pointback)
[](https://network.mobile.rakuten.co.jp/campaign/iphone-point-iphone-15/?l-id=top_campaign-banner_campaign_iphone-point-iphone-15)
[](https://network.mobile.rakuten.co.jp/campaign/iphone-point/?l-id=top_campaign-banner_campaign_iphone-point)
[](https://network.mobile.rakuten.co.jp/campaign/android-sale/?l-id=product_carousel_campaign_android-sale)
[](https://network.mobile.rakuten.co.jp/campaign/android-point/?l-id=top_campaign-banner_campaign_android-point)
[](https://network.mobile.rakuten.co.jp/campaign/start-point/?l-id=top_campaign-banner_campaign_start-point)
[](https://network.mobile.rakuten.co.jp/product/internet/rakuten-wifi-pocket-platinum/?l-id=top_campaign-banner_product_internet_rakuten-wifi-pocket-platinum)
[](https://network.mobile.rakuten.co.jp/campaign/digital-contents/?l-id=top_campaign-banner_campaign_digital-contents)
[](https://network.mobile.rakuten.co.jp/campaign/payment-google/?l-id=top_campaign-banner_campaign_payment-google)
[](https://network.mobile.rakuten.co.jp/campaign/spu/?l-id=top_campaign-banner_campaign_spu)
[](https://network.mobile.rakuten.co.jp/campaign/youtubepremium/?l-id=top_campaign-banner_campaign_youtubepremium)
[](https://network.mobile.rakuten.co.jp/internet/turbo/campaign/home-internet/?l-id=top_campaign-banner_internet_turbo_campaign_home-internet)
[](https://network.mobile.rakuten.co.jp/hikari/campaign/home-internet/?l-id=top_campaign-banner_hikari_campaign_home-internet)

[キャンペーン一覧を見る](https://network.mobile.rakuten.co.jp/campaign/?l-id=top_campaign)

選べるお手続き方法
---------

### ショップで相談しながら

 ![](https://network.mobile.rakuten.co.jp/assets/img/top-ex/img-guide-01-pc.png)

[ショップ詳細を見る](https://network.mobile.rakuten.co.jp/shop/?l-id=top_shop)

都道府県を選択,北海道,青森県,岩手県,宮城県,秋田県,山形県,福島県,茨城県,栃木県,群馬県,埼玉県,千葉県,東京都,神奈川県,新潟県,富山県,石川県,福井県,山梨県,長野県,岐阜県,静岡県,愛知県,三重県,滋賀県,京都府,大阪府,兵庫県,奈良県,和歌山県,鳥取県,島根県,岡山県,広島県,山口県,徳島県,香川県,愛媛県,高知県,福岡県,佐賀県,長崎県,熊本県,大分県,宮崎県,鹿児島県,沖縄県

市区町村を選択

お近くのショップを検索する

### オンラインで好きな時間に

 ![](https://network.mobile.rakuten.co.jp/assets/img/top-ex/img-guide-02-pc.png)

[申し込み手順を見る](https://network.mobile.rakuten.co.jp/guide/procedure/online-application/?l-id=guide_procedure_guide_online_application)

[楽天モバイル(ドコモ回線・au回線)からの変更手続き](https://members-station.mobile.rakuten.co.jp/members/rmb/login?language=J&campaign=web-rakuten&l-id=top_button2_ms&mno_migration=1)

### 電話で相談しながら

 ![](https://network.mobile.rakuten.co.jp/assets/img/top-ex/img-guide-03-pc.png)

[サポート詳細を見る](https://network.mobile.rakuten.co.jp/guide/application-support/?l-id=top_guide_application-support02)

※ 製品のみの購入、もしくは18歳未満のお客様はお電話でのお申し込みはご利用いただけません。

 [![かんたん4ステップでご利用開始 はじめてでも安心！お申し込みガイド](https://network.mobile.rakuten.co.jp/assets/img/top-ex/bnr-guide-procedure-pc.png)](https://network.mobile.rakuten.co.jp/guide/procedure/?l-id=top_guide_procedure)

Web CM公開中
---------

Play Video

Play

Mute

Current Time 0:00

/

Duration Time 0:00

Loaded: 0%

0:00

Progress: 0%

0:00

Progress: 0%

Stream TypeLIVE

Remaining Time -0:00

Playback Rate

1

*   Chapters

Chapters

*   descriptions off, selected

Descriptions

*   subtitles off, selected

Subtitles

*   captions off, selected

Captions

Audio Track

Fullscreen

This is a modal window.

This video is either unavailable or not supported in this browser
-----------------------------------------------------------------

**Error Code**: MEDIA\_ERR\_SRC\_NOT\_SUPPORTED

Technical details :

No compatible source was found for this media.

If you are using an older browser please try upgrading or installing Flash.

**Session ID:** 2025-12-05:6125edf98277fa211438ddee **Player ID:** vjs\_video\_3

OK

Close Modal Dialog

Caption Settings Dialog

Beginning of dialog window. Escape will cancel and close the window.

TextColorWhiteBlackRedGreenBlueYellowMagentaCyanTransparencyOpaqueSemi-Transparent

BackgroundColorBlackWhiteRedGreenBlueYellowMagentaCyanTransparencyOpaqueSemi-TransparentTransparent

WindowColorBlackWhiteRedGreenBlueYellowMagentaCyanTransparencyTransparentSemi-TransparentOpaque

Font Size50%75%100%125%150%175%200%300%400%

Text Edge StyleNoneRaisedDepressedUniformDropshadow

Font FamilyProportional Sans-SerifMonospace Sans-SerifProportional SerifMonospace SerifCasualScriptSmall Caps

DefaultsDone

Close Modal Dialog

This is a modal window. This modal can be closed by pressing the Escape key or activating the close button.

[![](https://network.mobile.rakuten.co.jp/assets/img/top/img-video-01.png)](https://network.mobile.rakuten.co.jp/#modal01)

Play Video

Play

Mute

Current Time 0:00

/

Duration Time 0:00

Loaded: 0%

0:00

Progress: 0%

0:00

Progress: 0%

Stream TypeLIVE

Remaining Time -0:00

Playback Rate

1

*   Chapters

Chapters

*   descriptions off, selected

Descriptions

*   subtitles off, selected

Subtitles

*   captions off, selected

Captions

Audio Track

Fullscreen

This is a modal window.

This video is either unavailable or not supported in this browser
-----------------------------------------------------------------

**Error Code**: MEDIA\_ERR\_SRC\_NOT\_SUPPORTED

Technical details :

No compatible source was found for this media.

If you are using an older browser please try upgrading or installing Flash.

**Session ID:** 2025-12-05:8d382e3610b55d13193cf38 **Player ID:** player1

OK

Close Modal Dialog

Caption Settings Dialog

Beginning of dialog window. Escape will cancel and close the window.

TextColorWhiteBlackRedGreenBlueYellowMagentaCyanTransparencyOpaqueSemi-Transparent

BackgroundColorBlackWhiteRedGreenBlueYellowMagentaCyanTransparencyOpaqueSemi-TransparentTransparent

WindowColorBlackWhiteRedGreenBlueYellowMagentaCyanTransparencyTransparentSemi-TransparentOpaque

Font Size50%75%100%125%150%175%200%300%400%

Text Edge StyleNoneRaisedDepressedUniformDropshadow

Font FamilyProportional Sans-SerifMonospace Sans-SerifProportional SerifMonospace SerifCasualScriptSmall Caps

DefaultsDone

Close Modal Dialog

This is a modal window. This modal can be closed by pressing the Escape key or activating the close button.

[![](https://network.mobile.rakuten.co.jp/assets/img/top/img-video-02.png)](https://network.mobile.rakuten.co.jp/#modal02)

[CMギャラリーを見る](https://network.mobile.rakuten.co.jp/cm/?l-id=top_cm)

 [![超かんたん＆便利 デュアルSIMのススメ！](https://network.mobile.rakuten.co.jp/assets/img/top-ex/bnr-dualsim.png)](https://network.mobile.rakuten.co.jp/product/sim/dual-sim/?l-id=top_product_dual-sim)
[![楽メール](https://network.mobile.rakuten.co.jp/assets/img/top-ex/bnr-rakumail-251024.png)](https://network.mobile.rakuten.co.jp/service/rakumail/?l-id=top_service_rakumail)
[![](https://network.mobile.rakuten.co.jp/assets/img/top-ex/bnr-vaundy.png)](https://www.youtube.com/watch?v=fJZrmX9oWj4)

 [![セキュリティ強化や業務効率化まで ビジネスでも楽天モバイル 法人のお客様はこちら](https://network.mobile.rakuten.co.jp/assets/img/top-ex/bnr-business-pc-251001.png)](https://business.mobile.rakuten.co.jp/?scid=wi_rmb_pers_top)

注意事項
----

■ギガ無制限について

※1 混雑時など公平なサービス提供のため速度制御する場合あり

■アプリ利用で国内通話無料について

※（0570）などから始まる他社接続サービス、一部特番（188）への通話については、無料通話の対象外となります。OS標準の電話アプリを利用した場合、30秒22円

■海外は2GBまで無料について

※ 通話料等別。プランのデータ利用量に加算。2GB超過後は最大128kbps。対象エリアおよび条件は変更する場合あり。[対象エリア](https://network.mobile.rakuten.co.jp/service/global/overseas/?l-id=top_service_global_overseas#accordion-1)
をご確認ください。

■「楽天市場のお買い物ポイントが毎日全員5倍」特典について

※6 楽天会員1倍と楽天モバイルSPU＋4倍の合計値です。楽天モバイルSPUの毎月の獲得上限ポイント数は2,000ポイント。期間限定ポイントでの付与。要エントリー。詳細は[こちら](https://network.mobile.rakuten.co.jp/campaign/spu/?l-id=top_campaign_spu)
をご確認ください。

■エンタメ特典について

※7 ミュージックは30日ごとに10時間無料。マガジンは1カ月ごとに3冊無料。ミュージックとマガジンの対象コンテンツに一部制限あり

■楽天ドライブについて

※8 当クラウドサービスは、高い信頼性と安全性を提供するよう設計されていますが、全てのデータの完全な保護を半永久的に保証するものではありません。

■サービスエリアについて

※11 2024年12月時点。人口カバー率は、国勢調査に用いられる約500m区画において、50%以上の場所で通信可能なエリアを基に算出。自社調べ。

■各種キャンペーンについて

\*1 詳細は[最新のiPhone 17購入で最大21,000ポイント還元キャンペーン！](https://network.mobile.rakuten.co.jp/campaign/iphone-point-iphone-17/?l-id=top_campaign_iphone-point-iphone-17)
をご確認ください。キャンペーン期間は、2025年9月12日（金）21:00～終了日未定。  
\*2 詳細は[楽天モバイル申し込み＋他社から電話番号そのまま乗り換え＋対象製品購入で22,000円値引き](https://network.mobile.rakuten.co.jp/campaign/android-sale/?l-id=top_campaign_android-sale)
をご確認ください。キャンペーン期間は2024年2月16日（金）09:00～終了日未定。

※各キャンペーンは予告なく変更・終了する場合有

*   [![x](https://network.mobile.rakuten.co.jp/assets/img/top/sns-icon-x.png)](https://x.com/Rakuten_Mobile)
    
*   [![facebook](https://network.mobile.rakuten.co.jp/assets/img/top/sns-icon-facebook.png)](https://www.facebook.com/RakutenMobile/)
    
*   [![youtube](https://network.mobile.rakuten.co.jp/assets/img/top/sns-icon-youtube.png)](https://www.youtube.com/channel/UCYqg3Pi0fp_sqmjN6dXA9JA)
    
*   [![instagram](https://network.mobile.rakuten.co.jp/assets/img/top/sns-icon-Instagram.png)](https://www.instagram.com/rakuten_mobile_official/)
    

![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-rmb-app.png)

my 楽天モバイルアプリ

アプリ1つで快適なモバイルライフをサポート

*   iPhone版アプリ
    
     [![App Storeからダウンロード](https://network.mobile.rakuten.co.jp/assets/img/top/btn-appstore.png)](https://apps.apple.com/jp/app/myrakutenmobile/id1473535769)
    ![](https://network.mobile.rakuten.co.jp/assets/img/top/appstore-qr.png)
    
*   Android版アプリ
    
     [![Google Playで手に入れよう](https://network.mobile.rakuten.co.jp/assets/img/top/btn-googleplay.png)](https://play.google.com/store/apps/details?id=jp.co.rakuten.mobile.ecare)
    ![](https://network.mobile.rakuten.co.jp/assets/img/top/googleplay-qr.png)
    

[新規／乗り換え（MNP）お申し込み](https://network.mobile.rakuten.co.jp/guide/application/?type=pitari&l-id=top_pc-modal_guide)

[お近くのショップを探す](https://network.mobile.rakuten.co.jp/shop/?l-id=top-modal_shop)

[新規／乗り換え(MNP)](https://network.mobile.rakuten.co.jp/guide/application/?type=pitari&l-id=top_sp-modal_guide)

[お近くのショップを探す](https://network.mobile.rakuten.co.jp/shop/?l-id=top_sp-modal_shop)

[![はじめてでも安心お申し込みガイド](https://network.mobile.rakuten.co.jp/assets/img/common/btn-apply-guide-250522.png)](https://network.mobile.rakuten.co.jp/guide/procedure/?l-id=top-modal_guide_procedure)

*   [会社概要](https://corp.mobile.rakuten.co.jp/)
    
*   [法人のお客様](https://business.mobile.rakuten.co.jp/?scid=wi_rmb_pers_footer)
    
*   [法人パートナープログラム](https://business.mobile.rakuten.co.jp/partner/?scid=wi_rmb_pers_footer)
    
*   [個人情報の取扱いについて](https://corp.mobile.rakuten.co.jp/guide/privacy/)
    
*   [情報セキュリティポリシー](https://corp.mobile.rakuten.co.jp/guide/security/)
    
*   [商標・登録商標について](https://corp.mobile.rakuten.co.jp/guide/trademark/)
    
*   [古物営業法に基づく表示](https://network.mobile.rakuten.co.jp/secondhand-dealer/)
    
*   [利用規約](https://network.mobile.rakuten.co.jp/terms/)
    
*   [外部送信される情報の取り扱いについて](https://network.mobile.rakuten.co.jp/optout/)
    

© Rakuten Mobile, Inc.

*   [![AIも、楽天グループなら安心](https://network.mobile.rakuten.co.jp/assets/img/common/bnr-ai-safety-240-75-250530.png)](https://corp.rakuten.co.jp/ai/ai-safety/?scid=wi_rmb_aisafety)
    
*   [![【Go Green Together】同社の従来ネットワーク比較 消費電力約20%削減へ 募金キャンペーン実施中](https://network.mobile.rakuten.co.jp/assets/img/common/bnr-green-charity-240-75-250530.png)](https://network.mobile.rakuten.co.jp/campaign/green-charity/?l-id=footer_campaign_green-charity)
    

*   楽天グループ
*   [サービス一覧](https://www.rakuten.co.jp/sitemap/)
    
*   [お問い合わせ一覧](https://www.rakuten.co.jp/sitemap/inquiry.html)
    
*   [サステナビリティ](https://corp.rakuten.co.jp/sustainability/)
    

    [![申し込み・相談 AIサポート](https://network.mobile.rakuten.co.jp/assets/img/common/gen-ai-link-balloon-pc-250804.svg) ![](https://network.mobile.rakuten.co.jp/assets/img/common/gen-ai-link-icon-pc-250804.svg)](https://network.mobile.rakuten.co.jp/chat/?l-id=assist-ai)
![閉じる](https://network.mobile.rakuten.co.jp/assets/img/common/gen-ai-close.svg)

    [![AI Support](https://network.mobile.rakuten.co.jp/assets/en/img/common/gen-ai-link-balloon-pc-250804.svg) ![](https://network.mobile.rakuten.co.jp/assets/img/common/gen-ai-link-icon-pc-250804.svg)](https://network.mobile.rakuten.co.jp/chat/?wovn=en&l-id=assist-ai)
![Close](https://network.mobile.rakuten.co.jp/assets/img/common/gen-ai-close.svg)

    

日本語

English
