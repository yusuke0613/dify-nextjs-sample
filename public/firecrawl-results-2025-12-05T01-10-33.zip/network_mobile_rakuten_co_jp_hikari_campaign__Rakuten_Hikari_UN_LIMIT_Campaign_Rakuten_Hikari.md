# Rakuten Hikari UN-LIMIT Campaign | Rakuten Hikari

URL: https://network.mobile.rakuten.co.jp/hikari/campaign/

---

[![Rakuten Mobile](https://cdn.rmc.contents.rakuten.co.jp/block/d40535ac09aac0ef32f8a23b8bb8e04bc2e8f9d6b0981fa98a16d0382f558d83/d72cbeb1-1b70-4fb2-b7e5-cb3c0a24841f/card20k_enddate_pc_1440x50.png)](https://cdn.rex.contents.rakuten.co.jp/webcx-redirect-module/1.3.0/index.html?clientId=d40535ac09aac0ef32f8a23b8bb8e04bc2e8f9d6b0981fa98a16d0382f558d83&version=2.73.0&sessionId=63fff4de-6af5-4eb0-a9c2-1402cb932f12&screen=WB&issueId=F01184-001256&campaignId=2aadf4f2-55c7-4337-8472-22f617277367&contentId=4382487a-283f-4306-b0d1-11d8c70206b1&replacementId=9354c015-1ef6-41d2-8298-0bf372a98402&impressionId=96e94538-cc3d-4ad8-815d-49eda6c2caf6&selector=mkdiv_header_pitari&redirect=aHR0cHM6Ly9uZXR3b3JrLm1vYmlsZS5yYWt1dGVuLmNvLmpwL2NhbXBhaWduL2NhcmQtbW9iaWxlLW1haml0b2t1Lw==&origin=aHR0cHM6Ly9uZXR3b3JrLm1vYmlsZS5yYWt1dGVuLmNvLmpw)

[![Rakuten Mobile](https://network.mobile.rakuten.co.jp/assets/img/hikari/common-v2/header-logo-pink.svg)](https://network.mobile.rakuten.co.jp/?wovn=en&l-id=rhk_header_mno_01)

[Rakuten Mobile](https://network.mobile.rakuten.co.jp/?wovn=en&l-id=rhk_header_mno_02)
 ​ ​| ​ ​[Rakuten Turbo](https://network.mobile.rakuten.co.jp/internet/turbo/?wovn=en&l-id=rhk_header_mno_internet_turbo_01)
 ​ ​|

Language

*   日本語
*   English
*   简体中文
*   繁體中文
*   한국어
*   tiếng việt
*   Indonesia
*   português

[![Rakuten Hikari](https://network.mobile.rakuten.co.jp/assets/img/hikari/common-v2/header-logo-white.svg)](https://network.mobile.rakuten.co.jp/hikari/?wovn=en&l-id=rhk_gheader_top_01)

Search

[Member page](https://ms.fusioncom.co.jp/rbb/members/login?campaign=web-rakuten&l-id=rhk_gheader_ecare&_ebx=g1rjgkpzt4.1693291119.7s1i0ki)

[Apply Now](https://secure3.gol.com/mod-pl/rbb/rmch.cgi?scode=qngTI9rXJpRlc1l6roM&cpnkind=offoffer2303d6&l-id=rhk_header_onb&ratck=Rp%3Df801f02807b1a9364cb19ebd5c69322f642f7aa)

Menu

*   Price
    
    *   [Price simulation](https://network.mobile.rakuten.co.jp/hikari/fee/simulation/?wovn=en&l-id=rhk_gheader_fee_simulation_01)
        
    *   [Price](https://network.mobile.rakuten.co.jp/hikari/fee/pricelist/?wovn=en&l-id=rhk_gheader_fee_pricelist_01)
        
    
*   Campaigns
    
    *   [Rakuten Hikari SAIKYO HOME Program](https://network.mobile.rakuten.co.jp/hikari/campaign/home-internet/?wovn=en&l-id=rhk_gheader_campaign_home-internet_01)
        
    *   [SPU (Super Point Up Program)](https://network.mobile.rakuten.co.jp/internet/turbo/campaign/spu/?wovn=en&l-id=rhk_gheader_mno_internet_turbo_campaign_spu_01)
        
    *   [Previous Campaign Rules](https://network.mobile.rakuten.co.jp/hikari/campaign/archive/?wovn=en&l-id=rhk_gheader_campaign_archive_01)
        
    
*   Those Considering Switching
    
    *   [Steps to Get Started](https://network.mobile.rakuten.co.jp/hikari/flow/?wovn=en&l-id=rhk_gheader_flow_01)
        
    *   [Speedy and stable](https://network.mobile.rakuten.co.jp/hikari/internet/?wovn=en&l-id=rhk_gheader_internet_01)
        
    
*   News & Support
    
    *   [News](https://network.mobile.rakuten.co.jp/hikari/information/?wovn=en&l-id=rhk_gheader_information_01)
        
    *   [Customer Support](https://network.mobile.rakuten.co.jp/hikari/support/?wovn=en&l-id=rhk_gheader_support_01)
        
    

*   [Top](https://network.mobile.rakuten.co.jp/hikari/?wovn=en&l-id=rhk_bct_top_01)
    
*   Rakuten Hikari UN-LIMIT Campaign

よく検索されるワード
----------

検索履歴
----

[Apply](https://secure3.gol.com/mod-pl/rbb/rmch.cgi?scode=qngTI9rXJpRlc1l6roM&cpnkind=offoffer2303d6&l-id=rhk_gmenu_onb&ratck=Rp%3Df801f02807b1a9364cb19ebd5c69322f642f7aa)
 ​ ​[Member page](https://ms.fusioncom.co.jp/rbb/members/login?campaign=web-rakuten&l-id=rhk_gmenu_ecare&_ebx=g1rjgkpzt4.1693291119.7s1i0ki)

*   Price
    
*   Campaigns
    
*   Those Considering Switching
    
*   News & Support
    
*   Language
    

[See Rakuten Turbo](https://network.mobile.rakuten.co.jp/internet/turbo/?wovn=en&l-id=rhk_gmenu_mno_internet_turbo_01)

[See Rakuten Mobile](https://network.mobile.rakuten.co.jp/?wovn=en&l-id=rhk_gmenu_mno_03)

Price

*   [Price simulation](https://network.mobile.rakuten.co.jp/hikari/fee/simulation/?wovn=en&l-id=rhk_gmenu_fee_simulation_01)
    
*   [Price](https://network.mobile.rakuten.co.jp/hikari/fee/pricelist/?wovn=en&l-id=rhk_gmenu_fee_pricelist_01)
    

Campaign

*   [Rakuten Hikari SAIKYO HOME Program](https://network.mobile.rakuten.co.jp/hikari/campaign/home-internet/?wovn=en&l-id=rhk_gmenu_campaign_home-internet_01)
    
*   [SPU (Super Point Up Program)](https://network.mobile.rakuten.co.jp/internet/turbo/campaign/spu/?wovn=en&l-id=rhk_gmenu_mno_internet_turbo_campaign_spu_01)
    
*   [Previous Campaign Rules](https://network.mobile.rakuten.co.jp/hikari/campaign/archive/?wovn=en&l-id=rhk_gmenu_campaign_archive_01)
    

Those Considering Switching

*   [Steps to Get Started](https://network.mobile.rakuten.co.jp/hikari/flow/?wovn=en&l-id=rhk_gmenu_flow_01)
    
*   [Speedy and stable](https://network.mobile.rakuten.co.jp/hikari/internet/?wovn=en&l-id=rhk_gmenu_internet_01)
    

News & 

*   [News](https://network.mobile.rakuten.co.jp/hikari/information/?wovn=en&l-id=rhk_gmenu_information_01)
    
*   [Customer Support](https://network.mobile.rakuten.co.jp/hikari/support/?wovn=en&l-id=rhk_gmenu_support_01)
    

Language

*   日本語
    
*   English
    
*   简体中文
    
*   繁體中文
    
*   한국어
    
*   tiếng việt
    
*   Indonesia
    
*   português
    

Choose your language for Rakuten Mobile !
-----------------------------------------

Our services are provided within the region and laws of Japan.

日本語 English 简体中文 繁體中文 한국어 tiếng việt Indonesia português

Select Language

Our services are provided within the region and laws of Japan and we provide translations for your convenience.  
The Japanese version of our websites and applications, in which include Rakuten Membership Rules, Privacy Policy or other terms and conditions, is the definitive version , unless otherwise indicated.  
If there are any discrepancies, the Japanese version shall prevail.  
We do not guarantee that we always provide translation.  
The Japanese versions of all terms and conditions, policies, and other notices are the definitive versions. Any dispute related to the terms and conditions, policies, or other notices will be under the jurisdiction of Japanese law, regardless of any conflicting laws or principles.  
Certain features or messages (including customer services) may not be available in the selected language.

Enjoy Rakuten Mobile in English!
--------------------------------

Our services are provided within the region and laws of Japan and we provide translations for your convenience.  
The Japanese version of our websites and applications, in which include Rakuten Membership Rules, Privacy Policy or other terms and conditions, is the definitive version , unless otherwise indicated.  
If there are any discrepancies, the Japanese version shall prevail.  
We do not guarantee that we always provide translation.  
The Japanese versions of all terms and conditions, policies, and other notices are the definitive versions. Any dispute related to the terms and conditions, policies, or other notices will be under the jurisdiction of Japanese law, regardless of any conflicting laws or principles.  
Certain features or messages (including customer services) may not be available in the selected language.

This campaign has ended.

[Visit Rakuten Hikari's Top Page](https://network.mobile.rakuten.co.jp/hikari/?wovn=en&l-id=rhk_top_01)

※The information on this page is current as of the campaign start date.

Both Rakuten Turbo and Hikari offer great deals!
------------------------------------------------

[![Join Rakuten Turbo & use Rakuten Mobile for a lifetime of 1,000 point rebates monthly※Time-limited points. Conditions apply.](https://network.mobile.rakuten.co.jp/assets/en/img/hikari/bnr/bnr-set-plan-turbo-328-185-20250730.png)](https://network.mobile.rakuten.co.jp/internet/turbo/campaign/home-internet/?wovn=en&l-id=rhk_hikari_campaign_one-year-free_internet_turbo_campaign_home-internet_01)

[![Get 1,000 point rebates every month for life when you apply for Rakuten Hikari for the first time & use Rakuten Mobile.※Time-limited points. Conditions apply.](https://network.mobile.rakuten.co.jp/assets/en/img/hikari/bnr/bnr-set-plan-hikari-328-185-20250730.png)](https://network.mobile.rakuten.co.jp/hikari/campaign/home-internet/?wovn=en&l-id=rhk_hikari_campaign_one-year-free_hikari_campaign_home-internet_01)

Rakuten Hikari UN-LIMIT Campaign Rules
--------------------------------------

*   When you contract for Rakuten UN-LIMIT VII
*   If you are not contracted with Rakuten UN-LIMIT VII

See Campaign Rules

|     |     |     |
| --- | --- | --- |  
| Campaign Code |     | 1109<br><br>*   \* When inquiring about this campaign, please quote the above "campaign code." |
| Campaign Application Period |     | Web<br><br>From October 7, 2020 (Wed) 9:00 to April 12, 2023 (Wed) 9:59<br><br>In-store (Rakuten Mobile Shop)<br><br>Open from October 7, 2020 (Wed) to close on April 11, 2023 (Tue) |
| Campaign Conditions |     | Rakuten members who meet all the following conditions:<br><br>*   ① Apply for Rakuten Hikari.<br><br>Those who apply for Rakuten Hikari through the application button on this page.<br><br>*   ② Activation of Rakuten Hikari<br><br>Those who apply for Rakuten Hikari during the campaign period and have their first connection within the 4th month after the application month.<br><br>*   \* "Open" refers to the following:  <br>    Activation refers to the state in which you have connected to the Internet using Rakuten Hikari. Please note that activation work is only available to those who are installing a new optical fiber line, and those who are already using FLET'S HIKARI (repurposing) or those who are using another company's optical fiber collaboration (changing service providers) will be activated without any in-house construction work. Customers who use VDSL or LAN wiring will be activated on the scheduled construction date.<br><br>*   ③ Rakuten Mobile “Rakuten UN-LIMIT VII” Plan Start Conditions<br><br>\*Must meet either condition (1) or (2)<br><br>(1) Rakuten Mobile plan "Rakuten UN-LIMIT VII" is already in use at the time of applying for "Rakuten Hikari".<br><br>(2) Apply for "Rakuten UN-LIMIT VII" by 23:59 on the 15th of the month following your application for "Rakuten Hikari".<br><br>\*This applies to all new applications, MNP transfer from other mobile carriers, and transfers from Rakuten Mobile (docomo/au network)<br><br>\*Eligible for both Plan (SIM card, eSIM) and Product + Plan (SIM card, eSIM) applications.<br><br>*   What is the plan start date?<br><br>For new applications<br><br>\*The plan start date will be the earlier of either 1 or 2.<br><br>The day we receive notification that the delivery has been completed.<br><br>② The date when the signal of Rakuten Network or Partner Line became available through the plan (SIM card, eSIM)<br><br>If MNP transfer from other mobile carriers<br><br>The date when the signal of Rakuten Network or Partner Line became available with the plan (SIM card, eSIM)<br><br>If you switch from Rakuten Mobile (docomo/au network) price plan<br><br>The date when the signal of Rakuten Network or Partner Line became available with the plan (SIM card, eSIM) |
| Campaign Benefits | Campaign Benefits | *   Up to 1 Year Free Rakuten Hikari Monthly Basic Fee<br><br>*   From the activation month, up to 12 months of ¥0 monthly basic fee.<br><br>*   \* Rights cannot be transferred. |
| Rakuten Hikari contract for the campaign | Applicable services | Rakuten Hikari<br><br>All plans (Apartment Plan, Family Plan) |
| Contract period | Rakuten Hikari Mansion Plan, Family Plan<br><br>2 years (24 months) / Auto-renewal available<br><br>*   \* Contract period (2 years) starts from the month following the activation month.<br>*   \* After 24 months of use, a new contract period (2 years) begins from the 25th month, and the same cycle will continue every 24 months thereafter.<br>*   \* Contract cancellation fee will not be incurred if the cancellation application or the issuance of the operator change approval number is made between the 24th and 26th months, and the line removal or transfer to another company’s optical collaboration is completed between the 24th and 28th months.<br>*   \* Example: Customers who activated their service in April 2023 will not incur a Contract cancellation fee if they apply for cancellation between April 1, 2025, and June 30, 2025, and complete the line removal or switch to another provider's optical collaboration within 5 months from April 1, 2025.<br>*   \* If you cancel during the installment payment period for the construction fee, the remaining balance must be paid in a lump sum. |
| Contract cancellation fee | Rakuten Hikari<br><br>Contract cancellation fee: Family Plan (House) ¥5,280, Apartment Plan (Mansion) ¥4,180<br><br>*   \* Contract cancellation fee will be incurred if the cancellation request is made and completed outside the free cancellation application period (24th to 26th month) even during the campaign benefits period. |
| Campaign benefits not applicable. |     | The campaign benefits will not apply if any of the following conditions are met:<br><br>*   \*If you are already using Rakuten Hikari at the time this campaign starts.<br>*   \*If you are already subscribed to Rakuten Hikari<br>*   \*If you have previously activated Rakuten Communications Hikari or Rakuten Hikari.<br>*   \*If you cancel your application for either Rakuten Mobile, Rakuten Hikari, or both,<br>*   \*When you change the Rakuten ID registered with Rakuten Mobile and Rakuten Hikari to another Rakuten ID.<br>*   \*If Rakuten ID used to Login when applying for Rakuten Hikari is different from the one registered with Rakuten Mobile<br>*   \*If your Rakuten Mobile application is canceled due to deficiencies in identity verification or MNP (Mobile Number Portability) procedures, etc.<br>*   \*If the plan usage of "Rakuten UN-LIMIT VII" has not started.<br>*   \*For those who are using NTT East/NTT West FLET'S HIKARI line and have Rakuten Broadband as their provider.<br>*   \*If you change the plan after Rakuten Hikari is activated (e.g., switching from Family Plan to Mansion Plan or vice versa).<br>*   \*If you cancel your Rakuten membership after applying.<br>*   \*If you proceed with the cancellation of Rakuten Hikari.<br>*   \*When a person living with an existing Rakuten Hikari user applies for Rakuten Hikari at the same installation address (including a contract name change)<br>*   \*When someone who has previously used Rakuten Communications Inc. Hikari or Rakuten Hikari is applying for Rakuten Hikari again at the same installation address as their previous usage.<br>*   \*If you fail to pay the fees for our services or those provided by Rakuten Group by the payment deadline.<br>*   \*If you violate the terms and conditions set by us or Rakuten Group.<br>*   \*If Rakuten Mobile or Rakuten Group determines that the applicant is not eligible for membership for any other reason. |
| Cannot be combined with other campaigns |     | *   Cashback Campaign for iPhone Purchase and Rakuten Hikari Activation (1765) |
| Other Important Notes |     | *   \*Campaign details are subject to change, cancellation, or extension without prior notice.<br>*   \*Campaign reward recipients may be excluded from other simultaneous campaigns, or total rewards may be limited to amounts within the scope of the Prize Display Law.<br>*   \*We may terminate the campaign if any violations such as unauthorized use or resale of the campaign code are found, including forwarding the code to anyone other than the eligible participants.<br>*   \*The information contained herein is current as of Tuesday, April 4, 2023. |

Scroll down

Scroll down

See Campaign Rules

|     |     |     |
| --- | --- | --- |  
| Campaign Code |     | 1109<br><br>*   \* When inquiring about this campaign, please quote the above "campaign code." |
| Campaign Application Period |     | Web<br><br>From October 7, 2020 (Wed) 9:00 to April 12, 2023 (Wed) 9:59<br><br>In-store (Rakuten Mobile Shop)<br><br>Open from October 7, 2020 (Wed) to close on April 11, 2023 (Tue) |
| Campaign Conditions |     | Rakuten members who meet all of the following conditions 1 and 2:<br><br>*   ① Apply for Rakuten Hikari.<br><br>Those who apply for Rakuten Hikari through the application button on this page.<br><br>*   ② Activation of Rakuten Hikari<br><br>Those who apply for Rakuten Hikari during the campaign period and have their first connection within the 4th month after the application month.<br><br>*   \* "Open" refers to the following:  <br>    Activation refers to the state in which you have connected to the Internet using Rakuten Hikari. Please note that activation work is only available to those who are installing a new optical fiber line, and those who are already using FLET'S HIKARI (repurposing) or those who are using another company's optical fiber collaboration (changing service providers) will be activated without any in-house construction work. Customers who use VDSL or LAN wiring will be activated on the scheduled construction date. |
| Campaign Benefits | Campaign Benefits | Mansion Plan<br><br>From the month after activation, for 12 months, the monthly basic fee is ¥1,800 (¥1,980 incl. tax).<br><br>Family Plan<br><br>From the month after activation, for 12 months, the monthly basic fee is ¥2,800 (¥3,080 incl. tax).<br><br>\*Monthly basic fee for the activation month is free.  <br>\*Rights are not transferable. |
| Rakuten Hikari contract for the campaign | Applicable services | Rakuten Hikari<br><br>All plans (Apartment Plan, Family Plan) |
| Contract period | Rakuten Hikari Mansion Plan, Family Plan<br><br>2 years (24 months) / auto-renewal  <br>\*The contract period (2 years) starts from the month following activation.  <br>\*After 24 months of use, a new contract period (2 years) will begin in the 25th month, and this cycle will repeat every 24 months.  <br>\*If the cancellation application is submitted or the number for changing operators is issued between the 24th and 26th months, and the line is removed or changed to another operator's optical collaboration within 24 to 28 months, the Contract cancellation fee will not be incurred.  <br>\*Example: For customers who activated in April 2023, if the cancellation application is received between April 1, 2025, and June 30, 2025, and the line is removed or changed to another operator's optical collaboration within 5 months from April 1, 2025, the Contract cancellation fee will not be incurred.  <br>\*If the contract is terminated during the installment payment period for construction costs, the remaining balance must be paid in a lump sum. |
| Contract cancellation fee | Rakuten Hikari<br><br>Contract cancellation fee: Family Plan (House) ¥5,280, Apartment Plan (Mansion) ¥4,180<br><br>*   \* Contract cancellation fee will be incurred if the cancellation request is made and completed outside the free cancellation application period (24th to 26th month) even during the campaign benefits period. |
| Campaign benefits not applicable. |     | The campaign benefits will not apply if any of the following conditions are met:<br><br>*   \*If you are already using Rakuten Hikari at the time this campaign starts.<br>*   \*If you are already subscribed to Rakuten Hikari<br>*   \*If you have previously activated Rakuten Communications Hikari or Rakuten Hikari.<br>*   \*If you cancel your application for either Rakuten Mobile, Rakuten Hikari, or both,<br>*   \*When you change the Rakuten ID registered with Rakuten Mobile and Rakuten Hikari to another Rakuten ID.<br>*   \*If Rakuten ID used to Login when applying for Rakuten Hikari is different from the one registered with Rakuten Mobile<br>*   \*If your Rakuten Mobile application is canceled due to deficiencies in identity verification or MNP (Mobile Number Portability) procedures, etc.<br>*   \*If the plan usage of "Rakuten UN-LIMIT VII" has not started.<br>*   \*For those who are using NTT East/NTT West FLET'S HIKARI line and have Rakuten Broadband as their provider.<br>*   \*If you change the plan after Rakuten Hikari is activated (e.g., switching from Family Plan to Mansion Plan or vice versa).<br>*   \*If you cancel your Rakuten membership after applying.<br>*   \*If you proceed with the cancellation of Rakuten Hikari.<br>*   \*When a person living with an existing Rakuten Hikari user applies for Rakuten Hikari at the same installation address (including a contract name change)<br>*   \*When someone who has previously used Rakuten Communications Inc. Hikari or Rakuten Hikari is applying for Rakuten Hikari again at the same installation address as their previous usage.<br>*   \*If you fail to pay the fees for our services or those provided by Rakuten Group by the payment deadline.<br>*   \*If you violate the terms and conditions set by us or Rakuten Group.<br>*   \*If Rakuten Mobile or Rakuten Group determines that the applicant is not eligible for membership for any other reason. |
| Cannot be combined with other campaigns |     | *   iPhone Purchase & Rakuten Hikari Activation Cashback Campaign (1765) |
| Other Important Notes |     | *   \*Campaign details are subject to change, cancellation, or extension without prior notice.<br>*   \*Campaign reward recipients may be excluded from other simultaneous campaigns, or total rewards may be limited to amounts within the scope of the Prize Display Law.<br>*   \*We may terminate the campaign if any violations such as unauthorized use or resale of the campaign code are found, including forwarding the code to anyone other than the eligible participants.<br>*   \*The information contained herein is current as of Tuesday, April 4, 2023. |

Scroll down

Scroll down

[Terms of Use & important notices](https://network.mobile.rakuten.co.jp/hikari/terms/?wovn=en&l-id=rhk_terms_01)

[View Other Past Campaign Rules](https://network.mobile.rakuten.co.jp/hikari/campaign/archive/?wovn=en&l-id=rhk_campaign_archive_01)

#### Notes

##### Rakuten Hikari UN-LIMIT Campaign

\*For those who are already using Rakuten Mobile (Rakuten UN-LIMIT VII) or apply for Rakuten Hikari, the monthly basic fee for Rakuten Hikari (Mansion Plan or Family Plan) will be free for up to 12 months from the activation month. From the 13th month onwards, the monthly basic fee will be ¥3,800 (¥4,180 incl. tax) for the Mansion Plan and ¥4,800 (¥5,280 incl. tax) for the Family Plan.

\*Only for the first line of each person. Available to Rakuten members.

\*For those not subscribed to Rakuten Mobile, the monthly basic fee is free in the activation month, and for the next 12 months, it is ¥1,800 (¥1,980 incl. tax) for the Mansion Plan and ¥2,800 (¥3,080 incl. tax) for the Family Plan. From the 14th month onwards, the fees are ¥3,800 (¥4,180 incl. tax) for the Mansion Plan and ¥4,800 (¥5,280 incl. tax) for the Family Plan.

\*Contract cancellation fees of ¥5,280 for Family Plan and ¥4,180 for Mansion Plan apply during the contract period (renewed every 2 years).

\*Excludes initial registration fees, construction costs, and option fees.

\*If Rakuten ID used to Login when applying for Rakuten Hikari is different from the one registered with Rakuten Mobile, or if you change your registered Rakuten ID to a different Rakuten ID, you will not be eligible for the benefit.

#### Rakuten Group Recommended Information

[![Rakuten Bank](https://network.mobile.rakuten.co.jp/assets/img/hikari/campaign/one-year-free/oneyear-banner-03.png)](https://www.rakuten-bank.co.jp/account/campaign/payment1000.html?scid=wi_rmb_hikari_cpn_footer)

[![Rakuten SEIYU Online Supermarket](https://network.mobile.rakuten.co.jp/assets/img/hikari/campaign/one-year-free/oneyear-banner-04.jpg)](https://sm.rakuten.co.jp/?scid=wi_rhk_mobile&xadid=wi_rhk_mobile)

[![Rakuten TV](https://network.mobile.rakuten.co.jp/assets/img/hikari/campaign/one-year-free/oneyear-banner-05.jpg)](https://tv.rakuten.co.jp/?scid=wi_rtv_rhikari_20220622)

[![Rakuten Card](https://network.mobile.rakuten.co.jp/assets/img/hikari/campaign/one-year-free/oneyear-banner-07-220921.gif)](https://ad2.trafficgate.net/t/r/13296/1441/99636_99636/)

[![Rakuten Insurance Referral Campaign](https://network.mobile.rakuten.co.jp/assets/img/hikari/campaign/one-year-free/oneyear-banner-08.png)](https://www.rakuten-insurance.co.jp/event/mgm/?scid=wi_hikari_2207_mgm&argument=bdhoDoBc&dmai=a62c65d0dd5b97)

[![Rakuten Books](https://network.mobile.rakuten.co.jp/assets/img/hikari/campaign/one-year-free/oneyear-banner-01.png)](https://books.rakuten.co.jp/)

[![More exclusive perks for Rakuten Mobile customers!](https://network.mobile.rakuten.co.jp/assets/img/hikari/bnr/tokuten_info_204-204_20241122.png)](https://service.link.link/lp/otoku/campaign.html?scid=wi_link_otoku_hikari)

[![Rakuten Super Mini Byte](https://network.mobile.rakuten.co.jp/assets/img/hikari/campaign/one-year-free/oneyear-banner-02.png)](https://minijob.rakuten.co.jp/?scid=wi_hikari_barter_pc&utm_source=hikari&utm_medium=banner&utm_campaign=barter)

[![Rakuten Bank](https://network.mobile.rakuten.co.jp/assets/img/hikari/campaign/one-year-free/oneyear-banner-03.png)](https://www.rakuten-bank.co.jp/account/campaign/payment1000.html?scid=wi_rmb_hikari_cpn_footer)

[![Rakuten SEIYU Online Supermarket](https://network.mobile.rakuten.co.jp/assets/img/hikari/campaign/one-year-free/oneyear-banner-04.jpg)](https://sm.rakuten.co.jp/?scid=wi_rhk_mobile&xadid=wi_rhk_mobile)

[![Rakuten TV](https://network.mobile.rakuten.co.jp/assets/img/hikari/campaign/one-year-free/oneyear-banner-05.jpg)](https://tv.rakuten.co.jp/?scid=wi_rtv_rhikari_20220622)

[![Rakuten Card](https://network.mobile.rakuten.co.jp/assets/img/hikari/campaign/one-year-free/oneyear-banner-07-220921.gif)](https://ad2.trafficgate.net/t/r/13296/1441/99636_99636/)

[![Rakuten Insurance Referral Campaign](https://network.mobile.rakuten.co.jp/assets/img/hikari/campaign/one-year-free/oneyear-banner-08.png)](https://www.rakuten-insurance.co.jp/event/mgm/?scid=wi_hikari_2207_mgm&argument=bdhoDoBc&dmai=a62c65d0dd5b97)

[![Rakuten Books](https://network.mobile.rakuten.co.jp/assets/img/hikari/campaign/one-year-free/oneyear-banner-01.png)](https://books.rakuten.co.jp/)

[![More exclusive perks for Rakuten Mobile customers!](https://network.mobile.rakuten.co.jp/assets/img/hikari/bnr/tokuten_info_204-204_20241122.png)](https://service.link.link/lp/otoku/campaign.html?scid=wi_link_otoku_hikari)

[![Rakuten Super Mini Byte](https://network.mobile.rakuten.co.jp/assets/img/hikari/campaign/one-year-free/oneyear-banner-02.png)](https://minijob.rakuten.co.jp/?scid=wi_hikari_barter_pc&utm_source=hikari&utm_medium=banner&utm_campaign=barter)

[![Rakuten Bank](https://network.mobile.rakuten.co.jp/assets/img/hikari/campaign/one-year-free/oneyear-banner-03.png)](https://www.rakuten-bank.co.jp/account/campaign/payment1000.html?scid=wi_rmb_hikari_cpn_footer)

[![Rakuten SEIYU Online Supermarket](https://network.mobile.rakuten.co.jp/assets/img/hikari/campaign/one-year-free/oneyear-banner-04.jpg)](https://sm.rakuten.co.jp/?scid=wi_rhk_mobile&xadid=wi_rhk_mobile)

[![Rakuten TV](https://network.mobile.rakuten.co.jp/assets/img/hikari/campaign/one-year-free/oneyear-banner-05.jpg)](https://tv.rakuten.co.jp/?scid=wi_rtv_rhikari_20220622)

[![Rakuten Card](https://network.mobile.rakuten.co.jp/assets/img/hikari/campaign/one-year-free/oneyear-banner-07-220921.gif)](https://ad2.trafficgate.net/t/r/13296/1441/99636_99636/)

[![Rakuten Insurance Referral Campaign](https://network.mobile.rakuten.co.jp/assets/img/hikari/campaign/one-year-free/oneyear-banner-08.png)](https://www.rakuten-insurance.co.jp/event/mgm/?scid=wi_hikari_2207_mgm&argument=bdhoDoBc&dmai=a62c65d0dd5b97)

PreviousNext

*   1
*   2
*   3
*   4
*   5
*   6
*   7
*   8

[![](https://network.mobile.rakuten.co.jp/assets/img/hikari/common-v2/backtop.svg)\
\
Back to top](https://network.mobile.rakuten.co.jp/hikari/campaign/#)

*   [Top](https://network.mobile.rakuten.co.jp/hikari/?wovn=en&l-id=rhk_bcb_top_01)
    
*   Rakuten Hikari UN-LIMIT Campaign

*   [Company Overview](https://corp.mobile.rakuten.co.jp/)
    
*   [Handling of Personal Information](https://corp.mobile.rakuten.co.jp/guide/privacy/)
    
*   [Handling of Information Sent to External Parties](https://network.mobile.rakuten.co.jp/optout/?wovn=en&l-id=rhk_footer_mno_optout_01)
    
*   [Information Security Policy](https://corp.mobile.rakuten.co.jp/guide/security/)
    
*   [Trademarks and Registered Trademarks](https://corp.mobile.rakuten.co.jp/guide/trademark/)
    
*   [Terms of Use & important notices](https://network.mobile.rakuten.co.jp/hikari/terms/?wovn=en&l-id=rhk_footer_terms_01)
    
*   [Rakuten Group Customer Harassment Response Policy](https://corp.rakuten.co.jp/sustainability/human-rights/customer-harassment/)
    

© Rakuten Mobile, Inc.

[![Rakuten Mobile](https://cdn.rmc.contents.rakuten.co.jp/block/d40535ac09aac0ef32f8a23b8bb8e04bc2e8f9d6b0981fa98a16d0382f558d83/d72cbeb1-1b70-4fb2-b7e5-cb3c0a24841f/card20k_enddate_pc_1440x50.png)](https://cdn.rex.contents.rakuten.co.jp/webcx-redirect-module/1.3.0/index.html?clientId=d40535ac09aac0ef32f8a23b8bb8e04bc2e8f9d6b0981fa98a16d0382f558d83&version=2.73.0&sessionId=63fff4de-6af5-4eb0-a9c2-1402cb932f12&screen=WB&issueId=F01184-001256&campaignId=2aadf4f2-55c7-4337-8472-22f617277367&contentId=4382487a-283f-4306-b0d1-11d8c70206b1&replacementId=81db9e56-ef96-4d72-a17a-b0e4899e9bca&impressionId=96e94538-cc3d-4ad8-815d-49eda6c2caf6&selector=mkdiv_footer_pitari&redirect=aHR0cHM6Ly9uZXR3b3JrLm1vYmlsZS5yYWt1dGVuLmNvLmpwL2NhbXBhaWduL2NhcmQtbW9iaWxlLW1haml0b2t1Lw==&origin=aHR0cHM6Ly9uZXR3b3JrLm1vYmlsZS5yYWt1dGVuLmNvLmpw)

*   Rakuten Group
*   [Services](https://www.rakuten.co.jp/sitemap/)
    
*   [Contact (us, form, etc..) list](https://www.rakuten.co.jp/sitemap/inquiry.html)
    
*   [SUSTAINABILITY](https://corp.rakuten.co.jp/sustainability/)
    

  

日本語

English
