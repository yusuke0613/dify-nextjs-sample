# J:COM TV | J:COM

URL: https://www.jcom.co.jp/service/tv/

---

[![あたらしいを、あたりまえに。 J:COM](https://www.jcom.co.jp/common_v10/images/logo-jcom-white.svg)](https://www.jcom.co.jp/?sc_pid=common_jcomlogo_01)

*   [はじめての方へ](https://www.jcom.co.jp/beginner/?sc_pid=globalnavi_beginner_01)
    
*   ご利用中の方
*   [オンラインショップ](https://onlineshop.jcom.co.jp/?sc_pid=globalnavi_ols_01)
    

J:COMサービスご利用中の方

[ご契約内容確認・変更  \
マイページログイン](https://mypage.jcom.co.jp/?sc_pid=common_mypage_01)
 [お困りごと解決・よくあるご質問  \
お客さまサポート](https://cs.myjcom.jp/?sc_pid=common_suppot_01)
 [もっとJ:COMを楽しみたい  \
テレビ番組情報／プレゼント・優待  \
Fun! J:COM](https://www.myjcom.jp/?sc_pid=common_myj_01)

    ![検索](https://www.jcom.co.jp/common_v10/images/snav-icn-search-submit.svg)

*   [あなたへの  \
    お知らせ](https://id.zaq.ne.jp/id/script/connect/authz_req/endpoint.seam?response_type=code&client_id=JCOM_COJP&redirect_uri=https%3A%2F%2Fwww.jcom.co.jp%2Fservice%2Ftv%2F&scope=http%3A%2F%2Fjcom.co.jp%2Fconnect%2Fprofile%2Fstandard_new&nonce=1949823872&state=&prompt=)
    
*   [あなたへの  \
    お知らせ](https://www.jcom.co.jp/service/tv/#)
    

Language

*   日本語
*   English
*   简体中文
*   한국어
*   Tiếng Việt
*   Português

*   サービス
*   [料金一覧](https://www.jcom.co.jp/price/)
    
*   [キャンペーン・  \
    特典](https://www.jcom.co.jp/campaign/)
    
*   お申し込み・  
    各種変更
*   サポート
*   企業サイト

[サービス紹介 トップ](https://www.jcom.co.jp/service/)

[テレビ](https://www.jcom.co.jp/service/tv/)
 [ネット](https://www.jcom.co.jp/service/net/)
 [スマホ](https://www.jcom.co.jp/service/mobile/)
 [でんき](https://www.jcom.co.jp/service/electricity/)
 [固定電話](https://www.jcom.co.jp/service/phone/)
 [ガス](https://www.jcom.co.jp/service/gas/)
 [ほけん](https://www.jcom.co.jp/service/ssi/)
 [ローン](https://www.jcom-financial.co.jp/)
 [防犯カメラ](https://www.jcom.co.jp/guide/starter/home_security/)
 [オンライン診療](https://www.jcom.co.jp/service/telemedicine/)
 [法人・自治体向けサービス![J:COM BUSINESS](https://www.jcom.co.jp/common_v10/images/logo_jcombusiness.webp)](https://business.jcom.co.jp/)

[お申し込み・お問い合わせ](https://www.jcom.co.jp/contactus/)

新規ご加入の方

[新規ご加入の方  \
お申し込み](https://onlineshop.jcom.co.jp/planSelect)

[新規ご加入の方  \
お問い合わせ](https://www.jcom.co.jp/contactus/#entry)

J:COMサービスご利用中の方

[ご利用中の方  \
各種お手続き](https://r.jcom.jp/eG4nLSC)

[お困りごと・お問い合わせ  \
（チャット）](https://prod8-live-chat.sprinklr.com/page?appId=67af27d73657336d345e4a96_app_9070639&did=CHAT_vivr_cojp_top&enableClose=true&skin=MODERN&userContext__c_679c8b53cb85b007fab0f6ea=DirectLink&utm_campaign=IVRSMS&utm_medium=referral&utm_source=did&webview=true&zoom=false)

あなたにピッタリのプランがすぐわかる

[料金シミュレーション](https://onlineshop.jcom.co.jp/Simulation/Simulation)

無料・特別料金の物件も！

対応エリア・物件をご案内

[企業サイト](https://www.jcom.co.jp/corporate/)

[企業理念](https://www.jcom.co.jp/corporate/philosophy_brand/)

[サステナビリティ](https://www.jcom.co.jp/corporate/sustainability/)

[中期経営計画](https://www.jcom.co.jp/corporate/managementplan/)

[ニュースリリース](https://newsreleases.jcom.co.jp/)

[会社案内](https://www.jcom.co.jp/corporate/company/)

[採用情報](https://recruit.jcom.co.jp/)

[サポート トップ](https://cs.myjcom.jp/)

[テレビ](https://cs.myjcom.jp/categories/support/67ab976bf07f5244a208cb97)
 [ネット](https://cs.myjcom.jp/categories/support/67ab9788f07f5244a208cced)
 [スマホ](https://cs.myjcom.jp/categories/support/67ab979df07f5244a208cdc9)
 [でんき](https://cs.myjcom.jp/categories/support/67ab97b5f07f5244a208cec9)
 [固定電話](https://cs.myjcom.jp/categories/support/67ab97abf07f5244a208ce4e)
 [ガス](https://cs.myjcom.jp/categories/support/67ab97b8f07f5244a208ceda)
 [ほけん](https://cs.myjcom.jp/categories/support/67ab97c5f07f5244a208cf2f)
 [オンライン診療](https://cs.myjcom.jp/categories/support/67ab97c2f07f5244a208cf1b)
 [ホームIoT](https://cs.myjcom.jp/categories/support/67ab97bcf07f5244a208cee6)
 [防犯カメラ](https://cs.myjcom.jp/categories/support/67ab97f5f07f5244a208d09b)

[J:COM STREAM](https://cs.myjcom.jp/categories/support/67ab97c9f07f5244a208cf49)

[えんかくサポート](https://cs.myjcom.jp/categories/support/67ab97faf07f5244a208d0c2)

[おうちサポート](https://cs.myjcom.jp/categories/support/67ab97d4f07f5244a208cf92)

[防災情報サービス](https://cs.myjcom.jp/categories/support/67ab97d8f07f5244a208cfa0)

[自転車生活サポート](https://cs.myjcom.jp/categories/support/67ab97e8f07f5244a208d023)

[J:COMブックス](https://cs.myjcom.jp/categories/support/67ab97e4f07f5244a208d003)

[WiMAX](https://cs.myjcom.jp/categories/support/67ab97f1f07f5244a208d074)

[障害・メンテナンス情報](https://information.myjcom.jp/maintenance_outage/)

各種お手続き

[パーソナルID](https://cs.myjcom.jp/categories/support/67ab9803f07f5244a208d113)

[料金・支払い](https://cs.myjcom.jp/categories/support/67ab9805f07f5244a208d139)

[引越し・建替え](https://cs.myjcom.jp/categories/support/67ab980cf07f5244a208d184)

[訪問・窓口](https://cs.myjcom.jp/categories/support/67ab980ff07f5244a208d1a4)

[契約関連](https://cs.myjcom.jp/categories/support/67ab9806f07f5244a208d150)

[休止・解約](https://cs.myjcom.jp/categories/support/67ab980cf07f5244a208d188)

[加入特典](https://cs.myjcom.jp/categories/support/67ab980df07f5244a208d18c)

[![あたらしいを、あたりまえに J:COM](https://www.jcom.co.jp/common_v10/images/logo-jcom-white.svg)](https://www.jcom.co.jp/?sc_pid=common_jcomlogo_01)

[![J:COM TV](https://www.jcom.co.jp/common_v10/images/logo-jcom-tv-bk.svg)](https://www.jcom.co.jp/service/tv/)

*   料金・コース
*   多彩なコンテンツ
*   [ネット動画](https://www.jcom.co.jp/service/tv/smart/ott.html)
    
*   [便利な機能](https://www.jcom.co.jp/service/tv/smart/)
    
*   オプション
*   [お申し込みの流れ](https://www.jcom.co.jp/service/tv/guide/)
    

[料金・コース トップ](https://www.jcom.co.jp/service/tv/course/)

*   [J:COM TV シン・スタンダード](https://www.jcom.co.jp/service/tv/course/standard.html)
    
*   [J:COM TV シン・スタンダードプラス](https://www.jcom.co.jp/service/tv/course/standard_plus.html)
    
*   [J:COM TV セレクト](https://www.jcom.co.jp/service/tv/course/select.html)
    

[多彩なコンテンツ トップ](https://www.jcom.co.jp/service/tv/channel/)

*   [チャンネルラインアップ](https://www.jcom.co.jp/service/tv/channel/list/)
    
*   [オプションチャンネルラインアップ](https://www.jcom.co.jp/service/tv/channel/option_ch/)
    
*   [コース別チャンネル比較表](https://www.jcom.co.jp/service/tv/channel/comparison/)
    

[オプション トップ](https://www.jcom.co.jp/service/tv/accessories/)

*   [J:COM Netflixセット](https://www.jcom.co.jp/guide/starter/netflix/)
    
*   [録画用ハードディスク](https://www.jcom.co.jp/service/tv/accessories/hdd/)
    
*   [J:COM LINK mini](https://www.jcom.co.jp/service/tv/accessories/linkmini/)
    

[![あたらしいを、あたりまえに J:COM](https://www.jcom.co.jp/common_v10/images/logo-jcom.svg)](https://www.jcom.co.jp/)

*   サービス

*   [お申し込み](https://onlineshop.jcom.co.jp/planSelect)
    
*   [お問い合わせ](https://www.jcom.co.jp/contactus/)
    
*   [はじめて  \
    の方へ](https://www.jcom.co.jp/beginner/)
    
*   ご利用中  
    の方
*   [オンライン  \
    ショップ](https://onlineshop.jcom.co.jp/)
    
*   ![検索する](https://www.jcom.co.jp/common_v10/images/fixed-nav-icn-search.svg)

    ![検索](https://www.jcom.co.jp/common_v10/images/snav-icn-search-submit.svg)

J:COMサービスご利用中の方

[ご契約内容確認・変更  \
マイページログイン](https://mypage.jcom.co.jp/)
 [お困りごと解決・よくあるご質問  \
お客さまサポート](https://cs.myjcom.jp/)
 [もっとJ:COMを楽しみたい  \
テレビ番組情報／プレゼント・優待  \
Fun! J:COM](https://www.myjcom.jp/)

[サービス紹介 トップ](https://www.jcom.co.jp/service/)

[テレビ](https://www.jcom.co.jp/service/tv/)
 [ネット](https://www.jcom.co.jp/service/net/)
 [スマホ](https://www.jcom.co.jp/service/mobile/)
 [でんき](https://www.jcom.co.jp/service/electricity/)
 [固定電話](https://www.jcom.co.jp/service/phone/)
 [ガス](https://www.jcom.co.jp/service/gas/)
 [ほけん](https://www.jcom.co.jp/service/ssi/)
 [ローン](https://www.jcom-financial.co.jp/)
 [防犯カメラ](https://www.jcom.co.jp/guide/starter/home_security/)
 [オンライン診療](https://www.jcom.co.jp/service/telemedicine/)
 [法人・自治体向けサービス![J:COM BUSINESS](https://www.jcom.co.jp/common_v10/images/logo_jcombusiness.webp)](https://business.jcom.co.jp/)

[![J:COM TV](https://www.jcom.co.jp/common_v10/images/logo-jcom-tv-bk.svg)](https://www.jcom.co.jp/service/tv/)

*   料金・コース
*   多彩なコンテンツ
*   [ネット動画](https://www.jcom.co.jp/service/tv/smart/ott.html)
    
*   [便利な機能](https://www.jcom.co.jp/service/tv/smart/)
    
*   オプション
*   [お申し込みの流れ](https://www.jcom.co.jp/service/tv/guide/)
    

[料金・コース トップ](https://www.jcom.co.jp/service/tv/course/)

*   [J:COM TV シン・スタンダード](https://www.jcom.co.jp/service/tv/course/standard.html)
    
*   [J:COM TV シン・スタンダードプラス](https://www.jcom.co.jp/service/tv/course/standard_plus.html)
    
*   [J:COM TV セレクト](https://www.jcom.co.jp/service/tv/course/select.html)
    

[多彩なコンテンツ トップ](https://www.jcom.co.jp/service/tv/channel/)

*   [チャンネルラインアップ](https://www.jcom.co.jp/service/tv/channel/list/)
    
*   [オプションチャンネルラインアップ](https://www.jcom.co.jp/service/tv/channel/option_ch/)
    
*   [コース別チャンネル比較表](https://www.jcom.co.jp/service/tv/channel/comparison/)
    

[オプション トップ](https://www.jcom.co.jp/service/tv/accessories/)

*   [J:COM Netflixセット](https://www.jcom.co.jp/guide/starter/netflix/)
    
*   [録画用ハードディスク](https://www.jcom.co.jp/service/tv/accessories/hdd/)
    
*   [J:COM LINK mini](https://www.jcom.co.jp/service/tv/accessories/linkmini/)
    

*   ![メニュー](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/text-menu.svg)
*   ![J:COM TV メニュー](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom-tv/text-menu.svg)
*   [![料金シミュレーション](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom-tv/text-sim.svg)](https://onlineshop.jcom.co.jp/Simulation/Simulation)
    
*   [![お申し込み](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom-tv/text-entry.svg)](https://onlineshop.jcom.co.jp/planSelect)
    
*   [![よくある質問　お問い合わせ](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom-tv/text-faq.svg)](https://cs.myjcom.jp/categorySearch?cg=ServiceOutside&c=tv)
    

*   [![あたらしいを、あたりまえに　J:COM](https://www.jcom.co.jp/common_v10/images/logo-jcom-only-white.svg)](https://www.jcom.co.jp/)
     ![メニューを閉じる](https://www.jcom.co.jp/common_v10/images/sp-menu/menu-close-white.svg)
    
    [J:COMのサービス](https://www.jcom.co.jp/service/)
    
    *   [![テレビ](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-tv-item.svg)](https://www.jcom.co.jp/service/tv/)
        
    *   [![ネット](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-net-item.svg)](https://www.jcom.co.jp/service/net/)
        
    *   [![スマホ](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-mobile-item.svg)](https://www.jcom.co.jp/service/mobile/)
        
    
    *   [![電気](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-electricity-item.svg)](https://www.jcom.co.jp/service/electricity/)
        
    *   [![固定電話](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-phone-item.svg)](https://www.jcom.co.jp/service/phone/)
        
    *   [![ガス](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-gas-item.svg)](https://www.jcom.co.jp/service/gas/)
        
    *   [![ほけん](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-ssi-item.svg)](https://www.jcom.co.jp/service/ssi/)
        
    *   [ローン](https://www.jcom-financial.co.jp/)
        
    *   [![ホームIoT](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-home-item.svg)](https://www.jcom.co.jp/service/home/)
        
    *   [防犯カメラ](https://www.jcom.co.jp/guide/starter/home_security/)
        
    *   [![オンライン診療](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-telemedicine-item.svg)](https://www.jcom.co.jp/service/telemedicine/)
        
    
    [法人・自治体向けサービス  \
    ![J:COM BUSINESS](https://www.jcom.co.jp/common_v10/images/logo_jcombusiness.webp)](https://business.jcom.co.jp/)
    
    サービス一覧
    
    [料金一覧](https://www.jcom.co.jp/price/)
     [キャンペーン・特典](https://www.jcom.co.jp/campaign/)
     [サポート](https://cs.myjcom.jp/)
     [お申し込み・各種変更](https://www.jcom.co.jp/contactus/)
    
        ![検索](https://www.jcom.co.jp/common_v10/images/snav-icn-search-submit-sp.svg)
    
    [J:COM トップ](https://www.jcom.co.jp/)
    
    *   [サービス情報](https://www.jcom.co.jp/)
        
    *   [オンライン  \
        ショップ](https://onlineshop.jcom.co.jp/)
        
    *   [サポート](https://cs.myjcom.jp/)
        
    *   [Fun! J:COM](https://www.myjcom.jp/)
        
    *   [マイページ](https://mypage.jcom.co.jp/)
        
    *   [企業サイト](https://www.jcom.co.jp/corporate/)
        
    
*   [![J:COM TV](https://www.jcom.co.jp/common_v10/images/icn-jcom-tv.svg)テレビ](https://www.jcom.co.jp/service/tv/)
     ![メニューを閉じる](https://www.jcom.co.jp/common_v10/images/sp-menu/menu-close.svg)
    
    [![](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom-tv/slide/menu/mv-middle.webp)\
    \
    あなたの見たいを叶える\
    \
    トップ](https://www.jcom.co.jp/service/tv/)
    
    *   料金・コース
        
        *   [料金・コース トップ](https://www.jcom.co.jp/service/tv/course/)
            
        *   [J:COM TV シン・スタンダード](https://www.jcom.co.jp/service/tv/course/standard.html)
            
        *   [J:COM TV シン・スタンダードプラス](https://www.jcom.co.jp/service/tv/course/standard_plus.html)
            
        *   [J:COM TV セレクト](https://www.jcom.co.jp/service/tv/course/select.html)
            
        
    *   多彩なコンテンツ
        
        *   [多彩なコンテンツ トップ](https://www.jcom.co.jp/service/tv/channel/)
            
        *   [チャンネルラインアップ](https://www.jcom.co.jp/service/tv/channel/list/)
            
        *   [オプションチャンネル](https://www.jcom.co.jp/service/tv/channel/option_ch/)
            
        *   [コース別チャンネル比較表](https://www.jcom.co.jp/service/tv/channel/comparison/)
            
        
    *   [ネット動画](https://www.jcom.co.jp/service/tv/smart/ott.html)
        
    *   [便利な機能](https://www.jcom.co.jp/service/tv/smart/)
        
    *   オプション
        
        *   [オプション トップ](https://www.jcom.co.jp/service/tv/accessories/)
            
        *   [J:COM Netflixセット](https://www.jcom.co.jp/guide/starter/netflix/)
            
        *   [録画用ハードディスク](https://www.jcom.co.jp/service/tv/accessories/hdd/)
            
        *   [J:COM LINK mini](https://www.jcom.co.jp/service/tv/accessories/linkmini/)
            
        
    *   [お申し込みの流れ](https://www.jcom.co.jp/service/tv/guide/)
        
    

![](https://www.jcom.co.jp/common_v10/images/icn-jcom-tv.svg)

![J:COM TV](https://www.jcom.co.jp/common_v10/images/logo-jcom-tv.svg)

見る楽しさ。見つける楽しさ。J:COM TV シン・スタンダード
================================

  [![見る楽しさ。見つける楽しさ。J:COM TV シン・スタンダード](https://www.jcom.co.jp/service/tv/images_v10/topics_shinsta.webp)](https://www.jcom.co.jp/guide/starter/tv/)

  [![2025-26 大同生命 SV.LEAGUE J SPORTSオンデマンドで男女全試合をLIVE配信！](https://www.jcom.co.jp/service/tv/images_v10/topics_svliague2025.webp)](https://www2.myjcom.jp/special/tv/sports/volleyball/svleague/)

  [![J:COM TV 見る楽しさ。見つける楽しさ。 シン・スタンダード3カ月間500円（税込）/月 ※WEB限定スタート割適用、4カ月目以降4,950円（税込）/月～。2年契約、自動更新。途中解約は解除料要。](https://www.jcom.co.jp/service/tv/images_v10/topics_shinsta-v2.webp)](https://www.jcom.co.jp/guide/starter/tv/)

  [![NETFLIX 夢中になれるシアワセを。 J:COM Netflixセット新登場 ずーっと330円/月割引](https://www.jcom.co.jp/service/tv/images_v10/topics_netflix.webp)](https://www.jcom.co.jp/guide/starter/netflix/)

  [![観たいものゾクゾク！ J:COM STREAM](https://www.jcom.co.jp/service/tv/images_v10/topics_stream.webp)](https://www.jcom.co.jp/guide/starter/tv/stream/)

  [![J:COMならディズニープラスが最大3カ月無料](https://www.jcom.co.jp/service/tv/images_v10/topics_dplus_v2.webp)](https://www.jcom.co.jp/service/disneyplus/lp/)

  [![2025-26 大同生命 SV.LEAGUE J SPORTSオンデマンドで男女全試合をLIVE配信！](https://www.jcom.co.jp/service/tv/images_v10/topics_svliague2025.webp)](https://www2.myjcom.jp/special/tv/sports/volleyball/svleague/)

  [![J:COM TV 見る楽しさ。見つける楽しさ。 シン・スタンダード3カ月間500円（税込）/月 ※WEB限定スタート割適用、4カ月目以降4,950円（税込）/月～。2年契約、自動更新。途中解約は解除料要。](https://www.jcom.co.jp/service/tv/images_v10/topics_shinsta-v2.webp)](https://www.jcom.co.jp/guide/starter/tv/)

  [![NETFLIX 夢中になれるシアワセを。 J:COM Netflixセット新登場 ずーっと330円/月割引](https://www.jcom.co.jp/service/tv/images_v10/topics_netflix.webp)](https://www.jcom.co.jp/guide/starter/netflix/)

  [![観たいものゾクゾク！ J:COM STREAM](https://www.jcom.co.jp/service/tv/images_v10/topics_stream.webp)](https://www.jcom.co.jp/guide/starter/tv/stream/)

  [![J:COMならディズニープラスが最大3カ月無料](https://www.jcom.co.jp/service/tv/images_v10/topics_dplus_v2.webp)](https://www.jcom.co.jp/service/disneyplus/lp/)

  [![2025-26 大同生命 SV.LEAGUE J SPORTSオンデマンドで男女全試合をLIVE配信！](https://www.jcom.co.jp/service/tv/images_v10/topics_svliague2025.webp)](https://www2.myjcom.jp/special/tv/sports/volleyball/svleague/)

  [![J:COM TV 見る楽しさ。見つける楽しさ。 シン・スタンダード3カ月間500円（税込）/月 ※WEB限定スタート割適用、4カ月目以降4,950円（税込）/月～。2年契約、自動更新。途中解約は解除料要。](https://www.jcom.co.jp/service/tv/images_v10/topics_shinsta-v2.webp)](https://www.jcom.co.jp/guide/starter/tv/)

  [![NETFLIX 夢中になれるシアワセを。 J:COM Netflixセット新登場 ずーっと330円/月割引](https://www.jcom.co.jp/service/tv/images_v10/topics_netflix.webp)](https://www.jcom.co.jp/guide/starter/netflix/)

  [![観たいものゾクゾク！ J:COM STREAM](https://www.jcom.co.jp/service/tv/images_v10/topics_stream.webp)](https://www.jcom.co.jp/guide/starter/tv/stream/)

  [![J:COMならディズニープラスが最大3カ月無料](https://www.jcom.co.jp/service/tv/images_v10/topics_dplus_v2.webp)](https://www.jcom.co.jp/service/disneyplus/lp/)

[おすすめ番組](https://www.jcom.co.jp/service/tv/#anc-01)

[J:COM TV  \
おすすめの理由](https://www.jcom.co.jp/service/tv/#anc-02)

[料金・コース](https://www.jcom.co.jp/service/tv/#anc-03)

[キャンペーン・特典](https://www.jcom.co.jp/service/tv/#anc-04)

[お客さまの声](https://www.jcom.co.jp/service/tv/#anc-05)

新規ご加入の方

[新規ご加入の方  \
お申し込み](https://onlineshop.jcom.co.jp/planSelect)

[新規ご加入の方  \
お問い合わせ](https://www.jcom.co.jp/service/tv/#)

ご利用中の方

[ご利用中の方  \
各種お手続き](https://r.jcom.jp/ev3z3wr)

[お困りごと・  \
お問い合わせ  \
（チャット）](https://prod8-live-chat.sprinklr.com/page?appId=67af27d73657336d345e4a96_app_9070639&did=CHAT_vivr_cojp_tv&enableClose=true&skin=MODERN&userContext__c_679c8b53cb85b007fab0f6ea=DirectLink&utm_campaign=IVRSMS&utm_medium=referral&utm_source=did&webview=true&zoom=false)

あなたにピッタリの  
プランがすぐわかる

[料金シミュ  \
レーション](https://onlineshop.jcom.co.jp/Simulation/Simulation)

無料・特別料金の物件も！

対応エリア・  
物件をご案内

新規ご加入の方

[お申し込み](https://onlineshop.jcom.co.jp/planSelect?sc_pid=common_upper_entry_02)

[![](https://www.jcom.co.jp/common_v10/images/icn-think-black.svg)Applications and Inquiries](https://www.jcom.co.jp/service/tv/#)

[![](https://www.jcom.co.jp/common_v10/images/icn-think-black.svg)申请・咨询](https://www.jcom.co.jp/zh-CHS/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[电话咨询  \
050-1722-1733](tel:050-1722-1733)
 9:00-18:00【全年无休】／有翻译 [日本語での通話は  \
こちら](https://www.jcom.co.jp/service/tv/#)

[![](https://www.jcom.co.jp/common_v10/images/icn-think-black.svg)신청·문의](https://www.jcom.co.jp/ko/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[신청·문의  \
050-1722-1733](tel:050-1722-1733)
 9:00-18:00【연중무휴】／통역 있음 [日本語での通話は  \
こちら](https://www.jcom.co.jp/service/tv/#)

[![](https://www.jcom.co.jp/common_v10/images/icn-think-black.svg)Ứng dụng / Yêu cầu](https://www.jcom.co.jp/vi/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Ứng dụng / Yêu cầu  \
050-1722-1733](tel:050-1722-1733)
 9:00-18:00【mở cửa quanh năm】／có phiên dịch [日本語での通話は  \
こちら](https://www.jcom.co.jp/service/tv/#)

[![](https://www.jcom.co.jp/common_v10/images/icn-think-black.svg)Solicitação/Consultas](https://www.jcom.co.jp/pt/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Solicitação/Consultas  \
050-1722-1733](tel:050-1722-1733)
 9:00-18:00【aberto todo o ano】／com intérprete [日本語での通話は  \
こちら](https://www.jcom.co.jp/service/tv/#)

ご利用中の方

[契約内容  \
確認・変更  \
日本語のみ](https://www2.myjcom.jp/join/?ac_id=btm_change&sc_pid=common_upper_join_02)

[![](https://www.jcom.co.jp/common_v10/images/icn-member.svg)Inquiries](https://www.jcom.co.jp/service/tv/#)

[![](https://www.jcom.co.jp/common_v10/images/icn-member.svg)联系我们](https://www.jcom.co.jp/service/tv/#)

[![](https://www.jcom.co.jp/common_v10/images/icn-member.svg)문의](https://www.jcom.co.jp/service/tv/#)

[![](https://www.jcom.co.jp/common_v10/images/icn-member.svg)Hỏi đáp](https://www.jcom.co.jp/service/tv/#)

[![](https://www.jcom.co.jp/common_v10/images/icn-member.svg)Consultar](https://www.jcom.co.jp/service/tv/#)

あなたにピッタリの  
プランがすぐわかる

[料金シミュ  \
レーション](https://onlineshop.jcom.co.jp/Simulation/Simulation?sc_pid=common_upper_simu_02)

無料・特別料金の物件も！

対応エリア・  
物件をご案内

[](https://www.jcom.co.jp/service/tv/#)

新規ご加入の方　  
お問い合わせ

[Webでお問い合わせ](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

J:COMよりメールまたはお電話で回答いたします。

お電話でのお問い合わせ(通話無料)はこちら

[0120-989-970](tel:0120-989-970)

9:00～18:00［年中無休］

[閉じる](https://www.jcom.co.jp/service/tv/#)

[大分の方は、こちらをご覧ください。](https://wwwjcom.oct-net.ne.jp/)

パーソナルIDでログイン中です。

ご利用中の方へ  
おすすめ情報をご案内

[![ログイン](https://www.jcom.co.jp/common_v10/images/login_b.webp)](https://id.zaq.ne.jp/id/script/connect/authz_req/endpoint.seam?response_type=code&client_id=JCOM_COJP&redirect_uri=https%3A%2F%2Fwww.jcom.co.jp%2Fservice%2Ftv%2F&scope=http%3A%2F%2Fjcom.co.jp%2Fconnect%2Fprofile%2Fstandard_new&nonce=1949823872&state=&prompt=)

2025年3月から

J:COM TVが、  
パワーアップして  
より楽しく！

さらに進化

J:COM STREAM

Paramount＋に加え、  
TELASAの作品も見放題に

![TELASA](https://www.jcom.co.jp/service/tv/images_v10/logo/logo_TELASA.webp)

[詳しく見る](https://www.jcom.co.jp/guide/starter/tv/stream/)

新登場

J:COM Netflix セット

J:COMなら、  
Netflixもおトクに楽しめる

![Netflix](https://www.jcom.co.jp/service/tv/images_v10/logo/logo_Netflix.webp)

[詳しく見る](https://www.jcom.co.jp/guide/starter/netflix/)

J:COM TV  
おすすめの理由
------------------

[圧倒的な番組数\
\
充実の  \
スポーツコンテンツ\
\
![](https://www.jcom.co.jp/service/tv/images_v10/img-rec-point01.webp)](https://www.jcom.co.jp/service/tv/#recommend1)

[映画・アニメ・ライブや時代劇も\
\
専門チャンネルと  \
動画配信を両方楽しめる\
\
![](https://www.jcom.co.jp/service/tv/images_v10/img-rec-point02.webp)](https://www.jcom.co.jp/service/tv/#recommend2)

[好みの作品と出会える！\
\
あなた好みの番組や  \
録画をレコメンド\
\
![](https://www.jcom.co.jp/service/tv/images_v10/img-rec-point03.webp)](https://www.jcom.co.jp/service/tv/#recommend3)

[テレビの大画面でも、スマホでも\
\
いつでもどこでも  \
楽しめる！\
\
![](https://www.jcom.co.jp/service/tv/images_v10/img-rec-point04.webp)](https://www.jcom.co.jp/service/tv/#recommend4)

おすすめ番組・配信PICK UP
----------------

[![](https://tvguide.myjcom.jp//monomedia/si/2025/20251205/16715553/image/c53cd2b4f475e7c54ecb6a16b15c469f.jpg)\
\
専門チャンネル\
\
\[映\]麒麟の翼〜劇場版・新参者〜\
\
12/5（金） 09:10〜11:30  \
日本映画専門チャンネル　HD](https://tvguide.myjcom.jp/r/?id=050120251205091000)

[![](https://www2.myjcom.jp//tv/assets/images/bnr_ott/bnr_vod_fuyuharunatsuaki_606_340.jpg)\
\
J:COM STREAM\
\
冬、春、夏、秋 私たちのラブストーリー\
\
見放題](https://linkvod.myjcom.jp/video/ep00546259?type=group)

[![](https://www2.myjcom.jp/special/tv/netflix/recommend/images/251101.jpg)\
\
Netflix\
\
イクサガミ\
\
11月13日独占配信](https://www2.myjcom.jp/special/tv/netflix/detail.shtml?page=251101)

[![](https://tvguide.myjcom.jp//monomedia/si/2025/20251205/16715579/image/5ac82006f1f39a22a25e17afdbe75298.jpg)\
\
専門チャンネル\
\
（吹）ワイルド・スピードＸ３　TOKYO DRIFT【新録版】【４K】\
\
12/5（金） 13:00〜14:55  \
ザ・シネマ HD](https://tvguide.myjcom.jp/r/?id=045220251205130000)

[![](https://www2.myjcom.jp//tv/assets/images/bnr_ott/bnr_vod_godzillaxkong_606_340.jpg)\
\
J:COM STREAM\
\
ゴジラxコング 新たなる帝国\
\
見放題](https://linkvod.myjcom.jp/video/ep00494266?type=group)

[![](https://www2.myjcom.jp/special/tv/netflix/recommend/images/251102.jpg)\
\
Netflix\
\
ストレンジャー・シングス 未知の世界 5\
\
独占配信中（VOL 1）](https://www2.myjcom.jp/special/tv/netflix/detail.shtml?page=251102)

[![](https://tvguide.myjcom.jp//monomedia/si/2025/20251205/16752647/image/65c796decf9a78c3ec85d1c0a2d33648.jpg)\
\
専門チャンネル\
\
トゥルー・クライム【日本語吹替版】◆特集：２４時間　吹替ざんまい◆\
\
12/5（金） 15:30〜17:45  \
ムービープラス](https://tvguide.myjcom.jp/r/?id=045020251205153000)

[![](https://www2.myjcom.jp//tv/assets/images/bnr_ott/bnr_vod__cinemakabuki_sagimusume_606_340.jpg)\
\
J:COM STREAM\
\
シネマ歌舞伎 鷺娘/日高川入相花王\
\
見放題](https://linkvod.myjcom.jp/video/ep00568280?type=group)

[![](https://www2.myjcom.jp/special/tv/netflix/recommend/images/%20251209.jpg)\
\
Netflix\
\
エミリー、パリへ行く: シーズン5\
\
12月18日独占配信](https://www2.myjcom.jp/special/tv/netflix/detail.shtml?page=251209)

[![](https://tvguide.myjcom.jp//monomedia/si/2025/20251205/16715553/image/c53cd2b4f475e7c54ecb6a16b15c469f.jpg)\
\
専門チャンネル\
\
\[映\]麒麟の翼〜劇場版・新参者〜\
\
12/5（金） 09:10〜11:30  \
日本映画専門チャンネル　HD](https://tvguide.myjcom.jp/r/?id=050120251205091000)

[![](https://www2.myjcom.jp//tv/assets/images/bnr_ott/bnr_vod_fuyuharunatsuaki_606_340.jpg)\
\
J:COM STREAM\
\
冬、春、夏、秋 私たちのラブストーリー\
\
見放題](https://linkvod.myjcom.jp/video/ep00546259?type=group)

[![](https://www2.myjcom.jp/special/tv/netflix/recommend/images/251101.jpg)\
\
Netflix\
\
イクサガミ\
\
11月13日独占配信](https://www2.myjcom.jp/special/tv/netflix/detail.shtml?page=251101)

[![](https://tvguide.myjcom.jp//monomedia/si/2025/20251205/16715579/image/5ac82006f1f39a22a25e17afdbe75298.jpg)\
\
専門チャンネル\
\
（吹）ワイルド・スピードＸ３　TOKYO DRIFT【新録版】【４K】\
\
12/5（金） 13:00〜14:55  \
ザ・シネマ HD](https://tvguide.myjcom.jp/r/?id=045220251205130000)

[![](https://www2.myjcom.jp//tv/assets/images/bnr_ott/bnr_vod_godzillaxkong_606_340.jpg)\
\
J:COM STREAM\
\
ゴジラxコング 新たなる帝国\
\
見放題](https://linkvod.myjcom.jp/video/ep00494266?type=group)

[![](https://www2.myjcom.jp/special/tv/netflix/recommend/images/251102.jpg)\
\
Netflix\
\
ストレンジャー・シングス 未知の世界 5\
\
独占配信中（VOL 1）](https://www2.myjcom.jp/special/tv/netflix/detail.shtml?page=251102)

[![](https://tvguide.myjcom.jp//monomedia/si/2025/20251205/16752647/image/65c796decf9a78c3ec85d1c0a2d33648.jpg)\
\
専門チャンネル\
\
トゥルー・クライム【日本語吹替版】◆特集：２４時間　吹替ざんまい◆\
\
12/5（金） 15:30〜17:45  \
ムービープラス](https://tvguide.myjcom.jp/r/?id=045020251205153000)

[![](https://www2.myjcom.jp//tv/assets/images/bnr_ott/bnr_vod__cinemakabuki_sagimusume_606_340.jpg)\
\
J:COM STREAM\
\
シネマ歌舞伎 鷺娘/日高川入相花王\
\
見放題](https://linkvod.myjcom.jp/video/ep00568280?type=group)

[![](https://www2.myjcom.jp/special/tv/netflix/recommend/images/%20251209.jpg)\
\
Netflix\
\
エミリー、パリへ行く: シーズン5\
\
12月18日独占配信](https://www2.myjcom.jp/special/tv/netflix/detail.shtml?page=251209)

[![](https://tvguide.myjcom.jp//monomedia/si/2025/20251205/16715553/image/c53cd2b4f475e7c54ecb6a16b15c469f.jpg)\
\
専門チャンネル\
\
\[映\]麒麟の翼〜劇場版・新参者〜\
\
12/5（金） 09:10〜11:30  \
日本映画専門チャンネル　HD](https://tvguide.myjcom.jp/r/?id=050120251205091000)

[![](https://www2.myjcom.jp//tv/assets/images/bnr_ott/bnr_vod_fuyuharunatsuaki_606_340.jpg)\
\
J:COM STREAM\
\
冬、春、夏、秋 私たちのラブストーリー\
\
見放題](https://linkvod.myjcom.jp/video/ep00546259?type=group)

[![](https://www2.myjcom.jp/special/tv/netflix/recommend/images/251101.jpg)\
\
Netflix\
\
イクサガミ\
\
11月13日独占配信](https://www2.myjcom.jp/special/tv/netflix/detail.shtml?page=251101)

[![](https://tvguide.myjcom.jp//monomedia/si/2025/20251205/16715579/image/5ac82006f1f39a22a25e17afdbe75298.jpg)\
\
専門チャンネル\
\
（吹）ワイルド・スピードＸ３　TOKYO DRIFT【新録版】【４K】\
\
12/5（金） 13:00〜14:55  \
ザ・シネマ HD](https://tvguide.myjcom.jp/r/?id=045220251205130000)

[![](https://www2.myjcom.jp//tv/assets/images/bnr_ott/bnr_vod_godzillaxkong_606_340.jpg)\
\
J:COM STREAM\
\
ゴジラxコング 新たなる帝国\
\
見放題](https://linkvod.myjcom.jp/video/ep00494266?type=group)

[![](https://www2.myjcom.jp/special/tv/netflix/recommend/images/251102.jpg)\
\
Netflix\
\
ストレンジャー・シングス 未知の世界 5\
\
独占配信中（VOL 1）](https://www2.myjcom.jp/special/tv/netflix/detail.shtml?page=251102)

[![](https://tvguide.myjcom.jp//monomedia/si/2025/20251205/16752647/image/65c796decf9a78c3ec85d1c0a2d33648.jpg)\
\
専門チャンネル\
\
トゥルー・クライム【日本語吹替版】◆特集：２４時間　吹替ざんまい◆\
\
12/5（金） 15:30〜17:45  \
ムービープラス](https://tvguide.myjcom.jp/r/?id=045020251205153000)

[![](https://www2.myjcom.jp//tv/assets/images/bnr_ott/bnr_vod__cinemakabuki_sagimusume_606_340.jpg)\
\
J:COM STREAM\
\
シネマ歌舞伎 鷺娘/日高川入相花王\
\
見放題](https://linkvod.myjcom.jp/video/ep00568280?type=group)

[![](https://www2.myjcom.jp/special/tv/netflix/recommend/images/%20251209.jpg)\
\
Netflix\
\
エミリー、パリへ行く: シーズン5\
\
12月18日独占配信](https://www2.myjcom.jp/special/tv/netflix/detail.shtml?page=251209)

[見たい番組・作品を探す](https://www2.myjcom.jp/tv/)

料金・コース
------

### みんなの 「見たい」に応える、充実のラインアップ

*   人気
    
     [![厳選した専門チャンネルとTELASA、Paramount+を含む動画配信 J:COM TV シン・スタンダード 厳選した48の専門チャンネル J:COM STREAM★1](https://www.jcom.co.jp/service/tv/channel/images_v10/channel-course2_v3.webp)\
    \
    詳しく見る](https://www.jcom.co.jp/service/tv/course/standard.html)
    
*    [![専門チャンネル69chと動画配信をとことん楽しむ J:COM TV シン・スタンダードプラス 充実の69の専門チャンネル J:COM STREAM](https://www.jcom.co.jp/service/tv/channel/images_v10/channel-course-standardplus.webp)\
    \
    詳しく見る](https://www.jcom.co.jp/service/tv/course/standard_plus.html)
    
*    [![あなたの好きなジャンルをセレクト！ J:COM TV セレクト 8パックから選べる](https://www.jcom.co.jp/service/tv/channel/images_v10/channel-course3.webp)\
    \
    詳しく見る](https://www.jcom.co.jp/service/tv/course/select.html)
    

[料金・コーストップはこちら](https://www.jcom.co.jp/service/tv/course/)

おすすめ料金例
-------

テレビがおトクに楽しめるコースをご案内

*   集合住宅の方
*   戸建住宅の方

|     |
| --- |
| 厳選した専門チャンネルと  <br>TELASA、Paramount＋が  <br>加わった動画配信を楽しみたい方<br><br>J:COM TVシン・スタンダード  <br>![J:COM STREAM](https://www.jcom.co.jp/common_v10/images/logo_stream.webp)![+](https://www.jcom.co.jp/common_v10/images/icn-plus-line.svg)48ch以上<br><br>[![](https://www.jcom.co.jp/common_v10/images/icn-text-qst.svg)コースについて](https://www.jcom.co.jp/service/tv/#)<br><br>[](https://www.jcom.co.jp/service/tv/#)<br><br>J:COM TV シン・スタンダード<br><br>48の専門チャンネル見放題に加えて、TELASA、Paramount+が加わったJ:COM STREAMも楽しめるコースです。<br><br>動画配信サービス<br><br>![J:COM STREAM](https://www.jcom.co.jp/common_v10/images/logo_stream.webp)<br><br>別途有料作品あり<br><br>![TELASA](https://www.jcom.co.jp/service/tv/images_v10/logo/logo_TELASA.webp)<br><br>![Paramount+](https://www.jcom.co.jp/service/tv/images_v10/logo/logo_Paramount.webp)<br><br>話題の  <br>アニメ・ドラマ  <br>バラエティなど<br><br>[見たい作品を探す](https://linkvod.myjcom.jp/)<br><br>![](https://www.jcom.co.jp/common_v10/images/icn-plus-lg.svg)<br><br>テレビ<br><br>厳選48chの専門チャンネル<br><br>スポーツ・音楽ライブなどの生中継から、映画・ドラマ・アニメまで！<br><br>*   映画・ドラマ<br>    <br>*   スポーツ<br>    <br>*   エンタメ・  <br>    バラエティ<br>    <br>*   ドキュメンタリー  <br>    ・ホビー<br>    <br>*   アニメ・  <br>    キッズ<br>    <br>*   音楽<br>    <br>*   ニュース<br>    <br><br>[視聴可能なチャンネル](https://www.jcom.co.jp/service/tv/course/standard.html#anc-05)<br><br>[閉じる](https://www.jcom.co.jp/service/tv/#)<br><br>3カ月 月額 500 円※1 （税込）  <br>（割引終了後：税込4,950円）<br><br>さらに2万円キャッシュバック<br><br>[詳しく見る](https://www.jcom.co.jp/guide/starter/tv/) |
| J:COMの動画配信サービス・  <br>専門チャンネルとNetflixを  <br>楽しみたい方<br><br>J:COM Netflixセット  <br>シン・スタンダード![+](https://www.jcom.co.jp/common_v10/images/icn-plus-line.svg)![Netflix](https://www.jcom.co.jp/common_v10/images/logo-netflix.webp)<br><br>[![](https://www.jcom.co.jp/common_v10/images/icn-text-qst.svg)コースについて](https://www.jcom.co.jp/service/tv/#)<br><br>[](https://www.jcom.co.jp/service/tv/#)<br><br>J:COM TV シン・スタンダード＋J:COM Netflixセット<br><br>48の専門チャンネル見放題に加えて、TELASA、Paramount+が加わったJ:COM STREAMも楽しめるコースです。さらにJ:COM サービスとNetflixがセットで毎月ずーっと330円(税込)おトク！<br><br>動画配信サービス<br><br>![J:COM STREAM](https://www.jcom.co.jp/common_v10/images/logo_stream.webp)<br><br>別途有料作品あり<br><br>![TELASA](https://www.jcom.co.jp/service/tv/images_v10/logo/logo_TELASA.webp)<br><br>![Paramount+](https://www.jcom.co.jp/service/tv/images_v10/logo/logo_Paramount.webp)<br><br>話題の  <br>アニメ・ドラマ  <br>バラエティなど<br><br>[見たい作品を探す](https://linkvod.myjcom.jp/)<br><br>![](https://www.jcom.co.jp/common_v10/images/icn-plus-lg.svg)<br><br>テレビ<br><br>厳選48chの専門チャンネル<br><br>スポーツ・音楽ライブなどの生中継から、映画・ドラマ・アニメまで！<br><br>*   映画・ドラマ<br>    <br>*   スポーツ<br>    <br>*   エンタメ・  <br>    バラエティ<br>    <br>*   ドキュメンタリー  <br>    ・ホビー<br>    <br>*   アニメ・  <br>    キッズ<br>    <br>*   音楽<br>    <br>*   ニュース<br>    <br><br>[視聴可能なチャンネル](https://www.jcom.co.jp/service/tv/course/standard.html#anc-05)<br><br>![](https://www.jcom.co.jp/common_v10/images/icn-plus-lg.svg)<br><br>[![NETFLIX 夢中になれるシアワセを。 J:COM Netflixセット新登場 ずーっと330円/月割引](https://www.jcom.co.jp/service/tv/images_v10/topics_netflix.webp)](https://www.jcom.co.jp/guide/starter/netflix/)<br><br>[閉じる](https://www.jcom.co.jp/service/tv/#)<br><br>おすすめ<br><br>毎月ずーっと330円(税込)おトク！<br><br>3カ月 月額 1,060 円※1 （税込）  <br>（割引終了後：税込5,510円）<br><br>さらに2万円キャッシュバック<br><br>[詳しく見る](https://www.jcom.co.jp/guide/starter/netflix/) |
| 青春22割・26割  <br>26歳以下の方限定！<br><br>J:COMシンスタンダード  <br><br>![J:COM STREAM](https://www.jcom.co.jp/common_v10/images/logo_stream.webp) ![+](https://www.jcom.co.jp/common_v10/images/icn-plus-line.svg)<br><br>48ch以上<br><br>26歳以下<br><br>1年間 月額 2,640 円※2 （税込）<br><br>さらに1万円キャッシュバック<br><br>[22歳以下の方](https://www.jcom.co.jp/campaign/u26/)<br><br>[26歳以下の方](https://www.jcom.co.jp/campaign/u26/?ad=u26) |

*   WEB限定スタート割適用。2年契約、自動更新。途中解約は解除料要。
*   集合住宅限定。13カ月目以降3,740円～にて自動継続。2年間の長期契約が条件。

さらに詳しい料金はこちら

[![icon](https://www.jcom.co.jp/common_v10/images/icn-simulation.svg)料金シミュレーション](https://onlineshop.jcom.co.jp/Simulation/Simulation?sc_pid=common_pricetariff_under_simu)

お好みで組み合わせ！  
おすすめのネットサービス

[![J:COM 光 1ギガ 集合住宅の方 月額3カ月間0円 さらに1万円キャッシュバック ※集合住宅の場合。4カ月目以降5,258円/月～。](https://www.jcom.co.jp/service/tv/images_v10/bnr_hikari1.webp)](https://www.jcom.co.jp/guide/starter/shinlife/price/)

|     |
| --- |
| 厳選した専門チャンネルと  <br>TELASA、Paramount＋が  <br>加わった動画配信を楽しみたい方<br><br>J:COM TVシン・スタンダード ![J:COM STREAM](https://www.jcom.co.jp/common_v10/images/logo_stream.webp)![+](https://www.jcom.co.jp/common_v10/images/icn-plus-line.svg)48ch以上<br><br>[![](https://www.jcom.co.jp/common_v10/images/icn-text-qst.svg)コースについて](https://www.jcom.co.jp/service/tv/#)<br><br>[](https://www.jcom.co.jp/service/tv/#)<br><br>J:COM TV シン・スタンダード<br><br>48の専門チャンネル見放題に加えて、TELASA、Paramount+が加わったJ:COM STREAMも楽しめるコースです。<br><br>動画配信サービス<br><br>![J:COM STREAM](https://www.jcom.co.jp/common_v10/images/logo_stream.webp)<br><br>別途有料作品あり<br><br>![TELASA](https://www.jcom.co.jp/service/tv/images_v10/logo/logo_TELASA.webp)<br><br>![Paramount+](https://www.jcom.co.jp/service/tv/images_v10/logo/logo_Paramount.webp)<br><br>話題の  <br>アニメ・ドラマ  <br>バラエティなど<br><br>[見たい作品を探す](https://linkvod.myjcom.jp/)<br><br>![](https://www.jcom.co.jp/common_v10/images/icn-plus-lg.svg)<br><br>テレビ<br><br>厳選48chの専門チャンネル<br><br>スポーツ・音楽ライブなどの生中継から、映画・ドラマ・アニメまで！<br><br>*   映画・ドラマ<br>    <br>*   スポーツ<br>    <br>*   エンタメ・  <br>    バラエティ<br>    <br>*   ドキュメンタリー  <br>    ・ホビー<br>    <br>*   アニメ・  <br>    キッズ<br>    <br>*   音楽<br>    <br>*   ニュース<br>    <br><br>[視聴可能なチャンネル](https://www.jcom.co.jp/service/tv/course/standard.html#anc-05)<br><br>[閉じる](https://www.jcom.co.jp/service/tv/#)<br><br>3カ月 月額 500 円※ （税込）  <br>（割引終了後：税込4,950円）<br><br>さらに2万円キャッシュバック<br><br>[詳しく見る](https://www.jcom.co.jp/guide/starter/tv/) |
| J:COMの動画配信サービス・  <br>専門チャンネルとNetflixを  <br>楽しみたい方<br><br>J:COM Netflixセット  <br>シン・スタンダード![+](https://www.jcom.co.jp/common_v10/images/icn-plus-line.svg)![Netflix](https://www.jcom.co.jp/common_v10/images/logo-netflix.webp)<br><br>[![](https://www.jcom.co.jp/common_v10/images/icn-text-qst.svg)コースについて](https://www.jcom.co.jp/service/tv/#)<br><br>[](https://www.jcom.co.jp/service/tv/#)<br><br>J:COM TV シン・スタンダード＋J:COM Netflixセット<br><br>48の専門チャンネル見放題に加えて、TELASA、Paramount+が加わったJ:COM STREAMも楽しめるコースです。さらにJ:COM サービスとNetflixがセットで毎月ずーっと330円(税込)おトク！<br><br>動画配信サービス<br><br>![J:COM STREAM](https://www.jcom.co.jp/common_v10/images/logo_stream.webp)<br><br>別途有料作品あり<br><br>![TELASA](https://www.jcom.co.jp/service/tv/images_v10/logo/logo_TELASA.webp)<br><br>![Paramount+](https://www.jcom.co.jp/service/tv/images_v10/logo/logo_Paramount.webp)<br><br>話題の  <br>アニメ・ドラマ  <br>バラエティなど<br><br>[見たい作品を探す](https://linkvod.myjcom.jp/)<br><br>![](https://www.jcom.co.jp/common_v10/images/icn-plus-lg.svg)<br><br>テレビ<br><br>厳選48chの専門チャンネル<br><br>スポーツ・音楽ライブなどの生中継から、映画・ドラマ・アニメまで！<br><br>*   映画・ドラマ<br>    <br>*   スポーツ<br>    <br>*   エンタメ・  <br>    バラエティ<br>    <br>*   ドキュメンタリー  <br>    ・ホビー<br>    <br>*   アニメ・  <br>    キッズ<br>    <br>*   音楽<br>    <br>*   ニュース<br>    <br><br>[視聴可能なチャンネル](https://www.jcom.co.jp/service/tv/course/standard.html#anc-05)<br><br>![](https://www.jcom.co.jp/common_v10/images/icn-plus-lg.svg)<br><br>[![NETFLIX 夢中になれるシアワセを。 J:COM Netflixセット新登場 ずーっと330円/月割引](https://www.jcom.co.jp/service/tv/images_v10/topics_netflix.webp)](https://www.jcom.co.jp/guide/starter/netflix/)<br><br>[閉じる](https://www.jcom.co.jp/service/tv/#)<br><br>おすすめ<br><br>毎月ずーっと330円(税込)おトク！<br><br>3カ月 月額 1,060 円※ （税込）  <br>（割引終了後：税込5,510円）<br><br>さらに2万円キャッシュバック<br><br>[詳しく見る](https://www.jcom.co.jp/guide/starter/netflix/) |

WEB限定スタート割適用。2年契約、自動更新。途中解約は解除料要。

さらに詳しい料金はこちら

[![icon](https://www.jcom.co.jp/common_v10/images/icn-simulation.svg)料金シミュレーション](https://onlineshop.jcom.co.jp/Simulation/Simulation?sc_pid=common_pricetariff_under_simu)

お好みで組み合わせ！  
おすすめのネットサービス

[![Wi-Fi 7対応　J:COM 光 10ギガ 一戸建ての方 実質月額6カ月間0円　※一戸建ての場合。7カ月目以降6,160円/月～、未提供エリア有。](https://www.jcom.co.jp/service/tv/images_v10/bnr_hikari10.webp)](https://www.jcom.co.jp/guide/starter/shinlife/price/?ad=sdu01)

### TVコース 月額利用料金（2年契約）

*   集合住宅の方
*   戸建住宅の方

|     |     |
| --- | --- | 
| J:COM TV シン・スタンダード | 月額4,950円（税込） |
| J:COM TV シン・スタンダードプラス | 月額6,050円（税込） |
| J:COM TV セレクト | 月額2,200円（税込） |

*   標準契約の場合、月額料金は下記の通り。
    *   J:COM TV シン・スタンダード…月額6,050円（税込）
    *   J:COM TV シン・スタンダードプラス…月額7,150円（税込）
    *   J:COM TV セレクトは、2年契約のみの提供。

J:COM TV(2年契約)　契約条件

1.  2年間の長期契約(自動更新)。
2.  前記条件を満たさなくなった場合には、「シン・スタンダードプラス」「シン・スタンダード」「フレックス」4,500円（4,950円（税込））/「セレクト」＜一戸建て＞2,700円（2,970円（税込））、＜集合住宅＞2,000円（2,200円（税込））の契約解除料金が必要。
3.  1契約ごとにTV1台のみ。

閉じる

|     |     |
| --- | --- | 
| J:COM TV シン・スタンダード | 月額4,950円（税込） |
| J:COM TV シン・スタンダードプラス | 月額6,050円（税込） |
| J:COM TV セレクト | 月額2,970円（税込） |

*   標準契約の場合、月額料金は下記の通り。
    *   J:COM TV シン・スタンダード…月額6,050円（税込）
    *   J:COM TV シン・スタンダードプラス…月額7,150円（税込）
    *   J:COM TV セレクトは、2年契約のみの提供。

J:COM TV(2年契約)　契約条件

1.  2年間の長期契約(自動更新)。
2.  前記条件を満たさなくなった場合には、「シン・スタンダードプラス」「シン・スタンダード」「フレックス」4,500円（4,950円（税込））/「セレクト」＜一戸建て＞2,700円（2,970円（税込））、＜集合住宅＞2,000円（2,200円（税込））の契約解除料金が必要。
3.  1契約ごとにTV1台のみ。

閉じる

J:COM TV  
おすすめの理由
------------------

![POINT01](https://www.jcom.co.jp/service/tv/images_v10/decoration/text-rec-point01.webp)

圧倒的な番組数、ライブ配信も

充実の  
スポーツコンテンツ

[スポーツコンテンツを詳しく見る](https://www2.myjcom.jp/special/sports/)

![POINT02](https://www.jcom.co.jp/service/tv/images_v10/decoration/text-rec-point02.webp)

映画・アニメ・ライブや  
時代劇も

専門チャンネルと  
動画配信を  
両方楽しめる

[多彩なコンテンツはこちら](https://www.jcom.co.jp/service/tv/channel/)

![POINT03](https://www.jcom.co.jp/service/tv/images_v10/decoration/text-rec-point03.webp)

好みの作品と出会える！

あなた好みの  
番組や  
録画を  
レコメンド

![POINT04](https://www.jcom.co.jp/service/tv/images_v10/decoration/text-rec-point04.webp)

テレビの大画面でも、  
スマホでも

いつでもどこでも  
楽しめる！

[便利な機能を詳しく見る](https://www.jcom.co.jp/service/tv/smart/)

[新規ご加入の方  \
お申し込み](https://onlineshop.jcom.co.jp/planSelect)

[ご利用中の方  \
各種お手続き](https://r.jcom.jp/ev3z3wr)

あなたにピッタリのプランがすぐわかる

[料金シミュ  \
レーション](https://onlineshop.jcom.co.jp/Simulation/Simulation)

[お申し込み](https://onlineshop.jcom.co.jp/planSelect?sc_pid=common_middle_entry_02)

[契約内容  \
確認・変更  \
日本語のみ](https://www2.myjcom.jp/join/?ac_id=btm_change&sc_pid=common_middle_join_02)

あなたにピッタリのプランがすぐわかる

[料金シミュ  \
レーション](https://onlineshop.jcom.co.jp/Simulation/Simulation?sc_pid=common_middle_simu_02)

[](https://www.jcom.co.jp/service/tv/#)

新規ご加入の方　  
お問い合わせ

[Webでお問い合わせ](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

J:COMよりメールまたはお電話で回答いたします。

お電話でのお問い合わせ(通話無料)はこちら

[0120-989-970](tel:0120-989-970)

9:00～18:00［年中無休］

[閉じる](https://www.jcom.co.jp/service/tv/#)

[](https://www.jcom.co.jp/service/tv/#)

新規ご加入の方　  
お問い合わせ

[Webでお問い合わせ](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

J:COMよりメールまたはお電話で回答いたします。

お電話でのお問い合わせ(通話無料)はこちら

[0120-989-970](tel:0120-989-970)

9:00～18:00［年中無休］

[閉じる](https://www.jcom.co.jp/service/tv/#)

[](https://www.jcom.co.jp/service/tv/#)

新規ご加入の方　  
お問い合わせ

[Webでお問い合わせ](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

J:COMよりメールまたはお電話で回答いたします。

お電話でのお問い合わせ(通話無料)はこちら

[0120-989-970](tel:0120-989-970)

9:00～18:00［年中無休］

[閉じる](https://www.jcom.co.jp/service/tv/#)

[](https://www.jcom.co.jp/service/tv/#)

ご利用中の方　  
お問い合わせ

ご契約内容の確認・変更  
はこちらから

[マイページログイン](https://mypage.jcom.co.jp/)

* * *

お困り事解決・よくあるご質問  
はこちらから

[お客さまサポート](https://cs.myjcom.jp/)

* * *

サービス・オプションの追加や変更  
はこちらから

[サービスの追加・変更](https://www2.myjcom.jp/join/)

[閉じる](https://www.jcom.co.jp/service/tv/#)

[](https://www.jcom.co.jp/service/tv/#)

ご利用中の方　  
お問い合わせ

ご契約内容の確認・変更  
はこちらから

[マイページログイン](https://mypage.jcom.co.jp/)

* * *

お困り事解決・よくあるご質問  
はこちらから

[お客さまサポート](https://cs.myjcom.jp/)

* * *

サービス・オプションの追加や変更  
はこちらから

[サービスの追加・変更](https://www2.myjcom.jp/join/)

[閉じる](https://www.jcom.co.jp/service/tv/#)

[](https://www.jcom.co.jp/service/tv/#)

ご利用中の方　  
お問い合わせ

ご契約内容の確認・変更  
はこちらから

[マイページログイン](https://mypage.jcom.co.jp/)

* * *

お困り事解決・よくあるご質問  
はこちらから

[お客さまサポート](https://cs.myjcom.jp/)

* * *

サービス・オプションの追加や変更  
はこちらから

[サービスの追加・変更](https://www2.myjcom.jp/join/)

[閉じる](https://www.jcom.co.jp/service/tv/#)

[](https://www.jcom.co.jp/service/tv/#)

ご利用中の方　  
お申し込み

J:COM TVをご利用でない方

[J:COM TV  \
シン・スタンダードプラスの  \
お申し込み](https://r.jcom.jp/24KC2mS)

既にJ:COM TVをご利用中の方

[J:COM TV  \
シン・スタンダードプラスへ  \
コース変更](https://r.jcom.jp/0JLPOoy)

[閉じる](https://www.jcom.co.jp/service/tv/#)

[](https://www.jcom.co.jp/service/tv/#)

ご利用中の方　  
お申し込み

J:COM TVをご利用でない方

[J:COM TV  \
シン・スタンダードプラスの  \
お申し込み](https://r.jcom.jp/24KC2mS)

既にJ:COM TVをご利用中の方

[J:COM TV  \
シン・スタンダードプラスへ  \
コース変更](https://r.jcom.jp/0JLPOoy)

[閉じる](https://www.jcom.co.jp/service/tv/#)

[](https://www.jcom.co.jp/service/tv/#)

ご利用中の方　  
お申し込み

J:COM TVをご利用でない方

[J:COM TV  \
シン・スタンダードプラスの  \
お申し込み](https://r.jcom.jp/24KC2mS)

既にJ:COM TVをご利用中の方

[J:COM TV  \
シン・スタンダードプラスへ  \
コース変更](https://r.jcom.jp/0JLPOoy)

[閉じる](https://www.jcom.co.jp/service/tv/#)

[](https://www.jcom.co.jp/service/tv/#)

工事日の確認・変更について

訪問工事の日程確認・変更・キャンセルは、マイページで行うことができます。

[マイページログイン](https://mypage.jcom.co.jp/)

[マイページのご確認手順はこちら](https://cs.myjcom.jp/articles/support/6790bf45ad2e841b2e3362cf)

J:COM NET 光 (N)の工事日はマイページでは変更いただけません。[カスタマーセンター](https://www.jcom.co.jp/contactus/call_rgu.html#phone)
にお問い合わせください。

[閉じる](https://www.jcom.co.jp/service/tv/#)

[](https://www.jcom.co.jp/service/tv/#)

New Customers　  
Applications and Inquiries

[Applications and Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[0120-989-970](tel:0120-989-970)

Business hours : 9:00-18:00  
\[open all year round\]

[閉じる](https://www.jcom.co.jp/service/tv/#)

[](https://www.jcom.co.jp/service/tv/#)

New Customers　  
Applications and Inquiries

[Applications and Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[0120-989-970](tel:0120-989-970)

Business hours : 9:00-18:00  
\[open all year round\]

[閉じる](https://www.jcom.co.jp/service/tv/#)

[](https://www.jcom.co.jp/service/tv/#)

New Customers　  
Applications and Inquiries

[Applications and Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[0120-989-970](tel:0120-989-970)

Business hours : 9:00-18:00  
\[open all year round\]

[閉じる](https://www.jcom.co.jp/service/tv/#)

[](https://www.jcom.co.jp/service/tv/#)

Current Customers　  
Inquiries

[Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[0120-989-970](tel:0120-989-970)

Business hours : 9:00-18:00  
\[open all year round\]

[閉じる](https://www.jcom.co.jp/service/tv/#)

[](https://www.jcom.co.jp/service/tv/#)

Current Customers　  
Inquiries

[Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[0120-989-970](tel:0120-989-970)

Business hours : 9:00-18:00  
\[open all year round\]

[閉じる](https://www.jcom.co.jp/service/tv/#)

[](https://www.jcom.co.jp/service/tv/#)

Current Customers　  
Inquiries

[Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[0120-989-970](tel:0120-989-970)

Business hours : 9:00-18:00  
\[open all year round\]

[閉じる](https://www.jcom.co.jp/service/tv/#)

[](https://www.jcom.co.jp/service/tv/#)

新用户　  
申请・咨询

신규가입 고객　  
신청·문의

Đối với khách hàng mới tham gia　  
Ứng dụng / Yêu cầu

Novos assinantes　  
Solicitação/Consultas

电话咨询（有翻译）

전화 상담(통역 있음)

Tư vấn qua điện thoại (có phiên dịch)

Consulta por telefone (com intérprete)

[050-1722-1733](tel:050-1722-1733)

9:00-18:00 ［年中無休］

[日本語での通話はこちら](https://www.jcom.co.jp/service/tv/#)

[申请・咨询](https://www.jcom.co.jp/zh-CHS/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[신청·문의](https://www.jcom.co.jp/ko/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Ứng dụng / Yêu cầu](https://www.jcom.co.jp/vi/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Solicitação/Consultas](https://www.jcom.co.jp/pt/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[閉じる](https://www.jcom.co.jp/service/tv/#)

[](https://www.jcom.co.jp/service/tv/#)

新用户　  
申请・咨询

신규가입 고객　  
신청·문의

Đối với khách hàng mới tham gia　  
Ứng dụng / Yêu cầu

Novos assinantes　  
Solicitação/Consultas

电话咨询（有翻译）

전화 상담(통역 있음)

Tư vấn qua điện thoại (có phiên dịch)

Consulta por telefone (com intérprete)

[050-1722-1733](tel:050-1722-1733)

9:00-18:00 ［年中無休］

[日本語での通話はこちら](https://www.jcom.co.jp/service/tv/#)

[申请・咨询](https://www.jcom.co.jp/zh-CHS/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[신청·문의](https://www.jcom.co.jp/ko/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Ứng dụng / Yêu cầu](https://www.jcom.co.jp/vi/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Solicitação/Consultas](https://www.jcom.co.jp/pt/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[閉じる](https://www.jcom.co.jp/service/tv/#)

[](https://www.jcom.co.jp/service/tv/#)

新用户　  
申请・咨询

신규가입 고객　  
신청·문의

Đối với khách hàng mới tham gia　  
Ứng dụng / Yêu cầu

Novos assinantes　  
Solicitação/Consultas

电话咨询（有翻译）

전화 상담(통역 있음)

Tư vấn qua điện thoại (có phiên dịch)

Consulta por telefone (com intérprete)

[050-1722-1733](tel:050-1722-1733)

9:00-18:00 ［年中無休］

[日本語での通話はこちら](https://www.jcom.co.jp/service/tv/#)

[申请・咨询](https://www.jcom.co.jp/zh-CHS/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[신청·문의](https://www.jcom.co.jp/ko/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Ứng dụng / Yêu cầu](https://www.jcom.co.jp/vi/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Solicitação/Consultas](https://www.jcom.co.jp/pt/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[閉じる](https://www.jcom.co.jp/service/tv/#)

[](https://www.jcom.co.jp/service/tv/#)

会员　  
联系我们

이용 중인 고객　  
문의

Khách hàng đang sử dụng　  
Hỏi đáp

Utilizadores　  
Consultar

电话咨询（有翻译）

전화 상담(통역 있음)

Tư vấn qua điện thoại (có phiên dịch)

Consulta por telefone (com intérprete)

[050-1722-1733](tel:050-1722-1733)

9:00-18:00 ［年中無休］

[日本語での通話はこちら](https://www.jcom.co.jp/service/tv/#)

[联系我们](https://www.jcom.co.jp/zh-CHS/sim_contact/entry_request.php?form_type=eng_inquires)

[문의](https://www.jcom.co.jp/ko/sim_contact/entry_request.php?form_type=eng_inquires)

[Hỏi đáp](https://www.jcom.co.jp/vi/sim_contact/entry_request.php?form_type=eng_inquires)

[Consultar](https://www.jcom.co.jp/pt/sim_contact/entry_request.php?form_type=eng_inquires)

[閉じる](https://www.jcom.co.jp/service/tv/#)

[](https://www.jcom.co.jp/service/tv/#)

会员　  
联系我们

이용 중인 고객　  
문의

Khách hàng đang sử dụng　  
Hỏi đáp

Utilizadores　  
Consultar

电话咨询（有翻译）

전화 상담(통역 있음)

Tư vấn qua điện thoại (có phiên dịch)

Consulta por telefone (com intérprete)

[050-1722-1733](tel:050-1722-1733)

9:00-18:00 ［年中無休］

[日本語での通話はこちら](https://www.jcom.co.jp/service/tv/#)

[联系我们](https://www.jcom.co.jp/zh-CHS/sim_contact/entry_request.php?form_type=eng_inquires)

[문의](https://www.jcom.co.jp/ko/sim_contact/entry_request.php?form_type=eng_inquires)

[Hỏi đáp](https://www.jcom.co.jp/vi/sim_contact/entry_request.php?form_type=eng_inquires)

[Consultar](https://www.jcom.co.jp/pt/sim_contact/entry_request.php?form_type=eng_inquires)

[閉じる](https://www.jcom.co.jp/service/tv/#)

[](https://www.jcom.co.jp/service/tv/#)

会员　  
联系我们

이용 중인 고객　  
문의

Khách hàng đang sử dụng　  
Hỏi đáp

Utilizadores　  
Consultar

电话咨询（有翻译）

전화 상담(통역 있음)

Tư vấn qua điện thoại (có phiên dịch)

Consulta por telefone (com intérprete)

[050-1722-1733](tel:050-1722-1733)

9:00-18:00 ［年中無休］

[日本語での通話はこちら](https://www.jcom.co.jp/service/tv/#)

[联系我们](https://www.jcom.co.jp/zh-CHS/sim_contact/entry_request.php?form_type=eng_inquires)

[문의](https://www.jcom.co.jp/ko/sim_contact/entry_request.php?form_type=eng_inquires)

[Hỏi đáp](https://www.jcom.co.jp/vi/sim_contact/entry_request.php?form_type=eng_inquires)

[Consultar](https://www.jcom.co.jp/pt/sim_contact/entry_request.php?form_type=eng_inquires)

[閉じる](https://www.jcom.co.jp/service/tv/#)

[](https://www.jcom.co.jp/service/tv/#)

日本語でのお問い合わせ

[海外にお住まいの方](https://cs.myjcom.jp/knowledgeDetail?an=004897372)

[日本国内にお住まいの方](https://www.jcom.co.jp/contactus/call_rgu.html)

[閉じる](https://www.jcom.co.jp/service/tv/#)

[](https://www.jcom.co.jp/service/tv/#)

日本語でのお問い合わせ

[海外にお住まいの方](https://cs.myjcom.jp/knowledgeDetail?an=004897372)

[日本国内にお住まいの方](https://www.jcom.co.jp/contactus/call_rgu.html)

[閉じる](https://www.jcom.co.jp/service/tv/#)

新しい視聴スタイルを実現する  
各種オプション
------------------------

[![外付けハードディスク](https://www.jcom.co.jp/service/tv/images_v10/common/option-img-hd.webp)\
\
外付けハードディスク\
\
番組録画のマストアイテム　  \
番組視聴中でも2番組同時録画](https://www.jcom.co.jp/service/tv/accessories/hdd/)
[![J:COM LINK mini](https://www.jcom.co.jp/service/tv/images_v10/common/option-img-linkmini.webp)\
\
J:COM LINK mini\
\
2台目のテレビでも専門チャンネル・録画番組・ネット動画が楽しめる](https://www.jcom.co.jp/service/tv/accessories/linkmini/)

[オプション・周辺機器を見る](https://www.jcom.co.jp/service/tv/accessories/)

セットでおすすめ・  
人気サービス
------------------

 [![](https://www.jcom.co.jp/images_v10/img-service-net.webp)\
\
![](https://www.jcom.co.jp/common_v10/images/icn-jcom-net.svg) ネット\
\
もっと速く、もっと快適に](https://www.jcom.co.jp/service/net/?sc_pid=common_service_net)
 [![](https://www.jcom.co.jp/images_v10/img-service-mobile.webp)\
\
![](https://www.jcom.co.jp/common_v10/images/icn-jcom-mobile.svg) スマホ\
\
セットなら、  \
スマホのデータず～っと増量！](https://www.jcom.co.jp/service/mobile/?sc_pid=common_service_mobile_02)
 [![](https://www.jcom.co.jp/images_v10/img-service-electricity.webp)\
\
![](https://www.jcom.co.jp/common_v10/images/icn-jcom-electricity.svg) でんき\
\
品質そのまままとめて便利](https://www.jcom.co.jp/service/electricity/?sc_pid=common_service_ele)

キャンペーン・特典
---------

[![録画用ハードディスク(J:COM LINK 専用)3ヵ月割引](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_hdd_155_90.webp)](https://www.jcom.co.jp/campaign/hdd/)

[![WEB限定スタート割](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_start.webp)](https://www.jcom.co.jp/campaign/start_jcom/)

[![青春22割・青春26割](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_u26.webp)](https://www.jcom.co.jp/campaign/u26/)

[![基本工事費実質0円](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_kojihi.webp)](https://www.jcom.co.jp/campaign/kojihi/)

[![auスマートバリュー](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_newreduce.webp)](https://www.jcom.co.jp/price/au/)

[![J:COM金利優遇割](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_au_loan.webp)](https://www.jcom.co.jp/price/au_loan/)

[![録画用ハードディスク(J:COM LINK 専用)3ヵ月割引](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_hdd_155_90.webp)](https://www.jcom.co.jp/campaign/hdd/)

[![WEB限定スタート割](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_start.webp)](https://www.jcom.co.jp/campaign/start_jcom/)

[![青春22割・青春26割](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_u26.webp)](https://www.jcom.co.jp/campaign/u26/)

[![基本工事費実質0円](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_kojihi.webp)](https://www.jcom.co.jp/campaign/kojihi/)

[![auスマートバリュー](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_newreduce.webp)](https://www.jcom.co.jp/price/au/)

[![J:COM金利優遇割](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_au_loan.webp)](https://www.jcom.co.jp/price/au_loan/)

[![録画用ハードディスク(J:COM LINK 専用)3ヵ月割引](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_hdd_155_90.webp)](https://www.jcom.co.jp/campaign/hdd/)

[![WEB限定スタート割](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_start.webp)](https://www.jcom.co.jp/campaign/start_jcom/)

[![青春22割・青春26割](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_u26.webp)](https://www.jcom.co.jp/campaign/u26/)

[![基本工事費実質0円](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_kojihi.webp)](https://www.jcom.co.jp/campaign/kojihi/)

[![auスマートバリュー](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_newreduce.webp)](https://www.jcom.co.jp/price/au/)

[![J:COM金利優遇割](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_au_loan.webp)](https://www.jcom.co.jp/price/au_loan/)

[キャンペーン・特典](https://www.jcom.co.jp/campaign/)

お客さまの声
------

### 世代を超えて  
楽しく鑑賞しています

時代劇が大好きな祖父が、J:COMの番組を楽しみにして我が家に遊びに来ます。娘のお世話も任せることができ、助かります。娘も時代劇が大好きになり、世代を越えて楽しく鑑賞しています。

30代／女性

### 音声操作が便利な  
J:COM LINK

J:COM LINKにして、テレビを満喫しています。音声で操作できたり、録画したものをダウンロードして外に持っていけたりするのでとても便利に活用してます。

50代／女性

### 外出先でも試合の  
一球一打を見逃さない

私のお気に入りはJ:COMで放送されるプロ野球です。スマホに入れて外出先でも、気になる試合が瞬時に見られます。これまで所用で外出先で見られなかったのが、リアルタイムで見られるようになったのがすごく良いです。

50代／男性

### オンデマンドの  
配信が充実

J:COM TVは映画、ドラマだけでなくスポーツ放送も充実しています。また、オンデマンドで映画やドラマを繰り返し楽しめるのが良いです。全豪オープンテニスは、オンデマンドの配信も充実していて本当に楽しめました。

40代／男性

### ネット動画も専門チャンネルも  
楽しめる

テレビでYouTubeやNetflixが見られるし、音楽チャンネルも見られる。 auとのパック割引もあり、いい所がたくさんあってとても好きです。

50代／女性

### オプションチャンネルの  
契約がかんたん

専門チャンネルが豊富なところとオプションチャンネルの追加・解約がかんたんにできるところが良いです。見たいスポーツ番組がある間はJsports4を契約し、オフシーズンは契約解除するなど柔軟に利用しています。

40代／女性

  [![お客さまの声公開中](https://www.jcom.co.jp/service/tv/images_v10/img_voice.webp)](https://www.jcom.co.jp/service/voice/)

新規ご加入・サービス追加をご検討中の方

### お申し込みのご案内

新規ご加入の方

[新規ご加入の方  \
お申し込み](https://onlineshop.jcom.co.jp/planSelect)

[新規ご加入の方  \
お問い合わせ](https://www.jcom.co.jp/service/tv/#)

ご利用中の方

[ご利用中の方  \
各種お手続き](https://r.jcom.jp/ev3z3wr)

[お困りごと・  \
お問い合わせ  \
（チャット）](https://prod8-live-chat.sprinklr.com/page?appId=67af27d73657336d345e4a96_app_9070639&did=CHAT_vivr_cojp_tv&enableClose=true&skin=MODERN&userContext__c_679c8b53cb85b007fab0f6ea=DirectLink&utm_campaign=IVRSMS&utm_medium=referral&utm_source=did&webview=true&zoom=false)

あなたにピッタリの  
プランがすぐわかる

[料金シミュ  \
レーション](https://onlineshop.jcom.co.jp/Simulation/Simulation)

無料・特別料金の物件も！

対応エリア・  
物件をご案内

新規ご加入・サービス追加をご検討中の方

### お申し込みのご案内

新規ご加入の方

[お申し込み](https://onlineshop.jcom.co.jp/planSelect?sc_pid=common_bottom_entry_02)

[![](https://www.jcom.co.jp/common_v10/images/icn-think-black.svg)Applications and Inquiries](https://www.jcom.co.jp/service/tv/#)

[![](https://www.jcom.co.jp/common_v10/images/icn-think-black.svg)申请・咨询](https://www.jcom.co.jp/zh-CHS/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[电话咨询  \
050-1722-1733](tel:050-1722-1733)
 9:00-18:00【全年无休】／有翻译 [日本語での通話は  \
こちら](https://www.jcom.co.jp/service/tv/#)

[![](https://www.jcom.co.jp/common_v10/images/icn-think-black.svg)신청·문의](https://www.jcom.co.jp/ko/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[신청·문의  \
050-1722-1733](tel:050-1722-1733)
 9:00-18:00【연중무휴】／통역 있음 [日本語での通話は  \
こちら](https://www.jcom.co.jp/service/tv/#)

[![](https://www.jcom.co.jp/common_v10/images/icn-think-black.svg)Ứng dụng / Yêu cầu](https://www.jcom.co.jp/vi/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Ứng dụng / Yêu cầu  \
050-1722-1733](tel:050-1722-1733)
 9:00-18:00【mở cửa quanh năm】／có phiên dịch [日本語での通話は  \
こちら](https://www.jcom.co.jp/service/tv/#)

[![](https://www.jcom.co.jp/common_v10/images/icn-think-black.svg)Solicitação/Consultas](https://www.jcom.co.jp/pt/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Solicitação/Consultas  \
050-1722-1733](tel:050-1722-1733)
 9:00-18:00【aberto todo o ano】／com intérprete [日本語での通話は  \
こちら](https://www.jcom.co.jp/service/tv/#)

ご利用中の方

[契約内容  \
確認・変更  \
日本語のみ](https://www2.myjcom.jp/join/?ac_id=btm_change&sc_pid=common_bottom_join_02)

[![](https://www.jcom.co.jp/common_v10/images/icn-member.svg)Inquiries](https://www.jcom.co.jp/service/tv/#)

[![](https://www.jcom.co.jp/common_v10/images/icn-member.svg)联系我们](https://www.jcom.co.jp/service/tv/#)

[![](https://www.jcom.co.jp/common_v10/images/icn-member.svg)문의](https://www.jcom.co.jp/service/tv/#)

[![](https://www.jcom.co.jp/common_v10/images/icn-member.svg)Hỏi đáp](https://www.jcom.co.jp/service/tv/#)

[![](https://www.jcom.co.jp/common_v10/images/icn-member.svg)Consultar](https://www.jcom.co.jp/service/tv/#)

あなたにピッタリの  
プランがすぐわかる

[料金シミュ  \
レーション](https://onlineshop.jcom.co.jp/Simulation/Simulation?sc_pid=common_bottom_simu_02)

無料・特別料金の物件も！

対応エリア・  
物件をご案内

[](https://www.jcom.co.jp/service/tv/#)

新規ご加入の方　  
お問い合わせ

[Webでお問い合わせ](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

J:COMよりメールまたはお電話で回答いたします。

お電話でのお問い合わせ(通話無料)はこちら

[0120-989-970](tel:0120-989-970)

9:00～18:00［年中無休］

[閉じる](https://www.jcom.co.jp/service/tv/#)

よくあるご質問
-------

どんな番組が見られますか？

J:COM TVは選べる3つのコースをご用意。厳選した専門チャンネルとTELASA、Paramount+が加わったJ:COMの動画配信が楽しめる「J:COM TV シン・スタンダード」。シン・スタンダードに専門チャンネルが21ch追加された充実のコース「J:COM TV シン・スタンダードプラス」、見たいジャンルを8パックから1つ選んで楽しめる「J:COM TV セレクト」と、お客さまのご利用に合わせたコースを用意しています。

![](https://www.jcom.co.jp/service/tv/images_v10/img_ondemand.webp)

トップ画面イメージ

地上デジタル放送のみを視聴したいのですが、どのようなコースがありますか？

地上デジタル放送のみのコースはございません。J:COM TVではすべてのコースで地上デジタル・BS放送と、専門チャンネル（CS放送）をご視聴いただけます。ご契約のコースにより視聴可能な専門チャンネル数は異なります。

テレビ番組を視聴するにはどうしたらいいですか？

J:COM機器でのテレビ視聴方法について、詳しくは下記リンク先をご覧ください。

[テレビの視聴方法](https://cs.myjcom.jp/knowledgeDetail?an=002316791)

地デジ・BSデジサービス(N)をご利用の方で、テレビが映らない場合は[こちら](https://cs.myjcom.jp/knowledgeDetail?an=004645969)

複数台のテレビで視聴できますか？

J:COM TVを新規でご契約される場合、またはJ:COM TV以外のサービスをご利用中の方がJ:COM TVを追加でご契約される場合、家じゅうのテレビに地デジ・BSデジ専用セットトップボックス（Smart J:COM Box）を最大3台まで無料でお付けいたします。

*   無料追加のTVチューナ機器ではCS放送はご視聴いただけません。
*   CS放送も複数台のテレビでご視聴いただきたい場合は、チャットまたはお電話にてご相談ください。

番組の録画はできますか？

J:COMが設置するTVチューナ機器を通して番組の録画が可能です。外付けHDDや、外部レコーダ機器と接続いただくことで、最大2番組の録画が可能となっております。

TVアンテナは必要ですか？

J:COM TVサービスをご利用いただくにあたり、TVアンテナの設置は不要です。  
J:COMにて放送を一括受信し、ケーブル回線で直接各ご家庭へお届けしています。ケーブル回線を宅内に引き込むことで、アンテナを設置することなく、地上波・衛星放送（BS・CS）の番組を視聴することができます。  
J:COMでは4K放送（BS・CS）も、ケーブル1本でお楽しみいただけます。

4K放送をご覧になるには指定のチューナーのご利用と、HDMI2.0/HDCP2.2の規格に対応した4K対応テレビが必要です。

オプションチャンネルを申し込むにはどうしたらいいですか？（加入・変更・解約）

J:COM TVのオプションチャンネルの申込・解約はマイページからお手続きができます。  
詳しくは以下リンク先にてご案内しております。

[オプションチャンネルの申込・解約について](https://cs.myjcom.jp/knowledgeDetail?an=002406091&sc_pid=olsfaq-entry-opch_support)

地デジ・BSデジサービス(N)では、オプションチャンネルをご利用いただけません。

テレビ放送以外の動画視聴サービスはありますか？

J:COMではテレビ放送以外にも、4つの動画配信サービスをテレビの大画面でお楽しみいただけます。

*   映画・ドラマ・アニメ・バラエティ等、幅広いジャンルの作品が定額で見放題が可能な動画配信サービス「J:COM STREAM(見放題)」
*   世界最大級のオンラインストリーミングサービス「Netflix」※
*   ディズニー、ピクサー、マーベル、スター・ウォーズ、ナショナル ジオグラフィック、スターの名作・話題作や、オリジナル作品が見放題で楽しめる「ディズニープラス」※
*   国内外のさまざまなスポーツ映像が、ライブ中継や見逃し配信で視聴できるサービス「DAZN」※

*   別途有料サービスとなります（ご登録が必要です）。

初期設定はしてもらえますか？

導入時の設置工事の際に、ご利用のテレビとの接続、リモコン設定や録画設定、ネット動画の動作確認はもちろん、使用方法についてもご案内しております。

加入後のサポート内容について知りたい

お電話やチャットでのお問合せから、サポート情報が掲載されたホームページでのご案内など、幅広いお問合せ方法をご用意しております。また、えんかくサポート（月額 550円(税込)）にご加入いただくことで、オペレータによる遠隔操作での対応もご用意しております。

[えんかくサポート について](https://www.jcom.co.jp/service/omakase/)

青春22割や青春26割は利用者が対象年齢であれば適用されますか？

ご利用者さまではなくご契約者さまの年齢が対象年齢であることが条件となります。例えば、既にJ:COMをご利用中で、青春22割をお申し込みされる場合は、ご契約者さまの年齢が22歳以下である必要がございます。

トピックス
-----

*   2023.10.04
    
    厳選した専門チャンネルとParamount +が加わった動画配信を楽しめるJ:COM TV シン・スタンダード登場！[詳しくはこちら](https://www.jcom.co.jp/guide/starter/tv/)
    

【注釈・注意事項】

*   チャンネル数はご提供する専用チューナー経由でご覧いただける、地上デジタル放送とBSデジタル放送を含みます。

【J:COM LINKについて】

*   ご利用には、J:COMが指定するサービスへのご加入が必要です。
*   ご契約プラン・ご利用環境により、提供できない場合があります。
*   双方向サービス対応物件でご利用可能です。
*   接続可能な外付けハードディスクは、6TB以下までのものに限ります。

【スマホ・タブレット向けJ:COM LINK専用アプリ】

*   各アプリのご利用には、インターネット接続環境、指定アプリのダウンロード、およびJ:COM LINK本体の事前設定が必要。
*   契約プランまたは接続端末・接続環境等により、利用できない場合あり。
*   4K放送・作品の視聴・購入不可。
*   利用環境や視聴方法によって、同時接続可能な端末台数が異なる。
*   日本国内でのご利用に限る。
*   一部、アプリ経由での宅外視聴に未対応の放送・作品あり。

【「J:COM STREAM」アプリ】

*   ご利用には、インターネット接続環境およびJ:COMパーソナルIDが必要。
*   日本国内でのご利用に限る。
*   録画不可。
*   同じ作品・番組は複数端末で同時視聴不可。異なる作品・番組の場合、複数端末での同時視聴には制限あり。
*   視聴可能な「ライブ配信」は一部に限る。
*   アプリを使用の場合、作品購入は不可（視聴は可能）。
*   契約プランおよび作品により「J:COM STREAM」アプリに未対応となる場合や、視聴可能端末が制限される場合あり。
*   4K作品は購入・視聴不可。
*   ダウンロードした作品の視聴期間は、原則48時間。

【TELASA】

*   ライブ配信および一部作品を除くTELASA見放題プランの作品が対象。
*   配信日が一部異なる場合あり。
*   特典の映画館クーポンおよびPontaポイント還元の適用なし。

*   Android およびAndroid ロゴは、Google LLC. の商標です。
*   Google およびGoogle ロゴは、Google LLC.の商標です。
*   Google , Google アシスタント は、 Google LLC の商標です。
*   Google Play およびGoogle Play ロゴは、Google LLC.の商標です。
*   YouTube およびYouTube ロゴは、Google LLC の商標です。
*   「Netflix」は、Netflix, Inc.の登録商標です。
*   「DAZN」は、DAZN Ltd.の商標または登録商標です。
*   Amazon、Prime Videoおよび関連する全てのロゴはAmazon.com, Inc.またはその関連会社の商標です。
*   AbemaTV及びAbemaTVロゴは株式会社 AbemaTVの登録商標です。
*   TELASAは、TELASA株式会社の商標または登録商標です。
*   Paravi及びParaviのロゴは株式会社プレミアム・プラットフォーム・ジャパンの商標または登録商標です。
*   Dolby、ドルビー、Dolby Atmos、Dolby AudioおよびダブルD記号は ドルビーラボラトリーズの商標または登録商標です。
*   その他、記載されている会社名・商品名は各社の商標または登録商標です。一部申請中のものを含みます。

閉じる

[シェアする](https://www.jcom.co.jp/service/tv/)

[Tweet](https://twitter.com/share?ref_src=twsrc%5Etfw)

【税込金額について】

*   表記の金額は特に記載のある場合を除き税込金額。
*   インボイス制度下における消費税の端数処理方法変更により消費税差額が生じる場合があります。

1.  [J:COM トップ](https://www.jcom.co.jp/)
    
2.  [サービス紹介](https://www.jcom.co.jp/service/)
    
3.  J:COM TV

[![ページ上部へ戻る](https://www.jcom.co.jp/common_v10/images/PageTop.webp)](https://www.jcom.co.jp/service/tv/#header)

[ページトップへ戻る](https://www.jcom.co.jp/service/tv/#header)

[サービス情報](https://www.jcom.co.jp/?sc_pid=common_footer_unav_service_01)

[オンラインショップ](https://onlineshop.jcom.co.jp/?sc_pid=common_footer_unav_ols_01)

[サポートお困りごと解決・よくあるご質問](https://cs.myjcom.jp/?sc_pid=common_footer_unav_csmyjcom_01)

[Fun! J:COMテレビ番組情報／プレゼント・優待](https://www.myjcom.jp/?sc_pid=common_footer_unav_myjcom_01)

[マイページ契約内容確認・変更](https://mypage.jcom.co.jp/?sc_pid=common_footer_unav_mypage_01)

[企業サイト](https://www.jcom.co.jp/corporate/?sc_pid=common_footer_unav_corporate_01)

*   [![Twitter](https://www.jcom.co.jp/common_v10/images/icn-x.svg)](https://twitter.com/jcom_info?sc_pid=common_footer_sns_twitter_01)
    
*   [![instagram](https://www.jcom.co.jp/common_v10/images/icn-instagram.svg)](https://www.instagram.com/jcom.official/?sc_pid=common_footer_sns_instagram_01)
    
*   [![Facebook](https://www.jcom.co.jp/common_v10/images/icn-facebook.svg)](https://www.facebook.com/JCOM.ZAQ?sc_pid=common_footer_sns_facebook_01)
    
*   [![LINE](https://www.jcom.co.jp/common_v10/images/icn-line.svg)](https://www.jcom.co.jp/social/campaign/line/?sc_pid=common_footer_sns_line_01)
    
*   [![note](https://www.jcom.co.jp/common_v10/images/icn-note.svg)](https://note.jcom.co.jp/?sc_pid=common_footer_sns_note_01)
    

[アカウント一覧](https://www.jcom.co.jp/service/social/?sc_pid=common_footer_sns_list_01)

[![あたらしいを、あたりまえに J:COMはおかげさまで30周年。 J:COM 30th ANNIVERSARY](https://www.jcom.co.jp/common_v10/images/logo-jcom-horizontal.svg)](https://www.jcom.co.jp/special/30th/)

*   [サイトマップ](https://www.jcom.co.jp/sitemap/?sc_pid=common_footer_sitemap)
    
*   [プライバシーポータル](https://www.jcom.co.jp/corporate/site_info/privacy-portal/?sc_pid=common_footer_privacybasic)
    
*   [プライバシーポリシー](https://www.jcom.co.jp/corporate/site_info/privacy_policy/?sc_pid=common_footer_privacy)
    
*   [ウェブアクセシビリティの取り組み](https://www.jcom.co.jp/corporate/site_info/accessibility/?sc_pid=common_footer_accessibility)
    
*   [セキュリティーポリシー](https://www.jcom.co.jp/corporate/site_info/security_policy/?sc_pid=common_footer_security)
    
*   [ソーシャルメディアポリシー](https://www.jcom.co.jp/corporate/site_info/socialmedia_policy/?sc_pid=common_footer_social)
    
*   [人権方針](https://www.jcom.co.jp/corporate/sustainability/well_being/hrp/?sc_pid=common_footer_hrp#policy)
    
*   [Cookie情報の利用、広告配信などについて](https://www.jcom.co.jp/corporate/site_info/privacy_policy/cookie/?sc_pid=common_footer_cookie)
    
*   [お問い合わせ](https://www.jcom.co.jp/contactus/?sc_pid=common_footer_contactus)
    
*   [企業サイト](https://www.jcom.co.jp/corporate/?sc_pid=common_footer_corporate)
    
*   [採用情報](https://recruit.jcom.co.jp/?sc_pid=common_footer_recruit)
    
*   [法人のお客さま](https://business.jcom.co.jp/?sc_pid=common_footer_business)
    
*   [当サイトについて](https://www.jcom.co.jp/site_info/?sc_pid=common_footer_siteinfo)
    

Copyright © JCOM Co., Ltd. All Rights Reserved.

[](https://www.jcom.co.jp/service/tv/#)

エリアを設定する

郵便番号を入力してください。

〒

ハイフン（-）は不要です

住居タイプを選択してください。

![icon](https://www.jcom.co.jp/common_v10/images/icn-apartment.svg)集合住宅

![icon](https://www.jcom.co.jp/common_v10/images/icn-house.svg)戸建住宅

該当する年齢を選択してください。  
（ご紹介できるプランが変わります。）

27歳以上

26歳以下

22歳以下

次へ

[](https://www.jcom.co.jp/service/tv/#)

エリアを設定する

郵便番号を入力してください。

〒

 

住居タイプを選択してください。

![icon](https://www.jcom.co.jp/common_v10/images/icn-apartment.svg)集合住宅

![icon](https://www.jcom.co.jp/common_v10/images/icn-house.svg)戸建住宅

次へ

[](https://www.jcom.co.jp/service/tv/#)

エリアを設定する

郵便番号を入力してください。

〒

 

住居タイプを選択してください。

![icon](https://www.jcom.co.jp/common_v10/images/icn-apartment.svg)集合住宅

![icon](https://www.jcom.co.jp/common_v10/images/icn-house.svg)戸建住宅

次へ

[](https://www.jcom.co.jp/service/tv/#)

エリアを設定する

郵便番号を入力してください。

〒

ハイフン（-）は不要です

次へ

[](https://www.jcom.co.jp/service/tv/#)

エリアを設定する

郵便番号を入力してください。

〒

 

住居タイプを選択してください。

![icon](https://www.jcom.co.jp/common_v10/images/icn-apartment.svg)集合住宅

![icon](https://www.jcom.co.jp/common_v10/images/icn-house.svg)戸建住宅

次へ

[](https://www.jcom.co.jp/service/tv/#)

サービスの確認

転居先の郵便番号を入力してください。

〒

 

次へ

[](https://www.jcom.co.jp/service/tv/#)

J:COM オンライン診療　提供エリアの確認

郵便番号を入力してください。

〒

ハイフン（-）は不要です

住居タイプを選択してください。

![icon](https://www.jcom.co.jp/common_v10/images/icn-apartment.svg)集合住宅

![icon](https://www.jcom.co.jp/common_v10/images/icn-house.svg)戸建住宅

次へ

[](https://www.jcom.co.jp/service/tv/#)

都道府県を選択

必須都道府県を選択してください。

北海道・東北

[北海道](https://www.jcom.co.jp/service/tv/#)
 [宮城県](https://www.jcom.co.jp/service/tv/#)

関東

[東京都](https://www.jcom.co.jp/service/tv/#)
 [神奈川県](https://www.jcom.co.jp/service/tv/#)
 [千葉県](https://www.jcom.co.jp/service/tv/#)
 [埼玉県](https://www.jcom.co.jp/service/tv/#)
 [群馬県](https://www.jcom.co.jp/service/tv/#)
 [茨城県](https://www.jcom.co.jp/service/tv/#)

関西

[大阪府](https://www.jcom.co.jp/service/tv/#)
 [京都府](https://www.jcom.co.jp/service/tv/#)
 [和歌山県](https://www.jcom.co.jp/service/tv/#)
 [兵庫県](https://www.jcom.co.jp/service/tv/#)

九州・山口

[福岡県](https://www.jcom.co.jp/service/tv/#)
 [熊本県](https://www.jcom.co.jp/service/tv/#)
 [大分県](https://www.jcom.co.jp/service/tv/#)
 [山口県](https://www.jcom.co.jp/service/tv/#)

[戻る](https://www.jcom.co.jp/service/tv/#)

[](https://www.jcom.co.jp/service/tv/#)

市区町村を選択

必須市区町村を選択してください。

現在の選択：東京都

*   あ
*   か
*   さ
*   た
*   な
*   は
*   ま
*   や
*   ら
*   わ

[昭島市](https://www.jcom.co.jp/service/tv/#)
 [あきる野市](https://www.jcom.co.jp/service/tv/#)
 [足立区](https://www.jcom.co.jp/service/tv/#)
 [板橋区](https://www.jcom.co.jp/service/tv/#)
 [稲城市](https://www.jcom.co.jp/service/tv/#)
 [江戸川区](https://www.jcom.co.jp/service/tv/#)
 [大田区](https://www.jcom.co.jp/service/tv/#)

「か」のコンテンツ内容

「あ」行から始まる地域

[昭島市](https://www.jcom.co.jp/service/tv/#)
 [あきる野市](https://www.jcom.co.jp/service/tv/#)
 [足立区](https://www.jcom.co.jp/service/tv/#)
 [板橋区](https://www.jcom.co.jp/service/tv/#)
 [稲城市](https://www.jcom.co.jp/service/tv/#)
 [江戸川区](https://www.jcom.co.jp/service/tv/#)
 [大田区](https://www.jcom.co.jp/service/tv/#)

「か」行から始まる地域

「さ」行から始まる地域

「た」行から始まる地域

「な」行から始まる地域

[戻る](https://www.jcom.co.jp/service/tv/#)

[](https://www.jcom.co.jp/service/tv/#)

エリアを設定する

〒 1070052

ご入力いただいた郵便番号には、複数のエリア候補があります。  
以下のリストから住所を選択してください

選択して下さい 1 2 3 テキストテキストテキスト

設定する

[戻る](https://www.jcom.co.jp/service/tv/#)

[](https://www.jcom.co.jp/service/tv/#)

エリアを設定する

〒 \-------

続く住所情報を選択してください。

  

選択して下さい 1 2 3 テキストテキストテキスト

次へ

[戻る](https://www.jcom.co.jp/service/tv/#)

[](https://www.jcom.co.jp/service/tv/#)

ギガ提供エリアの確認

〒 1070052 (J:COM 町田・川崎)は

J:COM NET 1Gコース  
の提供エリアです。

※ 「J:COM NET 1Gコース」はケーブルテレビ回線でご利用いただける1ギガサービスです。

光10G・5G・1Gコース  
の提供エリアです。

※ 光は一部エリアで未提供（順次拡大）[詳しくはこちらよりお問い合わせください](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

光10G・5G・1Gコース※1  
の提供エリア拡大中です。

J:COM NET 1Gコース※2  
の提供エリアです。

※1 光は一部エリアで未提供（順次拡大）[詳しくはこちらよりお問い合わせください](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

※2 「J:COM NET 1Gコース」はケーブルテレビ回線でご利用いただける1ギガサービスです。

光10G・5G・1Gコース  
J:COM NET 1Gコース  
の提供エリアです。

※ 一部エリアで未提供（順次拡大）[詳しくはこちらよりお問い合わせください](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

※ 「J:COM NET 1Gコース」はケーブルテレビ回線でご利用いただける1ギガサービスです。

J:COM NET 1Gコース  
の提供エリア外です。（順次提供エリア拡大中）

320Mコース  
の提供エリアです。

320Mコース  
の提供エリアです。

J:COM NET 1Gコースの提供エリアは順次拡大中です。

[提供エリアの詳しい情報はこちらよりお問い合わせください](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

J:COM大分（大分ケーブルテレコム株式会社）のサービスエリアです。  
[J:COM大分（大分ケーブルテレコム株式会社）のホームページ](https://wwwjcom.oct-net.ne.jp/)
をご覧ください。

横浜ケーブルビジョン（YCV）のサービスエリアです。  
[横浜ケーブルビジョン（YCV）のホームページ](https://www.catv-yokohama.ne.jp/)
をご覧ください。

[お申し込み](https://www.jcom.co.jp/sim_contact/entry_request.php?refresh=new&net_service=1)

[お申し込みの流れを確認する](https://www.jcom.co.jp/service/guide/sdu/)

一部地域は提供エリア外の場合があります。

[料金・コースを見る](https://www.jcom.co.jp/service/net/)

戻る

[](https://www.jcom.co.jp/service/tv/#)

ギガ提供エリアの確認

〒 1070052 (町田・川崎)は

光 10G・5G・1Gコース  
J:COM NET 1Gコース  
の提供エリアです。

※ 「J:COM NET 1Gコース」はケーブルテレビ回線でご利用いただける1ギガサービスです。

光 10G・5G・1Gコース  
の提供エリアです。

光 1Gコース  
J:COM NET 1Gコース  
の提供エリアです。

※ 「J:COM NET 1Gコース」はケーブルテレビ回線でご利用いただける1ギガサービスです。

光 1Gコース  
の提供エリアです。

320Mコース  
の提供エリアです。

[お申し込み](https://www.jcom.co.jp/sim_contact/entry_request.php?refresh=new&net_service=1)

[お申し込みの流れを確認する](https://www.jcom.co.jp/service/guide/sdu/)

一部地域は提供エリア外の場合があります。

料金・コースを見る

[料金シミュレーション](https://onlineshop.jcom.co.jp/Simulation/Simulation)

戻る

[](https://www.jcom.co.jp/service/tv/#)

ギガ提供エリアの確認

〒 1070052 

J:COM NET  
の提供エリア外です。

J:COM WiMAX  
の提供エリアです。

[お申し込み](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=wimax2p)

[お申し込みの流れを確認する](https://www.jcom.co.jp/service/guide/sdu/)

一部地域は提供エリア外の場合があります。

[料金・コースを見る](https://www.jcom.co.jp/service/wimax/)

戻る

[](https://www.jcom.co.jp/service/tv/#)

提供エリアの確認

〒 \------- 

J:COM大分（大分ケーブルテレコム株式会社）のサービスエリアです。  
[J:COM大分（大分ケーブルテレコム株式会社）のホームページ](https://wwwjcom.oct-net.ne.jp/)
をご覧ください。

横浜ケーブルビジョン（YCV）のサービスエリアです。  
[横浜ケーブルビジョン（YCV）のホームページ](https://www.catv-yokohama.ne.jp/)
をご覧ください。

以下のサービスをご利用いただけます。

   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-mobile.svg) ![J:COM MOBILE](https://www.jcom.co.jp/common_v10/images/logo-jcom-mobile.svg)](https://www.jcom.co.jp/service/mobile/)   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-electricity.svg) ![J:COM でんき](https://www.jcom.co.jp/common_v10/images/logo-jcom-electricity.svg)](https://www.jcom.co.jp/service/electricity/)
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-gas.svg) ![J:COM ガス](https://www.jcom.co.jp/common_v10/images/logo-jcom-gas.svg)](https://www.jcom.co.jp/service/gas/)
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-ssi.svg) ![J:COM ほけん](https://www.jcom.co.jp/common_v10/images/logo-jcom-ssi.svg)](https://www.jcom.co.jp/service/ssi/)
  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-telemedicine.svg) ![J:COM オンライン診療](https://www.jcom.co.jp/common_v10/images/logo-jcom-telemedicine.svg)](https://www.jcom.co.jp/service/telemedicine/)

以下サービスは[料金シミュレーション](https://onlineshop.jcom.co.jp/Simulation/Simulation)
で  
エリアをご確認ください。

  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-net.svg)\
\
![J:COM NET](https://www.jcom.co.jp/common_v10/images/logo-jcom-net.svg) 光10G/光1G](https://www.jcom.co.jp/price/hikari-n/)  ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-tv.svg) 地デジ・BSデジ  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-phone.svg) ひかり電話](https://www.jcom.co.jp/price/hikari-n/phone-op/)

J:COM NETは NTT回線でご提供となります。

[お申し込み](https://onlineshop.jcom.co.jp/planSelect)

[料金シミュレーション](https://onlineshop.jcom.co.jp/Simulation/Simulation)

地域のケーブルテレビをご希望の方は [こちら](https://www.catv-jcta.jp/search/index)

戻る

お住まいの地域によって、一部サービスがご利用いただけない場合がございます。

[](https://www.jcom.co.jp/service/tv/#)

サービスの確認

〒 1070052 は

J:COM大分（大分ケーブルテレコム株式会社）のサービスエリアです。提供サービスの確認は、[J:COM大分（大分ケーブルテレコム株式会社）のホームページ](https://wwwjcom.oct-net.ne.jp/)
をご覧ください。

横浜ケーブルビジョン（YCV）のサービスエリアです。  
[横浜ケーブルビジョン（YCV）のホームページ](https://www.catv-yokohama.ne.jp/)
をご覧ください。

以下のサービスをご利用いただけます。

   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-tv.svg) ![J:COM TV](https://www.jcom.co.jp/common_v10/images/logo-jcom-tv.svg)](https://www.jcom.co.jp/service/tv/)   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-net.svg) ![J:COM NET](https://www.jcom.co.jp/common_v10/images/logo-jcom-net.svg)](https://www.jcom.co.jp/service/net/)
  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-mobile.svg) ![J:COM MOBILE](https://www.jcom.co.jp/common_v10/images/logo-jcom-mobile.svg)](https://www.jcom.co.jp/service/mobile/)
  
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-phone.svg) ![J:COM PHONE](https://www.jcom.co.jp/common_v10/images/logo-jcom-phone.svg)](https://www.jcom.co.jp/service/phone/)   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-ssi.svg) ![J:COM ほけん](https://www.jcom.co.jp/common_v10/images/logo-jcom-ssi.svg)](https://www.jcom.co.jp/service/ssi/)
  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-telemedicine.svg) ![J:COM オンライン診療](https://www.jcom.co.jp/common_v10/images/logo-jcom-telemedicine.svg)](https://www.jcom.co.jp/service/telemedicine/)

[J:COMご加入中の方  \
お引越しのお手続き](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=contact_move)

郵便番号入力に戻る

[](https://www.jcom.co.jp/service/tv/#)

提供エリアの確認

〒 1070052 (J:COM 町田・川崎)は

以下のサービスをご利用いただけます。

   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-tv.svg) ![J:COM TV](https://www.jcom.co.jp/common_v10/images/logo-jcom-tv.svg)](https://www.jcom.co.jp/service/tv/)   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-net.svg) ![J:COM NET](https://www.jcom.co.jp/common_v10/images/logo-jcom-net.svg)](https://www.jcom.co.jp/service/net/)
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-mobile.svg) ![J:COM MOBILE](https://www.jcom.co.jp/common_v10/images/logo-jcom-mobile.svg)](https://www.jcom.co.jp/service/mobile/)
  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-electricity.svg) ![J:COM でんき](https://www.jcom.co.jp/common_v10/images/logo-jcom-electricity.svg)](https://www.jcom.co.jp/service/electricity/)
  
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-phone.svg) ![J:COM PHONE](https://www.jcom.co.jp/common_v10/images/logo-jcom-phone.svg)](https://www.jcom.co.jp/service/phone/)   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-gas.svg) ![J:COM ガス](https://www.jcom.co.jp/common_v10/images/logo-jcom-gas.svg)](https://www.jcom.co.jp/service/gas/)
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-ssi.svg) ![J:COM ほけん](https://www.jcom.co.jp/common_v10/images/logo-jcom-ssi.svg)](https://www.jcom.co.jp/service/ssi/)
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-home.svg) ![J:COM HOME](https://www.jcom.co.jp/common_v10/images/logo-jcom-home.svg)](https://www.jcom.co.jp/service/home/)
  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-telemedicine.svg) ![J:COM オンライン診療](https://www.jcom.co.jp/common_v10/images/logo-jcom-telemedicine.svg)](https://www.jcom.co.jp/service/telemedicine/)

[お申し込み](https://onlineshop.jcom.co.jp/planSelect)
 [お申し込み](https://onlineshop.jcom.co.jp/planSelect)

[お申し込みの流れを確認する](https://www.jcom.co.jp/service/guide/sdu/)

料金シミュレーション

戻る

[](https://www.jcom.co.jp/service/tv/#)

サービスの確認

〒 1070052 (J:COM 町田・川崎)は

以下のサービスをご利用いただけます。

   ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-tv.svg) ![J:COM TV](https://www.jcom.co.jp/common_v10/images/logo-jcom-tv.svg) ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-net.svg) ![J:COM NET](https://www.jcom.co.jp/common_v10/images/logo-jcom-net.svg)  ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-mobile.svg) ![J:COM MOBILE](https://www.jcom.co.jp/common_v10/images/logo-jcom-mobile.svg)  ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-electricity.svg) ![J:COM でんき](https://www.jcom.co.jp/common_v10/images/logo-jcom-electricity.svg)  
   ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-phone.svg) ![J:COM PHONE](https://www.jcom.co.jp/common_v10/images/logo-jcom-phone.svg) ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-gas.svg) ![J:COM ガス](https://www.jcom.co.jp/common_v10/images/logo-jcom-gas.svg)  ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-home.svg) ![J:COM HOME](https://www.jcom.co.jp/common_v10/images/logo-jcom-home.svg)

[J:COMご加入中の方  \
お引越しのお手続き](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=contact_move)

郵便番号入力に戻る

[](https://www.jcom.co.jp/service/tv/#)

提供エリアの確認

サービスをお選びください。

テレビとネットがセットでおトク！

 ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-tv.svg)  
![J:COM TV](https://www.jcom.co.jp/common_v10/images/logo-jcom-tv.svg)![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-net.svg)  
![J:COM NET](https://www.jcom.co.jp/common_v10/images/logo-jcom-net.svg) ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-phone.svg)  
![J:COM PHONE](https://www.jcom.co.jp/common_v10/images/logo-jcom-phone.svg)

[料金シミュレーション](https://onlineshop.jcom.co.jp/Simulation/Simulation)

月々のスマホ代をもっとおトクに。

![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-mobile.svg)  
![J:COM MOBILE](https://www.jcom.co.jp/common_v10/images/logo-jcom-mobile.svg)

[料金シミュレーション](https://www.jcom.co.jp/service/mobile/simulator/)

戻る

[](https://www.jcom.co.jp/service/tv/#)

J:COM ガス提供エリアの確認

〒 1070052 (J:COM ----)は

![](https://www.jcom.co.jp/common_form/img/common/logo/logo_gas_osaka.png)

の提供エリアです。

一部地域は提供エリア外の場合があります。

![](https://www.jcom.co.jp/common_form/img/common/logo/logo_gas_tokyo.png)

の提供エリアです。

一部地域は提供エリア外の場合があります。

![](https://www.jcom.co.jp/common_form/img/common/logo/logo_gas_keiyo.png)

の提供エリアです。

一部地域は提供エリア外の場合があります。

J:COM ガス  
の提供エリア外です。

（株）エナジー宇宙の【越谷・春日部地区/蓮田南地区】【取手・我孫子地区】の  
都市ガス供給エリアにお住まいの方は

東京ガス for J:COM「ずっともガス」

がご利用いただけます。

[詳しく見る](https://www.jcom.co.jp/service/tokyo_gas/)

J:COM ガス  
の提供エリア外です。

戻る

[](https://www.jcom.co.jp/service/tv/#)

J:COM オンライン診療　提供エリアの確認

〒 1070052 (J:COM ----)は

J:COM オンライン診療  
の提供エリアです。

一部地域は提供エリア外の場合があります。

[医療機関一覧を見る](https://www.jcom.co.jp/service/telemedicine/clinic/)

[料金を見る](https://www.jcom.co.jp/service/telemedicine/price/)

J:COM オンライン診療  
の提供エリア外です。

戻る

    

[](https://www.jcom.co.jp/service/tv/#)

あなたへのお知らせ
---------

[ログアウト](https://www.jcom.co.jp/common/logout.html)
