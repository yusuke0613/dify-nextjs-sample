# J:COM GAS | J:COM

URL: https://www.jcom.co.jp/service/gas/

---

[![あたらしいを、あたりまえに。 J:COM](https://www.jcom.co.jp/common_v10/images/logo-jcom-white.svg)](https://www.jcom.co.jp/en/?sc_pid=common_jcomlogo_01)

*   [Why J:COM](https://www.jcom.co.jp/en/beginner/?sc_pid=globalnavi_beginner_01)
    
*   Current customers
*   [Online Shop](https://onlineshop.jcom.co.jp/?sc_pid=globalnavi_ols_01)
    

J:COM Customers

[Check/Update Contract  \
My page login](https://mypage.jcom.co.jp/?sc_pid=common_mypage_01)
 [Troubleshooting/FAQ  \
Customer Support](https://cs.myjcom.jp/?sc_pid=common_suppot_01)
 [Enjoy J:COM even more  \
TV program information/presents and benefits  \
Fun! J:COM](https://www.myjcom.jp/?sc_pid=common_myj_01)

    ![検索](https://www.jcom.co.jp/common_v10/images/snav-icn-search-submit.svg)

*   [To you  \
    notice](https://id.zaq.ne.jp/id/script/connect/authz_req/endpoint.seam?response_type=code&client_id=JCOM_COJP&redirect_uri=https%3A%2F%2Fwww.jcom.co.jp%2Fservice%2Fgas%2F&scope=http%3A%2F%2Fjcom.co.jp%2Fconnect%2Fprofile%2Fstandard_new&nonce=1893975283&state=&prompt=)
     [ ] あなたへのお知らせを見よう
*   [To you  \
    notice](https://www.jcom.co.jp/service/gas/#)
    

Language

*   日本語
*   English
*   简体中文
*   한국어
*   Tiếng Việt
*   Português

*   Services
*   [Pricing](https://www.jcom.co.jp/en/price/)
    
*   [Promotions  \
    ​](https://www.jcom.co.jp/en/campaign/)
    
*   Sign Up /  
    Edit Account Info
*   Support
*   Company website

[Service Overview](https://www.jcom.co.jp/en/service/)

[TV,](https://www.jcom.co.jp/en/service/tv/)
 ​ ​[internet,](https://www.jcom.co.jp/en/service/net/)
 ​ ​[smartphone](https://www.jcom.co.jp/en/service/mobile/)
 [, electricity](https://www.jcom.co.jp/en/service/electricity/)
 ​ ​[Landline](https://www.jcom.co.jp/en/service/phone/)
 , [gas](https://www.jcom.co.jp/en/service/gas/)
 [,](https://www.jcom.co.jp/en/service/ssi/)
 insurance, [loan](https://www.jcom-financial.co.jp/)
 [, security camera,](https://www.jcom.co.jp/en/guide/starter/home_security/)
 ​ ​[Telemedicine](https://www.jcom.co.jp/en/service/telemedicine/)
 [, services for corporations and local governments![J:COM BUSINESS](https://www.jcom.co.jp/common_v10/images/logo_jcombusiness.webp)](https://business.jcom.co.jp/)

[Sign Up / Inquiries](https://www.jcom.co.jp/en/contactus/)

New customers

[New customers  \
Sign Up](https://onlineshop.jcom.co.jp/planSelect)

[New customers  \
Inquiries](https://www.jcom.co.jp/en/contactus/#entry)

J:COM Customers

[User  \
Various procedures](https://r.jcom.jp/eG4nLSC)

[Problems and inquiries  \
(chat)](https://prod8-live-chat.sprinklr.com/page?appId=67af27d73657336d345e4a96_app_9070639&did=CHAT_vivr_cojp_top&enableClose=true&skin=MODERN&userContext__c_679c8b53cb85b007fab0f6ea=DirectLink&utm_campaign=IVRSMS&utm_medium=referral&utm_source=did&webview=true&zoom=false)

Find the perfect plan for you

[Savings calculator](https://onlineshop.jcom.co.jp/Simulation/Simulation)

Some properties offer free or discounted options!

Covered areas & properties

[Company website](https://www.jcom.co.jp/en/corporate/)

[Corporate philosophy](https://www.jcom.co.jp/en/corporate/philosophy_brand/)

[Sustainability](https://www.jcom.co.jp/en/corporate/sustainability/)

[Medium-term management plan](https://www.jcom.co.jp/en/corporate/managementplan/)

[news release](https://newsreleases.jcom.co.jp/)

[Company Profile](https://www.jcom.co.jp/en/corporate/company/)

[Careers](https://recruit.jcom.co.jp/)

[Support Top](https://cs.myjcom.jp/)

[TV,](https://cs.myjcom.jp/categories/support/67ab976bf07f5244a208cb97)
 ​ ​[Internet,](https://cs.myjcom.jp/categories/support/67ab9788f07f5244a208cced)
 ​ ​[Smartphone](https://cs.myjcom.jp/categories/support/67ab979df07f5244a208cdc9)
 [, Electricity](https://cs.myjcom.jp/categories/support/67ab97b5f07f5244a208cec9)
 ​ ​[Landline](https://cs.myjcom.jp/categories/support/67ab97abf07f5244a208ce4e)
 [, Gas](https://cs.myjcom.jp/categories/support/67ab97b8f07f5244a208ceda)
 [, Insurance](https://cs.myjcom.jp/categories/support/67ab97c5f07f5244a208cf2f)
 ​ ​[Telemedicine](https://cs.myjcom.jp/categories/support/67ab97c2f07f5244a208cf1b)
 ​ ​[Home, IoT](https://cs.myjcom.jp/categories/support/67ab97bcf07f5244a208cee6)
 ​ ​[Security Camera](https://cs.myjcom.jp/categories/support/67ab97f5f07f5244a208d09b)

[J:COM STREAM](https://cs.myjcom.jp/categories/support/67ab97c9f07f5244a208cf49)

[Enkaku Support](https://cs.myjcom.jp/categories/support/67ab97faf07f5244a208d0c2)

[Home support](https://cs.myjcom.jp/categories/support/67ab97d4f07f5244a208cf92)

[Disaster prevention information service](https://cs.myjcom.jp/categories/support/67ab97d8f07f5244a208cfa0)

[Bicycle Life Support](https://cs.myjcom.jp/categories/support/67ab97e8f07f5244a208d023)

[J:COM Books](https://cs.myjcom.jp/categories/support/67ab97e4f07f5244a208d003)

[WiMAX](https://cs.myjcom.jp/categories/support/67ab97f1f07f5244a208d074)

[Trouble/maintenance information](https://information.myjcom.jp/maintenance_outage/)

Various procedures

[Personal ID](https://cs.myjcom.jp/categories/support/67ab9803f07f5244a208d113)

[Fees and Payment](https://cs.myjcom.jp/categories/support/67ab9805f07f5244a208d139)

[Moving and rebuilding](https://cs.myjcom.jp/categories/support/67ab980cf07f5244a208d184)

[Visits and counters](https://cs.myjcom.jp/categories/support/67ab980ff07f5244a208d1a4)

[Contract-related](https://cs.myjcom.jp/categories/support/67ab9806f07f5244a208d150)

[Suspension/cancellation](https://cs.myjcom.jp/categories/support/67ab980cf07f5244a208d188)

[Membership Benefits](https://cs.myjcom.jp/categories/support/67ab980df07f5244a208d18c)

[![あたらしいを、あたりまえに J:COM](https://www.jcom.co.jp/common_v10/images/logo-jcom-white.svg)](https://www.jcom.co.jp/en/?sc_pid=common_jcomlogo_01)

[![J:COM gas](https://www.jcom.co.jp/common_v10/images/logo-jcom-gas-bk.svg)](https://www.jcom.co.jp/en/service/gas/)

*   Rate plan
*   [How gas works](https://www.jcom.co.jp/en/service/gas/safety/)
    
*   [How to apply](https://www.jcom.co.jp/en/service/gas/flow/)
    

[Price plan top](https://www.jcom.co.jp/en/service/gas/price/)

*   [Tokyo gas area](https://www.jcom.co.jp/en/service/gas/tokyogas/price/)
    
*   [Osaka gas area](https://www.jcom.co.jp/en/service/gas/osakagas/price/)
    
*   [Keiyo gas area](https://www.jcom.co.jp/en/service/gas/keiyogas/price/)
    

[![あたらしいを、あたりまえに J:COM](https://www.jcom.co.jp/common_v10/images/logo-jcom.svg)](https://www.jcom.co.jp/en/)

*   Services

*   [Sign Up](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=gas)
    
*   [Inquiries](https://www.jcom.co.jp/en/contactus/#entry)
    
*   [For beginners  \
    ​](https://www.jcom.co.jp/en/beginner/)
    
*   User​  
    ​
*   [Online  \
    Shop](https://onlineshop.jcom.co.jp/)
    
*   ![検索する](https://www.jcom.co.jp/common_v10/images/fixed-nav-icn-search.svg)

    ![検索](https://www.jcom.co.jp/common_v10/images/snav-icn-search-submit.svg)

J:COM Customers

[Check/Update Contract  \
My page login](https://mypage.jcom.co.jp/)
 [Troubleshooting/FAQ  \
Customer Support](https://cs.myjcom.jp/)
 [Enjoy J:COM even more  \
TV program information/presents and benefits  \
Fun! J:COM](https://www.myjcom.jp/)

[Service Overview](https://www.jcom.co.jp/en/service/)

[TV,](https://www.jcom.co.jp/en/service/tv/)
 ​ ​[internet,](https://www.jcom.co.jp/en/service/net/)
 ​ ​[smartphone](https://www.jcom.co.jp/en/service/mobile/)
 [, electricity](https://www.jcom.co.jp/en/service/electricity/)
 ​ ​[Landline](https://www.jcom.co.jp/en/service/phone/)
 , [gas](https://www.jcom.co.jp/en/service/gas/)
 [,](https://www.jcom.co.jp/en/service/ssi/)
 insurance, [loan](https://www.jcom-financial.co.jp/)
 [, security camera,](https://www.jcom.co.jp/en/guide/starter/home_security/)
 ​ ​[Telemedicine](https://www.jcom.co.jp/en/service/telemedicine/)
 [, services for corporations and local governments![J:COM BUSINESS](https://www.jcom.co.jp/common_v10/images/logo_jcombusiness.webp)](https://business.jcom.co.jp/)

[![J:COM gas](https://www.jcom.co.jp/common_v10/images/logo-jcom-gas-bk.svg)](https://www.jcom.co.jp/en/service/gas/)

*   Rate plan
*   [How gas works](https://www.jcom.co.jp/en/service/gas/safety/)
    
*   [How to apply](https://www.jcom.co.jp/en/service/gas/flow/)
    

[Price plan top](https://www.jcom.co.jp/en/service/gas/price/)

*   [Tokyo gas area](https://www.jcom.co.jp/en/service/gas/tokyogas/price/)
    
*   [Osaka gas area](https://www.jcom.co.jp/en/service/gas/osakagas/price/)
    
*   [Keiyo gas area](https://www.jcom.co.jp/en/service/gas/keiyogas/price/)
    

*   ![メニュー](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/text-menu.svg)
*   ![J:COM gas メニュー](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom-gas/text-menu.svg)
*   [![お問い合わせ](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom-gas/text-inquiry.svg)](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=gas)
    
*   [![よくある質問 お問い合わせ](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom-gas/text-faq.svg)](https://cs.myjcom.jp/categorySearch?cg=ServiceOutside&c=gas)
    

*   [![あたらしいを、あたりまえに　J:COM](https://www.jcom.co.jp/common_v10/images/logo-jcom-only-white.svg)](https://www.jcom.co.jp/en/)
     ![メニューを閉じる](https://www.jcom.co.jp/common_v10/images/sp-menu/menu-close-white.svg)
    
    [J:COM Services](https://www.jcom.co.jp/en/service/)
    
    *   [![テレビ](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-tv-item.svg)](https://www.jcom.co.jp/en/service/tv/)
        
    *   [![ネット](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-net-item.svg)](https://www.jcom.co.jp/en/service/net/)
        
    *   [![スマホ](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-mobile-item.svg)](https://www.jcom.co.jp/en/service/mobile/)
        
    
    *   [![電気](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-electricity-item.svg)](https://www.jcom.co.jp/en/service/electricity/)
        
    *   [![固定電話](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-phone-item.svg)](https://www.jcom.co.jp/en/service/phone/)
        
    *   [![ガス](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-gas-item.svg)](https://www.jcom.co.jp/en/service/gas/)
        
    *   [![ほけん](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-ssi-item.svg)](https://www.jcom.co.jp/en/service/ssi/)
        
    *   [loan](https://www.jcom-financial.co.jp/)
        
    *   [![ホームIoT](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-home-item.svg)](https://www.jcom.co.jp/en/service/home/)
        
    *   [security cameras](https://www.jcom.co.jp/en/guide/starter/home_security/)
        
    *   [![オンライン診療](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-telemedicine-item.svg)](https://www.jcom.co.jp/en/service/telemedicine/)
        
    
    [Services for corporations and local governments  \
    ![J:COM BUSINESS](https://www.jcom.co.jp/common_v10/images/logo_jcombusiness.webp)](https://business.jcom.co.jp/)
    
    Service overview
    
    [Price List](https://www.jcom.co.jp/en/price/)
     [Promotions/Benefits](https://www.jcom.co.jp/en/campaign/)
     [Support](https://cs.myjcom.jp/)
     [Application/Various Changes](https://www.jcom.co.jp/en/contactus/)
    
        ![検索](https://www.jcom.co.jp/common_v10/images/snav-icn-search-submit-sp.svg)
    
    [J:COM Top](https://www.jcom.co.jp/en/)
    
    *   [Service Information](https://www.jcom.co.jp/en/)
        
    *   [Online  \
        Shop](https://onlineshop.jcom.co.jp/)
        
    *   [Support](https://cs.myjcom.jp/)
        
    *   [Fun! J:COM](https://www.myjcom.jp/)
        
    *   [My page](https://mypage.jcom.co.jp/)
        
    *   [Company website](https://www.jcom.co.jp/en/corporate/)
        
    
*   [![J:COM ガス](https://www.jcom.co.jp/common_v10/images/icn-jcom-gas.svg)gas](https://www.jcom.co.jp/en/service/gas/)
     ![メニューを閉じる](https://www.jcom.co.jp/common_v10/images/sp-menu/menu-close-white.svg)
    
    [![](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom-gas/slide/menu/mv-middle.jpg)\
    \
    Save even more by bundling\
    \
    Back to top](https://www.jcom.co.jp/en/service/gas/)
    
    *   Rate plan
        
        *   [Price plan top](https://www.jcom.co.jp/en/service/gas/price/)
            
        *   [Tokyo gas area](https://www.jcom.co.jp/en/service/gas/tokyogas/price/)
            
        *   [Osaka gas area](https://www.jcom.co.jp/en/service/gas/osakagas/price/)
            
        *   [Keiyo gas area](https://www.jcom.co.jp/en/service/gas/keiyogas/price/)
            
        
    *   [How gas works](https://www.jcom.co.jp/en/service/gas/safety/)
        
    *   [How to apply](https://www.jcom.co.jp/en/service/gas/flow/)
        
    

![](https://www.jcom.co.jp/common_v10/images/icn-jcom-gas.svg)

![](https://www.jcom.co.jp/common_v10/images/logo-jcom-gas.svg)

![J:COM ガス 支払いまとめてスッキリ](https://www.jcom.co.jp/service/gas/images_v10/img_mv_gas.png) ![J:COM ガス 支払いまとめてスッキリ](https://www.jcom.co.jp/service/gas/images_v10/img_mv_gas_sp.png)

[J:COM GAS  \
Reason for recommendation](https://www.jcom.co.jp/service/gas/#anc-01)

[Rate plan](https://www.jcom.co.jp/service/gas/#anc-02)

[How gas works](https://www.jcom.co.jp/service/gas/#anc-03)

[Customer Interviews](https://www.jcom.co.jp/service/gas/#anc-04)

New customers

[New Customers  \
Sign Up](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=gas)

[![](https://www.jcom.co.jp/common_v10/images/icn-think-black.svg)New Customers  \
Inquiries](https://www.jcom.co.jp/service/gas/#)

Current customers

[Current Customers  \
Various procedures](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=gas)

[Troubleshooting/  \
Inquiries](https://cs.myjcom.jp/categories/support/67ab97b8f07f5244a208ceda)

Tokyo Gas, Osaka Gas,  
Keiyo gas area is eligible!

Confirmation of target area

Inquiries about application

[on the web  \
inquiry](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=gas)

[Contact us by phone  \
(Toll free)​ ​0120-848-816](tel:0120-848-816)
 ​ ​9:00-18:00 \[Open all year round\]

Tokyo Gas, Osaka Gas,  
Keiyo gas area is eligible!

Confirmation of target area

[](https://www.jcom.co.jp/service/gas/#)

New Customers  
Inquiries

[Contact us online](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

J:COM will respond to you by email or phone.

Click here to contact us by phone (toll free)

[0120-848-816](tel:0120-848-816)

9:00-18:00 \[Open all year round\]

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

New Customers  
Inquiries

[Contact us online](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

J:COM will respond to you by email or phone.

Click here to contact us by phone (toll free)

[0120-848-816](tel:0120-848-816)

9:00-18:00 \[Open all year round\]

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

New Customers  
Inquiries

[Contact us online](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

J:COM will respond to you by email or phone.

Click here to contact us by phone (toll free)

[0120-989-970](tel:0120-989-970)

9:00-18:00 \[Open all year round\]

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

Current Customers  
Inquiries

Check / Update  
your contract here

[My page login](https://mypage.jcom.co.jp/)

* * *

Click here for  
Troubleshooting/FAQ

[Customer Support](https://cs.myjcom.jp/)

* * *

Click here to  
add or change service options

[Edit / Add to Your Plan](https://www2.myjcom.jp/join/)

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

Current Customers  
Inquiries

Check / Update  
your contract here

[My page login](https://mypage.jcom.co.jp/)

* * *

Click here for  
Troubleshooting/FAQ

[Customer Support](https://cs.myjcom.jp/)

* * *

Click here to  
add or change service options

[Edit / Add to Your Plan](https://www2.myjcom.jp/join/)

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

Current Customers  
Inquiries

Check / Update  
your contract here

[My page login](https://mypage.jcom.co.jp/)

* * *

Click here for  
Troubleshooting/FAQ

[Customer Support](https://cs.myjcom.jp/)

* * *

Click here to  
add or change service options

[Edit / Add to Your Plan](https://www2.myjcom.jp/join/)

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

User  
Application

For those who do not use J:COM TV

[J:COM TV  \
Shin Standard Plus  \
Application](https://r.jcom.jp/24KC2mS)

User J:COM TV

[J:COM TV  \
To Shin Standard Plus  \
Change of course](https://r.jcom.jp/0JLPOoy)

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

User  
Application

For those who do not use J:COM TV

[J:COM TV  \
Shin Standard Plus  \
Application](https://r.jcom.jp/24KC2mS)

User J:COM TV

[J:COM TV  \
To Shin Standard Plus  \
Change of course](https://r.jcom.jp/0JLPOoy)

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

User  
Application

For those who do not use J:COM TV

[J:COM TV  \
Shin Standard Plus  \
Application](https://r.jcom.jp/24KC2mS)

User J:COM TV

[J:COM TV  \
To Shin Standard Plus  \
Change of course](https://r.jcom.jp/0JLPOoy)

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

Confirming or changing the construction date

You can check, change, or cancel the schedule for on-site construction work on your My Page.

[My page login](https://mypage.jcom.co.jp/)

[Click here for instructions on how to check your My Page](https://cs.myjcom.jp/articles/support/6790bf45ad2e841b2e3362cf)

The installation date for J:COM NET Hikari (N) cannot be changed on My Page. Please contact [the customer center](https://www.jcom.co.jp/contactus/call_rgu.html#phone)
.

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

New Customers　  
Applications and Inquiries

[Applications and Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[0120-989-970](tel:0120-989-970)

Business hours: 9:00-18:00  
\[Open all year round\]

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

New Customers　  
Applications and Inquiries

[Applications and Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[0120-989-970](tel:0120-989-970)

Business hours: 9:00-18:00  
\[Open all year round\]

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

New Customers　  
Applications and Inquiries

[Applications and Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[0120-989-970](tel:0120-989-970)

Business hours: 9:00-18:00  
\[Open all year round\]

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

Current Customers　  
Inquiries

[Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[0120-989-970](tel:0120-989-970)

Business hours: 9:00-18:00  
\[Open all year round\]

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

Current Customers　  
Inquiries

[Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[0120-989-970](tel:0120-989-970)

Business hours: 9:00-18:00  
\[Open all year round\]

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

Current Customers　  
Inquiries

[Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[0120-989-970](tel:0120-989-970)

Business hours: 9:00-18:00  
\[Open all year round\]

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

新用户　  
申请・咨询

신규가입 고객　  
신청·문의

Đối với khách hàng mới tham gia　  
Ứng dụng / Yêu cầu

Novos assinantes　  
Solicitação/Consultas

电话咨询（有翻译）

전화 상담(통역 있음)

Tư vấn qua điện thoại (có phiên dịch)

Consulta por telefone (com intérprete)

[050-1722-1733](tel:050-1722-1733)

9:00-18:00 \[Open all year round\]

[日本語での通話はこちら](https://www.jcom.co.jp/service/gas/#)

[申请・咨询](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[신청・문의](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Ứng dụng / Yêu cầu](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Solicitação/Consultas](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

新用户　  
申请・咨询

신규가입 고객　  
신청·문의

Đối với khách hàng mới tham gia　  
Ứng dụng / Yêu cầu

Novos assinantes　  
Solicitação/Consultas

电话咨询（有翻译）

전화 상담(통역 있음)

Tư vấn qua điện thoại (có phiên dịch)

Consulta por telefone (com intérprete)

[050-1722-1733](tel:050-1722-1733)

9:00-18:00 \[Open all year round\]

[日本語での通話はこちら](https://www.jcom.co.jp/service/gas/#)

[申请・咨询](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[신청・문의](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Ứng dụng / Yêu cầu](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Solicitação/Consultas](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

新用户　  
申请・咨询

신규가입 고객　  
신청·문의

Đối với khách hàng mới tham gia　  
Ứng dụng / Yêu cầu

Novos assinantes　  
Solicitação/Consultas

电话咨询（有翻译）

전화 상담(통역 있음)

Tư vấn qua điện thoại (có phiên dịch)

Consulta por telefone (com intérprete)

[050-1722-1733](tel:050-1722-1733)

9:00-18:00 \[Open all year round\]

[日本語での通話はこちら](https://www.jcom.co.jp/service/gas/#)

[申请・咨询](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[신청・문의](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Ứng dụng / Yêu cầu](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Solicitação/Consultas](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

会员　  
联系我们

이용 중인 고객　  
문의

Khách hàng đang sử dụng　  
Hỏi đáp

Utilizadores　  
Consultar

电话咨询（有翻译）

전화 상담(통역 있음)

Tư vấn qua điện thoại (có phiên dịch)

Consulta por telefone (com intérprete)

[050-1722-1733](tel:050-1722-1733)

9:00-18:00 \[Open all year round\]

[日本語での通話はこちら](https://www.jcom.co.jp/service/gas/#)

[联系我们](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[문의](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[Hỏi đáp](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[Consultar](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

会员　  
联系我们

이용 중인 고객　  
문의

Khách hàng đang sử dụng　  
Hỏi đáp

Utilizadores　  
Consultar

电话咨询（有翻译）

전화 상담(통역 있음)

Tư vấn qua điện thoại (có phiên dịch)

Consulta por telefone (com intérprete)

[050-1722-1733](tel:050-1722-1733)

9:00-18:00 \[Open all year round\]

[日本語での通話はこちら](https://www.jcom.co.jp/service/gas/#)

[联系我们](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[문의](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[Hỏi đáp](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[Consultar](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

会员　  
联系我们

이용 중인 고객　  
문의

Khách hàng đang sử dụng　  
Hỏi đáp

Utilizadores　  
Consultar

电话咨询（有翻译）

전화 상담(통역 있음)

Tư vấn qua điện thoại (có phiên dịch)

Consulta por telefone (com intérprete)

[050-1722-1733](tel:050-1722-1733)

9:00-18:00 \[Open all year round\]

[日本語での通話はこちら](https://www.jcom.co.jp/service/gas/#)

[联系我们](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[문의](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[Hỏi đáp](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[Consultar](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

日本語でのお問い合わせ

[海外にお住まいの方](https://cs.myjcom.jp/knowledgeDetail?an=004897372)

[日本国内にお住まいの方](https://www.jcom.co.jp/contactus/call_rgu.html)

[閉じる](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

日本語でのお問い合わせ

[海外にお住まいの方](https://cs.myjcom.jp/knowledgeDetail?an=004897372)

[日本国内にお住まいの方](https://www.jcom.co.jp/contactus/call_rgu.html)

[閉じる](https://www.jcom.co.jp/service/gas/#)

Reasons why we recommend J:COM GAS
----------------------------------

*   [![品質も安全性もそのまま！ ガス供給も保安業務も変わらず安心！](https://www.jcom.co.jp/service/gas/images_v10/recommend1.png)](https://www.jcom.co.jp/service/gas/#recommend1)
    
*   [![切替はとってもカンタン！ お客さまはJ:COMへ申し込むだけ！](https://www.jcom.co.jp/service/gas/images_v10/recommend2.png)](https://www.jcom.co.jp/service/gas/#recommend2)
    
*   [![家計管理がスムーズに！ まとめてお支払ですっきり便利！](https://www.jcom.co.jp/service/gas/images_v10/recommend3.png)](https://www.jcom.co.jp/service/gas/#recommend3)
    

Rate plan
---------

available by region  
We will inform you about the price plan.

 [![J:COM ガス supplied by 東京ガス](https://www.jcom.co.jp/service/gas/images_v10/common/btn_tokyogas_visit_sp.png) ![J:COM ガス supplied by 東京ガス](https://www.jcom.co.jp/service/gas/images_v10/common/btn_tokyogas_visit_sp.png)](https://www.jcom.co.jp/en/service/gas/tokyogas/price/)

 [![J:COM ガス Supplied by 大阪ガス](https://www.jcom.co.jp/service/gas/images_v10/common/btn_osakagas_visit_sp.png) ![J:COM ガス Supplied by 大阪ガス](https://www.jcom.co.jp/service/gas/images_v10/common/btn_osakagas_visit_sp.png)](https://www.jcom.co.jp/en/service/gas/osakagas/price/)

 [![J:COM ガス supplied by 京葉ガス](https://www.jcom.co.jp/service/gas/images_v10/common/btn_keiyogas_visit_02.png) ![J:COM ガス supplied by 京葉ガス](https://www.jcom.co.jp/service/gas/images_v10/common/btn_keiyogas_visit_02.png)](https://www.jcom.co.jp/en/service/gas/keiyogas/price/)

[Tokyo Gas for J:COM “Zuttomo Gas”](https://www.jcom.co.jp/en/service/tokyo_gas/)

Click here if you live in Saitama, Ibaraki, or Chiba prefectures and are using city gas \*.

*   Energy Uchuu Co., Ltd. Koshigaya/Kasukabe/Hasudaminami, Toride/Abiko

Reasons why we recommend J:COM GAS
----------------------------------

Reason 1

Local supply and safety operations  
Because it remains a city gas company  
**Gas supply stability and  
Safety remains the same!**

[Read more about quality](https://www.jcom.co.jp/en/service/gas/safety/)

![品質そのままで安心！](https://www.jcom.co.jp/service/gas/images_v10/recommend-point1.png)

Reason 2

**Construction/cancellation procedures  
・No switching fee!**

![工事ナシ 解約手続きナシ 切替手数料ナシ](https://www.jcom.co.jp/service/gas/images_v10/recommend-point2.png)

Reason 3

in combination with other services  
**Clean billing  
Household management is easy!**

![請求確認もカンタン](https://www.jcom.co.jp/service/gas/images_v10/recommend-point3.png)

[View price plans by area](https://www.jcom.co.jp/en/service/gas/price/)

[New Customers  \
Sign Up](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=gas)

[Current Customers  \
Various procedures](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=gas)

Inquiries about application

[on the web  \
inquiry](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=gas)

[Contact us by phone  \
(Toll free)​ ​0120-848-816](tel:0120-848-816)
 ​ ​9:00-18:00 \[Open all year round\]

Tokyo Gas, Osaka Gas,  
Keiyo gas area is eligible!

Confirmation of target area

[](https://www.jcom.co.jp/service/gas/#)

New Customers  
Inquiries

[Contact us online](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

J:COM will respond to you by email or phone.

Click here to contact us by phone (toll free)

[0120-848-816](tel:0120-848-816)

9:00-18:00 \[Open all year round\]

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

New Customers  
Inquiries

[Contact us online](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

J:COM will respond to you by email or phone.

Click here to contact us by phone (toll free)

[0120-848-816](tel:0120-848-816)

9:00-18:00 \[Open all year round\]

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

New Customers  
Inquiries

[Contact us online](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

J:COM will respond to you by email or phone.

Click here to contact us by phone (toll free)

[0120-989-970](tel:0120-989-970)

9:00-18:00 \[Open all year round\]

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

Current Customers  
Inquiries

Check / Update  
your contract here

[My page login](https://mypage.jcom.co.jp/)

* * *

Click here for  
Troubleshooting/FAQ

[Customer Support](https://cs.myjcom.jp/)

* * *

Click here to  
add or change service options

[Edit / Add to Your Plan](https://www2.myjcom.jp/join/)

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

Current Customers  
Inquiries

Check / Update  
your contract here

[My page login](https://mypage.jcom.co.jp/)

* * *

Click here for  
Troubleshooting/FAQ

[Customer Support](https://cs.myjcom.jp/)

* * *

Click here to  
add or change service options

[Edit / Add to Your Plan](https://www2.myjcom.jp/join/)

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

Current Customers  
Inquiries

Check / Update  
your contract here

[My page login](https://mypage.jcom.co.jp/)

* * *

Click here for  
Troubleshooting/FAQ

[Customer Support](https://cs.myjcom.jp/)

* * *

Click here to  
add or change service options

[Edit / Add to Your Plan](https://www2.myjcom.jp/join/)

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

User  
Application

For those who do not use J:COM TV

[J:COM TV  \
Shin Standard Plus  \
Application](https://r.jcom.jp/24KC2mS)

User J:COM TV

[J:COM TV  \
To Shin Standard Plus  \
Change of course](https://r.jcom.jp/0JLPOoy)

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

User  
Application

For those who do not use J:COM TV

[J:COM TV  \
Shin Standard Plus  \
Application](https://r.jcom.jp/24KC2mS)

User J:COM TV

[J:COM TV  \
To Shin Standard Plus  \
Change of course](https://r.jcom.jp/0JLPOoy)

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

User  
Application

For those who do not use J:COM TV

[J:COM TV  \
Shin Standard Plus  \
Application](https://r.jcom.jp/24KC2mS)

User J:COM TV

[J:COM TV  \
To Shin Standard Plus  \
Change of course](https://r.jcom.jp/0JLPOoy)

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

Confirming or changing the construction date

You can check, change, or cancel the schedule for on-site construction work on your My Page.

[My page login](https://mypage.jcom.co.jp/)

[Click here for instructions on how to check your My Page](https://cs.myjcom.jp/articles/support/6790bf45ad2e841b2e3362cf)

The installation date for J:COM NET Hikari (N) cannot be changed on My Page. Please contact [the customer center](https://www.jcom.co.jp/contactus/call_rgu.html#phone)
.

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

New Customers　  
Applications and Inquiries

[Applications and Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[0120-989-970](tel:0120-989-970)

Business hours: 9:00-18:00  
\[Open all year round\]

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

New Customers　  
Applications and Inquiries

[Applications and Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[0120-989-970](tel:0120-989-970)

Business hours: 9:00-18:00  
\[Open all year round\]

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

New Customers　  
Applications and Inquiries

[Applications and Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[0120-989-970](tel:0120-989-970)

Business hours: 9:00-18:00  
\[Open all year round\]

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

Current Customers　  
Inquiries

[Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[0120-989-970](tel:0120-989-970)

Business hours: 9:00-18:00  
\[Open all year round\]

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

Current Customers　  
Inquiries

[Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[0120-989-970](tel:0120-989-970)

Business hours: 9:00-18:00  
\[Open all year round\]

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

Current Customers　  
Inquiries

[Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[0120-989-970](tel:0120-989-970)

Business hours: 9:00-18:00  
\[Open all year round\]

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

新用户　  
申请・咨询

신규가입 고객　  
신청·문의

Đối với khách hàng mới tham gia　  
Ứng dụng / Yêu cầu

Novos assinantes　  
Solicitação/Consultas

电话咨询（有翻译）

전화 상담(통역 있음)

Tư vấn qua điện thoại (có phiên dịch)

Consulta por telefone (com intérprete)

[050-1722-1733](tel:050-1722-1733)

9:00-18:00 \[Open all year round\]

[日本語での通話はこちら](https://www.jcom.co.jp/service/gas/#)

[申请・咨询](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[신청・문의](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Ứng dụng / Yêu cầu](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Solicitação/Consultas](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

新用户　  
申请・咨询

신규가입 고객　  
신청·문의

Đối với khách hàng mới tham gia　  
Ứng dụng / Yêu cầu

Novos assinantes　  
Solicitação/Consultas

电话咨询（有翻译）

전화 상담(통역 있음)

Tư vấn qua điện thoại (có phiên dịch)

Consulta por telefone (com intérprete)

[050-1722-1733](tel:050-1722-1733)

9:00-18:00 \[Open all year round\]

[日本語での通話はこちら](https://www.jcom.co.jp/service/gas/#)

[申请・咨询](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[신청・문의](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Ứng dụng / Yêu cầu](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Solicitação/Consultas](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

新用户　  
申请・咨询

신규가입 고객　  
신청·문의

Đối với khách hàng mới tham gia　  
Ứng dụng / Yêu cầu

Novos assinantes　  
Solicitação/Consultas

电话咨询（有翻译）

전화 상담(통역 있음)

Tư vấn qua điện thoại (có phiên dịch)

Consulta por telefone (com intérprete)

[050-1722-1733](tel:050-1722-1733)

9:00-18:00 \[Open all year round\]

[日本語での通話はこちら](https://www.jcom.co.jp/service/gas/#)

[申请・咨询](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[신청・문의](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Ứng dụng / Yêu cầu](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Solicitação/Consultas](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

会员　  
联系我们

이용 중인 고객　  
문의

Khách hàng đang sử dụng　  
Hỏi đáp

Utilizadores　  
Consultar

电话咨询（有翻译）

전화 상담(통역 있음)

Tư vấn qua điện thoại (có phiên dịch)

Consulta por telefone (com intérprete)

[050-1722-1733](tel:050-1722-1733)

9:00-18:00 \[Open all year round\]

[日本語での通話はこちら](https://www.jcom.co.jp/service/gas/#)

[联系我们](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[문의](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[Hỏi đáp](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[Consultar](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

会员　  
联系我们

이용 중인 고객　  
문의

Khách hàng đang sử dụng　  
Hỏi đáp

Utilizadores　  
Consultar

电话咨询（有翻译）

전화 상담(통역 있음)

Tư vấn qua điện thoại (có phiên dịch)

Consulta por telefone (com intérprete)

[050-1722-1733](tel:050-1722-1733)

9:00-18:00 \[Open all year round\]

[日本語での通話はこちら](https://www.jcom.co.jp/service/gas/#)

[联系我们](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[문의](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[Hỏi đáp](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[Consultar](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

会员　  
联系我们

이용 중인 고객　  
문의

Khách hàng đang sử dụng　  
Hỏi đáp

Utilizadores　  
Consultar

电话咨询（有翻译）

전화 상담(통역 있음)

Tư vấn qua điện thoại (có phiên dịch)

Consulta por telefone (com intérprete)

[050-1722-1733](tel:050-1722-1733)

9:00-18:00 \[Open all year round\]

[日本語での通話はこちら](https://www.jcom.co.jp/service/gas/#)

[联系我们](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[문의](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[Hỏi đáp](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[Consultar](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

日本語でのお問い合わせ

[海外にお住まいの方](https://cs.myjcom.jp/knowledgeDetail?an=004897372)

[日本国内にお住まいの方](https://www.jcom.co.jp/contactus/call_rgu.html)

[閉じる](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

日本語でのお問い合わせ

[海外にお住まいの方](https://cs.myjcom.jp/knowledgeDetail?an=004897372)

[日本国内にお住まいの方](https://www.jcom.co.jp/contactus/call_rgu.html)

[閉じる](https://www.jcom.co.jp/service/gas/#)

Safe and secure
---------------

![Safe and secure](https://www.jcom.co.jp/service/gas/images_v10/common/gas_system_736.png)

Gas supply and security services are handled by Tokyo Gas, Osaka Gas, and Keiyo Gas for each area, so quality remains the same. Even if you switch to J:COM GAS, you can still use gas safely and securely.

[Learn more](https://www.jcom.co.jp/en/service/gas/safety/)

Kanto/Kansai area  
Available at
--------------------------------

![関東・関西エリアで提供中](https://www.jcom.co.jp/service/gas/images_v10/gasmap_tokyo-keiyo-osaka.png)

Available in Tokyo Gas, Osaka Gas, and Keiyo Gas areas.

Confirmation of target area

Recommended as a set/  
Popular services
----------------------------------------

   [![](https://www.jcom.co.jp/images_v10/img-service-tv.jpg)\
\
![](https://www.jcom.co.jp/common_v10/images/icn-jcom-tv.svg) tv set\
\
Specialty channels  \
Make your "want to see" come true.](https://www.jcom.co.jp/en/service/tv/?sc_pid=common_service_tv)
   [![](https://www.jcom.co.jp/images_v10/img-service-net.jpg)\
\
![](https://www.jcom.co.jp/common_v10/images/icn-jcom-net.svg) Net\
\
Faster and more comfortable](https://www.jcom.co.jp/en/service/net/?sc_pid=common_service_net)
   [![](https://www.jcom.co.jp/images_v10/img-service-electricity.jpg)\
\
![](https://www.jcom.co.jp/common_v10/images/icn-jcom-electricity.svg) electricity\
\
Same quality  \
Convenient to put together](https://www.jcom.co.jp/en/service/electricity/?sc_pid=common_service_ele)

Customer feedback
-----------------

*   ### moving  
    added gas
    
    I thought it was very good because I could contract not only the internet but also gas, and there was a discount. I would like to sign a gas contract for my next move.
    
    20s/female
    
*   ### in any combination  
    Cheap!
    
    Not only the internet and telephone, but also gas will be cheaper.
    
    50s/Male
    
*   ### Better to collect  
    Easy to manage
    
    Gas and Wi-Fi can all be billed together, it is easy to manage, and it is good to have discounts.
    
    30s/female
    
*   ### Collection of withdrawals  
    Very convenient!
    
    It is very convenient that gas, smartphone, and J:COM usage fees, which were previously deducted separately, are all deducted at once. We will take care of all lifeline payments.
    
    30s/female
    

If you are considering signing up or adding services

### Sign Up information

New customers

[New Customers  \
Sign Up](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=gas)

[![](https://www.jcom.co.jp/common_v10/images/icn-think-black.svg)New Customers  \
Inquiries](https://www.jcom.co.jp/service/gas/#)

Current customers

[Current Customers  \
Various procedures](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=gas)

[Troubleshooting/  \
Inquiries](https://cs.myjcom.jp/categories/support/67ab97b8f07f5244a208ceda)

Tokyo Gas, Osaka Gas,  
Keiyo gas area is eligible!

Confirmation of target area

Inquiries about application

[on the web  \
inquiry](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=gas)

[Contact us by phone  \
(Toll free)​ ​0120-848-816](tel:0120-848-816)
 ​ ​9:00-18:00 \[Open all year round\]

Tokyo Gas, Osaka Gas,  
Keiyo gas area is eligible!

Confirmation of target area

[](https://www.jcom.co.jp/service/gas/#)

New Customers  
Inquiries

[Contact us online](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

J:COM will respond to you by email or phone.

Click here to contact us by phone (toll free)

[0120-848-816](tel:0120-848-816)

9:00-18:00 \[Open all year round\]

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

New Customers  
Inquiries

[Contact us online](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

J:COM will respond to you by email or phone.

Click here to contact us by phone (toll free)

[0120-848-816](tel:0120-848-816)

9:00-18:00 \[Open all year round\]

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

New Customers  
Inquiries

[Contact us online](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

J:COM will respond to you by email or phone.

Click here to contact us by phone (toll free)

[0120-989-970](tel:0120-989-970)

9:00-18:00 \[Open all year round\]

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

Current Customers  
Inquiries

Check / Update  
your contract here

[My page login](https://mypage.jcom.co.jp/)

* * *

Click here for  
Troubleshooting/FAQ

[Customer Support](https://cs.myjcom.jp/)

* * *

Click here to  
add or change service options

[Edit / Add to Your Plan](https://www2.myjcom.jp/join/)

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

Current Customers  
Inquiries

Check / Update  
your contract here

[My page login](https://mypage.jcom.co.jp/)

* * *

Click here for  
Troubleshooting/FAQ

[Customer Support](https://cs.myjcom.jp/)

* * *

Click here to  
add or change service options

[Edit / Add to Your Plan](https://www2.myjcom.jp/join/)

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

Current Customers  
Inquiries

Check / Update  
your contract here

[My page login](https://mypage.jcom.co.jp/)

* * *

Click here for  
Troubleshooting/FAQ

[Customer Support](https://cs.myjcom.jp/)

* * *

Click here to  
add or change service options

[Edit / Add to Your Plan](https://www2.myjcom.jp/join/)

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

User  
Application

For those who do not use J:COM TV

[J:COM TV  \
Shin Standard Plus  \
Application](https://r.jcom.jp/24KC2mS)

User J:COM TV

[J:COM TV  \
To Shin Standard Plus  \
Change of course](https://r.jcom.jp/0JLPOoy)

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

User  
Application

For those who do not use J:COM TV

[J:COM TV  \
Shin Standard Plus  \
Application](https://r.jcom.jp/24KC2mS)

User J:COM TV

[J:COM TV  \
To Shin Standard Plus  \
Change of course](https://r.jcom.jp/0JLPOoy)

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

User  
Application

For those who do not use J:COM TV

[J:COM TV  \
Shin Standard Plus  \
Application](https://r.jcom.jp/24KC2mS)

User J:COM TV

[J:COM TV  \
To Shin Standard Plus  \
Change of course](https://r.jcom.jp/0JLPOoy)

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

Confirming or changing the construction date

You can check, change, or cancel the schedule for on-site construction work on your My Page.

[My page login](https://mypage.jcom.co.jp/)

[Click here for instructions on how to check your My Page](https://cs.myjcom.jp/articles/support/6790bf45ad2e841b2e3362cf)

The installation date for J:COM NET Hikari (N) cannot be changed on My Page. Please contact [the customer center](https://www.jcom.co.jp/contactus/call_rgu.html#phone)
.

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

New Customers　  
Applications and Inquiries

[Applications and Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[0120-989-970](tel:0120-989-970)

Business hours: 9:00-18:00  
\[Open all year round\]

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

New Customers　  
Applications and Inquiries

[Applications and Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[0120-989-970](tel:0120-989-970)

Business hours: 9:00-18:00  
\[Open all year round\]

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

New Customers　  
Applications and Inquiries

[Applications and Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[0120-989-970](tel:0120-989-970)

Business hours: 9:00-18:00  
\[Open all year round\]

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

Current Customers　  
Inquiries

[Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[0120-989-970](tel:0120-989-970)

Business hours: 9:00-18:00  
\[Open all year round\]

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

Current Customers　  
Inquiries

[Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[0120-989-970](tel:0120-989-970)

Business hours: 9:00-18:00  
\[Open all year round\]

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

Current Customers　  
Inquiries

[Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[0120-989-970](tel:0120-989-970)

Business hours: 9:00-18:00  
\[Open all year round\]

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

新用户　  
申请・咨询

신규가입 고객　  
신청·문의

Đối với khách hàng mới tham gia　  
Ứng dụng / Yêu cầu

Novos assinantes　  
Solicitação/Consultas

电话咨询（有翻译）

전화 상담(통역 있음)

Tư vấn qua điện thoại (có phiên dịch)

Consulta por telefone (com intérprete)

[050-1722-1733](tel:050-1722-1733)

9:00-18:00 \[Open all year round\]

[日本語での通話はこちら](https://www.jcom.co.jp/service/gas/#)

[申请・咨询](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[신청・문의](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Ứng dụng / Yêu cầu](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Solicitação/Consultas](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

新用户　  
申请・咨询

신규가입 고객　  
신청·문의

Đối với khách hàng mới tham gia　  
Ứng dụng / Yêu cầu

Novos assinantes　  
Solicitação/Consultas

电话咨询（有翻译）

전화 상담(통역 있음)

Tư vấn qua điện thoại (có phiên dịch)

Consulta por telefone (com intérprete)

[050-1722-1733](tel:050-1722-1733)

9:00-18:00 \[Open all year round\]

[日本語での通話はこちら](https://www.jcom.co.jp/service/gas/#)

[申请・咨询](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[신청・문의](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Ứng dụng / Yêu cầu](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Solicitação/Consultas](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

新用户　  
申请・咨询

신규가입 고객　  
신청·문의

Đối với khách hàng mới tham gia　  
Ứng dụng / Yêu cầu

Novos assinantes　  
Solicitação/Consultas

电话咨询（有翻译）

전화 상담(통역 있음)

Tư vấn qua điện thoại (có phiên dịch)

Consulta por telefone (com intérprete)

[050-1722-1733](tel:050-1722-1733)

9:00-18:00 \[Open all year round\]

[日本語での通話はこちら](https://www.jcom.co.jp/service/gas/#)

[申请・咨询](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[신청・문의](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Ứng dụng / Yêu cầu](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Solicitação/Consultas](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

会员　  
联系我们

이용 중인 고객　  
문의

Khách hàng đang sử dụng　  
Hỏi đáp

Utilizadores　  
Consultar

电话咨询（有翻译）

전화 상담(통역 있음)

Tư vấn qua điện thoại (có phiên dịch)

Consulta por telefone (com intérprete)

[050-1722-1733](tel:050-1722-1733)

9:00-18:00 \[Open all year round\]

[日本語での通話はこちら](https://www.jcom.co.jp/service/gas/#)

[联系我们](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[문의](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[Hỏi đáp](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[Consultar](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

会员　  
联系我们

이용 중인 고객　  
문의

Khách hàng đang sử dụng　  
Hỏi đáp

Utilizadores　  
Consultar

电话咨询（有翻译）

전화 상담(통역 있음)

Tư vấn qua điện thoại (có phiên dịch)

Consulta por telefone (com intérprete)

[050-1722-1733](tel:050-1722-1733)

9:00-18:00 \[Open all year round\]

[日本語での通話はこちら](https://www.jcom.co.jp/service/gas/#)

[联系我们](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[문의](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[Hỏi đáp](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[Consultar](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

会员　  
联系我们

이용 중인 고객　  
문의

Khách hàng đang sử dụng　  
Hỏi đáp

Utilizadores　  
Consultar

电话咨询（有翻译）

전화 상담(통역 있음)

Tư vấn qua điện thoại (có phiên dịch)

Consulta por telefone (com intérprete)

[050-1722-1733](tel:050-1722-1733)

9:00-18:00 \[Open all year round\]

[日本語での通話はこちら](https://www.jcom.co.jp/service/gas/#)

[联系我们](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[문의](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[Hỏi đáp](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[Consultar](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[Close](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

日本語でのお問い合わせ

[海外にお住まいの方](https://cs.myjcom.jp/knowledgeDetail?an=004897372)

[日本国内にお住まいの方](https://www.jcom.co.jp/contactus/call_rgu.html)

[閉じる](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

日本語でのお問い合わせ

[海外にお住まいの方](https://cs.myjcom.jp/knowledgeDetail?an=004897372)

[日本国内にお住まいの方](https://www.jcom.co.jp/contactus/call_rgu.html)

[閉じる](https://www.jcom.co.jp/service/gas/#)

\[Notes\]

\[About J:COM GAS (hereinafter referred to as this service)\]

*   Basic charges are incurred even if gas is not used.
*   For details on fees, etc., please refer to the individual terms and conditions set out separately.
*   This service is only available to homes that use city gas 13A within the Tokyo Gas, Osaka Gas, and Keiyo Gas supply areas. If you use propane gas or all-electric appliances, you cannot switch to this service.
*   If less than one year has passed since the date of cancellation of this service, it may not be possible to renew the contract with the same demand location and the same content.
*   J:COM GAS contracts are only accepted for switching from other gas retailers.
*   Depending on your living situation, you may not be able to switch, such as if the meter is inside the building.
*   There may be cases where services such as points used with the previous gas retailer will expire or be suspended.
*   J:COM will handle cancellation procedures with other gas retailers.
*   Installation fees/handling charges etc. may apply to use, cancel or change services other than J:COM GAS.

\[About the 2-year gas contract service\]

*   To apply, you must subscribe to one of the following services designated by our company: television, internet, Landline, smartphone, or electricity.
*   A discount will be applied to J:COM service charges from the month following the start of your gas supply.
*   If the service is changed or canceled during the discount period, the discount will end.
*   There is no cancellation fee for the two-year contract service.

\[Disclosure regarding J:COM GAS (hereinafter, each service) based on the Specified Commercial Transactions Act\]

*   Regarding cooling-off: 1. If you notify us in writing or electromagnetic records by the day 8 days have passed from the date of receipt of the "Explanation of important matters regarding J:COM service subscription" that will be given to you at the time of contracting for this service. , the contract for providing this service can be canceled. We will notify you of the start date (switching date) of this service at a later date. 2.If this service has already been provided to the customer, the cost of canceling this service will be borne by our company.
*   If you request it, we will send you a separate document or electronic data containing the full text of the notice based on the Specified Commercial Transactions Act.

<Caution>

*   All images and illustrations are for illustrative purposes only.

Close

\[About the amount including tax\]

*   The listed amounts include tax unless otherwise specified.
*   Consumption tax differences may occur due to changes in the consumption tax rounding method under the invoice system.

1.  [J:COM Top](https://www.jcom.co.jp/en/)
    
2.  [Our Service](https://www.jcom.co.jp/en/service/)
    
3.  J:COM GAS

[![ページ上部へ戻る](https://www.jcom.co.jp/common_v10/images/PageTop.webp)](https://www.jcom.co.jp/service/gas/#header)

[Return to top of page](https://www.jcom.co.jp/service/gas/#header)

[Service Information](https://www.jcom.co.jp/en/?sc_pid=common_footer_unav_service_01)

[Online Shop](https://onlineshop.jcom.co.jp/?sc_pid=common_footer_unav_ols_01)

[Support Troubleshooting/FAQ](https://cs.myjcom.jp/?sc_pid=common_footer_unav_csmyjcom_01)

[Fun! J:COM TV program information/presents and benefits](https://www.myjcom.jp/?sc_pid=common_footer_unav_myjcom_01)

[My page Confirm/change contract details](https://mypage.jcom.co.jp/?sc_pid=common_footer_unav_mypage_01)

[Company website](https://www.jcom.co.jp/en/corporate/?sc_pid=common_footer_unav_corporate_01)

*   [![Twitter](https://www.jcom.co.jp/common_v10/images/icn-x.svg)](https://twitter.com/jcom_info?sc_pid=common_footer_sns_twitter_01)
    
*   [![instagram](https://www.jcom.co.jp/common_v10/images/icn-instagram.svg)](https://www.instagram.com/jcom.official/?sc_pid=common_footer_sns_instagram_01)
    
*   [![Facebook](https://www.jcom.co.jp/common_v10/images/icn-facebook.svg)](https://www.facebook.com/JCOM.ZAQ?sc_pid=common_footer_sns_facebook_01)
    
*   [![LINE](https://www.jcom.co.jp/common_v10/images/icn-line.svg)](https://www.jcom.co.jp/en/social/campaign/line/?sc_pid=common_footer_sns_line_01)
    
*   [![note](https://www.jcom.co.jp/common_v10/images/icn-note.svg)](https://note.jcom.co.jp/?sc_pid=common_footer_sns_note_01)
    

[Account list](https://www.jcom.co.jp/en/service/social/?sc_pid=common_footer_sns_list_01)

[![J:COM J:COM ANNIVERSARY: Making Newness a Natural Thing](https://www.jcom.co.jp/common_v10/images/logo-jcom-horizontal.svg)](https://www.jcom.co.jp/en/special/30th/)

*   [Site map](https://www.jcom.co.jp/en/sitemap/?sc_pid=common_footer_sitemap)
    
*   [Privacy portal](https://www.jcom.co.jp/en/corporate/site_info/privacy-portal/?sc_pid=common_footer_privacybasic)
    
*   [Privacy policy](https://www.jcom.co.jp/en/corporate/site_info/privacy_policy/?sc_pid=common_footer_privacy)
    
*   [Web Accessibility Initiatives](https://www.jcom.co.jp/en/corporate/site_info/accessibility/?sc_pid=common_footer_accessibility)
    
*   [Security policy](https://www.jcom.co.jp/en/corporate/site_info/security_policy/?sc_pid=common_footer_security)
    
*   [Social media policy](https://www.jcom.co.jp/en/corporate/site_info/socialmedia_policy/?sc_pid=common_footer_social)
    
*   [Human Rights Policy](https://www.jcom.co.jp/en/corporate/sustainability/well_being/hrp/?sc_pid=common_footer_hrp#policy)
    
*   [Regarding the use of cookie information, advertisement distribution, etc.](https://www.jcom.co.jp/en/corporate/site_info/privacy_policy/cookie/?sc_pid=common_footer_cookie)
    
*   [Inquiries](https://www.jcom.co.jp/en/contactus/?sc_pid=common_footer_contactus)
    
*   [Company website](https://www.jcom.co.jp/en/corporate/?sc_pid=common_footer_corporate)
    
*   [Careers](https://recruit.jcom.co.jp/?sc_pid=common_footer_recruit)
    
*   [Corporate customers](https://business.jcom.co.jp/?sc_pid=common_footer_business)
    
*   [About This Site](https://www.jcom.co.jp/en/site_info/?sc_pid=common_footer_siteinfo)
    

Copyright © JCOM Co., Ltd. All Rights Reserved.

[](https://www.jcom.co.jp/service/gas/#)

Configure area

Please enter your postal code.

〒

No hyphen (-) required

Please select your housing type.

![icon](https://www.jcom.co.jp/common_v10/images/icn-apartment.svg)Apartments

![icon](https://www.jcom.co.jp/common_v10/images/icn-house.svg)Houses

Please select the appropriate age.  
(The plans available will change.)

Age 27 or older

​Under 26 years old

​Under 22 years old

Next

[](https://www.jcom.co.jp/service/gas/#)

Configure area

Please enter your postal code.

〒

 

Please select your housing type.

![icon](https://www.jcom.co.jp/common_v10/images/icn-apartment.svg)Apartments

![icon](https://www.jcom.co.jp/common_v10/images/icn-house.svg)Houses

Next

[](https://www.jcom.co.jp/service/gas/#)

Configure area

Please enter your postal code.

〒

 

Please select your housing type.

![icon](https://www.jcom.co.jp/common_v10/images/icn-apartment.svg)Apartments

![icon](https://www.jcom.co.jp/common_v10/images/icn-house.svg)Houses

Next

[](https://www.jcom.co.jp/service/gas/#)

Configure area

Please enter your postal code.

〒

No hyphen (-) required

Next

[](https://www.jcom.co.jp/service/gas/#)

Configure area

Please enter your postal code.

〒

 

Please select your housing type.

![icon](https://www.jcom.co.jp/common_v10/images/icn-apartment.svg)Apartments

![icon](https://www.jcom.co.jp/common_v10/images/icn-house.svg)Houses

Next

[](https://www.jcom.co.jp/service/gas/#)

Check service

Please enter the postal code of your new address.

〒

 

Next

[](https://www.jcom.co.jp/service/gas/#)

J:COM Telemedicine coverage area check

Please enter your postal code.

〒

No hyphen (-) required

Please select your housing type.

![icon](https://www.jcom.co.jp/common_v10/images/icn-apartment.svg)Apartments

![icon](https://www.jcom.co.jp/common_v10/images/icn-house.svg)Houses

Next

[](https://www.jcom.co.jp/service/gas/#)

Select prefecture

Required Select prefecture.

Hokkaido and Tohoku

[Hokkaido](https://www.jcom.co.jp/service/gas/#)
 [Miyagi Prefecture](https://www.jcom.co.jp/service/gas/#)

Kanto

[Tokyo](https://www.jcom.co.jp/service/gas/#)
 [Kanagawa Prefecture](https://www.jcom.co.jp/service/gas/#)
 [Chiba Prefecture](https://www.jcom.co.jp/service/gas/#)
 [Saitama Prefecture](https://www.jcom.co.jp/service/gas/#)
 [Gunma Prefecture](https://www.jcom.co.jp/service/gas/#)
 [Ibaraki Prefecture](https://www.jcom.co.jp/service/gas/#)

Kansai

[Osaka Prefecture](https://www.jcom.co.jp/service/gas/#)
 [Kyoto Prefecture](https://www.jcom.co.jp/service/gas/#)
 [Wakayama Prefecture](https://www.jcom.co.jp/service/gas/#)
 [Hyogo Prefecture](https://www.jcom.co.jp/service/gas/#)

Kyushu/Yamaguchi

[Fukuoka Prefecture](https://www.jcom.co.jp/service/gas/#)
 [Kumamoto Prefecture](https://www.jcom.co.jp/service/gas/#)
 [Oita Prefecture](https://www.jcom.co.jp/service/gas/#)
 [Yamaguchi Prefecture](https://www.jcom.co.jp/service/gas/#)

[Return](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

Select city/ward/town

Required Please select your city.

Current selection: Tokyo

*   A
*   Ka
*   Sa
*   Ta
*   Na
*   Ha
*   Ma
*   Ya
*   Ra
*   Wa

[Akishima City](https://www.jcom.co.jp/service/gas/#)
 [Akiruno City](https://www.jcom.co.jp/service/gas/#)
 [Adachi Ward](https://www.jcom.co.jp/service/gas/#)
 [Itabashi Ward](https://www.jcom.co.jp/service/gas/#)
 [Inagi City](https://www.jcom.co.jp/service/gas/#)
 [Edogawa Ward](https://www.jcom.co.jp/service/gas/#)
 [Ota Ward](https://www.jcom.co.jp/service/gas/#)

Contents of “Ka”

Regions starting with “A”

[Akishima City](https://www.jcom.co.jp/service/gas/#)
 [Akiruno City](https://www.jcom.co.jp/service/gas/#)
 [Adachi Ward](https://www.jcom.co.jp/service/gas/#)
 [Itabashi Ward](https://www.jcom.co.jp/service/gas/#)
 [Inagi City](https://www.jcom.co.jp/service/gas/#)
 [Edogawa Ward](https://www.jcom.co.jp/service/gas/#)
 [Ota Ward](https://www.jcom.co.jp/service/gas/#)

Regions starting with “Ka”

Regions starting with “Sa”

Regions starting with “Ta”

Regions starting with “Na”

[Return](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

Configure area

〒 1070052

There are several possible areas for the postal code you entered.  
Please select your address from the list below

Please select 1 2 3 text text text

Configure

[Return](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

Configure area

〒 \-------

Please select the following address information.

  

Please select 1 2 3 text text text

Next

[Return](https://www.jcom.co.jp/service/gas/#)

[](https://www.jcom.co.jp/service/gas/#)

Check Gig coverage area

〒 1070052 (J:COM Machida/Kawasaki)

This is the coverage area of the J:COM NET 1G plan  
​

\* "J:COM NET 1Gig plan" is a 1Gig service that can be used with cable TV lines.

This is the coverage area for Hikari 10G/5G/1G plan  
​

\* Hikari is not available in some areas (gradually expanding service areas) [For more information, please contact us here.](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

Hikari 10G/5G/1G plan \*1  
coverage area is currently being expanded.

J:COM NET 1G plan \*2  
coverage area.

\*1 Hikari is not available in some areas (gradually expanding service areas) [For more information, please contact us here.](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

\*2 "J:COM NET 1Gig plan" is a 1Gig service that can be used with cable TV lines.

Hikari 10G/5G/1G plan  
J:COM NET 1G plan  
coverage area.

\*Not available in some areas (gradually expanding service areas) [For more information, please contact us here.](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

\* "J:COM NET 1Gig plan" is a 1Gig service that can be used with cable TV lines.

Outside the J:COM NET 1G plan  
coverage area. (Sequentially expanding the coverage area)

is in the 320M plan  
coverage area.

is in the 320M plan  
coverage area.

The J:COM NET 1G plan coverage area is gradually expanding.

[For detailed information on the coverage area, contact us here.](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

This is the service area of J:COM Oita (Oita Cable Telecom Co., Ltd.).  
[Please refer to the J:COM Oita (Oita Cable Telecom Co., Ltd.) homepage.](https://wwwjcom.oct-net.ne.jp/)
​

This is the Yokohama Cable Vision (YCV) service area.  
[Please refer to the Yokohama Cable Vision (YCV) homepage.](https://www.catv-yokohama.ne.jp/)
​

[Sign Up](https://www.jcom.co.jp/sim_contact/entry_request.php?refresh=new&net_service=1)

[Check the sign up process](https://www.jcom.co.jp/en/service/guide/sdu/)

Some areas may be outside the coverage area.

[View prices/plans](https://www.jcom.co.jp/en/service/net/)

Return

[](https://www.jcom.co.jp/service/gas/#)

Check Gig coverage area

〒 1070052 (Machida/Kawasaki)

Hikari 10G/5G/1G plan  
J:COM NET 1G plan  
coverage area.

\* "J:COM NET 1Gig plan" is a 1Gig service that can be used with cable TV lines.

Hikari 10G/5G/1G plan  
coverage area.

Hikari 1G plan  
J:COM NET 1G plan  
coverage area.

\* "J:COM NET 1Gig plan" is a 1Gig service that can be used with cable TV lines.

Hikari 1G plan  
coverage area.

is in the 320M plan  
coverage area.

[Sign Up](https://www.jcom.co.jp/sim_contact/entry_request.php?refresh=new&net_service=1)

[Check the sign up process](https://www.jcom.co.jp/en/service/guide/sdu/)

Some areas may be outside the coverage area.

View prices/plans

[Savings calculator](https://onlineshop.jcom.co.jp/Simulation/Simulation)

Return

[](https://www.jcom.co.jp/service/gas/#)

Check Gig coverage area

〒 1070052 

is out of the J:COM NET  
coverage area.

is in the J:COM WiMAX  
coverage area.

[Sign Up](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=wimax2p)

[Check the sign up process](https://www.jcom.co.jp/en/service/guide/sdu/)

Some areas may be outside the coverage area.

[View prices/plans](https://www.jcom.co.jp/en/service/wimax/)

Return

[](https://www.jcom.co.jp/service/gas/#)

Check coverage areas

〒 \------- 

This is the service area of J:COM Oita (Oita Cable Telecom Co., Ltd.).  
[Please refer to the J:COM Oita (Oita Cable Telecom Co., Ltd.) homepage.](https://wwwjcom.oct-net.ne.jp/)
​

This is the Yokohama Cable Vision (YCV) service area.  
[Please refer to the Yokohama Cable Vision (YCV) homepage.](https://www.catv-yokohama.ne.jp/)
​

The following services are available.

   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-mobile.svg) ![J:COM MOBILE](https://www.jcom.co.jp/common_v10/images/logo-jcom-mobile.svg)](https://www.jcom.co.jp/en/service/mobile/)   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-electricity.svg) ![J:COM Denki](https://www.jcom.co.jp/common_v10/images/logo-jcom-electricity.svg)](https://www.jcom.co.jp/en/service/electricity/)
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-gas.svg) ![J:COM ガス](https://www.jcom.co.jp/common_v10/images/logo-jcom-gas.svg)](https://www.jcom.co.jp/en/service/gas/)
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-ssi.svg) ![J:COM Insurance](https://www.jcom.co.jp/common_v10/images/logo-jcom-ssi.svg)](https://www.jcom.co.jp/en/service/ssi/)
  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-telemedicine.svg) ![J:COM Telemedicine](https://www.jcom.co.jp/common_v10/images/logo-jcom-telemedicine.svg)](https://www.jcom.co.jp/en/service/telemedicine/)

The following services are [Price simulation](https://onlineshop.jcom.co.jp/Simulation/Simulation)
 in  
Please check the area.

  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-net.svg)\
\
![J:COM NET](https://www.jcom.co.jp/common_v10/images/logo-jcom-net.svg) Optical 10G/Optical 1G](https://www.jcom.co.jp/en/price/hikari-n/)  ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-tv.svg) Terrestrial digital/BS digital  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-phone.svg) Hikari Denwa](https://www.jcom.co.jp/en/price/hikari-n/phone-op/)

J:COM NET is provided via NTT line.

[Sign Up](https://onlineshop.jcom.co.jp/planSelect)

[Savings calculator](https://onlineshop.jcom.co.jp/Simulation/Simulation)

If you want local cable TV ​ ​[here](https://www.catv-jcta.jp/search/index)

Return

Some services may not be available depending on your region.

[](https://www.jcom.co.jp/service/gas/#)

Check service

〒 1070052​

This is the service area of J:COM Oita (Oita Cable Telecom Co., Ltd.). Please refer to the [J:COM Oita (Oita Cable Television Co., Ltd.) website to confirm what services](https://wwwjcom.oct-net.ne.jp/)
 are provided.

This is the Yokohama Cable Vision (YCV) service area.  
[Please refer to the Yokohama Cable Vision (YCV) homepage.](https://www.catv-yokohama.ne.jp/)
​

The following services are available.

   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-tv.svg) ![J:COM TV](https://www.jcom.co.jp/common_v10/images/logo-jcom-tv.svg)](https://www.jcom.co.jp/en/service/tv/)   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-net.svg) ![J:COM NET](https://www.jcom.co.jp/common_v10/images/logo-jcom-net.svg)](https://www.jcom.co.jp/en/service/net/)
  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-mobile.svg) ![J:COM MOBILE](https://www.jcom.co.jp/common_v10/images/logo-jcom-mobile.svg)](https://www.jcom.co.jp/en/service/mobile/)
  
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-phone.svg) ![J:COM PHONE](https://www.jcom.co.jp/common_v10/images/logo-jcom-phone.svg)](https://www.jcom.co.jp/en/service/phone/)   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-ssi.svg) ![J:COM Insurance](https://www.jcom.co.jp/common_v10/images/logo-jcom-ssi.svg)](https://www.jcom.co.jp/en/service/ssi/)
  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-telemedicine.svg) ![J:COM Telemedicine](https://www.jcom.co.jp/common_v10/images/logo-jcom-telemedicine.svg)](https://www.jcom.co.jp/en/service/telemedicine/)

[J:COMご加入中の方  \
お引越しのお手続き](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=contact_move)

Return to postal code input

[](https://www.jcom.co.jp/service/gas/#)

Check coverage areas

〒 1070052 (J:COM Machida/Kawasaki)

The following services are available.

   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-tv.svg) ![J:COM TV](https://www.jcom.co.jp/common_v10/images/logo-jcom-tv.svg)](https://www.jcom.co.jp/en/service/tv/)   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-net.svg) ![J:COM NET](https://www.jcom.co.jp/common_v10/images/logo-jcom-net.svg)](https://www.jcom.co.jp/en/service/net/)
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-mobile.svg) ![J:COM MOBILE](https://www.jcom.co.jp/common_v10/images/logo-jcom-mobile.svg)](https://www.jcom.co.jp/en/service/mobile/)
  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-electricity.svg) ![J:COM Denki](https://www.jcom.co.jp/common_v10/images/logo-jcom-electricity.svg)](https://www.jcom.co.jp/en/service/electricity/)
  
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-phone.svg) ![J:COM PHONE](https://www.jcom.co.jp/common_v10/images/logo-jcom-phone.svg)](https://www.jcom.co.jp/en/service/phone/)   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-gas.svg) ![J:COM ガス](https://www.jcom.co.jp/common_v10/images/logo-jcom-gas.svg)](https://www.jcom.co.jp/en/service/gas/)
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-ssi.svg) ![J:COM Insurance](https://www.jcom.co.jp/common_v10/images/logo-jcom-ssi.svg)](https://www.jcom.co.jp/en/service/ssi/)
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-home.svg) ![J:COM HOME](https://www.jcom.co.jp/common_v10/images/logo-jcom-home.svg)](https://www.jcom.co.jp/en/service/home/)
  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-telemedicine.svg) ![J:COM Telemedicine](https://www.jcom.co.jp/common_v10/images/logo-jcom-telemedicine.svg)](https://www.jcom.co.jp/en/service/telemedicine/)

[Application](https://onlineshop.jcom.co.jp/planSelect)
 ​ ​[Application](https://onlineshop.jcom.co.jp/planSelect)

[Check the sign up process](https://www.jcom.co.jp/en/service/guide/sdu/)

Savings calculator

Return

[](https://www.jcom.co.jp/service/gas/#)

Check service

〒 1070052 (J:COM Machida/Kawasaki)

The following services are available.

   ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-tv.svg) ![J:COM TV](https://www.jcom.co.jp/common_v10/images/logo-jcom-tv.svg) ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-net.svg) ![J:COM NET](https://www.jcom.co.jp/common_v10/images/logo-jcom-net.svg)  ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-mobile.svg) ![J:COM MOBILE](https://www.jcom.co.jp/common_v10/images/logo-jcom-mobile.svg)  ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-electricity.svg) ![J:COM Denki](https://www.jcom.co.jp/common_v10/images/logo-jcom-electricity.svg)  
   ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-phone.svg) ![J:COM PHONE](https://www.jcom.co.jp/common_v10/images/logo-jcom-phone.svg) ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-gas.svg) ![J:COM ガス](https://www.jcom.co.jp/common_v10/images/logo-jcom-gas.svg)  ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-home.svg) ![J:COM HOME](https://www.jcom.co.jp/common_v10/images/logo-jcom-home.svg)

[J:COMご加入中の方  \
お引越しのお手続き](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=contact_move)

Return to postal code input

[](https://www.jcom.co.jp/service/gas/#)

Check coverage areas

Please select your service.

Get your TV and Internet together!

 ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-tv.svg)  
![J:COM TV](https://www.jcom.co.jp/common_v10/images/logo-jcom-tv.svg)![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-net.svg)  
![J:COM NET](https://www.jcom.co.jp/common_v10/images/logo-jcom-net.svg) ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-phone.svg)  
![J:COM PHONE](https://www.jcom.co.jp/common_v10/images/logo-jcom-phone.svg)

[Savings calculator](https://onlineshop.jcom.co.jp/Simulation/Simulation)

Save more money on your monthly smartphone bill.

![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-mobile.svg)  
![J:COM MOBILE](https://www.jcom.co.jp/common_v10/images/logo-jcom-mobile.svg)

[Savings calculator](https://www.jcom.co.jp/en/service/mobile/simulator/)

Return

[](https://www.jcom.co.jp/service/gas/#)

Check J:COM GAS coverage area

〒 1070052  ( J:COM ---- )​

![](https://www.jcom.co.jp/common_form/img/common/logo/logo_gas_osaka.png)

coverage area.

Some areas may be outside the coverage area.

![](https://www.jcom.co.jp/common_form/img/common/logo/logo_gas_tokyo.png)

coverage area.

Some areas may be outside the coverage area.

![](https://www.jcom.co.jp/common_form/img/common/logo/logo_gas_keiyo.png)

coverage area.

Some areas may be outside the coverage area.

is out of the J:COM GAS  
coverage area.

Energy Uchuu Co., Ltd. \[Koshigaya/Kasukabe area/Hasuda Minami area\] \[Toride/Abiko area\]  
If you live in an area where city gas is supplied,

you can use the

Tokyo Gas for J:COM "ZUTTO Gas" service.

[Learn more](https://www.jcom.co.jp/en/service/tokyo_gas/)

is out of the J:COM GAS  
coverage area.

Return

[](https://www.jcom.co.jp/service/gas/#)

J:COM Telemedicine coverage area check

〒 1070052  ( J:COM ---- )​

J:COM Telemedicine  
coverage area.

Some areas may be outside the coverage area.

[See list of medical institutions](https://www.jcom.co.jp/en/service/telemedicine/clinic/)

[See prices](https://www.jcom.co.jp/en/service/telemedicine/price/)

Outside the J:COM Telemedicine  
coverage area.

Return

    

[](https://www.jcom.co.jp/service/gas/#)

Notice to you
-------------

[Logout](https://www.jcom.co.jp/en/common/logout.html)

日本語

English
