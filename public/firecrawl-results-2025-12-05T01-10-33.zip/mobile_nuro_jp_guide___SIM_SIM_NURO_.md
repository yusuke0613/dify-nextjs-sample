# お申し込みガイド - SIMカード ‐｜格安SIM・スマホのNUROモバイル

URL: https://mobile.nuro.jp/guide/

---

![SONY](https://mobile.nuro.jp/images/nmui2/logo-sony-white.png)

[![【公式】格安SIM・格安スマホのNUROモバイル](https://mobile.nuro.jp/images/nmui2/logo-nuromobile-black.png)](https://mobile.nuro.jp/)

======================================================================================================================

[お申し込み](https://www.nuro.jp/app/nuromobile-directolsu/entry/new/)

[![マイページ](https://mobile.nuro.jp/images/nmui2/mypage.png)マイページ](https://mobile.nuro.jp/user/userMenu/)

*   [![facebook](https://mobile.nuro.jp/images/nmui2/icon-facebook.png)](https://www.facebook.com/NUROMobilebySony/)
    
*   [![Instagram](https://mobile.nuro.jp/images/nmui2/icon-instagram.png)](https://www.instagram.com/nuromobilebysony/)
    
*   [![Twitter](https://mobile.nuro.jp/images/nmui2/icon-twitter.png)](https://twitter.com/nuromobile_jp)
    
*   [![Youtube](https://mobile.nuro.jp/images/nmui2/icon-youtube.png)](https://youtube.com/channel/UC3PO0t22QLwQ4-cm8rvdFEw)
    

*   [NUROモバイルについて](https://mobile.nuro.jp/about/)
    
*   [お申し込みの流れ](https://mobile.nuro.jp/guide/sim.html)
    
*   [料金・プラン](https://mobile.nuro.jp/plan/)
    
*   [オプション・サービス](https://mobile.nuro.jp/option/)
    
*   [特典・キャンペーン](https://mobile.nuro.jp/campaign/)
    
*   [端末](https://mobile.nuro.jp/product/)
    
*   [FAQs新しいウィンドウで開く](https://support.sonynetwork.co.jp/faqsupport/nuromobile/web/index.html)
    
*   [スマホのアレコレ](https://mobile.nuro.jp/sumaho-arekore/)
    

*   [料金・プランについて](https://mobile.nuro.jp/plan/)
    
*   [NEOプラン](https://mobile.nuro.jp/plan/neoplan/)
    
*   [バリュープラス](https://mobile.nuro.jp/plan/valueplus/)
    
*   [かけ放題ジャスト](https://mobile.nuro.jp/plan/kakeho/)
    

*   [端末一覧](https://mobile.nuro.jp/product/)
    
*   [端末在庫情報 新しいウィンドウで開く](https://mobile.nuro.jp/deviceStockInformation/)
    
*   [Xperia 10 V特設ページ](https://mobile.nuro.jp/xperia/)
    
*   [SIMカード動作確認済端末一覧](https://mobile.nuro.jp/support/device/)
     
*   [eSIM動作確認済端末一覧](https://mobile.nuro.jp/support/device-esim/)
     

![閉じる](https://mobile.nuro.jp/images/nmui2/index/menu-close.svg)

[NUROモバイルについて](https://mobile.nuro.jp/about/)

[お申し込みの流れ](https://mobile.nuro.jp/guide/sim.html)

料金・プラン
------

*   [料金・プランについて](https://mobile.nuro.jp/plan/)
    
*   [NEOプラン](https://mobile.nuro.jp/plan/neoplan/)
    
*   [バリュープラス](https://mobile.nuro.jp/plan/valueplus/)
    
*   [かけ放題ジャスト](https://mobile.nuro.jp/plan/kakeho/)
    

[オプション・サービス](https://mobile.nuro.jp/option/)

[特典・キャンペーン](https://mobile.nuro.jp/campaign/)

端末
--

*   [端末一覧](https://mobile.nuro.jp/product/)
    
*   [端末在庫情報 新しいウィンドウで開く](https://mobile.nuro.jp/deviceStockInformation/)
    
*   [Xperia 10 V特設ページ](https://mobile.nuro.jp/xperia/)
    
*   [SIMカード動作確認済端末一覧](https://mobile.nuro.jp/support/device/)
    
*   [eSIM動作確認済端末一覧](https://mobile.nuro.jp/support/device-esim/)
    

[FAQs 新しいウィンドウで開く](https://support.sonynetwork.co.jp/faqsupport/nuromobile/web/index.html)

[スマホのアレコレ](https://mobile.nuro.jp/sumaho-arekore/)

[お申し込み](https://www.nuro.jp/app/nuromobile-directolsu/entry/new/)

[![マイページ](https://mobile.nuro.jp/images/nmui2/mypage.png)マイページ](https://mobile.nuro.jp/user/userMenu/)

お申し込みガイド - SIMカード ‐
===================

ご自宅にいながらすべての手続きができます。

*   特に注記のない限り、記載の金額は全て税込金額です。

STEP 1お申し込みの準備
--------------

お申し込みの前に、必要なものをご確認ください。
-----------------------

 ![お申し込みの前に、必要なものをご確認ください](https://mobile.nuro.jp/images/nmui2/guide/img1.png)

本人名義のクレジットカード※1  
[本人確認書類](https://mobile.nuro.jp/support/identity-verification.html)
※2  
MNP予約番号※3

※1 お支払いはクレジットカード払いです  
※2 データ専用SIMの場合は不要です  
※3 MNPワンストップをご利用の場合は不要です

STEP 2スマホを選ぶ
------------

#### 今のスマホをそのまま使う

お手元のスマホが利用可能か確認する  
[動作確認済み端末](https://mobile.nuro.jp/support/device/)

#### 新しいスマホを購入する

NUROモバイルで販売中のスマホ端末を確認する  
[販売端末一覧](https://mobile.nuro.jp/product/)

STEP 3SIMを選ぶ
------------

[SIMカードを使いたい](https://mobile.nuro.jp/guide/#setp3)

[eSIMを使いたい](https://mobile.nuro.jp/guide/esim.html#setp3)

SIMカードとeSIMって？

【SIMカードとは】  
従来の形式の物理SIM「nanoSIM」「microSIM」などスマートフォンに差し込むカードタイプを指します。  
【eSIMとは】  
対応端末に内臓されたSIMを使い、EIDを登録して使うタイプを指します。  
どちらも同じSIMですが、SIMカードは配送が必要なため、お手元に届くまでに配送日数とお受け取りが必要です。  
[eSIMの動作確認済端末](https://mobile.nuro.jp/support/device-esim/)
新しいウインドウで開くにダウンロードすることでSIMの受取が不要です。

STEP 4プランを選ぶ
------------

バリュープラス/NEOプラン/かけ放題ジャストの３つのプランから選択。

[開催中のオトクな特典はこちら新しいウインドウで開く](https://mobile.nuro.jp/campaign/)

今の電話番号をそのまま使う/新しく電話番号を取得する/SMS付きSIM・データ専用SIM  
の3つから自分に合ったプランをクリック

*   [今の電話番号をそのまま使う(MNP)](https://mobile.nuro.jp/guide/#tp4)
    
*   [新しく電話番号を取得](https://mobile.nuro.jp/guide/#tp5)
    
*   [SMS付きSIM・データ通信専用SIM](https://mobile.nuro.jp/guide/#tp6)
    

現在お使いの事業者と異なる名義でのお申し込みはできません。お使いの事業者にて名義変更をおこなっていただいた後、お申し込みください。

[MNP予約番号を発行していない](https://mobile.nuro.jp/guide/#onestop)

MNPワンストップを利用する

[MNP予約番号を発行している](https://mobile.nuro.jp/guide/#twostop)

MNPツーストップ（従来の乗り換え方式）を利用する

### MNP予約番号を発行しないお乗り換え～MNPワンストップとは～

MNPの予約番号発行不要。  
他社からNUROモバイルにMNP転入、NUROモバイルから他社にMNP転出を行う際に、MNP予約番号の取得が不要となる方式です。  
転出元でのMNPワンストップ対応有無および手続き方法については、転出元の携帯電話事業者にお問い合わせください。

MNPワンストップ対象携帯電話会社  

|     |     |
| --- | --- | 
| NTTドコモ | ドコモ  <br>ahamo |
| KDDI株式会社/沖縄セルラー電話株式会社 | au  <br>UQ mobile  <br>povo |
| ソフトバンク株式会社 | ソフトバンク  <br>ワイモバイル  <br>LINEMO  <br>LINEモバイル |
| 株式会社ジャパネットたかた | ジャパネットたかた通信サービス |
| 楽天モバイル株式会社 | 楽天モバイル  <br>楽天モバイル（ドコモ回線・au回線） |
| 日本通信株式会社 | 日本通信SIM、b-mobile |
| 株式会社オプテージ | mineo |
| 株式会社インターネットイニシアティブ | IIJmio |
| ソニーネットワークコミュニケーションズ株式会社 | NUROモバイル |
| イオンリテール株式会社 | イオンモバイル |
| ビッグローブ株式会社 | BIGLOBEモバイル |
| JCOM株式会社 | J:COM MOBILE |
| H.I.S.Mobile株式会社 | HISモバイル |
| 株式会社カブ＆ピース | KABU&モバイル |
| フラッシュコーポレーション合同会社 | FLASH MOBILE |
| 株式会社デジタルワレットソリューションズ | Smiles Connect |
| ニフティ株式会社 | NifMo |
| 株式会社メルカリ | メルカリモバイル |

※ 2025年4月24日現在

### MNP予約番号を発行するお乗り換え ～MNPツーストップとは～

MNPワンストップに対応していない会社からのMNPの転入の場合、MNP予約番号を取得してお申し込みいただきます。  
ご利用中の携帯電話事業者宛にMNP転出のお手続きをしていただき、「MNP予約番号」を取得し、「有効期限」を必ずご確認ください。

※お申し込みには、MNPの有効期限が10日間以上必要です。

[各社のMNP予約番号発行窓口について](https://mobile.nuro.jp/support/mnp.html)

### プラン選択

データ容量を1GB～55GBで選べて、月額792円からご利用可能です。  
大きく3種類のプランを提供しており、ライフスタイルに合わせて料金プランが選べます。

![ドコモ au ソフトバンク](https://mobile.nuro.jp/images/nmui2/plan/valueplus/triple_career.png)

トリプルキャリア対応で、  
ドコモ・au・ソフトバンク回線のどれを選んでも同一料金です。

※ 一部対象外のプランがあります。

[回線選択からプラン選択までのお申し込み方法  \
ワンストップの場合](https://mobile.nuro.jp/guide/#modal-c1)

### 【回線選択】

1.  ご利用になる「回線キャリア」、「音声通話付き」をお選びください。
2.  「現在の電話番号を引き継ぐ(MNP)」を選択いただきます。
3.  「MNP予約番号の有無」が表示されますので「ない」を選択ください。
4.  「転出元の選択」にて現在ご利用いただいてる携帯電話会社を選択し、「MNP手続きへ進む」を押下してください。

### 【解約手続き】

現在ご利用中の携帯電話会社のマイページにてMNP予約番号発行に関する注意事項をご確認いただき、転出手続きを行います。  
完了いたしますと、自動でNUROモバイルのお申込み画面へ戻ります。  
※既にMNP予約番号が発行されているなど、現在ご契約中の携帯電話会社でMNPワンストップによる転出手続きができない場合は、MNP予約番号を取得いただき、取得したMNP予約番号を利用して再度お申し込みください。

### 【プラン選択】

NUROモバイルのお申し手続きを再開します。  
ご利用になる「プラン」「SIMカード」等をご選択ください。

[回線選択からプラン選択までのお申し込み方法  \
ツーストップの場合](https://mobile.nuro.jp/guide/#modal-c1-2)

### 【回線選択】

1.  ご利用になる「回線キャリア」、「音声通話付き」をお選びください。
2.  「現在の電話番号を引き継ぐ(MNP)」を選択いただきます。
3.  「MNP予約番号の有無」が表示されますので「ある」を選択ください。
4.  「プラン選択へ進む」を押下してください。

### 【プラン選択】

NUROモバイルのお申し手続きを再開します。  
ご利用になる「プラン」「SIMカード」等をご選択ください。

### オプション選択

#### NUROモバイル オススメのオプション

[##### 通話定額オプション（5分/10分/かけ放題）\
\
5分または10分、かけ放題から選べる、通話定額オプション。時間内であれば何度でも通話することができます。  \
5分/10分の通話定額オプションは時間超過後、11円/30秒でご利用いただけます。\
\
詳しくはこちら](https://mobile.nuro.jp/option/denwa/10min-kakeho.html)

[##### 端末補償\
\
NUROモバイルで買った端末も、そうでない端末も、お客さまの端末を補償します。\
\
詳しくはこちら](https://mobile.nuro.jp/option/hoshou/)

[オプション・サービス一覧](https://mobile.nuro.jp/option/)

### 決済方法について

毎月のSIM月額基本料金のお支払いはクレジットカード払いです。

![ご利用可能なクレジットカード VISA, MASTER, JCB, Diners Club](https://mobile.nuro.jp/images/nmui2/guide/img3.png)

### お届けについて

SIMカードの場合、お申し込み手続きとご本人様確認が午後2時までに完了した場合、最短で当日発送です。

### 設定について

お手元にSIMカードが到着しましたら、ご利用ガイドをご確認いただき利用設定を行ってください。

[ご利用ガイド](https://mobile.nuro.jp/guide/setup.html#V01)

### プラン選択

データ容量を1GB～55GBで選べて、月額792円からご利用可能です。  
大きく3種類のプランを提供しており、ライフスタイルに合わせて料金プランが選べます。

![ドコモ au ソフトバンク](https://mobile.nuro.jp/images/nmui2/plan/valueplus/triple_career.png)

トリプルキャリア対応で、  
ドコモ・au・ソフトバンク回線のどれを選んでも同一料金です。

※ 一部対象外のプランがあります。

[回線選択からプラン選択までのお申し込み方法](https://mobile.nuro.jp/guide/#modal-c2)

### 【回線選択】

ご利用になる「回線キャリア」、「音声通話付き新規」をお選びください。

### 【プラン選択】

ご利用になる「プラン」「SIMカード」等をご選択ください。

### オプション選択

#### NUROモバイル オススメのオプション

[##### 通話定額オプション（5分/10分/かけ放題）\
\
5分または10分、かけ放題から選べる、通話定額オプション。時間内であれば何度でも通話することができます。  \
5分/10分の通話定額オプションは時間超過後、11円/30秒でご利用いただけます。\
\
詳しくはこちら](https://mobile.nuro.jp/option/denwa/10min-kakeho.html)

[##### 端末補償\
\
NUROモバイルで買った端末も、そうでない端末も、お客さまの端末を補償します。\
\
詳しくはこちら](https://mobile.nuro.jp/option/hoshou/)

[オプション・サービス一覧](https://mobile.nuro.jp/option/)

### 決済方法について

毎月のSIM月額基本料金のお支払いはクレジットカード払いです。

![ご利用可能なクレジットカード VISA, MASTER, JCB, Diners Club](https://mobile.nuro.jp/images/nmui2/guide/img3.png)

### お届けについて

SIMカードの場合、お申し込み手続きとご本人様確認が午後2時までに完了した場合、最短で当日発送です。

### 設定について

お手元にSIMカードが到着しましたら、ご利用ガイドをご確認いただき利用設定を行ってください。

[ご利用ガイド](https://mobile.nuro.jp/guide/setup.html#V01)

### プラン選択

NUROモバイルは、データ容量を0.2GB～15GBで選べて、月額330円からご利用可能です。 大きく3種類のプランを提供しており、ライフスタイルに合わせて料金プランが選べます。

![ドコモ au ソフトバンク](https://mobile.nuro.jp/images/nmui2/plan/valueplus/triple_career.png)

トリプルキャリア対応で、  
ドコモ・au・ソフトバンク回線のどれを選んでも同一料金です。

※ 一部対象外のプランがあります。

[回線選択からプラン選択までのお申し込み方法](https://mobile.nuro.jp/guide/#modal-c3)

### 【回線選択】

ご利用になる「回線キャリア」、「SMS付き・データ通信専用SIM」をお選びください。

### 【プラン選択】

ご利用になる「プラン」「SIMカード」等をご選択ください。

### オプション選択

#### NUROモバイル オススメのオプション

[##### 端末補償\
\
NUROモバイルで買った端末も、そうでない端末も、お客さまの端末を補償します。\
\
詳しくはこちら](https://mobile.nuro.jp/option/denwa/10min-kakeho.html)

[##### ウイルスバスターモバイル 月額版\
\
スマホ向け総合セキュリティ・ウイルス対策アプリです。ウイルス対策、個人情報漏えいの可能性のあるアプリの評価、危険なWebサイトのブロック、迷惑メールや迷惑電話の対策、盗難/紛失対策が可能です。\
\
詳しくはこちら](https://mobile.nuro.jp/option/hoshou/)

[](https://mobile.nuro.jp/option/hoshou/)

[オプション・サービス一覧](https://mobile.nuro.jp/option/)

### 決済方法について

毎月のSIM月額基本料金のお支払いはクレジットカード払いです。

![ご利用可能なクレジットカード VISA, MASTER, JCB, Diners Club](https://mobile.nuro.jp/images/nmui2/guide/img3.png)

### お届けについて

SIMカードの場合、お申し込み手続きとご本人様確認が午後2時までに完了した場合、最短で当日発送です。

### 設定について

お手元にSIMカードが到着しましたら、ご利用ガイドをご確認いただき利用設定を行ってください。

[ご利用ガイド](https://mobile.nuro.jp/guide/setup.html#V01)

*   [今の電話番号をそのまま使う(MNP)](https://mobile.nuro.jp/guide/#tp4)
    
*   [新しく電話番号を取得](https://mobile.nuro.jp/guide/#tp5)
    
*   [SMS付きSIMデータ通信専用SIM](https://mobile.nuro.jp/guide/#tp6)
    

いつでもササっと申し込み

[お申し込みはこちら](https://www.nuro.jp/app/nuromobile-directolsu/entry/new/)

[お申し込みから  \
ご利用開始まではこちら](https://mobile.nuro.jp/guide/)

あなたにぴったりのプランが  
見つかるかも

[料金](https://mobile.nuro.jp/plan/)

[オプション一覧](https://mobile.nuro.jp/option/)

[端末情報](https://mobile.nuro.jp/product/)

このページをシェアする

*   [![facebook](https://mobile.nuro.jp/images/nmui2/icon-facebook.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fmobile.nuro.jp%2F)
    
*   [![Twitter](https://mobile.nuro.jp/images/nmui2/icon-twitter.png)](https://twitter.com/share?text=%E6%A0%BC%E5%AE%89SIM%E3%80%81%E3%82%B9%E3%83%9E%E3%83%9B%E3%81%AA%E3%82%89%E3%81%8A%E3%83%88%E3%82%AF%E3%81%AA%E7%89%B9%E5%85%B8%E3%81%8C%E3%81%A4%E3%81%84%E3%81%A6%E3%81%8F%E3%82%8B%E3%80%8Cnuro%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB%E3%80%8D%EF%BC%81&url=https%3A%2F%2Fmobile.nuro.jp%2F)
    
*   [![LINE](https://mobile.nuro.jp/images/nmui2/icon-line.png)](https://social-plugins.line.me/lineit/share?url=https%3A%2F%2Fmobile.nuro.jp%2F)
    

1.  [NUROモバイル TOP](https://mobile.nuro.jp/)
    
2.  お申し込みガイド

[![ページトップ](https://mobile.nuro.jp/images/nmui2/gotop.png)](https://mobile.nuro.jp/guide/#)

![NURO Mobile](https://mobile.nuro.jp/images/nmui2/logo-nuromobile-white.png)

[トップ](https://mobile.nuro.jp/)

[お知らせ](https://mobile.nuro.jp/news_release/)

[アーカイブ](https://mobile.nuro.jp/archive/)

[障害メンテナンス情報新しいウィンドウで開く](https://www.nuro.jp/emerge/)

[規約一覧](https://mobile.nuro.jp/kiyaku/)

[NUROモバイルアプリ](https://mobile.nuro.jp/app/)

official account

*   [![facebook](https://mobile.nuro.jp/images/nmui2/icon-facebook.png)](https://www.facebook.com/NUROMobilebySony/)
    
*   [![Instagram](https://mobile.nuro.jp/images/nmui2/icon-instagram.png)](https://www.instagram.com/nuromobilebysony/)
    
*   [![(旧：Twitter)](https://mobile.nuro.jp/images/nmui2/icon-x-under.png)](https://twitter.com/nuromobile_jp)
    
*   [![Youtube](https://mobile.nuro.jp/images/nmui2/icon-youtube.png)](https://youtube.com/channel/UC3PO0t22QLwQ4-cm8rvdFEw)
    

[![NURO](https://mobile.nuro.jp/images/nmui2/logo-nuro-white.png)](https://www.sonynetwork.co.jp/corporation/nuro_rebrand2021/)

ソニーネットワークコミュニケーションズ株式会社  
Copr. Sony Network Communications Inc. 登録番号(電気通信事業者): 関第94号

*   [個人情報保護 / 情報セキュリティへの取り組み新しいウィンドウで開く](https://www.sonynetwork.co.jp/corporation/safety/)
    
*   [会社概要新しいウィンドウで開く](https://www.sonynetwork.co.jp/corporation/company/profile/)
    
*   [サイトポリシー](https://mobile.nuro.jp/kiyaku/siteinfo.html)
    

![](https://googleads.g.doubleclick.net/pagead/viewthroughconversion/981375687/?guid=ON&amp;script=0)![](https://b97.yahoo.co.jp/pagead/conversion/1000255097/?guid=ON&script=0&disvt=false)![](https://googleads.g.doubleclick.net/pagead/viewthroughconversion/843763034/?guid=ON&amp;script=0)![](https://www.googleadservices.com/pagead/conversion/843763034/?label=FCdICI_7wnMQ2pqrkgM&amp;guid=ON&amp;script=0)![](https://googleads.g.doubleclick.net/pagead/viewthroughconversion/941735114/?guid=ON&amp;script=0)![](https://b97.yahoo.co.jp/pagead/conversion/1000255095/?guid=ON&script=0&disvt=false)![](https://www.facebook.com/tr?id=1581914835441962&ev=PageView&noscript=1)![](https://b97.yahoo.co.jp/pagead/conversion/1000977195/?guid=ON&script=0&disvt=false)

![](https://bat.bing.com/action/0?ti=97129554&Ver=2&mid=b0ced8fa-d096-4adf-ad59-ea7d23bf29e6&bo=1&sid=46213b30d17611f09d4cf93d92813958&vid=46215480d17611f08f6931c1d8efda40&vids=1&msclkid=N&pi=0&lg=en-US@posix&sw=1280&sh=800&sc=24&nwd=1&tl=%E3%81%8A%E7%94%B3%E3%81%97%E8%BE%BC%E3%81%BF%E3%82%AC%E3%82%A4%E3%83%89%20-%20SIM%E3%82%AB%E3%83%BC%E3%83%89%20%E2%80%90%EF%BD%9C%E6%A0%BC%E5%AE%89SIM%E3%83%BB%E3%82%B9%E3%83%9E%E3%83%9B%E3%81%AENURO%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB&kw=%E6%A0%BC%E5%AE%89SIM,%E6%A0%BC%E5%AE%89%E3%82%B9%E3%83%9E%E3%83%9B,NURO%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB,%E3%81%8A%E7%94%B3%E3%81%97%E8%BE%BC%E3%81%BF%E3%82%AC%E3%82%A4%E3%83%89&p=https%3A%2F%2Fmobile.nuro.jp%2Fguide%2Fsim.html&r=&lt=3207&evt=pageLoad&sv=2&cdb=AQAQ&rn=900807)

![](https://api.botchan.chat/api/analytic/wc/pageview?cpid=666260145bab41507472c81b&uid=&curl=https%3A%2F%2Fmobile.nuro.jp%2Fguide%2Fsim.html&ref=&title=%E3%81%8A%E7%94%B3%E3%81%97%E8%BE%BC%E3%81%BF%E3%82%AC%E3%82%A4%E3%83%89%20-%20SIM%E3%82%AB%E3%83%BC%E3%83%89%20%E2%80%90%EF%BD%9C%E6%A0%BC%E5%AE%89SIM%E3%83%BB%E3%82%B9%E3%83%9E%E3%83%9B%E3%81%AENURO%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB&user_agent=Mozilla%2F5.0%20(Macintosh%3B%20Intel%20Mac%20OS%20X%2010_15_7)%20AppleWebKit%2F605.1.15%20(KHTML%2C%20like%20Gecko)%20Version%2F18.6%20Safari%2F605.1.15&t=1764896636576)![](https://t.co/i/adsct?bci=5&dv=UTC%26en-US%40posix%26Google%20Inc.%26Linux%20x86_64%26127%261280%26800%268%2624%261280%26800%260%26na&eci=2&event_id=7acbb8b5-175c-45f9-bc0a-79d2ba9866b2&events=%5B%5B%22pageview%22%2C%7B%7D%5D%5D&integration=advertiser&p_id=Twitter&p_user_id=0&pl_id=1e016dd9-00c3-4ca5-a02c-2f02ec9cb0b6&pt=%E3%81%8A%E7%94%B3%E3%81%97%E8%BE%BC%E3%81%BF%E3%82%AC%E3%82%A4%E3%83%89%20-%20SIM%E3%82%AB%E3%83%BC%E3%83%89%20%E2%80%90%EF%BD%9C%E6%A0%BC%E5%AE%89SIM%E3%83%BB%E3%82%B9%E3%83%9E%E3%83%9B%E3%81%AENURO%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB&tw_document_href=https%3A%2F%2Fmobile.nuro.jp%2Fguide%2Fsim.html&tw_iframe_status=0&tw_order_quantity=0&tw_sale_amount=0&txn_id=o2n66&type=javascript&version=2.3.35)![](https://analytics.twitter.com/i/adsct?bci=5&dv=UTC%26en-US%40posix%26Google%20Inc.%26Linux%20x86_64%26127%261280%26800%268%2624%261280%26800%260%26na&eci=2&event_id=7acbb8b5-175c-45f9-bc0a-79d2ba9866b2&events=%5B%5B%22pageview%22%2C%7B%7D%5D%5D&integration=advertiser&p_id=Twitter&p_user_id=0&pl_id=1e016dd9-00c3-4ca5-a02c-2f02ec9cb0b6&pt=%E3%81%8A%E7%94%B3%E3%81%97%E8%BE%BC%E3%81%BF%E3%82%AC%E3%82%A4%E3%83%89%20-%20SIM%E3%82%AB%E3%83%BC%E3%83%89%20%E2%80%90%EF%BD%9C%E6%A0%BC%E5%AE%89SIM%E3%83%BB%E3%82%B9%E3%83%9E%E3%83%9B%E3%81%AENURO%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB&tw_document_href=https%3A%2F%2Fmobile.nuro.jp%2Fguide%2Fsim.html&tw_iframe_status=0&tw_order_quantity=0&tw_sale_amount=0&txn_id=o2n66&type=javascript&version=2.3.35)![](https://t.co/i/adsct?bci=5&dv=UTC%26en-US%40posix%26Google%20Inc.%26Linux%20x86_64%26127%261280%26800%268%2624%261280%26800%260%26na&eci=2&event_id=d1c5948f-0ff9-47e3-b063-aaf53140004c&events=%5B%5B%22pageview%22%2C%7B%7D%5D%5D&integration=advertiser&p_id=Twitter&p_user_id=0&pl_id=1e016dd9-00c3-4ca5-a02c-2f02ec9cb0b6&pt=%E3%81%8A%E7%94%B3%E3%81%97%E8%BE%BC%E3%81%BF%E3%82%AC%E3%82%A4%E3%83%89%20-%20SIM%E3%82%AB%E3%83%BC%E3%83%89%20%E2%80%90%EF%BD%9C%E6%A0%BC%E5%AE%89SIM%E3%83%BB%E3%82%B9%E3%83%9E%E3%83%9B%E3%81%AENURO%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB&tw_document_href=https%3A%2F%2Fmobile.nuro.jp%2Fguide%2Fsim.html&tw_iframe_status=0&tw_order_quantity=0&tw_sale_amount=0&txn_id=o474l&type=javascript&version=2.3.35)![](https://analytics.twitter.com/i/adsct?bci=5&dv=UTC%26en-US%40posix%26Google%20Inc.%26Linux%20x86_64%26127%261280%26800%268%2624%261280%26800%260%26na&eci=2&event_id=d1c5948f-0ff9-47e3-b063-aaf53140004c&events=%5B%5B%22pageview%22%2C%7B%7D%5D%5D&integration=advertiser&p_id=Twitter&p_user_id=0&pl_id=1e016dd9-00c3-4ca5-a02c-2f02ec9cb0b6&pt=%E3%81%8A%E7%94%B3%E3%81%97%E8%BE%BC%E3%81%BF%E3%82%AC%E3%82%A4%E3%83%89%20-%20SIM%E3%82%AB%E3%83%BC%E3%83%89%20%E2%80%90%EF%BD%9C%E6%A0%BC%E5%AE%89SIM%E3%83%BB%E3%82%B9%E3%83%9E%E3%83%9B%E3%81%AENURO%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB&tw_document_href=https%3A%2F%2Fmobile.nuro.jp%2Fguide%2Fsim.html&tw_iframe_status=0&tw_order_quantity=0&tw_sale_amount=0&txn_id=o474l&type=javascript&version=2.3.35)![](https://t.co/1/i/adsct?bci=5&dv=UTC%26en-US%40posix%26Google%20Inc.%26Linux%20x86_64%26127%261280%26800%268%2624%261280%26800%260%26na&eci=3&event=%7B%7D&event_id=c741ca0f-9c69-47d5-9fe8-7ff428d7ae93&integration=advertiser&p_id=Twitter&p_user_id=0&pl_id=1e016dd9-00c3-4ca5-a02c-2f02ec9cb0b6&pt=%E3%81%8A%E7%94%B3%E3%81%97%E8%BE%BC%E3%81%BF%E3%82%AC%E3%82%A4%E3%83%89%20-%20SIM%E3%82%AB%E3%83%BC%E3%83%89%20%E2%80%90%EF%BD%9C%E6%A0%BC%E5%AE%89SIM%E3%83%BB%E3%82%B9%E3%83%9E%E3%83%9B%E3%81%AENURO%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB&tw_document_href=https%3A%2F%2Fmobile.nuro.jp%2Fguide%2Fsim.html&tw_iframe_status=0&txn_id=olnwk&type=javascript&version=2.3.35)![](https://analytics.twitter.com/1/i/adsct?bci=5&dv=UTC%26en-US%40posix%26Google%20Inc.%26Linux%20x86_64%26127%261280%26800%268%2624%261280%26800%260%26na&eci=3&event=%7B%7D&event_id=c741ca0f-9c69-47d5-9fe8-7ff428d7ae93&integration=advertiser&p_id=Twitter&p_user_id=0&pl_id=1e016dd9-00c3-4ca5-a02c-2f02ec9cb0b6&pt=%E3%81%8A%E7%94%B3%E3%81%97%E8%BE%BC%E3%81%BF%E3%82%AC%E3%82%A4%E3%83%89%20-%20SIM%E3%82%AB%E3%83%BC%E3%83%89%20%E2%80%90%EF%BD%9C%E6%A0%BC%E5%AE%89SIM%E3%83%BB%E3%82%B9%E3%83%9E%E3%83%9B%E3%81%AENURO%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB&tw_document_href=https%3A%2F%2Fmobile.nuro.jp%2Fguide%2Fsim.html&tw_iframe_status=0&txn_id=olnwk&type=javascript&version=2.3.35)![](https://t.co/i/adsct?bci=5&dv=UTC%26en-US%40posix%26Google%20Inc.%26Linux%20x86_64%26127%261280%26800%268%2624%261280%26800%260%26na&eci=2&event_id=e9f8fdaf-a190-42d7-9bb6-7f762d9bed65&events=%5B%5B%22pageview%22%2C%7B%7D%5D%5D&integration=advertiser&p_id=Twitter&p_user_id=0&pl_id=1e016dd9-00c3-4ca5-a02c-2f02ec9cb0b6&pt=%E3%81%8A%E7%94%B3%E3%81%97%E8%BE%BC%E3%81%BF%E3%82%AC%E3%82%A4%E3%83%89%20-%20SIM%E3%82%AB%E3%83%BC%E3%83%89%20%E2%80%90%EF%BD%9C%E6%A0%BC%E5%AE%89SIM%E3%83%BB%E3%82%B9%E3%83%9E%E3%83%9B%E3%81%AENURO%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB&tw_document_href=https%3A%2F%2Fmobile.nuro.jp%2Fguide%2Fsim.html&tw_iframe_status=0&tw_order_quantity=0&tw_sale_amount=0&txn_id=o2pfc&type=javascript&version=2.3.35)![](https://analytics.twitter.com/i/adsct?bci=5&dv=UTC%26en-US%40posix%26Google%20Inc.%26Linux%20x86_64%26127%261280%26800%268%2624%261280%26800%260%26na&eci=2&event_id=e9f8fdaf-a190-42d7-9bb6-7f762d9bed65&events=%5B%5B%22pageview%22%2C%7B%7D%5D%5D&integration=advertiser&p_id=Twitter&p_user_id=0&pl_id=1e016dd9-00c3-4ca5-a02c-2f02ec9cb0b6&pt=%E3%81%8A%E7%94%B3%E3%81%97%E8%BE%BC%E3%81%BF%E3%82%AC%E3%82%A4%E3%83%89%20-%20SIM%E3%82%AB%E3%83%BC%E3%83%89%20%E2%80%90%EF%BD%9C%E6%A0%BC%E5%AE%89SIM%E3%83%BB%E3%82%B9%E3%83%9E%E3%83%9B%E3%81%AENURO%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB&tw_document_href=https%3A%2F%2Fmobile.nuro.jp%2Fguide%2Fsim.html&tw_iframe_status=0&tw_order_quantity=0&tw_sale_amount=0&txn_id=o2pfc&type=javascript&version=2.3.35)![](https://t.co/i/adsct?bci=5&dv=UTC%26en-US%40posix%26Google%20Inc.%26Linux%20x86_64%26127%261280%26800%268%2624%261280%26800%260%26na&eci=2&event_id=76364261-5bec-447a-8e62-4897785f1f1d&events=%5B%5B%22pageview%22%2C%7B%7D%5D%5D&integration=advertiser&p_id=Twitter&p_user_id=0&pl_id=1e016dd9-00c3-4ca5-a02c-2f02ec9cb0b6&pt=%E3%81%8A%E7%94%B3%E3%81%97%E8%BE%BC%E3%81%BF%E3%82%AC%E3%82%A4%E3%83%89%20-%20SIM%E3%82%AB%E3%83%BC%E3%83%89%20%E2%80%90%EF%BD%9C%E6%A0%BC%E5%AE%89SIM%E3%83%BB%E3%82%B9%E3%83%9E%E3%83%9B%E3%81%AENURO%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB&tw_document_href=https%3A%2F%2Fmobile.nuro.jp%2Fguide%2Fsim.html&tw_iframe_status=0&tw_order_quantity=0&tw_sale_amount=0&txn_id=o4q08&type=javascript&version=2.3.35)![](https://analytics.twitter.com/i/adsct?bci=5&dv=UTC%26en-US%40posix%26Google%20Inc.%26Linux%20x86_64%26127%261280%26800%268%2624%261280%26800%260%26na&eci=2&event_id=76364261-5bec-447a-8e62-4897785f1f1d&events=%5B%5B%22pageview%22%2C%7B%7D%5D%5D&integration=advertiser&p_id=Twitter&p_user_id=0&pl_id=1e016dd9-00c3-4ca5-a02c-2f02ec9cb0b6&pt=%E3%81%8A%E7%94%B3%E3%81%97%E8%BE%BC%E3%81%BF%E3%82%AC%E3%82%A4%E3%83%89%20-%20SIM%E3%82%AB%E3%83%BC%E3%83%89%20%E2%80%90%EF%BD%9C%E6%A0%BC%E5%AE%89SIM%E3%83%BB%E3%82%B9%E3%83%9E%E3%83%9B%E3%81%AENURO%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB&tw_document_href=https%3A%2F%2Fmobile.nuro.jp%2Fguide%2Fsim.html&tw_iframe_status=0&tw_order_quantity=0&tw_sale_amount=0&txn_id=o4q08&type=javascript&version=2.3.35)    ![](https://t.co/i/adsct?bci=5&dv=UTC%26en-US%40posix%26Google%20Inc.%26Linux%20x86_64%26127%261280%26800%268%2624%261280%26800%260%26na&eci=1&event_id=5fc12073-f18d-4a65-8212-e96afb1a62f9&integration=advertiser&p_id=Twitter&p_user_id=0&pl_id=1e016dd9-00c3-4ca5-a02c-2f02ec9cb0b6&pt=%E3%81%8A%E7%94%B3%E3%81%97%E8%BE%BC%E3%81%BF%E3%82%AC%E3%82%A4%E3%83%89%20-%20SIM%E3%82%AB%E3%83%BC%E3%83%89%20%E2%80%90%EF%BD%9C%E6%A0%BC%E5%AE%89SIM%E3%83%BB%E3%82%B9%E3%83%9E%E3%83%9B%E3%81%AENURO%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB&tw_document_href=https%3A%2F%2Fmobile.nuro.jp%2Fguide%2Fsim.html&tw_iframe_status=0&tw_order_quantity=0&tw_sale_amount=0&txn_id=o4si0&type=javascript&version=2.3.35)![](https://analytics.twitter.com/i/adsct?bci=5&dv=UTC%26en-US%40posix%26Google%20Inc.%26Linux%20x86_64%26127%261280%26800%268%2624%261280%26800%260%26na&eci=1&event_id=5fc12073-f18d-4a65-8212-e96afb1a62f9&integration=advertiser&p_id=Twitter&p_user_id=0&pl_id=1e016dd9-00c3-4ca5-a02c-2f02ec9cb0b6&pt=%E3%81%8A%E7%94%B3%E3%81%97%E8%BE%BC%E3%81%BF%E3%82%AC%E3%82%A4%E3%83%89%20-%20SIM%E3%82%AB%E3%83%BC%E3%83%89%20%E2%80%90%EF%BD%9C%E6%A0%BC%E5%AE%89SIM%E3%83%BB%E3%82%B9%E3%83%9E%E3%83%9B%E3%81%AENURO%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB&tw_document_href=https%3A%2F%2Fmobile.nuro.jp%2Fguide%2Fsim.html&tw_iframe_status=0&tw_order_quantity=0&tw_sale_amount=0&txn_id=o4si0&type=javascript&version=2.3.35)

[![](https://img.ada-cloud.com/pattern/j4WwrCJNdOUxmRDPv1LpwIhymYB6p3DrClq9m65S.gif)](https://lin.ee/7RtURM5T)

        

![](https://img.ada-cloud.com/pattern/P7qB6TytLfqcOq27gJMTgGhEfjBtH4Vf3W1qSyJL.gif)

× LINE友だち限定で配信中🎁

![](https://t.co/1/i/adsct?bci=5&dv=UTC%26en-US%40posix%26Google%20Inc.%26Linux%20x86_64%26127%261280%26800%268%2624%261280%26800%260%26na&eci=3&event=%7B%7D&event_id=9e0bd88f-ea71-4569-a79e-7c13625f833d&integration=advertiser&p_id=Twitter&p_user_id=0&pl_id=1e016dd9-00c3-4ca5-a02c-2f02ec9cb0b6&pt=%E3%81%8A%E7%94%B3%E3%81%97%E8%BE%BC%E3%81%BF%E3%82%AC%E3%82%A4%E3%83%89%20-%20SIM%E3%82%AB%E3%83%BC%E3%83%89%20%E2%80%90%EF%BD%9C%E6%A0%BC%E5%AE%89SIM%E3%83%BB%E3%82%B9%E3%83%9E%E3%83%9B%E3%81%AENURO%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB&tw_document_href=https%3A%2F%2Fmobile.nuro.jp%2Fguide%2Fsim.html&tw_iframe_status=0&txn_id=o6c6r&type=javascript&version=2.3.35)![](https://analytics.twitter.com/1/i/adsct?bci=5&dv=UTC%26en-US%40posix%26Google%20Inc.%26Linux%20x86_64%26127%261280%26800%268%2624%261280%26800%260%26na&eci=3&event=%7B%7D&event_id=9e0bd88f-ea71-4569-a79e-7c13625f833d&integration=advertiser&p_id=Twitter&p_user_id=0&pl_id=1e016dd9-00c3-4ca5-a02c-2f02ec9cb0b6&pt=%E3%81%8A%E7%94%B3%E3%81%97%E8%BE%BC%E3%81%BF%E3%82%AC%E3%82%A4%E3%83%89%20-%20SIM%E3%82%AB%E3%83%BC%E3%83%89%20%E2%80%90%EF%BD%9C%E6%A0%BC%E5%AE%89SIM%E3%83%BB%E3%82%B9%E3%83%9E%E3%83%9B%E3%81%AENURO%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB&tw_document_href=https%3A%2F%2Fmobile.nuro.jp%2Fguide%2Fsim.html&tw_iframe_status=0&txn_id=o6c6r&type=javascript&version=2.3.35)         ![](https://t.co/1/i/adsct?bci=5&dv=UTC%26en-US%40posix%26Google%20Inc.%26Linux%20x86_64%26127%261280%26800%268%2624%261280%26800%260%26na&eci=3&event=%7B%7D&event_id=c806984b-a6ea-405a-a19e-daf1aa9aa3d9&integration=advertiser&p_id=Twitter&p_user_id=0&pl_id=1e016dd9-00c3-4ca5-a02c-2f02ec9cb0b6&pt=%E3%81%8A%E7%94%B3%E3%81%97%E8%BE%BC%E3%81%BF%E3%82%AC%E3%82%A4%E3%83%89%20-%20SIM%E3%82%AB%E3%83%BC%E3%83%89%20%E2%80%90%EF%BD%9C%E6%A0%BC%E5%AE%89SIM%E3%83%BB%E3%82%B9%E3%83%9E%E3%83%9B%E3%81%AENURO%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB&tw_document_href=https%3A%2F%2Fmobile.nuro.jp%2Fguide%2Fsim.html&tw_iframe_status=0&txn_id=odviq&type=javascript&version=2.3.35)![](https://analytics.twitter.com/1/i/adsct?bci=5&dv=UTC%26en-US%40posix%26Google%20Inc.%26Linux%20x86_64%26127%261280%26800%268%2624%261280%26800%260%26na&eci=3&event=%7B%7D&event_id=c806984b-a6ea-405a-a19e-daf1aa9aa3d9&integration=advertiser&p_id=Twitter&p_user_id=0&pl_id=1e016dd9-00c3-4ca5-a02c-2f02ec9cb0b6&pt=%E3%81%8A%E7%94%B3%E3%81%97%E8%BE%BC%E3%81%BF%E3%82%AC%E3%82%A4%E3%83%89%20-%20SIM%E3%82%AB%E3%83%BC%E3%83%89%20%E2%80%90%EF%BD%9C%E6%A0%BC%E5%AE%89SIM%E3%83%BB%E3%82%B9%E3%83%9E%E3%83%9B%E3%81%AENURO%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB&tw_document_href=https%3A%2F%2Fmobile.nuro.jp%2Fguide%2Fsim.html&tw_iframe_status=0&txn_id=odviq&type=javascript&version=2.3.35)
