# J:COM HOME | J:COM

URL: https://www.jcom.co.jp/service/home/

---

[![あたらしいを、あたりまえに。 J:COM](https://www.jcom.co.jp/common_v10/images/logo-jcom-white.svg)](https://www.jcom.co.jp/?sc_pid=common_jcomlogo_01)

*   [はじめての方へ](https://www.jcom.co.jp/beginner/?sc_pid=globalnavi_beginner_01)
    
*   ご利用中の方
*   [オンラインショップ](https://onlineshop.jcom.co.jp/?sc_pid=globalnavi_ols_01)
    

J:COMサービスご利用中の方

[ご契約内容確認・変更  \
マイページログイン](https://mypage.jcom.co.jp/?sc_pid=common_mypage_01)
 [お困りごと解決・よくあるご質問  \
お客さまサポート](https://cs.myjcom.jp/?sc_pid=common_suppot_01)
 [もっとJ:COMを楽しみたい  \
テレビ番組情報／プレゼント・優待  \
Fun! J:COM](https://www.myjcom.jp/?sc_pid=common_myj_01)

    ![検索](https://www.jcom.co.jp/common_v10/images/snav-icn-search-submit.svg)

*   [あなたへの  \
    お知らせ](https://id.zaq.ne.jp/id/script/connect/authz_req/endpoint.seam?response_type=code&client_id=JCOM_COJP&redirect_uri=https%3A%2F%2Fwww.jcom.co.jp%2Fservice%2Fhome%2F&scope=http%3A%2F%2Fjcom.co.jp%2Fconnect%2Fprofile%2Fstandard_new&nonce=1434411725&state=&prompt=)
    
*   [あなたへの  \
    お知らせ](https://www.jcom.co.jp/service/home/#)
    

Language

*   日本語
*   English
*   简体中文
*   한국어
*   Tiếng Việt
*   Português

*   サービス
*   [料金一覧](https://www.jcom.co.jp/price/)
    
*   [キャンペーン・  \
    特典](https://www.jcom.co.jp/campaign/)
    
*   お申し込み・  
    各種変更
*   サポート
*   企業サイト

[サービス紹介 トップ](https://www.jcom.co.jp/service/)

[テレビ](https://www.jcom.co.jp/service/tv/)
 [ネット](https://www.jcom.co.jp/service/net/)
 [スマホ](https://www.jcom.co.jp/service/mobile/)
 [でんき](https://www.jcom.co.jp/service/electricity/)
 [固定電話](https://www.jcom.co.jp/service/phone/)
 [ガス](https://www.jcom.co.jp/service/gas/)
 [ほけん](https://www.jcom.co.jp/service/ssi/)
 [ローン](https://www.jcom-financial.co.jp/)
 [防犯カメラ](https://www.jcom.co.jp/guide/starter/home_security/)
 [オンライン診療](https://www.jcom.co.jp/service/telemedicine/)
 [法人・自治体向けサービス![J:COM BUSINESS](https://www.jcom.co.jp/common_v10/images/logo_jcombusiness.webp)](https://business.jcom.co.jp/)

[お申し込み・お問い合わせ](https://www.jcom.co.jp/contactus/)

新規ご加入の方

[新規ご加入の方  \
お申し込み](https://onlineshop.jcom.co.jp/planSelect)

[新規ご加入の方  \
お問い合わせ](https://www.jcom.co.jp/contactus/#entry)

J:COMサービスご利用中の方

[ご利用中の方  \
各種お手続き](https://r.jcom.jp/eG4nLSC)

[お困りごと・お問い合わせ  \
（チャット）](https://prod8-live-chat.sprinklr.com/page?appId=67af27d73657336d345e4a96_app_9070639&did=CHAT_vivr_cojp_top&enableClose=true&skin=MODERN&userContext__c_679c8b53cb85b007fab0f6ea=DirectLink&utm_campaign=IVRSMS&utm_medium=referral&utm_source=did&webview=true&zoom=false)

あなたにピッタリのプランがすぐわかる

[料金シミュレーション](https://onlineshop.jcom.co.jp/Simulation/Simulation)

無料・特別料金の物件も！

対応エリア・物件をご案内

[企業サイト](https://www.jcom.co.jp/corporate/)

[企業理念](https://www.jcom.co.jp/corporate/philosophy_brand/)

[サステナビリティ](https://www.jcom.co.jp/corporate/sustainability/)

[中期経営計画](https://www.jcom.co.jp/corporate/managementplan/)

[ニュースリリース](https://newsreleases.jcom.co.jp/)

[会社案内](https://www.jcom.co.jp/corporate/company/)

[採用情報](https://recruit.jcom.co.jp/)

[サポート トップ](https://cs.myjcom.jp/)

[テレビ](https://cs.myjcom.jp/categories/support/67ab976bf07f5244a208cb97)
 [ネット](https://cs.myjcom.jp/categories/support/67ab9788f07f5244a208cced)
 [スマホ](https://cs.myjcom.jp/categories/support/67ab979df07f5244a208cdc9)
 [でんき](https://cs.myjcom.jp/categories/support/67ab97b5f07f5244a208cec9)
 [固定電話](https://cs.myjcom.jp/categories/support/67ab97abf07f5244a208ce4e)
 [ガス](https://cs.myjcom.jp/categories/support/67ab97b8f07f5244a208ceda)
 [ほけん](https://cs.myjcom.jp/categories/support/67ab97c5f07f5244a208cf2f)
 [オンライン診療](https://cs.myjcom.jp/categories/support/67ab97c2f07f5244a208cf1b)
 [ホームIoT](https://cs.myjcom.jp/categories/support/67ab97bcf07f5244a208cee6)
 [防犯カメラ](https://cs.myjcom.jp/categories/support/67ab97f5f07f5244a208d09b)

[J:COM STREAM](https://cs.myjcom.jp/categories/support/67ab97c9f07f5244a208cf49)

[えんかくサポート](https://cs.myjcom.jp/categories/support/67ab97faf07f5244a208d0c2)

[おうちサポート](https://cs.myjcom.jp/categories/support/67ab97d4f07f5244a208cf92)

[防災情報サービス](https://cs.myjcom.jp/categories/support/67ab97d8f07f5244a208cfa0)

[自転車生活サポート](https://cs.myjcom.jp/categories/support/67ab97e8f07f5244a208d023)

[J:COMブックス](https://cs.myjcom.jp/categories/support/67ab97e4f07f5244a208d003)

[WiMAX](https://cs.myjcom.jp/categories/support/67ab97f1f07f5244a208d074)

[障害・メンテナンス情報](https://information.myjcom.jp/maintenance_outage/)

各種お手続き

[パーソナルID](https://cs.myjcom.jp/categories/support/67ab9803f07f5244a208d113)

[料金・支払い](https://cs.myjcom.jp/categories/support/67ab9805f07f5244a208d139)

[引越し・建替え](https://cs.myjcom.jp/categories/support/67ab980cf07f5244a208d184)

[訪問・窓口](https://cs.myjcom.jp/categories/support/67ab980ff07f5244a208d1a4)

[契約関連](https://cs.myjcom.jp/categories/support/67ab9806f07f5244a208d150)

[休止・解約](https://cs.myjcom.jp/categories/support/67ab980cf07f5244a208d188)

[加入特典](https://cs.myjcom.jp/categories/support/67ab980df07f5244a208d18c)

[![あたらしいを、あたりまえに J:COM](https://www.jcom.co.jp/common_v10/images/logo-jcom-white.svg)](https://www.jcom.co.jp/?sc_pid=common_jcomlogo_01)

[![J:COM HOME](https://www.jcom.co.jp/common_v10/images/logo-jcom-home-bk.svg)](https://www.jcom.co.jp/service/home/)

*   防犯カメラパック
*   HOMEパック
*   [ご利用シーン](https://www.jcom.co.jp/service/home/features/)
    

[防犯カメラパック トップ](https://www.jcom.co.jp/guide/starter/home_security/)

*   [機能詳細](https://www.jcom.co.jp/service/home/security/)
    
*   [お申し込みの流れ](https://www.jcom.co.jp/service/home/security/flow/)
    

[HOMEパック トップ](https://www.jcom.co.jp/service/home/iot/)

*   [オプション端末一覧](https://www.jcom.co.jp/service/home/device/)
    
*   [お申し込みの流れ](https://www.jcom.co.jp/service/home/flow/)
    

[![あたらしいを、あたりまえに J:COM](https://www.jcom.co.jp/common_v10/images/logo-jcom.svg)](https://www.jcom.co.jp/)

*   サービス

*   [お申し込み](https://onlineshop.jcom.co.jp/planSelect)
    
*   [お問い合わせ](https://www.jcom.co.jp/contactus/)
    
*   [はじめて  \
    の方へ](https://www.jcom.co.jp/beginner/)
    
*   ご利用中  
    の方
*   [オンライン  \
    ショップ](https://onlineshop.jcom.co.jp/)
    
*   ![検索する](https://www.jcom.co.jp/common_v10/images/fixed-nav-icn-search.svg)

    ![検索](https://www.jcom.co.jp/common_v10/images/snav-icn-search-submit.svg)

J:COMサービスご利用中の方

[ご契約内容確認・変更  \
マイページログイン](https://mypage.jcom.co.jp/)
 [お困りごと解決・よくあるご質問  \
お客さまサポート](https://cs.myjcom.jp/)
 [もっとJ:COMを楽しみたい  \
テレビ番組情報／プレゼント・優待  \
Fun! J:COM](https://www.myjcom.jp/)

[サービス紹介 トップ](https://www.jcom.co.jp/service/)

[テレビ](https://www.jcom.co.jp/service/tv/)
 [ネット](https://www.jcom.co.jp/service/net/)
 [スマホ](https://www.jcom.co.jp/service/mobile/)
 [でんき](https://www.jcom.co.jp/service/electricity/)
 [固定電話](https://www.jcom.co.jp/service/phone/)
 [ガス](https://www.jcom.co.jp/service/gas/)
 [ほけん](https://www.jcom.co.jp/service/ssi/)
 [ローン](https://www.jcom-financial.co.jp/)
 [防犯カメラ](https://www.jcom.co.jp/guide/starter/home_security/)
 [オンライン診療](https://www.jcom.co.jp/service/telemedicine/)
 [法人・自治体向けサービス![J:COM BUSINESS](https://www.jcom.co.jp/common_v10/images/logo_jcombusiness.webp)](https://business.jcom.co.jp/)

[![J:COM HOME](https://www.jcom.co.jp/common_v10/images/logo-jcom-home-bk.svg)](https://www.jcom.co.jp/service/home/)

*   防犯カメラパック
*   HOMEパック
*   [ご利用シーン](https://www.jcom.co.jp/service/home/features/)
    

[防犯カメラパック トップ](https://www.jcom.co.jp/guide/starter/home_security/)

*   [機能詳細](https://www.jcom.co.jp/service/home/security/)
    
*   [お申し込みの流れ](https://www.jcom.co.jp/service/home/security/flow/)
    

[HOMEパック トップ](https://www.jcom.co.jp/service/home/iot/)

*   [オプション端末一覧](https://www.jcom.co.jp/service/home/device/)
    
*   [お申し込みの流れ](https://www.jcom.co.jp/service/home/flow/)
    

*   ![メニュー](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/text-menu.svg)
*   ![J:COM HOME メニュー](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom-home/text-menu.svg)
*   [![お申し込みの流れ](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom-home/text-entry.svg)](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=jcomhome)
    
*   [![よくある質問　お問い合わせ](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom-home/text-faq.svg)](https://cs.myjcom.jp/categorySearch?cg=ServiceOutside&c=J_COM_HOME)
    

*   [![あたらしいを、あたりまえに　J:COM](https://www.jcom.co.jp/common_v10/images/logo-jcom-only-white.svg)](https://www.jcom.co.jp/)
     ![メニューを閉じる](https://www.jcom.co.jp/common_v10/images/sp-menu/menu-close-white.svg)
    
    [J:COMのサービス](https://www.jcom.co.jp/service/)
    
    *   [![テレビ](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-tv-item.svg)](https://www.jcom.co.jp/service/tv/)
        
    *   [![ネット](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-net-item.svg)](https://www.jcom.co.jp/service/net/)
        
    *   [![スマホ](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-mobile-item.svg)](https://www.jcom.co.jp/service/mobile/)
        
    
    *   [![電気](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-electricity-item.svg)](https://www.jcom.co.jp/service/electricity/)
        
    *   [![固定電話](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-phone-item.svg)](https://www.jcom.co.jp/service/phone/)
        
    *   [![ガス](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-gas-item.svg)](https://www.jcom.co.jp/service/gas/)
        
    *   [![ほけん](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-ssi-item.svg)](https://www.jcom.co.jp/service/ssi/)
        
    *   [ローン](https://www.jcom-financial.co.jp/)
        
    *   [![ホームIoT](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-home-item.svg)](https://www.jcom.co.jp/service/home/)
        
    *   [防犯カメラ](https://www.jcom.co.jp/guide/starter/home_security/)
        
    *   [![オンライン診療](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-telemedicine-item.svg)](https://www.jcom.co.jp/service/telemedicine/)
        
    
    [法人・自治体向けサービス  \
    ![J:COM BUSINESS](https://www.jcom.co.jp/common_v10/images/logo_jcombusiness.webp)](https://business.jcom.co.jp/)
    
    サービス一覧
    
    [料金一覧](https://www.jcom.co.jp/price/)
     [キャンペーン・特典](https://www.jcom.co.jp/campaign/)
     [サポート](https://cs.myjcom.jp/)
     [お申し込み・各種変更](https://www.jcom.co.jp/contactus/)
    
        ![検索](https://www.jcom.co.jp/common_v10/images/snav-icn-search-submit-sp.svg)
    
    [J:COM トップ](https://www.jcom.co.jp/)
    
    *   [サービス情報](https://www.jcom.co.jp/)
        
    *   [オンライン  \
        ショップ](https://onlineshop.jcom.co.jp/)
        
    *   [サポート](https://cs.myjcom.jp/)
        
    *   [Fun! J:COM](https://www.myjcom.jp/)
        
    *   [マイページ](https://mypage.jcom.co.jp/)
        
    *   [企業サイト](https://www.jcom.co.jp/corporate/)
        
    
*   [![J:COM HOME](https://www.jcom.co.jp/common_v10/images/icn-jcom-home.svg)ホームIoT](https://www.jcom.co.jp/service/home/)
     ![メニューを閉じる](https://www.jcom.co.jp/common_v10/images/sp-menu/menu-close-white.svg)
    
    [![](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom-home/slide/menu/mv-middle.jpg)\
    \
    暮らしをもっと安心・便利に\
    \
    トップ](https://www.jcom.co.jp/service/home/)
    
    *   防犯カメラパック
        
        *   [防犯カメラパック トップ](https://www.jcom.co.jp/guide/starter/home_security/)
            
        *   [機能詳細](https://www.jcom.co.jp/service/home/security/)
            
        *   [お申し込みの流れ](https://www.jcom.co.jp/service/home/security/flow/)
            
        
    *   HOMEパック
        
        *   [HOMEパック トップ](https://www.jcom.co.jp/service/home/iot/)
            
        *   [オプション端末一覧](https://www.jcom.co.jp/service/home/device/)
            
        *   [お申し込みの流れ](https://www.jcom.co.jp/service/home/flow/)
            
        
    *   [ご利用シーン](https://www.jcom.co.jp/service/home/features/)
        
    

![J:COM](https://www.jcom.co.jp/common_v10/images/icn-jcom-home.svg)

![HOME](https://www.jcom.co.jp/common_v10/images/logo-jcom-home.svg)

  [![防犯カメラ 手頃な価格で安心のセキュリティー](https://www.jcom.co.jp/service/home/images_v10/hero-img-7.jpg)](https://www.jcom.co.jp/guide/starter/home_security/)

[J:COM HOME  \
おすすめの理由](https://www.jcom.co.jp/service/home/#anc-recommend)

[J:COM HOMEとは](https://www.jcom.co.jp/service/home/#anc-about)

[J:COM HOMEで  \
できること](https://www.jcom.co.jp/service/home/#anc-pack)

[よくあるご質問](https://www.jcom.co.jp/service/home/#anc-faq)

[ご検討中の方  \
お申し込み](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=jcomhome)

[ご利用中の方  \
サービスの  \
追加・変更](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=jcomhome)

[お電話でお問い合わせ  \
（通話無料）  \
0120-999-000  \
9:00～18:00［年中無休］](https://jcom.tolfa.jp/8703ce7c5cf98304e8df170cbd160362/1233676884/)
 9:00～18:00［年中無休］ 次の画面で![マイクアイコン](https://www.jcom.co.jp/service/home/images_v10/tolfa_mic_2.png)を押してください

[お困りごと・  \
お問い合わせ](https://cs.myjcom.jp/categories/support/67ab97bcf07f5244a208cee6)

J:COM HOMEおすすめの理由
-----------------

*   [![お家を守る防犯カメラ](https://www.jcom.co.jp/service/home/images_v10/recommend_1.png)](https://www.jcom.co.jp/service/home/#recommend1)
    
*   [![音声・アプリで暮らし快適！](https://www.jcom.co.jp/service/home/images_v10/recommend_2.png)](https://www.jcom.co.jp/service/home/#recommend2)
    
*   [![設定・設置はおまかせ](https://www.jcom.co.jp/service/home/images_v10/recommend_3.png)](https://www.jcom.co.jp/service/home/#recommend3)
    

J:COM HOMEとは
------------

![](https://www.jcom.co.jp/service/home/images_v10/about2.webp)

かんたん設置でご家庭の防犯対策ができる、一戸建て向けの防犯カメラパックと、専用端末を設置・設定するだけで外出先から家電操作ができるようになるHOMEパックをご利用いただけます。  
専用アプリでかんたんに操作することができ、今の暮らしをもっと安心に、もっと便利にします。

### サービス紹介

防犯カメラパック

![](https://www.jcom.co.jp/service/home/images_v10/service_01.webp)

一戸建て向け防犯カメラは、設置・設定もおまかせ。スマホからのお手軽操作で、安心のセキュリティーをご提供します。

[防犯カメラパックを詳しく見る](https://www.jcom.co.jp/guide/starter/home_security/)

HOMEパック

![](https://www.jcom.co.jp/service/home/images_v10/service_02.webp)

手が離せないときに音声で家電を操作したり、帰宅前に照明やエアコンをつけたり、家電をコントロールすることができます。

[HOMEパックを詳しく見る](https://www.jcom.co.jp/service/home/iot/)

J:COM HOMEおすすめの理由
-----------------

POINT01

手頃な価格で  
安心のセキュリティ  
**お家を守る防犯カメラ新登場！**

[防犯カメラについて詳しく見る](https://www.jcom.co.jp/guide/starter/home_security/)

![手頃な価格で安心のセキュリティ お家を守る防犯カメラ新登場！](https://www.jcom.co.jp/service/home/images_v10/recommend-point4.webp)

POINT02

音声やアプリで  
**暮らしに安心･便利･楽しさ**をプラス

[ご利用シーンを詳しく見る](https://www.jcom.co.jp/service/home/features/)

![音声やアプリで暮らしに安心・便利・楽しさをプラス](https://www.jcom.co.jp/service/home/images_v10/recommend-point1.webp)

POINT03

設定・設置は  
**J:COMにおまかせ**

[防犯カメラパックのサポートを見る](https://www.jcom.co.jp/service/home/security/flow/#anc-02)

[HOMEパックのサポートを見る](https://www.jcom.co.jp/service/home/flow/#anc-02)

![設定・設置はJ:COMにおまかせ](https://www.jcom.co.jp/service/home/images_v10/recommend-point3.webp)

J:COM HOMEでできること
----------------

防犯カメラパック

![](https://www.jcom.co.jp/service/home/images_v10/case_01.webp)

かんたん設置で安心見守り

玄関前や家の死角に設置するだけで抑止効果アップ。

HOMEパック

![](https://www.jcom.co.jp/service/home/images_v10/case_02.webp)

ペットのお留守番をサポート

外出先からカメラを通して、自宅のペットの様子を確認。

HOMEパック

![](https://www.jcom.co.jp/service/home/images_v10/case_03.webp)

家電を音声で操作

音声で照明のON/OFFなど家電の操作が簡単にできます。

[ご利用シーンを見る](https://www.jcom.co.jp/service/home/features/)

セットでおすすめ・  
人気サービス
------------------

 [![](https://www.jcom.co.jp/images_v10/img-service-net.webp)\
\
![](https://www.jcom.co.jp/common_v10/images/icn-jcom-net.svg) ネット\
\
もっと速く、もっと快適に](https://www.jcom.co.jp/service/net/?sc_pid=common_service_net)
 [![](https://www.jcom.co.jp/images_v10/img-service-mobile.webp)\
\
![](https://www.jcom.co.jp/common_v10/images/icn-jcom-mobile.svg) スマホ\
\
セットなら、  \
スマホのデータず～っと増量！](https://www.jcom.co.jp/service/mobile/?sc_pid=common_service_mobile_02)
 [![](https://www.jcom.co.jp/images_v10/img-service-tv.webp)\
\
![](https://www.jcom.co.jp/common_v10/images/icn-jcom-tv.svg) テレビ\
\
専門チャンネルが  \
あなたの”見たい”を叶える。](https://www.jcom.co.jp/service/tv/?sc_pid=common_service_tv)
 [![](https://www.jcom.co.jp/images_v10/img-service-electricity.webp)\
\
![](https://www.jcom.co.jp/common_v10/images/icn-jcom-electricity.svg) でんき\
\
品質そのまままとめて便利](https://www.jcom.co.jp/service/electricity/?sc_pid=common_service_ele)

キャンペーン・特典
---------

[![防犯カメラ](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_construction_discount_sp_v2.webp)](https://www.jcom.co.jp/campaign/home_security/)

[キャンペーン・特典](https://www.jcom.co.jp/campaign/)

お客さまの声
------

*   ### スマホで手軽に  
    映像が確認できる
    
    外出先からも手軽に映像の確認が出来て、保存期間も長い点が良かったです。
    
    30代／女性
    
*   ### 防犯カメラの設置で  
    抑止力に
    
    防犯カメラを設置して、抑止力にもなるし、何かあった時など録画されているのでとても安心です。精神的に凄く安心感がありますね。
    
    40代／男性
    
*   ### 録画の検索も  
    わかりやすい
    
    大手の駆けつけは不要だったので、サービス的に丁度良いです。録画が日付検索と時間で確認出来るのでわかりやすいですね。
    
    40代／女性
    
*   ### 子供の見守りにも  
    あんしん
    
    子供の行き帰りが一人の時など、安全面で役に立っているし、安心出来ます。
    
    40代／男性
    
*   ### 画像が鮮明で  
    防犯の役目に十分
    
    カメラの撮影範囲が広く画像も鮮明でいつもチェックできるのがよいです。防犯の役目には十分だと思います。
    
    60代以上／男性
    
*   ### ライトが点灯するから  
    防犯に効果的
    
    夜間、人が通ると明かりがつくので、防犯に効果的だと思っています。
    
    50代／女性
    

[ご検討中の方  \
お申し込み](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=jcomhome)

[ご利用中の方  \
サービスの  \
追加・変更](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=jcomhome)

[お電話でお問い合わせ  \
（通話無料）  \
0120-999-000  \
9:00～18:00［年中無休］](https://jcom.tolfa.jp/8703ce7c5cf98304e8df170cbd160362/1233676884/)
 9:00～18:00［年中無休］ 次の画面で![マイクアイコン](https://www.jcom.co.jp/service/home/images_v10/tolfa_mic_2.png)を押してください

[お困りごと・  \
お問い合わせ](https://cs.myjcom.jp/categories/support/67ab97bcf07f5244a208cee6)

よくあるご質問
-------

ご利用開始までの流れが知りたい。

HOMEパックについては、[こちら](https://www.jcom.co.jp/service/home/flow/)
でご案内しています。

防犯カメラパックについては[こちら](https://www.jcom.co.jp/service/home/security/)
でご案内しています。

TV、NET、PHONEなどの他サービスについては、[こちら](https://www.jcom.co.jp/contactus/#anc01)
でご案内しています。

日本全国、どこに住んでいても契約できる？

J:COM HOMEは、J:COMのサービス提供エリア内にお住いのお客さまのみご契約いただるサービスとなります。提供エリア外の方はお申し込みいただけません。  
あらかじめご了承ください。

加入後トラブルが起きた場合どうすればよい？

お電話でのサポート、訪問サポート、Webサイトにてご対応いたします。

[サポートサイト](https://cs.myjcom.jp/)

お役立ちコラム
-------

![屋外用ネットワークカメラ](https://www.jcom.co.jp/service/home/images_v10/column.webp)

J:COM HOMEにまつわるさまざまな情報をお届けします。

[詳しく見る](https://www.jcom.co.jp/service/home/column/)

[シェアする](https://www.jcom.co.jp/service/home/)

[Tweet](https://twitter.com/share?ref_src=twsrc%5Etfw)

【税込金額について】

*   表記の金額は特に記載のある場合を除き税込金額。
*   インボイス制度下における消費税の端数処理方法変更により消費税差額が生じる場合があります。

1.  [J:COM トップ](https://www.jcom.co.jp/)
    
2.  [サービス案内](https://www.jcom.co.jp/service/)
    
3.  J:COM HOME

[![ページ上部へ戻る](https://www.jcom.co.jp/common_v10/images/PageTop.webp)](https://www.jcom.co.jp/service/home/#header)

[ページトップへ戻る](https://www.jcom.co.jp/service/home/#header)

[サービス情報](https://www.jcom.co.jp/?sc_pid=common_footer_unav_service_01)

[オンラインショップ](https://onlineshop.jcom.co.jp/?sc_pid=common_footer_unav_ols_01)

[サポートお困りごと解決・よくあるご質問](https://cs.myjcom.jp/?sc_pid=common_footer_unav_csmyjcom_01)

[Fun! J:COMテレビ番組情報／プレゼント・優待](https://www.myjcom.jp/?sc_pid=common_footer_unav_myjcom_01)

[マイページ契約内容確認・変更](https://mypage.jcom.co.jp/?sc_pid=common_footer_unav_mypage_01)

[企業サイト](https://www.jcom.co.jp/corporate/?sc_pid=common_footer_unav_corporate_01)

*   [![Twitter](https://www.jcom.co.jp/common_v10/images/icn-x.svg)](https://twitter.com/jcom_info?sc_pid=common_footer_sns_twitter_01)
    
*   [![instagram](https://www.jcom.co.jp/common_v10/images/icn-instagram.svg)](https://www.instagram.com/jcom.official/?sc_pid=common_footer_sns_instagram_01)
    
*   [![Facebook](https://www.jcom.co.jp/common_v10/images/icn-facebook.svg)](https://www.facebook.com/JCOM.ZAQ?sc_pid=common_footer_sns_facebook_01)
    
*   [![LINE](https://www.jcom.co.jp/common_v10/images/icn-line.svg)](https://www.jcom.co.jp/social/campaign/line/?sc_pid=common_footer_sns_line_01)
    
*   [![note](https://www.jcom.co.jp/common_v10/images/icn-note.svg)](https://note.jcom.co.jp/?sc_pid=common_footer_sns_note_01)
    

[アカウント一覧](https://www.jcom.co.jp/service/social/?sc_pid=common_footer_sns_list_01)

[![あたらしいを、あたりまえに J:COMはおかげさまで30周年。 J:COM 30th ANNIVERSARY](https://www.jcom.co.jp/common_v10/images/logo-jcom-horizontal.svg)](https://www.jcom.co.jp/special/30th/)

*   [サイトマップ](https://www.jcom.co.jp/sitemap/?sc_pid=common_footer_sitemap)
    
*   [プライバシーポータル](https://www.jcom.co.jp/corporate/site_info/privacy-portal/?sc_pid=common_footer_privacybasic)
    
*   [プライバシーポリシー](https://www.jcom.co.jp/corporate/site_info/privacy_policy/?sc_pid=common_footer_privacy)
    
*   [ウェブアクセシビリティの取り組み](https://www.jcom.co.jp/corporate/site_info/accessibility/?sc_pid=common_footer_accessibility)
    
*   [セキュリティーポリシー](https://www.jcom.co.jp/corporate/site_info/security_policy/?sc_pid=common_footer_security)
    
*   [ソーシャルメディアポリシー](https://www.jcom.co.jp/corporate/site_info/socialmedia_policy/?sc_pid=common_footer_social)
    
*   [人権方針](https://www.jcom.co.jp/corporate/sustainability/well_being/hrp/?sc_pid=common_footer_hrp#policy)
    
*   [Cookie情報の利用、広告配信などについて](https://www.jcom.co.jp/corporate/site_info/privacy_policy/cookie/?sc_pid=common_footer_cookie)
    
*   [お問い合わせ](https://www.jcom.co.jp/contactus/?sc_pid=common_footer_contactus)
    
*   [企業サイト](https://www.jcom.co.jp/corporate/?sc_pid=common_footer_corporate)
    
*   [採用情報](https://recruit.jcom.co.jp/?sc_pid=common_footer_recruit)
    
*   [法人のお客さま](https://business.jcom.co.jp/?sc_pid=common_footer_business)
    
*   [当サイトについて](https://www.jcom.co.jp/site_info/?sc_pid=common_footer_siteinfo)
    

Copyright © JCOM Co., Ltd. All Rights Reserved.

[](https://www.jcom.co.jp/service/home/#)

エリアを設定する

郵便番号を入力してください。

〒

ハイフン（-）は不要です

住居タイプを選択してください。

![icon](https://www.jcom.co.jp/common_v10/images/icn-apartment.svg)集合住宅

![icon](https://www.jcom.co.jp/common_v10/images/icn-house.svg)戸建住宅

該当する年齢を選択してください。  
（ご紹介できるプランが変わります。）

27歳以上

26歳以下

22歳以下

次へ

[](https://www.jcom.co.jp/service/home/#)

エリアを設定する

郵便番号を入力してください。

〒

 

住居タイプを選択してください。

![icon](https://www.jcom.co.jp/common_v10/images/icn-apartment.svg)集合住宅

![icon](https://www.jcom.co.jp/common_v10/images/icn-house.svg)戸建住宅

次へ

[](https://www.jcom.co.jp/service/home/#)

エリアを設定する

郵便番号を入力してください。

〒

 

住居タイプを選択してください。

![icon](https://www.jcom.co.jp/common_v10/images/icn-apartment.svg)集合住宅

![icon](https://www.jcom.co.jp/common_v10/images/icn-house.svg)戸建住宅

次へ

[](https://www.jcom.co.jp/service/home/#)

エリアを設定する

郵便番号を入力してください。

〒

ハイフン（-）は不要です

次へ

[](https://www.jcom.co.jp/service/home/#)

エリアを設定する

郵便番号を入力してください。

〒

 

住居タイプを選択してください。

![icon](https://www.jcom.co.jp/common_v10/images/icn-apartment.svg)集合住宅

![icon](https://www.jcom.co.jp/common_v10/images/icn-house.svg)戸建住宅

次へ

[](https://www.jcom.co.jp/service/home/#)

サービスの確認

転居先の郵便番号を入力してください。

〒

 

次へ

[](https://www.jcom.co.jp/service/home/#)

J:COM オンライン診療　提供エリアの確認

郵便番号を入力してください。

〒

ハイフン（-）は不要です

住居タイプを選択してください。

![icon](https://www.jcom.co.jp/common_v10/images/icn-apartment.svg)集合住宅

![icon](https://www.jcom.co.jp/common_v10/images/icn-house.svg)戸建住宅

次へ

[](https://www.jcom.co.jp/service/home/#)

都道府県を選択

必須都道府県を選択してください。

北海道・東北

[北海道](https://www.jcom.co.jp/service/home/#)
 [宮城県](https://www.jcom.co.jp/service/home/#)

関東

[東京都](https://www.jcom.co.jp/service/home/#)
 [神奈川県](https://www.jcom.co.jp/service/home/#)
 [千葉県](https://www.jcom.co.jp/service/home/#)
 [埼玉県](https://www.jcom.co.jp/service/home/#)
 [群馬県](https://www.jcom.co.jp/service/home/#)
 [茨城県](https://www.jcom.co.jp/service/home/#)

関西

[大阪府](https://www.jcom.co.jp/service/home/#)
 [京都府](https://www.jcom.co.jp/service/home/#)
 [和歌山県](https://www.jcom.co.jp/service/home/#)
 [兵庫県](https://www.jcom.co.jp/service/home/#)

九州・山口

[福岡県](https://www.jcom.co.jp/service/home/#)
 [熊本県](https://www.jcom.co.jp/service/home/#)
 [大分県](https://www.jcom.co.jp/service/home/#)
 [山口県](https://www.jcom.co.jp/service/home/#)

[戻る](https://www.jcom.co.jp/service/home/#)

[](https://www.jcom.co.jp/service/home/#)

市区町村を選択

必須市区町村を選択してください。

現在の選択：東京都

*   あ
*   か
*   さ
*   た
*   な
*   は
*   ま
*   や
*   ら
*   わ

[昭島市](https://www.jcom.co.jp/service/home/#)
 [あきる野市](https://www.jcom.co.jp/service/home/#)
 [足立区](https://www.jcom.co.jp/service/home/#)
 [板橋区](https://www.jcom.co.jp/service/home/#)
 [稲城市](https://www.jcom.co.jp/service/home/#)
 [江戸川区](https://www.jcom.co.jp/service/home/#)
 [大田区](https://www.jcom.co.jp/service/home/#)

「か」のコンテンツ内容

「あ」行から始まる地域

[昭島市](https://www.jcom.co.jp/service/home/#)
 [あきる野市](https://www.jcom.co.jp/service/home/#)
 [足立区](https://www.jcom.co.jp/service/home/#)
 [板橋区](https://www.jcom.co.jp/service/home/#)
 [稲城市](https://www.jcom.co.jp/service/home/#)
 [江戸川区](https://www.jcom.co.jp/service/home/#)
 [大田区](https://www.jcom.co.jp/service/home/#)

「か」行から始まる地域

「さ」行から始まる地域

「た」行から始まる地域

「な」行から始まる地域

[戻る](https://www.jcom.co.jp/service/home/#)

[](https://www.jcom.co.jp/service/home/#)

エリアを設定する

〒 1070052

ご入力いただいた郵便番号には、複数のエリア候補があります。  
以下のリストから住所を選択してください

選択して下さい 1 2 3 テキストテキストテキスト

設定する

[戻る](https://www.jcom.co.jp/service/home/#)

[](https://www.jcom.co.jp/service/home/#)

エリアを設定する

〒 \-------

続く住所情報を選択してください。

  

選択して下さい 1 2 3 テキストテキストテキスト

次へ

[戻る](https://www.jcom.co.jp/service/home/#)

[](https://www.jcom.co.jp/service/home/#)

ギガ提供エリアの確認

〒 1070052 (J:COM 町田・川崎)は

J:COM NET 1Gコース  
の提供エリアです。

※ 「J:COM NET 1Gコース」はケーブルテレビ回線でご利用いただける1ギガサービスです。

光10G・5G・1Gコース  
の提供エリアです。

※ 光は一部エリアで未提供（順次拡大）[詳しくはこちらよりお問い合わせください](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

光10G・5G・1Gコース※1  
の提供エリア拡大中です。

J:COM NET 1Gコース※2  
の提供エリアです。

※1 光は一部エリアで未提供（順次拡大）[詳しくはこちらよりお問い合わせください](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

※2 「J:COM NET 1Gコース」はケーブルテレビ回線でご利用いただける1ギガサービスです。

光10G・5G・1Gコース  
J:COM NET 1Gコース  
の提供エリアです。

※ 一部エリアで未提供（順次拡大）[詳しくはこちらよりお問い合わせください](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

※ 「J:COM NET 1Gコース」はケーブルテレビ回線でご利用いただける1ギガサービスです。

J:COM NET 1Gコース  
の提供エリア外です。（順次提供エリア拡大中）

320Mコース  
の提供エリアです。

320Mコース  
の提供エリアです。

J:COM NET 1Gコースの提供エリアは順次拡大中です。

[提供エリアの詳しい情報はこちらよりお問い合わせください](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

J:COM大分（大分ケーブルテレコム株式会社）のサービスエリアです。  
[J:COM大分（大分ケーブルテレコム株式会社）のホームページ](https://wwwjcom.oct-net.ne.jp/)
をご覧ください。

横浜ケーブルビジョン（YCV）のサービスエリアです。  
[横浜ケーブルビジョン（YCV）のホームページ](https://www.catv-yokohama.ne.jp/)
をご覧ください。

[お申し込み](https://www.jcom.co.jp/sim_contact/entry_request.php?refresh=new&net_service=1)

[お申し込みの流れを確認する](https://www.jcom.co.jp/service/guide/sdu/)

一部地域は提供エリア外の場合があります。

[料金・コースを見る](https://www.jcom.co.jp/service/net/)

戻る

[](https://www.jcom.co.jp/service/home/#)

ギガ提供エリアの確認

〒 1070052 (町田・川崎)は

光 10G・5G・1Gコース  
J:COM NET 1Gコース  
の提供エリアです。

※ 「J:COM NET 1Gコース」はケーブルテレビ回線でご利用いただける1ギガサービスです。

光 10G・5G・1Gコース  
の提供エリアです。

光 1Gコース  
J:COM NET 1Gコース  
の提供エリアです。

※ 「J:COM NET 1Gコース」はケーブルテレビ回線でご利用いただける1ギガサービスです。

光 1Gコース  
の提供エリアです。

320Mコース  
の提供エリアです。

[お申し込み](https://www.jcom.co.jp/sim_contact/entry_request.php?refresh=new&net_service=1)

[お申し込みの流れを確認する](https://www.jcom.co.jp/service/guide/sdu/)

一部地域は提供エリア外の場合があります。

料金・コースを見る

[料金シミュレーション](https://onlineshop.jcom.co.jp/Simulation/Simulation)

戻る

[](https://www.jcom.co.jp/service/home/#)

ギガ提供エリアの確認

〒 1070052 

J:COM NET  
の提供エリア外です。

J:COM WiMAX  
の提供エリアです。

[お申し込み](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=wimax2p)

[お申し込みの流れを確認する](https://www.jcom.co.jp/service/guide/sdu/)

一部地域は提供エリア外の場合があります。

[料金・コースを見る](https://www.jcom.co.jp/service/wimax/)

戻る

[](https://www.jcom.co.jp/service/home/#)

提供エリアの確認

〒 \------- 

J:COM大分（大分ケーブルテレコム株式会社）のサービスエリアです。  
[J:COM大分（大分ケーブルテレコム株式会社）のホームページ](https://wwwjcom.oct-net.ne.jp/)
をご覧ください。

横浜ケーブルビジョン（YCV）のサービスエリアです。  
[横浜ケーブルビジョン（YCV）のホームページ](https://www.catv-yokohama.ne.jp/)
をご覧ください。

以下のサービスをご利用いただけます。

   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-mobile.svg) ![J:COM MOBILE](https://www.jcom.co.jp/common_v10/images/logo-jcom-mobile.svg)](https://www.jcom.co.jp/service/mobile/)   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-electricity.svg) ![J:COM でんき](https://www.jcom.co.jp/common_v10/images/logo-jcom-electricity.svg)](https://www.jcom.co.jp/service/electricity/)
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-gas.svg) ![J:COM ガス](https://www.jcom.co.jp/common_v10/images/logo-jcom-gas.svg)](https://www.jcom.co.jp/service/gas/)
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-ssi.svg) ![J:COM ほけん](https://www.jcom.co.jp/common_v10/images/logo-jcom-ssi.svg)](https://www.jcom.co.jp/service/ssi/)
  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-telemedicine.svg) ![J:COM オンライン診療](https://www.jcom.co.jp/common_v10/images/logo-jcom-telemedicine.svg)](https://www.jcom.co.jp/service/telemedicine/)

以下サービスは[料金シミュレーション](https://onlineshop.jcom.co.jp/Simulation/Simulation)
で  
エリアをご確認ください。

  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-net.svg)\
\
![J:COM NET](https://www.jcom.co.jp/common_v10/images/logo-jcom-net.svg) 光10G/光1G](https://www.jcom.co.jp/price/hikari-n/)  ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-tv.svg) 地デジ・BSデジ  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-phone.svg) ひかり電話](https://www.jcom.co.jp/price/hikari-n/phone-op/)

J:COM NETは NTT回線でご提供となります。

[お申し込み](https://onlineshop.jcom.co.jp/planSelect)

[料金シミュレーション](https://onlineshop.jcom.co.jp/Simulation/Simulation)

地域のケーブルテレビをご希望の方は [こちら](https://www.catv-jcta.jp/search/index)

戻る

お住まいの地域によって、一部サービスがご利用いただけない場合がございます。

[](https://www.jcom.co.jp/service/home/#)

サービスの確認

〒 1070052 は

J:COM大分（大分ケーブルテレコム株式会社）のサービスエリアです。提供サービスの確認は、[J:COM大分（大分ケーブルテレコム株式会社）のホームページ](https://wwwjcom.oct-net.ne.jp/)
をご覧ください。

横浜ケーブルビジョン（YCV）のサービスエリアです。  
[横浜ケーブルビジョン（YCV）のホームページ](https://www.catv-yokohama.ne.jp/)
をご覧ください。

以下のサービスをご利用いただけます。

   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-tv.svg) ![J:COM TV](https://www.jcom.co.jp/common_v10/images/logo-jcom-tv.svg)](https://www.jcom.co.jp/service/tv/)   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-net.svg) ![J:COM NET](https://www.jcom.co.jp/common_v10/images/logo-jcom-net.svg)](https://www.jcom.co.jp/service/net/)
  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-mobile.svg) ![J:COM MOBILE](https://www.jcom.co.jp/common_v10/images/logo-jcom-mobile.svg)](https://www.jcom.co.jp/service/mobile/)
  
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-phone.svg) ![J:COM PHONE](https://www.jcom.co.jp/common_v10/images/logo-jcom-phone.svg)](https://www.jcom.co.jp/service/phone/)   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-ssi.svg) ![J:COM ほけん](https://www.jcom.co.jp/common_v10/images/logo-jcom-ssi.svg)](https://www.jcom.co.jp/service/ssi/)
  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-telemedicine.svg) ![J:COM オンライン診療](https://www.jcom.co.jp/common_v10/images/logo-jcom-telemedicine.svg)](https://www.jcom.co.jp/service/telemedicine/)

[J:COMご加入中の方  \
お引越しのお手続き](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=contact_move)

郵便番号入力に戻る

[](https://www.jcom.co.jp/service/home/#)

提供エリアの確認

〒 1070052 (J:COM 町田・川崎)は

以下のサービスをご利用いただけます。

   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-tv.svg) ![J:COM TV](https://www.jcom.co.jp/common_v10/images/logo-jcom-tv.svg)](https://www.jcom.co.jp/service/tv/)   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-net.svg) ![J:COM NET](https://www.jcom.co.jp/common_v10/images/logo-jcom-net.svg)](https://www.jcom.co.jp/service/net/)
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-mobile.svg) ![J:COM MOBILE](https://www.jcom.co.jp/common_v10/images/logo-jcom-mobile.svg)](https://www.jcom.co.jp/service/mobile/)
  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-electricity.svg) ![J:COM でんき](https://www.jcom.co.jp/common_v10/images/logo-jcom-electricity.svg)](https://www.jcom.co.jp/service/electricity/)
  
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-phone.svg) ![J:COM PHONE](https://www.jcom.co.jp/common_v10/images/logo-jcom-phone.svg)](https://www.jcom.co.jp/service/phone/)   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-gas.svg) ![J:COM ガス](https://www.jcom.co.jp/common_v10/images/logo-jcom-gas.svg)](https://www.jcom.co.jp/service/gas/)
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-ssi.svg) ![J:COM ほけん](https://www.jcom.co.jp/common_v10/images/logo-jcom-ssi.svg)](https://www.jcom.co.jp/service/ssi/)
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-home.svg) ![J:COM HOME](https://www.jcom.co.jp/common_v10/images/logo-jcom-home.svg)](https://www.jcom.co.jp/service/home/)
  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-telemedicine.svg) ![J:COM オンライン診療](https://www.jcom.co.jp/common_v10/images/logo-jcom-telemedicine.svg)](https://www.jcom.co.jp/service/telemedicine/)

[お申し込み](https://onlineshop.jcom.co.jp/planSelect)
 [お申し込み](https://onlineshop.jcom.co.jp/planSelect)

[お申し込みの流れを確認する](https://www.jcom.co.jp/service/guide/sdu/)

料金シミュレーション

戻る

[](https://www.jcom.co.jp/service/home/#)

サービスの確認

〒 1070052 (J:COM 町田・川崎)は

以下のサービスをご利用いただけます。

   ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-tv.svg) ![J:COM TV](https://www.jcom.co.jp/common_v10/images/logo-jcom-tv.svg) ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-net.svg) ![J:COM NET](https://www.jcom.co.jp/common_v10/images/logo-jcom-net.svg)  ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-mobile.svg) ![J:COM MOBILE](https://www.jcom.co.jp/common_v10/images/logo-jcom-mobile.svg)  ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-electricity.svg) ![J:COM でんき](https://www.jcom.co.jp/common_v10/images/logo-jcom-electricity.svg)  
   ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-phone.svg) ![J:COM PHONE](https://www.jcom.co.jp/common_v10/images/logo-jcom-phone.svg) ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-gas.svg) ![J:COM ガス](https://www.jcom.co.jp/common_v10/images/logo-jcom-gas.svg)  ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-home.svg) ![J:COM HOME](https://www.jcom.co.jp/common_v10/images/logo-jcom-home.svg)

[J:COMご加入中の方  \
お引越しのお手続き](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=contact_move)

郵便番号入力に戻る

[](https://www.jcom.co.jp/service/home/#)

提供エリアの確認

サービスをお選びください。

テレビとネットがセットでおトク！

 ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-tv.svg)  
![J:COM TV](https://www.jcom.co.jp/common_v10/images/logo-jcom-tv.svg)![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-net.svg)  
![J:COM NET](https://www.jcom.co.jp/common_v10/images/logo-jcom-net.svg) ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-phone.svg)  
![J:COM PHONE](https://www.jcom.co.jp/common_v10/images/logo-jcom-phone.svg)

[料金シミュレーション](https://onlineshop.jcom.co.jp/Simulation/Simulation)

月々のスマホ代をもっとおトクに。

![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-mobile.svg)  
![J:COM MOBILE](https://www.jcom.co.jp/common_v10/images/logo-jcom-mobile.svg)

[料金シミュレーション](https://www.jcom.co.jp/service/mobile/simulator/)

戻る

[](https://www.jcom.co.jp/service/home/#)

J:COM ガス提供エリアの確認

〒 1070052 (J:COM ----)は

![](https://www.jcom.co.jp/common_form/img/common/logo/logo_gas_osaka.png)

の提供エリアです。

一部地域は提供エリア外の場合があります。

![](https://www.jcom.co.jp/common_form/img/common/logo/logo_gas_tokyo.png)

の提供エリアです。

一部地域は提供エリア外の場合があります。

![](https://www.jcom.co.jp/common_form/img/common/logo/logo_gas_keiyo.png)

の提供エリアです。

一部地域は提供エリア外の場合があります。

J:COM ガス  
の提供エリア外です。

（株）エナジー宇宙の【越谷・春日部地区/蓮田南地区】【取手・我孫子地区】の  
都市ガス供給エリアにお住まいの方は

東京ガス for J:COM「ずっともガス」

がご利用いただけます。

[詳しく見る](https://www.jcom.co.jp/service/tokyo_gas/)

J:COM ガス  
の提供エリア外です。

戻る

[](https://www.jcom.co.jp/service/home/#)

J:COM オンライン診療　提供エリアの確認

〒 1070052 (J:COM ----)は

J:COM オンライン診療  
の提供エリアです。

一部地域は提供エリア外の場合があります。

[医療機関一覧を見る](https://www.jcom.co.jp/service/telemedicine/clinic/)

[料金を見る](https://www.jcom.co.jp/service/telemedicine/price/)

J:COM オンライン診療  
の提供エリア外です。

戻る

    

[](https://www.jcom.co.jp/service/home/#)

あなたへのお知らせ
---------

[ログアウト](https://www.jcom.co.jp/common/logout.html)
