# 格安SIM/格安スマホ・インターネットサービスのIIJmio

URL: https://www.iijmio.jp/

---

[![IIJmioロゴ](https://www.iijmio.jp/image/logo.jpg)](https://www.iijmio.jp/)

  

*   [![IPv6接続状態](https://www.iijmio.jp/image/hn_ipv4.gif)](https://www.iijmio.jp/guide/outline/ipv6/icon/)
    

[![メッセージあり](https://www.iijmio.jp/image/message.jpg)](https://www.iijmio.jp/auth/message/welcome/)
 [![ログアウト](https://www.iijmio.jp/image/logout-btn.jpg)](https://www.iijmio.jp/auth/logout/)

[![ログイン](https://www.iijmio.jp/image/login-btn.jpg)](https://www.iijmio.jp/auth/login/)

*   [会員専用ページ](https://www.iijmio.jp/member/)
    
*   [キャンペーン](https://www.iijmio.jp/campaign/)
    
*   [外国人の方 English](https://www.iijmio.jp/hdc/visitors/)
    
*   [取り扱い店舗](https://www.iijmio.jp/hdd/shop/)
    

*     [![料金・プラン](https://www.iijmio.jp/image/global_menu/icon_plan.png) ![料金・プラン](https://www.iijmio.jp/image/global_menu/icon_plan_on.png) 料金プラン](https://www.iijmio.jp/hdc/spec/)
    
*     [![SIM・eSIM](https://www.iijmio.jp/image/global_menu/icon_sim.png) ![SIM・eSIM](https://www.iijmio.jp/image/global_menu/icon_sim_on.png) SIM / eSIM](javascript:void(0);)
    *   ラインアップ
        
        [ギガプラン](https://www.iijmio.jp/gigaplan/)
        
        [ギガプラン 音声eSIM](https://www.iijmio.jp/gigaplan/esim/phone/)
        
        [従量制プラン](https://www.iijmio.jp/juryo.html)
        
        [eSIM（データプラン ゼロ）](https://www.iijmio.jp/esim/)
        
        [えらべるSIMカード](https://www.iijmio.jp/eraberu/)
        
        [プリペイドSIM](https://s.iijmio.jp/prepaid/)
        
        [クーポンカード](https://s.iijmio.jp/couponcard/)
        
        [Japan Travel SIM  \
        （訪日外国人向けSIM）](https://tr.iijmio.jp/)
        
        [BIC SIM](https://bicsim.com/)
        
    *   オプション
        
        [通話定額オプション  \
        （5分、10分、かけ放題）](https://www.iijmio.jp/mobile/voicefree/)
        
        [U-NEXT for スマートシネマ](https://www.iijmio.jp/mop/u-next/)
        
        [オプションサービス](https://www.iijmio.jp/hdd/option/)
        
        [セーフティメールサービス](https://www.iijmio.jp/mm/)
        
    *   ご購入ガイド
        
        [格安SIMガイド](https://www.iijmio.jp/simguide/)
        
        [お申し込みの流れ](https://www.iijmio.jp/hdc/guide/norikae.html)
        
        [データシェア・プレゼント機能とは](https://www.iijmio.jp/gigaplan/dataoption/)
        
        [国際電話](https://www.iijmio.jp/intlcall/)
        
        [動作確認済み端末一覧](https://www.iijmio.jp/hdd/devices/)
        
        [SIM設定手順（APN設定）](https://www.iijmio.jp/hdc/guide/setting/)
        
        [機種変更ガイド](https://www.iijmio.jp/hdc/guide/switch/)
        
        [乗り換えガイド](https://www.iijmio.jp/hdc/guide/norikae.html)
        
*     [![端末・セット](https://www.iijmio.jp/image/global_menu/icon_device.png) ![端末・セット](https://www.iijmio.jp/image/global_menu/icon_device_on.png) 端末セット](javascript:void(0);)
    *   [端末ラインアップ](https://www.iijmio.jp/device/)
        
        [動作確認済み端末](https://www.iijmio.jp/hdd/devices/)
        
        メーカーから探す
        
        [Xiaomi](https://www.iijmio.jp/device/?SearchKeyword=Xiaomi)
        
        [OPPO](https://www.iijmio.jp/device/?SearchKeyword=OPPO)
        
        [motorola](https://www.iijmio.jp/device/?SearchKeyword=motorola)
        
        [Nothing](https://www.iijmio.jp/device/?SearchKeyword=Nothing)
        
        [ASUS](https://www.iijmio.jp/device/?SearchKeyword=ASUS)
        
    *   ブランドから探す
        
        [中古 iPhone＆iPad](https://www.iijmio.jp/device/iphone.html)
        
        [中古 Androidスマホ](https://www.iijmio.jp/device/usedandroid.html)
        
        [arrows](https://www.iijmio.jp/device/?SearchKeyword=arrows)
        
        [AQUOS](https://www.iijmio.jp/device/?SearchKeyword=AQUOS)
        
        [Xperia](https://www.iijmio.jp/device/?SearchKeyword=Xperia)
        
        [nubia](https://www.iijmio.jp/device/?SearchKeyword=nubia)
        
    *   [ノートPC](https://www.iijmio.jp/device/?DeviceType=ntpc)
        
        [SIMフリータブレット](https://www.iijmio.jp/device/?DeviceType=t)
        
        [IoT機器](https://www.iijmio.jp/device/?DeviceType=i)
        
        [WiFiルータ](https://www.iijmio.jp/device/?DeviceType=r&DeviceType2=hikari)
        
        その他
        
        [端末補償（IIJmioで新品端末購入）](https://www.iijmio.jp/device/option/)
        
        [端末補償（IIJmioで中古端末購入）](https://www.iijmio.jp/device/option/used.html)
        
        [端末保証（お手持ちのスマホ対象）](https://www.iijmio.jp/hdd/option/tsunagaru/)
        
*     [![mioひかり](https://www.iijmio.jp/image/global_menu/icon_hikari.png) ![SIM・eSIM](https://www.iijmio.jp/image/global_menu/icon_hikari_on.png) mioひかり](https://www.iijmio.jp/imh/)
    
*     [![サポート・取扱店舗](https://www.iijmio.jp/image/global_menu/icon_sup.png) ![サポート・取扱店舗](https://www.iijmio.jp/image/global_menu/icon_sup_on.png) サポート  \
    FAQ](javascript:void(0);)
    *   [FAQホーム](https://help.iijmio.jp/)
        
        [お問い合わせ](https://www.iijmio.jp/contact.html)
        
          
        
        ご購入ガイド
        
        [SIM設定手順（APN設定）](https://www.iijmio.jp/hdc/guide/setting/)
        
        [機種変更ガイド](https://www.iijmio.jp/hdc/guide/switch/)
        
        [乗り換えガイド](https://www.iijmio.jp/hdc/guide/norikae.html)
        
*     [![法人の客様](https://www.iijmio.jp/image/global_menu/icon_biz.png) ![法人の客様](https://www.iijmio.jp/image/global_menu/icon_biz_on.png) 法人のお客様](https://www.iijmio.jp/biz/)
    
*   [![ご購入・お申し込み](https://www.iijmio.jp/image/sr-nav6.jpg)](https://www.iijmio.jp/mobile/signup/)
    

[![IIJmio](https://www.iijmio.jp/image/header-logo.png)](https://www.iijmio.jp/)
 [English](https://www.iijmio.jp/hdc/visitors/)

[![IPv6接続状態](https://www.iijmio.jp/image/hn_ipv4.gif)](https://www.iijmio.jp/guide/outline/ipv6/icon/)

[![法人のお客様](https://www.iijmio.jp/image/biz-icon_sp.png)法人の  \
お客様](https://www.iijmio.jp/biz/)

[![会員専用ページ](https://www.iijmio.jp/image/icon_member.png)会員専用  \
ページ](https://www.iijmio.jp/member/)

[![キャンペーン](https://www.iijmio.jp/image/icon_campaign.png)キャンペーン](https://www.iijmio.jp/campaign/)

[![取り扱い店舗](https://www.iijmio.jp/image/icon_store.png)取り扱い  \
店舗](https://www.iijmio.jp/hdd/shop/)

![SIM/eSIM](https://www.iijmio.jp/image/icon_sim2.png)

SIM/eSIM

月額サービス

*   [ギガプラン](https://www.iijmio.jp/gigaplan/)
    
*   [ギガプラン 音声eSIM](https://www.iijmio.jp/gigaplan/esim/phone/)
    
*   [従量制プラン](https://www.iijmio.jp/juryo.html)
    
*   [えらべるSIMカード](https://www.iijmio.jp/eraberu/)
    
*   [BIC SIM](https://bicsim.com/)
    

その他サービス

*   [プリペイドSIM](https://s.iijmio.jp/prepaid/)
    
*   [クーポンカード](https://s.iijmio.jp/couponcard/)
    
*   [Japan Travel SIM  \
    (訪日外国人向けSIM)](https://tr.iijmio.jp/)
    
*   [通話定額オプション  \
    (5分、10分、かけ放題)](https://www.iijmio.jp/mobile/voicefree/)
    
*   [U-NEXT for スマートシネマ](https://www.iijmio.jp/mop/u-next/)
    
*   [オプションサービス](https://www.iijmio.jp/hdd/option/)
    

お役立ちガイド

*   [格安SIMガイド](https://www.iijmio.jp/simguide/)
    
*   [お申し込みの流れ  \
    (事前準備～初期設定)](https://www.iijmio.jp/hdc/guide/)
    
*   [データシェアとは](https://www.iijmio.jp/gigaplan/dataoption/)
    
*   [データプレゼントとは](https://www.iijmio.jp/gigaplan/dataoption/?id=tab2)
    
*   [国際電話](https://www.iijmio.jp/intlcall/)
    
*   [動作確認済み端末一覧](https://www.iijmio.jp/hdd/devices/)
    

![サポート/FAQ](https://www.iijmio.jp/image/icon_support.png)

サポート/FAQ

*   [FAQホーム](https://help.iijmio.jp/)
    
*   [お問い合わせ](https://www.iijmio.jp/contact.html)
    
*   [SIM 設定手順  \
    (APN設定)](https://www.iijmio.jp/hdc/guide/setting/)
    
*   [機種変更ガイド](https://www.iijmio.jp/hdc/guide/switch/)
    
*   [乗り換えガイド](https://www.iijmio.jp/hdc/guide/norikae.html)
    

*   [![料金](https://www.iijmio.jp/image/icon_price2.png)\
    \
    料金](https://www.iijmio.jp/hdc/spec/)
    
*   [![SIM/eSIM](https://www.iijmio.jp/image/icon_sim2.png)\
    \
    SIM/eSIM](https://www.iijmio.jp/#sim-esim)
    
*   [![端末](https://www.iijmio.jp/image/icon_set.png)\
    \
    端末](https://www.iijmio.jp/device/)
    
*   [![mioひかり](https://www.iijmio.jp/image/icon_imh.png)\
    \
    mioひかり](https://www.iijmio.jp/imh/)
    
*   [![サポート](https://www.iijmio.jp/image/icon_support.png)\
    \
    サポート](https://www.iijmio.jp/#support-shop)
    

![](https://www.iijmio.jp/image/cover_image.png) ![](https://www.iijmio.jp/image/cover_image_sp.png)

![](https://www.iijmio.jp/image/cover_image2026.png) ![](https://www.iijmio.jp/image/cover_image2026_sp.png)

![](https://www.iijmio.jp/image/cover_image.png) ![](https://www.iijmio.jp/image/cover_image_sp.png)

*    [![のりかえ価格端末一覧](https://www.iijmio.jp/image/topbnr/slider_norikae_sp.png)](https://www.iijmio.jp/device/#title)
    
*    [![IIJmio会員限定オンラインストア](https://www.iijmio.jp/image/topbnr/slider_closed_sale_sp.png)](https://www.iijmio.jp/campaign/auth/closed_sale.html)
    
*    [![ハッピースマイルキャンペーン最大3ヵ月間25ギガ900円](https://www.iijmio.jp/image/topbnr/slider_simcplarge_sp.png)](https://www.iijmio.jp/campaign/mio.html?cptype=simcp)
    
*    [![U-NEXT for スマートシネマ](https://www.iijmio.jp/image/topbnr/slider_u-next_sp.png)](https://www.iijmio.jp/mop/u-next/)
    
*    [![ [期間限定]スマホ大特価セール](https://www.iijmio.jp/image/topbnr/slider_devicecp_sp.png)](https://www.iijmio.jp/campaign/mio.html?cptype=devicecp)
    
*    [![クリスマスセール](https://www.iijmio.jp/image/topbnr/slider_christmassale2025_sp.png)](https://www.iijmio.jp/campaign/christmassale2025.html)
    
*    [![音声eSIM【ギガプラン】](https://www.iijmio.jp/image/topbnr/slider_voiceeSIM_sp.png)](https://www.iijmio.jp/gigaplan/esim/phone/)
    
*    [![プラン変更15GBが最大3ヵ月間1,400円](https://www.iijmio.jp/image/topbnr/slider_15giga-upgrade_sp.png)](https://www.iijmio.jp/campaign/15giga-upgrade202511/)
    
*    [![eSIM初期費用2,200円](https://www.iijmio.jp/image/topbnr/slider_esim202511_sp.png)](https://www.iijmio.jp/gigaplan/esim/)
    
*    [![IIJmioひかり キャンペーン](https://www.iijmio.jp/image/topbnr/slider_hikari_cp_10g_sp.png)](https://www.iijmio.jp/campaign/imh/10g.html)
    
*    [![IIJmioひかり キャンペーン](https://www.iijmio.jp/image/topbnr/slider_hikari_cp_sp.png)](https://www.iijmio.jp/campaign/imh/hikaricp.html)
    
*    [![セブン‐イレブン限定！IIJmioクーポンカード/デジタルプレゼントキャンペーン](https://www.iijmio.jp/image/topbnr/seven202512_sp.png)](https://www.iijmio.jp/campaign/sej/sej2512.html)
    
*    [![顧客満足度No.１＜MVNO＞](https://www.iijmio.jp/image/topbnr/slider_award_oricon_2025_sp.png)](https://www.iijmio.jp/hdd/award/)
    
*    [![家族割引](https://www.iijmio.jp/image/topbnr/slider_kazokuwaribiki_sp.png)](https://www.iijmio.jp/hdc/kazokuwaribiki/index.html)
    
*    [![長期利用特典](https://www.iijmio.jp/image/topbnr/slider_choki-riyotokuten_sp.png)](https://www.iijmio.jp/hdc/choki-riyotokuten/)
    
*    [![3Gケータイ（スマホ）から乗り換えよう！](https://www.iijmio.jp/image/topbnr/slider_3g-norikae_sp.png)](https://www.iijmio.jp/campaign/3g-norikae/)
    
*    [![のりかえ価格端末一覧](https://www.iijmio.jp/image/topbnr/slider_norikae_sp.png)](https://www.iijmio.jp/device/#title)
    
*    [![IIJmio会員限定オンラインストア](https://www.iijmio.jp/image/topbnr/slider_closed_sale_sp.png)](https://www.iijmio.jp/campaign/auth/closed_sale.html)
    
*    [![ハッピースマイルキャンペーン最大3ヵ月間25ギガ900円](https://www.iijmio.jp/image/topbnr/slider_simcplarge_sp.png)](https://www.iijmio.jp/campaign/mio.html?cptype=simcp)
    
*    [![U-NEXT for スマートシネマ](https://www.iijmio.jp/image/topbnr/slider_u-next_sp.png)](https://www.iijmio.jp/mop/u-next/)
    

*   ![顧客満足度No.１＜MVNO＞](https://www.iijmio.jp/image/topbnr/slider_award_oricon_2025.png)
*   ![家族割引](https://www.iijmio.jp/image/topbnr/slider_kazokuwaribiki.png)
*   ![長期利用特典](https://www.iijmio.jp/image/topbnr/slider_choki-riyotokuten.png)
*   ![3Gケータイ（スマホ）から乗り換えよう！](https://www.iijmio.jp/image/topbnr/slider_3g-norikae.png)
*   ![のりかえ価格端末一覧](https://www.iijmio.jp/image/topbnr/slider_norikae.png)
*   ![IIJmio会員限定オンラインストア](https://www.iijmio.jp/image/topbnr/slider_closed_sale.png)
*   ![ハッピースマイルキャンペーン最大3ヵ月間25ギガ900円](https://www.iijmio.jp/image/topbnr/slider_simcplarge.png)
*   ![U-NEXT for スマートシネマ](https://www.iijmio.jp/image/topbnr/slider_u-next.png)
*   ![ [期間限定]スマホ大特価セール](https://www.iijmio.jp/image/topbnr/slider_devicecp.png)
*   ![クリスマスセール](https://www.iijmio.jp/image/topbnr/slider_christmassale2025.png)
*   ![音声eSIM【ギガプラン】](https://www.iijmio.jp/image/topbnr/slider_voiceeSIM.png)
*   ![プラン変更で15GBが最大3ヵ月間1,400円](https://www.iijmio.jp/image/topbnr/slider_15giga-upgrade.png)
*   ![eSIM初期費用2,200円](https://www.iijmio.jp/image/topbnr/slider_esim202511.png)
*   ![IIJmioひかり キャンペーン](https://www.iijmio.jp/image/topbnr/slider_hikari_cp_10g.png)
*   ![IIJmioひかり キャンペーン](https://www.iijmio.jp/image/topbnr/slider_hikari_cp.png)
*   ![セブン‐イレブン限定！IIJmioクーポンカード/デジタルプレゼントキャンペーン](https://www.iijmio.jp/image/topbnr/seven202512.png)
*   ![顧客満足度No.１＜MVNO＞](https://www.iijmio.jp/image/topbnr/slider_award_oricon_2025.png)
*   ![家族割引](https://www.iijmio.jp/image/topbnr/slider_kazokuwaribiki.png)
*   ![長期利用特典](https://www.iijmio.jp/image/topbnr/slider_choki-riyotokuten.png)
*   ![3Gケータイ（スマホ）から乗り換えよう！](https://www.iijmio.jp/image/topbnr/slider_3g-norikae.png)
*   ![のりかえ価格端末一覧](https://www.iijmio.jp/image/topbnr/slider_norikae.png)
*   ![IIJmio会員限定オンラインストア](https://www.iijmio.jp/image/topbnr/slider_closed_sale.png)
*   ![ハッピースマイルキャンペーン最大3ヵ月間25ギガ900円](https://www.iijmio.jp/image/topbnr/slider_simcplarge.png)
*   ![U-NEXT for スマートシネマ](https://www.iijmio.jp/image/topbnr/slider_u-next.png)
*   ![ [期間限定]スマホ大特価セール](https://www.iijmio.jp/image/topbnr/slider_devicecp.png)
*   ![クリスマスセール](https://www.iijmio.jp/image/topbnr/slider_christmassale2025.png)
*   ![音声eSIM【ギガプラン】](https://www.iijmio.jp/image/topbnr/slider_voiceeSIM.png)
*   ![プラン変更で15GBが最大3ヵ月間1,400円](https://www.iijmio.jp/image/topbnr/slider_15giga-upgrade.png)

![](https://www.iijmio.jp/image/top/slider_next.png)

![](https://www.iijmio.jp/image/top/slider_prev.png)

*   [![ご購入・お申し込み](https://www.iijmio.jp/image/sp-nav06.png)](https://www.iijmio.jp/mobile/signup/)
    

トップページ
======

お知らせ
----

[障害一覧 障害発生中](https://www.iijmio.jp/info/trouble/)

    

重要なお知らせ キャンペーン サービス 端末 災害支援

[障害一覧 障害発生中](https://www.iijmio.jp/info/trouble/)

*   2025.12.01
    
    [ユニバーサルサービス料の変更について](https://www.iijmio.jp/info/iij/1763013592.html)
    
*   2025.10.30
    
    [IIJmio本人確認手続きの変更のお知らせ 公的個人認証サービスおよびICチップ読み取り＋容貌画像方式に対応](https://www.iijmio.jp/info/iij/1760669254.html)
    
*   2025.10.30
    
    [被保険者証等の本人確認書類取り扱い停止のお知らせ](https://www.iijmio.jp/info/iij/1760601780.html)
    

現在、お知らせはありません

[一覧を見る](https://www.iijmio.jp/info/iij/)

*   2025.12.02
    
    [スマホ大特価セール実施のお知らせ](https://www.iijmio.jp/info/iij/1763432854.html)
    
*   2025.12.02
    
    [回線セット特価実施のお知らせ](https://www.iijmio.jp/info/iij/1763447957.html)
    
*   2025.12.02
    
    [のりかえ価格での端末販売のお知らせ](https://www.iijmio.jp/info/iij/1755476367.html)
    

現在、お知らせはありません

[一覧を見る](https://www.iijmio.jp/info/iij/)

*   2025.11.25
    
    [「Japan Travel SIM/Digital（eSIM）」ファミリーマートのマルチコピー機で販売開始のお知らせ](https://www.iijmio.jp/info/iij/1763342873.html)
    
*   2025.10.16
    
    [新たなオプションサービス「U-NEXT for スマートシネマ」提供開始のお知らせ](https://www.iijmio.jp/info/iij/1759379017.html)
    
*   2025.10.01
    
    [【訂正更新】DMMとIIJ、「DMMモバイル Plus Powered by IIJ」販売開始のお知らせ](https://www.iijmio.jp/info/iij/1758846421.html)
    

現在、お知らせはありません

[一覧を見る](https://www.iijmio.jp/info/iij/)

*   2025.12.01
    
    [動作確認端末一覧に「OPPO A5 5G」「motorola razr 60 ultra」「REDMI Pad 2 Pro 5G」追加のお知らせ](https://www.iijmio.jp/info/iij/1764298317.html)
    
*   2025.11.28
    
    [IIJmioサプライサービス OPPO 製スマートフォン、Xiaomi 製タブレット・ スマートウオッチ、Apple 認定整備済製品「MacBook Pro 14 インチ」販売開始のお知らせ](https://www.iijmio.jp/info/iij/1764126002.html)
    
*   2025.11.26
    
    [IIJmioサプライサービス モトローラ製「motorola razr 60 Ultra」販売開始のお知らせ](https://www.iijmio.jp/info/iij/1763425448.html)
    

現在、お知らせはありません

[一覧を見る](https://www.iijmio.jp/info/iij/)

*   2025.11.20
    
    [IIJmioモバイルサービスにおける”令和7年11月18日大分市佐賀関の大規模火災"にかかる災害救助法の適用について](https://www.iijmio.jp/info/iij/1763538900.html)
    
*   2025.11.20
    
    [IIJmioひかりにおける”令和7年11月18日大分市佐賀関の大規模火災"にかかる特別措置について](https://www.iijmio.jp/info/iij/1763540230.html)
    
*   2025.10.09
    
    [IIJmioモバイルサービスにおける”令和7年台風第22号に伴う災害"にかかる災害救助法の適用について](https://www.iijmio.jp/info/iij/1759973865.html)
    

現在、お知らせはありません

[一覧を見る](https://www.iijmio.jp/info/iij/)

ピックアップ
------

*   [![iPhone>eSIM初期設定ガイド](https://www.iijmio.jp/image/topbnr/pickup_iphone_esim.png)\
    \
    iPhone>eSIM初期設定ガイド](https://www.iijmio.jp/hdc/guide/switch/?type=esim-iphone-voice-docomo)
    
*   [![乗り換えガイド](https://www.iijmio.jp/image/topbnr/pickup_20_cmn.png)\
    \
    乗り換えガイド](https://www.iijmio.jp/hdc/guide/)
    
*   [![動作確認済み端末一覧](https://www.iijmio.jp/image/topbnr/pickup_04_cmn.png)\
    \
    動作確認済み端末一覧](https://www.iijmio.jp/hdd/devices/index.html)
    
*   [![IIJmio乗り換え体験談](https://www.iijmio.jp/image/topbnr/pickup_uservoice.png)\
    \
    ご利用いただいている  \
    お客様の声をご紹介します](https://www.iijmio.jp/uservoice/)
    
*   [![ご愛顧感謝特典](https://www.iijmio.jp/image/topbnr/pickup_thanksgoaiko.png)\
    \
    ギガプランご利用中の方に  \
    ありがとうの気持ちを込めて](https://www.iijmio.jp/goaiko/)
    
*   [![ギガプラン](https://www.iijmio.jp/image/topbnr/pickup_gigaplan2502.png)\
    \
    10GB増量キャンペーン実施中！月額割引＆通話定額割引も！](https://www.iijmio.jp/gigaplan/)
    
*   [![eSIM初期費用1,100円割引キャンペーン](https://www.iijmio.jp/campaign/img/esim202511.png)\
    \
    eSIMの申込ならおトク！初期費用が1,100円割引！](https://www.iijmio.jp/gigaplan/esim/)
    
*   [![他社からお乗り換えでスマホがお得！](https://www.iijmio.jp/campaign/img/devicecp.png)\
    \
    他社からお乗り換えで  \
    スマホがお得！](https://www.iijmio.jp/campaign/mio.html?cptype=devicecp)
    
*   [![他社光回線からの乗り換えかんたん！](https://www.iijmio.jp/campaign/img/hikari202502.png)\
    \
    おうちのネットは  \
    スマホとセットがおトク！](https://www.iijmio.jp/campaign/imh/hikaricp.html)
    
*   [![販売パートナー募集](https://www.iijmio.jp/image/topbnr/pickup_biz_cmn.png)\
    \
    人気＆最新スマホと格安SIM  \
    販売してみませんか？](https://www.iijmio.jp/biz/)
    

  

端末ラインアップ
--------

[![](https://www.iijmio.jp/device/img/Redmi_14C_4GB_128GB.png)\
\
Xiaomi\
\
Redmi 14C \[4GB/128GB\]\
\
のりかえ価格\
\
一括支払い17,980円\
\
税込500円](https://www.iijmio.jp/device/xiaomi/redmi14c.html)

[![](https://www.iijmio.jp/device/img/motorola_edge_60_pro.png)\
\
motorola\
\
motorola edge 60 pro\
\
\[2/2まで\]のりかえ価格\
\
一括支払い57,800円\
\
税込39,800円](https://www.iijmio.jp/device/motorola/edge60-pro.html)

[![](https://www.iijmio.jp/device/img/AQUOS_sense10_6GB_128GB.png)\
\
SHARP\
\
AQUOS sense10 \[6GB/128GB\]\
\
\[2/2まで\]のりかえ価格\
\
一括支払い61,000円\
\
税込44,800円](https://www.iijmio.jp/device/sharp/sense10.html)

その他の製品はこちらから
------------

[iPhone/ iPad\
\
![iphone/iPad](https://www.iijmio.jp/image/top/iphone_thumb.png)](https://www.iijmio.jp/device/?DeviceType=a)
[ノートPC\
\
![ノートPC](https://www.iijmio.jp/image/top/ntpc_thumb.png)](https://www.iijmio.jp/device/?DeviceType=ntpc)
[タブレット\
\
![タブレット](https://www.iijmio.jp/image/top/tablet_thumb.png)](https://www.iijmio.jp/device/?DeviceType=t)
[Wi-Fiルーター\
\
![Wi-Fiルーター](https://www.iijmio.jp/image/top/router_thumb.png)](https://www.iijmio.jp/device/?DeviceType=r&DeviceType2=hikari)
[IoT機器\
\
![IoT機器](https://www.iijmio.jp/image/top/iot_thumb.png)](https://www.iijmio.jp/device/?DeviceType=i&DeviceType2=home)
[ウェアラブル\
\
![ウェアラブル](https://www.iijmio.jp/image/top/wear_thumb.png)](https://www.iijmio.jp/device/?DeviceType=wear)

[すべての端末を見る](https://www.iijmio.jp/device/index.html)

![](https://www.iijmio.jp/img/closedsale-area-bar.png)

![](https://www.iijmio.jp/img/top-closed-badge.png)

IIJmio会員限定オンラインストア
------------------

IIJmio会員限定で、一部商品を特別価格で大放出！  
ログインして限定価格をチェック！

[![](https://www.iijmio.jp/device/img/OPPO_Pad_3_Matte_Display_Edition.png)\
\
OPPO\
\
OPPO Pad 3 Matte Display Edition\
\
会員限定価格](https://www.iijmio.jp/device/oppo/pad_3.html)

[![](https://www.iijmio.jp/device/img/TCL_TAB_10_Gen2.png)\
\
TCL\
\
TCL TAB 10 Gen2\
\
会員限定価格](https://www.iijmio.jp/device/tcl/tab10-gen2.html)

[![](https://www.iijmio.jp/device/img/TCL_TAB_8_Gen2.png)\
\
TCL\
\
TCL TAB 8 Gen2\
\
会員限定価格](https://www.iijmio.jp/device/tcl/tab8-gen2.html)

[すべての会員限定商品を見る](https://www.iijmio.jp/campaign/auth/closed_sale.html)

※会員専用ページへのログインが必要です。

![](https://www.iijmio.jp/img/closedsale-area-bar.png)

IIJmioギガプランの特長
--------------

選べる自由な組み合わせ  
「データ量」「SIMの機能」「オプション」を  
使い方に合わせて自由に組み合わせできます。

 [![IIJmioモバイルサービス ギガプラン](https://www.iijmio.jp/image/banner/bnr_gigaplan_sp.png) ![IIJmioモバイルサービス ギガプラン](https://www.iijmio.jp/image/banner/bnr_gigaplan.png)](https://www.iijmio.jp/gigaplan/)

使いたいデータ量に合わせて、  
2GBから自由に選べる！

![IIJmioのデータ容量の種類](https://www.iijmio.jp/gigaplan/img/eraberu_data.png)    ![選べるデータ量](https://www.iijmio.jp/gigaplan/img/eraberu_data_obi.png)

スマホだけじゃなく、タブレットや  
eSIMも自由に選べる！

![音声、SMS、データ通信専用](https://www.iijmio.jp/gigaplan/img/eraberu_sim.png) ![選べるSIM機能](https://www.iijmio.jp/gigaplan/img/eraberu_sim_obi.png)

かけ放題プランも自由に選べる！

通話定額5分+

通話定額10分+

かけ放題+

最大3ヵ月間0円に割引中！

![選べる通話オプション](https://www.iijmio.jp/gigaplan/img/eraberu_option_obi.png)

![U-NEXT for スマートシネマ](https://www.iijmio.jp/image/top/u-next_logo.png)

U-NEXT for スマートシネマ

月額2,189円(税込)

最大 **2**ヵ月トライアル

### ギガプランとセットでお得！![女の子](https://www.iijmio.jp/image/top/u-next_girl.png)

ギガプランとセットでず　　っと**220**円/月(税込)割引！

![SIMカード](https://www.iijmio.jp/image/top/simcard.png)ギガプラン

![U-NEXT for スマートシネマ](https://www.iijmio.jp/image/top/u-next_logo.png)

月額合計  
2ギガの場合

3ヵ月目以降ずーっと

セットで3,039円

**2,819**円(税込)

![女の子](https://www.iijmio.jp/image/top/u-next_girl.png)

![おススメオプション](https://www.iijmio.jp/image/top/osusume_option_obi.png)

### ギガプランはシンプルで自由！  
データ量が無駄なく使えてサービスも充実

![](https://www.iijmio.jp/image/top/gigaplan-feature1.png)

余ったデータ量を無駄なく翌月繰り越し

[![](https://www.iijmio.jp/image/top/gigaplan-feature2.png)\
\
機能が違ってもデータ量のシェアが出来る](https://www.iijmio.jp/gigaplan/dataoption/)

![](https://www.iijmio.jp/image/top/gigaplan-feature3.png)

MNP転出料・契約解除料なし

[![](https://www.iijmio.jp/image/top/gigaplan-feature4.png)\
\
5G無料](https://www.iijmio.jp/mobile/5g/)
[![](https://www.iijmio.jp/image/top/gigaplan-feature5.png)\
\
eSIMも選べる](https://www.iijmio.jp/gigaplan/esim/)
[![](https://www.iijmio.jp/gigaplan/img/app_icon.png)\
\
ギガプラン専用アプリ「My IIJmio」](https://www.iijmio.jp/gigaplan/#app)

[ギガプラン詳細はこちら](https://www.iijmio.jp/gigaplan/)

IIJmioご愛顧感謝特典
-------------

![IIJmioご愛顧感謝特典](https://www.iijmio.jp/goaiko/img/benefits_main.png) ![IIJmioご愛顧感謝特典](https://www.iijmio.jp/goaiko/img/benefits_main_sp.png)

### mio優待券

2024年6月21日開始

#### スマホ割引券プレゼント！

ご契約内容に応じて、スマホ割引券（mio優待券）をプレゼント！  
端末単体での購入時にご利用が可能です。

![スマホ割引](https://www.iijmio.jp/goaiko/img/tokuten1.png)

### 家族割引

2024年10月1日開始

#### 音声回線利用で月額割引！

ギガプランの音声SIM/音声eSIMが対象！  
複数回線ご利用で、1回線あたり月額100円割引します。

![音声回線利用で月額割引！](https://www.iijmio.jp/goaiko/img/tokuten2.png)

### mio長特  
（長期利用特典）

2025年1月23日開始

#### ご契約期間に応じて、  
おトクな特典をプレゼント！

データ量や各種手数料割引など特典をプレゼント！  
特典は今後も追加予定！

![ご契約期間に応じて、おトクな特典をプレゼント！](https://www.iijmio.jp/goaiko/img/tokuten3.png)

[ご愛顧感謝特典の詳細はこちら](https://www.iijmio.jp/goaiko/)

選べるオプション！
---------

![](https://www.iijmio.jp/lp/lp1707/img/deviceSlider_arrow_lt.png)

[![スマート留守電](https://www.iijmio.jp/hdd/option/img/thumb_rusuden.png)\
\
### スマート留守電\
\
#### LINEで留守電が着信できる、読める、聞ける、新しい留守番電話サービス。](https://www.iijmio.jp/hdd/option/rusuden/)

[![Smart・Checker (MyPermissions)](https://www.iijmio.jp/hdd/option/img/thumb_sc.png)\
\
### Smart・Checker(MyPermissions)\
\
#### アプリ上の個人情報連携を知る・管理する・解除する。](https://www.iijmio.jp/hdd/option/mypermi/)

[![タブホ（タブレット使い放題）](https://www.iijmio.jp/hdd/option/img/thumb_tab.png)\
\
### タブホ（タブレット使い放題）\
\
#### スマホ・タブレットに加え、パソコンからも読み放題！](https://www.iijmio.jp/hdd/option/tabuho/)

[![SMART USEN](https://www.iijmio.jp/hdd/option/img/thumb_usen.png)\
\
### SMART USEN\
\
#### お店のBGMでおなじみのUSENが提供する音楽アプリ！](https://www.iijmio.jp/hdd/option/usen/)

[![ローチケHMVプレミアム](https://www.iijmio.jp/hdd/option/img/thumb_l-tike.png)\
\
### ローチケHMVプレミアム\
\
#### チケット、映画視聴、マンガが楽しめる総合エンタメアプリ！](https://www.iijmio.jp/hdd/option/l-tike/)

[![U-NEXT for スマートシネマ](https://www.iijmio.jp/hdd/option/img/thumb_u-next.png)\
\
### U-NEXT for スマートシネマ\
\
#### 最大2ヵ月トライアル！動画配信サービス「U-NEXT」をお得に利用できます。ギガプランとセットでさらにおトク。](https://www.iijmio.jp/mop/u-next/)

[![みまもりパック](https://www.iijmio.jp/hdd/option/img/thumb_mimamori.png)\
\
### みまもりパック\
\
#### お子様のスマホの安全を考えたお得なパックです。](https://www.iijmio.jp/hdd/option/mimamori/)

[![IIJmio WiFi by エコネクト](https://www.iijmio.jp/hdd/option/img/thumb_econnect.png)\
\
### IIJmio WiFi by エコネクト\
\
#### 日本全国100,000ヵ所以上でWiFiが利用できます！](https://www.iijmio.jp/hdd/option/iijmiowifi/)

[![新品端末補償オプション](https://www.iijmio.jp/hdd/option/img/thumb_new.png)\
\
### 新品  \
端末補償オプション\
\
#### IIJmioでご購入の新品の端末が故障などの際、交換端末をお届けします。](https://www.iijmio.jp/device/option/)

[![中古端末補償オプション](https://www.iijmio.jp/hdd/option/img/thumb_used.png)\
\
### 中古  \
端末補償オプション\
\
#### IIJmioでご購入の中古の端末が故障などの際、修理・交換します。](https://www.iijmio.jp/device/option/used.html)

[![つながる端末保証](https://www.iijmio.jp/hdd/option/img/thumb_tsunagaru.png)\
\
### つながる端末保証\
\
#### IIJmioでお使いの端末を修理・交換します。](https://www.iijmio.jp/hdd/option/tsunagaru/)

[![ウイルスバスター モバイル 月額版](https://www.iijmio.jp/hdd/option/img/thumb_trend.png)\
\
### ウイルスバスター モバイル 月額版\
\
#### スマホ向け総合セキュリティ・ウイルス対策アプリ。](https://www.iijmio.jp/hdd/option/trend/)

[![マカフィー モバイル セキュリティ](https://www.iijmio.jp/hdd/option/img/thumb_mcafee.png)\
\
### マカフィー モバイル セキュリティ\
\
#### スマホ向け総合セキュリティ・ウイルス対策アプリ。](https://www.iijmio.jp/hdd/option/mcafee/)

[![i-フィルター for マルチデバイス](https://www.iijmio.jp/hdd/option/img/thumb_ifilter.png)\
\
### i-フィルター for マルチデバイス\
\
#### インターネットに潜む危険からお子様を守る！](https://www.iijmio.jp/hdd/option/ifilter/)

[![スマート留守電](https://www.iijmio.jp/hdd/option/img/thumb_rusuden.png)\
\
### スマート留守電\
\
#### LINEで留守電が着信できる、読める、聞ける、新しい留守番電話サービス。](https://www.iijmio.jp/hdd/option/rusuden/)

[![Smart・Checker (MyPermissions)](https://www.iijmio.jp/hdd/option/img/thumb_sc.png)\
\
### Smart・Checker(MyPermissions)\
\
#### アプリ上の個人情報連携を知る・管理する・解除する。](https://www.iijmio.jp/hdd/option/mypermi/)

[![タブホ（タブレット使い放題）](https://www.iijmio.jp/hdd/option/img/thumb_tab.png)\
\
### タブホ（タブレット使い放題）\
\
#### スマホ・タブレットに加え、パソコンからも読み放題！](https://www.iijmio.jp/hdd/option/tabuho/)

[![SMART USEN](https://www.iijmio.jp/hdd/option/img/thumb_usen.png)\
\
### SMART USEN\
\
#### お店のBGMでおなじみのUSENが提供する音楽アプリ！](https://www.iijmio.jp/hdd/option/usen/)

[![ローチケHMVプレミアム](https://www.iijmio.jp/hdd/option/img/thumb_l-tike.png)\
\
### ローチケHMVプレミアム\
\
#### チケット、映画視聴、マンガが楽しめる総合エンタメアプリ！](https://www.iijmio.jp/hdd/option/l-tike/)

[![U-NEXT for スマートシネマ](https://www.iijmio.jp/hdd/option/img/thumb_u-next.png)\
\
### U-NEXT for スマートシネマ\
\
#### 最大2ヵ月トライアル！動画配信サービス「U-NEXT」をお得に利用できます。ギガプランとセットでさらにおトク。](https://www.iijmio.jp/mop/u-next/)

[![みまもりパック](https://www.iijmio.jp/hdd/option/img/thumb_mimamori.png)\
\
### みまもりパック\
\
#### お子様のスマホの安全を考えたお得なパックです。](https://www.iijmio.jp/hdd/option/mimamori/)

[![IIJmio WiFi by エコネクト](https://www.iijmio.jp/hdd/option/img/thumb_econnect.png)\
\
### IIJmio WiFi by エコネクト\
\
#### 日本全国100,000ヵ所以上でWiFiが利用できます！](https://www.iijmio.jp/hdd/option/iijmiowifi/)

[![新品端末補償オプション](https://www.iijmio.jp/hdd/option/img/thumb_new.png)\
\
### 新品  \
端末補償オプション\
\
#### IIJmioでご購入の新品の端末が故障などの際、交換端末をお届けします。](https://www.iijmio.jp/device/option/)

[![中古端末補償オプション](https://www.iijmio.jp/hdd/option/img/thumb_used.png)\
\
### 中古  \
端末補償オプション\
\
#### IIJmioでご購入の中古の端末が故障などの際、修理・交換します。](https://www.iijmio.jp/device/option/used.html)

[![つながる端末保証](https://www.iijmio.jp/hdd/option/img/thumb_tsunagaru.png)\
\
### つながる端末保証\
\
#### IIJmioでお使いの端末を修理・交換します。](https://www.iijmio.jp/hdd/option/tsunagaru/)

[![ウイルスバスター モバイル 月額版](https://www.iijmio.jp/hdd/option/img/thumb_trend.png)\
\
### ウイルスバスター モバイル 月額版\
\
#### スマホ向け総合セキュリティ・ウイルス対策アプリ。](https://www.iijmio.jp/hdd/option/trend/)

![](https://www.iijmio.jp/lp/lp1707/img/deviceSlider_arrow_rt.png)

*   1
*   2
*   3
*   4
*   5
*   6
*   7
*   8
*   9
*   10
*   11
*   12
*   13
*   14

[すべてのモバイルオプションを見る](https://www.iijmio.jp/hdd/option/)

インターネットサービス
-----------

ご家庭のインターネット接続やメールサービスなど、  
格安SIM以外のサービスもご用意しています。

*    [![](https://www.iijmio.jp/image/top_is_imh.svg) IIJmioひかり](https://www.iijmio.jp/imh/)
    
*    [![](https://www.iijmio.jp/image/top_is_mm.svg) セーフティメールサービス](https://www.iijmio.jp/mm/)
    

[その他のサービスラインアップはこちら](https://www.iijmio.jp/guide/outline/)

 [![IIJmioひかり キャンペーン](https://www.iijmio.jp/imh/img/bigbnr_hikaricp_202502_pc.png) ![IIJmioひかり キャンペーン](https://www.iijmio.jp/imh/img/bigbnr_hikaricp_202502_sp.png)](https://www.iijmio.jp/campaign/imh/hikaricp.html)

人気の記事
-----

[![サムネイル](https://www.iijmio.jp/simguide/img/thumbsnail/android_th_reno13a.png)\
\
OPPO Reno13 Aを実機レビュー〜“スペック以上”の満足感？使ってわかったOPPO AIの魅力～](https://www.iijmio.jp/simguide/android/reno13a.html)

[![サムネイル](https://www.iijmio.jp/simguide/img/thumbsnail/android_th_aquoswish5.png)\
\
AQUOS wish5を実機レビュー〜おサイフケータイ機能や大容量バッテリーを搭載した使い勝手の良いスマホ～](https://www.iijmio.jp/simguide/android/aquoswish5.html)

[![サムネイル](https://www.iijmio.jp/simguide/img/thumbsnail/android_th_edge60pro.png)\
\
motorola edge 60 proを実機レビュー〜moto ai対応の準ハイエンドスマホを紹介～](https://www.iijmio.jp/simguide/android/edge60pro.html)

[格安SIMガイドを読む](https://www.iijmio.jp/simguide/)

IIJmioの改善活動。皆様のご要望にお応えします！![IIJmioの改善活動。皆様のご要望にお応えします！](https://www.iijmio.jp/image/bg_improvement_sp.png)
----------------------------------------------------------------------------------------------------------

*   [![](https://www.iijmio.jp/improvement/img/icon_mobile.svg)\
    \
    ### iPhone用eSIM設定手順を見つけやすくしました！\
    \
    2025年9月対応](https://www.iijmio.jp/improvement/topics-24/)
    
*   [![](https://www.iijmio.jp/improvement/img/icon_mobile.svg)\
    \
    ### FAQをもっと使いやすくしました！\
    \
    2025年8月対応](https://www.iijmio.jp/improvement/topics-25/)
    
*   [![](https://www.iijmio.jp/improvement/img/icon_mobile.svg)\
    \
    ### 申し込み完了後でも申し込み内容を確認できるようにしました！\
    \
    2025年8月対応](https://www.iijmio.jp/improvement/topics-23/)
    

[改善活動詳細はこちら](https://www.iijmio.jp/improvement/)

IIJmio 動画ギャラリー
--------------

[![サムネイル](https://www.iijmio.jp/image/topbnr/thumbnail_movie_typed.png)](https://www.youtube.com/embed/D23lkKwZG18?rel=0)

### 音声eSIMの設定方法

音声eSIM（ドコモ網）の申込～設定方法までご紹介

[![サムネイル](https://img.youtube.com/vi/BFDB812teaE/mqdefault.jpg)](https://www.youtube.com/embed/BFDB812teaE?rel=0)

### はじめての格安SIM

格安SIMへの乗り換えフローを解説！5ステップで完了！

[![サムネイル](https://img.youtube.com/vi/g-HjOPxAyCY/mqdefault.jpg)](https://www.youtube.com/embed/g-HjOPxAyCY?rel=00)

### 運営会社「IIJ」って？

どんな事業をしている会社なのか、ご紹介いたします。

[全ての動画をみる](https://www.youtube.com/user/IIJmio)

*   メンテナンス・障害情報
    
    [メンテナンスのお知らせ](https://www.iijmio.jp/info/stop/)
    
    [障害情報](https://www.iijmio.jp/info/trouble/)
    
    [東日本大震災関連情報](https://www.iijmio.jp/info/iij/20110324-1.html)
    
*   サービス案内
    
    [IIJサービスご利用にあたって](https://www.iijmio.jp/guide/supplement/)
    
    [IIJmioサービス約款・規約](https://www.iijmio.jp/guide/agreement/)
    
    [サービスQ&A](https://help.iijmio.jp/)
    
    [mio割引プランについて](https://www.iijmio.jp/imh/miowari.html)
    
*   IIJ4Uサービスの廃止と統合
    
    [IIJ4UサービスのIIJmioサービスへの統合について](https://www.iijmio.jp/4uunity/index.html)
    
*   IIJmioモバイルパートナー・法人利用ご希望の方へ
    
    IIJmioは拡販にご協力いただけるパートナーを募集しております
    
    [モバイルパートナー募集](https://www.iijmio.jp/biz/)
    
    [IIJmio法人利用検討中の方こちら](https://www.iij.ad.jp/svcsol/campaign/iijmiobiz_202306.html)
    

IIJmioソーシャルメディア

  

※金額は全て税込で表記しています  
※記載されている商品名、会社名等は各会社の商号、商標または登録商標です。本文中では™、®マークは表記しておりません。  
※Apple、Appleのロゴ、iPhone、iPad、iPad Pro、AppleCare、AppleCare+は米国およびその他の国々で登録されたApple Inc.の商標です。 iPhone 商標は、アイホン株式会社のライセンスに基づき使用されています。

*   [![IIJmioの申込にあたってのご注意](https://www.iijmio.jp/image/topbnr/footer-caution.png)](https://www.iijmio.jp/hdd/care/)
    
*   [![IIJmioが選ばれる6つの理由](https://www.iijmio.jp/image/topbnr/footer-03_B.jpg)](https://www.iijmio.jp/hdd/award/)
    
*   [![通話定額オプション](https://www.iijmio.jp/image/topbnr/footer-voicefree.png)](https://www.iijmio.jp/mobile/voicefree/)
    
*   [![Happy mio Life](https://www.iijmio.jp/image/topbnr/footer-happymiolife.png)](https://www.iijmio.jp/hml/)
    

*   [このサイトのご利用について](https://www.iijmio.jp/thissite/)
    
*   [情報セキュリティ基本方針](http://www.iij.ad.jp/securitypolicy/)
    
*   [サイトマップ](https://www.iijmio.jp/sitemap.html)
    
*   [初期契約解除について](https://www.iijmio.jp/member/cancellation/)
    

*   [個人情報保護ポリシー](http://www.iij.ad.jp/privacy/)
    
*   [「特定商取引に関する法律」「古物営業法」に基づく表示](https://www.iijmio.jp/tokusho/)
    
*   [お問い合わせ](https://www.iijmio.jp/contact.html)
    

[![プライバシーマーク](https://www.iijmio.jp/image/pmark.png)](https://privacymark.jp/)

[![page top](https://www.iijmio.jp/image/page-top.png)](https://www.iijmio.jp/#top)

*   SIMカード

*   [ギガプラン](https://www.iijmio.jp/gigaplan/)
    
*   [従量制プラン](https://www.iijmio.jp/juryo.html)
    
*   [eSIM（データプラン ゼロ）](https://www.iijmio.jp/esim/)
    
*   [えらべるSIMカード](https://www.iijmio.jp/eraberu/)
    

*   [プリペイドSIM](https://s.iijmio.jp/prepaid/)
    
*   [クーポンカード](https://s.iijmio.jp/couponcard/)
    
*   [Japan Travel SIM（訪日外国人向けSIM）](https://tr.iijmio.jp/)
    
*   [IIJmio IoT](https://www.iijmio.jp/mit/)
    

*   [SIMフリースマホ](https://www.iijmio.jp/device/)
    
*   [SIMフリータブレット](https://www.iijmio.jp/device/?DeviceType=t)
    
*   [IoT機器](https://www.iijmio.jp/device/?DeviceType=i)
    
*   [Wi-Fiルータ](https://www.iijmio.jp/device/?DeviceType=r&DeviceType2=hikari)
    
*   [キャンペーン](https://www.iijmio.jp/campaign/)
    
*   [会員専用ページ](https://www.iijmio.jp/member/)
    

*   [IIJmioひかり](https://www.iijmio.jp/imh/)
    
*   *   [IIJmioひかり電話](https://www.iijmio.jp/imh/hikaridenwa.html)
        

* * *

*   [ご購入・お申し込み  \
    ギガプラン](https://www.iijmio.jp/mobile/signup/)
    

[![IIJ](https://www.iijmio.jp/image/footer-logo.jpg)](http://www.iij.ad.jp/)

IIJmioは株式会社インターネットイニシアティブが提供する個人向けインターネットサービスです

[企業情報はこちら](http://www.iij.ad.jp/company/)

©2005-2025 Internet Initiative Japan Inc.

〒102-0071　東京都千代田区富士見2-10-2　飯田橋グラン・ブルーム  
届出番号(電気通信事業者)：第A-16-7006号  
代理店届出番号：第C2002871号

[![twitter](https://www.iijmio.jp/image/footer-sns-icon-01.jpg)](http://twitter.com/share?url=https://www.iijmio.jp/&amp;text=%E6%A0%BC%E5%AE%89SIM/%E6%A0%BC%E5%AE%89%E3%82%B9%E3%83%9E%E3%83%9B%E3%83%BB%E3%82%A4%E3%83%B3%E3%82%BF%E3%83%BC%E3%83%8D%E3%83%83%E3%83%88%E3%82%B5%E3%83%BC%E3%83%93%E3%82%B9%E3%81%AEIIJmio)
 [![hatena](https://www.iijmio.jp/image/footer-sns-icon-02.jpg)](http://b.hatena.ne.jp/append?https://www.iijmio.jp/)

©2005-2025 Internet Initiative Japan Inc.
