# 【公式】格安SIM・格安スマホのNUROモバイル

URL: https://mobile.nuro.jp/

---

![SONY](https://mobile.nuro.jp/images/nmui2/logo-sony-white.png)

[![【公式】格安SIM・格安スマホのNUROモバイル](https://mobile.nuro.jp/images/nmui2/logo-nuromobile-black.png)](https://mobile.nuro.jp/)

======================================================================================================================

[お申し込み](https://www.nuro.jp/app/nuromobile-directolsu/entry/new/)

[![マイページ](https://mobile.nuro.jp/images/nmui2/mypage.png)マイページ](https://mobile.nuro.jp/user/userMenu/)

*   [![facebook](https://mobile.nuro.jp/images/nmui2/icon-facebook.png)](https://www.facebook.com/NUROMobilebySony/)
    
*   [![Instagram](https://mobile.nuro.jp/images/nmui2/icon-instagram.png)](https://www.instagram.com/nuromobilebysony/)
    
*   [![Twitter](https://mobile.nuro.jp/images/nmui2/icon-twitter.png)](https://twitter.com/nuromobile_jp)
    
*   [![Youtube](https://mobile.nuro.jp/images/nmui2/icon-youtube.png)](https://youtube.com/channel/UC3PO0t22QLwQ4-cm8rvdFEw)
    

*   [NUROモバイルについて](https://mobile.nuro.jp/about/)
    
*   [お申し込みの流れ](https://mobile.nuro.jp/guide/sim.html)
    
*   [料金・プラン](https://mobile.nuro.jp/plan/)
    
*   [オプション・サービス](https://mobile.nuro.jp/option/)
    
*   [特典・キャンペーン](https://mobile.nuro.jp/campaign/)
    
*   [端末](https://mobile.nuro.jp/product/)
    
*   [FAQs新しいウィンドウで開く](https://support.sonynetwork.co.jp/faqsupport/nuromobile/web/index.html)
    
*   [スマホのアレコレ](https://mobile.nuro.jp/sumaho-arekore/)
    

*   [料金・プランについて](https://mobile.nuro.jp/plan/)
    
*   [NEOプラン](https://mobile.nuro.jp/plan/neoplan/)
    
*   [バリュープラス](https://mobile.nuro.jp/plan/valueplus/)
    
*   [かけ放題ジャスト](https://mobile.nuro.jp/plan/kakeho/)
    

*   [端末一覧](https://mobile.nuro.jp/product/)
    
*   [端末在庫情報 新しいウィンドウで開く](https://mobile.nuro.jp/deviceStockInformation/)
    
*   [Xperia 10 V特設ページ](https://mobile.nuro.jp/xperia/)
    
*   [SIMカード動作確認済端末一覧](https://mobile.nuro.jp/support/device/)
     
*   [eSIM動作確認済端末一覧](https://mobile.nuro.jp/support/device-esim/)
     

![閉じる](https://mobile.nuro.jp/images/nmui2/index/menu-close.svg)

[NUROモバイルについて](https://mobile.nuro.jp/about/)

[お申し込みの流れ](https://mobile.nuro.jp/guide/sim.html)

料金・プラン
------

*   [料金・プランについて](https://mobile.nuro.jp/plan/)
    
*   [NEOプラン](https://mobile.nuro.jp/plan/neoplan/)
    
*   [バリュープラス](https://mobile.nuro.jp/plan/valueplus/)
    
*   [かけ放題ジャスト](https://mobile.nuro.jp/plan/kakeho/)
    

[オプション・サービス](https://mobile.nuro.jp/option/)

[特典・キャンペーン](https://mobile.nuro.jp/campaign/)

端末
--

*   [端末一覧](https://mobile.nuro.jp/product/)
    
*   [端末在庫情報 新しいウィンドウで開く](https://mobile.nuro.jp/deviceStockInformation/)
    
*   [Xperia 10 V特設ページ](https://mobile.nuro.jp/xperia/)
    
*   [SIMカード動作確認済端末一覧](https://mobile.nuro.jp/support/device/)
    
*   [eSIM動作確認済端末一覧](https://mobile.nuro.jp/support/device-esim/)
    

[FAQs 新しいウィンドウで開く](https://support.sonynetwork.co.jp/faqsupport/nuromobile/web/index.html)

[スマホのアレコレ](https://mobile.nuro.jp/sumaho-arekore/)

[お申し込み](https://www.nuro.jp/app/nuromobile-directolsu/entry/new/)

[![マイページ](https://mobile.nuro.jp/images/nmui2/mypage.png)マイページ](https://mobile.nuro.jp/user/userMenu/)

Previous

 [![感動を止めるな。ちゃんみなLIVEチケット等、豪華賞品が当たるキャンペーン実施中](https://mobile.nuro.jp/images/nmui2/kv/catch-bg8_pc.png)\
\
お申し込みはこちら](https://www.nuro.jp/hikari/campaign/brand/?SmRcid=sny_s_nuromobile_top_bnr)

 [![ネットとスマホをまとめておトクに！NURO光のセット割](https://mobile.nuro.jp/images/nmui2/kv/catch-bg6_pc.png)\
\
お申し込みはこちら](https://www.nuro.jp/hikari/campaign/hikarimobileset/?SmRcid=sny_s_nuromobile_top_bnr)

 [![バリュープラス 人気の5GBプランなら 1年間ずーっと割引！499円/月](https://mobile.nuro.jp/images/nmui2/kv/catch-bg7_pc.png)\
\
お申し込みはこちら](https://mobile.nuro.jp/campaign/voice-sim/)

 [![感動を止めるな。ちゃんみなLIVEチケット等、豪華賞品が当たるキャンペーン実施中](https://mobile.nuro.jp/images/nmui2/kv/catch-bg8_pc.png)\
\
お申し込みはこちら](https://www.nuro.jp/hikari/campaign/brand/?SmRcid=sny_s_nuromobile_top_bnr)

 [![ネットとスマホをまとめておトクに！NURO光のセット割](https://mobile.nuro.jp/images/nmui2/kv/catch-bg6_pc.png)\
\
お申し込みはこちら](https://www.nuro.jp/hikari/campaign/hikarimobileset/?SmRcid=sny_s_nuromobile_top_bnr)

 [![バリュープラス 人気の5GBプランなら 1年間ずーっと割引！499円/月](https://mobile.nuro.jp/images/nmui2/kv/catch-bg7_pc.png)\
\
お申し込みはこちら](https://mobile.nuro.jp/campaign/voice-sim/)

 [![感動を止めるな。ちゃんみなLIVEチケット等、豪華賞品が当たるキャンペーン実施中](https://mobile.nuro.jp/images/nmui2/kv/catch-bg8_pc.png)\
\
お申し込みはこちら](https://www.nuro.jp/hikari/campaign/brand/?SmRcid=sny_s_nuromobile_top_bnr)

 [![ネットとスマホをまとめておトクに！NURO光のセット割](https://mobile.nuro.jp/images/nmui2/kv/catch-bg6_pc.png)\
\
お申し込みはこちら](https://www.nuro.jp/hikari/campaign/hikarimobileset/?SmRcid=sny_s_nuromobile_top_bnr)

Next

*   1
*   2
*   3

*   [料金・プラン](https://mobile.nuro.jp/plan/)
    
*   [オプション・サービス](https://mobile.nuro.jp/option/)
    
*   [端末](https://mobile.nuro.jp/product/)
    
*   [特典・キャンペーン](https://mobile.nuro.jp/campaign/)
    
*   [お申し込みの流れ](https://mobile.nuro.jp/guide/sim.html)
    
*   [FAQ新しいウィンドウで開く](https://support.sonynetwork.co.jp/faqsupport/nuromobile/web/index.html)
    
*   [NUROモバイルについて](https://mobile.nuro.jp/about/)
    
*   [スマホのアレコレ](https://mobile.nuro.jp/sumaho-arekore/)
    

[![NEOプラン35～55GB2,699円。クリックでNEOプラン詳細ページへ](https://mobile.nuro.jp/images/nmui2/index/mv-img1-sp.png?1658231536812)](https://mobile.nuro.jp/plan/neoplan/)

---------------------------------------------------------------------------------------------------------------------------------------------------------

[![バリュープラス。3GB792円。クリックでバリュープラス詳細ページへ](https://mobile.nuro.jp/images/nmui2/index/mv-img2-sp.png?1658231536812)](https://mobile.nuro.jp/plan/valueplus/)

--------------------------------------------------------------------------------------------------------------------------------------------------------

[![かけ放題ジャスト。5分かけ放題1GB930円。各種取り揃えたかけ放題詳細ページへ](https://mobile.nuro.jp/images/nmui2/index/mv-img3-sp.png?1658231536812)](https://mobile.nuro.jp/plan/kakeho/)

-----------------------------------------------------------------------------------------------------------------------------------------------------------

特に注記のない限り、記載の金額は全て税込金額です。

実施中の特典・キャンペーン
-------------

Previous

[![VLプラン（10GB）の月額料金が1485円から994円に1年間割引](https://mobile.nuro.jp/images/nmui2/index/mv-carousel82-sp.png?20251016)](https://mobile.nuro.jp/campaign/voice-sim/)

[![VLLプラン（15GB）の月額料金が1790円から1299円に1年間割引](https://mobile.nuro.jp/images/nmui2/index/mv-carousel83-sp.png?20251016)](https://mobile.nuro.jp/campaign/voice-sim/)

[![NEOプラン（35GB）の月額料金が2699円から2209円に1年間割引](https://mobile.nuro.jp/images/nmui2/index/mv-carousel84-sp.png?20251016)](https://mobile.nuro.jp/campaign/voice-sim/)

[![VMプラン（5GB）の月額料金が990円から499円に1年間割引](https://mobile.nuro.jp/images/nmui2/index/mv-carousel81-sp.png?20251016)](https://mobile.nuro.jp/campaign/voice-sim/)

[![VLプラン（10GB）の月額料金が1485円から994円に1年間割引](https://mobile.nuro.jp/images/nmui2/index/mv-carousel82-sp.png?20251016)](https://mobile.nuro.jp/campaign/voice-sim/)

[![VLLプラン（15GB）の月額料金が1790円から1299円に1年間割引](https://mobile.nuro.jp/images/nmui2/index/mv-carousel83-sp.png?20251016)](https://mobile.nuro.jp/campaign/voice-sim/)

[![NEOプラン（35GB）の月額料金が2699円から2209円に1年間割引](https://mobile.nuro.jp/images/nmui2/index/mv-carousel84-sp.png?20251016)](https://mobile.nuro.jp/campaign/voice-sim/)

[![VMプラン（5GB）の月額料金が990円から499円に1年間割引](https://mobile.nuro.jp/images/nmui2/index/mv-carousel81-sp.png?20251016)](https://mobile.nuro.jp/campaign/voice-sim/)

[![VLプラン（10GB）の月額料金が1485円から994円に1年間割引](https://mobile.nuro.jp/images/nmui2/index/mv-carousel82-sp.png?20251016)](https://mobile.nuro.jp/campaign/voice-sim/)

[![VLLプラン（15GB）の月額料金が1790円から1299円に1年間割引](https://mobile.nuro.jp/images/nmui2/index/mv-carousel83-sp.png?20251016)](https://mobile.nuro.jp/campaign/voice-sim/)

[![NEOプラン（35GB）の月額料金が2699円から2209円に1年間割引](https://mobile.nuro.jp/images/nmui2/index/mv-carousel84-sp.png?20251016)](https://mobile.nuro.jp/campaign/voice-sim/)

Next

[その他のキャンペーン情報はこちら](https://mobile.nuro.jp/campaign/)

[お申し込みはこちら](https://www.nuro.jp/app/nuromobile-directolsu/entry/new/)

[料金](https://mobile.nuro.jp/plan/)

[申し込みの流れ](https://mobile.nuro.jp/guide/sim.html)

[端末情報](https://mobile.nuro.jp/product/)

格安スマホ・格安SIM

NUROモバイルの3つのポイント
----------------

![](https://mobile.nuro.jp/images/nmui2/index/img0.png)

### 選びやすい料金プラン

使い方にあわせて選べる料金プラン。データ容量の翌月繰越ができるので、毎月ムダなくご利用いただけます。

[料金プランはこちら](https://mobile.nuro.jp/plan/)

![もちろんiPhoneも使える](https://mobile.nuro.jp/images/nmui2/index/img1.png)

### 今のスマホがそのまま使える！

お手持ちの端末が対応していれば、お申し込み後に届くSIMカードまたは[すぐに使えるeSIMを選んで設定](https://mobile.nuro.jp/sim/esim/)
するだけ。乗り換えの面倒な手間を省きます。

[動作確認済端末はこちら](https://mobile.nuro.jp/support/device/)

![](https://mobile.nuro.jp/images/nmui2/index/img2.png)

### 自宅で完了！NUROモバイルのはじめ方

ご利用開始までのステップをご紹介。ご自宅にいながらすべての手続きが出来ます。

[ご利用ガイドはこちら](https://mobile.nuro.jp/guide/)

使いやすさも、安心も

NUROモバイルの特長
-----------

### 通話料が半額

![](https://mobile.nuro.jp/images/nmui2/index/img5.png)

オートプレフィックス機能で、手間をかけずに通話料半額。

### ムダなく使えるデータ

![](https://mobile.nuro.jp/images/nmui2/index/img4.png)

データ容量は繰越やギフトでやりくり可能。もう追加課金いらずです。

### 解約金0円。他にも？！

![](https://mobile.nuro.jp/images/nmui2/index/img11.png)

解約金・MNP転出手数料が0円！気軽にお試しできます。

### 生成AIで  
24時間サポート

![](https://mobile.nuro.jp/images/nmui2/index/img22.png)

[生成AIを用いたチャットボット](https://support.sonynetwork.co.jp/faqsupport/nuromobile-bot/chat/150/index.html?utm_source=m-pages&utm_medium=paper&utm_campaign=mbqa-sp-aichat)
新しいウィンドウで開くが質問から５秒程度で迅速に回答。いつでもお客様の疑問に対応します。

ご利用中のみなさんに聞いてみた！

NUROモバイルを選んだ理由
--------------

NUROモバイルご利用者さまのリアルな声をご紹介しています。

Previous

![](https://mobile.nuro.jp/images/nmui2/index/img_02.png)

女性 40代  
VLプラン

データ容量と価格のバランスが良い。設定されたデータ容量は少な目だが、繰越とパケットギフトで十分な量が確保できる。運営会社が信頼できる。回線が選べる。3日の通信速度制限がない。

![](https://mobile.nuro.jp/images/nmui2/index/img_02.png)

女性 40代  
NEOプラン

夫が選んでましたので、ついでに頼みました。 他社のCMとかはイメージだけで、結局NUROモバイルのNEOプランが、実用的な通信速度で、家族でギガ分け合えて、上り通信はカウントフリーだし、SNSもカウントフリー。今どのくらい使ったかは、ブラウザから見なければいけないが、即反映されているので良い。

![](https://mobile.nuro.jp/images/nmui2/index/img_01.png)

男性 30代  
VSプラン

ニュースしか見ないのですが、それでも1GBは余裕で使っていたので、音声通話付きSIMで1,000円未満を探していたところ、データ容量3GBで800円を切り、なおかつ繰越あり＆3日通信制限がない、他にはない魅力的なプランがだったので。

![](https://mobile.nuro.jp/images/nmui2/index/img_02.png)

女性 30代  
VSプラン

他社より安価であり、初月の月額基本料金が無料のため、繋がりやすさ等を確認するためのお試し契約がしやすかった。また、MNPでの申し込みもしやすく煩雑な手続きがなかった。現在契約を継続している理由は安価であり、特に繋がりにくい等の不便がないため。

![](https://mobile.nuro.jp/images/nmui2/index/img_02.png)

女性 50代  
VSプラン

とにかく安く済む。ほとんど家でのNURO 光のWi-Fiを使用しているので、たまに旅行や買い物に出た時くらいしか、モバイル回線は使わないから、安いことが重要。でもいざという時に問題なく使えるところも良い。

![](https://mobile.nuro.jp/images/nmui2/index/img_01.png)

男性 30代  
VMプラン

これまで他の格安SIMの3GBプランを利用していたが毎月、月末になるとデータ容量が足りなくなり低速で我慢していた。また特段他社と比べても価格のメリットがなくなってきたため、価格・データ容量とも納得できるNUROモバイルのバリュープラスを選択した。 趣味の登山の際も安心して使用できるドコモ回線を選べることもNUROモバイルを選んだ理由の一つである。

![](https://mobile.nuro.jp/images/nmui2/index/img_02.png)

女性 40代  
VMプラン

料金。 ひとまず使ってみても良いかなと思える金額だった。 1か月利用した通信量を見て、翌月のプラン変更が簡単に自由にできた。 翌月に繰り越せる。 3か月に1回、Gigaプラスでギガがもらえる。

![](https://mobile.nuro.jp/images/nmui2/index/img_02.png)

女性 40代  
VLプラン

データ容量と価格のバランスが良い。設定されたデータ容量は少な目だが、繰越とパケットギフトで十分な量が確保できる。運営会社が信頼できる。回線が選べる。3日の通信速度制限がない。

![](https://mobile.nuro.jp/images/nmui2/index/img_02.png)

女性 40代  
NEOプラン

夫が選んでましたので、ついでに頼みました。 他社のCMとかはイメージだけで、結局NUROモバイルのNEOプランが、実用的な通信速度で、家族でギガ分け合えて、上り通信はカウントフリーだし、SNSもカウントフリー。今どのくらい使ったかは、ブラウザから見なければいけないが、即反映されているので良い。

![](https://mobile.nuro.jp/images/nmui2/index/img_01.png)

男性 30代  
VSプラン

ニュースしか見ないのですが、それでも1GBは余裕で使っていたので、音声通話付きSIMで1,000円未満を探していたところ、データ容量3GBで800円を切り、なおかつ繰越あり＆3日通信制限がない、他にはない魅力的なプランがだったので。

![](https://mobile.nuro.jp/images/nmui2/index/img_02.png)

女性 30代  
VSプラン

他社より安価であり、初月の月額基本料金が無料のため、繋がりやすさ等を確認するためのお試し契約がしやすかった。また、MNPでの申し込みもしやすく煩雑な手続きがなかった。現在契約を継続している理由は安価であり、特に繋がりにくい等の不便がないため。

![](https://mobile.nuro.jp/images/nmui2/index/img_02.png)

女性 50代  
VSプラン

とにかく安く済む。ほとんど家でのNURO 光のWi-Fiを使用しているので、たまに旅行や買い物に出た時くらいしか、モバイル回線は使わないから、安いことが重要。でもいざという時に問題なく使えるところも良い。

![](https://mobile.nuro.jp/images/nmui2/index/img_01.png)

男性 30代  
VMプラン

これまで他の格安SIMの3GBプランを利用していたが毎月、月末になるとデータ容量が足りなくなり低速で我慢していた。また特段他社と比べても価格のメリットがなくなってきたため、価格・データ容量とも納得できるNUROモバイルのバリュープラスを選択した。 趣味の登山の際も安心して使用できるドコモ回線を選べることもNUROモバイルを選んだ理由の一つである。

![](https://mobile.nuro.jp/images/nmui2/index/img_02.png)

女性 40代  
VMプラン

料金。 ひとまず使ってみても良いかなと思える金額だった。 1か月利用した通信量を見て、翌月のプラン変更が簡単に自由にできた。 翌月に繰り越せる。 3か月に1回、Gigaプラスでギガがもらえる。

![](https://mobile.nuro.jp/images/nmui2/index/img_02.png)

女性 40代  
VLプラン

データ容量と価格のバランスが良い。設定されたデータ容量は少な目だが、繰越とパケットギフトで十分な量が確保できる。運営会社が信頼できる。回線が選べる。3日の通信速度制限がない。

Next

NUROモバイル（NEOプラン・バリュープラス）契約者へのWebアンケート調査による 弊社調べ2022年7月13日～20日実施

[お申し込みはこちら](https://www.nuro.jp/app/nuromobile-directolsu/entry/new/)

[料金](https://mobile.nuro.jp/plan/)

[申し込みの流れ](https://mobile.nuro.jp/guide/sim.html)

[端末情報](https://mobile.nuro.jp/product/)

そのまま使う？新しくする？

使用するスマホ  
について
--------------

### 今のスマホをそのまま使う

![iPhoneも今のまま使える](https://mobile.nuro.jp/images/nmui2/index/img7.png)

電話番号もアプリも全部そのまま！お申し込み時に選んだSIMを設定するだけで乗り換えできます。

[NUROモバイルで使える端末一覧はこちら](https://mobile.nuro.jp/support/device/)

### 新しいスマホを購入する

![](https://mobile.nuro.jp/images/nmui2/index/img8.png)

お申し込み時に新しいスマートフォンを一緒に購入することもできます。

[販売中の端末はこちら](https://mobile.nuro.jp/product/)

オススメの端末
-------

### motog05

![](https://mobile.nuro.jp/common/images/device/device_img_g05.png)

本体端末価格 19,800円

### Xperoa10VII

![](https://mobile.nuro.jp/images/nmui2/product/index/top/device_img_xperia10vii.png)

本体端末価格 74,800円

もっと便利にカスタマイズ  

オプション・サービス
----------

選べる！[### 通話定額  \
オプション\
\
![](https://mobile.nuro.jp/images/nmui2/index/imgs16.png?1658231536812)\
\
詳しくはこちら](https://mobile.nuro.jp/option/denwa/kakeho.html)

今のスマホをそのまま  
使う人でもOK！[### 端末補償\
\
![](https://mobile.nuro.jp/images/nmui2/index/img12.png?1658231536812)\
\
詳しくはこちら](https://mobile.nuro.jp/option/hoshou/)

スマホに安心を[### ウイルスバスター  \
モバイル\
\
![](https://mobile.nuro.jp/images/nmui2/index/img21.png?1658231536812)\
\
詳しくはこちら](https://mobile.nuro.jp/option/trend/)

VMプラン/VLプラン/VLLプラン/  
5分かけ放題プラン/10分かけ放題プラン限定  
[### バリュー  \
データフリー\
\
![](https://mobile.nuro.jp/images/nmui2/index/img_s20.png?1658231536812)\
\
詳しくはこちら](https://mobile.nuro.jp/option/value-datafree/)

NEOプラン/NEOプランW[### NEOデータフリー\
\
![](https://mobile.nuro.jp/images/nmui2/index/img_s17.png?1658231536812)\
\
詳しくはこちら](https://mobile.nuro.jp/option/neo-datafree/)

NEOプラン/NEOプランW[### あげ放題\
\
![](https://mobile.nuro.jp/images/nmui2/index/imgs19.png?1658231536812)\
\
詳しくはこちら](https://mobile.nuro.jp/option/age-hodai/)

[オプション・サービス一覧はこちら](https://mobile.nuro.jp/option/)

[お申し込みはこちら](https://www.nuro.jp/app/nuromobile-directolsu/entry/new/)

[料金](https://mobile.nuro.jp/plan/)

[申し込みの流れ](https://mobile.nuro.jp/guide/sim.html)

[端末情報](https://mobile.nuro.jp/product/)

格安SIM・格安携帯に関するよくある質問（FAQs）
--------------------------

### 5Gに対応していますか？

はい、5Gオプションが無料でご利用いただけます。NUROモバイル利用開始後に、「ご利用者向けページ」にてお申し込みください。  
※ [オプションのご利用/お申し込みについての各種条件はこちらをご確認ください](https://mobile.nuro.jp/option/5g/)
。

### APN設定をしたいです。

SIMカードに同梱のマニュアルまたは[WEBのマニュアル](https://mobile.nuro.jp/support/settings/apn/)
をご確認ください。  
MNP（他社からのお乗り換え）でお申し込みの場合、SIMカードお受け取り後にご自身で開通手続きを行っていただく必要があります。APN設定は、開通手続き後に行ってください。  
お申し込み時に「MNP手続き済のSIMカードを受け取る」を希望した場合、開通手続きは不要です。

### 申し込みの際、キャリア回線は選択できますか？

NUROモバイルはトリプルキャリア対応のため、ドコモ回線/au回線/ソフトバンク回線よりお選びいただけます。  
※ かけ放題ジャストは、ドコモ回線・au回線のみの提供です。

[その他のFAQsはこちら新しいウインドウで開く](https://support.sonynetwork.co.jp/faqsupport/nuromobile/web/index.html)

お知らせ
----

*   2025.10.09 お知らせ NUROモバイル、[お申し込み時の本人確認において、マイナンバーカードによる公的個人認証サービス（JPKI）に対応](https://mobile.nuro.jp/support/identity-verification.html)
    しました。
*   2025.10.03 お知らせ 2025年10月12日(日)午前8:00～午後1:00の間、みずほ銀行のシステムメンテナンスに伴い、みずほ銀行でのキャッシュバックの受取手続きをご利用いただけません。  
    ご迷惑をおかけしますが、ご理解を賜りますよう何卒よろしくお願いいたします。
*   2025.10.03 お知らせ 2025年10月9日(木)午前1:00～午前5:00の間、キャッシュバックの受取手続きをご利用いただけません。  
    ご迷惑をおかけしますが、ご理解を賜りますよう何卒よろしくお願いいたします。
*   2025.10.01 お知らせ [NUROモバイル　ご利用規約の改訂について](https://mobile.nuro.jp/news_release/2025/1001.html)
    新しいウィンドウで開く
*   2025.09.29 お知らせ [ドコモ回線の3Gサービス終了に伴うお知らせ](https://mobile.nuro.jp/news_release/2025/0929.html)
    新しいウィンドウで開く
*   2025.08.05 お知らせ 2025年8月14日(木)午前3:00～午前4:00の間、キャッシュバックの受取手続きをご利用いただけません。  
    ご迷惑をおかけしますが、ご理解を賜りますよう何卒よろしくお願いいたします。
*   2025.07.30 お知らせ 津波警報の影響により、NUROモバイルの一部の配送に遅延および配達見合わせが発生しております。  
    詳しい状況や最新情報は、[ヤマトホールディングスのお知らせ](https://www.yamato-hd.co.jp/important/info_250730_1.html)
    新しいウィンドウで開くをご確認ください。
*   2025.07.11 お知らせ [【緊急】システムメンテナンスのお知らせ](https://mobile.nuro.jp/news_release/2025/0711.html)
    新しいウィンドウで開く
*   2025.06.19 お知らせ [【緊急】システムメンテナンスのお知らせ](https://mobile.nuro.jp/news_release/2025/0619.html)
    新しいウィンドウで開く
*   2025.06.11 お知らせ [ユニバーサルサービス料改訂のお知らせ](https://mobile.nuro.jp/news_release/2025/0611.html)
    新しいウィンドウで開く
*   2025.06.04 お知らせ 2025年6月12日(木)午前3:00～午前4:00の間、キャッシュバックの受取手続きをご利用いただけません。  
    ご迷惑をおかけしますが、ご理解を賜りますよう何卒よろしくお願いいたします。
*   2025.05.29 お知らせ [NUROモバイル　対応機器販売規約の改訂について](https://mobile.nuro.jp/news_release/2025/0529.html)
    新しいウィンドウで開く
*   2025.04.15 お知らせ キャッシュバック：ゴールデンウィーク期間のお振り込みについて  
    ゴールデンウィーク期間の振込業務停止に伴い、以下の期間にキャッシュバックのお手続きをされた場合、お振り込みは2025年5月7日以降となります。あらかじめご了承ください。  
    【振込停止期間】2025年5月2日(金)14:30 ～ 2025年5月7日(水)8:50
*   2025.04.02 お知らせ 2025年4月10日(木)午前3:00～午前4:00の間、キャッシュバックの受取手続きをご利用いただけません。  
    ご迷惑をおかけしますが、ご理解を賜りますよう何卒よろしくお願いいたします。
*   2025.03.31 お知らせ [【復旧済み】ソフトバンク回線のデータ専用SIMの発送遅延について](https://mobile.nuro.jp/news_release/2025/033102.html)
    新しいウィンドウで開く
*   2025.03.31 お知らせ [電話リレーサービス料のご負担について](https://mobile.nuro.jp/news_release/2025/0331.html)
    新しいウィンドウで開く
*   2025.03.28 お知らせ [ソフトバンク回線のデータ専用SIMの発送遅延について](https://mobile.nuro.jp/news_release/2025/0328.html)
    新しいウィンドウで開く
*   2025.03.19 お知らせ 2025年3月27日(木)午前0:00～午前6:00の間、キャッシュバックの受取手続きをご利用いただけません。  
    ご迷惑をおかけしますが、ご理解を賜りますよう何卒よろしくお願いいたします。
*   2025.03.14 お知らせ moto g05のお取り扱いを開始しました。
*   2025.03.04 お知らせ 大雪の影響により、NUROモバイルの一部の配送に遅延が発生する可能性がございます。  
    詳しい状況や最新情報は、[ヤマトホールディングスのお知らせ](https://www.yamato-hd.co.jp/important/info_250304_1.html)
    新しいウィンドウで開くをご確認ください。
*   2025.03.01 お知らせ 音声通話付きSIMのバリュープラスVMプラン・VLプランのお乗り換え（MNP)で、月額基本料金が5か月割引、5分かけ放題オプションが6か月間無料。[特典の詳細はこちら](https://mobile.nuro.jp/campaign/voice-sim/)
      
    また、NEOプランのお乗り換え（MNP)で、月額基本料金が3か月割引。キャンペーン期間中にNEOプランのお申し込みで、抽選で1名様の月額基本料金が最大1年間無料。[特典の詳細はこちら](https://mobile.nuro.jp/campaign/neoplan/)
    
*   2025.02.28 お知らせ [NUROモバイル　ご利用規約の改訂について](https://mobile.nuro.jp/news_release/2025/0228.html)
    新しいウィンドウで開く
*   2025.02.18 お知らせ 大雪の影響により、NUROモバイルの一部の配送に遅延が発生する可能性がございます。  
    詳しい状況や最新情報は、[ヤマトホールディングスのお知らせ](https://www.yamato-hd.co.jp/important/info_250204_1.html)
    新しいウィンドウで開くをご確認ください。
*   2025.02.04 お知らせ 大雪の影響により、NUROモバイルの一部の配送に遅延および配達見合わせが発生しております。  
    詳しい状況や最新情報は、[ヤマトホールディングスのお知らせ](https://www.yamato-hd.co.jp/important/info_250204_1.html)
    新しいウィンドウで開くをご確認ください。
*   2025.02.03 お知らせ OPPO A3 5G、Redmi 14Cのお取り扱いを開始しました。
*   2025.01.16 お知らせ 2025年1月23日(木)午前0:00～午前7:00の間、キャッシュバックの受取手続きをご利用いただけません。  
    ご迷惑をおかけしますが、ご理解を賜りますよう何卒よろしくお願いいたします。
*   2025.01.15 お知らせ [NUROモバイル　ご利用規約の改訂について](https://mobile.nuro.jp/news_release/2025/0115.html)
    新しいウィンドウで開く
*   2025.01.10 お知らせ 大雪の影響により、NUROモバイルの一部の配送に遅延および配達見合わせが発生しております。  
    詳しい状況や最新情報は、[ヤマトホールディングスのお知らせ](https://www.kuronekoyamato.co.jp/ytc/chien/chien_hp.html)
    新しいウィンドウで開くをご確認ください。
*   2025.01.07 お知らせ 2025年1月12日(日)19:00～2025年1月13日(月)13:00の間、三井住友銀行のシステムメンテナンスに伴い、キャッシュバックの受取手続きが遅延する可能性があります。  
    ご迷惑をおかけしますが、ご理解を賜りますよう何卒よろしくお願いいたします。
*   2024.12.18 お知らせ [Xperia10VI価格改定のお知らせ](https://mobile.nuro.jp/news_release/2024/1218.html)
    新しいウィンドウで開く
*   2024.12.10 お知らせ キャッシュバック：年末年始のお振り込みについて  
    年末年始における銀行の振込業務停止に伴い、以下の期間にキャッシュバックのお手続きをされた場合、お振り込みは2025年1月6日以降となります。あらかじめご了承ください。  
    【振込停止期間】2024年12月31日(火)14:30 ～ 2025年1月6日(月)08:50
*   2024.12.6 お知らせ 2024年12月12日(木)午前3:00～午前4:00の間、キャッシュバックの受取手続きをご利用いただけません。  
    ご迷惑をおかけしますが、ご理解を賜りますよう何卒よろしくお願いいたします。
*   2024.11.19 お知らせ 2024年11月21日(木)午前1:00～午前5:00の間、キャッシュバックの受取手続きをご利用いただけません。ご迷惑をおかけしますが、ご理解を賜りますよう何卒よろしくお願いいたします。
*   2024.11.15 お知らせ [健康保険証等の本人確認書類としてのお取り扱い終了のお知らせ](https://mobile.nuro.jp/news_release/2024/1115.html)
    新しいウィンドウで開く
*   2024.11.08 お知らせ [NUROモバイル　ご利用規約の改訂について](https://mobile.nuro.jp/news_release/2024/1108.html)
    新しいウィンドウで開く
*   2024.11.01 お知らせ [NEOプラン3周年 大感謝祭 実施中！](https://mobile.nuro.jp/campaign/neoplan-3rd-anniversary/)
    
*   2024.10.09 お知らせ [一部のSIMカード(ドコモ回線)における通信不良について](https://mobile.nuro.jp/news_release/2024/1009.html)
    新しいウィンドウで開く
*   2024.10.03 お知らせ 2024年10月10日(木)午前1:00～午前5:00の間、キャッシュバックの受取手続きをご利用いただけません。  
    ご迷惑をおかけしますが、ご理解を賜りますよう何卒よろしくお願いいたします。
*   2024.10.01 お知らせ 音声通話付きSIMのVSプラン・VMプラン・VLプラン・VLLプランにお乗り換え（MNP）で、月額基本料金が3か月間割引。[特典の詳細はこちら](https://mobile.nuro.jp/campaign/voice-sim/)
    
*   2024.09.02 お知らせ NEOプラン/NEOプランWの初期費用有料化に関するお知らせ。[詳細はこちら](https://mobile.nuro.jp/news_release/2024/0902.html)
    新しいウィンドウで開く
*   2024.08.29 お知らせ 台風10号の影響により、NUROモバイルの一部の配送に遅延および配達見合わせが発生しております。  
    詳しい状況や最新情報は、[ヤマトホールディングスのお知らせ](https://www.yamato-hd.co.jp/important/info_240823_2.html)
    新しいウィンドウで開くをご確認ください。
*   2024.08.16 お知らせ 台風7号の影響により、NUROモバイルの一部の配送に遅延および配達見合わせが発生しております。  
    詳しい状況や最新情報は、[ヤマトホールディングスのお知らせ](https://www.yamato-hd.co.jp/important/info_240814.html)
    新しいウィンドウで開くをご確認ください。
*   2024.08.09 お知らせ 宮崎県日向灘沖で発生した地震の影響により、一部の配送に遅延が発生する可能性がございます。[詳しい状況や最新情報は、こちらにてご確認ください。](https://www.kuronekoyamato.co.jp/ytc/chien/chien_hp.html)
    新しいウィンドウで開く
*   2024.08.01 お知らせ 2024年8月8日(木) 午前1:00 ～ 午前4:00の間、 システムメンテナンスにより、通信の瞬断が発生いたします。  
    お手続き中にエラーが発生した場合は、再度お手続きいただけますようお願いいたします。
*   2024.07.19 お知らせ 7月19日現在、システムトラブルによる影響により、サポートデスクへのお電話、チャットが繋がりにくい状況が発生しております。  
    恐れ入りますが、チャットまたはメールにてお問い合わせくださいますよう、お願い申し上げます。
    
    なお、ご利用者向けページからもお手続きいただけます。あわせてご利用くださいますようお願いいたします。
    
    [ご利用者向けページ](https://www.nuro.jp/app/mypage/login/)
    新しいウィンドウで開く
    
    ご不便をおかけし誠に申し訳ございませんが、何卒よろしくお願い申し上げます。
*   2024.07.05 お知らせ Xperia 10 VIのお取り扱いを開始しました。
*   2024.07.01 お知らせ 音声通話付きSIMのVMプラン・VLプラン・VLLプランをお申し込みで、月額基本料金が3か月間割引。[特典の詳細はこちら](https://mobile.nuro.jp/campaign/voice-sim/)
      
    5分かけ放題プラン(1GB)をお申し込みで、月額基本料金が3か月間割引。[特典の詳細はこちら](https://mobile.nuro.jp/campaign/kakeho-plan/)
    
*   2024.07.01 お知らせ 2024年7月4日(木) 午前1:00 ～ 午前5:00の間、 システムメンテナンスにより、通信の瞬断が発生いたします。  
    お手続き中にエラーが発生した場合は、再度お手続きいただけますようお願いいたします。
*   2024.06.13 お知らせ NUROモバイル、「[MNPワンストップ方式](https://mobile.nuro.jp/mnp/onestop/)
    」を導入、[音声通話付きSIM（MNP）においてもeSIMの提供開始](https://mobile.nuro.jp/sim/esim/)
    しました。
*   2024.06.07 お知らせ eSIMプロファイルの取り扱いにご注意ください。  
    eSIMプロファイルにはお客さまの回線契約情報が含まれているため、 不正利用による被害防止の観点から、絶対に第3者へ共有することがないようにお願いいたします。  
    ご不明な点がございましたらNURO SIMサービスサポートまでお問い合わせください。
*   2024.06.07 お知らせ 2024年6月13日(木) 午前0:00 ～ 午前6:00の間、 システムメンテナンスにより、複数回の瞬断が発生いたします。  
    お手続き中にエラーが発生した場合は、再度お手続きいただけますようお願いいたします。
*   2024.04.08 お知らせ 2024年4月11日(木) 午前1:00 ～ 午前5:00の間、 キャッシュバックの受取手続きをご利用いただけません。  
    ご迷惑をおかけしますが、ご理解を賜りますよう何卒よろしくお願いいたします。
*   2024.04.03 お知らせ [電話リレーサービス料のご負担について](https://mobile.nuro.jp/news_release/2024/0403.html)
    新しいウィンドウで開く
*   2024.03.27 お知らせ [【NUROモバイル】ソフトバンクの3Gサービス終了に伴うお知らせ（更新）](https://mobile.nuro.jp/news_release/2024/0118.html)
    新しいウィンドウで開く
*   2024.03.12 お知らせ 2024年3月14日(木) 午前3時00分～午前4時00分の間、 キャッシュバックの受取手続きをご利用いただけません。  
    ご迷惑をおかけしますが、ご理解を賜りますよう何卒よろしくお願いいたします。
*   2024.02.05 お知らせ 関東甲信の降雪の影響により一部の配送に遅延が発生しております。 [詳しい状況や最新情報は、こちらにてご確認ください。](https://www.yamato-hd.co.jp/important/info_240205.html)
    新しいウィンドウで開く
*   2024.02.01 お知らせ NEOプランにお乗り換え（MNP）で13,000円キャッシュバック特典実施中。※新規の場合は5,000円 [特典の詳細はこちら](https://mobile.nuro.jp/plan/neoplan/campaign/)
      
    NEOプランWにお乗り換え（MNP）で16,000円キャッシュバック特典実施中。※新規の場合は5,000円 [特典の詳細はこちら](https://mobile.nuro.jp/plan/neoplan/campaign/w/)
      
    音声通話付きSIMのVSプラン・VMプラン・VLプラン・VLLプランにお乗り換え（MNP）で、月額基本料金が3か月間割引。※新規の場合は1か月間 [特典の詳細はこちら](https://mobile.nuro.jp/campaign/voice-sim/)
    
*   2024.01.31 お知らせ [【重要】【NUROモバイル】送信メールドメイン追加のお知らせ](https://mobile.nuro.jp/news_release/2024/0131.html)
    新しいウィンドウで開く
*   2024.01.09 お知らせ [【NUROモバイル】「令和6年能登半島地震」による災害に伴う減免措置について](https://mobile.nuro.jp/news_release/2024/0109.html)
    新しいウィンドウで開く
*   2024.01.09 お知らせ 能登半島地震の影響により、一部の配送に遅延および配達見合わせが発生しております。 [詳しい状況や最新情報は、こちらにてご確認ください。](https://www.yamato-hd.co.jp/important/hd_ja_important.html)
    新しいウィンドウで開く
*   2023.12.13 お知らせ キャッシュバック：年末年始のお振り込みについて  
    年末年始における銀行の振込業務停止に伴い、以下の期間にキャッシュバックのお手続きをされた場合、お振り込みは2024年1月4日以降となります。あらかじめご了承ください。  
    【振込停止期間】2023年12月29日(金)14:30 ～ 2024年1月4日(木)08:50
*   2023.12.08 お知らせ 年末年始については、以下の通りサポート窓口を休業とさせていただきます。  
    対象窓口：  
    　NURO SIM サービスサポート  
    　NURO SIM 登録センター  
    　NURO モバイル アプリサポート  
    休業日：  
    　2023年12月31日（日）～2024年1月3日（水）  
    　※1月4日（木）10時より通常通り営業を再開いたします。
*   2023.12.06 お知らせ 2023年12月14日 午前3時00分～午前4時00分の間、キャッシュバックの受取手続きをご利用いただけません。  
    ご迷惑をおかけしますが、ご理解を賜りますよう何卒よろしくお願いいたします。
*   2023.11.08 お知らせ Android端末において、NUROモバイルアプリがご利用いただけない不具合が発生しておりましたが、本不具合の解消を行ったバージョン1.2.13をリリースいたしました。  
    誠にお手数をおかけいたしますが、自動アップデートなどで最新バージョンになっていない方は、[Google Playストア](https://play.google.com/store/apps/details?id=jp.nuro.mobile)
    新しいウィンドウで開くより最新バージョンへアップデートいただき、ご利用いただきますようお願い申し上げます。アプリ操作ができる方はすでにアップデートが完了しています。  
    お客さまには多大なご迷惑をおかけしたことを深くお詫び申し上げます。
*   2023.11.01 お知らせ 新料金プラン「VLLプラン」、「5分/10分かけ放題プラン」サービス提供開始！  
    [VLLプランの特典の詳細はこちら。](https://mobile.nuro.jp/campaign/voice-sim/)
      
    [5分/10分かけ放題プランの特典詳細はこちら。](https://mobile.nuro.jp/campaign/kakeho-plan/)
    
*   2023.10.05 お知らせ 2023年10月12日 午前3時00分～午前4時00分の間、 キャッシュバックの受取手続きをご利用いただけません。  
    ご迷惑をおかけしますが、ご理解を賜りますよう何卒よろしくお願いいたします。
*   2023.10.02 お知らせ [【NUROモバイル】適格請求書等保存方式（インボイス制度）対応について](https://www.so-net.ne.jp/info/2023/op20231002_0043.html)
    新しいウィンドウで開く
*   2023.09.01 お知らせ [クレジットカード情報更新について](https://www.so-net.ne.jp/info/2023/op20230531_0016.html)
    新しいウィンドウで開く
*   2023.09.01 お知らせ 2023年9月4日 午前7時00分～午前8時00分の間、 キャッシュバックの受取手続きをご利用いただけません。  
    ご迷惑をおかけしますが、ご理解を賜りますよう何卒よろしくお願いいたします。
*   2023.09.01 お知らせ NEOプランのお申し込みで11,000円キャッシュバック特典実施中。 [特典の詳細はこちら](https://mobile.nuro.jp/plan/neoplan/campaign/)
    
*   2023.09.01 お知らせ NEOプランWのお申し込みで15,000円キャッシュバック特典実施中。 [特典の詳細はこちら](https://mobile.nuro.jp/plan/neoplan/campaign/w/)
    
*   2023.09.01 お知らせ 音声通話付きSIMのVSプラン・VMプラン・VLプランをお申し込みで、月額基本料金が6か月間割引。 [特典の詳細はこちら](https://mobile.nuro.jp/campaign/voice-sim/)
    
*   2023.09.01 お知らせ NUROモバイルとセットでXperia 10 IVをご購入いただくと、ご利用開始月を除く8か月目に、10,000円をキャッシュバック。 [特典の詳細はこちら。](https://mobile.nuro.jp/campaign/xperia/)
    
*   2023.08.25 お知らせ [【NUROモバイル】ソフトバンクの3Gサービス終了に伴うお知らせ](https://www.so-net.ne.jp/info/2023/op20230825_0033.html)
    新しいウィンドウで開く
*   2023.08.16 お知らせ 台風の影響により、NUROモバイルの一部の配送に遅延および配達見合わせが発生しております。 詳しい状況や最新情報は、[ヤマトホールディングスのお知らせ](https://www.yamato-hd.co.jp/important/info_230729_1.html)
    新しいウィンドウで開くをご確認ください。
*   2023.08.04 お知らせ Xperia 10 Vのお取り扱いを開始しました。発売と同時にXperia 10 V早期購入キャンペーンを実施しています。[キャンペーンの詳細はこちら](https://mobile.nuro.jp/campaign/xperia10v/)
    。
*   2023.08.04 お知らせ NUROモバイルのいずれかのプランと端末補償の同時お申し込みで、端末補償の月額基本料金が3か月無料。端末補償同時申込特典 実施中。[詳しくはこちら](https://mobile.nuro.jp/campaign/option/hoshou/)
    。
*   2023.08.04 お知らせ 2023年8月10日 午前1時00分～午前5時00分の間、キャッシュバックの受取手続きをご利用いただけません。  
    ご迷惑をおかけしますが、ご理解を賜りますよう何卒よろしくお願いいたします。
*   2023.07.20 更新 8月4日よりXperia 10 Vのお取り扱いを開始します。[詳しくはこちら](https://mobile.nuro.jp/xperia/)
    。
*   2023.07.19 お知らせ 大雨の影響により、NUROモバイルの一部の配送に遅延および配達見合わせが発生しております。 詳しい状況や最新情報は、[ヤマトホールディングスのお知らせ](https://www.yamato-hd.co.jp/important/info_230710_1.html)
    新しいウィンドウで開くをご確認ください。
*   2023.06.28 お知らせ [NUROモバイル、eSIMの提供を開始](https://mobile.nuro.jp/sim/esim/)
    
*   2023.06.05 お知らせ 2023年6月8日 午前1時00分～午前5時00分の間、キャッシュバックの受取手続きをご利用いただけません。  
    ご迷惑をおかけしますが、ご理解を賜りますよう何卒よろしくお願いいたします。
*   2023.06.01 お知らせ VMプラン・VLプランをお申し込みで、月額基本料金が6か月間792円  
    [バリュープラスお申し込み特典実施中。詳しくはこちら](https://mobile.nuro.jp/campaign/voice-sim/)
    
*   2023.06.01 お知らせ NEOプランをお申し込みで、月額基本料金が12か月間1,980円  
    [NEOプランお申し込み特典実施中。 詳しくはこちら](https://mobile.nuro.jp/plan/neoplan/campaign/)
    
*   2023.06.01 お知らせ NEOプランWをお申し込みで、月額基本料金が12か月間2,980円  
    [NEOプランWお申し込み特典実施中。 詳しくはこちら](https://mobile.nuro.jp/plan/neoplan/campaign/w/)
    
*   2023.05.31 お知らせ [クレジットカード情報更新について](https://www.so-net.ne.jp/info/2023/op20230531_0016.html)
    新しいウィンドウで開く
*   2023.05.18 お知らせ [【NUROモバイル】「NEOプランLite（D）」新規申込受付終了のお知らせ](https://www.so-net.ne.jp/info/2023/op20230518_0014.html)
    新しいウィンドウで開く
*   2023.05.17 お知らせ 3月28日より提供開始している「NUROモバイルアプリ」において、データ通信量の消費を抑えることができる新機能「節約スイッチ」の提供を開始しました。[詳しくはこちらをご確認ください](https://mobile.nuro.jp/app/)
    。
*   2023.04.26 お知らせ Xperia 10 IVご購入で5,000円キャッシュバック！[詳しくはこちら](https://mobile.nuro.jp/campaign/xperia/)
    
*   2023.04.20 お知らせ キャッシュバック：ゴールデンウィーク期間のお振り込みについて  
    ゴールデンウィーク期間の振込業務停止に伴い、以下の期間にキャッシュバックのお手続きをされた場合、お振り込みは2023年5月8日以降となります。あらかじめご了承ください。  
    【振込停止期間】2023年5月2日(火)14:30 ～ 2023年5月8日(月)8:50
*   2023.04.20 お知らせ 端末買取サービス：ゴールデンウィーク休業のお知らせ  
    下記期間にて、ゴールデンウィーク休業となりますので、ご案内いたします。  
    【休業期間】2023年4月29日(土) ～ 2023年5月7日(日)  
    なお、お引き取りや代金お支払いなど、詳細については以下よりご確認ください。  
    [デジタルリユース買取サービス　ゴールデンウィーク休業のお知らせ](https://ssl1.kaimasu.biz/sm-kaitori/service/inter_info23GW.html)
    新しいウィンドウで開く
*   2023.04.11 記事更新 [スマホ断ちによるデジタルデトックスのすゝめ。即実践できる方法を紹介](https://mobile.nuro.jp/sumaho-arekore/enjoy/3416/)
    
*   2023.04.11 お知らせ 2023年4月13日 午前1時00分～午前5時00分の間、 キャッシュバックの受取手続きをご利用いただけません。 ご迷惑をおかけしますが、ご理解を賜りますよう何卒よろしくお願いいたします。
*   2023.04.06 記事更新 [動画配信サービス徹底比較！Netflix、Hulu、dTV…オススメは？](https://mobile.nuro.jp/sumaho-arekore/enjoy/6886/)
    
*   2023.03.31 記事更新 [iPhoneの賢い選び方と格安SIMでおトクに使う方法](https://mobile.nuro.jp/sumaho-arekore/transfer/741/)
    
*   2023.03.31 お知らせ [電話リレーサービス料のご負担について](https://www.so-net.ne.jp/info/2021/op20210610_0029.html)
    新しいウィンドウで開く
*   2023.03.28 記事更新 [動作の重さ・遅さが解決！スマホのメンテナンス17選](https://mobile.nuro.jp/sumaho-arekore/tips/943/)
    
*   2023.03.13 記事更新 [NUROモバイルのNEOプラン/バリュープラスの魅力とは？](https://mobile.nuro.jp/sumaho-arekore/transfer/3062/)
    
*   2023.03.08 お知らせ 新料金プラン「NEOプランW」サービス提供開始！  
    20,000円キャッシュバック特典実施中。[詳しくはこちら](https://mobile.nuro.jp/plan/neoplan/campaign/w/)
    
*   2023.03.08 お知らせ NEOプランと同じ高品質な通信をお試しいただける容量チャージ  
    「NEOトライアル」サービス提供開始！[詳しくはこちら](https://mobile.nuro.jp/option/neo-trial/)
    
*   2023.03.01 記事更新 [オススメの就職活動・転職活動関連アプリ20選](https://mobile.nuro.jp/sumaho-arekore/app/3219/)
    
*   2023.02.13 記事更新 [NUROモバイルがおトクな理由！家族に最適なプランは](https://mobile.nuro.jp/sumaho-arekore/transfer/3888/)
    
*   2023.02.01 お知らせ 18,000円キャッシュバック！  
    NEOプランお申し込み特典実施中。[詳しくはこちら](https://mobile.nuro.jp/plan/neoplan/campaign/)
    
*   2023.02.01 お知らせ 月額基本料金が6か月間半額＆キャッシュバック！  
    バリュープラスお申し込み特典実施中。[詳しくはこちら](https://mobile.nuro.jp/campaign/voice-sim/)
    
*   2023.01.30 お知らせ 動作確認済端末ページにGalaxy A53、Galaxy S22シリーズ、他57機種を追加しました。[詳しくはこちら](https://mobile.nuro.jp/support/device/)
    
*   2023.01.26 お知らせ 動作確認済端末ページにAQUOS sense6、Xiaomi POCO F4 GT、他36機種を追加しました。[詳しくはこちら](https://mobile.nuro.jp/support/device/)
    
*   2023.01.26 お知らせ AQUOS sense7のお取り扱いを開始しました。[詳しくはこちら](https://mobile.nuro.jp/product/aquos_sense7/)
    
*   2023.01.25 お知らせ Xperia 10 IVの端末価格を見直しました。[詳しくはこちら](https://mobile.nuro.jp/product/xperia_10_iv/)
    
*   2023.01.19 お知らせ 動作確認済端末ページにAQUOS sense7、Huawei Pシリーズ、他49機種を追加しました。[詳しくはこちら](https://mobile.nuro.jp/support/device/)
    
*   2023.01.18 お知らせ [NUROモバイル　au回線 お留守番サービスのシステム移行に伴うメンテナンスのお知らせ](https://www.so-net.ne.jp/info/2022/op20221122_0067.html)
    新しいウィンドウで開く
*   2023.01.16 お知らせ NEOプラン公式アンバサダーの募集受付を終了しました。
*   2023.01.10 お知らせ NEOプラン公式アンバサダーの募集受付を開始しました。[詳しくはこちら](https://mobile.nuro.jp/ambassador/)
    
*   2023.01.06 お知らせ 動作確認済端末ページにiPhone 14、Google Pixel 7、他115機種を追加しました。[詳しくはこちら](https://mobile.nuro.jp/support/device/)
    
*   2022.12.27 記事更新 [Cookieとは？危険性は？有効にするやり方と削除方法](https://mobile.nuro.jp/sumaho-arekore/knowledge/392/)
    
*   2022.12.21 お知らせ 北日本、日本海側を中心とした大雪の影響により、NUROモバイルの一部の配送に遅延が発生しております。  
    詳しい状況や最新情報は、[こちら](https://www.yamato-hd.co.jp/important/info_221214_1.html)
    新しいウィンドウで開くにてご確認ください。
*   2022.12.19 記事更新 [NUROモバイルが使えるSIMフリー端末を紹介](https://mobile.nuro.jp/sumaho-arekore/transfer/240/)
    
*   2022.11.29 記事更新 [おサイフケータイ(R)が使える格安スマホの選び方](https://mobile.nuro.jp/sumaho-arekore/knowledge/3862/)
    
*   2022.11.17 お知らせ 【キャッシュバックお受け取り手続きについて】  
    現在、一部のお客様を対象に、お受け取りページが正常に遷移しない事象が発生しております。  
    ブラウザの変更やポップアップブロック機能をOFFにしてお試しください。  
    ご迷惑をおかけし、大変申し訳ございません。
*   2022.11.16 お知らせ かけ放題プランがセット割の対象になりました。  
    [NURO 光セット割はこちら](https://www.nuro.jp/hikari/campaign/hikarimobileset/?SmRcid=sny_s_nuromobile_top_2)
    新しいウィンドウで開く  
    [So-net 光セット割はこちら](https://www.so-net.ne.jp/access/hikari/nuromobile/?SmRcid=NMset_ban)
    新しいウィンドウで開く
*   2022.11.08 記事更新 [付帯サービスが充実！いつでもどこでもスマホを楽しめるNEOプラン](https://mobile.nuro.jp/sumaho-arekore/interview/5821/)
    
*   2022.11.01 記事更新 [コスパよし！NEOプランの金額･データ容量･速度のバランスに満足](https://mobile.nuro.jp/sumaho-arekore/interview/5743/)
    
*   2022.10.27 記事更新 [格安スマホで得する人の特徴！5つのポイントとは？](https://mobile.nuro.jp/sumaho-arekore/transfer/3882/)
    
*   2022.10.26 お知らせ [かけ放題プランの対象外となる通話について](https://www.so-net.ne.jp/info/2022/op20221026_0061.html)
    新しいウィンドウで開く
*   2022.10.21 お知らせ 「NEOプラン/NEOプランLiteの参考速度の計測結果」を公開しました。[詳しくはこちら](https://mobile.nuro.jp/plan/neoplan/speed/)
    
*   2022.10.17 記事更新 [スマホの使い方向上！サブ端末がNEOプランでストレスフリー](https://mobile.nuro.jp/sumaho-arekore/interview/5722/)
    
*   2022.10.13 お知らせ 新料金プラン「かけ放題プラン」サービス提供開始！  
    リリース記念特典実施中。[詳しくはこちら](https://mobile.nuro.jp/campaign/kakeho-plan/)
    
*   2022.10.13 更新 端末一覧ページをリニューアルいたしました。[詳しくはこちら](https://mobile.nuro.jp/product/)
    
*   2022.10.07 記事更新 [速度制限とおさらば。NEOプランで外でも音楽やSNSの利用が可能に](https://mobile.nuro.jp/sumaho-arekore/interview/5691/)
    
*   2022.10.04 記事更新 [安くても通信品質は重視したい。サクサク使えるNEOプランで快適な日常に](https://mobile.nuro.jp/sumaho-arekore/interview/5645/)
    
*   2022.09.30 記事更新 [画像付き！Twitterを初心者でも楽しむ方法](https://mobile.nuro.jp/sumaho-arekore/enjoy/5572/)
    
*   2022.09.12 記事更新 [Xperia 10 IVをレビュー！電池持ちと軽さが魅力](https://mobile.nuro.jp/sumaho-arekore/review/5459/)
    
*   2022.09.12 記事更新 [格安スマホとは？長所短所と後悔しない選び方を紹介](https://mobile.nuro.jp/sumaho-arekore/howto/874/)
    
*   2022.09.12 更新 端末一覧ページをリニューアルいたしました。[詳しくはこちら](https://mobile.nuro.jp/product/)
    
*   2022.09.09 お知らせ [NUROモバイル　NEOデータフリーに関するお詫び](https://www.so-net.ne.jp/info/2022/op20220909_0051.html)
    新しいウィンドウで開く
*   2022.08.30 メディア掲載 ITmedia Mobileに取材記事が掲載されました。[詳しくはこちら](https://www.itmedia.co.jp/mobile/articles/2208/30/news067.html)
    新しいウィンドウで開く
*   2022.08.29 更新 公式YouTubeチャンネルにNEOプランのWebCM動画を公開しました。  
    [詳しくはこちら](https://youtu.be/_Urc7OURRQ8)
    新しいウィンドウで開く
*   2022.08.18 記事更新 [一人暮らしの節約術！生活費をやりくりする方法とは](https://mobile.nuro.jp/sumaho-arekore/tips/5164/)
    
*   2022.08.10 記事更新 [時短と節約になる！オススメのスマホ決済アプリ7選](https://mobile.nuro.jp/sumaho-arekore/app/4677/)
    
*   2022.08.10 お知らせ SIM在庫切れにより、ソフトバンク回線にて提供中の「nanoSIM(iPhone専用)」の受付を停止しております。  
    iPhone7以降であれば「nanoSIM」でご利用いただけます。  
    ※ iPhone 6s、iPhone 6s Plusでご利用いただく場合は、SIMロック解除の上「nanoSIM」をご利用ください。  
    ご迷惑をおかけし、大変申し訳ございません。
*   2022.08.02 お知らせ [NUROモバイル au回線の通信障害におけるお詫びと返金について新しいウィンドウで開く](https://www.so-net.ne.jp/info/2022/op20220802_0047.html)
    
*   2022.07.22 更新 Xperia 10 IVのお取り扱いを開始しました。[詳しくはこちら](https://mobile.nuro.jp/xperia/)
    
*   2022.07.21 お知らせ ネットの脅威から守る、スマホセキュリティアプリの決定版  
    「ウイルスバスターモバイル月額版」オプション提供開始！[詳しくはこちら](https://mobile.nuro.jp/option/trend/)
    
*   2022.07.14 更新 OPPO Reno7 Aとmoto e32sのお取り扱いを開始しました。[詳しくはこちら](https://mobile.nuro.jp/product/)
    
*   2022.08.02 お知らせ [NUROモバイル au回線の通信障害におけるお詫びと返金について新しいウィンドウで開く](https://www.so-net.ne.jp/info/2022/op20220802_0047.html)
    
*   2022.07.04 お知らせ [NUROモバイル au回線がご利用しづらい状況について新しいウィンドウで開く](https://www.so-net.ne.jp/emerge/tr/nuro_mobile.html)
    
*   2022.06.30 お知らせ So-net 光 & NUROモバイル セット割実施中。[詳しくはこちら](https://www.so-net.ne.jp/access/hikari/nuromobile/?SmRcid=NMset_ban)
    新しいウィンドウで開く
*   2022.06.30 お知らせ [ソフトバンク回線のオートプレフィックス機能に関する規約改訂のお知らせ  \
    3G通話（3Gエリア/3G端末）のオートプレフィックス機能非適用について](https://www.so-net.ne.jp/info/2022/op20220630_0035.html)
    新しいウィンドウで開く
*   2022.06.09 お知らせ [au回線 オートプレフィックス機能の提供開始に伴う規約改訂について](https://www.so-net.ne.jp/info/2022/op20220609_0029.html)
    新しいウィンドウで開く
*   2022.06.02 特典 ネットとスマホをまとめておトクに！NUROならスマホ代が1年間0円～。  
    NURO 光・NUROモバイルセット割引特典実施中。[詳しくはこちら](https://www.nuro.jp/hikari/campaign/hikarimobileset/?SmRcid=sny_s_nuromobile_top_2)
    新しいウィンドウで開く
*   2022.06.01 記事更新 [画像付き！TikTokの使い方。見るだけから動画投稿方法まで徹底解説](https://mobile.nuro.jp/sumaho-arekore/enjoy/3646/)
    
*   2022.05.31 記事更新 [防水機能付き格安スマホが便利！シチュエーション別の選び方も紹介](https://mobile.nuro.jp/sumaho-arekore/knowledge/800/)
    
*   2022.05.31 記事更新 [決定版！アウトドアやキャンプで使える便利なアプリ17個を厳選](https://mobile.nuro.jp/sumaho-arekore/app/3649/)
    
*   2022.05.26 お知らせ 一部のお客さまにおいて、2022年3月通話分の通話明細が正しく表示されておりませんでした。  
    現在は正しく表示されておりますので、ご確認ください。  
    この度はご迷惑をおかけし大変申し訳ございませんでした。
*   2022.05.25 記事更新 [キャリアメールの移行や持ち運びとは？手順やフリーメールの種類も紹介](https://mobile.nuro.jp/sumaho-arekore/howto/2850/)
    
*   2022.05.12 お知らせ 【モトローラ製品で発生している不具合について】  
    一部モトローラ製品につきまして、デュアル SIM機能利用時に、緊急機関 （110 番、118 番、119 番）への発信ができない場合があることが確認されています。 対象の端末をご購入された方、およびご購入を検討されている方は[こちら](https://store.motorola.co.jp/topics_detail.html?info_id=120)
    新しいウィンドウで開くを ご確認いただき、ご不明点等についてはモトローラカスタマーセンターへお問い合わせください。 ご迷惑をおかけしますが、ご理解を賜りますよう何卒よろしくお願いいたします。
*   2022.05.11 更新 公式YouTubeチャンネルにNEOプラン・NEOプランLiteのWebCM動画を公開しました。  
    [ギガが余っちゃう彼女篇の動画はこちら](https://youtu.be/Wnpe218GMuo)
    新しいウィンドウで開く  
    [ギガが足りない彼氏篇の動画はこちら](https://youtu.be/4EOFU0Ys84I)
    新しいウィンドウで開く
*   2022.05.11 更新 AQUOS wishのお取り扱いを開始しました。[詳しくはこちら](https://mobile.nuro.jp/product/)
    
*   2022.05.11 お知らせ NEOプラン・NEOプランLiteとバリュープラス、お試しプラン間のプラン変更の受付を開始しました。[詳しくはこちら](https://www.so-net.ne.jp/info/2022/op20220511_0022.html)
    新しいウィンドウで開く
*   2022.03.30 お知らせ [電話リレーサービス料のご負担について](https://www.so-net.ne.jp/info/2021/op20210610_0029.html)
    新しいウィンドウで開く
*   2022.03.24 お知らせ [ドコモ回線「危険SMS拒否設定」導入について](https://www.so-net.ne.jp/info/2022/op20220324_0015.html)
    新しいウィンドウで開く

基本的なハウツーから暮らしのアイデアまで

新着記事がありません。

格安SIM関連コラム
----------

[![](https://mobile.nuro.jp/sumaho-arekore/wp-content/uploads/2023/05/202305/6925/top_image.png)](https://mobile.nuro.jp/sumaho-arekore/howto/6925/)

格安SIM講座

格安SIMとは？メリット・デメリットをわかりやすく解説

[![](https://mobile.nuro.jp/sumaho-arekore/wp-content/uploads/2021/03/202103/1003/icatch.png)](https://mobile.nuro.jp/sumaho-arekore/transfer/1003/)

乗換・機種変更

難しくない！格安SIMへの乗り換え方法や手順・注意点

[![](https://mobile.nuro.jp/sumaho-arekore/wp-content/uploads/2024/11/202411/8676/icatch.png)](https://mobile.nuro.jp/sumaho-arekore/howto/8676/)

格安SIM講座

格安SIMは即日開通もできる！最短の手続き方法も解説

このページをシェアする

*   [![facebook](https://mobile.nuro.jp/images/nmui2/icon-facebook.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fmobile.nuro.jp%2F)
    
*   [![Twitter](https://mobile.nuro.jp/images/nmui2/icon-twitter.png)](https://twitter.com/share?text=%E6%A0%BC%E5%AE%89SIM%E3%80%81%E3%82%B9%E3%83%9E%E3%83%9B%E3%81%AA%E3%82%89%E3%81%8A%E3%83%88%E3%82%AF%E3%81%AA%E7%89%B9%E5%85%B8%E3%81%8C%E3%81%A4%E3%81%84%E3%81%A6%E3%81%8F%E3%82%8B%E3%80%8CNURO%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB%E3%80%8D%EF%BC%81&url=https%3A%2F%2Fmobile.nuro.jp%2F)
    
*   [![LINE](https://mobile.nuro.jp/images/nmui2/icon-line.png)](https://social-plugins.line.me/lineit/share?url=https%3A%2F%2Fmobile.nuro.jp%2F)
    

[![ページトップ](https://mobile.nuro.jp/images/nmui2/gotop.png)](https://mobile.nuro.jp/#)

![NURO Mobile](https://mobile.nuro.jp/images/nmui2/logo-nuromobile-white.png)

[トップ](https://mobile.nuro.jp/)

[お知らせ](https://mobile.nuro.jp/news_release/)

[アーカイブ](https://mobile.nuro.jp/archive/)

[障害メンテナンス情報新しいウィンドウで開く](https://www.nuro.jp/emerge/)

[規約一覧](https://mobile.nuro.jp/kiyaku/)

[NUROモバイルアプリ](https://mobile.nuro.jp/app/)

official account

*   [![facebook](https://mobile.nuro.jp/images/nmui2/icon-facebook.png)](https://www.facebook.com/NUROMobilebySony/)
    
*   [![Instagram](https://mobile.nuro.jp/images/nmui2/icon-instagram.png)](https://www.instagram.com/nuromobilebysony/)
    
*   [![(旧：Twitter)](https://mobile.nuro.jp/images/nmui2/icon-x-under.png)](https://twitter.com/nuromobile_jp)
    
*   [![Youtube](https://mobile.nuro.jp/images/nmui2/icon-youtube.png)](https://youtube.com/channel/UC3PO0t22QLwQ4-cm8rvdFEw)
    

[![NURO](https://mobile.nuro.jp/images/nmui2/logo-nuro-white.png)](https://www.sonynetwork.co.jp/corporation/nuro_rebrand2021/)

ソニーネットワークコミュニケーションズ株式会社  
Copr. Sony Network Communications Inc. 登録番号(電気通信事業者): 関第94号

*   [個人情報保護 / 情報セキュリティへの取り組み新しいウィンドウで開く](https://www.sonynetwork.co.jp/corporation/safety/)
    
*   [会社概要新しいウィンドウで開く](https://www.sonynetwork.co.jp/corporation/company/profile/)
    
*   [サイトポリシー](https://mobile.nuro.jp/kiyaku/siteinfo.html)
    

![](https://a-mpd.com/pixel.png?own=44dc1d28abb3b184b3c13a1dcf2cc7f0&agt=dc0d2187ab1165026e2945febd603799&brnd=8d7312aae9df9714096db5371a9a97af&pg=2daba54cb820a940bb838d8f78eb7f7f)     ![](https://googleads.g.doubleclick.net/pagead/viewthroughconversion/981375687/?guid=ON&amp;script=0)![](https://b97.yahoo.co.jp/pagead/conversion/1000255097/?guid=ON&script=0&disvt=false)![](https://googleads.g.doubleclick.net/pagead/viewthroughconversion/843763034/?guid=ON&amp;script=0)![](https://www.googleadservices.com/pagead/conversion/843763034/?label=FCdICI_7wnMQ2pqrkgM&amp;guid=ON&amp;script=0)![](https://googleads.g.doubleclick.net/pagead/viewthroughconversion/941735114/?guid=ON&amp;script=0)![](https://b97.yahoo.co.jp/pagead/conversion/1000255095/?guid=ON&script=0&disvt=false)![](https://www.facebook.com/tr?id=1581914835441962&ev=PageView&noscript=1)![](https://b97.yahoo.co.jp/pagead/conversion/1000977195/?guid=ON&script=0&disvt=false)    ![](https://api.botchan.chat/api/analytic/wc/pageview?cpid=666260145bab41507472c81b&uid=&curl=https%3A%2F%2Fmobile.nuro.jp%2F&ref=&title=%E3%80%90%E5%85%AC%E5%BC%8F%E3%80%91%E6%A0%BC%E5%AE%89SIM%E3%83%BB%E6%A0%BC%E5%AE%89%E3%82%B9%E3%83%9E%E3%83%9B%E3%81%AENURO%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB&user_agent=Mozilla%2F5.0%20(Linux%3B%20Android%2010%3B%20K)%20AppleWebKit%2F537.36%20(KHTML%2C%20like%20Gecko)%20Chrome%2F141.0.0.0%20Mobile%20Safari%2F537.36&t=1764896683002)

![](https://bat.bing.com/action/0?ti=97129554&Ver=2&mid=e5032cdf-8847-4fa6-acef-de26ea88c246&bo=1&sid=625b7f30d17611f0a833b16fa2e1f462&vid=625b8a40d17611f09cff697239445928&vids=1&msclkid=N&pi=0&lg=en-US@posix&sw=1280&sh=800&sc=24&nwd=1&tl=%E3%80%90%E5%85%AC%E5%BC%8F%E3%80%91%E6%A0%BC%E5%AE%89SIM%E3%83%BB%E6%A0%BC%E5%AE%89%E3%82%B9%E3%83%9E%E3%83%9B%E3%81%AENURO%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB&kw=%E6%A0%BC%E5%AE%89SIM,%E6%A0%BC%E5%AE%89%E3%82%B9%E3%83%9E%E3%83%9B,NURO%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB&p=https%3A%2F%2Fmobile.nuro.jp%2F&r=&lt=1627&evt=pageLoad&sv=2&cdb=AQAQ&rn=341252)

![](https://t.co/i/adsct?bci=5&dv=UTC%26en-US%40posix%26Google%20Inc.%26Linux%20x86_64%26127%261280%26800%268%2624%261280%26800%260%26na&eci=2&event_id=d88ffeee-7b28-4bfd-b152-8abab244e0d6&events=%5B%5B%22pageview%22%2C%7B%7D%5D%5D&integration=advertiser&p_id=Twitter&p_user_id=0&pl_id=b1e96043-e916-47b3-bb4e-9817ec559a99&pt=%E3%80%90%E5%85%AC%E5%BC%8F%E3%80%91%E6%A0%BC%E5%AE%89SIM%E3%83%BB%E6%A0%BC%E5%AE%89%E3%82%B9%E3%83%9E%E3%83%9B%E3%81%AENURO%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB&tw_document_href=https%3A%2F%2Fmobile.nuro.jp%2F&tw_iframe_status=0&tw_order_quantity=0&tw_sale_amount=0&txn_id=o2n66&type=javascript&version=2.3.35)![](https://analytics.twitter.com/i/adsct?bci=5&dv=UTC%26en-US%40posix%26Google%20Inc.%26Linux%20x86_64%26127%261280%26800%268%2624%261280%26800%260%26na&eci=2&event_id=d88ffeee-7b28-4bfd-b152-8abab244e0d6&events=%5B%5B%22pageview%22%2C%7B%7D%5D%5D&integration=advertiser&p_id=Twitter&p_user_id=0&pl_id=b1e96043-e916-47b3-bb4e-9817ec559a99&pt=%E3%80%90%E5%85%AC%E5%BC%8F%E3%80%91%E6%A0%BC%E5%AE%89SIM%E3%83%BB%E6%A0%BC%E5%AE%89%E3%82%B9%E3%83%9E%E3%83%9B%E3%81%AENURO%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB&tw_document_href=https%3A%2F%2Fmobile.nuro.jp%2F&tw_iframe_status=0&tw_order_quantity=0&tw_sale_amount=0&txn_id=o2n66&type=javascript&version=2.3.35)![](https://t.co/i/adsct?bci=5&dv=UTC%26en-US%40posix%26Google%20Inc.%26Linux%20x86_64%26127%261280%26800%268%2624%261280%26800%260%26na&eci=2&event_id=4d7a1210-469e-4d95-9980-a63eb7aa9ef4&events=%5B%5B%22pageview%22%2C%7B%7D%5D%5D&integration=advertiser&p_id=Twitter&p_user_id=0&pl_id=b1e96043-e916-47b3-bb4e-9817ec559a99&pt=%E3%80%90%E5%85%AC%E5%BC%8F%E3%80%91%E6%A0%BC%E5%AE%89SIM%E3%83%BB%E6%A0%BC%E5%AE%89%E3%82%B9%E3%83%9E%E3%83%9B%E3%81%AENURO%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB&tw_document_href=https%3A%2F%2Fmobile.nuro.jp%2F&tw_iframe_status=0&tw_order_quantity=0&tw_sale_amount=0&txn_id=o474l&type=javascript&version=2.3.35)![](https://analytics.twitter.com/i/adsct?bci=5&dv=UTC%26en-US%40posix%26Google%20Inc.%26Linux%20x86_64%26127%261280%26800%268%2624%261280%26800%260%26na&eci=2&event_id=4d7a1210-469e-4d95-9980-a63eb7aa9ef4&events=%5B%5B%22pageview%22%2C%7B%7D%5D%5D&integration=advertiser&p_id=Twitter&p_user_id=0&pl_id=b1e96043-e916-47b3-bb4e-9817ec559a99&pt=%E3%80%90%E5%85%AC%E5%BC%8F%E3%80%91%E6%A0%BC%E5%AE%89SIM%E3%83%BB%E6%A0%BC%E5%AE%89%E3%82%B9%E3%83%9E%E3%83%9B%E3%81%AENURO%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB&tw_document_href=https%3A%2F%2Fmobile.nuro.jp%2F&tw_iframe_status=0&tw_order_quantity=0&tw_sale_amount=0&txn_id=o474l&type=javascript&version=2.3.35)![](https://t.co/1/i/adsct?bci=5&dv=UTC%26en-US%40posix%26Google%20Inc.%26Linux%20x86_64%26127%261280%26800%268%2624%261280%26800%260%26na&eci=3&event=%7B%7D&event_id=24a17830-e5e6-4f08-9051-67ae5a87a3af&integration=advertiser&p_id=Twitter&p_user_id=0&pl_id=b1e96043-e916-47b3-bb4e-9817ec559a99&pt=%E3%80%90%E5%85%AC%E5%BC%8F%E3%80%91%E6%A0%BC%E5%AE%89SIM%E3%83%BB%E6%A0%BC%E5%AE%89%E3%82%B9%E3%83%9E%E3%83%9B%E3%81%AENURO%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB&tw_document_href=https%3A%2F%2Fmobile.nuro.jp%2F&tw_iframe_status=0&txn_id=olnwk&type=javascript&version=2.3.35)![](https://analytics.twitter.com/1/i/adsct?bci=5&dv=UTC%26en-US%40posix%26Google%20Inc.%26Linux%20x86_64%26127%261280%26800%268%2624%261280%26800%260%26na&eci=3&event=%7B%7D&event_id=24a17830-e5e6-4f08-9051-67ae5a87a3af&integration=advertiser&p_id=Twitter&p_user_id=0&pl_id=b1e96043-e916-47b3-bb4e-9817ec559a99&pt=%E3%80%90%E5%85%AC%E5%BC%8F%E3%80%91%E6%A0%BC%E5%AE%89SIM%E3%83%BB%E6%A0%BC%E5%AE%89%E3%82%B9%E3%83%9E%E3%83%9B%E3%81%AENURO%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB&tw_document_href=https%3A%2F%2Fmobile.nuro.jp%2F&tw_iframe_status=0&txn_id=olnwk&type=javascript&version=2.3.35)![](https://t.co/i/adsct?bci=5&dv=UTC%26en-US%40posix%26Google%20Inc.%26Linux%20x86_64%26127%261280%26800%268%2624%261280%26800%260%26na&eci=2&event_id=f0cd5bf9-c32b-40b0-a976-cc1468a18679&events=%5B%5B%22pageview%22%2C%7B%7D%5D%5D&integration=advertiser&p_id=Twitter&p_user_id=0&pl_id=b1e96043-e916-47b3-bb4e-9817ec559a99&pt=%E3%80%90%E5%85%AC%E5%BC%8F%E3%80%91%E6%A0%BC%E5%AE%89SIM%E3%83%BB%E6%A0%BC%E5%AE%89%E3%82%B9%E3%83%9E%E3%83%9B%E3%81%AENURO%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB&tw_document_href=https%3A%2F%2Fmobile.nuro.jp%2F&tw_iframe_status=0&tw_order_quantity=0&tw_sale_amount=0&txn_id=o2pfc&type=javascript&version=2.3.35)![](https://analytics.twitter.com/i/adsct?bci=5&dv=UTC%26en-US%40posix%26Google%20Inc.%26Linux%20x86_64%26127%261280%26800%268%2624%261280%26800%260%26na&eci=2&event_id=f0cd5bf9-c32b-40b0-a976-cc1468a18679&events=%5B%5B%22pageview%22%2C%7B%7D%5D%5D&integration=advertiser&p_id=Twitter&p_user_id=0&pl_id=b1e96043-e916-47b3-bb4e-9817ec559a99&pt=%E3%80%90%E5%85%AC%E5%BC%8F%E3%80%91%E6%A0%BC%E5%AE%89SIM%E3%83%BB%E6%A0%BC%E5%AE%89%E3%82%B9%E3%83%9E%E3%83%9B%E3%81%AENURO%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB&tw_document_href=https%3A%2F%2Fmobile.nuro.jp%2F&tw_iframe_status=0&tw_order_quantity=0&tw_sale_amount=0&txn_id=o2pfc&type=javascript&version=2.3.35)![](https://t.co/i/adsct?bci=5&dv=UTC%26en-US%40posix%26Google%20Inc.%26Linux%20x86_64%26127%261280%26800%268%2624%261280%26800%260%26na&eci=2&event_id=35aa52d5-6721-4911-9ec2-31a859d7145d&events=%5B%5B%22pageview%22%2C%7B%7D%5D%5D&integration=advertiser&p_id=Twitter&p_user_id=0&pl_id=b1e96043-e916-47b3-bb4e-9817ec559a99&pt=%E3%80%90%E5%85%AC%E5%BC%8F%E3%80%91%E6%A0%BC%E5%AE%89SIM%E3%83%BB%E6%A0%BC%E5%AE%89%E3%82%B9%E3%83%9E%E3%83%9B%E3%81%AENURO%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB&tw_document_href=https%3A%2F%2Fmobile.nuro.jp%2F&tw_iframe_status=0&tw_order_quantity=0&tw_sale_amount=0&txn_id=o4q08&type=javascript&version=2.3.35)![](https://analytics.twitter.com/i/adsct?bci=5&dv=UTC%26en-US%40posix%26Google%20Inc.%26Linux%20x86_64%26127%261280%26800%268%2624%261280%26800%260%26na&eci=2&event_id=35aa52d5-6721-4911-9ec2-31a859d7145d&events=%5B%5B%22pageview%22%2C%7B%7D%5D%5D&integration=advertiser&p_id=Twitter&p_user_id=0&pl_id=b1e96043-e916-47b3-bb4e-9817ec559a99&pt=%E3%80%90%E5%85%AC%E5%BC%8F%E3%80%91%E6%A0%BC%E5%AE%89SIM%E3%83%BB%E6%A0%BC%E5%AE%89%E3%82%B9%E3%83%9E%E3%83%9B%E3%81%AENURO%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB&tw_document_href=https%3A%2F%2Fmobile.nuro.jp%2F&tw_iframe_status=0&tw_order_quantity=0&tw_sale_amount=0&txn_id=o4q08&type=javascript&version=2.3.35)    ![](https://t.co/i/adsct?bci=5&dv=UTC%26en-US%40posix%26Google%20Inc.%26Linux%20x86_64%26127%261280%26800%268%2624%261280%26800%260%26na&eci=1&event_id=a8d0e87c-beb2-4e9f-901c-5be709486653&integration=advertiser&p_id=Twitter&p_user_id=0&pl_id=b1e96043-e916-47b3-bb4e-9817ec559a99&pt=%E3%80%90%E5%85%AC%E5%BC%8F%E3%80%91%E6%A0%BC%E5%AE%89SIM%E3%83%BB%E6%A0%BC%E5%AE%89%E3%82%B9%E3%83%9E%E3%83%9B%E3%81%AENURO%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB&tw_document_href=https%3A%2F%2Fmobile.nuro.jp%2F&tw_iframe_status=0&tw_order_quantity=0&tw_sale_amount=0&txn_id=o4si0&type=javascript&version=2.3.35)![](https://analytics.twitter.com/i/adsct?bci=5&dv=UTC%26en-US%40posix%26Google%20Inc.%26Linux%20x86_64%26127%261280%26800%268%2624%261280%26800%260%26na&eci=1&event_id=a8d0e87c-beb2-4e9f-901c-5be709486653&integration=advertiser&p_id=Twitter&p_user_id=0&pl_id=b1e96043-e916-47b3-bb4e-9817ec559a99&pt=%E3%80%90%E5%85%AC%E5%BC%8F%E3%80%91%E6%A0%BC%E5%AE%89SIM%E3%83%BB%E6%A0%BC%E5%AE%89%E3%82%B9%E3%83%9E%E3%83%9B%E3%81%AENURO%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB&tw_document_href=https%3A%2F%2Fmobile.nuro.jp%2F&tw_iframe_status=0&tw_order_quantity=0&tw_sale_amount=0&txn_id=o4si0&type=javascript&version=2.3.35)

[![](https://img.ada-cloud.com/pattern/j4WwrCJNdOUxmRDPv1LpwIhymYB6p3DrClq9m65S.gif)](https://lin.ee/7RtURM5T)

        

![](https://img.ada-cloud.com/pattern/P7qB6TytLfqcOq27gJMTgGhEfjBtH4Vf3W1qSyJL.gif)

× LINE友だち限定で配信中🎁

![](https://t.co/1/i/adsct?bci=5&dv=UTC%26en-US%40posix%26Google%20Inc.%26Linux%20x86_64%26127%261280%26800%268%2624%261280%26800%260%26na&eci=3&event=%7B%7D&event_id=0b3ff0fb-4406-4fa8-bb0e-f408ac3c4642&integration=advertiser&p_id=Twitter&p_user_id=0&pl_id=b1e96043-e916-47b3-bb4e-9817ec559a99&pt=%E3%80%90%E5%85%AC%E5%BC%8F%E3%80%91%E6%A0%BC%E5%AE%89SIM%E3%83%BB%E6%A0%BC%E5%AE%89%E3%82%B9%E3%83%9E%E3%83%9B%E3%81%AENURO%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB&tw_document_href=https%3A%2F%2Fmobile.nuro.jp%2F&tw_iframe_status=0&txn_id=o6c6r&type=javascript&version=2.3.35)![](https://analytics.twitter.com/1/i/adsct?bci=5&dv=UTC%26en-US%40posix%26Google%20Inc.%26Linux%20x86_64%26127%261280%26800%268%2624%261280%26800%260%26na&eci=3&event=%7B%7D&event_id=0b3ff0fb-4406-4fa8-bb0e-f408ac3c4642&integration=advertiser&p_id=Twitter&p_user_id=0&pl_id=b1e96043-e916-47b3-bb4e-9817ec559a99&pt=%E3%80%90%E5%85%AC%E5%BC%8F%E3%80%91%E6%A0%BC%E5%AE%89SIM%E3%83%BB%E6%A0%BC%E5%AE%89%E3%82%B9%E3%83%9E%E3%83%9B%E3%81%AENURO%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB&tw_document_href=https%3A%2F%2Fmobile.nuro.jp%2F&tw_iframe_status=0&txn_id=o6c6r&type=javascript&version=2.3.35)         ![](https://t.co/1/i/adsct?bci=5&dv=UTC%26en-US%40posix%26Google%20Inc.%26Linux%20x86_64%26127%261280%26800%268%2624%261280%26800%260%26na&eci=3&event=%7B%7D&event_id=4f89b770-2f69-4b3f-b892-66602527f240&integration=advertiser&p_id=Twitter&p_user_id=0&pl_id=b1e96043-e916-47b3-bb4e-9817ec559a99&pt=%E3%80%90%E5%85%AC%E5%BC%8F%E3%80%91%E6%A0%BC%E5%AE%89SIM%E3%83%BB%E6%A0%BC%E5%AE%89%E3%82%B9%E3%83%9E%E3%83%9B%E3%81%AENURO%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB&tw_document_href=https%3A%2F%2Fmobile.nuro.jp%2F&tw_iframe_status=0&txn_id=odviq&type=javascript&version=2.3.35)![](https://analytics.twitter.com/1/i/adsct?bci=5&dv=UTC%26en-US%40posix%26Google%20Inc.%26Linux%20x86_64%26127%261280%26800%268%2624%261280%26800%260%26na&eci=3&event=%7B%7D&event_id=4f89b770-2f69-4b3f-b892-66602527f240&integration=advertiser&p_id=Twitter&p_user_id=0&pl_id=b1e96043-e916-47b3-bb4e-9817ec559a99&pt=%E3%80%90%E5%85%AC%E5%BC%8F%E3%80%91%E6%A0%BC%E5%AE%89SIM%E3%83%BB%E6%A0%BC%E5%AE%89%E3%82%B9%E3%83%9E%E3%83%9B%E3%81%AENURO%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB&tw_document_href=https%3A%2F%2Fmobile.nuro.jp%2F&tw_iframe_status=0&txn_id=odviq&type=javascript&version=2.3.35)
