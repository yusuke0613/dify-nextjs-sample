# マイそく｜料金表｜格安スマホ・格安SIM【mineo(マイネオ)】

URL: https://mineo.jp/price/mysoku/

---

[![格安SIM・格安スマホのmineo](https://mineo.jp/asset/img/common/template/logo_mineo_white.png)](https://mineo.jp/)

*   [法人のお客さま](https://mineo.jp/r/biz/link_header.html)
    
*   [お知らせ](https://mineo.jp/#info)
    
*   [キャンペーン](https://mineo.jp/campaign/)
    
*   [特集](https://mineo.jp/special/)
    
*        ![検索](https://mineo.jp/asset/img/common/icon_search.png)
    

*   [![](https://mineo.jp/asset/img/common/template/icon_menu_feature.png)\
    \
    mineoの  \
    特長](https://mineo.jp/price/mysoku/#header-menu-feature)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_service.png)\
    \
    料金・  \
    サービス](https://mineo.jp/price/mysoku/#header-menu-service)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_device.png)\
    \
    端末](https://mineo.jp/price/mysoku/#header-menu-device)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_shop.png)\
    \
    店舗](https://mineo.jp/price/mysoku/#header-menu-shop)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_guide.png)\
    \
    申込ガイド](https://mineo.jp/price/mysoku/#header-menu-guide)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_support.png)\
    \
    サポート](https://mineo.jp/price/mysoku/#header-menu-support)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_king.png)\
    \
    コミュニティ](https://mineo.jp/price/mysoku/#header-menu-king)
    

*   [![](https://mineo.jp/asset/img/common/template/icon_mypage.png)\
    \
    マイページ](https://my.mineo.jp/)
    
*    [![](https://mineo.jp/asset/img/common/template/icon_apply_wh.png) ![](https://mineo.jp/asset/img/common/template/icon_apply_pink.png)\
    \
    お申し込み](https://mineo.jp/apply/)
    

メニュー

[![格安SIM・格安スマホのmineo](https://mineo.jp/asset/img/common/template/logo_mineo.png)](https://mineo.jp/)

*   [![](https://mineo.jp/asset/img/common/template/icon_menu_feature.png)\
    \
    mineoの  \
    特長](https://mineo.jp/price/mysoku/#header-menu-feature)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_service.png)\
    \
    料金・  \
    サービス](https://mineo.jp/price/mysoku/#header-menu-service)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_device.png)\
    \
    端末](https://mineo.jp/price/mysoku/#header-menu-device)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_shop.png)\
    \
    店舗](https://mineo.jp/price/mysoku/#header-menu-shop)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_guide.png)\
    \
    申込ガイド](https://mineo.jp/price/mysoku/#header-menu-guide)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_support.png)\
    \
    サポート](https://mineo.jp/price/mysoku/#header-menu-support)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_king.png)\
    \
    コミュニティ](https://mineo.jp/price/mysoku/#header-menu-king)
    

*   [![](https://mineo.jp/asset/img/common/template/icon_mypage.png)\
    \
    マイページ](https://my.mineo.jp/)
    
*    [![](https://mineo.jp/asset/img/common/template/icon_apply_wh.png) ![](https://mineo.jp/asset/img/common/template/icon_apply_pink.png)\
    \
    お申し込み](https://mineo.jp/apply/)
    

![](https://mineo.jp/asset/img/common/template/header_mark.png)

閉じる

     ![検索](https://mineo.jp/asset/img/common/icon_search.png)

*   [![](https://mineo.jp/asset/img/common/template/icon_mypage.png)\
    \
    マイページ](https://my.mineo.jp/)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_apply_wh.png)\
    \
    お申し込み](https://mineo.jp/apply/)
    

![](https://mineo.jp/asset/img/common/template/icon_menu_feature.png)

mineoの特長

[はじめての方へ](https://mineo.jp/beginner/)
 [mineoが選ばれる理由](https://mineo.jp/reason/)
 [Fun with Fans！](https://mineo.jp/brand/)

![](https://mineo.jp/asset/img/common/template/icon_menu_service.png)

料金・サービス

[料金表](https://mineo.jp/price/)
 [サービス・オプション一覧](https://mineo.jp/service/)
 [かんたん料金シミュレーション](https://mineo.jp/simulator/)

[![](https://mineo.jp/asset/img/common/template/icon_menu_campaign.png)\
\
キャンペーン](https://mineo.jp/campaign/)

![](https://mineo.jp/asset/img/common/template/icon_menu_device.png)

端末

[mineoで使う端末を選ぶ](https://mineo.jp/device/about/)
 [iPhone](https://mineo.jp/device/iphone/)
 [スマートフォン](https://mineo.jp/device/smartphone/)
 [タブレット・ルーター](https://mineo.jp/device/other/)
 [動作確認済み端末検索](https://mineo.jp/device/devicelist/)

![](https://mineo.jp/asset/img/common/template/icon_menu_shop.png)

店舗

[店舗を探す](https://mineo.jp/shop/)
 [店舗でできること](https://mineo.jp/shop/about/)
 [店舗でSIMを受け取る](https://mineo.jp/shop/online/counter/)

![](https://mineo.jp/asset/img/common/template/icon_menu_guide.png)

申込ガイド

[お手持ちの端末をそのまま使う方](https://mineo.jp/apply/simonly-flow/)
 [mineoで端末も一緒に買いたい方](https://mineo.jp/apply/device-flow/)
 [初期設定～ご利用開始の流れ](https://mineo.jp/apply/setup-flow/)
 [お申し込み](https://mineo.jp/apply/)

![](https://mineo.jp/asset/img/common/template/icon_menu_support.png)

サポート

[ユーザーサポートTOP](https://support.mineo.jp/)
 [初期設定・各種設定](https://support.mineo.jp/setup/guide/)
 [よくあるご質問](https://support.mineo.jp/usqa/)
 [AIチャットサポート](https://mineo.jp/r/mai_chat/)
 [お問い合わせ](https://support.mineo.jp/inquiry.html)

[![](https://mineo.jp/asset/img/common/template/icon_menu_king.png)\
\
コミュニティ](https://king.mineo.jp/)
[![](https://mineo.jp/asset/img/common/template/icon_menu_news.png)\
\
お知らせ](https://support.mineo.jp/news_list/)
[![](https://mineo.jp/asset/img/common/template/icon_menu_special.png)\
\
特集](https://mineo.jp/special/)
[![](https://mineo.jp/asset/img/common/template/icon_menu_column.png)\
\
お役立ちコラム](https://mineo.jp/column/)
[![](https://mineo.jp/asset/img/common/template/icon_menu_business.png)\
\
法人のお客さま](https://mineo.jp/r/biz/link_header.html)

[![](https://mineo.jp/asset/img/common/template/logo_mineo.svg)](https://mineo.jp/)

![](https://mineo.jp/asset/img/common/template/icon_menu_feature.png)

mineoの特長

[](https://mineo.jp/price/mysoku/#)

*   mineo（マイネオ）や格安スマホサービスがはじめての方へ
    
      [![](https://mineo.jp/asset/img/common/template/icon_feature_beginner.png?v20230614) ![](https://mineo.jp/asset/img/common/template/icon_feature_beginner.png?v20230614) はじめての方へ](https://mineo.jp/beginner/)
    
*   格安スマホサービスの中でも選ばれるのには理由があります！
    
      [![](https://mineo.jp/asset/img/common/template/icon_feature_reason.png?v20230614) ![](https://mineo.jp/asset/img/common/template/icon_feature_reason.png?v20230614) mineoが選ばれる理由](https://mineo.jp/reason/)
    
*    [![ブランドステートメント Fun with Fans!](https://mineo.jp/asset/img/common/template/feature-banner.png?v20190731) ![ブランドステートメント Fun with Fans!](https://mineo.jp/asset/img/common/template/sp/feature-banner.png?v20190731)](https://mineo.jp/brand/)
    

*   [![お役立ちコラム](https://mineo.jp/_mg/_uploads/files/4fce8fccb3fa0a96_mineo_Gnavi_bnr_B.jpg)](https://mineo.jp/column/)
    

![](https://mineo.jp/asset/img/common/template/icon_menu_service.png)

料金・サービス

[](https://mineo.jp/price/mysoku/#)

*     [![](https://mineo.jp/asset/img/common/template/icon_service_price.png) ![](https://mineo.jp/asset/img/common/template/icon_service_price.png) 料金表](https://mineo.jp/price/)
    
*    [![](https://mineo.jp/asset/img/common/template/icon_service_option.png) サービス・オプション一覧](https://mineo.jp/service/)
    
*     [![](https://mineo.jp/asset/img/common/template/icon_service_simulator.png?v20210401) ![](https://mineo.jp/asset/img/common/template/icon_service_simulator.png?v20210401) かんたん料金シミュレーション](https://mineo.jp/simulator/)
    

*   [![おトクなキャンペーン情報](https://mineo.jp/_mg/_uploads/files/3897e85cae780a5f_maipyon_banner.jpg)](https://mineo.jp/campaign/)
    
*   [![法人のお客さまはこちら](https://mineo.jp/_mg/_uploads/files/13c4fc24b5f50ae4_business.jpg)](https://mineo.jp/r/biz/link_drop/)
    

![](https://mineo.jp/asset/img/common/template/icon_menu_device.png)

端末

[](https://mineo.jp/price/mysoku/#)

*   持ち込みも買い替えも自由に選べる！
    
      [![](https://mineo.jp/asset/img/common/template/icon_device_about.png) ![](https://mineo.jp/asset/img/common/template/icon_device_about.png) mineoで使う  \
    端末を選ぶ](https://mineo.jp/device/about/)
    
*   mineoで端末を買う
    
     [![](https://mineo.jp/asset/img/common/template/icon_device_iphone.png) iPhone](https://mineo.jp/device/iphone/)
    [![](https://mineo.jp/asset/img/common/template/icon_device_smartphone.png) スマートフォン](https://mineo.jp/device/smartphone/)
    [![](https://mineo.jp/asset/img/common/template/icon_device_other.png) タブレット・ルーター](https://mineo.jp/device/other/)
    
*   お手持ちの端末を使う
    
      [![](https://mineo.jp/asset/img/common/template/icon_device_devicelist.png) ![](https://mineo.jp/asset/img/common/template/icon_device_devicelist.png) 動作確認済み  \
    端末検索](https://mineo.jp/device/devicelist/)
    

*   [![mineoスマホコーティング](https://mineo.jp/_mg/_uploads/files/ebd51d24a7bb0a3f_mineo_Gnavi_bnr_smartphone_coating_A.jpg)](https://mineo.jp/service/discount/coating/)
    

![](https://mineo.jp/asset/img/common/template/icon_menu_shop.png)

店舗

[](https://mineo.jp/price/mysoku/#)

Webでの新規申し込みが不安な方は、お気軽にご来店ください。

*     [![](https://mineo.jp/asset/img/common/template/icon_shop_search.png) ![](https://mineo.jp/asset/img/common/template/icon_shop_search.png) 店舗を探す](https://mineo.jp/shop/)
    
*     [![](https://mineo.jp/asset/img/common/template/icon_shop_about.png) ![](https://mineo.jp/asset/img/common/template/icon_shop_about.png) 店舗でできること](https://mineo.jp/shop/about/)
    
*     [![](https://mineo.jp/asset/img/common/template/icon_shop_online.png) ![](https://mineo.jp/asset/img/common/template/icon_shop_online.png) 店舗でSIMを受け取る](https://mineo.jp/shop/online/counter/)
    

![](https://mineo.jp/asset/img/common/template/icon_menu_guide.png)

申込ガイド

[](https://mineo.jp/price/mysoku/#)

*   準備からお申し込みの流れ
    
     [![](https://mineo.jp/asset/img/common/template/icon_apply_simonly.png) お手持ちの端末を  \
    そのまま使う方](https://mineo.jp/apply/simonly-flow/)
    [![](https://mineo.jp/asset/img/common/template/icon_apply_device.png) mineoで端末も  \
    一緒に買いたい方](https://mineo.jp/apply/device-flow/)
    
*   SIMカードや端末が届いたら
    
      [![](https://mineo.jp/asset/img/common/template/icon_apply_flow.png?v20211000) ![](https://mineo.jp/asset/img/common/template/icon_apply_flow.png?v20211000) 初期設定～  \
    ご利用開始の流れ](https://mineo.jp/apply/setup-flow/)
    
*   お申し込みページでご契約
    
      [![](https://mineo.jp/asset/img/common/template/icon_apply_entry.png) ![](https://mineo.jp/asset/img/common/template/icon_apply_entry.png) お申し込み](https://mineo.jp/apply/)
    

![](https://mineo.jp/asset/img/common/template/icon_menu_support.png)

サポート

[](https://mineo.jp/price/mysoku/#)

*   mineoユーザーサポート
    
      [![](https://mineo.jp/asset/img/common/template/icon_support_top.png?v20210401) ![](https://mineo.jp/asset/img/common/template/icon_support_top.png?v20210401) ユーザーサポートTOP](https://support.mineo.jp/)
    
*   設定でわからないことを調べる
    
     [![](https://mineo.jp/asset/img/common/template/icon_support_setup.png) 初期設定・各種設定](https://support.mineo.jp/setup/guide/)
    [![](https://mineo.jp/asset/img/common/template/icon_support_faq.png) よくあるご質問](https://support.mineo.jp/usqa/)
    
*   わからないこと、不安なことがあればお問い合わせを
    
     [![](https://mineo.jp/asset/img/common/template/icon_support_chat.png) AIチャットサポート](https://mineo.jp/r/mai_chat/)
    [![](https://mineo.jp/asset/img/common/template/icon_support_inquiry.png) お問い合わせ](https://support.mineo.jp/inquiry.html)
    

![](https://mineo.jp/asset/img/common/template/icon_menu_king.png)

コミュニティ

[](https://mineo.jp/price/mysoku/#)

*   マイネ王は、全国のmineoユーザーやmineoスタッフたちが交流しているコミュニティサイトです。
    
    [![](https://mineo.jp/asset/img/common/template/icon_king_guide.png)](https://king.mineo.jp/beginner_guide.html)
    
     [![](https://mineo.jp/asset/img/common/template/icon_king_top.png) コミュニティサイト  \
    マイネ王](https://king.mineo.jp/)
    
*   おすすめコンテンツ
    
    mineoのサービスや端末のレビュー [![](https://mineo.jp/asset/img/common/template/icon_king_review.png) レビュー](https://king.mineo.jp/reviews/)
    
    みんなの疑問と回答 [![](https://mineo.jp/asset/img/common/template/icon_king_faq.png) Q&A](https://king.mineo.jp/question-answer/)
    
*     
    
    mineoに対するみんなの提案 [![](https://mineo.jp/asset/img/common/template/icon_king_idea.png) アイデアファーム](https://king.mineo.jp/ideas/)
    
    パケットをシェアして助け合い [![](https://mineo.jp/asset/img/common/template/icon_king_freetank.png) フリータンク](https://king.mineo.jp/freetank/)
    

マイネ王は、全国のmineoユーザーや  
mineoスタッフたちが交流している  
コミュニティサイトです。 [![](https://mineo.jp/asset/img/common/template/icon_king_top.png) コミュニティサイト  \
マイネ王](https://king.mineo.jp/)

[![](https://mineo.jp/asset/img/common/template/icon_king_guide.png)](https://king.mineo.jp/beginner_guide.html)

おすすめコンテンツ

*   mineoのサービスや端末の  
    レビュー [![](https://mineo.jp/asset/img/common/template/icon_king_review.png) レビュー](https://king.mineo.jp/reviews/)
    
*   みんなの疑問と回答  
      
     [![](https://mineo.jp/asset/img/common/template/icon_king_faq.png) Q&A](https://king.mineo.jp/question-answer/)
    

*   mineoに対するみんなの提案 [![](https://mineo.jp/asset/img/common/template/icon_king_idea.png) アイデア  \
    ファーム](https://king.mineo.jp/ideas/)
    
*   パケットをシェアして助け合い [![](https://mineo.jp/asset/img/common/template/icon_king_freetank.png) フリータンク](https://king.mineo.jp/freetank/)
    

マイそく
====

 ![最大通信速度で選ぶデータ無制限※プラン マイそく](https://mineo.jp/asset/img/price/mysoku/sp/mv.jpg?v20250604)

*   ※ 月曜～金曜の12時台は最大32kbps（プレミアムのみ最大200kbps）になります。  
    また混雑回避のための速度制限（3日間で10GB以上利用時）および通信最適化が適用されます。

マイそくって？
-------

月曜～金曜の12～13時の  
通信速度が制限される代わりに、  
おトクにデータが使い放題になる  
料金プランです。

### こんな人におすすめ！

*   ![](https://mineo.jp/asset/img/price/mysoku/about_case_pic_01.png)
    
    お昼に自宅のWi-Fiを  
    利用できる方
    
*   ![](https://mineo.jp/asset/img/price/mysoku/about_case_pic_02.png)
    
    お昼にスマホを使わない方
    
*   ![](https://mineo.jp/asset/img/price/mysoku/about_case_pic_03.png)
    
    無線Wi-Fiルーターとして  
    使用し、自宅の通信回線の  
    コストを抑えたい方
    
*   ![](https://mineo.jp/asset/img/price/mysoku/about_case_pic_04.png)
    
    電話のみの利用の方
    

### 自分に合った通信速度を選べる。  
だから「マイそく！」

コスパ抜群！  
スマホをよりおトクに使いたい方に

スタンダード

最大1.5Mbps

990円

（税抜900円）

データ無制限+音声通話付き

1.5Mbpsでも、ほとんどのスマホで  
問題なくご利用いただけます

1.5Mbpsってどれくらい使える？

*   Webサイトの  
    閲覧
    
    ![利用できた97%](https://mineo.jp/asset/img/price/mysoku/about_speed_card_graph_pic_97.png)
*   音楽ストリーミング  
    の利用
    
    ![利用できた97%](https://mineo.jp/asset/img/price/mysoku/about_speed_card_graph_pic_97.png)
*   YouTubeなどの  
    動画視聴
    
    ![利用できた92%](https://mineo.jp/asset/img/price/mysoku/about_speed_card_graph_pic_92.png)
*   問題なく利用できた
    
    やや遅さを感じたが  
    利用できた
    
    利用に支障があった・  
    利用できなかった
    

*   ○ mineoユーザーアンケートより n=1,869

もっと快適に  
ネットや動画を楽しみたい方に

プレミアム

最大5Mbps

2,200円

（税抜2,000円）

データ無制限+音声通話付き

マイそく スタンダードの  
3倍以上の速度で使い放題

アプリの更新やOSアップデートなども快適！  
ネットや動画をたくさん楽しみたい方に  
おすすめです。

![](https://mineo.jp/asset/img/price/mysoku/about_speed_card_pic_03.png)

電話やメッセージのやり取り中心で  
ほとんどデータ通信しない方に

ライト

最大300kbps

660円

（税抜600円）

データ無制限+音声通話付き

ライトな使い方をされる方向け  
とことんおトクなコース

メッセージのやり取りやネットラジオなど  
通信速度が求められない使い方にピッタリ。  
また、10分かけ放題と合わせて  
1,210円/月～ご利用いただけます。

![](https://mineo.jp/asset/img/price/mysoku/about_speed_card_pic_04.png)

[10分かけ放題について詳しく見る](https://mineo.jp/service/voice/kakehoudai/)

音声通話専用や  
障害時の  
バックアップ回線として  
備えておきたい方に

スーパーライト

最大32kbps

250円

（税抜228円）

音声通話のみ

必要なときに必要な分だけ  
使いたい人向け

音声通話専用回線としてだけではなく、  
旅行や通信障害時の一時的な回線として  
使いたい方にもピッタリ。  
10分かけ放題と合わせて800円/月～、  
無制限かけ放題と合わせても1460円/月～。  
データ利用したいときはオプションの  
24時間データ使い放題（198円/回）  
を追加することでご利用いただけます。

[10分かけ放題について詳しく見る](https://mineo.jp/service/voice/kakehoudai/)
 [24時間データ使い放題  \
について詳しく見る](https://mineo.jp/price/mysoku/#unlimited)

ご注意事項

*   ・月曜～金曜（祝日含む）の12～13時の通信速度は、プレミアム以外は最大32kbps、プレミアムは最大200Kbpsになります。
*   ・32kbpsではメールやメッセージなどテキスト情報のやり取りはできますが、それ以外の用途（Webサイト閲覧 QR決済など）ではほとんどご利用いただけません。
*   ・おサイフケータイやApple PayなどFeliCa決済は32kbpsでもご利用いただけます。
*   ・090/080などから始まる音声通話は速度制限の対象外のため制限時間帯も普段通りご利用いただけます。
*   ・混雑回避のための速度制限（3日間で10GB以上利用時）および通信最適化が適用されます。  
    詳しくは[ご注意事項](https://mineo.jp/price/mysoku/#attention)
    をご覧ください。
*   ・混雑時間帯はマイピタ契約者の通信が優先される場合があります。

### それぞれの通信速度で  
何ができる？

|     | 32kbps<br><br>・スーパーライト  <br>・プレミアム以外の月～金曜  <br>　お昼の速度制限(※1) | 200kbps<br><br>・プレミアムの月～金曜お昼  <br>　の速度制限(※1) | 300kbps<br><br>・ライトの標準速度 | 1.5Mbps<br><br>・スタンダードの標準速度 | 5Mbps<br><br>・プレミアムの標準速度 |
| --- | --- | --- | --- | --- | --- |
| メール/メッセージ | ○   | ◎   | ◎   | ◎   | ◎   |
| LINE通話など  <br>のIP電話 | ×   | ◎   | ◎   | ◎   | ◎   |
| QR決済  <br>/バーコード決済 | ×   | ◎   | ◎   | ◎   | ◎   |
| 音楽ストリーミング | ×   | △   | ○   | ◎   | ◎   |
| テキストサイト  <br>/SNS | ×   | △   | ○   | ◎   | ◎   |
| 画像サイト  <br>/SNS  <br>(Instagram) | ×   | ×   | △   | ○   | ◎   |
| 動画視聴  <br>（低画質 144p） | ×   | △   | △   | ◎   | ◎   |
| 動画視聴  <br>（標準画質 360p） | ×   | ×   | ×   | ◎   | ◎   |
| 動画視聴  <br>（高画質 720p） | ×   | ×   | ×   | ×   | ◎   |
| ビデオ会議 | ×   | ×   | ×   | △   | ◎   |
| FeliCa決済※2  <br>（おサイフケータイや  <br>Apple Payなど） | ◎   | ◎   | ◎   | ◎   | ◎   |
| 音声通話※3  <br>（090/080などから  <br>始まる通話） | ◎   | ◎   | ◎   | ◎   | ◎   |

*   ※1 月曜～金曜（祝日含む）の12～13時の通信速度は、プレミアム以外は最大32kbps、プレミアムは最大200Kbpsになります。
*   ※2 データ通信がほとんど発生しないため、どの速度でも利用可能です。
*   ※3 音声通話のための通信に対して速度制限は適用されません。
*   ○ あくまでも利用の目安であり、通信環境やご利用サービスによって利用できない場合があります。

### 3日間で10GBって  
どれくらい通信できる？

10GBでできること

*   Webサイト閲覧
    
    ![](https://mineo.jp/asset/img/price/mysoku/about_icon_02.png)
    
    約30,000ページ
    
*   音楽  
    ストリーミング
    
    ![](https://mineo.jp/asset/img/price/mysoku/about_icon_03.png)
    
    約115時間
    
*   動画再生  
    （標準画質）
    
    ![](https://mineo.jp/asset/img/price/mysoku/about_icon_04.png)
    
    約20時間
    
*   データ通信
    
    ![](https://mineo.jp/asset/img/price/mysoku/about_icon_01.png)
    
    約15時間  
    （1.5Mbpsで連続利用）
    

*   ○ コンテンツを単独利用した場合のご利用目安です。ご利用状況やコンテンツの内容により、消費データ量は変動します。

*   #### 新規の方はこちら
    
    [mineoに新規お申し込み](https://mineo.jp/apply/)
    
*   #### ご利用中のmineo回線を変更
    
    [コース変更お申し込み](https://my.mineo.jp/)
    

マイそく専用オプション　  
24時間データ使い放題　
---------------------------

マイそくご契約中も速度制限を気にせず使いたい方に！24時間制限なくご利用いただけます。

*   ○ 速度制限中の月曜～金曜の12～13時や3日間10GB超過時も速度制限なくご利用いただけます。
*   ○ 24時間データ使い放題でのデータご利用分は3日間10GB制限のカウント対象外となります。
*   ○ 通信速度はベストエフォートとなり、使い放題利用中も通信最適化が適用されます。

|     |     |
| --- | --- |
| 料金  | 198円 |

![](https://mineo.jp/asset/img/price/mysoku/option_advice_pic_01.png)

突然、高速でのデータ通信が必要になったら？  
お昼もネットにつながないといけなくなったら？

![](https://mineo.jp/asset/img/price/mysoku/option_advice_pic_02.png)

24時間データ使い放題を使えば、mineoの通常速度にいつでも切り替えられます。24時間データ使い放題の利用中は、通信速度制限のあるお昼もmineoの通常速度でデータ通信ができます。

*   ○ お申し込み後数分でサービスが適用されます。
*   ○ 速度制限中はWebサイトからのお申し込みができませんのでmineoアプリまたはWi-Fiに接続してお申し込みください。

*   #### マイそくをご利用中の方
    
    [24時間データ使い放題に  \
    お申し込み](https://my.mineo.jp/)
    

24時間データ使い放題の  
便利な使い方
---------------------

速度制限中およびマイそく スーパーライトご利用時はアプリからのお申し込みが便利です。  
スムーズにお申し込みいただくために事前に課金ロック解除の設定をお願いします。

*   ○ 速度制限中およびマイそく スーパーライトご利用時は、eoIDのログインに時間がかかります。課金ロック解除を設定いただくとeoIDのログインなしでお申し込みいただけますので、通信制限のない時間帯に事前の解除をお願いします。
*   ○ 初回のみ。一度設定いただきますと以降の設定は不要です。

STEP.1

### アプリをダウンロードする

*   ![mineoアプリ](https://mineo.jp/asset/img/price/mysoku/app_icon.png)
*   *   [![Google Playで手に入れよう](https://mineo.jp/asset/img/price/mysoku/btn_google_play.png)](https://mineo.jp/r/app/mineoapp/googleplay.html)
        
    *   [![App Storeからダウンロード](https://mineo.jp/asset/img/price/mysoku/btn_app_store.png)](https://mineo.jp/r/app/mineoapp/appstore.html)
        

![↓](https://mineo.jp/asset/img/common/step_arrow_b.png)

STEP.2

### 課金ロックを解除する

![](https://mineo.jp/asset/img/price/mysoku/step_pic_01.png)

① アプリホーム画面左上の〔アイコン〕をタップ

![](https://mineo.jp/asset/img/price/mysoku/step_pic_02.png)

② 〔課金ロック〕をタップ

![](https://mineo.jp/asset/img/price/mysoku/step_pic_03.png)

③ 〔解除する〕をタップ

![↓](https://mineo.jp/asset/img/common/step_arrow_b.png)

STEP.3

### サービスを申し込む

![](https://mineo.jp/asset/img/price/mysoku/step_pic_04.png)

① アプリホーム画面の24時間データ使い放題〔今すぐ利用する（198円/回）〕をタップ

![](https://mineo.jp/asset/img/price/mysoku/step_pic_05.png)

② 〔今すぐ利用する〕をタップ

ご注意事項

*   マイそく
*   ・従来のデータ容量で選ぶマイピタとマイそくは月に一度コース変更することができます。
*   ・マイピタおよびマイそくの他コースからマイそく スーパーライトへコース変更することはできません。
*   ・マイピタの使い放題サービス（パケット放題/パケット放題 Plus）との併用はできません。すでにオプション加入いただいている場合はマイそくプラン変更の前月28日に使い放題サービスは強制解約となります。
*   ・直近3日間で10GB以上のご利用があった場合、通信速度を最大32kbpsに制限する場合がございます。  
    （24時間使い放題ご利用時の通信量はカウント対象外です）
*   ・マイそくご契約時はゆずるね。サービスをご利用いただけません。
*   ・マイそく スーパーライトはお申し込み時にエントリーコード等の契約事務手数料の割引はご利用できません。
*   ・マイそく スーパーライトは家族割引、複数回線割引、eo×mineoセット割の対象外です。
*   ・広告フリーは、マイそくではご利用できません。
*   ・夜間フリーは、マイそく（スーパーライト、ライト）ではご利用できません。

*   24時間データ使い放題
*   ・マイそくコースをご契約者のみご利用いただけるサービスとなります。マイピタコースご契約の方はご利用いただけません。
*   ・手続き完了後、上記ご利用番号の回線が24時間データ使い放題（速度制限解除）となります。
*   ・手続き完了後のキャンセルはできませんので、あらかじめご了承ください。
*   ・適用開始まで数分程度かかる場合があります。
*   ・通信速度はベストエフォートとなります。
*   ・使い放題利用中も通信最適化が適用されます。
*   ・マイそくからマイピタへのコース変更の場合、月末日の前日23時以降は24時間データ使い放題をご利用いただけません。
*   ・マイピタからマイそくへのコース変更の場合、変更後月初1日は24時間データ使い放題をご利用いただけません。

 ![もうひとつの料金プラン『マイピタ』もチェック](https://mineo.jp/asset/img/price/mysoku/sp/mypita_title.png)

 [![毎月必要なデータ容量で選ぶ マイピタ](https://mineo.jp/asset/img/price/mysoku/sp/mypita_bnr.png)](https://mineo.jp/price/mypita/)

[料金をシミュレーションする](https://mineo.jp/simulator/)

*   [mineoホーム](https://mineo.jp/)
    
*   [料金表](https://mineo.jp/price/)
    
*   マイそく

*   [![facebook](https://mineo.jp/asset/img/common/template/icon_sns_fb.png)](https://www.facebook.com/mineo.jp)
    
*   [![LINE](https://mineo.jp/asset/img/common/template/icon_sns_ln.png)](https://line.me/R/ti/p/%40pdp9012a)
    
*   [![X](https://mineo.jp/asset/img/common/template/icon_sns_x.png)](https://twitter.com/mineojp)
    
*   [![YouTube](https://mineo.jp/asset/img/common/template/icon_sns_yt.png)](https://www.youtube.com/user/mineoofficial)
    
*   [![Instagram](https://mineo.jp/asset/img/common/template/icon_sns_ig.png)](https://www.instagram.com/mineo_jp/)
    

[![格安SIM・格安スマホのmineo](https://mineo.jp/asset/img/common/template/logo_mineo.png)](https://mineo.jp/)

*   mineoの特長
    
    *   [はじめての方へ](https://mineo.jp/beginner/)
        
    *   [mineoが選ばれる理由](https://mineo.jp/reason/)
        
    *   [ブランドステートメント](https://mineo.jp/brand/)
        
    
    料金・サービス
    
    *   [料金表](https://mineo.jp/price/)
        
    *   [サービス・オプション一覧](https://mineo.jp/service/)
        
    *   [かんたん料金シミュレーション](https://mineo.jp/simulator/)
        
    
*   端末
    
    *   [mineoで使う端末を選ぶ](https://mineo.jp/device/about/)
        
    *   mineoで端末を買う
    *   [iPhone](https://mineo.jp/device/iphone/)
        
    *   [スマートフォン](https://mineo.jp/device/smartphone/)
        
    *   [タブレット・ルーター](https://mineo.jp/device/other/)
        
    *   お手持ちの端末を使う
    *   [動作確認済み端末検索](https://mineo.jp/device/devicelist/)
        
    
    店舗
    
    *   [店舗を探す](https://mineo.jp/shop/)
        
    *   [店舗でできること](https://mineo.jp/shop/about/)
        
    *   [店舗でSIMを受け取る](https://mineo.jp/shop/online/counter/)
        
    
*   申込ガイド
    
    *   準備からお申し込みの流れ
    *   [お手持ちの端末をそのまま使う方](https://mineo.jp/apply/simonly-flow/)
        
    *   [mineoで端末も一緒に買いたい方](https://mineo.jp/apply/device-flow/)
        
    *   SIMカードや端末が届いたら
    *   [初期設定～ご利用開始の流れ](https://mineo.jp/apply/setup-flow/)
        
    
    サポート
    
    *   [ユーザーサポート](https://support.mineo.jp/)
        
    *   [初期設定・各種設定](https://support.mineo.jp/setup/guide/)
        
    *   [よくあるご質問](https://support.mineo.jp/usqa/)
        
    *   [AIチャットサポート](https://mineo.jp/r/mai_chat/)
        
    *   [お問い合わせ](https://support.mineo.jp/inquiry.html)
        
    
*   コミュニティ
    
    *   [マイネ王サイト](https://king.mineo.jp/)
        
    *   [マイネ王はじめてガイド](https://king.mineo.jp/beginner_guide.html)
        
    *   おすすめコンテンツ
    *   [レビュー](https://king.mineo.jp/reviews/)
        
    *   [Q&A](https://king.mineo.jp/question-answer/)
        
    *   [アイデアファーム](https://king.mineo.jp/ideas/)
        
    *   [フリータンク](https://king.mineo.jp/freetank/)
        
    

*   *   [![](https://mineo.jp/asset/img/common/template/icon_mypage.png)マイページ](https://my.mineo.jp/)
        
    *     [![](https://mineo.jp/asset/img/common/template/icon_apply_wh.png) ![](https://mineo.jp/asset/img/common/template/icon_apply_pink.png)お申し込み](https://mineo.jp/apply/)
        
*   *   [法人のお客さま](https://mineo.jp/r/biz/link_footer.html)
        
    *   [お知らせ](https://mineo.jp/#info)
        
    *   [キャンペーン](https://mineo.jp/campaign/)
        
    *   [特集](https://mineo.jp/special/)
        

     ![検索](https://mineo.jp/asset/img/common/icon_search.png)

記載の価格は税抜記載のものを除き税込です。税込価格は2021年4月1日現在の税率（10%）に基づく金額です。税率に応じて金額は変更されます。

[![株式会社オプテージ](https://mineo.jp/asset/img/common/template/logo_optage.png)](https://optage.co.jp/)

*   [第三者認証](https://optage.co.jp/company/authorization/safesecurityisp.html)
    
*   [情報セキュリティポリシー](https://optage.co.jp/info/security.html)
    
*   [プライバシーポリシー](https://optage.co.jp/info/privacy/)
    
*   [Cookie等の外部送信について](https://optage.co.jp/info/informative.html)
    
*   [サイトのご利用にあたって](https://mineo.jp/site/terms/)
    
*   [特定商取引法に基づく表示](https://mineo.jp/site/law/)
    
*   [ユニバーサルサービス料について](https://optage.co.jp/info/universal.html)
    
*   [電話リレーサービス料について](https://optage.co.jp/info/telephonerelay.html)
    
*   [企業情報](https://optage.co.jp/company/)
    
*   [古物営業法に基づく表示](https://optage.co.jp/company/authorization/)
    

© OPTAGE Inc.
