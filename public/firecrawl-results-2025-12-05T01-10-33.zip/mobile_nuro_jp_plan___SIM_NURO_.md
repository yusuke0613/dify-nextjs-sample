# 料金プラン｜格安SIM・スマホのNUROモバイル

URL: https://mobile.nuro.jp/plan/

---

![SONY](https://mobile.nuro.jp/images/nmui2/logo-sony-white.png)

[![【公式】格安SIM・格安スマホのNUROモバイル](https://mobile.nuro.jp/images/nmui2/logo-nuromobile-black.png)](https://mobile.nuro.jp/)

======================================================================================================================

[お申し込み](https://www.nuro.jp/app/nuromobile-directolsu/entry/new/)

[![マイページ](https://mobile.nuro.jp/images/nmui2/mypage.png)マイページ](https://mobile.nuro.jp/user/userMenu/)

*   [![facebook](https://mobile.nuro.jp/images/nmui2/icon-facebook.png)](https://www.facebook.com/NUROMobilebySony/)
    
*   [![Instagram](https://mobile.nuro.jp/images/nmui2/icon-instagram.png)](https://www.instagram.com/nuromobilebysony/)
    
*   [![Twitter](https://mobile.nuro.jp/images/nmui2/icon-twitter.png)](https://twitter.com/nuromobile_jp)
    
*   [![Youtube](https://mobile.nuro.jp/images/nmui2/icon-youtube.png)](https://youtube.com/channel/UC3PO0t22QLwQ4-cm8rvdFEw)
    

*   [NUROモバイルについて](https://mobile.nuro.jp/about/)
    
*   [お申し込みの流れ](https://mobile.nuro.jp/guide/sim.html)
    
*   [料金・プラン](https://mobile.nuro.jp/plan/)
    
*   [オプション・サービス](https://mobile.nuro.jp/option/)
    
*   [特典・キャンペーン](https://mobile.nuro.jp/campaign/)
    
*   [端末](https://mobile.nuro.jp/product/)
    
*   [FAQs新しいウィンドウで開く](https://support.sonynetwork.co.jp/faqsupport/nuromobile/web/index.html)
    
*   [スマホのアレコレ](https://mobile.nuro.jp/sumaho-arekore/)
    

*   [料金・プランについて](https://mobile.nuro.jp/plan/)
    
*   [NEOプラン](https://mobile.nuro.jp/plan/neoplan/)
    
*   [バリュープラス](https://mobile.nuro.jp/plan/valueplus/)
    
*   [かけ放題ジャスト](https://mobile.nuro.jp/plan/kakeho/)
    

*   [端末一覧](https://mobile.nuro.jp/product/)
    
*   [端末在庫情報 新しいウィンドウで開く](https://mobile.nuro.jp/deviceStockInformation/)
    
*   [Xperia 10 V特設ページ](https://mobile.nuro.jp/xperia/)
    
*   [SIMカード動作確認済端末一覧](https://mobile.nuro.jp/support/device/)
     
*   [eSIM動作確認済端末一覧](https://mobile.nuro.jp/support/device-esim/)
     

![閉じる](https://mobile.nuro.jp/images/nmui2/index/menu-close.svg)

[NUROモバイルについて](https://mobile.nuro.jp/about/)

[お申し込みの流れ](https://mobile.nuro.jp/guide/sim.html)

料金・プラン
------

*   [料金・プランについて](https://mobile.nuro.jp/plan/)
    
*   [NEOプラン](https://mobile.nuro.jp/plan/neoplan/)
    
*   [バリュープラス](https://mobile.nuro.jp/plan/valueplus/)
    
*   [かけ放題ジャスト](https://mobile.nuro.jp/plan/kakeho/)
    

[オプション・サービス](https://mobile.nuro.jp/option/)

[特典・キャンペーン](https://mobile.nuro.jp/campaign/)

端末
--

*   [端末一覧](https://mobile.nuro.jp/product/)
    
*   [端末在庫情報 新しいウィンドウで開く](https://mobile.nuro.jp/deviceStockInformation/)
    
*   [Xperia 10 V特設ページ](https://mobile.nuro.jp/xperia/)
    
*   [SIMカード動作確認済端末一覧](https://mobile.nuro.jp/support/device/)
    
*   [eSIM動作確認済端末一覧](https://mobile.nuro.jp/support/device-esim/)
    

[FAQs 新しいウィンドウで開く](https://support.sonynetwork.co.jp/faqsupport/nuromobile/web/index.html)

[スマホのアレコレ](https://mobile.nuro.jp/sumaho-arekore/)

[お申し込み](https://www.nuro.jp/app/nuromobile-directolsu/entry/new/)

[![マイページ](https://mobile.nuro.jp/images/nmui2/mypage.png)マイページ](https://mobile.nuro.jp/user/userMenu/)

料金プラン
=====

[月額基本料金一覧はこちら](https://mobile.nuro.jp/plan/#anchor-02)

*   特に注記のない限り、記載の金額は全て税込金額です。

SIMタイプ
------

### 音声通話付き SIM

ネットはもちろん、  
通話とSMSも使いたいという方向け。

![音声通話付き SIM](https://mobile.nuro.jp/images/nmui2/plan/img1.png)

### データ通信＋SMS SIM

通話はしないけど、  
ネットとSMSは必要という方向け。

![データ通信＋SMS SIM](https://mobile.nuro.jp/images/nmui2/plan/img2.png)

### データ通信専用 SIM

ネットしか使わない、電話番号は不要の方向け。

![データ通信専用 SIM](https://mobile.nuro.jp/images/nmui2/plan/img3.png)

月額料金一覧
------

NUROモバイルならご利用開始月は月額基本料金が0円！

*   [音声通話付きSIM](https://mobile.nuro.jp/plan/#tp4)
    
*   [データ+SMS  \
    （ドコモ・au回線のみ）](https://mobile.nuro.jp/plan/#tp5)
    
*   [データ専用](https://mobile.nuro.jp/plan/#tp6)
    

    
| プラン名  <br>データ容量 | 月額基本料金 | データ  <br>フリー | あげ放題 | Giga  <br>プラス |
| --- | --- | --- | --- | --- |
| #高品質　NEOプラン　[\>>特長](https://mobile.nuro.jp/plan/#neo001) |     |     |     |     |
| NEO  <br>プラン  <br>~20GB~→35GB | 2,699円 | [NEO  <br>データフリー](https://mobile.nuro.jp/option/neo-datafree/) | [〇](https://mobile.nuro.jp/option/age-hodai/) | [15GB](https://mobile.nuro.jp/option/giga-plus/) |
| NEO  <br>プランW  <br>~40GB~→55GB | 3,980円 | [NEO  <br>データフリー](https://mobile.nuro.jp/option/neo-datafree/) | [〇](https://mobile.nuro.jp/option/age-hodai/) | [15GB](https://mobile.nuro.jp/option/giga-plus/) |
| #コスパ◎　バリュープラス　[\>>特長](https://mobile.nuro.jp/plan/#vp001) |     |     |     |     |
| VSプラン  <br>3GB | 792円 | \-  | \-  | \-  |
| VM  <br>プラン  <br>5GB | 990円 | [バリュー  <br>データフリー](https://mobile.nuro.jp/option/value-datafree/) | \-  | [3GB](https://mobile.nuro.jp/option/giga-plus/) |
| VL  <br>プラン  <br>10GB | 1,485円 | [バリュー  <br>データフリー](https://mobile.nuro.jp/option/value-datafree/) | \-  | [6GB](https://mobile.nuro.jp/option/giga-plus/) |
| VLL  <br>プラン  <br>15GB | 1,790円 | [バリュー  <br>データフリー](https://mobile.nuro.jp/option/value-datafree/) | \-  | [9GB](https://mobile.nuro.jp/option/giga-plus/) |
| #通話定額つき　かけ放題ジャスト※1　[\>>特長](https://mobile.nuro.jp/plan/#kakeho001) |     |     |     |     |
| 5分  <br>かけ放題プラン  <br>1GB | 930円 | [バリュー  <br>データフリー](https://mobile.nuro.jp/option/value-datafree/) | \-  | \-  |
| 10分  <br>かけ放題プラン  <br>1GB | 1,320円 | [バリュー  <br>データフリー](https://mobile.nuro.jp/option/value-datafree/) | \-  | \-  |
| かけ放題プラン  <br>1GB | 1,870円 | \-  | \-  | \-  |

*   ※1 かけ放題ジャストはドコモ回線・au回線のみのご提供です。また、ご利用開始月の請求額は記載の金額と異なります。詳細は[NUROモバイルご利用にあたっての注意事項](https://mobile.nuro.jp/plan/#attention)
    をご確認ください。

   
| プラン名  <br>データ容量 | 月額基本料金 | データ  <br>フリー | Giga  <br>プラス |
| --- | --- | --- | --- |
| #コスパ◎　バリュープラス　[\>>特長](https://mobile.nuro.jp/plan/#vp001) |     |     |     |     |
| VSプラン  <br>3GB | 792円 | \-  | \-  |
| VM  <br>プラン  <br>5GB | 990円 | [バリュー  <br>データ  <br>フリー](https://mobile.nuro.jp/option/value-datafree/) | [3GB](https://mobile.nuro.jp/option/giga-plus/) |
| VLプラン  <br>10GB | 1,485円 | [バリュー  <br>データ  <br>フリー](https://mobile.nuro.jp/option/value-datafree/) | [6GB](https://mobile.nuro.jp/option/giga-plus/) |
| VLL  <br>プラン  <br>15GB | 1,790円 | [バリュー  <br>データ  <br>フリー](https://mobile.nuro.jp/option/value-datafree/) | [9GB](https://mobile.nuro.jp/option/giga-plus/) |
| お試し  <br>プラン  <br>0.2GB | 495円 | \-  | \-  |

　

   
| プラン名  <br>データ容量 | 月額基本料金 | データ  <br>フリー | Giga  <br>プラス |
| --- | --- | --- | --- |
| #コスパ◎　バリュープラス　[\>>特長](https://mobile.nuro.jp/plan/#vp001) |     |     |     |     |
| VSプラン  <br>3GB | 627円 | \-  | \-  |
| VM  <br>プラン  <br>5GB | 825円 | [バリュー  <br>データ  <br>フリー](https://mobile.nuro.jp/option/value-datafree/) | [3GB](https://mobile.nuro.jp/option/giga-plus/) |
| VLプラン  <br>10GB | 1,320円 | [バリュー  <br>データ  <br>フリー](https://mobile.nuro.jp/option/value-datafree/) | [6GB](https://mobile.nuro.jp/option/giga-plus/) |
| VLL  <br>プラン  <br>15GB | 1,625円 | [バリュー  <br>データ  <br>フリー](https://mobile.nuro.jp/option/value-datafree/) | [9GB](https://mobile.nuro.jp/option/giga-plus/) |
| お試し  <br>プラン  <br>0.2GB | 330円 | \-  | \-  |

その他費用
-----

    
|     | SIMカード |     | eSIM |     |
| --- | --- | --- | --- | --- |
| 初期費用 | 登録事務手数料 | 3,300円 |     |     |
| SIMカード準備料 | 440円 | eSIM発行手数料 | 440円 |
| 音声通話・SMS利用 | 音声通話料 | NUROモバイルでんわの通話料 ※2 11円/30秒  <br>上記以外の通話料　22円/30秒 |     |     |
| SMS送信料 | 3円～/通 |     |     |
| 国際SMS送信料 | ドコモ：50円～/通  <br>au・ソフトバンク：100円～/通 （不課税） | 国際SMS送信料 | ドコモ：50円～/通 （不課税） |
| その他手数料 | SIM切替手数料 ※3 | 3,300円 | eSIM種別切替発行手数料 ※4 | 440円 |
| SIM有償交換手数料 | 3,300円 | eSIM再発行手数料 | 440円 |
| SIM損害金 | 3,300円 | eSIM損害金 | なし  |
| MNP転出手数料 | 0円  |     |     |

*   ※2　[NUROモバイルでんわの詳細はこちら](https://mobile.nuro.jp/option/denwa/)
    。
*   ※3　eSIMからSIMカードへ変更する場合も含みます。
*   ※4　eSIMの利用端末を変更する場合にかかる手数料です。SIMカードからeSIMへ変更する場合も含みます。

いつでもササっと申し込み

[お申し込みはこちら](https://www.nuro.jp/app/nuromobile-directolsu/entry/new/)

[お申し込みから  \
ご利用開始まではこちら](https://mobile.nuro.jp/guide/)

あなたにぴったりのプランが  
見つかるかも

[オプション一覧](https://mobile.nuro.jp/option/)

[端末情報](https://mobile.nuro.jp/product/)

[![NEOプラン](https://mobile.nuro.jp/plan/images/neoplan.png)\
\
### この速さ、ストレスフリー※5  \
無料オプションで想像以上のデータ量\
\
#### ![NEOデータフリー](https://mobile.nuro.jp/plan/images/neo-ti001.png)\
\
対象SNSの  \
データ通信量カウントなし\
\
![NEOデータフリー](https://mobile.nuro.jp/plan/neoplan/images/common/img17.png)\
\
#### ![NEOデータフリー](https://mobile.nuro.jp/plan/images/neo-ti002.png)\
\
アップロードの  \
データ通信量カウントなし\
\
![あげ放題](https://mobile.nuro.jp/plan/images/neo-02.png)\
\
#### ![NEOデータフリー](https://mobile.nuro.jp/plan/images/neo-ti003.png)\
\
3か月毎に  \
データ容量プレゼント\
\
![Gigaプラス](https://mobile.nuro.jp/plan/images/neo-03.png)](https://mobile.nuro.jp/plan/neoplan/)

※5　NEOプラン専用の帯域をご利用いただけます。速度品質を保証するものではありません。

[![バリュープラス](https://mobile.nuro.jp/plan/images/vp.png)\
\
### 一人でもおトク！なっトクプラン  \
なるべくおトクに使いたい方に！\
\
#### ![NEOデータフリー](https://mobile.nuro.jp/plan/images/vp-ti001.png)\
\
バリューデータフリーで  \
LINEのトークがし放題！※6\
\
![バリューデータフリー](https://mobile.nuro.jp/images/nmui2/index/img20.png)\
\
#### ![NEOデータフリー](https://mobile.nuro.jp/plan/images/vp-ti002.png)\
\
3日間の通信制限なしで  \
快適な使い心地！\
\
![通信制限なし](https://mobile.nuro.jp/images/nmui2/plan/valueplus/nattoku_other_01.png)\
\
#### ![NEOデータフリー](https://mobile.nuro.jp/plan/images/vp-ti003.png)\
\
縛りなし! 解約金0円\
\
![解約金0円](https://mobile.nuro.jp/images/nmui2/index/img11.png)](https://mobile.nuro.jp/plan/valueplus/)

※6　VSプランは対象外です。お客様のご利用環境によっては一部対象外になる通信があります。[詳細はこちらをご確認ください](https://mobile.nuro.jp/option/value-datafree/)
。

[![かけ放題ジャスト](https://mobile.nuro.jp/plan/images/kakeho.png)\
\
### 通話メインの回線なら  \
LINEもカウントフリーで使える！\
\
#### ![3つのプラン](https://mobile.nuro.jp/plan/images/kakeho-ti01.png)\
\
ライフスタイルに合わせて  \
3つのプランから選べる！\
\
![3種のかけほ](https://mobile.nuro.jp/plan/images/kakeho-01.png)\
\
#### ![回数無制限](https://mobile.nuro.jp/plan/images/kakeho-ti02.png)\
\
一定時間の国内通話が  \
回数無制限\
\
![かけ放題](https://mobile.nuro.jp/plan/images/kakeho-02.png)\
\
#### ![バリューデータフリー](https://mobile.nuro.jp/plan/images/kakeho-ti03.png)\
\
LINEのトークがし放題！※7\
\
![バリューデータフリー](https://mobile.nuro.jp/plan/images/kakeho-03.png)](https://mobile.nuro.jp/plan/kakeho/)

※7　かけ放題プランは対象外です。お客様のご利用環境によっては一部対象外になる通信があります。[詳細はこちらをご確認ください](https://mobile.nuro.jp/option/value-datafree/)
。

いつでもササっと申し込み

[お申し込みはこちら](https://www.nuro.jp/app/nuromobile-directolsu/entry/new/)

[お申し込みから  \
ご利用開始まではこちら](https://mobile.nuro.jp/guide/)

あなたにぴったりのプランが  
見つかるかも

[オプション一覧](https://mobile.nuro.jp/option/)

[端末情報](https://mobile.nuro.jp/product/)

オプション
-----

便利なオプション・サービスを多数ご用意しています。もっと使いやすく、おトクにカスタマイズしませんか。

### オススメ 通話定額オプション（5分/10分/かけ放題）

月額 490円/880円/1,430円

5分または10分、かけ放題から選べる通話定額オプション！時間内であれば何度でも通話することができます。超過後は、11円/30秒でご利用いただけます。

![かけ放題オプション](https://mobile.nuro.jp/images/nmui2/plan/img5.png)

[詳しくはこちら](https://mobile.nuro.jp/option/denwa/kakeho.html)

### 端末補償

月額550円

自然故障・破損・水濡れ等、万が一のトラブルも安心。端末を買いなおすより安い金額で交換でき、最短翌日にはお手元に交換機が届きます。

![端末補償](https://mobile.nuro.jp/images/nmui2/plan/img11.png)

[詳しくはこちら](https://mobile.nuro.jp/option/hoshou/)

[オプション・サービス一覧はこちら](https://mobile.nuro.jp/option/)

NUROモバイルご利用にあたっての注意事項
---------------------

### サービスについて

*   提供エリア内であっても、建物の中・地下・トンネルなど電波の届かないところ、または屋外でも電波の弱いところではご利用いただけない場合があります。
*   当月ご利用のデータ通信量が各月の規定値に達した場合、当月末までの通信速度を制限いたします。
*   使い切れずに余ったデータ容量は、翌月に繰り越してご利用いただけます。お試しプランは対象外です。
*   別途ユニバーサルサービス料および電話リレーサービス料がかかります（但し、電話番号が「020」から始まる場合は除きます）。詳細は、[『ご利用規約』新しいウインドウで開く](https://mobile.nuro.jp/legal/postpaid/kiyaku.pdf)
    の料金表をご確認ください。

### お申し込みについて

*   同一名義または同一世帯にて5件を超えるお申し込みはできません。
*   音声通話付きSIMをお申し込みの際は、お手元に本人確認書類をご準備ください。
*   MNP(携帯電話番号ポータビリティー)をご利用の場合、MNP予約番号の有効期限まで10日以上ある状態でお申し込み下さい。
*   本サービスのお申し込みには、お申し込み者ご本人名義のクレジットカードが必要です。  
    ご利用いただけるクレジットカードは次の通りです。：VISA、MasterCard、JCB、Diners、AMEX  
    上記ブランドであってもデビットカード、プリペイドカード等のご利用はできません。また、一部ご利用いただけないクレジットカードがございます。予めご了承ください。

### 商品の発送について

*   お申し込み者ご本人によるお受け取りをお願いいたします。
*   音声通話付きSIMをお申し込みの場合、提出いただいた本人確認書類に記載されている住所宛にお送りいたします。
*   データ通信専用SIMのSIMカードのみをお申し込みの場合（端末とセットでのお申し込みでない場合）は、ご自宅のポストへ投函いたします。
*   午後2時までにお申し込み手続きが完了しますと、最短で当日に発送いたします。なお、音声通話付きSIMをお申し込み頂いた場合は、ご本人様確認が午後2時まで完了した場合に最短当日発送となります。お申し込みプランを問わず、端末セットは順次発送いたします。
*   お申し込み受け付け数や在庫状況によっては発送にお時間を いただく場合がございます。また、お申し込み内容や本人確認書類に不備があった場合はお手続きに時間がかかる場合がございます。
*   端末が在庫切れとなった場合、発送にお時間を頂く場合や、お申し込みをキャンセルさせていただく場合がございますので、予めご了承ください。
*   音声通話付きSIMをお申し込みの場合、本人確認完了後の配送となり、ご希望の配送日時にお届けできない場合がございます。予めご了承ください。
*   MNPで開通済のSIMカードをお送りする場合、切替からSIM到着までは電話番号が使用できません。予めご留意ください。
*   商品の発送には万全を期しておりますが、万が一、商品ご到着時に破損等お気づきの点がございましたら、商品パッケージの封緘シールを剥がさずに、[SIMサービスサポート新しいウインドウで開く](https://support.sonynetwork.co.jp/faqsupport/nuromobile/web/index.html)
    まで速やかにご連絡ください。  
    なお、開封済みの端末については、交換等のご対応が出来兼ねる場合もございますので、ご了承ください。

### 解約について

*   端末料金を分割クレジットまたはお受け取り時にお支払いいただいている場合、設定したお支払い回数分の請求は継続します。

### マイページについて

*   本サービスのご利用明細および通話明細は[「マイページ」新しいウインドウで開く](https://www.nuro.jp/app/mypage/login/)
    にてご確認ができます。  
    書面によるご利用明細および領収書の発行はいたしておりません。
*   マイページは解約後4か月経過すると利用できなくなります。

### NEOプランについて

*   音声通話付きSIMのみのご提供です。
*   当月ご利用のデータ通信量が各月の規定値に達した場合、当月末までの通信速度を最大1Mbpsに制限します。制限後も、データ通信の最初の数秒は低速通信速度以上の速度（初速バースト）がご利用いただけます。
*   NEOデータフリーをご利用いただくにあたって、お申し込みの際に注意事項に同意を頂く必要がございます。詳細については[こちら](https://mobile.nuro.jp/option/neo-datafree/)
    をご覧ください。
*   ご購入いただいたチャージ容量、受取済みのチャージ容量は、プラン変更の際に繰り越しできません。

### 格安SIMプランについて（バリュープラス・お試しプラン）

*   au回線プランは、au VoLTE非対応端末ではご利用できません。au VoLTE対応端末が必要です。また、2017年7月31日以前にauから発売されたau VoLTE対応端末に関しては、SIMロックを解除していただくことが必要です。
*   当月ご利用のデータ通信量が各月の規定値に達した場合、当月末までの通信速度を最大200kbpsに制限します。制限後も、データ通信の最初の数秒は低速通信速度以上の速度（初速バースト）がご利用いただけます。
*   プラン変更は可能です。プラン変更のお手続きをした月の翌月1日より適用となります。なお、ドコモ回線・au回線・ソフトバンク回線の間での変更はできません。予めご留意ください。

### かけ放題ジャストについて

*   ドコモ回線・au回線のみのご提供です。
*   音声通話付きSIMのみのご提供です。
*   ご利用開始月の請求額は、5分かけ放題プラン：490円/10分かけ放題プラン：880円/かけ放題プラン：1,430円となります。
*   かけ放題プランの1回の通話時間は120分までとなるため、120分を超過する通話は切断されます。再架電いただくことは可能で、通話回数に制限はありません。
*   MNPでお申し込みの場合、かけ放題プランに標準付帯されている通話定額機能は、サービス開始日の翌日からご利用いただけます。サービス開始日当日に発信した通話は、転出元の事業者との契約内容に基づいた通話料が発生しますので、ご注意ください。
*   かけ放題プランの対象になる通話は、オートプレフィックス通話のみです。オートプレフィックス通話以外（専用アプリ使用など手動付加によるプレフィックス通話）は対象外ですので、ご注意ください。5分かけ放題プラン、10分かけ放題プランは、オートプレフィックス通話・手動付加によるプレフィックス通話のどちらも定額通話の対象です。
*   標準付帯されている通話定額機能部分のみを変更・解約はできません。マイページで契約プランの変更を行ったうえで、お手続きください。
*   かけ放題プランの対象外となる通話がございます。詳細は[こちら新しいウインドウで開く](https://mobile.nuro.jp/option/denwa/pdf/kakeho.pdf)
    からご確認ください。
*   かけ放題ジャスト以外のプランへ変更することが可能です。（5分かけ放題プラン、10分かけ放題プラン間のプラン変更は可能です。）プラン変更のお手続きをした月の翌月1日より適用となります。なお、ドコモ回線・au回線・ソフトバンク回線の間での変更はできません。予めご留意ください。
*   国際通話、フリーダイヤル、ナビダイヤル、110番等の3桁番号への通話は定額通話の対象外となります。

このページをシェアする

*   [![facebook](https://mobile.nuro.jp/images/nmui2/icon-facebook.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fmobile.nuro.jp%2Fplan%2F)
    
*   [![Twitter](https://mobile.nuro.jp/images/nmui2/icon-twitter.png)](https://twitter.com/share?url=https%3A%2F%2Fmobile.nuro.jp%2Fplan%2F)
    
*   [![LINE](https://mobile.nuro.jp/images/nmui2/icon-line.png)](https://line.me/R/msg/text/?https%3A%2F%2Fmobile.nuro.jp%2Fplan%2F)
    

1.  [NUROモバイル TOP](https://mobile.nuro.jp/)
    
2.  料金プラン

[![ページトップ](https://mobile.nuro.jp/images/nmui2/gotop.png)](https://mobile.nuro.jp/plan/#)

![NURO Mobile](https://mobile.nuro.jp/images/nmui2/logo-nuromobile-white.png)

[トップ](https://mobile.nuro.jp/)

[お知らせ](https://mobile.nuro.jp/news_release/)

[アーカイブ](https://mobile.nuro.jp/archive/)

[障害メンテナンス情報新しいウィンドウで開く](https://www.nuro.jp/emerge/)

[規約一覧](https://mobile.nuro.jp/kiyaku/)

[NUROモバイルアプリ](https://mobile.nuro.jp/app/)

official account

*   [![facebook](https://mobile.nuro.jp/images/nmui2/icon-facebook.png)](https://www.facebook.com/NUROMobilebySony/)
    
*   [![Instagram](https://mobile.nuro.jp/images/nmui2/icon-instagram.png)](https://www.instagram.com/nuromobilebysony/)
    
*   [![(旧：Twitter)](https://mobile.nuro.jp/images/nmui2/icon-x-under.png)](https://twitter.com/nuromobile_jp)
    
*   [![Youtube](https://mobile.nuro.jp/images/nmui2/icon-youtube.png)](https://youtube.com/channel/UC3PO0t22QLwQ4-cm8rvdFEw)
    

[![NURO](https://mobile.nuro.jp/images/nmui2/logo-nuro-white.png)](https://www.sonynetwork.co.jp/corporation/nuro_rebrand2021/)

ソニーネットワークコミュニケーションズ株式会社  
Copr. Sony Network Communications Inc. 登録番号(電気通信事業者): 関第94号

*   [個人情報保護 / 情報セキュリティへの取り組み新しいウィンドウで開く](https://www.sonynetwork.co.jp/corporation/safety/)
    
*   [会社概要新しいウィンドウで開く](https://www.sonynetwork.co.jp/corporation/company/profile/)
    
*   [サイトポリシー](https://mobile.nuro.jp/kiyaku/siteinfo.html)
    

![](https://bat.bing.com/action/0?ti=97129554&Ver=2&mid=1ce30fab-9384-497e-96e2-cfc67edee0c7&bo=1&sid=4fdf6fc0d17611f0aca0c98b2a0041bc&vid=4fdf8b10d17611f094cfb37a15c0a6bd&vids=1&msclkid=N&pi=0&lg=en-US@posix&sw=1280&sh=800&sc=24&nwd=1&tl=%E6%96%99%E9%87%91%E3%83%97%E3%83%A9%E3%83%B3%EF%BD%9C%E6%A0%BC%E5%AE%89SIM%E3%83%BB%E3%82%B9%E3%83%9E%E3%83%9B%E3%81%AENURO%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB&kw=%E6%A0%BC%E5%AE%89SIM,%E6%A0%BC%E5%AE%89%E3%82%B9%E3%83%9E%E3%83%9B,NURO%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB,%E6%96%99%E9%87%91%E3%83%97%E3%83%A9%E3%83%B3&p=https%3A%2F%2Fmobile.nuro.jp%2Fplan%2F&r=&lt=1281&evt=pageLoad&sv=2&cdb=AQAQ&rn=945605)

![](https://googleads.g.doubleclick.net/pagead/viewthroughconversion/981375687/?guid=ON&amp;script=0)![](https://b97.yahoo.co.jp/pagead/conversion/1000255097/?guid=ON&script=0&disvt=false)![](https://googleads.g.doubleclick.net/pagead/viewthroughconversion/843763034/?guid=ON&amp;script=0)![](https://www.googleadservices.com/pagead/conversion/843763034/?label=FCdICI_7wnMQ2pqrkgM&amp;guid=ON&amp;script=0)![](https://googleads.g.doubleclick.net/pagead/viewthroughconversion/941735114/?guid=ON&amp;script=0)![](https://b97.yahoo.co.jp/pagead/conversion/1000255095/?guid=ON&script=0&disvt=false)![](https://www.facebook.com/tr?id=1581914835441962&ev=PageView&noscript=1)![](https://b97.yahoo.co.jp/pagead/conversion/1000977195/?guid=ON&script=0&disvt=false)    ![](https://api.botchan.chat/api/analytic/wc/pageview?cpid=666260145bab41507472c81b&uid=&curl=https%3A%2F%2Fmobile.nuro.jp%2Fplan%2F&ref=&title=%E6%96%99%E9%87%91%E3%83%97%E3%83%A9%E3%83%B3%EF%BD%9C%E6%A0%BC%E5%AE%89SIM%E3%83%BB%E3%82%B9%E3%83%9E%E3%83%9B%E3%81%AENURO%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB&user_agent=Mozilla%2F5.0%20(iPhone%3B%20CPU%20iPhone%20OS%2018_6_2%20like%20Mac%20OS%20X)%20AppleWebKit%2F605.1.15%20(KHTML%2C%20like%20Gecko)%20CriOS%2F141.0.7390.41%20Mobile%2F15E148%20Safari%2F604.1&t=1764896653039)![](https://t.co/i/adsct?bci=5&dv=UTC%26en-US%40posix%26Google%20Inc.%26Linux%20x86_64%26127%261280%26800%268%2624%261280%26800%260%26na&eci=2&event_id=1ea06588-6d79-4d46-8a86-934102fbaeaf&events=%5B%5B%22pageview%22%2C%7B%7D%5D%5D&integration=advertiser&p_id=Twitter&p_user_id=0&pl_id=af60e531-bf60-4c92-8c07-95afb668dae4&pt=%E6%96%99%E9%87%91%E3%83%97%E3%83%A9%E3%83%B3%EF%BD%9C%E6%A0%BC%E5%AE%89SIM%E3%83%BB%E3%82%B9%E3%83%9E%E3%83%9B%E3%81%AENURO%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB&tw_document_href=https%3A%2F%2Fmobile.nuro.jp%2Fplan%2F&tw_iframe_status=0&tw_order_quantity=0&tw_sale_amount=0&txn_id=o2n66&type=javascript&version=2.3.35)![](https://analytics.twitter.com/i/adsct?bci=5&dv=UTC%26en-US%40posix%26Google%20Inc.%26Linux%20x86_64%26127%261280%26800%268%2624%261280%26800%260%26na&eci=2&event_id=1ea06588-6d79-4d46-8a86-934102fbaeaf&events=%5B%5B%22pageview%22%2C%7B%7D%5D%5D&integration=advertiser&p_id=Twitter&p_user_id=0&pl_id=af60e531-bf60-4c92-8c07-95afb668dae4&pt=%E6%96%99%E9%87%91%E3%83%97%E3%83%A9%E3%83%B3%EF%BD%9C%E6%A0%BC%E5%AE%89SIM%E3%83%BB%E3%82%B9%E3%83%9E%E3%83%9B%E3%81%AENURO%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB&tw_document_href=https%3A%2F%2Fmobile.nuro.jp%2Fplan%2F&tw_iframe_status=0&tw_order_quantity=0&tw_sale_amount=0&txn_id=o2n66&type=javascript&version=2.3.35)![](https://t.co/i/adsct?bci=5&dv=UTC%26en-US%40posix%26Google%20Inc.%26Linux%20x86_64%26127%261280%26800%268%2624%261280%26800%260%26na&eci=2&event_id=7bdc247f-eef3-45cf-94c6-dbeee87fc19b&events=%5B%5B%22pageview%22%2C%7B%7D%5D%5D&integration=advertiser&p_id=Twitter&p_user_id=0&pl_id=af60e531-bf60-4c92-8c07-95afb668dae4&pt=%E6%96%99%E9%87%91%E3%83%97%E3%83%A9%E3%83%B3%EF%BD%9C%E6%A0%BC%E5%AE%89SIM%E3%83%BB%E3%82%B9%E3%83%9E%E3%83%9B%E3%81%AENURO%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB&tw_document_href=https%3A%2F%2Fmobile.nuro.jp%2Fplan%2F&tw_iframe_status=0&tw_order_quantity=0&tw_sale_amount=0&txn_id=o474l&type=javascript&version=2.3.35)![](https://analytics.twitter.com/i/adsct?bci=5&dv=UTC%26en-US%40posix%26Google%20Inc.%26Linux%20x86_64%26127%261280%26800%268%2624%261280%26800%260%26na&eci=2&event_id=7bdc247f-eef3-45cf-94c6-dbeee87fc19b&events=%5B%5B%22pageview%22%2C%7B%7D%5D%5D&integration=advertiser&p_id=Twitter&p_user_id=0&pl_id=af60e531-bf60-4c92-8c07-95afb668dae4&pt=%E6%96%99%E9%87%91%E3%83%97%E3%83%A9%E3%83%B3%EF%BD%9C%E6%A0%BC%E5%AE%89SIM%E3%83%BB%E3%82%B9%E3%83%9E%E3%83%9B%E3%81%AENURO%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB&tw_document_href=https%3A%2F%2Fmobile.nuro.jp%2Fplan%2F&tw_iframe_status=0&tw_order_quantity=0&tw_sale_amount=0&txn_id=o474l&type=javascript&version=2.3.35)![](https://t.co/1/i/adsct?bci=5&dv=UTC%26en-US%40posix%26Google%20Inc.%26Linux%20x86_64%26127%261280%26800%268%2624%261280%26800%260%26na&eci=3&event=%7B%7D&event_id=f0076f36-e920-484b-8ea9-f9071b03d30f&integration=advertiser&p_id=Twitter&p_user_id=0&pl_id=af60e531-bf60-4c92-8c07-95afb668dae4&pt=%E6%96%99%E9%87%91%E3%83%97%E3%83%A9%E3%83%B3%EF%BD%9C%E6%A0%BC%E5%AE%89SIM%E3%83%BB%E3%82%B9%E3%83%9E%E3%83%9B%E3%81%AENURO%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB&tw_document_href=https%3A%2F%2Fmobile.nuro.jp%2Fplan%2F&tw_iframe_status=0&txn_id=olnwk&type=javascript&version=2.3.35)![](https://analytics.twitter.com/1/i/adsct?bci=5&dv=UTC%26en-US%40posix%26Google%20Inc.%26Linux%20x86_64%26127%261280%26800%268%2624%261280%26800%260%26na&eci=3&event=%7B%7D&event_id=f0076f36-e920-484b-8ea9-f9071b03d30f&integration=advertiser&p_id=Twitter&p_user_id=0&pl_id=af60e531-bf60-4c92-8c07-95afb668dae4&pt=%E6%96%99%E9%87%91%E3%83%97%E3%83%A9%E3%83%B3%EF%BD%9C%E6%A0%BC%E5%AE%89SIM%E3%83%BB%E3%82%B9%E3%83%9E%E3%83%9B%E3%81%AENURO%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB&tw_document_href=https%3A%2F%2Fmobile.nuro.jp%2Fplan%2F&tw_iframe_status=0&txn_id=olnwk&type=javascript&version=2.3.35)![](https://t.co/i/adsct?bci=5&dv=UTC%26en-US%40posix%26Google%20Inc.%26Linux%20x86_64%26127%261280%26800%268%2624%261280%26800%260%26na&eci=2&event_id=8ed3f135-7628-42d8-8a41-681c5e2ebc95&events=%5B%5B%22pageview%22%2C%7B%7D%5D%5D&integration=advertiser&p_id=Twitter&p_user_id=0&pl_id=af60e531-bf60-4c92-8c07-95afb668dae4&pt=%E6%96%99%E9%87%91%E3%83%97%E3%83%A9%E3%83%B3%EF%BD%9C%E6%A0%BC%E5%AE%89SIM%E3%83%BB%E3%82%B9%E3%83%9E%E3%83%9B%E3%81%AENURO%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB&tw_document_href=https%3A%2F%2Fmobile.nuro.jp%2Fplan%2F&tw_iframe_status=0&tw_order_quantity=0&tw_sale_amount=0&txn_id=o2pfc&type=javascript&version=2.3.35)![](https://analytics.twitter.com/i/adsct?bci=5&dv=UTC%26en-US%40posix%26Google%20Inc.%26Linux%20x86_64%26127%261280%26800%268%2624%261280%26800%260%26na&eci=2&event_id=8ed3f135-7628-42d8-8a41-681c5e2ebc95&events=%5B%5B%22pageview%22%2C%7B%7D%5D%5D&integration=advertiser&p_id=Twitter&p_user_id=0&pl_id=af60e531-bf60-4c92-8c07-95afb668dae4&pt=%E6%96%99%E9%87%91%E3%83%97%E3%83%A9%E3%83%B3%EF%BD%9C%E6%A0%BC%E5%AE%89SIM%E3%83%BB%E3%82%B9%E3%83%9E%E3%83%9B%E3%81%AENURO%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB&tw_document_href=https%3A%2F%2Fmobile.nuro.jp%2Fplan%2F&tw_iframe_status=0&tw_order_quantity=0&tw_sale_amount=0&txn_id=o2pfc&type=javascript&version=2.3.35)![](https://t.co/i/adsct?bci=5&dv=UTC%26en-US%40posix%26Google%20Inc.%26Linux%20x86_64%26127%261280%26800%268%2624%261280%26800%260%26na&eci=2&event_id=0c9d0d66-a548-4995-809d-c7768d909e66&events=%5B%5B%22pageview%22%2C%7B%7D%5D%5D&integration=advertiser&p_id=Twitter&p_user_id=0&pl_id=af60e531-bf60-4c92-8c07-95afb668dae4&pt=%E6%96%99%E9%87%91%E3%83%97%E3%83%A9%E3%83%B3%EF%BD%9C%E6%A0%BC%E5%AE%89SIM%E3%83%BB%E3%82%B9%E3%83%9E%E3%83%9B%E3%81%AENURO%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB&tw_document_href=https%3A%2F%2Fmobile.nuro.jp%2Fplan%2F&tw_iframe_status=0&tw_order_quantity=0&tw_sale_amount=0&txn_id=o4q08&type=javascript&version=2.3.35)![](https://analytics.twitter.com/i/adsct?bci=5&dv=UTC%26en-US%40posix%26Google%20Inc.%26Linux%20x86_64%26127%261280%26800%268%2624%261280%26800%260%26na&eci=2&event_id=0c9d0d66-a548-4995-809d-c7768d909e66&events=%5B%5B%22pageview%22%2C%7B%7D%5D%5D&integration=advertiser&p_id=Twitter&p_user_id=0&pl_id=af60e531-bf60-4c92-8c07-95afb668dae4&pt=%E6%96%99%E9%87%91%E3%83%97%E3%83%A9%E3%83%B3%EF%BD%9C%E6%A0%BC%E5%AE%89SIM%E3%83%BB%E3%82%B9%E3%83%9E%E3%83%9B%E3%81%AENURO%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB&tw_document_href=https%3A%2F%2Fmobile.nuro.jp%2Fplan%2F&tw_iframe_status=0&tw_order_quantity=0&tw_sale_amount=0&txn_id=o4q08&type=javascript&version=2.3.35)    ![](https://t.co/i/adsct?bci=5&dv=UTC%26en-US%40posix%26Google%20Inc.%26Linux%20x86_64%26127%261280%26800%268%2624%261280%26800%260%26na&eci=1&event_id=d3b04294-fa24-4052-a016-2a9d2b0b918b&integration=advertiser&p_id=Twitter&p_user_id=0&pl_id=af60e531-bf60-4c92-8c07-95afb668dae4&pt=%E6%96%99%E9%87%91%E3%83%97%E3%83%A9%E3%83%B3%EF%BD%9C%E6%A0%BC%E5%AE%89SIM%E3%83%BB%E3%82%B9%E3%83%9E%E3%83%9B%E3%81%AENURO%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB&tw_document_href=https%3A%2F%2Fmobile.nuro.jp%2Fplan%2F&tw_iframe_status=0&tw_order_quantity=0&tw_sale_amount=0&txn_id=o4si0&type=javascript&version=2.3.35)![](https://analytics.twitter.com/i/adsct?bci=5&dv=UTC%26en-US%40posix%26Google%20Inc.%26Linux%20x86_64%26127%261280%26800%268%2624%261280%26800%260%26na&eci=1&event_id=d3b04294-fa24-4052-a016-2a9d2b0b918b&integration=advertiser&p_id=Twitter&p_user_id=0&pl_id=af60e531-bf60-4c92-8c07-95afb668dae4&pt=%E6%96%99%E9%87%91%E3%83%97%E3%83%A9%E3%83%B3%EF%BD%9C%E6%A0%BC%E5%AE%89SIM%E3%83%BB%E3%82%B9%E3%83%9E%E3%83%9B%E3%81%AENURO%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB&tw_document_href=https%3A%2F%2Fmobile.nuro.jp%2Fplan%2F&tw_iframe_status=0&tw_order_quantity=0&tw_sale_amount=0&txn_id=o4si0&type=javascript&version=2.3.35)

[![](https://img.ada-cloud.com/pattern/j4WwrCJNdOUxmRDPv1LpwIhymYB6p3DrClq9m65S.gif)](https://lin.ee/7RtURM5T)

        

![](https://img.ada-cloud.com/pattern/P7qB6TytLfqcOq27gJMTgGhEfjBtH4Vf3W1qSyJL.gif)

× LINE友だち限定で配信中🎁

![](https://t.co/1/i/adsct?bci=5&dv=UTC%26en-US%40posix%26Google%20Inc.%26Linux%20x86_64%26127%261280%26800%268%2624%261280%26800%260%26na&eci=3&event=%7B%7D&event_id=49142650-1858-4f30-bd46-8456a687e8ab&integration=advertiser&p_id=Twitter&p_user_id=0&pl_id=af60e531-bf60-4c92-8c07-95afb668dae4&pt=%E6%96%99%E9%87%91%E3%83%97%E3%83%A9%E3%83%B3%EF%BD%9C%E6%A0%BC%E5%AE%89SIM%E3%83%BB%E3%82%B9%E3%83%9E%E3%83%9B%E3%81%AENURO%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB&tw_document_href=https%3A%2F%2Fmobile.nuro.jp%2Fplan%2F&tw_iframe_status=0&txn_id=o6c6r&type=javascript&version=2.3.35)![](https://analytics.twitter.com/1/i/adsct?bci=5&dv=UTC%26en-US%40posix%26Google%20Inc.%26Linux%20x86_64%26127%261280%26800%268%2624%261280%26800%260%26na&eci=3&event=%7B%7D&event_id=49142650-1858-4f30-bd46-8456a687e8ab&integration=advertiser&p_id=Twitter&p_user_id=0&pl_id=af60e531-bf60-4c92-8c07-95afb668dae4&pt=%E6%96%99%E9%87%91%E3%83%97%E3%83%A9%E3%83%B3%EF%BD%9C%E6%A0%BC%E5%AE%89SIM%E3%83%BB%E3%82%B9%E3%83%9E%E3%83%9B%E3%81%AENURO%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB&tw_document_href=https%3A%2F%2Fmobile.nuro.jp%2Fplan%2F&tw_iframe_status=0&txn_id=o6c6r&type=javascript&version=2.3.35)         ![](https://t.co/1/i/adsct?bci=5&dv=UTC%26en-US%40posix%26Google%20Inc.%26Linux%20x86_64%26127%261280%26800%268%2624%261280%26800%260%26na&eci=3&event=%7B%7D&event_id=59facad4-0036-4b67-b401-f6c3de9c01fa&integration=advertiser&p_id=Twitter&p_user_id=0&pl_id=af60e531-bf60-4c92-8c07-95afb668dae4&pt=%E6%96%99%E9%87%91%E3%83%97%E3%83%A9%E3%83%B3%EF%BD%9C%E6%A0%BC%E5%AE%89SIM%E3%83%BB%E3%82%B9%E3%83%9E%E3%83%9B%E3%81%AENURO%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB&tw_document_href=https%3A%2F%2Fmobile.nuro.jp%2Fplan%2F&tw_iframe_status=0&txn_id=odviq&type=javascript&version=2.3.35)![](https://analytics.twitter.com/1/i/adsct?bci=5&dv=UTC%26en-US%40posix%26Google%20Inc.%26Linux%20x86_64%26127%261280%26800%268%2624%261280%26800%260%26na&eci=3&event=%7B%7D&event_id=59facad4-0036-4b67-b401-f6c3de9c01fa&integration=advertiser&p_id=Twitter&p_user_id=0&pl_id=af60e531-bf60-4c92-8c07-95afb668dae4&pt=%E6%96%99%E9%87%91%E3%83%97%E3%83%A9%E3%83%B3%EF%BD%9C%E6%A0%BC%E5%AE%89SIM%E3%83%BB%E3%82%B9%E3%83%9E%E3%83%9B%E3%81%AENURO%E3%83%A2%E3%83%90%E3%82%A4%E3%83%AB&tw_document_href=https%3A%2F%2Fmobile.nuro.jp%2Fplan%2F&tw_iframe_status=0&txn_id=odviq&type=javascript&version=2.3.35)
