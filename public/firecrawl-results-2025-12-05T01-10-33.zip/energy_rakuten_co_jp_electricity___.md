# 楽天でんき（個人・家庭向け電気サービス）｜楽天エナジー

URL: https://energy.rakuten.co.jp/electricity/

---

[![Rakuten Mobile](https://cdn.rmc.contents.rakuten.co.jp/block/d40535ac09aac0ef32f8a23b8bb8e04bc2e8f9d6b0981fa98a16d0382f558d83/d72cbeb1-1b70-4fb2-b7e5-cb3c0a24841f/card20k_enddate_pc_1440x50.png)](https://cdn.rex.contents.rakuten.co.jp/webcx-redirect-module/1.3.0/index.html?clientId=d40535ac09aac0ef32f8a23b8bb8e04bc2e8f9d6b0981fa98a16d0382f558d83&version=2.73.0&sessionId=0e9928e2-4c3c-4902-b2f4-0f6616dbf3cf&screen=WB&issueId=F01184-001256&campaignId=2aadf4f2-55c7-4337-8472-22f617277367&contentId=4382487a-283f-4306-b0d1-11d8c70206b1&replacementId=9354c015-1ef6-41d2-8298-0bf372a98402&impressionId=4e5e261c-b1ff-4cc4-9428-c14e5dc7312a&selector=mkdiv_header_pitari&redirect=aHR0cHM6Ly9yZC5yYWt1dGVuLmNvLmpwL3JhdD9SMj1odHRwczovL25ldHdvcmsubW9iaWxlLnJha3V0ZW4uY28uanAvY2FtcGFpZ24vY2FyZC1tb2JpbGUtbWFqaXRva3UvJTNGc2NpZCUzRHdpX2VuZV9ybWJfbWtkaXZfaGVhZGVyX3BpdGFyaV9jbW9fc3BfbmV3LWNhcmQtbm8td2ViY3hfY2FyZC1tb2JpbGUtbWFqaXRva3VfMjAyNTEyMDEmYWNjPTEzMTImYWlkPTEmZXR5cGU9Y2xpY2smc3NjPWNyb3NzdXNlX2NhbXBhaWduJnBnbj1jbW9fcGl0YXJpJnJlZj1odHRwczovL2VuZXJneS5yYWt1dGVuLmNvLmpwL2VsZWN0cmljaXR5LyZ0YXJnZXRfZWxlPW5ldy1jYXJkLW5vLXdlYmN4X2NhcmQtbW9iaWxlLW1haml0b2t1XzIwMjUxMjAx&origin=aHR0cHM6Ly9lbmVyZ3kucmFrdXRlbi5jby5qcA==)

*   [楽天モバイル](https://network.mobile.rakuten.co.jp/?scid=wi_ene_mnotop)
    
*   [楽天市場](https://www.rakuten.co.jp/)
    
*   [楽天グループ](https://www.rakuten.co.jp/sitemap/)
    

[メニュー](https://energy.rakuten.co.jp/electricity/#)

[メニュー](https://energy.rakuten.co.jp/electricity/#)

[![logo](https://energy.rakuten.co.jp/common/img/logo_energy_small.svg)](https://energy.rakuten.co.jp/)

[お申し込み](https://energy.rakuten.co.jp/electricity/#)

[ログイン](https://mypage.energy.rakuten.co.jp/contracts/?l-id=visitor_head_gnavi_dialog)

[閉じる](https://energy.rakuten.co.jp/electricity/#)

[![logo](https://energy.rakuten.co.jp/common/img/logo_energy.svg)](https://energy.rakuten.co.jp/)

*   [お申し込み](https://energy.rakuten.co.jp/electricity/#)
    
*   [ログイン](https://mypage.energy.rakuten.co.jp/contracts/?l-id=visitor_head_gnavi_dialog)
    
    [ログイン](https://mypage.energy.rakuten.co.jp/contracts/?l-id=visitor_head_gnavi_login)
    

*   楽天でんき
    
    [楽天でんき](https://energy.rakuten.co.jp/electricity/)
    
    *   楽天でんきTOP
        
        *   [楽天でんきTOP](https://energy.rakuten.co.jp/electricity/?l-id=visitor_per_head_gnavi_electricity_top)
            
        
    *   料金・お支払い
        
        *   [料金シミュレーション](https://energy.rakuten.co.jp/electricity/LvEasySimulation/?l-id=visitor_per_head_gnavi_electricity_LvEasySimulation)
            
        *   [電気料金プラン](https://energy.rakuten.co.jp/electricity/fee/?l-id=visitor_per_head_gnavi_electricity_fee)
            
        *   [お支払い方法](https://energy.rakuten.co.jp/electricity/payment/?l-id=visitor_per_head_gnavi_electricity_payment)
            
        *   [燃料費調整単価](https://energy.rakuten.co.jp/electricity/fee/fuelcost/?l-id=visitor_per_head_gnavi_electricity_fuelcost)
            
        *   [市場価格調整単価](https://energy.rakuten.co.jp/electricity/fee/market_linked/?l-id=visitor_per_head_gnavi_electricity_market_linked)
            
        
    *   おトク
        
        *   [楽天ポイントが  \
            貯まる・使える](https://energy.rakuten.co.jp/electricity/merit/?l-id=visitor_per_head_gnavi_electricity_merit)
            
        *   [キャンペーン](https://energy.rakuten.co.jp/campaign/?l-id=visitor_per_head_gnavi_electricity_campaign)
            
        
    *   お申し込み
        
        *   [お申し込みの流れ](https://energy.rakuten.co.jp/electricity/flow/?l-id=visitor_per_head_gnavi_electricity_flow)
            
        *   [お申し込み](https://energy.rakuten.co.jp/electricity/#)
            
        
    *   契約約款・利用規約
        
        *   [契約約款・利用規約一覧](https://energy.rakuten.co.jp/electricity/terms/?l-id=visitor_per_head_gnavi_electricity_terms)
            
        *   [注意事項](https://energy.rakuten.co.jp/electricity/attention/?l-id=visitor_per_head_gnavi_electricity_attention)
            
        *   [特定商取引法に基づく表示](https://energy.rakuten.co.jp/electricity/commerce/?l-id=visitor_per_head_gnavi_commerce)
            
        
    *   安心・安全・便利
        
        *   [安定した電力供給](https://energy.rakuten.co.jp/electricity/power/?l-id=visitor_per_head_gnavi_electricity_power)
            
        *   [マイページ機能紹介  \
            （使用量管理）](https://energy.rakuten.co.jp/electricity/mypage/?l-id=visitor_per_head_gnavi_electricity_mypage)
            
        
    *   お問い合わせ
        
        *   [Q&A・お問い合わせ](https://energy.rakuten.co.jp/faq/)
            
        
    
    *   ご契約中のお客様
        
        *   [マイページログイン](https://mypage.energy.rakuten.co.jp/contracts/?l-id=visitor_per_head_gnavi_electricity_mypage_login)
            
        *   [引越し手続き](https://energy.rakuten.co.jp/electricity/#)
            
        *   [停電など非常時のご案内](https://energy.rakuten.co.jp/electricity/if/?l-id=visitor_per_head_gnavi_electricity_if)
            
        *   [省エネ情報](https://energy.rakuten.co.jp/energy_saving/?l-id=visitor_per_head_gnavi_energy_saving)
            
        *   [節電トライ](https://energy.rakuten.co.jp/electricity/power_saving/?l-id=visitor_per_head_gnavi_power_saving)
            
        
    
*   楽天ガス
    
    [楽天ガス](https://energy.rakuten.co.jp/electricity/)
    
    *   楽天ガスTOP
        
        *   [楽天ガスTOP](https://energy.rakuten.co.jp/gas/?l-id=visitor_per_head_gnavi_gas_top)
            
        
    *   料金・お支払い
        
        *   [ガス料金プラン](https://energy.rakuten.co.jp/gas/fee/?l-id=visitor_per_head_gnavi_gas_fee)
            
        *   [お支払い方法](https://energy.rakuten.co.jp/gas/payment/?l-id=visitor_per_head_gnavi_gas_payment)
            
        *   [原料費調整単価](https://energy.rakuten.co.jp/gas/fee/materialcost/?l-id=visitor_per_head_gnavi_gas_costadjustment)
            
        
    *   おトク
        
        *   [楽天ポイントが  \
            貯まる・使える](https://energy.rakuten.co.jp/gas/merit/?l-id=visitor_per_head_gnavi_gas_merit)
            
        *   [キャンペーン](https://energy.rakuten.co.jp/campaign/?l-id=visitor_per_head_gnavi_gas_campaign)
            
        
    *   お申し込み
        
        *   [お申し込みの流れ](https://energy.rakuten.co.jp/gas/flow/?l-id=visitor_per_head_gnavi_gas_flow)
            
        *   [お申し込み](https://energy.rakuten.co.jp/electricity/#)
            
        
    *   契約約款・利用規約
        
        *   [契約約款・利用規約一覧](https://energy.rakuten.co.jp/gas/terms/?l-id=visitor_per_head_gnavi_gas_terms)
            
        *   [注意事項](https://energy.rakuten.co.jp/gas/attention/?l-id=visitor_per_head_gnavi_gas_attention)
            
        *   [特定商取引法に基づく表示](https://energy.rakuten.co.jp/gas/commerce/?l-id=visitor_per_head_gnavi_gas_commerce)
            
        
    *   対象エリア
        
        *   [対象エリア](https://energy.rakuten.co.jp/gas/area/?l-id=visitor_per_head_gnavi_gas_area)
            
        
    *   安心・安全・便利
        
        *   [安定したガス供給](https://energy.rakuten.co.jp/gas/supply/?l-id=visitor_per_head_gnavi_gas_supply)
            
        *   [マイページ機能紹介  \
            （使用量管理）](https://energy.rakuten.co.jp/gas/mypage/?l-id=visitor_per_head_gnavi_gas_mypage)
            
        
    *   お問い合わせ
        
        *   [Q&A・お問い合わせ](https://energy.rakuten.co.jp/faq/)
            
        
    *   ご契約中のお客様
        
        *   [マイページログイン](https://mypage.energy.rakuten.co.jp/contracts/?l-id=visitor_per_head_gnavi_gas_login_mypage)
            
        *   [ガス漏れなど非常時のご案内](https://energy.rakuten.co.jp/gas/if/?l-id=visitor_per_head_gnavi_gas_if)
            
        
    

[閉じる](https://energy.rakuten.co.jp/electricity/#)

申し込むサービスを  
選択してください。

*   [楽天でんき](https://energy.rakuten.co.jp/electricity/#)
    
*   [楽天ガス](https://energy.rakuten.co.jp/electricity/#)
    

楽天でんきと楽天ガスに合わせてお申し込みをご希望の方は、楽天でんきの申し込み完了後に楽天ガスをお申し込みください。詳しくは[楽天でんきお申し込みの流れ](https://energy.rakuten.co.jp/electricity/flow/?l-id=visitor_per_head_popup_electricity_flow)
と[楽天ガスお申し込みの流れ](https://energy.rakuten.co.jp/gas/flow/?l-id=visitor_per_head_popup_gas_flow)
をご確認ください

※楽天ガスは、東京ガスエリア・東邦ガスエリア・関電ガスエリアの方のみお申し込みいただけます。  
詳しくは[対象エリアページ](https://energy.rakuten.co.jp/gas/area/?l-id=visitor_per_head_popup_gas_area)
をご確認ください。

[閉じる](https://energy.rakuten.co.jp/electricity/#)

申し込み内容を  
ご選択ください。

*   [現住所を  \
    楽天でんきに切り替える](https://energy.rakuten.co.jp/electricity/application/ConsumerApplication/switch/confirmCard/?l-id=visitor_per_head_popup_apply_denki_sw1)
    
*   [引越し先で  \
    楽天でんきを申し込む](https://energy.rakuten.co.jp/electricity/#)
    

でんきとガスを合わせてお申し込み希望の方は、楽天でんき申し込み完了後に、楽天ガスをお申し込みください。

[閉じる](https://energy.rakuten.co.jp/electricity/#)

引越し先で電気のご契約を  
されていますか？

*   [いいえ、まだ電気の契約を  \
    していません  \
    （不明の場合はこちら）](https://energy.rakuten.co.jp/electricity/#)
    
*   [はい、すでに電気の契約を  \
    しています](https://energy.rakuten.co.jp/electricity/application/ConsumerApplication/switch/confirmCard/?l-id=visitor_per_head_popup_apply_denki_sw2)
    

[閉じる](https://energy.rakuten.co.jp/electricity/#)

引越し予定日をご選択ください

引越し予定日が12月10日より前の場合  
引越し当日から楽天でんきを利用する事はできません。一度地域の電力会社でご利用した後、楽天でんきに切替えの手続きをお願いします。

[閉じる](https://energy.rakuten.co.jp/electricity/#)

楽天ガスの  
申し込み方を  
選択してください。

*   [現住所を  \
    楽天ガスに切り替える](https://gas.energy.rakuten.co.jp/singleApplication/switch/confirmCard?l-id=visitor_per_head_popup_apply_gas_new)
    
*   [引越し先で  \
    楽天ガスを申し込む  \
    （東京ガスエリアのみ）](https://energy.rakuten.co.jp/electricity/#)
    

楽天ガスお申し込みの[対象エリア](https://energy.rakuten.co.jp/gas/area/?l-id=visitor_per_head_popup_gas_area)
をご確認ください。

現住所でのお切り替え：東京ガス・東邦ガス・関電ガスエリア  
引越しに伴うお申し込み：東京ガスエリア

※東邦ガス・関電ガスエリアのお客様は、お引越し後、地域のガス会社から楽天ガスへお切り替えください。

[閉じる](https://energy.rakuten.co.jp/electricity/#)

引越し先でガスの  
ご契約をされていますか？

*   [いいえ、まだガスの契約を  \
    していません  \
    （不明の場合はこちら）](https://energy.rakuten.co.jp/electricity/#)
    
*   [はい、すでにガスの契約を  \
    しています](https://gas.energy.rakuten.co.jp/singleApplication/switch/confirmCard?l-id=visitor_per_head_popup_apply_gas_new)
    

[閉じる](https://energy.rakuten.co.jp/electricity/#)

引越し予定日をご選択ください

東京ガスのエリアへ引っ越しのお客様  
選択可能な日付にて、引っ越し日から楽天ガスをご利用可能です。

その他エリアへ引っ越しのお客様  
一度地域のガス会社でご利用した後、楽天ガスへお切替えください。楽天ガスの対象エリアは[こちら](https://energy.rakuten.co.jp/gas/area/?l-id=visitor_per_head_popup_gas_area)

[閉じる](https://energy.rakuten.co.jp/electricity/#)

「楽天でんき」「楽天ガス」解約※1の  
お手続きを選択ください。

*   現住所で他社へのお切り替え  
    楽天エナジーへのお手続き原則不要※2です。  
    他社にお申し込みいただければ  
    自動的に解約されます。
    
*   [お引越し等に伴う現住所の解約※3  \
    現住所で電気を使わないお客様は  \
    こちらよりお手続きください。](https://energy.rakuten.co.jp/electricity/application/ConsumerApplication/move/termination/input)
    

※1 ご利用開始特典の条件を満たす前に解約を行った場合、特典の対象となりません。詳しくは[キャンペーンルール](https://energy.rakuten.co.jp/gas/?l-id=visitor_per_head_gnavi_gas_top#rule_gas)
をご確認ください。（楽天でんきと楽天ガスのキャンペーンルールは同様の条件となります）  
※2 「楽天でんき」では、お切替先の電力会社によって、楽天エナジーへ廃止日のご連絡を求められる場合がございます。その際は、[問い合わせフォーム](https://energy.faq.rakuten.net/CCRM_EnergyAsk?l-id=visitor_per_head_gnavi_energyask)
へお進みください。  
※3 ログインエラー等で解約申し込みができないお客様についてはお電話にてお手続きをお願いいたします。  
楽天エナジーカスタマーセンター TEL : 050-5490-9070（有料）  
受付時間 : 9:30～17:30 月曜日～日曜日(年末年始等の期間は除く)

*   いくらおトクになるか試算！
    
    [料金  \
    シミュレーション](https://energy.rakuten.co.jp/electricity/#js-simulation)
    
*   いくらおトクになるか試算！
    
    [料金  \
    シミュレーション](https://energy.rakuten.co.jp/electricity/LvEasySimulation/?l-id=visitor_per_floating_electricity)
    
*   平均2分でサクッと完了!!
    
    [お申し込み](https://energy.rakuten.co.jp/electricity/#)
    

![楽天でんき](https://energy.rakuten.co.jp/common/img/logo_denki.svg) ![楽天でんき](https://energy.rakuten.co.jp/common/img/logo_denki.svg)
=================================================================================================================================

![新規お申し込み&ご利用で3,000ポイント進呈](https://energy.rakuten.co.jp/electricity/img/mainvisual_normal_pc.png) ![新規お申し込み&ご利用で3,000ポイント進呈](https://energy.rakuten.co.jp/electricity/img/mainvisual_normal_sp.png)
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

**キャンペーン期間** :  
2025年12月2日(火)10:00 ～ 2026年2月2日(月)9:59

*   進呈するポイント(期間限定ポイント)の条件は[でんきキャンペーン詳細](https://energy.rakuten.co.jp/electricity/#rule_denki)
    をご確認ください。

＼平均2分でサクッと完了!!／

*   [今すぐ申し込む](https://energy.rakuten.co.jp/electricity/#)
    

![](https://energy.rakuten.co.jp/img/webblocks/electricity_20251031/mainvisual.png) ![](https://energy.rakuten.co.jp/img/webblocks/electricity_20251031/mainvisual_sp.png)

*   キャンペーン期間中に2つの条件を満たす必要があります。  
    1.2026年2月20日時点で楽天カードをご利用中の方。  
    2.楽天市場・楽天トラベルのご利用額合計が2025年10月16日～2026年2月20日のお買い物期間中で37,000円以上。
*   進呈されるポイントは6カ月間の期間限定で、2026年3月進呈を予定しています。
*   キャンペーンルールの詳細は[こちら](https://energy.rakuten.co.jp/mobile/datasim/rule/)
    をご確認ください。

キャンペーンの申し込み方法
-------------

STEP1

### 楽天でんきのお申し込みページで「キャンペーン申し込み」にチェック

![](https://energy.rakuten.co.jp/img/webblocks/electricity_20251031/datasim_form_image.png) ![](https://energy.rakuten.co.jp/img/webblocks/electricity_20251031/datasim_form_image_sp.png)

お申し込みフォーム入力画面のページで、チェックボックスにチェック！

*   [楽天でんきにお申し込み](https://energy.rakuten.co.jp/electricity/#)
    

STEP2

### 楽天市場、楽天トラベルでお買いもの

![](https://energy.rakuten.co.jp/img/webblocks/electricity_20251031/flow_step1.png)

*   2025年10月16日～2026年2月20日の期間中に累計37,000円以上ご利用ください。

STEP3

### 条件達成のお知らせ

![](https://energy.rakuten.co.jp/img/webblocks/electricity_20251031/flow_step2.png)

2026年3月ごろまでに条件達成のお知らせと配送先とSIMタイプご確認のメールをお送りします。

STEP4

### 届いたら即日利用可能！ ご利用開始！

![](https://energy.rakuten.co.jp/img/webblocks/electricity_20251031/flow_step3.png)

eSIM用のQRコードまたはSIMを郵送いたします。届きましたら案内に沿ってお手続きください。郵送は2026年3月以降の対応となります。

無料期間終了後に自動解約

データSIMは2027年3月31日以降、自動で解約されます。お客様のお手続きは不要です。

*   ![](https://energy.rakuten.co.jp/common/img/icon_tab_electricity.png)楽天でんき
*   [![](https://energy.rakuten.co.jp/common/img/icon_tab_gas.png)楽天ガス](https://energy.rakuten.co.jp/gas/)
    

楽天でんきの特長

*   [基本料金0円の  \
    料金体系](https://energy.rakuten.co.jp/electricity/#01)
    
*   [楽天ポイントが  \
    ザクザク貯まる](https://energy.rakuten.co.jp/electricity/#02)
    
*   [ポイント払いで  \
    電気代0円！？](https://energy.rakuten.co.jp/electricity/#03)
    
*   [お申し込みは  \
    Webでカンタン](https://energy.rakuten.co.jp/electricity/#04)
    
*   [契約の縛り無し  \
    解約も0円](https://energy.rakuten.co.jp/electricity/#05)
    
*   [安心の  \
    サポート](https://energy.rakuten.co.jp/electricity/#06)
    

楽天でんきなら料金体系が  
おトク！
-------------------

*   ### お支払いは使った分だけ！
    
    基本料金
    
    ![0円](https://energy.rakuten.co.jp/campaign/lp/point/energy/img/price_img_2.png)
    
    *   電気料金プランの詳しい情報は[こちら](https://energy.rakuten.co.jp/electricity/fee/?l-id=visitor_per_electricity_top)
        
    
*   切り替えた際の一例
    
    *   [標準的な  \
        4人世帯の場合](https://energy.rakuten.co.jp/electricity/#)
        
    *   [標準的な  \
        2人世帯の場合](https://energy.rakuten.co.jp/electricity/#)
        
    
    標準的な4人世帯の場合
    
    東京エリア・従量電灯B  
    40A・11月利用分の電気代12,283円※1で計算※2
    
    初年度11,515円相当おトク
    
    内訳
    
    *   電気料金※3
        
        6,235円削減
        
    *   電気料金で楽天ポイント
        
        710ポイント獲得
        
    *   楽天カード払いで  
        楽天ポイント※4
        
        1,570ポイント獲得
        
    *   でんき加入  
        特典ポイント※5
        
        3,000ポイント獲得
        
    
    *   電気料金はこちらを参照しています。e-Stat 「家計調査」2024年  
         [1～3月期](https://www.e-stat.go.jp/stat-search/files?page=1&layout=datalist&toukei=00200561&tstat=000000330001&cycle=2&year=20240&month=11010300&tclass1=000000330001&tclass2=000000330019&tclass3=000000330020&cycle_facet=tclass1%3Atclass2%3Atclass3%3Acycle&tclass4val=0&metadata=1&data=1)
          [4～6月期](https://www.e-stat.go.jp/stat-search/files?page=1&layout=datalist&toukei=00200561&tstat=000000330001&cycle=2&year=20240&month=12040600&tclass1=000000330001&tclass2=000000330019&tclass3=000000330020&cycle_facet=tclass1%3Atclass2%3Atclass3%3Acycle&tclass4val=0&metadata=1&data=1)
          [7～9月期](https://www.e-stat.go.jp/stat-search/files?page=1&layout=datalist&toukei=00200561&tstat=000000330001&cycle=2&year=20240&month=23070900&tclass1=000000330001&tclass2=000000330019&tclass3=000000330020&cycle_facet=tclass1%3Atclass2%3Atclass3%3Acycle&tclass4val=0&metadata=1&data=1)
          [10～12月期](https://www.e-stat.go.jp/stat-search/files?page=1&layout=datasetList&toukei=00200561&tstat=000000330001&cycle=2&year=20240&month=24101200&tclass1=000000330001&tclass2=000000330019&tclass3=000000330020&cycle_facet=tclass1%3Atclass2%3Atclass3%3Acycle&metadata=1&data=1)
        
    *   2025年11月自社調べ
    *   **電気料金に燃料費調整額、市場価格調整額は含まれていません。**
    *   楽天ポイントの進呈対象は、クレジットカードでお支払いいただいた料金となります。
    *   進呈するポイントは期間限定ポイントです。詳しくは[キャンペーンルール](https://energy.rakuten.co.jp/electricity/#rule_denki)
        をご確認ください。
    
    標準的な2人世帯の場合
    
    東京エリア・従量電灯B  
    40A・11月利用分の電気代10,535円※1で計算※2
    
    初年度9,901円相当おトク
    
    内訳
    
    *   電気料金※3
        
        4,954円削減
        
    *   電気料金で楽天ポイント
        
        607ポイント獲得
        
    *   楽天カード払いで  
        楽天ポイント※4
        
        1,340ポイント獲得
        
    *   でんき加入特典  
        ポイント※5
        
        3,000ポイント獲得
        
    
    *   電気料金はこちらを参照しています。e-Stat 「家計調査」2024年  
         [1～3月期](https://www.e-stat.go.jp/stat-search/files?page=1&layout=datalist&toukei=00200561&tstat=000000330001&cycle=2&year=20240&month=11010300&tclass1=000000330001&tclass2=000000330019&tclass3=000000330020&cycle_facet=tclass1%3Atclass2%3Atclass3%3Acycle&tclass4val=0&metadata=1&data=1)
          [4～6月期](https://www.e-stat.go.jp/stat-search/files?page=1&layout=datalist&toukei=00200561&tstat=000000330001&cycle=2&year=20240&month=12040600&tclass1=000000330001&tclass2=000000330019&tclass3=000000330020&cycle_facet=tclass1%3Atclass2%3Atclass3%3Acycle&tclass4val=0&metadata=1&data=1)
          [7～9月期](https://www.e-stat.go.jp/stat-search/files?page=1&layout=datalist&toukei=00200561&tstat=000000330001&cycle=2&year=20240&month=23070900&tclass1=000000330001&tclass2=000000330019&tclass3=000000330020&cycle_facet=tclass1%3Atclass2%3Atclass3%3Acycle&tclass4val=0&metadata=1&data=1)
          [10～12月期](https://www.e-stat.go.jp/stat-search/files?page=1&layout=datasetList&toukei=00200561&tstat=000000330001&cycle=2&year=20240&month=24101200&tclass1=000000330001&tclass2=000000330019&tclass3=000000330020&cycle_facet=tclass1%3Atclass2%3Atclass3%3Acycle&metadata=1&data=1)
        
    *   2025年11月自社調べ
    *   **電気料金に燃料費調整額、市場価格調整額は含まれていません。**
    *   楽天ポイントの進呈対象は、クレジットカードでお支払いいただいた料金となります。
    *   進呈するポイントは期間限定ポイントです。詳しくは[キャンペーンルール](https://energy.rakuten.co.jp/electricity/#rule_denki)
        をご確認ください。
    
*   ![計算機イラスト](https://energy.rakuten.co.jp/campaign/lp/point/energy/img/icon_calculator.svg)
    
    料金シミュレーションで  
    比べてみてください！
    
     
    
    *   *   契約中の電力会社 （必須）
            
            北海道電力 東北電力 東京電力 中部電力 北陸電力 関西電力 中国電力 四国電力 九州電力
            
    *   *   利用月 （必須）
            
            1月 2月 3月 4月 5月 6月 7月 8月 9月 10月 11月 12月
            
    *   *   電気料金 （必須）
            
        
        電気料金の目安※  
        1人世帯6,356円  2人世帯10,535円    
        3人世帯12,486円    
        4人世帯12,283円
        
        ※ 出典：e-Stat 「家計調査」2024年  
         [1～3月期](https://www.e-stat.go.jp/stat-search/files?page=1&layout=datalist&toukei=00200561&tstat=000000330001&cycle=2&year=20240&month=11010300&tclass1=000000330001&tclass2=000000330019&tclass3=000000330020&cycle_facet=tclass1%3Atclass2%3Atclass3%3Acycle&tclass4val=0&metadata=1&data=1)
          [4～6月期](https://www.e-stat.go.jp/stat-search/files?page=1&layout=datalist&toukei=00200561&tstat=000000330001&cycle=2&year=20240&month=12040600&tclass1=000000330001&tclass2=000000330019&tclass3=000000330020&cycle_facet=tclass1%3Atclass2%3Atclass3%3Acycle&tclass4val=0&metadata=1&data=1)
          [7～9月期](https://www.e-stat.go.jp/stat-search/files?page=1&layout=datalist&toukei=00200561&tstat=000000330001&cycle=2&year=20240&month=23070900&tclass1=000000330001&tclass2=000000330019&tclass3=000000330020&cycle_facet=tclass1%3Atclass2%3Atclass3%3Acycle&tclass4val=0&metadata=1&data=1)
          [10～12月期](https://www.e-stat.go.jp/stat-search/files?page=1&layout=datasetList&toukei=00200561&tstat=000000330001&cycle=2&year=20240&month=24101200&tclass1=000000330001&tclass2=000000330019&tclass3=000000330020&cycle_facet=tclass1%3Atclass2%3Atclass3%3Acycle&metadata=1&data=1)
        
    
    [試算結果を見る](https://energy.rakuten.co.jp/electricity/#js-result)
    
    *   **シミュレーション結果には、毎月変動する市場価格調整単価・燃料費調整単価は反映しておりません。  
        電力取引価格によっては、楽天でんきが地域の電力会社よりも安くならないことがあります。**
    *   楽天でんきの過去の市場価格調整単価は[こちら](https://energy.rakuten.co.jp/electricity/fee/market_linked/)
        よりご確認ください。
    
    シミュレーション結果
    
    地域の電力会社と比べて
    
    初年度
    
    \-円
    
    相当おトク！
    
    内訳
    
    *   電気料金 ※
        
    *   楽天ガスも加入で+3,000ポイント獲得
        
        電気料金で  
        楽天ポイント
        
        \-  
        ポイント獲得
        
    *   楽天カード払いで  
        楽天ポイント
        
        \-  
        ポイント獲得
        
    *   でんき加入特典  
        楽天ポイント
        
        \-
        
    
    *   **シミュレーション結果には、毎月変動する市場価格調整単価・燃料費調整単価は反映しておりません。  
        電力取引価格によっては、楽天でんきが地域の電力会社よりも安くならないことがあります。**  
        （例：東京電力エリア２人世帯(200kWh利用)の場合、シミュレーション結果よりも、2023年4月利用だと1,026円安く、2024年12月利用だと1,942円高い）
    *   楽天でんきの過去の市場価格調整単価は[こちら](https://energy.rakuten.co.jp/electricity/fee/market_linked/)
        よりご確認ください。  
        地域電力会社の料金に関する情報は、各社がウェブサイト等で公開している情報を使用しております。（2024年2月1日時点。）
        *   シミュレーションの結果（計算方法等）について、詳しくは[注意事項](https://energy.rakuten.co.jp/electricity/LvEasySimulation/#precautions_simulation)
            をご覧ください。
        *   ポイント進呈条件について詳しくは[キャンペーンルール](https://energy.rakuten.co.jp/electricity/#rule_denki)
            をご確認ください。
    
    *   [もう一度、試算する](https://energy.rakuten.co.jp/electricity/#)
        
    
    ![](https://energy.rakuten.co.jp/campaign/lp/point/energy/img/logo_gas.svg)も
    
    同時にお申し込み＆ご利用で
    
    +3,000ポイント進呈※
    
    最大6,000ポイント進呈！
    
    *   進呈するポイント(期間限定ポイント)の条件は[ガスキャンペーン詳細](https://energy.rakuten.co.jp/electricity/#gas_rule)
        をご確認ください。
    *   東京ガス / 東邦ガス / 関電ガスエリアが対象となります。詳しくは[対象エリア](https://energy.rakuten.co.jp/gas/area/)
        をご確認ください。
    *   楽天でんきの申し込み完了後に楽天ガスをお申し込みください。
    
    [ガスも合わせて試算する](https://energy.rakuten.co.jp/electricity/LvEasySimulation/)
    
    ＼平均2分でサクッと完了!!／
    
    *   [今すぐ申し込む](https://energy.rakuten.co.jp/electricity/#)
        
    

楽天でんきならポイントが  
ザクザク貯まる！
-----------------------

*   ポイント1
    
    ### 使った分だけポイントが貯まる
    
    *   おトク!
        
        でんき単体なら  
        ご利用料金
        
        200円につき1ポイント!
        
    *   ダンゼンおトク!
        
        でんきとガスをセットなら  
        ご利用料金
        
        100円につき1ポイント!
        
    
    *   楽天ポイントの進呈対象は、クレジットカードでお支払いいただいた料金となります。コンビニ払込用紙でのお支払いではポイント進呈  
        対象にはなりません。
    
*   ポイント2
    
    ### 楽天カードで支払えばさらに貯まる！
    
    楽天カード決済のポイント還元率が  
    地域電力会社を利用した際の
    
    ![楽天カード決済のポイント還元率5倍](https://energy.rakuten.co.jp/campaign/lp/point/img/card_img_1.png)
    
    ポイント貯まる
    
    ![楽天でんき](https://energy.rakuten.co.jp/campaign/lp/point/img/card_img_3.png) ![楽天でんき](https://energy.rakuten.co.jp/campaign/lp/point/img/card_img_3.png)
    
    100円で1ポイント
    
    地域電力会社
    
    500円で1ポイント
    
    *   詳しくは[還元率が異なる公共料金](https://www.rakuten-card.co.jp/point/pointrate/)
        をご確認ください。
    
*   ポイント3
    
    ### SPUでさらにポイントザクザク！
    
    ![楽天spu](https://energy.rakuten.co.jp/campaign/lp/point/energy/img/logo_spu.svg)
    
    楽天市場の  
    お買い物が
    
    ポイント+0.5倍
    
    *   毎月の獲得上限ポイント数は1,000ポイントとなります。
    *   クレジットカードでのお支払い完了が条件となります。
    *   詳しくは[こちら](https://energy.rakuten.co.jp/campaign/lp/pre_spu/)
        をご確認ください。
    

貯まったポイントで  
電気料金が支払える！
----------------------

*   ![月々のお支払い→実際のお支払いは通常ポイントに加えて、期間限定ポイントもお支払いにご利用可能。](https://energy.rakuten.co.jp/electricity/img/point_use.png) ![月々のお支払い→実際のお支払いは通常ポイントに加えて、期間限定ポイントもお支払いにご利用可能。](https://energy.rakuten.co.jp/electricity/img/point_use.png)
    
    期間限定ポイントから支払えるので  
    自動支払い設定を利用すれば  
    ポイントの使い忘れ防止に便利！
    
    さらに
    
    ![Coins](https://energy.rakuten.co.jp/electricity/img/point_use_coin.png) ポイントで支払った分も  
    ポイント進呈！
    
    *   詳しくは[ポイント利用に関する注意事項](https://energy.rakuten.co.jp/electricity/attention/#point)
        をご覧ください。
    
    ![Devices](https://energy.rakuten.co.jp/electricity/img/point_use_device.png) ポイント支払い設定は  
    ご利用開始後マイページから！
    
    *   ご利用いただくには、[マイページ](https://mypage.energy.rakuten.co.jp/contracts/)
        にログインいただき、「各種お手続き」＞「ポイント設定」より設定してください。翌月請求分より適用となります。
    

[詳しいポイントの貯め方・使い方はこちら](https://energy.rakuten.co.jp/electricity/merit/?l-id=visitor_per_electricitytop_merit)

*   面倒な切替手続き不要
    ----------
    
    ![切替工事、切替時の立ち会い、現でんき会社への解約連絡、書類などのご記入、不要](https://energy.rakuten.co.jp/campaign/lp/point/energy/img/no_procedure.png) ![切替工事、切替時の立ち会い、現でんき会社への解約連絡、書類などのご記入、不要](https://energy.rakuten.co.jp/campaign/lp/point/energy/img/no_procedure.png)
    
*   お申し込みはWEBで完結  
    工事不要
    -------------------
    
    *   ![](https://energy.rakuten.co.jp/electricity/img/flow_01.png) ![](https://energy.rakuten.co.jp/electricity/img/flow_01.png)
        
        1.お申し込み（WEBのみ）
        
        「検針票」や「ご契約中の電力会社のWEBサイト」など、契約内容がわかるもの※をご準備のうえ、[申し込みフォーム](https://energy.rakuten.co.jp/entry/)
        にて必要事項をご入力ください。
        
        *   お申し込みには、ご契約中の電力会社名・供給地点特定番号・お客様番号・契約容量が必要です。
        
        ![](https://energy.rakuten.co.jp/electricity/img/flow_pc_image.png) ![](https://energy.rakuten.co.jp/electricity/img/flow_pc_image.png)
        
        ご契約中の電力会社の解約手続きは不要です。  
        楽天エナジーが解約手続きをいたします。
        
    *   ![](https://energy.rakuten.co.jp/electricity/img/flow_02.png)
        
        2.供給開始予定日のお知らせ
        
        供給開始予定日のお知らせメールをお送りいたします。
        
    *   ![](https://energy.rakuten.co.jp/electricity/img/flow_04.png)
        
        3.ご請求・お支払い  
        （ご利用開始から約3ヵ月以降）
        
        楽天でんきは、月々の電気料金をクレジットカード決済にてお支払いいただきます。  
        初回のお支払いはご利用開始から約3ヵ月以降になります。  
        詳しくは[お支払いスケジュール](https://energy.rakuten.co.jp/electricity/payment/)
        をご確認ください。
        
    
    *   [お申し込みの流れについて  \
        もっと詳しく](https://energy.rakuten.co.jp/electricity/flow/?l-id=visitor_per_electricitytop_flow)
        
    
*   楽天モバイルショップでもでんきのお申し込みをサポート！
    ---------------------------
    
    ![楽天モバイルショップ](https://energy.rakuten.co.jp/electricity/img/rakuten_mobile.png)
    
    *   東電エリア内（静岡県を除く）のみ
    *   楽天でんき取扱店舗は各店舗ページの「対応サービス・店舗条件」をご確認ください。
    
    [お近くのショップを探す・来店予約](https://r10.to/hFipzN)
    

契約年数の縛りなし  
切替も解約も０円
--------------------

### 切り替え手続き・工事費用・解約手数料

![0円](https://energy.rakuten.co.jp/common/img/zero.svg) ![0円](https://energy.rakuten.co.jp/common/img/zero.svg)

他社から楽天でんきへの切替手続き・工事費用はかかりません。  
現契約の解約についても、お客様によるお手続きは不要です。  
また、契約年数の縛りはないので、楽天でんきを解約する場合であっても、解約手数料・違約金を支払う必要はありません。

*   現在ご契約中の電力会社・プランによっては解約手数料が掛かる場合がございますので、現在のご契約内容をご確認ください。

電気の品質・トラブル対応は  
これまで通り
----------------------

### 電力の安定性は変わりません。

供給の安定性や停電の  
復旧対応はこれまでと同じ

ブレーカーが落ちやすく  
なったりはしません

*   停電時の復旧作業等は地域電力が今までどおり対応します。

### 専用のカスタマーセンターが丁寧にご対応します。

楽天エナジーのカスタマーセンターに寄せられたお客様の声の一部を紹介します。

*   ![お客様の声01](https://energy.rakuten.co.jp/campaign/lp/point/energy/img/cf_01.png)
    
    でんきの契約切替時に必要な情報について、  
    前の電気会社と比較にならないくらい的確なフォローをいただきました。
    
*   ![お客様の声02](https://energy.rakuten.co.jp/campaign/lp/point/energy/img/cf_02.png)
    
    引越し先の電気開通状況をメールで確認すると、すぐにお返事を頂きました。  
    開通する旨とご安心くださいという一言があり、不安が解消されました。
    

![](https://energy.rakuten.co.jp/campaign/lp/point/energy/img/logo_gas.svg)も

同時にお申し込み＆ご利用で

+3,000ポイント進呈※

今なら

最大6,000ポイント進呈！

*   進呈するポイント(期間限定ポイント)の条件は[ガスキャンペーン詳細](https://energy.rakuten.co.jp/electricity/#rule_gas)
    をご確認ください。
*   東京ガス / 東邦ガス / 関電ガスエリアが対象となります。詳しくは[対象エリア](https://energy.rakuten.co.jp/gas/area/)
    をご確認ください。
*   楽天でんきの申し込み完了後に楽天ガスをお申し込みください。

＼平均2分でサクッと完了!!／

*   [今すぐ申し込む](https://energy.rakuten.co.jp/electricity/#)
    

楽天でんきご利用開始特典に関するキャンペーンルール

*   キャンペーン期間
    
    2025年12月2日(火)10:00 ～ 2026年2月2日(月)9:59
    
*   特典
    
    対象の方全員に楽天ポイントを3,000ポイントプレゼントします。
    
*   ポイント進呈
    
    *   進呈される楽天ポイントは、進呈日から有効期間6カ月間の期間限定ポイントになります。
    *   楽天ポイントの進呈は、楽天でんきのサービス利用開始月を0カ月目として、6カ月目の月末頃までに行います。  
        （例）利用開始月が12月の場合、翌年6月末にポイントが進呈される予定です。
    
*   特典対象
    
    以下のすべての条件を満たす方が対象者となります。  
    
    *   利用開始月およびその翌月分の電気料金合計が6,000円以上の方。
    *   ※ 電気の使用量から利用料金を推計される場合、[楽天でんきの料金表](https://energy.rakuten.co.jp/electricity/fee/)
        にてエリアごとの1kWhあたりの料金をご参照ください。
    *   楽天でんきのサービス利用開始月を0カ月目として、5カ月目の末日まで楽天でんきをご利用いただいた方。
    
*   特典対象外理由
    
    以下のいずれかに該当する場合、本キャンペーンの適用対象外となりますのでご注意ください。
    
    *   お申し込みから4カ月以内に楽天でんきの利用が開始（供給開始）されていない場合。
    *   お申込み内容の不備等により、ご利用開始に至らなかった場合。
    *   ポイント進呈月の前月末までに解約した場合。
    *   利用開始月およびその翌月の電気料金合計が6,000円未満の方。
    *   動力プランもしくは楽天でんきBusinessのご契約。
    *   楽天でんきの契約の引き継ぎに伴うお申し込みの場合。
    *   当社が合理的に不正行為と判断した場合。
    
*   注意事項
    
    *   楽天でんきのご利用開始を条件とする複数のキャンペーンに参加されている場合、ポイント数が多い方のキャンペーンが適用されます。
    *   お住まいの住所（一部離島など）や現在ご利用の電力会社プランによっては、稀にサービス自体ご提供できない場合がございます。
    *   楽天ID1つにつき複数施設を本キャンペーンの対象としてご契約の場合、ご契約施設数にあわせてポイントを進呈いたします。
    *   同一楽天IDで過去に楽天でんきのご利用をしたことがある施設でのお申し込みは楽天ポイント進呈の対象外となります。
    *   権利の譲渡はできません。
    *   特典の適用判定に使用する電気料金は、再生可能エネルギー賦課金、市場価格調整額、燃料費調整額を含む特別値引き前の金額（税込、楽天ポイント充当前）になります。
    *   利用開始月およびその翌月分の電気料金合計が6,000円以上の方。引越し日当日から楽天でんきを申し込みされているお客様は、利用開始月の請求が2つに分かれることがありますが、利用開始月と翌月分合計3つの請求で計算します。
    *   本キャンペーンからお申し込み後、6カ月以内にお引越しに伴う継続利用申し込みをされた場合でも、本キャンペーンは適用されます。
    *   期間終了後も継続して、または不定期に同様のキャンペーン（特典内容や条件が異なる場合含む）を実施する可能性があります。
    *   本キャンペーンは予告なく内容の変更もしくは中止させていただく場合がございます。
    

楽天ガスご利用開始特典に関するキャンペーンルール

*   キャンペーン期間
    
    2025年11月2日(日)9:59 ～ 常時開催
    
*   特典
    
    対象の方全員に楽天ポイントを3,000ポイントプレゼントします。
    
*   ポイント進呈
    
    *   進呈される楽天ポイントは、進呈日から有効期間6カ月間の期間限定ポイントになります。
    *   楽天ポイントの進呈は、楽天ガスのサービス利用開始月を0ヵ月目として、6ヵ月目の月末頃までに行います。  
        （例）利用開始月が12月の場合、翌年6月末にポイントが進呈される予定です。
    
*   特典対象
    
    以下のすべての条件を満たす方が対象者となります。  
    
    *   利用開始月およびその翌月分のガス料金合計が3,000円以上の方。
    *   キャンペーン開始以降に楽天ガスにお申し込みされ、6ヵ月以内にサービスを利用開始（供給開始）した方。
    *   楽天ガスのサービス利用開始月を0カ月目として、5カ月目の末日まで楽天ガスをご利用いただいた方。
    
*   特典対象外理由
    
    以下のいずれかに該当する場合、本キャンペーンの適用対象外となりますのでご注意ください。
    
    *   お申し込みから6ヵ月以内に楽天ガスの利用が開始（供給開始）されていない場合。
    *   お申し込み内容の不備等により、ご利用開始に至らなかった場合。
    *   楽天ポイント進呈月の前月末までに解約した場合。（楽天ポイント進呈前月末日までに楽天ガスを解約した場合において、ガス小売事業者による管理の都合上、楽天ポイント進呈前月末日まで当社が楽天ガスを供給中と取り扱っている場合には、楽天ポイント進呈を行います。 楽天ガスの解約を申し出た後に、お客様とガス小売事業者との間で独自に解約日を変更した場合には、変更によって実際の供給実態が進呈条件を満たしている場合でも進呈を行いません。）
    *   利用開始月およびその翌月分のガス料金合計が3,000円未満の方。
    *   楽天ガスの契約の引き継ぎに伴うお申し込みの場合。
    *   当社が合理的に不正行為と判断した場合。
    
*   注意事項
    
    *   楽天ガスのご利用開始を条件とする複数のキャンペーンに参加されている場合、楽天ポイント数が多い方のキャンペーンが適用されます。
    *   楽天ガスはサービス提供エリアが限定されているため、あらかじめ[供給エリア](https://energy.rakuten.co.jp/gas/area/)
        をご確認ください。
    *   楽天ID1つにつき複数施設を本キャンペーンの対象としてご契約の場合、ご契約施設数にあわせてポイントを進呈いたします。
    *   同一楽天IDで過去に楽天ガスの新規利用特典の適用を受けた施設でのお申し込みは楽天ポイント進呈の対象外となります。
    *   権利の譲渡はできません。
    *   特典の適用判定に使用するガス料金は、原料費調整額を含む特別値引き前の金額（税込、楽天ポイント充当前）になります。
    *   引越し日当日から楽天ガスを申し込みされているお客様は、利用開始月の請求が2つに分かれることがありますが、利用開始月と翌月分合計3つの請求で計算します。
    *   本キャンペーンからお申し込み後、6カ月以内にお引越しに伴う継続利用申し込みをされた場合でも、本キャンペーンは適用されます。
    *   期間終了後も継続して、または不定期に同様のキャンペーン（特典内容や条件が異なる場合含む）を実施する可能性があります。
    *   本キャンペーンは予告なく内容の変更もしくは中止させていただく場合がございます。
    

Previous

*   [![楽天損保の自転車保険](https://energy.rakuten.co.jp/img/top/banner/sonpo_bicycle_165x100.jpg)](https://www.rakuten-sonpo.co.jp/tabid/997/Default.aspx?ag=elc1)
    
*   [![楽天ママ割](https://energy.rakuten.co.jp/img/top/banner/mamawari_165x100.jpg)](https://event.rakuten.co.jp/family/line/?scid=wi_ene_mmw_line_pc_lps_200413)
    
*   [![Rakutenwallet](https://energy.rakuten.co.jp/img/top/banner/wallet-165_100.png)](https://www.rakuten-wallet.co.jp/point/?scid=wi_ener_top_165_100)
    
*   [![ポイ活から投資までお得な情報がたくさん](https://energy.rakuten.co.jp/img/top/banner/money_165x100.jpeg)](https://www.rakuten-card.co.jp/minna-money/?scid=wi_mny_ene_minna_top_202206)
    
*   [![SPU](https://energy.rakuten.co.jp/img/top/banner/spu_165x100.png)](https://event.rakuten.co.jp/campaign/point-up/everyday/point/challenge/?scid=wi_ich_challenge_energy_electricity_top)
    
*   [![楽天不動産](https://energy.rakuten.co.jp/img/top/banner/realestate_165x100.png)](https://realestate.rakuten.co.jp/contents/lp/2025/newpropertymail/?scid=we_energy_bnr)
    
*   [![楽天家計簿](https://energy.rakuten.co.jp/img/top/banner/kakeibo_entrycampaign_165x100.png)](https://app.adjust.com/1dsni5m5?redirect=https%3A%2F%2Fpersonal-finance.rakuten.co.jp%2Fcampaign%2F%E2%80%A6)
    
*   [![楽天ラクマ](https://energy.rakuten.co.jp/img/top/banner/rakuma_165x100.png)](https://rakuma.rakuten.co.jp/info/campaign/spu/?scid=wi_energy_campaign)
    
*   [![RakutenBEAUTY](https://energy.rakuten.co.jp/img/top/banner/beauty_165x100.png)](https://app.adjust.com/1i7mmj9d?redirect=https://beauty.rakuten.co.jp/cnt/topics/campaign/app2x/?scid=wi_ene_group_App2x)
    
*   [![楽天ぐるなび楽天ポイント進呈最大30,000ポイント](https://energy.rakuten.co.jp/img/top/banner/gnavi_165x100.jpg)](https://r.gnavi.co.jp/plan/campaign/bonus/?sc_cid=cp_rkt_ene_cam251101_01&scid=wi_ene_cam251101_01)
    
*   [![楽天Rebates](https://energy.rakuten.co.jp/img/top/banner/rebates_165x100.png)](https://www.rebates.jp/event/ftb?utm_medium=partner&utm_campaign=202312_rakuten_energy_top&utm_source=web&utm_content=rakutengroup&utm_term=&utm_size=&utm_pub=&utm_ebs=LP&scid=202312_rakuten_energy_top)
    
*   [![楽天Car](https://energy.rakuten.co.jp/img/top/banner/rakuten_car_165x100.jpg)](https://car.rakuten.co.jp/shaken/campaign/prospects/lottery5000p_aug23/?scid=wi_denki_lottery5000p_topgrouplist)
    
*   [![楽天ウェブ検索](https://energy.rakuten.co.jp/img/top/banner/web_search.png)](https://toolbar.rakuten.co.jp/intro/information/members/newcampaign1/?scid=wi_ene_banner)
    
*   [![楽天イーグルス](https://energy.rakuten.co.jp/img/top/banner/eagles_165x100.jpg)](https://www.youtube.com/c/rakuteneagles)
    
*   [![楽天銀行](https://energy.rakuten.co.jp/img/top/banner/bank_165x100.png)](https://www.rakuten-bank.co.jp/account/campaign/payment1000.html?scid=wi_ene_top_1000_internal)
    
*   [![紹介キャンペーン](https://energy.rakuten.co.jp/img/top/banner/tomodachi-portal.jpg)](https://event.rakuten.co.jp/group/invitation/?scid=wi_ene_memd_friendsportal_01)
    
*   [![楽天ファーム](https://energy.rakuten.co.jp/img/top/banner/farm_165x100.png)](https://www.rakuten.co.jp/rakuten-farm/?scid=wi_frm_renergy_frm-ichiba-top)
    
*   [![Rakuten edyshop](https://energy.rakuten.co.jp/img/top/banner/edy_165x100.gif)](https://item.rakuten.co.jp/edyshop/edy-rpoint_panda/)
    
*   [![短期賃貸ならライフルホームズマンスリー](https://energy.rakuten.co.jp/img/top/banner/homes_165x100.jpg)](https://monthly.homes.jp/?utm_source=r_energy&utm_medium=banner&utm_campaign=top)
    
*   [![Rakuten TV](https://energy.rakuten.co.jp/img/top/banner/tv_banner.jpeg)](https://tv.rakuten.co.jp/?scid=we_ene_grp_banner)
    
*   [![Rakuten music](https://energy.rakuten.co.jp/img/top/banner/music_165x100.png)](https://books.rakuten.co.jp/music/?scid=wi_ene_special_msc_non_top)
    
*   [![当時情報メディアトウシル楽天スーパーポイントの上手な貯め方](https://energy.rakuten.co.jp/img/top/banner/toshiru_seikaku_165x100.png)](https://media.rakuten-sec.net/articles/-/22413?scid=ex_scr_rsecarticle_201908_TOSHIRU_seikaku)
    
*   [![貯まる裏ワザ大公開ポイント活用術](https://energy.rakuten.co.jp/img/top/banner/toshiru_point_165x100.png)](https://media.rakuten-sec.net/ud/theme_simple/theme_code/point?scid=ex_scr_rsecarticle_201908_TOSHIRU_point)
    
*   [![楽天損保の自転車保険](https://energy.rakuten.co.jp/img/top/banner/sonpo_bicycle_165x100.jpg)](https://www.rakuten-sonpo.co.jp/tabid/997/Default.aspx?ag=elc1)
    
*   [![楽天ママ割](https://energy.rakuten.co.jp/img/top/banner/mamawari_165x100.jpg)](https://event.rakuten.co.jp/family/line/?scid=wi_ene_mmw_line_pc_lps_200413)
    
*   [![Rakutenwallet](https://energy.rakuten.co.jp/img/top/banner/wallet-165_100.png)](https://www.rakuten-wallet.co.jp/point/?scid=wi_ener_top_165_100)
    
*   [![ポイ活から投資までお得な情報がたくさん](https://energy.rakuten.co.jp/img/top/banner/money_165x100.jpeg)](https://www.rakuten-card.co.jp/minna-money/?scid=wi_mny_ene_minna_top_202206)
    
*   [![SPU](https://energy.rakuten.co.jp/img/top/banner/spu_165x100.png)](https://event.rakuten.co.jp/campaign/point-up/everyday/point/challenge/?scid=wi_ich_challenge_energy_electricity_top)
    
*   [![楽天不動産](https://energy.rakuten.co.jp/img/top/banner/realestate_165x100.png)](https://realestate.rakuten.co.jp/contents/lp/2025/newpropertymail/?scid=we_energy_bnr)
    
*   [![楽天家計簿](https://energy.rakuten.co.jp/img/top/banner/kakeibo_entrycampaign_165x100.png)](https://app.adjust.com/1dsni5m5?redirect=https%3A%2F%2Fpersonal-finance.rakuten.co.jp%2Fcampaign%2F%E2%80%A6)
    
*   [![楽天ラクマ](https://energy.rakuten.co.jp/img/top/banner/rakuma_165x100.png)](https://rakuma.rakuten.co.jp/info/campaign/spu/?scid=wi_energy_campaign)
    
*   [![RakutenBEAUTY](https://energy.rakuten.co.jp/img/top/banner/beauty_165x100.png)](https://app.adjust.com/1i7mmj9d?redirect=https://beauty.rakuten.co.jp/cnt/topics/campaign/app2x/?scid=wi_ene_group_App2x)
    
*   [![楽天ぐるなび楽天ポイント進呈最大30,000ポイント](https://energy.rakuten.co.jp/img/top/banner/gnavi_165x100.jpg)](https://r.gnavi.co.jp/plan/campaign/bonus/?sc_cid=cp_rkt_ene_cam251101_01&scid=wi_ene_cam251101_01)
    
*   [![楽天Rebates](https://energy.rakuten.co.jp/img/top/banner/rebates_165x100.png)](https://www.rebates.jp/event/ftb?utm_medium=partner&utm_campaign=202312_rakuten_energy_top&utm_source=web&utm_content=rakutengroup&utm_term=&utm_size=&utm_pub=&utm_ebs=LP&scid=202312_rakuten_energy_top)
    
*   [![楽天Car](https://energy.rakuten.co.jp/img/top/banner/rakuten_car_165x100.jpg)](https://car.rakuten.co.jp/shaken/campaign/prospects/lottery5000p_aug23/?scid=wi_denki_lottery5000p_topgrouplist)
    
*   [![楽天ウェブ検索](https://energy.rakuten.co.jp/img/top/banner/web_search.png)](https://toolbar.rakuten.co.jp/intro/information/members/newcampaign1/?scid=wi_ene_banner)
    
*   [![楽天イーグルス](https://energy.rakuten.co.jp/img/top/banner/eagles_165x100.jpg)](https://www.youtube.com/c/rakuteneagles)
    
*   [![楽天銀行](https://energy.rakuten.co.jp/img/top/banner/bank_165x100.png)](https://www.rakuten-bank.co.jp/account/campaign/payment1000.html?scid=wi_ene_top_1000_internal)
    
*   [![紹介キャンペーン](https://energy.rakuten.co.jp/img/top/banner/tomodachi-portal.jpg)](https://event.rakuten.co.jp/group/invitation/?scid=wi_ene_memd_friendsportal_01)
    
*   [![楽天ファーム](https://energy.rakuten.co.jp/img/top/banner/farm_165x100.png)](https://www.rakuten.co.jp/rakuten-farm/?scid=wi_frm_renergy_frm-ichiba-top)
    
*   [![Rakuten edyshop](https://energy.rakuten.co.jp/img/top/banner/edy_165x100.gif)](https://item.rakuten.co.jp/edyshop/edy-rpoint_panda/)
    
*   [![短期賃貸ならライフルホームズマンスリー](https://energy.rakuten.co.jp/img/top/banner/homes_165x100.jpg)](https://monthly.homes.jp/?utm_source=r_energy&utm_medium=banner&utm_campaign=top)
    
*   [![Rakuten TV](https://energy.rakuten.co.jp/img/top/banner/tv_banner.jpeg)](https://tv.rakuten.co.jp/?scid=we_ene_grp_banner)
    
*   [![Rakuten music](https://energy.rakuten.co.jp/img/top/banner/music_165x100.png)](https://books.rakuten.co.jp/music/?scid=wi_ene_special_msc_non_top)
    
*   [![当時情報メディアトウシル楽天スーパーポイントの上手な貯め方](https://energy.rakuten.co.jp/img/top/banner/toshiru_seikaku_165x100.png)](https://media.rakuten-sec.net/articles/-/22413?scid=ex_scr_rsecarticle_201908_TOSHIRU_seikaku)
    
*   [![貯まる裏ワザ大公開ポイント活用術](https://energy.rakuten.co.jp/img/top/banner/toshiru_point_165x100.png)](https://media.rakuten-sec.net/ud/theme_simple/theme_code/point?scid=ex_scr_rsecarticle_201908_TOSHIRU_point)
    
*   [![楽天損保の自転車保険](https://energy.rakuten.co.jp/img/top/banner/sonpo_bicycle_165x100.jpg)](https://www.rakuten-sonpo.co.jp/tabid/997/Default.aspx?ag=elc1)
    
*   [![楽天ママ割](https://energy.rakuten.co.jp/img/top/banner/mamawari_165x100.jpg)](https://event.rakuten.co.jp/family/line/?scid=wi_ene_mmw_line_pc_lps_200413)
    
*   [![Rakutenwallet](https://energy.rakuten.co.jp/img/top/banner/wallet-165_100.png)](https://www.rakuten-wallet.co.jp/point/?scid=wi_ener_top_165_100)
    
*   [![ポイ活から投資までお得な情報がたくさん](https://energy.rakuten.co.jp/img/top/banner/money_165x100.jpeg)](https://www.rakuten-card.co.jp/minna-money/?scid=wi_mny_ene_minna_top_202206)
    
*   [![SPU](https://energy.rakuten.co.jp/img/top/banner/spu_165x100.png)](https://event.rakuten.co.jp/campaign/point-up/everyday/point/challenge/?scid=wi_ich_challenge_energy_electricity_top)
    

Next

*   1
*   2
*   3
*   4
*   5

1.  [![home](https://energy.rakuten.co.jp/common/img/home_white.svg)](https://energy.rakuten.co.jp/)
    
2.  楽天でんきTOP

[![Rakuten Mobile](https://cdn.rmc.contents.rakuten.co.jp/block/d40535ac09aac0ef32f8a23b8bb8e04bc2e8f9d6b0981fa98a16d0382f558d83/d72cbeb1-1b70-4fb2-b7e5-cb3c0a24841f/card20k_enddate_pc_1440x50.png)](https://cdn.rex.contents.rakuten.co.jp/webcx-redirect-module/1.3.0/index.html?clientId=d40535ac09aac0ef32f8a23b8bb8e04bc2e8f9d6b0981fa98a16d0382f558d83&version=2.73.0&sessionId=0e9928e2-4c3c-4902-b2f4-0f6616dbf3cf&screen=WB&issueId=F01184-001256&campaignId=2aadf4f2-55c7-4337-8472-22f617277367&contentId=4382487a-283f-4306-b0d1-11d8c70206b1&replacementId=81db9e56-ef96-4d72-a17a-b0e4899e9bca&impressionId=4e5e261c-b1ff-4cc4-9428-c14e5dc7312a&selector=mkdiv_footer_pitari&redirect=aHR0cHM6Ly9yZC5yYWt1dGVuLmNvLmpwL3JhdD9SMj1odHRwczovL25ldHdvcmsubW9iaWxlLnJha3V0ZW4uY28uanAvY2FtcGFpZ24vY2FyZC1tb2JpbGUtbWFqaXRva3UvJTNGc2NpZCUzRHdpX2VuZV9ybWJfbWtkaXZfZm9vdGVyX3BpdGFyaV9jbW9fc3BfbmV3LWNhcmQtbm8td2ViY3hfY2FyZC1tb2JpbGUtbWFqaXRva3VfMjAyNTEyMDEmYWNjPTEzMTImYWlkPTEmZXR5cGU9Y2xpY2smc3NjPWNyb3NzdXNlX2NhbXBhaWduJnBnbj1jbW9fcGl0YXJpJnJlZj1odHRwczovL2VuZXJneS5yYWt1dGVuLmNvLmpwL2VsZWN0cmljaXR5LyZ0YXJnZXRfZWxlPW5ldy1jYXJkLW5vLXdlYmN4X2NhcmQtbW9iaWxlLW1haml0b2t1XzIwMjUxMjAx&origin=aHR0cHM6Ly9lbmVyZ3kucmFrdXRlbi5jby5qcA==)

*   *   楽天でんき[楽天でんき](https://energy.rakuten.co.jp/electricity/)
        
        *   楽天でんきTOP
            
            *   [楽天でんきTOP](https://energy.rakuten.co.jp/electricity/?l-id=visitor_per_foot_gnavi_electricity_top)
                
            
        *   料金・お支払い
            
            *   [料金シミュレーション](https://energy.rakuten.co.jp/electricity/LvEasySimulation/?l-id=visitor_per_foot_gnavi_electricity_LvEasySimulation)
                
            *   [電気料金プラン](https://energy.rakuten.co.jp/electricity/fee/?l-id=visitor_per_foot_gnavi_electricity_fee)
                
            *   [お支払い方法](https://energy.rakuten.co.jp/electricity/payment/?l-id=visitor_per_foot_gnavi_electricity_payment)
                
            *   [燃料費調整単価](https://energy.rakuten.co.jp/electricity/fee/fuelcost/?l-id=visitor_per_foot_gnavi_electricity_fuelcost)
                
            *   [市場価格調整単価](https://energy.rakuten.co.jp/electricity/fee/market_linked/?l-id=visitor_per_foot_gnavi_electricity_market_linked)
                
            
        *   おトク
            
            *   [楽天ポイントが貯まる・使える](https://energy.rakuten.co.jp/electricity/merit/?l-id=visitor_per_foot_gnavi_electricity_merit)
                
            *   [キャンペーン](https://energy.rakuten.co.jp/campaign/?l-id=visitor_per_foot_gnavi_electricity_campaign)
                
            
        *   お申し込み
            
            *   [お申し込みの流れ](https://energy.rakuten.co.jp/electricity/flow/?l-id=visitor_per_foot_gnavi_electricity_flow)
                
            *   [お申し込み](https://energy.rakuten.co.jp/electricity/#)
                
            
        *   契約約款・利用規約
            
            *   [契約約款・利用規約一覧](https://energy.rakuten.co.jp/electricity/terms/?l-id=visitor_per_foot_gnavi_electricity_terms)
                
            *   [注意事項](https://energy.rakuten.co.jp/electricity/attention/?l-id=visitor_per_foot_gnavi_electricity_attention)
                
            *   [特定商取引法に基づく表示](https://energy.rakuten.co.jp/electricity/commerce/?l-id=visitor_per_foot_gnavi_electricity_commerce)
                
            
        *   安心・安全・便利
            
            *   [安定した電力供給](https://energy.rakuten.co.jp/electricity/power/?l-id=visitor_per_foot_gnavi_electricity_power)
                
            *   [マイページ機能紹介  \
                （使用量管理）](https://energy.rakuten.co.jp/electricity/mypage/?l-id=visitor_per_foot_gnavi_electricity_mypage)
                
            
        *   お問い合わせ
            
            *   [Q&A・お問い合わせ](https://energy.rakuten.co.jp/faq/)
                
            
        *   ご契約中のお客様
            
            *   [マイページログイン](https://mypage.energy.rakuten.co.jp/contracts/?l-id=visitor_per_foot_gnavi_electricity_mypage_login)
                
            *   [引越し手続き](https://energy.rakuten.co.jp/electricity/#)
                
            *   [停電など非常時のご案内](https://energy.rakuten.co.jp/electricity/if/?l-id=visitor_per_foot_gnavi_electricity_if)
                
            *   [省エネ情報](https://energy.rakuten.co.jp/energy_saving/?l-id=visitor_per_head_gnavi_energy_saving)
                
            *   [節電トライ](https://energy.rakuten.co.jp/electricity/power_saving/?l-id=visitor_per_foot_gnavi_power_saving)
                
            
        
    *   楽天ガス[楽天ガス](https://energy.rakuten.co.jp/electricity/)
        
        *   楽天ガスTOP
            
            *   [楽天ガスTOP](https://energy.rakuten.co.jp/gas/?l-id=visitor_per_foot_gnavi_gas_top)
                
            
        *   料金・お支払い
            
            *   [ガス料金プラン](https://energy.rakuten.co.jp/gas/fee/?l-id=visitor_per_foot_gnavi_gas_fee)
                
            *   [お支払い方法](https://energy.rakuten.co.jp/gas/payment/?l-id=visitor_per_foot_gnavi_gas_payment)
                
            *   [原料費調整単価](https://energy.rakuten.co.jp/gas/fee/materialcost/?l-id=visitor_per_foot_gnavi_gas_materialcost)
                
            
        *   おトク
            
            *   [楽天ポイントが貯まる・使える](https://energy.rakuten.co.jp/gas/merit/?l-id=visitor_per_foot_gnavi_gas_merit)
                
            *   [キャンペーン](https://energy.rakuten.co.jp/campaign/?l-id=visitor_per_foot_gnavi_gas_campaign)
                
            
        *   お申し込み
            
            *   [お申し込みの流れ](https://energy.rakuten.co.jp/gas/flow/?l-id=visitor_per_foot_gnavi_gas_flow)
                
            *   [お申し込み](https://energy.rakuten.co.jp/electricity/#)
                
            
        *   契約約款・利用規約
            
            *   [契約約款・利用規約一覧](https://energy.rakuten.co.jp/gas/terms/?l-id=visitor_per_foot_gnavi_gas_terms)
                
            *   [注意事項](https://energy.rakuten.co.jp/gas/attention/?l-id=visitor_per_foot_gnavi_gas_attention)
                
            *   [特定商取引法に基づく表示](https://energy.rakuten.co.jp/gas/commerce/?l-id=visitor_per_foot_gnavi_gas_commerce)
                
            
        *   対象エリア
            
            *   [対象エリア](https://energy.rakuten.co.jp/gas/area/?l-id=visitor_per_foot_gnavi_gas_area)
                
            
        *   安心・安全・便利
            
            *   [安定したガス供給](https://energy.rakuten.co.jp/gas/supply/?l-id=visitor_per_foot_gnavi_gas_supply)
                
            *   [マイページ機能紹介  \
                （使用量管理）](https://energy.rakuten.co.jp/gas/mypage/?l-id=visitor_per_foot_gnavi_gas_mypage)
                
            
        *   お問い合わせ
            
            *   [Q&A・お問い合わせ](https://energy.rakuten.co.jp/faq/)
                
            
        *   ご契約中のお客様
            
            *   [マイページログイン](https://mypage.energy.rakuten.co.jp/contracts/?l-id=visitor_per_foot_gnavi_gas_login_mypage)
                
            *   [引越し手続き](https://energy.rakuten.co.jp/electricity/#)
                
            *   [ガス漏れなど非常時のご案内](https://energy.rakuten.co.jp/gas/if/?l-id=visitor_per_foot_gnavi_gas_if)
                
            
        
    

*   [楽天エナジー公式 X（旧Twitter）](https://twitter.com/rakuten_energy/)
    
*   [でんき・ガスのコラム](https://energy.rakuten.co.jp/column/?l-id=visitor_foot_sns_gnavi_column)
    

*   [会社概要](https://corp.mobile.rakuten.co.jp/?l-id=visitor_biz_foot_gnavi_corporate)
    
*   [採用情報](https://japan-job-jp.rakuten.careers/%e6%a4%9c%e7%b4%a2%e3%82%b8%e3%83%a7%e3%83%96/%E6%A5%BD%E5%A4%A9%E3%82%A8%E3%83%8A%E3%82%B8%E3%83%BC/31272/1)
    
*   [社会的責任（CSR）](https://corp.rakuten.co.jp/csr/)
    
*   [サイトマップ](https://energy.rakuten.co.jp/sitemap/?l-id=visitor_biz_foot_gnavi_sitemap)
    
*   [個人情報保護方針](https://privacy.rakuten.co.jp/)
    
*   [共同利用プライバシーポリシー](https://energy.rakuten.co.jp/privacypolicy/?l-id=visitor_biz_foot_gnavi_privacypolicy)
    
*   [推奨環境](https://energy.rakuten.co.jp/site/?l-id=visitor_biz_foot_gnavi_site)
    
*   [でんき・ガスのコラム](https://energy.rakuten.co.jp/column/?l-id=visitor_biz_foot_gnavi_column)
    

© Rakuten Mobile, Inc.

[閉じる](https://energy.rakuten.co.jp/electricity/#)

申し込むサービスを  
選択してください。

*   [楽天でんき](https://energy.rakuten.co.jp/electricity/#)
    
*   [楽天ガス](https://energy.rakuten.co.jp/electricity/#)
    

楽天でんきと楽天ガスに合わせてお申し込みをご希望の方は、楽天でんきの申し込み完了後に楽天ガスをお申し込みください。詳しくは[楽天でんきお申し込みの流れ](https://energy.rakuten.co.jp/electricity/flow/?l-id=visitor_per_foot_popup_electricity_flow)
と[楽天ガスお申し込みの流れ](https://energy.rakuten.co.jp/gas/flow/?l-id=visitor_per_foot_popup_gas_flow)
をご確認ください

※楽天ガスは、東京ガスエリア・東邦ガスエリア・関電ガスエリアの方のみお申し込みいただけます。  
詳しくは[対象エリアページ](https://energy.rakuten.co.jp/gas/area/?l-id=visitor_pe_foot_popup_gas_area)
をご確認ください。

[閉じる](https://energy.rakuten.co.jp/electricity/#)

申し込み内容を  
ご選択ください。

*   [現住所を  \
    楽天でんきに切り替える](https://energy.rakuten.co.jp/electricity/application/ConsumerApplication/switch/confirmCard/?l-id=visitor_per_head_popup_apply_denki_sw1)
    
*   [引越し先で  \
    楽天でんきを申し込む](https://energy.rakuten.co.jp/electricity/#)
    

[閉じる](https://energy.rakuten.co.jp/electricity/#)

引越し先で電気のご契約を  
されていますか？

*   [いいえ、まだ電気の契約を  \
    していません  \
    （不明の場合はこちら）](https://energy.rakuten.co.jp/electricity/#)
    
*   [はい、すでに電気の契約を  \
    しています](https://energy.rakuten.co.jp/electricity/application/ConsumerApplication/switch/confirmCard/?l-id=visitor_per_head_popup_apply_denki_sw2)
    

[閉じる](https://energy.rakuten.co.jp/electricity/#)

引越し予定日をご選択ください

引越し予定日が12月10日より前の場合  
引越し当日から楽天でんきを利用する事はできません。一度地域の電力会社でご利用した後、楽天でんきに切替えの手続きをお願いします。

[閉じる](https://energy.rakuten.co.jp/electricity/#)

楽天ガスの  
申し込み方を  
選択してください。

*   [現住所を  \
    楽天ガスに切り替える](https://gas.energy.rakuten.co.jp/singleApplication/switch/confirmCard?l-id=visitor_per_head_popup_apply_gas_new)
    
*   [引越し先で  \
    楽天ガスを申し込む  \
    （東京ガスエリアのみ）](https://energy.rakuten.co.jp/electricity/#)
    

楽天ガスお申し込みの[対象エリア](https://energy.rakuten.co.jp/gas/area/?l-id=visitor_per_head_popup_gas_area)
をご確認ください。

現住所でのお切り替え：東京ガス・東邦ガス・関電ガスエリア  
引越しに伴うお申し込み：東京ガスエリア

※東邦ガス・関電ガスエリアのお客様は、お引越し後、地域のガス会社から楽天ガスへお切り替えください。

[閉じる](https://energy.rakuten.co.jp/electricity/#)

引越し先でガスの  
ご契約をされていますか？

*   [いいえ、まだガスの契約を  \
    していません  \
    （不明の場合はこちら）](https://energy.rakuten.co.jp/electricity/#)
    
*   [はい、すでにガスの契約を  \
    しています](https://gas.energy.rakuten.co.jp/singleApplication/switch/confirmCard?l-id=visitor_per_head_popup_apply_gas_new)
    

[閉じる](https://energy.rakuten.co.jp/electricity/#)

引越し予定日をご選択ください

東京ガスのエリアへ引っ越しのお客様  
選択可能な日付にて、引っ越し日から楽天ガスをご利用可能です。

その他エリアへ引っ越しのお客様  
一度地域のガス会社でご利用した後、楽天ガスへお切替えください。楽天ガスの対象エリアは[こちら](https://energy.rakuten.co.jp/gas/area/?l-id=visitor_per_head_popup_gas_area)

[閉じる](https://energy.rakuten.co.jp/electricity/#)

「楽天でんき」「楽天ガス」解約※1の  
お手続きを選択ください。

*   現住所で他社へのお切り替え  
    楽天エナジーへのお手続き原則不要※2です。  
    他社にお申し込みいただければ  
    自動的に解約されます。
    
*   [お引越し等に伴う現住所の解約※3  \
    現住所で電気を使わないお客様は  \
    こちらよりお手続きください。](https://energy.rakuten.co.jp/electricity/application/ConsumerApplication/move/termination/input)
    

※1 ご利用開始特典の条件を満たす前に解約を行った場合、特典の対象となりません。詳しくは[キャンペーンルール](https://energy.rakuten.co.jp/gas/?l-id=visitor_per_head_gnavi_gas_top#rule_gas)
をご確認ください。（楽天でんきと楽天ガスのキャンペーンルールは同様の条件となります）  
※2 「楽天でんき」では、お切替先の電力会社によって、楽天エナジーへ廃止日のご連絡を求められる場合がございます。その際は、[問い合わせフォーム](https://energy.faq.rakuten.net/CCRM_EnergyAsk?l-id=visitor_per_head_gnavi_energyask)
へお進みください。  
※3 ログインエラー等で解約申し込みができないお客様についてはお電話にてお手続きをお願いいたします。  
楽天エナジーカスタマーセンター TEL : 050-5490-9070（有料）  
受付時間 : 9:30～17:30 月曜日～日曜日(年末年始等の期間は除く)

*   [サービス一覧](https://www.rakuten.co.jp/sitemap/)
    
*   [お問い合わせ一覧](https://www.rakuten.co.jp/sitemap/inquiry.html)
    
*   [サステナビリティ](https://corp.rakuten.co.jp/sustainability/)
    
*   [カスタマーハラスメントポリシー](https://corp.rakuten.co.jp/sustainability/human-rights/customer-harassment/)
    

© Rakuten Group, Inc.
