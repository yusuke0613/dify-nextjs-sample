# Products (iPhone, Android / Smartphone) | Rakuten Mobile

URL: https://network.mobile.rakuten.co.jp/product/

---

![](https://secure.rat.rakuten.co.jp/?cpkg_none=%7B%22acc%22%3A1312%2C%22aid%22%3A1%2C%22bid%22%3A%2217648966155025100dd45%22%2C%22url%22%3A%22https%3A%2F%2Fnetwork.mobile.rakuten.co.jp%2Fproduct%2F%22%2C%22ua%22%3A%22Mozilla%2F5.0%20(iPhone%3B%20CPU%20iPhone%20OS%2018_6_2%20like%20Mac%20OS%20X)%20AppleWebKit%2F605.1.15%20(KHTML%2C%20like%20Gecko)%20Version%2F18.6%20Mobile%2F15E148%20Safari%2F604.1%22%2C%22etype%22%3A%22async%22%2C%22phoenix_pattern%22%3A%22network.mobile.rakuten.co.jp%7C%2Fproduct%2F%7Cmnoprj_product_top_carousel_202510_responsive%7Cdefault%22%2C%22cp%22%3A%7B%22phxcampaign%22%3A%22mnoprj_product_top_carousel_202510_responsive%22%2C%22phxexperiment%22%3A25979%2C%22phxpattern%22%3A%22default%22%2C%22phxbanditpattern%22%3A%22default%22%2C%22phxversion%22%3A%223.2.2%22%2C%22phxcmpruntime%22%3A0.002%2C%22phxapiresptime%22%3A0.001%2C%22phxpatternloadtime%22%3A0%7D%7D)

*   Individual customers
*   [Business customers](https://business.mobile.rakuten.co.jp/?scid=wi_rmb_pers_header)
    
*   Language
    
    *   日本語
    *   English
    *   简体中文
    *   繁體中文
    *   한국어
    *   tiếng việt
    *   Indonesia
    *   português
    

Choose your language for Rakuten Mobile !
-----------------------------------------

Our services are provided within the region and laws of Japan.

日本語English简体中文繁體中文한국어tiếng việtIndonesiaportuguês

Select Language

Our services are provided within the region and laws of Japan and we provide translations for your convenience.  
The Japanese version of our websites and applications, in which include Rakuten Membership Rules, Privacy Policy or other terms and conditions, is the definitive version , unless otherwise indicated.  
If there are any discrepancies, the Japanese version shall prevail.  
We do not guarantee that we always provide translation.  
The Japanese versions of all terms and conditions, policies, and other notices are the definitive versions. Any dispute related to the terms and conditions, policies, or other notices will be under the jurisdiction of Japanese law, regardless of any conflicting laws or principles.  
Certain features or messages (including customer services) may not be available in the selected language.

[Rakuten Mobile](https://network.mobile.rakuten.co.jp/?wovn=en&l-id=gnavi_logo_b)

[![Thanks to you, we have 9.5 million lines.](https://network.mobile.rakuten.co.jp/assets/en/img/common/logo-thankyou-950-magenta.svg)](https://network.mobile.rakuten.co.jp/feature/why-rakuten-mobile/?wovn=en&l-id=gnavi_banner_why-rakuten-mobile_b)

*   Plans &   
    Devices
    
    Smartphone
    
    *   [Rakuten SAIKYO Plan](https://network.mobile.rakuten.co.jp/fee/saikyo-plan/?wovn=en&l-id=gnavi_fee_saikyo-plan_b)
        *   [Data type](https://network.mobile.rakuten.co.jp/fee/saikyo-plan/data-type/?wovn=en&l-id=gnavi_fee_saikyo-plan_data-type_b)
            
    *   [![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-unext.svg)Rakuten SAIKYO U-NEXT](https://network.mobile.rakuten.co.jp/fee/unext/?wovn=en&l-id=gnavi_fee_unext_b)
        
        ![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-reduction.svg)Discount program
        
        *   [SAIKYO FAMILY Discount\
            \
            For Those Who Want to Save More as a Family](https://network.mobile.rakuten.co.jp/fee/family/?wovn=en&l-id=gnavi_fee_family_b)
            
        *   [SAIKYO KIDS Discount\
            \
            Super savings for kids Up to age 12!](https://network.mobile.rakuten.co.jp/fee/kids/?wovn=en&l-id=gnavi_fee_kids_b)
            
        *   [SAIKYO YOUTH Discount\
            \
            Always a great deal Up to age 22](https://network.mobile.rakuten.co.jp/fee/youth/?wovn=en&l-id=gnavi_fee_youth_b)
            
        *   [SAIKYO SENIOR Program\
            \
            From age 65  \
            Always safe & good value](https://network.mobile.rakuten.co.jp/fee/senior/?wovn=en&l-id=gnavi_fee_senior_b)
            
        
    
    *   [![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-fee-simulation.svg)Price simulation](https://network.mobile.rakuten.co.jp/fee/simulation/?wovn=en&l-id=gnavi_fee_un-limit_simulation_b)
        
    *   [Device](https://network.mobile.rakuten.co.jp/product/?wovn=en&l-id=gnavi_product_b)
        *   [iPhone](https://network.mobile.rakuten.co.jp/product/iphone/?wovn=en&l-id=gnavi_product_iphone_b)
            
        *   [Apple Watch](https://network.mobile.rakuten.co.jp/product/apple-watch/?wovn=en&l-id=gnavi_product_apple-watch_b)
            
        *   [Android](https://network.mobile.rakuten.co.jp/product/smartphone/?wovn=en&l-id=gnavi_product_smartphone_b)
            
        *   [Wi-Fi router](https://network.mobile.rakuten.co.jp/product/internet/?wovn=en&l-id=gnavi_product_internet_b)
            
        *   [Accessories](https://network.mobile.rakuten.co.jp/product/accessory/?wovn=en&l-id=gnavi_product_accessory_b)
            
        *   [Other Recommended Products](https://network.mobile.rakuten.co.jp/product/ichiba-recommended/?wovn=en&l-id=gnavi_product_ichiba-recommended_b)
            
    *   [Option services](https://network.mobile.rakuten.co.jp/service/?wovn=en&l-id=gnavi_service_b)
        
    
    *   [![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-sim.svg)SIM](https://network.mobile.rakuten.co.jp/product/sim/?wovn=en&l-id=gnavi_product_sim_b)
        *   [eSIM](https://network.mobile.rakuten.co.jp/product/sim/esim/?wovn=en&l-id=gnavi_product_sim_esim_b)
            
        *   [Dual SIM](https://network.mobile.rakuten.co.jp/product/sim/dual-sim/?wovn=en&l-id=gnavi_product_sim_dual-sim_b)
            
        *   [Check device compatibility](https://network.mobile.rakuten.co.jp/product/byod/?wovn=en&l-id=gnavi_product_byod_b)
            
    
    Internet and electricity
    
    *   [Rakuten Turbo](https://network.mobile.rakuten.co.jp/internet/turbo/?wovn=en&l-id=gnavi_internet_turbo_b)
        *   [Price plan](https://network.mobile.rakuten.co.jp/internet/turbo/fee/?wovn=en&l-id=gnavi_internet_turbo_fee_b)
            
    
    *   [Rakuten Hikari](https://network.mobile.rakuten.co.jp/hikari/?wovn=en&l-id=gnavi_hikari_b)
        *   [Price plan](https://network.mobile.rakuten.co.jp/hikari/fee/pricelist/?wovn=en&l-id=gnavi_hikari_fee_b)
            
    
    *   [![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-energy.svg)Rakuten Denki](https://energy.rakuten.co.jp/electricity/?scid=wi_rmb_gnavi_top)
        *   [Price plan](https://energy.rakuten.co.jp/electricity/fee/?scid=wi_rmb_gnavi_plan)
            
    
    Great deals when you combine with a smartphone!
    
    *   [![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-saikyo-program.svg)SAIKYO HOME Program](https://network.mobile.rakuten.co.jp/campaign/home-internet/?wovn=en&l-id=gnavi_campaign_home-internet_b)
        *   [Smartphone + Rakuten Turbo\
            \
            Sign up for Rakuten Turbo for the first time and get 1,000 point rebates every month](https://network.mobile.rakuten.co.jp/internet/turbo/campaign/home-internet/?wovn=en&l-id=gnavi_internet_turbo_campaign_home-internet_b)
            
        *   [Smartphone + Rakuten Hikari\
            \
            Receive 1,000 point rebates every month when you sign up for Rakuten Hikari for the first time](https://network.mobile.rakuten.co.jp/hikari/campaign/home-internet/?wovn=en&l-id=gnavi_hikari_campaign_home-internet_b)
            
    
*   Coverage &   
    Shops
    
    Coverage Area
    
    *   [Smartphone](https://network.mobile.rakuten.co.jp/area/?wovn=en&l-id=gnavi_area_b)
        
    *   [Rakuten Turbo](https://network.mobile.rakuten.co.jp/internet/turbo/area/?wovn=en&l-id=gnavi_internet_turbo_area_b)
        
    
    For customers visiting our shops
    
    *   [Shop (Retail store)](https://network.mobile.rakuten.co.jp/shop/?wovn=en&l-id=gnavi_shop_b)
        
    
*   Campaigns
    
    Campaign
    
    *   [Smartphone](https://network.mobile.rakuten.co.jp/campaign/?wovn=en&l-id=gnavi_campaign_b)
        
    *   [Rakuten Turbo](https://network.mobile.rakuten.co.jp/internet/turbo/campaign/home-internet/?wovn=en&l-id=gnavi_internet_turbo_campaign_home-internet_b)
        
    *   [Rakuten Hikari](https://network.mobile.rakuten.co.jp/hikari/campaign/home-internet/?wovn=en&l-id=gnavi_hikari_campaign_home-internet_b)
        
    *   [![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-energy.svg)Rakuten Denki](https://energy.rakuten.co.jp/campaign/lp/mobilelink/?scid=wi_rmb_gnavi_cpn)
        
    
*   News &   
    Support
    
    News & Other
    
    *   [News](https://network.mobile.rakuten.co.jp/information/?wovn=en&l-id=gnavi_info_b)
        *   [Super Hodai / Combination Plan  \
            Current users](https://mobile.rakuten.co.jp/mvno/?l-id=gnavi_mvno_b)
            
    
    Those Considering Switching
    
    *   [![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-new-user.svg)Application Guide](https://network.mobile.rakuten.co.jp/guide/procedure/?wovn=en&l-id=gnavi_guide_procedure_b)
        
    *   [Why Choose Rakuten Mobile Now?](https://network.mobile.rakuten.co.jp/feature/why-rakuten-mobile/?wovn=en&l-id=gnavi_feature_why-rakuten-mobile_b)
        
    *   [Customer Reviews](https://network.mobile.rakuten.co.jp/uservoice/?wovn=en&l-id=gnavi_uservoice_b)
        
    *   [Learn smartphone tips](https://network.mobile.rakuten.co.jp/sumakatsu/?l-id=gnavi_sumakatsu_b)
        
    
    Customer Support
    
    *   [Rakuten Mobile](https://network.mobile.rakuten.co.jp/support/?wovn=en&l-id=gnavi_support_b)
        
    *   [Rakuten Turbo](https://network.mobile.rakuten.co.jp/internet/turbo/support/?wovn=en&l-id=gnavi_internet_turbo_support_b)
        
    *   [Rakuten Hikari](https://network.mobile.rakuten.co.jp/hikari/support/?wovn=en&l-id=gnavi_hikari_support_b)
        
    *   [![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-energy.svg)Rakuten Denki](https://energy.rakuten.co.jp/faq/?scid=wi_rmb_gnavi_qa)
        
    

Menu

Search

[my Rakuten Mobile](https://portal.mobile.rakuten.co.jp/my-rakuten-mobile?l-id=network_gnavi_ecare_b)

[Apply Now](https://network.mobile.rakuten.co.jp/guide/application/?wovn=en&ref=header&lid-r=gnavi_onboarding_b)

[Apply Now](https://network.mobile.rakuten.co.jp/guide/application/?wovn=en&ref=header&lid-r=burger_onboarding_b)
​ ​[my Rakuten Mobile](https://portal.mobile.rakuten.co.jp/my-rakuten-mobile?l-id=network_burger_ecare_b)

*   Those Considering Switching
    
*   price plan and Products
    
*   Coverage Area
    
*   [Shop (Retail store)](https://network.mobile.rakuten.co.jp/shop/?wovn=en&l-id=burger_shop_b)
    
*   Campaigns
    
*   [News](https://network.mobile.rakuten.co.jp/information/?wovn=en&l-id=burger_info_b)
    
*   Customer Support
    

Language

English

*   日本語
*   English
*   简体中文
*   繁體中文
*   한국어
*   tiếng việt
*   Indonesia
*   português

[For users of Super Hodai / Combination Plan](https://mobile.rakuten.co.jp/mvno/?l-id=burger_mvno_b)

[Business customers](https://business.mobile.rakuten.co.jp/?scid=wi_rmb_pers_burger)

price plan and Products

Smartphone

*   Price plan
    
*   [![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-fee-simulation.svg)Price simulation](https://network.mobile.rakuten.co.jp/fee/simulation/?wovn=en&l-id=burger_fee_un-limit_simulation_b)
    
*   [Option services](https://network.mobile.rakuten.co.jp/service/?wovn=en&l-id=burger_service_b)
    
*   Device
    
*   ![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-sim.svg)SIM
    

Don’t miss out on our great discount and cashback programs!

[![SAIKYO FAMILY Discount](https://network.mobile.rakuten.co.jp/assets/en/img/common/img-family-251118.png)](https://network.mobile.rakuten.co.jp/fee/family/?wovn=en&l-id=burger_banner_fee-family_b)

[![SAIKYO KIDS Discount](https://network.mobile.rakuten.co.jp/assets/en/img/common/img-kids-251118.png)](https://network.mobile.rakuten.co.jp/fee/kids/?wovn=en&l-id=burger_banner_fee-kids_b)

[![SAIKYO YOUTH Discount](https://network.mobile.rakuten.co.jp/assets/en/img/common/img-youth-251118.png)](https://network.mobile.rakuten.co.jp/fee/youth/?wovn=en&l-id=burger_banner_fee-youth_b)

[![SAIKYO SENIOR Program](https://network.mobile.rakuten.co.jp/assets/en/img/common/img-senior-251118.png)](https://network.mobile.rakuten.co.jp/fee/senior/?wovn=en&l-id=burger_banner_fee_senior_b)

Internet and electricity

*   Rakuten Turbo
    
*   Rakuten Hikari
    
*   ![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-energy.svg)Rakuten Denki
    

Great deals when you combine with a smartphone!

*   ![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-saikyo-program.svg)SAIKYO HOME Program
    

Price plan

Price plan

*   [Rakuten SAIKYO Plan\
    \
    A simple and easy-to-use plan.](https://network.mobile.rakuten.co.jp/fee/saikyo-plan/?wovn=en&l-id=burger_fee_saikyo-plan_b)
    
*   [Rakuten SAIKYO Plan Data Type\
    \
    For those who only need data communication](https://network.mobile.rakuten.co.jp/fee/saikyo-plan/data-type/?wovn=en&l-id=burger_fee_saikyo-plan_data-type_b)
    
*   [Rakuten SAIKYO U-NEXT\
    \
    For those who want to enjoy videos and magazines](https://network.mobile.rakuten.co.jp/fee/unext/?wovn=en&l-id=burger_fee_unext_b)
    

Discount program

*   [SAIKYO FAMILY Discount\
    \
    For Those Who Want to Save More as a Family](https://network.mobile.rakuten.co.jp/fee/family/?wovn=en&l-id=burger_fee_family_b)
    
*   [SAIKYO KIDS Discount\
    \
    Super savings for kids Up to age 12!](https://network.mobile.rakuten.co.jp/fee/kids/?wovn=en&l-id=burger_fee_kids_b)
    
*   [SAIKYO YOUTH Discount\
    \
    Always a great deal Up to age 22](https://network.mobile.rakuten.co.jp/fee/youth/?wovn=en&l-id=burger_fee_youth_b)
    
*   [SAIKYO SENIOR Program\
    \
    From age 65: Enjoy peace of mind and great savings!](https://network.mobile.rakuten.co.jp/fee/senior/?wovn=en&l-id=burger_fee_senior_b)
    

Device

*   [device Top](https://network.mobile.rakuten.co.jp/product/?wovn=en&l-id=burger_product_b)
    
*   [iPhone](https://network.mobile.rakuten.co.jp/product/iphone/?wovn=en&l-id=burger_product_iphone_b)
    
*   [Apple Watch](https://network.mobile.rakuten.co.jp/product/apple-watch/?wovn=en&l-id=burger_product_apple-watch_b)
    
*   [Android](https://network.mobile.rakuten.co.jp/product/smartphone/?wovn=en&l-id=burger_product_smartphone_b)
    
*   [Wi-Fi router](https://network.mobile.rakuten.co.jp/product/internet/?wovn=en&l-id=burger_product_internet_b)
    
*   [Accessories](https://network.mobile.rakuten.co.jp/product/accessory/?wovn=en&l-id=burger_product_accessory_b)
    
*   [Other Recommended Products](https://network.mobile.rakuten.co.jp/product/ichiba-recommended/?wovn=en&l-id=burger_product_ichiba-recommended_b)
    

![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-sim.svg)SIM

*   [SIM](https://network.mobile.rakuten.co.jp/product/sim/?wovn=en&l-id=burger_product_sim_b)
    
*   [eSIM](https://network.mobile.rakuten.co.jp/product/sim/esim/?wovn=en&l-id=burger_product_sim_esim_b)
    
*   [Dual SIM](https://network.mobile.rakuten.co.jp/product/sim/dual-sim/?wovn=en&l-id=burger_product_sim_dual-sim_b)
    
*   [Check device compatibility](https://network.mobile.rakuten.co.jp/product/byod/?wovn=en&l-id=burger_product_byod_b)
    

Rakuten Turbo

*   [Top](https://network.mobile.rakuten.co.jp/internet/turbo/?wovn=en&l-id=burger_internet_turbo_b)
    
*   [Price plan](https://network.mobile.rakuten.co.jp/internet/turbo/fee/?wovn=en&l-id=burger_internet_turbo_fee_b)
    

Rakuten Hikari

*   [Top](https://network.mobile.rakuten.co.jp/hikari/?wovn=en&l-id=burger_hikari_b)
    
*   [Price plan](https://network.mobile.rakuten.co.jp/hikari/fee/pricelist/?wovn=en&l-id=burger_hikari_fee_b)
    

Coverage Area

*   [Smartphone](https://network.mobile.rakuten.co.jp/area/?wovn=en&l-id=burger_area_b)
    
*   [Rakuten Turbo](https://network.mobile.rakuten.co.jp/internet/turbo/area/?wovn=en&l-id=burger_internet_turbo_area_b)
    

Campaign

*   [Smartphone](https://network.mobile.rakuten.co.jp/campaign/?wovn=en&l-id=burger_campaign_b)
    
*   [Rakuten Turbo](https://network.mobile.rakuten.co.jp/internet/turbo/campaign/home-internet/?wovn=en&l-id=burger_internet_turbo_campaign_home-internet_b)
    
*   [Rakuten Hikari](https://network.mobile.rakuten.co.jp/hikari/campaign/home-internet/?wovn=en&l-id=burger_hikari_campaign_home-internet_b)
    
*   [Rakuten Denki](https://energy.rakuten.co.jp/campaign/lp/mobilelink/?scid=wi_rmb_gnavi_cpn)
    

Those Considering Switching

*   [Application Guide](https://network.mobile.rakuten.co.jp/guide/procedure/?wovn=en&l-id=burger_guide_procedure_b)
    
*   [Why Choose Rakuten Mobile Now?](https://network.mobile.rakuten.co.jp/feature/why-rakuten-mobile/?wovn=en&l-id=burger_feature_why-rakuten-mobile_b)
    
*   [Customer Reviews](https://network.mobile.rakuten.co.jp/uservoice/?wovn=en&l-id=burger_uservoice_b)
    
*   [Learn smartphone tips and tricks.](https://network.mobile.rakuten.co.jp/sumakatsu/?l-id=burger_sumakatsu_b)
    

Customer Support

*   [Rakuten Mobile](https://network.mobile.rakuten.co.jp/support/?wovn=en&l-id=burger_support_b)
    
*   [Rakuten Turbo](https://network.mobile.rakuten.co.jp/internet/turbo/support/?wovn=en&l-id=burger_internet_turbo_support_b)
    
*   [Rakuten Hikari](https://network.mobile.rakuten.co.jp/hikari/support/?wovn=en&l-id=burger_hikari_support_b)
    
*   [Rakuten Denki](https://energy.rakuten.co.jp/faq/?scid=wi_rmb_gnavi_qa)
    

![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-energy.svg)Rakuten Denki

*   [Top](https://energy.rakuten.co.jp/electricity/?scid=wi_rmb_gnavi_top)
    
*   [Price plan](https://energy.rakuten.co.jp/electricity/fee/?scid=wi_rmb_gnavi_plan)
    

![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-saikyo-program.svg)SAIKYO HOME Program

*   [Top](https://network.mobile.rakuten.co.jp/campaign/home-internet/?wovn=en&l-id=burger_campaign_home-internet_b)
    
*   [Smartphone + Rakuten Turbo\
    \
    Sign up for Rakuten Turbo for the first time and get 1,000 point rebates every month](https://network.mobile.rakuten.co.jp/internet/turbo/campaign/home-internet/?wovn=en&l-id=burger_internet_turbo_campaign_home-internet_b)
    
*   [Smartphone + Rakuten Hikari\
    \
    Receive 1,000 point rebates every month when you sign up for Rakuten Hikari for the first time](https://network.mobile.rakuten.co.jp/hikari/campaign/home-internet/?wovn=en&l-id=burger_hikari_campaign_home-internet_b)
    

*   [Top](https://network.mobile.rakuten.co.jp/?wovn=en)
    
*   Device (iPhone, Android/ Smartphone)

※All amounts listed are incl. tax.

Device
======

[![Get the latest iPhone 17 Pro with Rakuten Mobile. The lowest price among all carriers.※As of September 16, 2025.](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-iphone-17-pro-1032-300-250919.png)](https://network.mobile.rakuten.co.jp/product/iphone/iphone-17-pro/?wovn=en&l-id=product_carousel_product_iphone_iphone-17-pro)
[![Apply for Rakuten Mobile + Switch from another carrier (keeping your number) + Purchase a qualifying device = 1 yen!](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-android-discount-1032-300-251202.png)](https://network.mobile.rakuten.co.jp/campaign/android-discount/?wovn=en&l-id=product_carousel_campaign_android-discount)
[![Get the latest iPhone 17 with Rakuten Mobile. The lowest price among all carriers.※As of September 16, 2025.](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-iphone-17-1032-300-250919.png)](https://network.mobile.rakuten.co.jp/product/iphone/iphone-17/?wovn=en&l-id=product_carousel_product_iphone_iphone-17)
[![Get a great deal on iPhone 16e (128GB)! Switch from another carrier and pay with Rakuten Card in 48 installments for just 1 yen/mo. (1-24 months: 1 yen; 25th month onward: 4,365 yen/mo.)](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-iphone-point-iphone-16e-1032-300-251128.png)](https://network.mobile.rakuten.co.jp/campaign/iphone-point-iphone-16e/?wovn=en&l-id=product_carousel_campaign_iphone-point-iphone-16e)
[![【Entry required】Get up to 21,000 points! Switch to Rakuten Mobile and trade in your iPhone 17 or iPhone 17 Pro. Buy a new iPhone, apply for Rakuten Mobile, switch from another carrier, and trade in your iPhone.](https://network.mobile.rakuten.co.jp/assets/img/bnr/iphone-point-iphone-17-1032-300-250912.png)](https://network.mobile.rakuten.co.jp/campaign/iphone-point-iphone-17/?wovn=en&l-id=product_carousel_campaign_iphone-point-iphone-17)
[![楽天モバイル申し込み＋他社から電話番号そのまま乗り換え＋nubia S2Rご購入で1円](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-nubia-s2r-1032-300-251202.png)](https://network.mobile.rakuten.co.jp/product/smartphone/nubia-s2r/?wovn=en&l-id=product_carousel_product_smartphone_nubia-s2r)
[![【要エントリー】楽天モバイルへ初めてお申し込み＋他社から電話番号そのまま乗り換え＋OPPO A5 5Gご購入で最大16,000ポイント還元!](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-a5-5g-1032-300.png)](https://network.mobile.rakuten.co.jp/product/smartphone/a5-5g/?wovn=en&l-id=product_carousel_product_smartphone_a5-5g)
[![[Entry required] Apply for Rakuten Mobile for the first time + switch from another carrier (keeping the same number) + purchase arrows Alpha to get up to ¥26,000 in point rebates!](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-arrows-alpha-1032-300-251121.png)](https://network.mobile.rakuten.co.jp/product/smartphone/arrows-alpha/?wovn=en&l-id=product_carousel_product_smartphone_arrows-alpha)
[![Google Pixel 9a Just !Kaikae Chotoku Program 48 installments from 750 yen/mo. ~](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-product-smartphone-google-pixel-9a-1032-300-251201.png)](https://network.mobile.rakuten.co.jp/product/smartphone/google-pixel-9a/?wovn=en&l-id=product_carousel_product_smartphone_google-pixel-9a)
[![Get the latest iPhone Air with Rakuten Mobile. The lowest price among all carriers.※As of September 16, 2025.](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-iphone-air-1032-300-250919.png)](https://network.mobile.rakuten.co.jp/product/iphone/iphone-air/?wovn=en&l-id=product_carousel_product_iphone_iphone-air)
[![Rakuten WiFi Pocket Platinum for 1 yen with Rakuten Mobile subscription!](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-rakuten-wifi-pocket-platinum-1032-300-250930.png)](https://network.mobile.rakuten.co.jp/product/internet/rakuten-wifi-pocket-platinum/?wovn=en&l-id=product_carousel_product_internet_rakuten-wifi-pocket-platinum)
[![When you buy a qualifying iPhone or Android through the Rakuten Mobile Kaikae Chotoku Program, you'll be exempt from paying up to 24 of the 48 monthly installments.](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-replacement-program-1032-300-251128.png)](https://network.mobile.rakuten.co.jp/service/replacement-program/?wovn=en&l-id=product_carousel_service_replacement-program)
[![iPhone 16, now even more affordable. Get the best deal on Rakuten Mobile!](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-iphone-16-1032-300-250912.png)](https://network.mobile.rakuten.co.jp/product/iphone/iphone-16/?wovn=en&l-id=product_carousel_product_iphone_iphone-16)
[![[Entry required] iPhone 16 and iPhone 16 Pro Eligible! Purchase an eligible iPhone in full or 24 installments, apply for Rakuten Mobile for the first time, and switch from another carrier while keeping your number to get up to ¥36,000 worth of rewards!](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-iphone-pointback-1032-300-251017.png)](https://network.mobile.rakuten.co.jp/campaign/iphone-pointback/?wovn=en&l-id=product_carousel_campaign_iphone-pointback)
[![We have renewed Smartphone Trade-in Service appraisal criteria! Even scratches and defects are appraised at a high price! You can also trade in products purchased from other companies. No handling fees or shipping fees. Just the device is OK! No box or accessories required. Right now, in addition to the trade-in amount, you can also get 5,000 point rebates when you buy iPhone or trade in iPhone! *There are certain conditions for trade-ins.](https://network.mobile.rakuten.co.jp/assets/img/bnr/service-tradein-iphone-1032-300-250912.png)](https://network.mobile.rakuten.co.jp/service/tradein/?wovn=en&l-id=product_carousel_service_tradein)
[![Popular smartphone ranking Check out the best-selling models!](https://network.mobile.rakuten.co.jp/assets/img/bnr/popular-1032-300.png)](https://network.mobile.rakuten.co.jp/product/ranking/?wovn=en&l-id=product_carousel_smartphone_ranking)
[![Apple Watch Series 11 The gift that speaks to the heart. Apple Watch.](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-apple-watch-series11-1032-300-251126.png)](https://network.mobile.rakuten.co.jp/product/apple-watch/apple-watch-series11/?wovn=en&l-id=product_carousel_product_apple-watch_apple-watch-series11)
[![AirPods Pro 3 Now Available at Rakuten Mobile](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-airpods-pro-3-led-1032-300-250919.png)](https://network.mobile.rakuten.co.jp/product/accessory/apple/?wovn=en&l-id=product_carousel_product_accessory_apple#audio)
[![Get ¥22,000 off with Rakuten Mobile signup, number transfer from another carrier, and eligible product purchase!](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-android-sale-1032-300-250801.png)](https://network.mobile.rakuten.co.jp/campaign/android-sale/?wovn=en&l-id=product_carousel_campaign_android-sale)
[![Purchase iPhone 15 or iPhone 15 Pro in one lump sum or 24 installments, apply for Rakuten Mobile for the first time, and switch from another company while keeping your phone number and save up to 40,000 yen!](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-iphone-point-iphone-15-1032-300-250701.png)](https://network.mobile.rakuten.co.jp/campaign/iphone-point-iphone-15/?wovn=en&l-id=product_carousel_campaign_iphone-point-iphone-15)
[![[Entry required] Buy a qualifying iPhone in one go or in 24 installments, apply for Rakuten Mobile for the first time, and switch from another carrier while keeping your number to get up to ¥36,000 in rewards!](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-iphone-point-1032-300-250425.png)](https://network.mobile.rakuten.co.jp/campaign/iphone-point/?wovn=en&l-id=product_carousel_campaign_iphone-point)
[![Purchase OPPO Reno11 A or Phone (3a) 256GB, sign up for Rakuten Mobile, and switch from another company while keeping your phone number to get 20,000 point rebates!](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-android-point-1032-300-250801.png)](https://network.mobile.rakuten.co.jp/campaign/android-point/?wovn=en&l-id=product_carousel_campaign_android-point)
[![[Entry required] Apply for Rakuten Mobile for the first time, switch from another carrier, and purchase an eligible product to point rebates! Plus, get an additional 10,000 points with arrows Alpha! Even if you're not switching from another carrier, point rebates.](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-campaign-start-point-1032-300-251128.png)](https://network.mobile.rakuten.co.jp/campaign/start-point/?wovn=en&l-id=product_carousel_campaign_start-point)
[![Get the latest Apple Watch SE 3 with Rakuten Mobile. The lowest price among all carriers.※As of September 12, 2025.](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-apple-watch-se-3-1032-300-250919.png)](https://network.mobile.rakuten.co.jp/product/apple-watch/apple-watch-se-3/?wovn=en&l-id=product_carousel_product_apple-watch_apple-watch-se-3)
[![Get the latest Apple Watch Ultra 3 with Rakuten Mobile. The lowest price among all carriers.※As of September 12, 2025.](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-apple-watch-ultra-3-1032-300-250919.png)](https://network.mobile.rakuten.co.jp/product/apple-watch/apple-watch-ultra-3/?wovn=en&l-id=product_carousel_product_apple-watch_apple-watch-ultra-3)
[![[Entry required] Web exclusive! Purchase an Apple Watch + join Phone Number Sharing Service (¥550/month) to get up to 25,000 Points!](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-number-share-1032-300-250801.png)](https://network.mobile.rakuten.co.jp/campaign/apple-watch-number-share/?wovn=en&l-id=product_carousel_campaign_apple-watch-number-share)
[![More Flexible Purchase Options All accessories now eligible for installment payment! Whether with a smartphone or just accessories, installment payment is available!](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-product-split-1032-300_220916.png)](https://network.mobile.rakuten.co.jp/product/accessory/?wovn=en&l-id=product_carousel_product_accessory)
[![Get Great Deals on Rakuten Ichiba! Recommended Products for Rakuten Mobile Users](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-ichiba-recommended-1032-300-250908.png)](https://network.mobile.rakuten.co.jp/product/ichiba-recommended/?wovn=en&l-id=product_carousel_product_ichiba-recommended)
[![【Rakuten Certified Used】High-quality and affordable reconditioned smartphones, carefully selected by Rakuten Mobile, are now available at the official Rakuten Mobile Rakuten Ichiba store.](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-rakuten-certified-1032-300.png)](https://www.rakuten.ne.jp/gold/rakutenmobile-store/product/rakuten-certified/?scid=product_carousel_ichiba_rakuten-certified)

PreviousNext

012345678910111213141516171819202122232425262728

![Notification icon](https://network.mobile.rakuten.co.jp/assets/img/common/icon-speaker.svg)

### What's New

*   NEW From December 2, 2025
    
    [Introducing the nubia S2R! Special campaign now on!](https://network.mobile.rakuten.co.jp/product/smartphone/nubia-s2r/?wovn=en&l-id=product_product_smartphone_nubia-s2r_featured)
    
*   NEW From November 28, 2025
    
    [Introducing the OPPO A5 5G! Check out our campaign!](https://network.mobile.rakuten.co.jp/product/smartphone/a5-5g/?wovn=en&l-id=product_product_smartphone_a5-5g_featured)
    
*   *   Price cut From Nov 28, 2025
        
        [Phone (3a) is now an even better deal with a price reduction!](https://network.mobile.rakuten.co.jp/product/smartphone/phone-3a/?wovn=en&l-id=product_product_smartphone_phone-3a_featured)
        
    *   NEW From November 28, 2025
        
        [Switching from Another Carrier to iPhone 16e is a Great Deal!](https://network.mobile.rakuten.co.jp/product/iphone/iphone-16e/?wovn=en&l-id=product_iphone_product_iphone_iphone-16e_featured)
        
    *   NEW From November 21, 2025
        
        [Introducing the all-new arrows Alpha! Join the campaign now!](https://network.mobile.rakuten.co.jp/product/smartphone/arrows-alpha/?wovn=en&l-id=product_product_smartphone_arrows-alpha_featured)
        
    *   NEW From November 20, 2025
        
        [Introducing the Samsung Galaxy A25 5G! Check out our campaign!](https://network.mobile.rakuten.co.jp/product/smartphone/galaxy-a25-5g/?wovn=en&l-id=product_product_smartphone_galaxy-a25-5g_featured)
        
    *   NEW From October 31, 2025
        
        [Introducing the all-new AQUOS sense10! Join our exciting campaign now!](https://network.mobile.rakuten.co.jp/product/smartphone/aquos-sense10/?wovn=en&l-id=product_product_smartphone_aquos-sense10_featured)
        
    *   NEW From October 24, 2025
        
        [Switch from another carrier to get a great deal on Google Pixel 9a!](https://network.mobile.rakuten.co.jp/product/smartphone/google-pixel-9a/?wovn=en&l-id=product_product_smartphone_google-pixel-9a_featured)
        
    
    See More

*   [Device List![Device List](https://network.mobile.rakuten.co.jp/assets/img/product/top/nav-icon-products.png)](https://network.mobile.rakuten.co.jp/product/#products)
    
*   [Ranking![Ranking](https://network.mobile.rakuten.co.jp/assets/img/product/top/nav-icon-ranking.png)](https://network.mobile.rakuten.co.jp/product/#ranking)
    
*   [Campaign Information![Campaigns](https://network.mobile.rakuten.co.jp/assets/img/product/top/nav-icon-cpn.png)](https://network.mobile.rakuten.co.jp/product/#campaign)
    

### Recommended devices

Entry is required to earn some points.  
Please check each[Campaign page](https://network.mobile.rakuten.co.jp/product/#campaign)
​

[New release on December 4\
\
![nubia S2R](https://network.mobile.rakuten.co.jp/assets/img/product/nubia-s2r/rank-thumb.png?251202)\
\
#### nubia S2R\
\
Device Price\
\
19,800円\
\
Campaign\
\
¥19,799​ ​OFF!​ ​\*3](https://network.mobile.rakuten.co.jp/product/smartphone/nubia-s2r/?wovn=en&l-id=product-recommendation_product_smartphone_nubia-s2r)
[New release on December 4\
\
![OPPO A5 5G](https://network.mobile.rakuten.co.jp/assets/img/product/a5-5g/rank-thumb.png?251128)\
\
#### OPPO A5 5G\
\
Device Price\
\
26,990円\
\
Campaign\
\
最大16,000ポイント還元！\*5](https://network.mobile.rakuten.co.jp/product/smartphone/a5-5g/?wovn=en&l-id=product-recommendation_product_smartphone_a5-5g)
[Newly released on November 21\
\
![arrows Alpha](https://network.mobile.rakuten.co.jp/assets/img/product/arrows-alpha/rank-thumb.png?251121)\
\
#### arrows Alpha\
\
Device Price\
\
69,900円\
\
Campaign\
\
最大26,000ポイント還元！\*5,6](https://network.mobile.rakuten.co.jp/product/smartphone/arrows-alpha/?wovn=en&l-id=product-recommendation_product_smartphone_arrows-alpha)
[New Release on November 20\
\
![Samsung Galaxy A25 5G](https://network.mobile.rakuten.co.jp/product/)\
\
#### Samsung Galaxy A25 5G\
\
Device Price\
\
22,001円\
\
Campaign\
\
¥22,000​ ​OFF!​ ​\*3](https://network.mobile.rakuten.co.jp/product/smartphone/galaxy-a25-5g/?wovn=en&l-id=product-recommendation_product_smartphone_galaxy-a25-5g)
[Price drop on November 28\
\
![Phone (3a)](https://network.mobile.rakuten.co.jp/product/)\
\
#### Phone (3a)\
\
Device Price\
\
54,890円\*9\
\
46,900円~\
\
Campaign\
\
¥22,000​ ​OFF!​ ​\*3,8](https://network.mobile.rakuten.co.jp/product/smartphone/phone-3a/?wovn=en&l-id=product-recommendation_product_smartphone_phone-3a)
[Campaign eligible\
\
![iPhone 16e](https://network.mobile.rakuten.co.jp/product/)\
\
#### iPhone 16e\
\
Device Price\
\
104,800円~\
\
Campaign\
\
48 installments (1st to 24th)\
\
1​ ​yen/mo.～\*2,7](https://network.mobile.rakuten.co.jp/product/iphone/iphone-16e/?wovn=en&l-id=product-recommendation_product_iphone_iphone-16e)
[Campaign eligible\
\
![Google Pixel 9a](https://network.mobile.rakuten.co.jp/product/)\
\
#### Google Pixel 9a\
\
Device Price\
\
92,000円~\
\
Campaign\
\
48 installments (1st to 24th)\
\
750​ ​yen/mo.～\*4,7](https://network.mobile.rakuten.co.jp/product/smartphone/google-pixel-9a/?wovn=en&l-id=product-recommendation_product_smartphone_google-pixel-9a)
[New Release on November 13\
\
![AQUOS sense10](https://network.mobile.rakuten.co.jp/product/)\
\
#### AQUOS sense10\
\
Device Price\
\
59,900円~\
\
Campaign\
\
最大16,000ポイント還元！\*5](https://network.mobile.rakuten.co.jp/product/smartphone/aquos-sense10/?wovn=en&l-id=product-recommendation_product_smartphone_aquos-sense10)
[Campaign eligible\
\
![iPhone 17](https://network.mobile.rakuten.co.jp/product/)\
\
#### iPhone 17\
\
Device Price\
\
146,800円~\
\
Campaign\
\
最大21,000ポイント還元！\*1](https://network.mobile.rakuten.co.jp/product/iphone/iphone-17/?wovn=en&l-id=product-recommendation_product_iphone_iphone-17)
[Campaign eligible\
\
![OPPO A3 5G](https://network.mobile.rakuten.co.jp/product/)\
\
#### OPPO A3 5G\
\
Device Price\
\
22,001円\
\
Campaign\
\
¥22,000​ ​OFF!​ ​\*3](https://network.mobile.rakuten.co.jp/product/smartphone/a3-5g/?wovn=en&l-id=product-recommendation_product_smartphone_a3-5g)
[Campaign eligible\
\
![iPhone 17 Pro](https://network.mobile.rakuten.co.jp/product/)\
\
#### iPhone 17 Pro\
\
Device Price\
\
207,900円~\
\
Campaign\
\
最大21,000ポイント還元！\*1](https://network.mobile.rakuten.co.jp/product/iphone/iphone-17-pro/?wovn=en&l-id=product-recommendation_product_iphone_iphone-17-pro)

PreviousNext

0123

*   \*1,2,3,4,5,6 See [Campaigns](https://network.mobile.rakuten.co.jp/product/#campaign-information)
     for details. Maximum Points are the total of various campaigns.
*   \*7 The 48 installments amount for Google Pixel 9a and iPhone 16e is when switching from another company while keeping the same phone number. Payment amounts will differ from the 25th payment onwards.
*   \*8 Price and campaign eligibility conditions vary by color and capacity.
*   \*9 Price at Rakuten Mobile. Sales period for Phone (3a): April 15, 2025 – November 27, 2025.

Device List
-----------

*   [![iPhone](https://network.mobile.rakuten.co.jp/assets/img/product/top/thumb-iphone-250912-pc.png)\
    \
    iPhone](https://network.mobile.rakuten.co.jp/product/iphone/?wovn=en&l-id=product_product_iphone)
    
*   [![Apple Watch](https://network.mobile.rakuten.co.jp/assets/img/product/top/thumb-apple-watch-250912-pc.png)\
    \
    Apple Watch](https://network.mobile.rakuten.co.jp/product/apple-watch/?wovn=en&l-id=product_product_apple-watch)
    

*   [![Android](https://network.mobile.rakuten.co.jp/assets/img/product/top/thumb-android-240-160-pc-250801.png)\
    \
    Android](https://network.mobile.rakuten.co.jp/product/smartphone/?wovn=en&l-id=product_product_smartphone)
    

*   [![Google](https://network.mobile.rakuten.co.jp/assets/img/product/top/thumb-google-80-80-250828.png)\
    \
    Google](https://network.mobile.rakuten.co.jp/product/smartphone/?wovn=en&l-id=product_product_smartphone-Google&device=Google#payment-advertisement)
    
*   [![Samsung](https://network.mobile.rakuten.co.jp/assets/img/product/top/thumb-galaxy-80-80-251120.png)\
    \
    Samsung](https://network.mobile.rakuten.co.jp/product/smartphone/?wovn=en&l-id=product_product_smartphone-Samsung&device=Samsung#payment-advertisement)
    
*   [![Nothing](https://network.mobile.rakuten.co.jp/assets/img/product/top/thumb-nothing-80-80-250820.png)\
    \
    Nothing](https://network.mobile.rakuten.co.jp/product/smartphone/?wovn=en&l-id=product_product_smartphone-Nothing&device=Nothing#payment-advertisement)
    
*   [![FCNT](https://network.mobile.rakuten.co.jp/assets/img/product/top/thumb-fcnt-80-80-251121.png)\
    \
    FCNT](https://network.mobile.rakuten.co.jp/product/smartphone/?wovn=en&l-id=product_product_smartphone-FCNT&device=FCNT#payment-advertisement)
    
*   [![OPPO](https://network.mobile.rakuten.co.jp/assets/img/product/top/thumb-oppo-80-80-250619.png)\
    \
    OPPO](https://network.mobile.rakuten.co.jp/product/smartphone/?wovn=en&l-id=product_product_smartphone-OPPO&device=OPPO#payment-advertisement)
    
*   [![SHARP](https://network.mobile.rakuten.co.jp/assets/img/product/top/thumb-aquos-80-80-251120.png)\
    \
    SHARP](https://network.mobile.rakuten.co.jp/product/smartphone/?wovn=en&l-id=product_product_smartphone-SHARP&device=SHARP#payment-advertisement)
    
*   [![ZTE](https://network.mobile.rakuten.co.jp/assets/img/product/top/thumb-zte-80-80-251202.png)\
    \
    ZTE](https://network.mobile.rakuten.co.jp/product/smartphone/?wovn=en&l-id=product_product_smartphone-ZTE&device=ZTE#payment-advertisement)
    
*   [![SONY](https://network.mobile.rakuten.co.jp/assets/img/product/top/thumb-xperia-80-80-241206.png)\
    \
    SONY](https://network.mobile.rakuten.co.jp/product/smartphone/?wovn=en&l-id=product_product_smartphone-SONY&device=SONY#payment-advertisement)
    

*   [![Wi-Fi routers / peripherals list](https://network.mobile.rakuten.co.jp/assets/img/product/top/thumb-wifi-240-160-pc-240711.png)\
    \
    Wi-Fi routers /  \
    peripherals list](https://network.mobile.rakuten.co.jp/product/internet/?wovn=en&l-id=product_product_internet)
    

*   [![Accessories List](https://network.mobile.rakuten.co.jp/assets/img/product/top/thumb-accessary-240-160-pc-231124.png)\
    \
    Accessories List](https://network.mobile.rakuten.co.jp/product/accessory/?wovn=en&l-id=product_product_accessory)
    

*   [![[Object]](https://network.mobile.rakuten.co.jp/assets/img/product/top/thumb-accessary-apple-80-80-240912.png)\
    \
    Apple  \
    accessories](https://network.mobile.rakuten.co.jp/product/accessory/apple/?wovn=en&l-id=product_product_accessory_apple)
    
*   [![[Object]](https://network.mobile.rakuten.co.jp/assets/img/product/top/thumb-accessary-apple-related-80-80.png)\
    \
    Apple-related  \
    accessories](https://network.mobile.rakuten.co.jp/product/accessory/apple-related/?wovn=en&l-id=product_product_accessory_apple-related)
    
*   [![[Object]](https://network.mobile.rakuten.co.jp/assets/img/product/top/thumb-accessary-smartphone-80-80-231124.png)\
    \
    Smartphone-related accessories](https://network.mobile.rakuten.co.jp/product/accessory/smartphone-related/?wovn=en&l-id=product_product_accessory_smartphone-related)
    

### Find it on Rakuten Ichiba! Special Feature on Smartphones & IoT Devices

[![Get Great Deals on Rakuten Ichiba! Recommended Products for Rakuten Mobile Users](https://network.mobile.rakuten.co.jp/assets/img/product/bnr-ichiba-recommended-pc-251113.png)](https://network.mobile.rakuten.co.jp/product/ichiba-recommended/?wovn=en&l-id=product_product_ichiba-recommended)

Device Popularity Ranking
-------------------------

Overall RankingiPhoneAndroid

[1 st\
\
![iPhone 16e](https://network.mobile.rakuten.co.jp/assets/img/product/iphone/iphone-16e/rank-thumb.png?250220)\
\
### iPhone 16e\
\
104,800円~](https://network.mobile.rakuten.co.jp/product/iphone/iphone-16e/?wovn=en&l-id=product_ranking_product_iphone_iphone-16e)
[2 nd\
\
![](https://network.mobile.rakuten.co.jp/assets/img/product/a3-5g/rank-thumb.png?251121)\
\
### OPPO A3 5G\
\
22,001円](https://network.mobile.rakuten.co.jp/product/smartphone/a3-5g/?wovn=en&l-id=product_ranking_product_smartphone_a3-5g)
[3 rd\
\
![](https://network.mobile.rakuten.co.jp/assets/img/product/arrows-we2/rank-thumb.png?251121)\
\
### Arrows We2\
\
22,001円](https://network.mobile.rakuten.co.jp/product/smartphone/arrows-we2/?wovn=en&l-id=product_ranking_product_smartphone_arrows-we2)
[4 th\
\
![iPhone 16](https://network.mobile.rakuten.co.jp/assets/img/product/iphone/iphone-16/rank-thumb.png?241121)\
\
### iPhone 16\
\
141,700円~](https://network.mobile.rakuten.co.jp/product/iphone/iphone-16/?wovn=en&l-id=product_ranking_product_iphone_iphone-16)
[5 th\
\
![iPhone 17](https://network.mobile.rakuten.co.jp/assets/img/product/iphone/iphone-17/rank-thumb.png?250912)\
\
### iPhone 17\
\
146,800円~](https://network.mobile.rakuten.co.jp/product/iphone/iphone-17/?wovn=en&l-id=product_ranking_product_iphone_iphone-17)
[6 th\
\
![](https://network.mobile.rakuten.co.jp/product/)\
\
### AQUOS sense9\
\
55,900円](https://network.mobile.rakuten.co.jp/product/smartphone/aquos-sense9/?wovn=en&l-id=product_ranking_product_smartphone_aquos-sense9)
[7 th\
\
![iPhone 17 Pro](https://network.mobile.rakuten.co.jp/product/)\
\
### iPhone 17 Pro\
\
207,900円~](https://network.mobile.rakuten.co.jp/product/iphone/iphone-17-pro/?wovn=en&l-id=product_ranking_product_iphone_iphone-17-pro)
[8 th\
\
![iPhone 15](https://network.mobile.rakuten.co.jp/product/)\
\
### iPhone 15\
\
112,800円~](https://network.mobile.rakuten.co.jp/product/iphone/iphone-15/?wovn=en&l-id=product_ranking_product_iphone_iphone-15)
[9 th\
\
![iPhone 16 Pro](https://network.mobile.rakuten.co.jp/product/)\
\
### iPhone 16 Pro\
\
181,800円~](https://network.mobile.rakuten.co.jp/product/iphone/iphone-16-pro/?wovn=en&l-id=product_ranking_product_iphone_iphone-16-pro)
[10 th\
\
![iPhone 17 Pro Max](https://network.mobile.rakuten.co.jp/product/)\
\
### iPhone 17 Pro Max\
\
234,800円~](https://network.mobile.rakuten.co.jp/product/iphone/iphone-17-pro-max/?wovn=en&l-id=product_ranking_product_iphone_iphone-17-pro-max)

PreviousNext

01

[View Details of Popularity Ranking](https://network.mobile.rakuten.co.jp/product/ranking/?wovn=en&l-id=product_product_ranking)

※Based on the number of units sold from September 1 to September 30, 2025.

Current Campaigns
-----------------

### iPhone

[![【Entry required】Get up to 21,000 points! Switch to Rakuten Mobile and trade in your iPhone 17 or iPhone 17 Pro. Buy a new iPhone, apply for Rakuten Mobile, switch from another carrier, and trade in your iPhone.](https://network.mobile.rakuten.co.jp/assets/img/bnr/iphone-point-iphone-17-328-185-250912.png)](https://network.mobile.rakuten.co.jp/campaign/iphone-point-iphone-17/?wovn=en&l-id=product_campaign_iphone-point-iphone-17)
[![Get a great deal on iPhone 16e (128GB)! Switch from another carrier and pay with Rakuten Card in 48 installments for just 1 yen/mo. (1-24 months: 1 yen; 25th month onward: 4,365 yen/mo.)](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-iphone-point-iphone-16e-328-185-251128.png)](https://network.mobile.rakuten.co.jp/campaign/iphone-point-iphone-16e/?wovn=en&l-id=product_campaign_iphone-point-iphone-16e)
[![[Entry required] iPhone 16 and iPhone 16 Pro Eligible! Purchase an eligible iPhone in full or 24 installments, apply for Rakuten Mobile for the first time, and switch from another carrier while keeping your number to get up to ¥36,000 worth of rewards!](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-iphone-pointback-328-185-251017.png)](https://network.mobile.rakuten.co.jp/campaign/iphone-pointback/?wovn=en&l-id=product_campaign_iphone-pointback)
[![Purchase iPhone 15 or iPhone 15 Pro in one lump sum or 24 installments, apply for Rakuten Mobile for the first time, and switch from another company while keeping your phone number and save up to 40,000 yen!](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-iphone-point-iphone-15-328-185.png)](https://network.mobile.rakuten.co.jp/campaign/iphone-point-iphone-15/?wovn=en&l-id=product_campaign_iphone-point-iphone-15)
[![[Entry required] Buy a qualifying iPhone in one go or in 24 installments, apply for Rakuten Mobile for the first time, and switch from another carrier while keeping your number to get up to ¥36,000 in rewards!](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-iphone-point-328-185-250425.png)](https://network.mobile.rakuten.co.jp/campaign/iphone-point/?wovn=en&l-id=product_campaign_iphone-point)

PreviousNext

01

### Android

[![Apply for Rakuten Mobile + Switch from another carrier (keeping your number) + Purchase a qualifying device = 1 yen!](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-android-discount-328-185-251202.png)](https://network.mobile.rakuten.co.jp/campaign/android-discount/?wovn=en&l-id=product_campaign_android-discount)
[![Get ¥22,000 off with Rakuten Mobile signup, number transfer from another carrier, and eligible product purchase!](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-android-sale-328-185-250801.png)](https://network.mobile.rakuten.co.jp/campaign/android-sale/?wovn=en&l-id=product_campaign_android-sale)
[![Purchase OPPO Reno11 A or Phone (3a) 256GB, sign up for Rakuten Mobile, and switch from another company while keeping your phone number to get 20,000 point rebates!](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-android-point-328-185-250801.png)](https://network.mobile.rakuten.co.jp/campaign/android-point/?wovn=en&l-id=product_campaign_android-point)
[![Get a guaranteed ¥5,000 cashback when you purchase and apply for AQUOS sense10. The purchase period ends on Thursday, January 15, 2026. This campaign is sponsored by Sharp Corporation.](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-aquos-sense10-cashback-328-185.png)](https://k-tai.sharp.co.jp/campaign/sense10cp/rakuten/index.html?utm_source=rakuten_cp&utm_medium=r_banner328185_sen10cp&utm_campaign=r_sense10_campaign)
[![Not sure which smartphone to choose? Let’s find the perfect Android device for you!](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-find-android-328-185-250820.png)](https://network.mobile.rakuten.co.jp/product/smartphone/features/?wovn=en&l-id=product_product_smartphone_features)
[![[Entry required] Apply for Rakuten Mobile for the first time, switch from another carrier, and purchase an eligible product to point rebates! Plus, get an additional 10,000 points with arrows Alpha! Even if you're not switching from another carrier, point rebates.](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-start-point-328-185-251128.png)](https://network.mobile.rakuten.co.jp/campaign/start-point/?wovn=en&l-id=product_campaign_start-point)

PreviousNext

012345

### Apple Watch

[![[Entry required] Web exclusive! Purchase an Apple Watch + join Phone Number Sharing Service (¥550/month) to get up to 25,000 Points!](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-number-share-328-185-250801.png)](https://network.mobile.rakuten.co.jp/campaign/apple-watch-number-share/?wovn=en&l-id=product_campaign_apple-watch-number-share)
[![Get 2 Years of Free Workout Insurance with Apple Watch Purchase!](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-watch-insurance-328-185-250115.png)](https://network.mobile.rakuten.co.jp/campaign/applewatch-insurance/?wovn=en&l-id=product_campaign_applewatch-insurance)
[![“Apple Watch Family Setup” Connect all your family’s Apple Watches with just one iPhone.](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-service_apple-watch-family-sharing-328-185-250115.png)](https://network.mobile.rakuten.co.jp/fee/apple-watch-family-sharing/?wovn=en&l-id=product_fee_apple-watch-family-sharing)

PreviousNext

### Wi-Fi

[![Rakuten WiFi Pocket Platinum for 1 yen with Rakuten Mobile subscription!](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-rakuten-wifi-pocket-platinum-328-185-251001.png)](https://network.mobile.rakuten.co.jp/product/internet/rakuten-wifi-pocket-platinum/?wovn=en&l-id=product_product_internet_rakuten-wifi-pocket-platinum)
[![Get 1,000 point rebates every month for life when you apply for Rakuten Turbo and use Rakuten Mobile. ※Time-limited points. Conditions apply.](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-turbo-328-185-250806.png)](https://network.mobile.rakuten.co.jp/internet/turbo/campaign/home-internet/?wovn=en&l-id=product_internet_turbo_campaign_home-internet)

PreviousNext

### Notes

Campaigns

*   \*1 For details, please see [the campaign where you can get up to 21,000 point rebates when you purchase the latest iPhone 17!](https://network.mobile.rakuten.co.jp/campaign/iphone-point-iphone-17/?wovn=en)
    ​
*   \*2 For details, please check [iPhone 16e: Switch from Another Carrier with Number Retention + 48 Installments (Kaikae Chotoku Program) from 1 yen/mo.!](https://network.mobile.rakuten.co.jp/campaign/iphone-point-iphone-16e/?wovn=en#detail)
     Campaign period: Monday, September 8, 2025, 9:00 AM - End date TBD. 48 installments available only with Rakuten Card. Cash lump-sum payment/installment price: 104,800 yen. Rakuten Card 48 installments: 4,365 yen/mo. for 25th-47th installments, 4,381 yen for 48th installment. Payment period: 48 months. Effective annual rate: 0%. Administrative fee: 3,300 yen.
*   \*3 For details, please check the [Limited-Time Campaign for Android Devices](https://network.mobile.rakuten.co.jp/campaign/android-discount/?wovn=en#campaign-rule2178)
    .
*   \*4 For details, please check the [“Rakuten SAIKYO Plan Contract & Android Kaikae Chotoku Program Use” Special Price Campaign](https://network.mobile.rakuten.co.jp/service/replacement-program/?wovn=en#campaign-rule2961)
    .
*   \*5 For details, please see [Smartphone TokuToku NoriKae! Up to 16,000 point rebates on Android devices!](https://network.mobile.rakuten.co.jp/campaign/start-point/?wovn=en#campaign-rule)
    .
*   \*6 For details, please check the campaign page for [10,000 Points for Switching from Another Carrier to arrows Alpha](https://network.mobile.rakuten.co.jp/campaign/start-point/?wovn=en#campaign-rule3076)
    .
*   \*Entry is required to earn some Points.
*   \*Point timing and validity periods vary by campaign, and points may be awarded in installments. Please check the campaign rules.
*   \*Earned Rakuten Point can be used for Rakuten Mobile and other Rakuten services. For more information, please see [the Rakuten Point](https://network.mobile.rakuten.co.jp/campaign/iphone-point/?wovn=en#point-detail)
     page.

#### Device Announcement

2025年12月02日

[楽天モバイル、「nubia S2R」を発売](https://network.mobile.rakuten.co.jp/product/smartphone/nubia-s2r/?wovn=en)

November 28, 2025

[Rakuten Mobile Launches OPPO A5 5G](https://network.mobile.rakuten.co.jp/product/smartphone/a5-5g/?wovn=en)

November 21, 2025

[Rakuten Mobile launches "arrows Alpha"](https://network.mobile.rakuten.co.jp/product/smartphone/arrows-alpha/?wovn=en)

[View all device announcements](https://network.mobile.rakuten.co.jp/information/news/product/?wovn=en)

#### Software Update Notification

November 12, 2025

[Galaxy Z Flip4 Update Information](https://network.mobile.rakuten.co.jp/information/software/galaxy-z-flip4/?wovn=en)

November 12, 2025

[Galaxy S23 Update Information](https://network.mobile.rakuten.co.jp/information/software/galaxy-s23/?wovn=en)

October 29, 2025

[Xperia 5 IV Update Information](https://network.mobile.rakuten.co.jp/information/software/xperia-5m4/?wovn=en)

[View list of software update notifications](https://network.mobile.rakuten.co.jp/information/software/?wovn=en)

### Support information for device purchase

*   Learn how to change your device, transfer data, and back up your information.
    
    [How to Change Your Device at Rakuten Mobile](https://network.mobile.rakuten.co.jp/guide/product/device-upgrade/?wovn=en&l-id=include_support_guide_device-upgrade)
    
*   Guidance for safe use of device
    
    [Caution when using Smartphone and peripherals](https://network.mobile.rakuten.co.jp/guide/product-safety/?wovn=en&l-id=include_support_guide_product-safety)
    
*   Learn how to keep your current phone number when switching from another carrier.
    
    [MNP transfer from other mobile carriers](https://network.mobile.rakuten.co.jp/guide/mnp/?wovn=en&l-id=include_support_guide_mnp)
    
*   Compatibility of Rakuten Mobile Devices with Other Carriers' Networks
    
    [List of compatible device with other companies' lines](https://network.mobile.rakuten.co.jp/product/compatible-band/?wovn=en&l-id=include_support_product_compatible-band)
    

Keep reading to find out more.
------------------------------

*   [Price PlanRakuten SAIKYO Plan details and application](https://network.mobile.rakuten.co.jp/fee/saikyo-plan/?wovn=en&l-id=footer_fee_saikyo)
    
*   [DevicesSmartphones compatible with Rakuten Mobile and 5G](https://network.mobile.rakuten.co.jp/product/?wovn=en&l-id=footer_product)
    
*   [Customer SupportYour questions about application and usage are answered here](https://network.mobile.rakuten.co.jp/support/?wovn=en&l-id=footer_support)
    

*   [Top](https://network.mobile.rakuten.co.jp/?wovn=en)
    
*   Device (iPhone, Android/ Smartphone)

*   [Company Overview](https://corp.mobile.rakuten.co.jp/)
    
*   [Business customers](https://business.mobile.rakuten.co.jp/?scid=wi_rmb_pers_footer)
    
*   [Corporate Partner Program](https://business.mobile.rakuten.co.jp/partner/?scid=wi_rmb_pers_footer)
    
*   [Handling of Personal Information](https://corp.mobile.rakuten.co.jp/guide/privacy/)
    
*   [Information Security Policy](https://corp.mobile.rakuten.co.jp/guide/security/)
    
*   [Trademarks and Registered Trademarks](https://corp.mobile.rakuten.co.jp/guide/trademark/)
    
*   [Display based on the Antique Dealings Act](https://network.mobile.rakuten.co.jp/secondhand-dealer/?wovn=en)
    
*   [Terms of Use](https://network.mobile.rakuten.co.jp/terms/?wovn=en)
    
*   [Handling of Information Sent Externally](https://network.mobile.rakuten.co.jp/optout/?wovn=en)
    

© Rakuten Mobile, Inc.

[![You can trust AI with Rakuten Group](https://network.mobile.rakuten.co.jp/assets/en/img/common/bnr-ai-safety-240-75-250530.png)](https://corp.rakuten.co.jp/ai/ai-safety/?scid=wi_rmb_aisafety)

[![【Go Green Together】Power consumption reduced by about 20% compared to the company's conventional network. Donation campaign ongoing.](https://network.mobile.rakuten.co.jp/assets/en/img/common/bnr-green-charity-240-75-250530.png)](https://network.mobile.rakuten.co.jp/campaign/green-charity/?wovn=en&l-id=footer_campaign_green-charity)

*   Rakuten Group
*   [Services](https://www.rakuten.co.jp/sitemap/)
    
*   [Contact (us, form, etc..) list](https://www.rakuten.co.jp/sitemap/inquiry.html)
    
*   [SUSTAINABILITY](https://corp.rakuten.co.jp/sustainability/)
    

[![Apply/Consult AI Support](https://network.mobile.rakuten.co.jp/assets/en/img/common/gen-ai-link-balloon-pc-250804.svg)![](https://network.mobile.rakuten.co.jp/assets/img/common/gen-ai-link-icon-pc-250804.svg)](https://network.mobile.rakuten.co.jp/chat/?l-id=assist-ai)
![Close](https://network.mobile.rakuten.co.jp/assets/img/common/gen-ai-close.svg)

日本語

English
