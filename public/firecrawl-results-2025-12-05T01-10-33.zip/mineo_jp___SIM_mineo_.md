# 格安スマホ・格安SIM【mineo(マイネオ)】

URL: https://mineo.jp/

---

![格安SIM・格安スマホのmineo](https://mineo.jp/asset/img/common/template/logo_mineo_white.png)
=====================================================================================

*   [法人のお客さま](https://mineo.jp/r/biz/link_header.html)
    
*   [お知らせ](https://mineo.jp/#info)
    
*   [キャンペーン](https://mineo.jp/campaign/)
    
*   [特集](https://mineo.jp/special/)
    
*        ![検索](https://mineo.jp/asset/img/common/icon_search.png)
    

*   [![](https://mineo.jp/asset/img/common/template/icon_menu_feature.png)\
    \
    mineoの  \
    特長](https://mineo.jp/#header-menu-feature)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_service.png)\
    \
    料金・  \
    サービス](https://mineo.jp/#header-menu-service)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_device.png)\
    \
    端末](https://mineo.jp/#header-menu-device)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_shop.png)\
    \
    店舗](https://mineo.jp/#header-menu-shop)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_guide.png)\
    \
    申込ガイド](https://mineo.jp/#header-menu-guide)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_support.png)\
    \
    サポート](https://mineo.jp/#header-menu-support)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_king.png)\
    \
    コミュニティ](https://mineo.jp/#header-menu-king)
    

*   [![](https://mineo.jp/asset/img/common/template/icon_mypage.png)\
    \
    マイページ](https://my.mineo.jp/)
    
*    [![](https://mineo.jp/asset/img/common/template/icon_apply_wh.png) ![](https://mineo.jp/asset/img/common/template/icon_apply_pink.png)\
    \
    お申し込み](https://mineo.jp/apply/)
    

メニュー

[![格安SIM・格安スマホのmineo](https://mineo.jp/asset/img/common/template/logo_mineo.png)](https://mineo.jp/)

*   [![](https://mineo.jp/asset/img/common/template/icon_menu_feature.png)\
    \
    mineoの  \
    特長](https://mineo.jp/#header-menu-feature)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_service.png)\
    \
    料金・  \
    サービス](https://mineo.jp/#header-menu-service)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_device.png)\
    \
    端末](https://mineo.jp/#header-menu-device)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_shop.png)\
    \
    店舗](https://mineo.jp/#header-menu-shop)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_guide.png)\
    \
    申込ガイド](https://mineo.jp/#header-menu-guide)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_support.png)\
    \
    サポート](https://mineo.jp/#header-menu-support)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_king.png)\
    \
    コミュニティ](https://mineo.jp/#header-menu-king)
    

*   [![](https://mineo.jp/asset/img/common/template/icon_mypage.png)\
    \
    マイページ](https://my.mineo.jp/)
    
*    [![](https://mineo.jp/asset/img/common/template/icon_apply_wh.png) ![](https://mineo.jp/asset/img/common/template/icon_apply_pink.png)\
    \
    お申し込み](https://mineo.jp/apply/)
    

![](https://mineo.jp/asset/img/common/template/header_mark.png)

閉じる

     ![検索](https://mineo.jp/asset/img/common/icon_search.png)

*   [![](https://mineo.jp/asset/img/common/template/icon_mypage.png)\
    \
    マイページ](https://my.mineo.jp/)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_apply_wh.png)\
    \
    お申し込み](https://mineo.jp/apply/)
    

![](https://mineo.jp/asset/img/common/template/icon_menu_feature.png)

mineoの特長

[はじめての方へ](https://mineo.jp/beginner/)
 [mineoが選ばれる理由](https://mineo.jp/reason/)
 [Fun with Fans！](https://mineo.jp/brand/)

![](https://mineo.jp/asset/img/common/template/icon_menu_service.png)

料金・サービス

[料金表](https://mineo.jp/price/)
 [サービス・オプション一覧](https://mineo.jp/service/)
 [かんたん料金シミュレーション](https://mineo.jp/simulator/)

[![](https://mineo.jp/asset/img/common/template/icon_menu_campaign.png)\
\
キャンペーン](https://mineo.jp/campaign/)

![](https://mineo.jp/asset/img/common/template/icon_menu_device.png)

端末

[mineoで使う端末を選ぶ](https://mineo.jp/device/about/)
 [iPhone](https://mineo.jp/device/iphone/)
 [スマートフォン](https://mineo.jp/device/smartphone/)
 [タブレット・ルーター](https://mineo.jp/device/other/)
 [動作確認済み端末検索](https://mineo.jp/device/devicelist/)

![](https://mineo.jp/asset/img/common/template/icon_menu_shop.png)

店舗

[店舗を探す](https://mineo.jp/shop/)
 [店舗でできること](https://mineo.jp/shop/about/)
 [店舗でSIMを受け取る](https://mineo.jp/shop/online/counter/)

![](https://mineo.jp/asset/img/common/template/icon_menu_guide.png)

申込ガイド

[お手持ちの端末をそのまま使う方](https://mineo.jp/apply/simonly-flow/)
 [mineoで端末も一緒に買いたい方](https://mineo.jp/apply/device-flow/)
 [初期設定～ご利用開始の流れ](https://mineo.jp/apply/setup-flow/)
 [お申し込み](https://mineo.jp/apply/)

![](https://mineo.jp/asset/img/common/template/icon_menu_support.png)

サポート

[ユーザーサポートTOP](https://support.mineo.jp/)
 [初期設定・各種設定](https://support.mineo.jp/setup/guide/)
 [よくあるご質問](https://support.mineo.jp/usqa/)
 [AIチャットサポート](https://mineo.jp/r/mai_chat/)
 [お問い合わせ](https://support.mineo.jp/inquiry.html)

[![](https://mineo.jp/asset/img/common/template/icon_menu_king.png)\
\
コミュニティ](https://king.mineo.jp/)
[![](https://mineo.jp/asset/img/common/template/icon_menu_news.png)\
\
お知らせ](https://support.mineo.jp/news_list/)
[![](https://mineo.jp/asset/img/common/template/icon_menu_special.png)\
\
特集](https://mineo.jp/special/)
[![](https://mineo.jp/asset/img/common/template/icon_menu_column.png)\
\
お役立ちコラム](https://mineo.jp/column/)
[![](https://mineo.jp/asset/img/common/template/icon_menu_business.png)\
\
法人のお客さま](https://mineo.jp/r/biz/link_header.html)

[![](https://mineo.jp/asset/img/common/template/logo_mineo.svg)](https://mineo.jp/)

![](https://mineo.jp/asset/img/common/template/icon_menu_feature.png)

mineoの特長

[](https://mineo.jp/#)

*   mineo（マイネオ）や格安スマホサービスがはじめての方へ
    
      [![](https://mineo.jp/asset/img/common/template/icon_feature_beginner.png?v20230614) ![](https://mineo.jp/asset/img/common/template/icon_feature_beginner.png?v20230614) はじめての方へ](https://mineo.jp/beginner/)
    
*   格安スマホサービスの中でも選ばれるのには理由があります！
    
      [![](https://mineo.jp/asset/img/common/template/icon_feature_reason.png?v20230614) ![](https://mineo.jp/asset/img/common/template/icon_feature_reason.png?v20230614) mineoが選ばれる理由](https://mineo.jp/reason/)
    
*    [![ブランドステートメント Fun with Fans!](https://mineo.jp/asset/img/common/template/feature-banner.png?v20190731) ![ブランドステートメント Fun with Fans!](https://mineo.jp/asset/img/common/template/sp/feature-banner.png?v20190731)](https://mineo.jp/brand/)
    

*   [![お役立ちコラム](https://mineo.jp/_mg/_uploads/files/4fce8fccb3fa0a96_mineo_Gnavi_bnr_B.jpg)](https://mineo.jp/column/)
    

![](https://mineo.jp/asset/img/common/template/icon_menu_service.png)

料金・サービス

[](https://mineo.jp/#)

*     [![](https://mineo.jp/asset/img/common/template/icon_service_price.png) ![](https://mineo.jp/asset/img/common/template/icon_service_price.png) 料金表](https://mineo.jp/price/)
    
*    [![](https://mineo.jp/asset/img/common/template/icon_service_option.png) サービス・オプション一覧](https://mineo.jp/service/)
    
*     [![](https://mineo.jp/asset/img/common/template/icon_service_simulator.png?v20210401) ![](https://mineo.jp/asset/img/common/template/icon_service_simulator.png?v20210401) かんたん料金シミュレーション](https://mineo.jp/simulator/)
    

*   [![おトクなキャンペーン情報](https://mineo.jp/_mg/_uploads/files/3897e85cae780a5f_maipyon_banner.jpg)](https://mineo.jp/campaign/)
    
*   [![法人のお客さまはこちら](https://mineo.jp/_mg/_uploads/files/13c4fc24b5f50ae4_business.jpg)](https://mineo.jp/r/biz/link_drop/)
    

![](https://mineo.jp/asset/img/common/template/icon_menu_device.png)

端末

[](https://mineo.jp/#)

*   持ち込みも買い替えも自由に選べる！
    
      [![](https://mineo.jp/asset/img/common/template/icon_device_about.png) ![](https://mineo.jp/asset/img/common/template/icon_device_about.png) mineoで使う  \
    端末を選ぶ](https://mineo.jp/device/about/)
    
*   mineoで端末を買う
    
     [![](https://mineo.jp/asset/img/common/template/icon_device_iphone.png) iPhone](https://mineo.jp/device/iphone/)
    [![](https://mineo.jp/asset/img/common/template/icon_device_smartphone.png) スマートフォン](https://mineo.jp/device/smartphone/)
    [![](https://mineo.jp/asset/img/common/template/icon_device_other.png) タブレット・ルーター](https://mineo.jp/device/other/)
    
*   お手持ちの端末を使う
    
      [![](https://mineo.jp/asset/img/common/template/icon_device_devicelist.png) ![](https://mineo.jp/asset/img/common/template/icon_device_devicelist.png) 動作確認済み  \
    端末検索](https://mineo.jp/device/devicelist/)
    

*   [![mineoスマホコーティング](https://mineo.jp/_mg/_uploads/files/ebd51d24a7bb0a3f_mineo_Gnavi_bnr_smartphone_coating_A.jpg)](https://mineo.jp/service/discount/coating/)
    

![](https://mineo.jp/asset/img/common/template/icon_menu_shop.png)

店舗

[](https://mineo.jp/#)

Webでの新規申し込みが不安な方は、お気軽にご来店ください。

*     [![](https://mineo.jp/asset/img/common/template/icon_shop_search.png) ![](https://mineo.jp/asset/img/common/template/icon_shop_search.png) 店舗を探す](https://mineo.jp/shop/)
    
*     [![](https://mineo.jp/asset/img/common/template/icon_shop_about.png) ![](https://mineo.jp/asset/img/common/template/icon_shop_about.png) 店舗でできること](https://mineo.jp/shop/about/)
    
*     [![](https://mineo.jp/asset/img/common/template/icon_shop_online.png) ![](https://mineo.jp/asset/img/common/template/icon_shop_online.png) 店舗でSIMを受け取る](https://mineo.jp/shop/online/counter/)
    

![](https://mineo.jp/asset/img/common/template/icon_menu_guide.png)

申込ガイド

[](https://mineo.jp/#)

*   準備からお申し込みの流れ
    
     [![](https://mineo.jp/asset/img/common/template/icon_apply_simonly.png) お手持ちの端末を  \
    そのまま使う方](https://mineo.jp/apply/simonly-flow/)
    [![](https://mineo.jp/asset/img/common/template/icon_apply_device.png) mineoで端末も  \
    一緒に買いたい方](https://mineo.jp/apply/device-flow/)
    
*   SIMカードや端末が届いたら
    
      [![](https://mineo.jp/asset/img/common/template/icon_apply_flow.png?v20211000) ![](https://mineo.jp/asset/img/common/template/icon_apply_flow.png?v20211000) 初期設定～  \
    ご利用開始の流れ](https://mineo.jp/apply/setup-flow/)
    
*   お申し込みページでご契約
    
      [![](https://mineo.jp/asset/img/common/template/icon_apply_entry.png) ![](https://mineo.jp/asset/img/common/template/icon_apply_entry.png) お申し込み](https://mineo.jp/apply/)
    

![](https://mineo.jp/asset/img/common/template/icon_menu_support.png)

サポート

[](https://mineo.jp/#)

*   mineoユーザーサポート
    
      [![](https://mineo.jp/asset/img/common/template/icon_support_top.png?v20210401) ![](https://mineo.jp/asset/img/common/template/icon_support_top.png?v20210401) ユーザーサポートTOP](https://support.mineo.jp/)
    
*   設定でわからないことを調べる
    
     [![](https://mineo.jp/asset/img/common/template/icon_support_setup.png) 初期設定・各種設定](https://support.mineo.jp/setup/guide/)
    [![](https://mineo.jp/asset/img/common/template/icon_support_faq.png) よくあるご質問](https://support.mineo.jp/usqa/)
    
*   わからないこと、不安なことがあればお問い合わせを
    
     [![](https://mineo.jp/asset/img/common/template/icon_support_chat.png) AIチャットサポート](https://mineo.jp/r/mai_chat/)
    [![](https://mineo.jp/asset/img/common/template/icon_support_inquiry.png) お問い合わせ](https://support.mineo.jp/inquiry.html)
    

![](https://mineo.jp/asset/img/common/template/icon_menu_king.png)

コミュニティ

[](https://mineo.jp/#)

*   マイネ王は、全国のmineoユーザーやmineoスタッフたちが交流しているコミュニティサイトです。
    
    [![](https://mineo.jp/asset/img/common/template/icon_king_guide.png)](https://king.mineo.jp/beginner_guide.html)
    
     [![](https://mineo.jp/asset/img/common/template/icon_king_top.png) コミュニティサイト  \
    マイネ王](https://king.mineo.jp/)
    
*   おすすめコンテンツ
    
    mineoのサービスや端末のレビュー [![](https://mineo.jp/asset/img/common/template/icon_king_review.png) レビュー](https://king.mineo.jp/reviews/)
    
    みんなの疑問と回答 [![](https://mineo.jp/asset/img/common/template/icon_king_faq.png) Q&A](https://king.mineo.jp/question-answer/)
    
*     
    
    mineoに対するみんなの提案 [![](https://mineo.jp/asset/img/common/template/icon_king_idea.png) アイデアファーム](https://king.mineo.jp/ideas/)
    
    パケットをシェアして助け合い [![](https://mineo.jp/asset/img/common/template/icon_king_freetank.png) フリータンク](https://king.mineo.jp/freetank/)
    

マイネ王は、全国のmineoユーザーや  
mineoスタッフたちが交流している  
コミュニティサイトです。 [![](https://mineo.jp/asset/img/common/template/icon_king_top.png) コミュニティサイト  \
マイネ王](https://king.mineo.jp/)

[![](https://mineo.jp/asset/img/common/template/icon_king_guide.png)](https://king.mineo.jp/beginner_guide.html)

おすすめコンテンツ

*   mineoのサービスや端末の  
    レビュー [![](https://mineo.jp/asset/img/common/template/icon_king_review.png) レビュー](https://king.mineo.jp/reviews/)
    
*   みんなの疑問と回答  
      
     [![](https://mineo.jp/asset/img/common/template/icon_king_faq.png) Q&A](https://king.mineo.jp/question-answer/)
    

*   mineoに対するみんなの提案 [![](https://mineo.jp/asset/img/common/template/icon_king_idea.png) アイデア  \
    ファーム](https://king.mineo.jp/ideas/)
    
*   パケットをシェアして助け合い [![](https://mineo.jp/asset/img/common/template/icon_king_freetank.png) フリータンク](https://king.mineo.jp/freetank/)
    

*   [![マイピタ料金そのままデータ増量!　1GB→3GB　5GB→7GB　10GB→15GB　20GB→30GB　さらに!パケット放題サービスをアップデート!](https://mineo.jp/_mg/_uploads/files/571dbd40af030a3b_20251125_teaser_top_bnr_pc.webp)![マイピタ料金そのままデータ増量!　1GB→3GB　5GB→7GB　10GB→15GB　20GB→30GB　さらに!パケット放題サービスをアップデート!](https://mineo.jp/_mg/_uploads/files/39a433abb08a0a29_20251125_teaser_top_bnr_sp.webp)](https://mineo.jp/special/2025winter/)
    
*   [![NEW　iPhone 17(中古 未使用品)　iPhone Air(中古 未使用品)　好評発売中！](https://mineo.jp/_mg/_uploads/files/3a115b1cb18e0a91_251201_newiphone_ssTOP_bnr_pc.webp)![NEW　iPhone 17(中古 未使用品)　iPhone Air(中古 未使用品)　好評発売中！](https://mineo.jp/_mg/_uploads/files/00949197b86d0ac5_251201_newiphone_ssTOP_bnr_sp.webp)](https://mineo.jp/device/iphone/)
    
*   [![New　Mode1 POCKET 8GB/256GBモデル　OPPO A5 5G　好評発売中!](https://mineo.jp/_mg/_uploads/files/f337d24cb4960a9e_251204_newdevice_ssTOP_bnr_pc.webp)![New　Mode1 POCKET 8GB/256GBモデル　OPPO A5 5G　好評発売中!](https://mineo.jp/_mg/_uploads/files/08f785e8adb00a4d_251204_newdevice_ssTOP_bnr_sp.webp)](https://mineo.jp/device/smartphone/)
    
*   [![最大6カ月間無料キャンペーン中！　お手持ちのパケットを貯められる！パスケット　パスケットの中に貯まっているパケットはずっと繰越可能！](https://mineo.jp/_mg/_uploads/files/aba2c5faba500af5_20251126_pasket_top_bnr_pc.webp)![最大6カ月間無料キャンペーン中！　お手持ちのパケットを貯められる！パスケット　パスケットの中に貯まっているパケットはずっと繰越可能！](https://mineo.jp/_mg/_uploads/files/f55b6336b0290a77_20251126_pasket_top_bnr_sp.webp)](https://mineo.jp/service/data/pasket/)
    
*   [![【motorola razr 60】対象のスマートフォン購入で電子マネーギフト※10,000円分プレゼントキャンペーン　お申し込み期間：2025年12月25日（木）まで　※電子マネーギフトは「EJOICAセレクトギフト」になります。「EJOICAセレクトギフト」は、株式会社NTTカードソリューションが発行する電子マネーギフトです。](https://mineo.jp/_mg/_uploads/files/02b5c7bfa69709fc_251113_motorolacp_ssTOP_bnr_pc.webp)![【motorola razr 60】対象のスマートフォン購入で電子マネーギフト※10,000円分プレゼントキャンペーン　お申し込み期間：2025年12月25日（木）まで　※電子マネーギフトは「EJOICAセレクトギフト」になります。「EJOICAセレクトギフト」は、株式会社NTTカードソリューションが発行する電子マネーギフトです。](https://mineo.jp/_mg/_uploads/files/fc6e0948a1b50983_251113_motorolacp_ssTOP_bnr_sp.webp)](https://mineo.jp/campaign/cp-20251113-1/)
    
*   [![【OPPO Reno14 5G　OPPO Reno13 A　OPPO Reno11 A】対象のスマートフォン購入で電子マネーギフト※プレゼントキャンペーン　お申し込み期間：2026年1月30日（金）まで　※電子マネーギフトは「EJOICAセレクトギフト」になります。「EJOICAセレクトギフト」は、株式会社NTTカードソリューションが発行する電子マネーギフトです。](https://mineo.jp/_mg/_uploads/files/9a1299caa6890a00_251113_oppocp_ssTOP_bnr_pc.webp)![【OPPO Reno14 5G　OPPO Reno13 A　OPPO Reno11 A】対象のスマートフォン購入で電子マネーギフト※プレゼントキャンペーン　お申し込み期間：2026年1月30日（金）まで　※電子マネーギフトは「EJOICAセレクトギフト」になります。「EJOICAセレクトギフト」は、株式会社NTTカードソリューションが発行する電子マネーギフトです。](https://mineo.jp/_mg/_uploads/files/d092dc0bbbd20afd_251113_oppocp_ssTOP_bnr_sp.webp)](https://mineo.jp/campaign/cp-20251113-2/)
    
*   [![マイピタ料金そのままデータ増量!　1GB→3GB　5GB→7GB　10GB→15GB　20GB→30GB　さらに!パケット放題サービスをアップデート!](https://mineo.jp/_mg/_uploads/files/571dbd40af030a3b_20251125_teaser_top_bnr_pc.webp)![マイピタ料金そのままデータ増量!　1GB→3GB　5GB→7GB　10GB→15GB　20GB→30GB　さらに!パケット放題サービスをアップデート!](https://mineo.jp/_mg/_uploads/files/39a433abb08a0a29_20251125_teaser_top_bnr_sp.webp)](https://mineo.jp/special/2025winter/)
    
*   [![NEW　iPhone 17(中古 未使用品)　iPhone Air(中古 未使用品)　好評発売中！](https://mineo.jp/_mg/_uploads/files/3a115b1cb18e0a91_251201_newiphone_ssTOP_bnr_pc.webp)![NEW　iPhone 17(中古 未使用品)　iPhone Air(中古 未使用品)　好評発売中！](https://mineo.jp/_mg/_uploads/files/00949197b86d0ac5_251201_newiphone_ssTOP_bnr_sp.webp)](https://mineo.jp/device/iphone/)
    
*   [![New　Mode1 POCKET 8GB/256GBモデル　OPPO A5 5G　好評発売中!](https://mineo.jp/_mg/_uploads/files/f337d24cb4960a9e_251204_newdevice_ssTOP_bnr_pc.webp)![New　Mode1 POCKET 8GB/256GBモデル　OPPO A5 5G　好評発売中!](https://mineo.jp/_mg/_uploads/files/08f785e8adb00a4d_251204_newdevice_ssTOP_bnr_sp.webp)](https://mineo.jp/device/smartphone/)
    
*   [![最大6カ月間無料キャンペーン中！　お手持ちのパケットを貯められる！パスケット　パスケットの中に貯まっているパケットはずっと繰越可能！](https://mineo.jp/_mg/_uploads/files/aba2c5faba500af5_20251126_pasket_top_bnr_pc.webp)![最大6カ月間無料キャンペーン中！　お手持ちのパケットを貯められる！パスケット　パスケットの中に貯まっているパケットはずっと繰越可能！](https://mineo.jp/_mg/_uploads/files/f55b6336b0290a77_20251126_pasket_top_bnr_sp.webp)](https://mineo.jp/service/data/pasket/)
    
*   [![【motorola razr 60】対象のスマートフォン購入で電子マネーギフト※10,000円分プレゼントキャンペーン　お申し込み期間：2025年12月25日（木）まで　※電子マネーギフトは「EJOICAセレクトギフト」になります。「EJOICAセレクトギフト」は、株式会社NTTカードソリューションが発行する電子マネーギフトです。](https://mineo.jp/_mg/_uploads/files/02b5c7bfa69709fc_251113_motorolacp_ssTOP_bnr_pc.webp)![【motorola razr 60】対象のスマートフォン購入で電子マネーギフト※10,000円分プレゼントキャンペーン　お申し込み期間：2025年12月25日（木）まで　※電子マネーギフトは「EJOICAセレクトギフト」になります。「EJOICAセレクトギフト」は、株式会社NTTカードソリューションが発行する電子マネーギフトです。](https://mineo.jp/_mg/_uploads/files/fc6e0948a1b50983_251113_motorolacp_ssTOP_bnr_sp.webp)](https://mineo.jp/campaign/cp-20251113-1/)
    
*   [![【OPPO Reno14 5G　OPPO Reno13 A　OPPO Reno11 A】対象のスマートフォン購入で電子マネーギフト※プレゼントキャンペーン　お申し込み期間：2026年1月30日（金）まで　※電子マネーギフトは「EJOICAセレクトギフト」になります。「EJOICAセレクトギフト」は、株式会社NTTカードソリューションが発行する電子マネーギフトです。](https://mineo.jp/_mg/_uploads/files/9a1299caa6890a00_251113_oppocp_ssTOP_bnr_pc.webp)![【OPPO Reno14 5G　OPPO Reno13 A　OPPO Reno11 A】対象のスマートフォン購入で電子マネーギフト※プレゼントキャンペーン　お申し込み期間：2026年1月30日（金）まで　※電子マネーギフトは「EJOICAセレクトギフト」になります。「EJOICAセレクトギフト」は、株式会社NTTカードソリューションが発行する電子マネーギフトです。](https://mineo.jp/_mg/_uploads/files/d092dc0bbbd20afd_251113_oppocp_ssTOP_bnr_sp.webp)](https://mineo.jp/campaign/cp-20251113-2/)
    
*   [![マイピタ料金そのままデータ増量!　1GB→3GB　5GB→7GB　10GB→15GB　20GB→30GB　さらに!パケット放題サービスをアップデート!](https://mineo.jp/_mg/_uploads/files/571dbd40af030a3b_20251125_teaser_top_bnr_pc.webp)![マイピタ料金そのままデータ増量!　1GB→3GB　5GB→7GB　10GB→15GB　20GB→30GB　さらに!パケット放題サービスをアップデート!](https://mineo.jp/_mg/_uploads/files/39a433abb08a0a29_20251125_teaser_top_bnr_sp.webp)](https://mineo.jp/special/2025winter/)
    
*   [![NEW　iPhone 17(中古 未使用品)　iPhone Air(中古 未使用品)　好評発売中！](https://mineo.jp/_mg/_uploads/files/3a115b1cb18e0a91_251201_newiphone_ssTOP_bnr_pc.webp)![NEW　iPhone 17(中古 未使用品)　iPhone Air(中古 未使用品)　好評発売中！](https://mineo.jp/_mg/_uploads/files/00949197b86d0ac5_251201_newiphone_ssTOP_bnr_sp.webp)](https://mineo.jp/device/iphone/)
    
*   [![New　Mode1 POCKET 8GB/256GBモデル　OPPO A5 5G　好評発売中!](https://mineo.jp/_mg/_uploads/files/f337d24cb4960a9e_251204_newdevice_ssTOP_bnr_pc.webp)![New　Mode1 POCKET 8GB/256GBモデル　OPPO A5 5G　好評発売中!](https://mineo.jp/_mg/_uploads/files/08f785e8adb00a4d_251204_newdevice_ssTOP_bnr_sp.webp)](https://mineo.jp/device/smartphone/)
    
*   [![最大6カ月間無料キャンペーン中！　お手持ちのパケットを貯められる！パスケット　パスケットの中に貯まっているパケットはずっと繰越可能！](https://mineo.jp/_mg/_uploads/files/aba2c5faba500af5_20251126_pasket_top_bnr_pc.webp)![最大6カ月間無料キャンペーン中！　お手持ちのパケットを貯められる！パスケット　パスケットの中に貯まっているパケットはずっと繰越可能！](https://mineo.jp/_mg/_uploads/files/f55b6336b0290a77_20251126_pasket_top_bnr_sp.webp)](https://mineo.jp/service/data/pasket/)
    
*   [![【motorola razr 60】対象のスマートフォン購入で電子マネーギフト※10,000円分プレゼントキャンペーン　お申し込み期間：2025年12月25日（木）まで　※電子マネーギフトは「EJOICAセレクトギフト」になります。「EJOICAセレクトギフト」は、株式会社NTTカードソリューションが発行する電子マネーギフトです。](https://mineo.jp/_mg/_uploads/files/02b5c7bfa69709fc_251113_motorolacp_ssTOP_bnr_pc.webp)![【motorola razr 60】対象のスマートフォン購入で電子マネーギフト※10,000円分プレゼントキャンペーン　お申し込み期間：2025年12月25日（木）まで　※電子マネーギフトは「EJOICAセレクトギフト」になります。「EJOICAセレクトギフト」は、株式会社NTTカードソリューションが発行する電子マネーギフトです。](https://mineo.jp/_mg/_uploads/files/fc6e0948a1b50983_251113_motorolacp_ssTOP_bnr_sp.webp)](https://mineo.jp/campaign/cp-20251113-1/)
    
*   [![【OPPO Reno14 5G　OPPO Reno13 A　OPPO Reno11 A】対象のスマートフォン購入で電子マネーギフト※プレゼントキャンペーン　お申し込み期間：2026年1月30日（金）まで　※電子マネーギフトは「EJOICAセレクトギフト」になります。「EJOICAセレクトギフト」は、株式会社NTTカードソリューションが発行する電子マネーギフトです。](https://mineo.jp/_mg/_uploads/files/9a1299caa6890a00_251113_oppocp_ssTOP_bnr_pc.webp)![【OPPO Reno14 5G　OPPO Reno13 A　OPPO Reno11 A】対象のスマートフォン購入で電子マネーギフト※プレゼントキャンペーン　お申し込み期間：2026年1月30日（金）まで　※電子マネーギフトは「EJOICAセレクトギフト」になります。「EJOICAセレクトギフト」は、株式会社NTTカードソリューションが発行する電子マネーギフトです。](https://mineo.jp/_mg/_uploads/files/d092dc0bbbd20afd_251113_oppocp_ssTOP_bnr_sp.webp)](https://mineo.jp/campaign/cp-20251113-2/)
    

![前へ](https://mineo.jp/asset/img/device/lineup/mv_arrow_prev.png)

![次へ](https://mineo.jp/asset/img/device/lineup/mv_arrow_next.png)

*   [![](https://mineo.jp/asset/img/top/sp/nav_icon_01.png)\
    \
    料金表](https://mineo.jp/price/)
    
*   [![](https://mineo.jp/asset/img/top/sp/nav_icon_02.png)\
    \
    サービス・  \
    オプション](https://mineo.jp/service/)
    
*   [![](https://mineo.jp/asset/img/top/sp/nav_icon_03.png)\
    \
    端末](https://mineo.jp/device/about/)
    
*   [![](https://mineo.jp/asset/img/top/sp/nav_icon_04.png)\
    \
    動作確認  \
    端末一覧](https://mineo.jp/device/devicelist/)
    
*   [![](https://mineo.jp/asset/img/top/sp/nav_icon_05.png)\
    \
    キャンペーン](https://mineo.jp/campaign/)
    
*   [![](https://mineo.jp/asset/img/top/sp/nav_icon_06.png)\
    \
    店舗](https://mineo.jp/shop/)
    
*   [![](https://mineo.jp/asset/img/top/sp/nav_icon_07.png)\
    \
    サポート](https://support.mineo.jp/)
    
*   [![](https://mineo.jp/asset/img/top/sp/nav_icon_08.png)\
    \
    コミュニティ  \
    サイト](https://king.mineo.jp/)
    

mineoって  
どんなサービス？
------------------

*   データ容量で選ぶ
    
    ![マイピタ](https://mineo.jp/asset/img/top/about_tab_mypita.png)
*   通信速度で選ぶ
    
    ![マイそく](https://mineo.jp/asset/img/top/about_tab_mysoku.png)

### ![毎月必要なデータ容量で選ぶ マイピタ](https://mineo.jp/asset/img/top/about_mypita_logo.png)

自分に合ったデータ容量を  
選んでムダなくおトク！

7GB

![](https://mineo.jp/asset/img/top/about_mypita_service_icon_voice.png)

音声通話付き

1,518円/月

選べるデータ容量は5種類

3GB

1,298円/月

7GB

1,518円/月

15GB

1,958円/月

30GB

2,178円/月

50GB

2,948円/月

![](https://mineo.jp/asset/img/top/about_carry_graph.png)

余ったデータ容量は  
翌月繰り越し

[マイピタの詳細を見る](https://mineo.jp/price/mypita/)

### ![データ無制限！最大通信速度※で選ぶマイそく](https://mineo.jp/asset/img/top/about_mysoku_logo.png)

月曜～金曜の12～13時の通信速度が  
制限される代わりに、  
おトクにデータ通信が使い放題！

*   ※ 月曜～金曜の12時台は最大32kbps（プレミアムのみ200kbps）になります。また混雑回避のための速度  
    制限（3日間で10GB以上利用時）および通信最適化が適用されます。

スタンダード  
最大1.5Mbps

990円/月

選べる通信速度は４種類

最大32kbps

最大300kbps

最大1.5Mbps

最大5Mbps

![](https://mineo.jp/asset/img/top/about_mysoku_pic.png)

お昼に自宅のWi-Fiを利用できる方や  
お昼にスマホを使わない方、  
電話のみ利用する方におすすめ！

[マイそくの詳細を見る](https://mineo.jp/price/mysoku/)

さあ、mineoをはじめよう！
---------------

*    [![](https://mineo.jp/asset/img/common/conversion_icon_apply.png) mineoに申し込む](https://mineo.jp/apply/)
    
*    [![](https://mineo.jp/asset/img/common/conversion_icon_sim.png) 料金をシミュレーションする](https://mineo.jp/simulator/)
    

mineoならではの  
パケットサービスが充実！
-------------------------

データ通信量が多い人も  
少ない人も使いやすい  
さまざまなサービスをご提供！

*   ### パケット放題 Plus
    
    ![](https://mineo.jp/asset/img/top/service_icon_packethoudai.png)
    
    ネットも動画もデータ通信が使い放題（最大1.5Mbps）！  
    マイピタ 15GB以上のコースをご契約の場合は月額料金385円が無料！
    
    *   ○ 混雑回避のための速度制限（3日間で10GB以上利用時）があります。
    
    [詳細を見る](https://mineo.jp/service/data/packet-free/)
    
*   ### フリータンク
    
    ![](https://mineo.jp/asset/img/top/service_icon_freetank.png)
    
    mineoユーザーのパケットをみんなでシェア！  
    余ったパケットを入れておいたり、足りないときは分けてもらえる！
    
    [詳細を見る](https://mineo.jp/service/data/freetank/)
    
*   ### パケットギフト
    
    ![](https://mineo.jp/asset/img/top/service_icon_packetgift.png)
    
    家族や友達とパケットを分け合える！
    
    [詳細を見る](https://mineo.jp/service/data/packet-gift/)
    
*   ### パケットシェア
    
    ![](https://mineo.jp/asset/img/top/service_icon_packetshare.png)
    
    翌月に繰り越したパケットをグループ内で自動シェア！
    
    [詳細を見る](https://mineo.jp/service/data/packet-share/)
    

端末もサービスも  
自分にぴったりのものが  
選べる！
-----------------------------

POINT1

### 持ち込みも買い替えも！  
いろんなスマホがすぐ使える

動作確認端末は700種類以上！  
auもドコモもソフトバンクも  
お手持ちの端末がそのまま使える！

![](https://mineo.jp/asset/img/top/feature_device_pic_01.png)

[動作確認済みの端末を見る](https://mineo.jp/device/devicelist/)

iPhoneをはじめとする  
多数の端末をご用意。  
乗り換えと一緒に買い替えもOK！

*   [OPPO A5 5G\
    \
    ![OPPO A5 5G](https://mineo.jp/_mg/_uploads/files/7fb944bba77609f9_251204_OPPO_A5_5G_deviceimg_main.png)](https://mineo.jp/device/smartphone/oppo-a5-5g/)
    
*   [Mode1 Pocket 8GB/256GBモデル\
    \
    ![Mode1 Pocket 8GB/256GBモデル](https://mineo.jp/_mg/_uploads/files/1aba9944adb60a91_251205_%20Mode1_Pocket_deviceimg_main.png)](https://mineo.jp/device/smartphone/mode1-pocket-8gb-256gb/)
    
*   [iPhone 17（中古 未使用品）(256GB)国内版SIMフリー\
    \
    ![iPhone 17（中古 未使用品）(256GB)](https://mineo.jp/_mg/_uploads/files/fc3124e8b6610af6_251201_iphone17_deviceimg_main.png)](https://mineo.jp/device/iphone/iphone17-256gb-u/)
    
*   [AQUOS sense10 8GB/256GBモデル\
    \
    ![AQUOS sense10 8GB/256GBモデル](https://mineo.jp/_mg/_uploads/files/0f62204eba640b46_251113_%20aquossense10_deviceimg_main.png)](https://mineo.jp/device/smartphone/aquos-sense10-8gb-256gb/)
    
*   [motorola razr 60\
    \
    ![motorola razr 60](https://mineo.jp/_mg/_uploads/files/b3a189d8a78709f0_251113_%20motorolarazr60_deviceimg_main.png)](https://mineo.jp/device/smartphone/motorola-razr-60/)
    
*   [Xiaomi 15T Pro 12GB/256GBモデル\
    \
    ![Xiaomi 15T Pro 12GB/256GBモデル](https://mineo.jp/_mg/_uploads/files/9882ba25a2dc09f0_251009_xiaomi15tpro_deviceimg_main.png)](https://mineo.jp/device/smartphone/xiaomi-15t-pro-12gb-256gb/)
    
*   [Xperia 10 VII\
    \
    ![Xperia 10 VII](https://mineo.jp/_mg/_uploads/files/1414f8f9ba1d0afc_251009_xperia10vii_deviceimg_main.png)](https://mineo.jp/device/smartphone/xperia-10m7/)
    
*   [arrows Alpha\
    \
    ![arrows Alpha](https://mineo.jp/_mg/_uploads/files/f92c972da6140a01_250910_arrowsalpha_deviceimg_main.png)](https://mineo.jp/device/smartphone/arrows-alpha/)
    
*   [FS045W\
    \
    ![FS045W](https://mineo.jp/_mg/_uploads/files/a986a9c7c85b0b9c_250626_fs045w_deviceimg_main.png)](https://mineo.jp/device/other/fs045w/)
    
*   [Aterm MR51FN\
    \
    ![Aterm MR51FN](https://mineo.jp/_mg/_uploads/files/95fbe0a3c2ba0b71_aterm_mr51fn_178x160_rev01.png)](https://mineo.jp/device/other/aterm-mr51fn/)
    

![](https://mineo.jp/asset/img/common/slider/arrow_prev.png)

![](https://mineo.jp/asset/img/common/slider/arrow_next.png)

*   [スマートフォン](https://mineo.jp/device/smartphone/)
    
*   [iPhone](https://mineo.jp/device/iphone/)
    

[タブレット・ルーター](https://mineo.jp/device/other/)

POINT2

### 使い方に合わせて  
必要なサービス・オプション  
を追加できる！

さまざまなサービス・オプションをご用意。  
ご自身のスタイルに合ったものだけを  
お選びください。

*   短い通話が多い人におすすめ！  
    10分以内の国内通話なら誰とでも何度でもかけ放題！
    
    ![](https://mineo.jp/asset/img/top/feature_service_pic_01.png) [10分かけ放題](https://mineo.jp/service/voice/kakehoudai/)
    
*   ご自身で用意した端末が故障した場合も  
    故障端末の修理や交換用端末をご提供！
    
    ![](https://mineo.jp/asset/img/top/feature_service_pic_02.png) [持込み端末安心保証サービス](https://mineo.jp/service/safety/bring-devicewarranty/)
    

*   [10分かけ放題](https://mineo.jp/service/voice/kakehoudai/)
    
*   [持込み端末安心保証サービス](https://mineo.jp/service/safety/bring-devicewarranty/)
    

[他のサービス・オプションを見る](https://mineo.jp/service/)

はじめての格安スマホ  
（格安SIM）でも  
安心して  
ご利用いただけます！
------------------------------------------

POINT1

大手キャリアの通信設備を  
共用しているから  
つながりやすさも、  
使えるエリアも同じ！

![](https://mineo.jp/asset/img/top/beginner_area_pic_01.webp)

mineoはau/ドコモ/ソフトバンクの3キャリアに対応。  
ご利用中のキャリアと同じ通信プランを選べば使用感は変わらずにご利用いただけます。

POINT2

mineoは顧客満足度No.1！  
多くの方に選ばれています！

 ![サービス産業生産性協議会No.1 満足度（顧客満足） 企業・ブランドへの期待（顧客期待） コストパフォーマンス（知覚価値） 満足度4年連続1位受賞‼](https://mineo.jp/asset/img/top/sp/beginner_award_logo_04.png?v20250731)

出典元：  
2025年度JCSI（日本版顧客満足度指数）第1回調査

*   ○ 顧客満足:2022、2023、2024、2025年度 第1位
*   ○ 顧客期待:2022、2024、2025年度 第1位
*   ○ 知覚価値:2024、2025年度 第1位

[mineoが選ばれる理由を見る](https://mineo.jp/reason/)

POINT3

安心・充実のサポート体制！

*   ![](https://mineo.jp/asset/img/top/beginner_support_pic_01.png)
    
    オンラインチャットで  
    AIやオペレーターが  
    ご質問にお答えします。
    
    [オンラインチャットについて](https://mineo.jp/site/chat/)
    
*   ![](https://mineo.jp/asset/img/top/beginner_support_pic_02.png)
    
    店舗窓口は全国100店以上！  
    お気軽にご来店ください。
    
    [店舗でできること](https://mineo.jp/shop/about/)
    

*   [オンラインチャットについて](https://mineo.jp/site/chat/)
    
*   [店舗でできること](https://mineo.jp/shop/about/)
    

お申し込みは  
Web・電話・店舗でも

 ![](https://mineo.jp/asset/img/top/sp/beginner_apply_pic_01.png)

*   ### Web
    
    Webではいつでもお好きなときに  
    お申し込みができます。
    
    [Webで申し込む](https://mineo.jp/apply/)
    
*   ### 電話
    
    お電話でお申し込みを  
    ご希望の場合はこちら
    
    [電話で申し込む](https://support.mineo.jp/usqa/service/option/other/40033253_8863.html)
    

 ![](https://mineo.jp/asset/img/top/sp/beginner_apply_pic_02.png)

### 店舗

全国各地のmineoの店舗で新規  
お申し込みを受け付けております。

[店舗を探す](https://mineo.jp/shop/)

お申し込みはWebで行い、  
最短1時間後に店舗で受け取る  
こともできます。

[店舗でSIMを  \
受け取る](https://mineo.jp/shop/online/)

mineoユーザーの  
コミュニティサイト  
「マイネ王」
-------------------------------

格安スマホ（格安SIM）の  
わからないことは、  
先輩のmineoユーザーが  
助けてくれる！  
ここだけで見られるmineoの  
情報が盛りだくさん！

![](https://mineo.jp/asset/img/top/topics_pic_01.webp)

[マイネ王はじめてガイド](https://king.mineo.jp/beginner_guide.html)

### スタッフブログ

*   [![『OPPO A5 5G』『Mode1 Pocket 8GB/256GBモデル』を端末ラインアップに追加しました！](https://img.king.mineo.jp/system/magazine_images/images/000/001/727/653/M_image.jpg?1764578463)\
    \
    『OPPO A5 5G』『Mode1 Pocket 8GB/256GBモデル』を端末ラインアップに追加しました！](https://king.mineo.jp/staff_blogs/2978?utm_campaign=magazine_notification&utm_medium=timeline&utm_source=magazine)
    
*   [![【12月王国アイテム紹介】年明けから健康習慣をスタートしよう♪テーマ「健康志向」](https://img.king.mineo.jp/system/magazine_images/images/000/001/727/568/M_image.jpg?1764565699)\
    \
    【12月王国アイテム紹介】年明けから健康習慣をスタートしよう♪テーマ「健康志向」](https://king.mineo.jp/staff_blogs/3010?utm_campaign=magazine_notification&utm_medium=timeline&utm_source=magazine)
    
*   [![世界最小級ミニスマホ「Unihertz Jelly Star」を実機レビュー！指でつまめる小さいスマホ、日常でどこまで使える？](https://img.king.mineo.jp/system/magazine_images/images/000/001/721/275/M_image.jpg?1763362990)\
    \
    世界最小級ミニスマホ「Unihertz Jelly Star」を実機レビュー！指でつまめる小さいスマホ、日常でどこまで使える？](https://king.mineo.jp/staff_blogs/2972?utm_campaign=magazine_notification&utm_medium=timeline&utm_source=magazine)
    
*   [![2025年 オリコン顧客満足度®調査でmineoが格安SIM 総合第1位を獲得！！記念にご愛顧感謝パケット1GBをプレゼントします](https://img.king.mineo.jp/system/magazine_images/images/000/001/725/333/M_image.jpg?1764142937)\
    \
    2025年 オリコン顧客満足度®調査でmineoが格安SIM 総合第1位を獲得！！記念にご愛顧感謝パケット1GBをプレゼントします](https://king.mineo.jp/staff_blogs/2968?utm_campaign=magazine_notification&utm_medium=timeline&utm_source=magazine)
    
*   [![【スマホ端末プレゼント！】マイネ王AWARD 2025を開催します(12/12まで開催)](https://img.king.mineo.jp/system/magazine_images/images/000/001/724/925/M_image.jpg?1764056348)\
    \
    【スマホ端末プレゼント！】マイネ王AWARD 2025を開催します(12/12まで開催)](https://king.mineo.jp/staff_blogs/2967?utm_campaign=magazine_notification&utm_medium=timeline&utm_source=magazine)
    
*   [![スマホの容量不足は「外付けストレージ」で解決！ iPhoneのデータをSDカードに移してみた](https://img.king.mineo.jp/system/magazine_images/images/000/001/724/861/M_image.jpg?1764044916)\
    \
    スマホの容量不足は「外付けストレージ」で解決！ iPhoneのデータをSDカードに移してみた](https://king.mineo.jp/staff_blogs/2963?utm_campaign=magazine_notification&utm_medium=timeline&utm_source=magazine)
    
*   [![あったかアイテムプレゼント♪マイピタデータ容量増量記念！mineoでホクホクキャンペーン（12/10まで） ](https://img.king.mineo.jp/system/magazine_images/images/000/001/722/947/M_image.jpg?1763707258)\
    \
    あったかアイテムプレゼント♪マイピタデータ容量増量記念！mineoでホクホクキャンペーン（12/10まで）](https://king.mineo.jp/staff_blogs/2966?utm_campaign=magazine_notification&utm_medium=timeline&utm_source=magazine)
    
*   [![【mineo重大ニュース】マイピタのデータ容量が料金そのままで増量！パケット放題 Plusが増速！新サービス「パケット放題 1Mbps」が誕生！](https://img.king.mineo.jp/system/magazine_images/images/000/001/722/862/M_image.jpg?1763689040)\
    \
    【mineo重大ニュース】マイピタのデータ容量が料金そのままで増量！パケット放題 Plusが増速！新サービス「パケット放題 1Mbps」が誕生！](https://king.mineo.jp/staff_blogs/2964?utm_campaign=magazine_notification&utm_medium=timeline&utm_source=magazine)
    

![](https://mineo.jp/asset/img/common/slider/arrow_prev.png)

![](https://mineo.jp/asset/img/common/slider/arrow_next.png)

[一覧を見る](https://king.mineo.jp/magazines/special/)

お知らせ
----

*   [mineoからの  \
    お知らせ](https://mineo.jp/#news)
    
*   [障害情報](https://mineo.jp/#ac)
    
*   [メンテナンス  \
    情報](https://mineo.jp/#mt)
    

[2025年12月1日\
\
iPhone端末におけるiOS 26.1での動作確認結果のお知らせ](https://support.mineo.jp/news/1789/)
[2025年12月1日\
\
iPad端末におけるiPadOS 26.1での動作確認結果のお知らせ](https://support.mineo.jp/news/1788/)
[2025年11月30日\
\
2025年 オリコン顧客満足度（R）調査において、格安SIM 総合第1位を獲得しました！](https://support.mineo.jp/news/1787/)
[2025年11月30日\
\
【重要】ユニバーサルサービス料の改定について](https://support.mineo.jp/news/1786/)
[2025年11月27日\
\
新端末「OPPO A5 5G」「Mode1 Pocket 8GB/256GBモデル」の販売開始について](https://support.mineo.jp/news/1784/)

現在、mineoからのお知らせはありません。

読み込みに失敗しました。ページを更新してください。

[mineoからのお知らせ一覧](https://support.mineo.jp/news_list/)

[2025年12月1日\
\
mineoサービスのシステム処理遅延のお知らせ(復旧報)](https://support.mineo.jp/ac/1503/)
[2025年10月27日\
\
Aプラン国際ローミングサービスにおける音声通話発信不可について(復旧報)](https://support.mineo.jp/ac/1501/)
[2025年10月7日\
\
【応急復旧】２０２４年０９月２１日 ｍｉｎｅｏ設備障害発生のお知らせとお詫び（第４２８報：２０２５年１０月０８日１０時現在）](https://support.mineo.jp/ac/1500/)
[2025年10月1日\
\
パケットシェアの処理遅延事象について(復旧報)](https://support.mineo.jp/ac/1498/)
[2025年9月19日\
\
2025年9月19日ＤプランのeSIMお申し込み不具合復旧のお知らせとお詫び(復旧報)](https://support.mineo.jp/ac/1496/)
[2025年8月29日\
\
２０２５年８月３０日SoftbankとのMNP回線切替の障害発生のお知らせとお詫び](https://support.mineo.jp/ac/1492/)
[2025年8月14日\
\
２０２５年０８月１１日 ｍｉｎｅｏ設備障害復旧のお知らせとお詫び](https://support.mineo.jp/ac/1491/)
[2025年8月12日\
\
２０２５年０８月１１日 ｍｉｎｅｏ設備障害復旧のお知らせとお詫び](https://support.mineo.jp/ac/1486/)
[2025年8月7日\
\
２０２５年０８月０８日 ｍｉｎｅｏ設備障害復旧のお知らせとお詫び](https://support.mineo.jp/ac/1475/)
[2025年7月24日\
\
mineoマイページへログイン、新規お申し込みがご利用不可（復旧報）](https://support.mineo.jp/ac/1473/)
[2025年6月25日\
\
2025年06月26日 (Aプラン)ｍｉｎｅｏ設備障害復旧のお知らせとお詫び](https://support.mineo.jp/ac/1472/)
[2025年6月7日\
\
２０２５年６月８日　メールサービスの障害復旧のお知らせとお詫び](https://support.mineo.jp/ac/1471/)
[2025年2月18日\
\
【重要】mineoアプリご利用不可（復旧報）](https://support.mineo.jp/ac/1466/)
[2025年1月12日\
\
２０２５年 ０１月 １３日 弊社ホームページ（https://mineo.jp/）障害復旧のお知らせとお詫び](https://support.mineo.jp/ac/1372/)

現在、障害情報はありません。

読み込みに失敗しました。ページを更新してください。

[障害・メンテナンス情報一覧](https://support.mineo.jp/mt_ac_list/)

[2025年12月1日\
\
2025/12/09 2025年12月9日システムメンテナンスに伴う一部サービスの停止について](https://support.mineo.jp/mt/2271/)

現在、メンテナンス情報はありません。

読み込みに失敗しました。ページを更新してください。

[障害・メンテナンス情報一覧](https://support.mineo.jp/mt_ac_list/)

よくあるご質問
-------

格安スマホ（格安SIM）とは？なぜ安いの？

格安スマホ（格安SIM）とは、大手通信キャリアと比べて安い料金で利用できるSIMカードやeSIM、スマートフォンの総称で、主にMVNOから提供されている通信サービスのことを指します。毎月のスマホ料金が安くなる人も多いため、大手キャリアから乗り換えている人が増えています。  
  
具体的には、以下のような方法でコストが抑えられています。

*   ・基地局などの通信設備を大手通信キャリアから借りることで設備投資を減らす
*   ・テレビCMなどの広告宣伝にあまり費用をかけない

![](https://mineo.jp/asset/img/beginner/faq_pic_02.png)

他社から乗り換える場合、いつから使えるようになるの？

お申し込み完了後、最短で翌日発送にてSIMカードをお届けします。  
SIMカードをスマートフォンに挿入し、初期設定を行った時点で利用できるようになります。

MNPの手続き方法を知りたい

MNPを行う際の手続きについては以下の方法があります。

*   ・MNP予約番号を取得して申し込みを行う。  
    ご利用中の携帯電話会社にMNP予約番号を発行してもらう必要があります。  
    詳細は[こちら](https://mineo.jp/apply/mnp-reserve/)
    
*   ・MNPワンストップでのお手続き。（MNP予約番号をお持ちでない場合）  
    MNPワンストップ対象携帯電話会社からMNPを行う場合、MNPワンストップでのお手続きが可能です。  
    詳細は[こちら](https://mineo.jp/apply/mnp-onestop/)
    

解約時に手数料はかかるの？

解約時の手数料は発生しません。他社へ乗り換える場合も無料です。  
最低利用期間もありませんので、ご安心ください。

[もっと見る](https://support.mineo.jp/usqa/)

お役立ちコラム
-------

*   [![データ容量の目安とは](https://mineo.jp/asset/img/top/column_bnr_speed.webp)\
    \
    #### スマホが遅い！通信速度の目安やすぐ試せる速度改善策を解説\
    \
    掲載日：2025年5月8日](https://mineo.jp/column/speed/)
    
*   [![データ容量の目安とは](https://mineo.jp/asset/img/top/column_bnr_data.webp)\
    \
    #### データ容量の目安を解説！何ギガを選ぶべき？\
    \
    掲載日：2025年2月21日](https://mineo.jp/column/data/)
    
*   [![スマホの寿命とは](https://mineo.jp/asset/img/top/column_bnr_lifespan.webp)\
    \
    #### スマホの寿命はどれくらい？買い替えのタイミングや劣化を防ぐ方法を紹介\
    \
    掲載日：2025年2月21日](https://mineo.jp/column/lifespan/)
    
*   [![データ移行とは](https://mineo.jp/asset/img/top/column_bnr_transfer.webp)\
    \
    #### 【機種変更】スマホのデータ移行を解説！LINEの引き継ぎ方法も紹介\
    \
    掲載日：2025年2月21日](https://mineo.jp/column/transfer/)
    
*   [![Wi-fiにつながらない対処法とは](https://mineo.jp/asset/img/top/column_bnr_nosignal.webp)\
    \
    #### スマホがWi-Fiにつながらない！原因特定と対処法を解説\
    \
    掲載日：2025年2月21日](https://mineo.jp/column/nosignal/)
    
*   [![cookieとは](https://mineo.jp/asset/img/top/column_bnr_cookie.webp)\
    \
    #### Cookieとは？同意しないとどうなる？仕組みやメリット、削除方法を解説\
    \
    掲載日：2025年2月21日](https://mineo.jp/column/cookie/)
    
*   [![eSIMとは](https://mineo.jp/asset/img/top/column_bnr_esim.webp)\
    \
    #### eSIMとは？特長やメリット・デメリット、SIMカードとの違いを解説\
    \
    掲載日：2023年12月15日](https://mineo.jp/column/esim/)
    
*   [![MNPとは](https://mineo.jp/asset/img/top/column_bnr_mnp.webp)\
    \
    #### MNP（ナンバーポータビリティ）の仕組みとは？通信キャリアを変えても電話番号はそのまま使えるサービスを解説\
    \
    掲載日：2023年12月15日](https://mineo.jp/column/mnp/)
    
*   [![テザリングとは](https://mineo.jp/asset/img/top/column_bnr_tethering.webp)\
    \
    #### テザリングの利用手順を分かりやすく解説\
    \
    掲載日：2023年12月15日](https://mineo.jp/column/tethering/)
    
*   [![5Gとは](https://mineo.jp/asset/img/top/column_bnr_5g.webp)\
    \
    #### 5G（次世代高速通信）が私たちの生活を変える！？\
    \
    掲載日：2023年3月30日](https://mineo.jp/column/5g/)
    
*   [![SIMロックとは](https://mineo.jp/asset/img/top/column_bnr_simlock.webp)\
    \
    #### SIMロックの仕組みとSIMロック解除（SIMフリー）の方法\
    \
    掲載日：2023年3月30日](https://mineo.jp/column/simlock/)
    
*   [![格安SIMとは](https://mineo.jp/asset/img/top/column_bnr_lowcost-sim.webp)\
    \
    #### 格安SIMの安さの理由とおすすめしたい人の特長\
    \
    掲載日：2023年3月30日](https://mineo.jp/column/lowcost-sim/)
    
*   [![格安スマホとは](https://mineo.jp/asset/img/top/column_bnr_lowcost-mobile.webp)\
    \
    #### 格安スマホの良いところ・悪いところ\
    \
    掲載日：2023年3月30日](https://mineo.jp/column/lowcost-mobile/)
    
*   [![MVNOとは](https://mineo.jp/asset/img/top/column_bnr_mvno.webp)\
    \
    #### MVNOとは？大手キャリアとの違いって？\
    \
    掲載日：2023年3月30日](https://mineo.jp/column/mvno/)
    

![](https://mineo.jp/asset/img/common/slider/arrow_prev.png)

![](https://mineo.jp/asset/img/common/slider/arrow_next.png)

[一覧を見る](https://mineo.jp/column/)

*   [キャンペーン](https://mineo.jp/campaign/)
    
*   [特集](https://mineo.jp/special/)
    

[![通信サービス品質確保の取り組み](https://mineo.jp/asset/img/top/bnr_annotation.png)](https://support.mineo.jp/news/685/)

法人でもmineo！

 [![会社の通信費をおトクに モバイルワークにもおすすめ 最大1,000回線でデータ容量を分け合える！](https://mineo.jp/asset/img/top/sp/bnr_biz.webp)](https://mineo.jp/r/biz/link_banner.html)

さあ、mineoをはじめよう！
---------------

*    [![](https://mineo.jp/asset/img/common/conversion_icon_apply.png) mineoに申し込む](https://mineo.jp/apply/)
    
*    [![](https://mineo.jp/asset/img/common/conversion_icon_sim.png) 料金をシミュレーションする](https://mineo.jp/simulator/)
    

*   [![facebook](https://mineo.jp/asset/img/common/template/icon_sns_fb.png)](https://www.facebook.com/mineo.jp)
    
*   [![LINE](https://mineo.jp/asset/img/common/template/icon_sns_ln.png)](https://line.me/R/ti/p/%40pdp9012a)
    
*   [![X](https://mineo.jp/asset/img/common/template/icon_sns_x.png)](https://twitter.com/mineojp)
    
*   [![YouTube](https://mineo.jp/asset/img/common/template/icon_sns_yt.png)](https://www.youtube.com/user/mineoofficial)
    
*   [![Instagram](https://mineo.jp/asset/img/common/template/icon_sns_ig.png)](https://www.instagram.com/mineo_jp/)
    

[![格安SIM・格安スマホのmineo](https://mineo.jp/asset/img/common/template/logo_mineo.png)](https://mineo.jp/)

*   mineoの特長
    
    *   [はじめての方へ](https://mineo.jp/beginner/)
        
    *   [mineoが選ばれる理由](https://mineo.jp/reason/)
        
    *   [ブランドステートメント](https://mineo.jp/brand/)
        
    
    料金・サービス
    
    *   [料金表](https://mineo.jp/price/)
        
    *   [サービス・オプション一覧](https://mineo.jp/service/)
        
    *   [かんたん料金シミュレーション](https://mineo.jp/simulator/)
        
    
*   端末
    
    *   [mineoで使う端末を選ぶ](https://mineo.jp/device/about/)
        
    *   mineoで端末を買う
    *   [iPhone](https://mineo.jp/device/iphone/)
        
    *   [スマートフォン](https://mineo.jp/device/smartphone/)
        
    *   [タブレット・ルーター](https://mineo.jp/device/other/)
        
    *   お手持ちの端末を使う
    *   [動作確認済み端末検索](https://mineo.jp/device/devicelist/)
        
    
    店舗
    
    *   [店舗を探す](https://mineo.jp/shop/)
        
    *   [店舗でできること](https://mineo.jp/shop/about/)
        
    *   [店舗でSIMを受け取る](https://mineo.jp/shop/online/counter/)
        
    
*   申込ガイド
    
    *   準備からお申し込みの流れ
    *   [お手持ちの端末をそのまま使う方](https://mineo.jp/apply/simonly-flow/)
        
    *   [mineoで端末も一緒に買いたい方](https://mineo.jp/apply/device-flow/)
        
    *   SIMカードや端末が届いたら
    *   [初期設定～ご利用開始の流れ](https://mineo.jp/apply/setup-flow/)
        
    
    サポート
    
    *   [ユーザーサポート](https://support.mineo.jp/)
        
    *   [初期設定・各種設定](https://support.mineo.jp/setup/guide/)
        
    *   [よくあるご質問](https://support.mineo.jp/usqa/)
        
    *   [AIチャットサポート](https://mineo.jp/r/mai_chat/)
        
    *   [お問い合わせ](https://support.mineo.jp/inquiry.html)
        
    
*   コミュニティ
    
    *   [マイネ王サイト](https://king.mineo.jp/)
        
    *   [マイネ王はじめてガイド](https://king.mineo.jp/beginner_guide.html)
        
    *   おすすめコンテンツ
    *   [レビュー](https://king.mineo.jp/reviews/)
        
    *   [Q&A](https://king.mineo.jp/question-answer/)
        
    *   [アイデアファーム](https://king.mineo.jp/ideas/)
        
    *   [フリータンク](https://king.mineo.jp/freetank/)
        
    

*   *   [![](https://mineo.jp/asset/img/common/template/icon_mypage.png)マイページ](https://my.mineo.jp/)
        
    *     [![](https://mineo.jp/asset/img/common/template/icon_apply_wh.png) ![](https://mineo.jp/asset/img/common/template/icon_apply_pink.png)お申し込み](https://mineo.jp/apply/)
        
*   *   [法人のお客さま](https://mineo.jp/r/biz/link_footer.html)
        
    *   [お知らせ](https://mineo.jp/#info)
        
    *   [キャンペーン](https://mineo.jp/campaign/)
        
    *   [特集](https://mineo.jp/special/)
        

     ![検索](https://mineo.jp/asset/img/common/icon_search.png)

記載の価格は税抜記載のものを除き税込です。税込価格は2021年4月1日現在の税率（10%）に基づく金額です。税率に応じて金額は変更されます。

[![株式会社オプテージ](https://mineo.jp/asset/img/common/template/logo_optage.png)](https://optage.co.jp/)

*   [第三者認証](https://optage.co.jp/company/authorization/safesecurityisp.html)
    
*   [情報セキュリティポリシー](https://optage.co.jp/info/security.html)
    
*   [プライバシーポリシー](https://optage.co.jp/info/privacy/)
    
*   [Cookie等の外部送信について](https://optage.co.jp/info/informative.html)
    
*   [サイトのご利用にあたって](https://mineo.jp/site/terms/)
    
*   [特定商取引法に基づく表示](https://mineo.jp/site/law/)
    
*   [ユニバーサルサービス料について](https://optage.co.jp/info/universal.html)
    
*   [電話リレーサービス料について](https://optage.co.jp/info/telephonerelay.html)
    
*   [企業情報](https://optage.co.jp/company/)
    
*   [古物営業法に基づく表示](https://optage.co.jp/company/authorization/)
    

© OPTAGE Inc.

![](https://acv.mira-dsp.com/v1/image?tag_id=9060bb35-fbb5-484f-8045-5cd2db32902c)
