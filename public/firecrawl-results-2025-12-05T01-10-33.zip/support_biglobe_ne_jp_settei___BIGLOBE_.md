# 各種設定方法：BIGLOBE会員サポート

URL: https://support.biglobe.ne.jp/settei/

---

*   サービス
    
    サービス
    
    *   [![BIGLOBE光](https://top.bcdn.jp/images/ImgService-1.png)](https://join.biglobe.ne.jp/ftth/hikari/?cl=global_header_hikari_logo)
        
    *   [![BIGLOBE mobile](https://top.bcdn.jp/images/ImgService-2.png)](https://join.biglobe.ne.jp/mobile/?cl=global_header_mobile_logo)
        
    *   [![BIGLOBE WiMAX](https://top.bcdn.jp/images/ImgService-3.png)](https://join.biglobe.ne.jp/mobile/wimax/?cl=global_header_wimax_logo)
        
    *   [![BIGLOBE biz](https://top.bcdn.jp/images/ImgService-4.png)](https://biz.biglobe.ne.jp/index.html)
        
    
    通信サービス
    
    *   [BIGLOBE光](https://join.biglobe.ne.jp/ftth/hikari/?cl=global_header_hikari_text)
        
    *   [auひかり](https://join.biglobe.ne.jp/ftth/one/?cl=global_header_one_text)
        
    *   [BIGLOBEモバイル](https://join.biglobe.ne.jp/mobile/?cl=global_header_mobile_text)
        
    *   [BIGLOBE WiMAX](https://join.biglobe.ne.jp/mobile/wimax/?cl=global_header_wimax_text)
        
    
    オプションサービス
    
    *   [お助けサポート＋](https://otasuke.biglobe.ne.jp/otasuke_plus/)
        
    *   [インターネット端末保証サービス](https://service.biglobe.ne.jp/internethosho/)
        
    *   [トータル・ネットセキュリティ](https://security.biglobe.ne.jp/tns/)
        
    *   [U-NEXT for BIGLOBE](https://vod.biglobe.ne.jp/unext/)
        
    *   [その他オプション](https://service.biglobe.ne.jp/)
        
    
    Webメディア
    
    *   [温泉大賞](https://biz.biglobe.ne.jp/onsen/award/)
        
    *   [しむぐらし](https://join.biglobe.ne.jp/mobile/sim/gurashi/)
        
    *   [あしたメディア](https://ashita.biglobe.co.jp/)
        
    
    法人のお客さま
    
    *   [BIGLOBE biz.](https://biz.biglobe.ne.jp/index.html)
        
    
*   企業情報
    
    企業情報
    
    *   [![](https://top.bcdn.jp/images/ImgCompany-1.png)\
        \
        企業情報トップ](https://www.biglobe.co.jp/outline)
        
    *   [![](https://top.bcdn.jp/images/ImgCompany-2.png)\
        \
        採用情報](https://www.biglobe.co.jp/recruit)
        
    *   [![](https://top.bcdn.jp/images/ImgCompany-3.png)\
        \
        ブランド](https://www.biglobe.co.jp/outline/brand)
        
    
*   [](https://mypage.sso.biglobe.ne.jp/?cl=global_header_mypage)
    

[](https://support.biglobe.ne.jp/settei/)

 [![BIGLOBE 会員サポート](https://support.biglobe.ne.jp/v3/image/common/logo_support_pc.svg)](https://support.biglobe.ne.jp/)

 

*    
    
*   [トップ](https://support.biglobe.ne.jp/?cl=head_support_top)
    
*   設定方法
    
    *   [インターネット接続設定](https://support.biglobe.ne.jp/settei/setuzoku/?cl=head_support_setuzoku)
        
    *   [IPv6オプション設定](https://support.biglobe.ne.jp/settei/setuzoku/ipv6/?cl=head_support_setipv6)
        
    *   [無線LANの接続設定](https://support.biglobe.ne.jp/settei/setuzoku/musenlan/?cl=head_support_musenlan)
        
    *   [光回線の速度改善](https://support.biglobe.ne.jp/speed/?cl=head_support_speed)
        
    *   [BIGLOBEモバイル接続設定](https://support.biglobe.ne.jp/settei/setuzoku/lte/?cl=head_support_setlte)
        
    *   [メールの設定](https://support.biglobe.ne.jp/settei/mailinfo/?cl=head_support_mailinfo)
        
    *   [ブラウザの設定](https://support.biglobe.ne.jp/settei/browser/?cl=head_support_browser)
        
*   各種手続き
    
    *   [BIGLOBE ID・パスワード](https://support.biglobe.ne.jp/jimu/idpw/)
        
    *   [au ID・パスワード](https://support.biglobe.ne.jp/jimu/idpw/auid.html?cl=head_support_auid)
        
    *   [住所・電話番号の確認／変更](https://support.biglobe.ne.jp/jimu/keiyaku/jimuchg.html?cl=head_support_jimuchg)
        
    *   [お支払い方法の登録／確認／変更](https://support.biglobe.ne.jp/jimu/keiyaku/paychg/?cl=head_support_paychg)
        
    *   [メール・SMS受取設定の確認／変更](https://support.biglobe.ne.jp/jimu/keiyaku/osirasemail.html?cl=head_support_osirasemail)
        
    *   [家族会員サービス](https://support.biglobe.ne.jp/family/?cl=head_support_family)
        
    *   [契約コースの変更／タイプ変更](https://support.biglobe.ne.jp/jimu/keiyaku/coursechg.html?cl=head_support_coursechg)
        
    *   [BIGLOBEメールアドレスの取得／変更](https://support.biglobe.ne.jp/jimu/keiyaku/mailaccount.html?cl=head_support_mailaccount)
        
    *   [各種手続き一覧](https://support.biglobe.ne.jp/jimu/?cl=head_support_jimu)
        
*   料金・特典
    
    *   [利用明細の確認](https://support.biglobe.ne.jp/jimu/meisai/?cl=head_support_meisai)
        
    *   [接続コース料金表](https://support.biglobe.ne.jp/jimu/ryokin/?cl=head_support_ryokin)
        
    *   [キャッシュバック特典受取](https://support.biglobe.ne.jp/jimu/keiyaku/paychg/kouza_cashback.html?cl=head_support_cashback)
        
    *   [会員特典](https://mypage.sso.biglobe.ne.jp/member/longterm)
        
    *   [Gポイント](https://mypage.sso.biglobe.ne.jp/member/gpoint)
        
*   お知らせ
    
    *   [緊急/災害情報](https://support.biglobe.ne.jp/saigai/?cl=head_support_saigai)
        
    *   [運用/障害情報](https://support.biglobe.ne.jp/shogaiap/?cl=head_support_shogai)
        
    *   [メンテナンス情報](https://support.biglobe.ne.jp/menteap/?cl=head_support_mente)
        
    *   [お知らせ一覧](https://support.biglobe.ne.jp/news/?cl=head_support_news)
        
*   [よくある質問](https://faq.support.biglobe.ne.jp/?cl=head_support_faq)
    
*   [お問い合わせ](https://support.biglobe.ne.jp/ask/?cl=head_support_ask)
    

1.  [TOP](https://support.biglobe.ne.jp/)
    
2.  各種設定方法
    ======
    

解決ナンバー：60002

各種設定方法

インターネット接続設定
-----------

[![](https://support.biglobe.ne.jp/v3/image/icon/big-icon-pc.svg)\
\
インターネットの接続](https://support.biglobe.ne.jp/settei/setuzoku/)
[![](https://support.biglobe.ne.jp/v3/image/icon/big-icon-wifi.svg)\
\
無線LANの接続設定(宅内)](https://support.biglobe.ne.jp/settei/setuzoku/musenlan/)
[![](https://support.biglobe.ne.jp/v3/image/connect/common/mv-image-50.png)\
\
光回線の速度を  \
最大限に引き出すには](https://support.biglobe.ne.jp/speed/)

モバイル接続設定
--------

[![](https://support.biglobe.ne.jp/v3/image/icon/big-icon-mobile.svg)\
\
BIGLOBEモバイル接続設定](https://support.biglobe.ne.jp/settei/setuzoku/lte/)

メール・ブラウザ設定
----------

[![](https://support.biglobe.ne.jp/v3/image/icon/big-icon-mail.svg)\
\
メールの設定](https://support.biglobe.ne.jp/settei/mailinfo/)
[![](https://support.biglobe.ne.jp/v3/image/icon/big-icon-browser.svg)\
\
ブラウザの設定](https://support.biglobe.ne.jp/settei/browser/)

[ページトップへ](https://support.biglobe.ne.jp/settei/#)

[サイトマップ](https://support.biglobe.ne.jp/sitemap/)

[](https://www.biglobe.ne.jp/bipple/)

[](https://www.biglobe.ne.jp/)

*   [](https://twitter.com/biglobe)
    
*   [](https://www.instagram.com/biglobe_official/)
    
*   [](https://www.facebook.com/BIGLOBE)
    
*   [](https://www.youtube.com/user/BIGLOBEchannel)
    

個人のお客さま

通信サービス

*   [BIGLOBE光](https://join.biglobe.ne.jp/ftth/hikari/?cl=global_footer_hikari)
    
*   [auひかり](https://join.biglobe.ne.jp/ftth/one/?cl=global_footer_one)
    
*   [BIGLOBEモバイル](https://join.biglobe.ne.jp/mobile/?cl=global_footer_mobile)
    
*   [BIGLOBE WiMAX](https://join.biglobe.ne.jp/mobile/wimax/?cl=global_footer_wimax)
    

オプションサービス

*   [お助けサポート＋](https://otasuke.biglobe.ne.jp/otasuke_plus/)
    
*   [インターネット端末保証サービス](https://service.biglobe.ne.jp/internethosho/)
    
*   [トータル・ネットセキュリティ](https://security.biglobe.ne.jp/tns/)
    
*   [U-NEXT for BIGLOBE](https://vod.biglobe.ne.jp/unext/)
    
*   [その他オプション](https://service.biglobe.ne.jp/)
    

Webメディア

*   [温泉大賞](https://biz.biglobe.ne.jp/onsen/award/)
    
*   [しむぐらし](https://join.biglobe.ne.jp/mobile/sim/gurashi/)
    
*   [あしたメディア](https://ashita.biglobe.co.jp/)
    

法人のお客さま

*   [BIGLOBE biz.](https://biz.biglobe.ne.jp/index.html)
    
*   [BIGLOBE光](https://biz.biglobe.ne.jp/hikari/index.html)
    
*   [フレッツ光](https://biz.biglobe.ne.jp/flets/index.html)
    
*   [プロバイダサービス](https://biz.biglobe.ne.jp/member/office/provider.html)
    
*   [光回線用 固定IPアドレス](https://biz.biglobe.ne.jp/ip/index.html)
    
*   [BIGLOBEモバイル](https://biz.biglobe.ne.jp/sim/index.html)
    
*   [BIGLOBE WiMAX](https://biz.biglobe.ne.jp/wimax/index.html)
    
*   [IPトランジット](https://biz.biglobe.ne.jp/transit/index.html)
    
*   [マカフィー®マルチ アクセス](https://biz.biglobe.ne.jp/mma/index.html)
    
*   [法人向け独自ドメイン](https://biz.biglobe.ne.jp/domain/index.html)
    
*   [ONSENWORK](https://workation.biglobe.ne.jp/onsen/)
    

企業情報

*   [企業情報](https://www.biglobe.co.jp/outline)
    
*   [トップメッセージ](https://www.biglobe.co.jp/outline/message)
    
*   [ブランド](https://www.biglobe.co.jp/outline/brand)
    
*   [サステナビリティ](https://www.biglobe.co.jp/sustainability)
    
*   [ニュース](https://www.biglobe.co.jp/pressroom)
    
*   [採用情報](https://www.biglobe.co.jp/recruit)
    
*   [BIGLOBE Style](https://style.biglobe.co.jp/)
    
*   [ソーシャルメディア](https://www.biglobe.co.jp/social)
    

ご利用中の方

*   [マイページ](https://mypage.sso.biglobe.ne.jp/?cl=global_footer_mypage)
    
*   [メール](https://auth.sso.biglobe.ne.jp/mail/?cl=global_footer_mail)
    
*   [会員サポート](https://support.biglobe.ne.jp/?cl=global_footer_support)
    

*   [お問い合わせ](https://www.biglobe.co.jp/inquire)
    
*   [消費税の表示](https://support.biglobe.ne.jp/salestax.html)
    
*   [ウェブアクセシビリティの取り組み](https://support.biglobe.ne.jp/accessibility/)
    
*   [個人情報保護ポリシー](https://www.biglobe.ne.jp/privacy.html)
    
*   [プライバシーポータル](https://www.biglobe.ne.jp/privacy-portal.html)
    
*   [Cookieポリシー](https://www.biglobe.ne.jp/cookie.html)
    
*   [特定商取引法に基づく表記](https://support.biglobe.ne.jp/tokusyo.html)
    
*   [古物営業法に基づく表記](https://support.biglobe.ne.jp/kobutsusyo.html)
    
*   [情報セキュリティ基本方針](https://www.biglobe.co.jp/security)
    
*   [商標について](https://join.biglobe.ne.jp/trademark/)
    
*   [BIGLOBEトップ](https://www.biglobe.ne.jp/)
    

[![プライバシーマーク](https://top.bcdn.jp/images/PrivacyMark.png)](https://privacymark.jp/)

[![セキュリティ認証](https://top.bcdn.jp/images/ISP.png)](https://www.biglobe.ne.jp/safesecurity.html)

[![ETOCマーク](https://top.bcdn.jp/images/ETOC.png)](https://www.etoc.jp/elite/0037)

Copyright ©BIGLOBE Inc. 2025. All rights reserved.
