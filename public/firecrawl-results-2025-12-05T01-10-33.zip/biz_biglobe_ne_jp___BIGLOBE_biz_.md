# 【公式】BIGLOBE biz. | ビッグローブの法人向けサービス

URL: https://biz.biglobe.ne.jp/

---

*   [個人のお客さま](https://join.biglobe.ne.jp/)
    

*   [お役立ち資料](https://biz.biglobe.ne.jp/catalog/index.html?click=gronavi_catalog)
    

ログイン

*   [BIGLOBEオフィスサービス](https://biz-mypage.sso.biglobe.ne.jp/mng/top)
    
*   [BIGLOBEメール](https://webmail.biglobe.ne.jp/)
    
*   [クラウドホスティング](https://biz.biglobe.ne.jp/hosting/login/index.html)
    

[](https://biz.biglobe.ne.jp/search.html?site=49IDH818&group=0&summary=200&start=0)

[ビッグローブの法人向けサービス ![BIGLOBE biz.](https://biz.biglobe.ne.jp/common/esiqtd00000000b3-img/esiqtd00000006o8.svg)](https://biz.biglobe.ne.jp/index.html)
 
=====================================================================================================================================================

 

*   サービス・製品
    
    *   光回線
        *   [BIGLOBE光](https://biz.biglobe.ne.jp/hikari/index.html)
            
        *   [BIGLOBE光 10ギガ](https://biz.biglobe.ne.jp/hikari/10g.html)
            
        *   [フレッツ光](https://biz.biglobe.ne.jp/flets/index.html)
            
        *   [プロバイダのみ契約](https://biz.biglobe.ne.jp/member/office/provider.html)
            
        *   [光回線用 固定IP](https://biz.biglobe.ne.jp/ip/index.html)
            
        *   [マンション向け無料インターネット](https://biz.biglobe.ne.jp/mansion_isp/index.html)
            
        *   [マンションISP事業者向け(IPIP)](https://biz.biglobe.ne.jp/mansion_isp/ipip.html)
            
        *   [光回線のサービスマップ](https://biz.biglobe.ne.jp/hikari/ftth_sitemap.html)
            
    *   モバイル
        *   [BIGLOBEモバイル](https://biz.biglobe.ne.jp/sim/index.html)
            
        *   [BIGLOBEモバイル 音声通話SIM](https://biz.biglobe.ne.jp/sim/call.html)
            
        *   [IoT・M2M向けモバイル回線](https://biz.biglobe.ne.jp/sim/iot-m2m.html)
            
        *   [WiMAX +5G](https://biz.biglobe.ne.jp/wimax/index.html)
            
    *   ネットワーク・VPN
        *   [IPトランジット](https://biz.biglobe.ne.jp/transit/index.html)
            
        *   [Flow分析プラットフォームサービス](https://biz.biglobe.ne.jp/flow/index.html)
            
    *   ホスティング
        *   [クラウドホスティング](https://biz.biglobe.ne.jp/hosting/index.html)
            
    *   ホームページ・マーケティング
        *   [クラウド型CMS](https://biz.biglobe.ne.jp/cms/index.html)
            
        *   [ホームページ制作ツール](https://biz.biglobe.ne.jp/fc/index.html)
            
    *   業務効率化
        *   [クラウドストレージ](https://biz.biglobe.ne.jp/storage/index.html)
            
        *   [法人向け独自ドメイン](https://biz.biglobe.ne.jp/domain/index.html)
            
        *   [DNSマネージャ](https://biz.biglobe.ne.jp/domain/dns/index.html)
            
    *   セキュリティ
        *   [MDM「OPTiM Biz」](https://biz.biglobe.ne.jp/mdm/index.html)
            
        *   [マカフィー® マルチ アクセス](https://biz.biglobe.ne.jp/mma/index.html)
            
        *   [メールウィルスチェックプラス](https://email.biglobe.ne.jp/vcheck/index.html)
            
        *   [迷惑メールブロックサービス](https://email.biglobe.ne.jp/spam/index.html)
            
    *   メールソリューション
        *   [BIGLOBEメール](https://biz.biglobe.ne.jp/bmail/index.html)
            
        *   [独自ドメインメール](https://biz.biglobe.ne.jp/domain/mail/index.html)
            
        *   [迷惑メールブロック](http://email.biglobe.ne.jp/spam/index.html)
            
    *   その他
        *   [BIGLOBEオフィスサービス](https://biz.biglobe.ne.jp/member/office/index.html)
            
        *   [料金制選択コース](https://biz.biglobe.ne.jp/member/ryokinsei/index.html)
            
    
    *   [BIGLOBE光](https://biz.biglobe.ne.jp/hikari/index.html)
        
    *   [BIGLOBE光 10ギガ](https://biz.biglobe.ne.jp/hikari/10g.html)
        
    *   [フレッツ光](https://biz.biglobe.ne.jp/flets/index.html)
        
    *   [プロバイダのみ契約](https://biz.biglobe.ne.jp/member/office/provider.html)
        
    *   [光回線用 固定IP](https://biz.biglobe.ne.jp/ip/index.html)
        
    *   [マンション向け無料インターネット](https://biz.biglobe.ne.jp/mansion_isp/index.html)
        
    *   [マンションISP事業者向け(IPIP)](https://biz.biglobe.ne.jp/mansion_isp/ipip.html)
        
    *   [光回線のサービスマップ](https://biz.biglobe.ne.jp/hikari/ftth_sitemap.html)
        
    
    *   [BIGLOBEモバイル](https://biz.biglobe.ne.jp/sim/index.html)
        
    *   [BIGLOBEモバイル 音声通話SIM](https://biz.biglobe.ne.jp/sim/call.html)
        
    *   [IoT・M2M向けモバイル回線](https://biz.biglobe.ne.jp/sim/iot-m2m.html)
        
    *   [WiMAX +5G](https://biz.biglobe.ne.jp/wimax/index.html)
        
    
    *   [IPトランジット](https://biz.biglobe.ne.jp/transit/index.html)
        
    *   [Flow分析プラットフォームサービス](https://biz.biglobe.ne.jp/flow/index.html)
        
    
    *   [クラウドホスティング](https://biz.biglobe.ne.jp/hosting/index.html)
        
    
    *   [クラウド型CMS](https://biz.biglobe.ne.jp/cms/index.html)
        
    *   [ホームページ制作ツール](https://biz.biglobe.ne.jp/fc/index.html)
        
    
    *   [クラウドストレージ](https://biz.biglobe.ne.jp/storage/index.html)
        
    *   [法人向け独自ドメイン](https://biz.biglobe.ne.jp/domain/index.html)
        
    *   [DNSマネージャ](https://biz.biglobe.ne.jp/domain/dns/index.html)
        
    
    *   [MDM「OPTiM Biz」](https://biz.biglobe.ne.jp/mdm/index.html)
        
    *   [マカフィー® マルチ アクセス](https://biz.biglobe.ne.jp/mma/index.html)
        
    *   [メールウィルスチェックプラス](https://email.biglobe.ne.jp/vcheck/index.html)
        
    *   [迷惑メールブロックサービス](https://email.biglobe.ne.jp/spam/index.html)
        
    
    *   [BIGLOBEメール](https://biz.biglobe.ne.jp/bmail/index.html)
        
    *   [独自ドメインメール](https://biz.biglobe.ne.jp/domain/mail/index.html)
        
    *   [迷惑メールブロック](http://email.biglobe.ne.jp/spam/index.html)
        
    
    *   [BIGLOBEオフィスサービス](https://biz.biglobe.ne.jp/member/office/index.html)
        
    *   [料金制選択コース](https://biz.biglobe.ne.jp/member/ryokinsei/index.html)
        
    
*   目的・テーマから探す
    
    *   インターネットを使いたい
        *   [BIGLOBE光](https://biz.biglobe.ne.jp/hikari/index.html)
            
        *   [BIGLOBE光10ギガ](https://biz.biglobe.ne.jp/hikari/10g.html)
            
        *   [フレッツ光](https://biz.biglobe.ne.jp/flets/index.html)
            
        *   [プロバイダのみの契約](https://biz.biglobe.ne.jp/member/office/provider.html)
            
        *   [光回線用　固定IP](https://biz.biglobe.ne.jp/ip/index.html)
            
        *   [マンション向け無料インターネット](https://biz.biglobe.ne.jp/mansion_isp/index.html)
            
        *   [光回線のサービスマップ](https://biz.biglobe.ne.jp/hikari/ftth_sitemap.html)
            
    *   社用携帯が欲しい
        *   [BIGLOBEモバイル](https://biz.biglobe.ne.jp/sim/index.html)
            
        *   [BIGLOBEモバイル端末一覧](https://biz.biglobe.ne.jp/sim/device/index.html)
            
        *   [MDM「OPTiM Biz」](https://biz.biglobe.ne.jp/mdm/index.html)
            
        *   [マカフィー® マルチ アクセス](https://biz.biglobe.ne.jp/mma/index.html)
            
    *   モバイルルータが欲しい
        *   [BIGLOBEモバイル](https://biz.biglobe.ne.jp/sim/index.html)
            
        *   [BIGLOBEモバイル端末一覧](https://biz.biglobe.ne.jp/sim/device/index.html)
            
        *   [WiMAX +5G](https://biz.biglobe.ne.jp/wimax/index.html)
            
    *   IoT用のモバイル回線が欲しい
        *   [IoT・M2M向けモバイル回線](https://biz.biglobe.ne.jp/sim/iot-m2m.html)
            
        *   [モバイル回線用 固定IP](https://biz.biglobe.ne.jp/sim/static_ip_address.html)
            
    *   セキュリティ対策をしたい
        *   [マカフィー® マルチ アクセス](https://biz.biglobe.ne.jp/mma/index.html)
            
        *   [MDM「OPTiM Biz」](https://biz.biglobe.ne.jp/mdm/index.html)
            
        *   [クラウドストレージ](https://biz.biglobe.ne.jp/storage/index.html)
            
    *   テレワークを導入したい
        *   [BIGLOBEモバイル](https://biz.biglobe.ne.jp/sim/index.html)
            
        *   [MDM「OPTiM Biz」](https://biz.biglobe.ne.jp/mdm/index.html)
            
        *   [マカフィー® マルチ アクセス](https://biz.biglobe.ne.jp/mma/index.html)
            
        *   [WiMAX +5G](https://biz.biglobe.ne.jp/wimax/index.html)
            
        *   [クラウドストレージ](https://biz.biglobe.ne.jp/storage/index.html)
            
    *   ホームページを作りたい
        *   [クラウド型CMS](https://biz.biglobe.ne.jp/cms/index.html)
            
        *   [ホームページ制作ツール](https://biz.biglobe.ne.jp/fc/index.html)
            
        *   [法人向け独自ドメイン](https://biz.biglobe.ne.jp/domain/index.html)
            
    *   クラウドを導入したい
        *   [クラウドホスティング](https://biz.biglobe.ne.jp/hosting/index.html)
            
        *   [クラウドストレージ](https://biz.biglobe.ne.jp/storage/index.html)
            
    
    *   [BIGLOBE光](https://biz.biglobe.ne.jp/hikari/index.html)
        
    *   [BIGLOBE光10ギガ](https://biz.biglobe.ne.jp/hikari/10g.html)
        
    *   [フレッツ光](https://biz.biglobe.ne.jp/flets/index.html)
        
    *   [プロバイダのみの契約](https://biz.biglobe.ne.jp/member/office/provider.html)
        
    *   [光回線用　固定IP](https://biz.biglobe.ne.jp/ip/index.html)
        
    *   [マンション向け無料インターネット](https://biz.biglobe.ne.jp/mansion_isp/index.html)
        
    *   [光回線のサービスマップ](https://biz.biglobe.ne.jp/hikari/ftth_sitemap.html)
        
    
    *   [BIGLOBEモバイル](https://biz.biglobe.ne.jp/sim/index.html)
        
    *   [BIGLOBEモバイル端末一覧](https://biz.biglobe.ne.jp/sim/device/index.html)
        
    *   [MDM「OPTiM Biz」](https://biz.biglobe.ne.jp/mdm/index.html)
        
    *   [マカフィー® マルチ アクセス](https://biz.biglobe.ne.jp/mma/index.html)
        
    
    *   [BIGLOBEモバイル](https://biz.biglobe.ne.jp/sim/index.html)
        
    *   [BIGLOBEモバイル端末一覧](https://biz.biglobe.ne.jp/sim/device/index.html)
        
    *   [WiMAX +5G](https://biz.biglobe.ne.jp/wimax/index.html)
        
    
    *   [IoT・M2M向けモバイル回線](https://biz.biglobe.ne.jp/sim/iot-m2m.html)
        
    *   [モバイル回線用 固定IP](https://biz.biglobe.ne.jp/sim/static_ip_address.html)
        
    
    *   [マカフィー® マルチ アクセス](https://biz.biglobe.ne.jp/mma/index.html)
        
    *   [MDM「OPTiM Biz」](https://biz.biglobe.ne.jp/mdm/index.html)
        
    *   [クラウドストレージ](https://biz.biglobe.ne.jp/storage/index.html)
        
    
    *   [BIGLOBEモバイル](https://biz.biglobe.ne.jp/sim/index.html)
        
    *   [MDM「OPTiM Biz」](https://biz.biglobe.ne.jp/mdm/index.html)
        
    *   [マカフィー® マルチ アクセス](https://biz.biglobe.ne.jp/mma/index.html)
        
    *   [WiMAX +5G](https://biz.biglobe.ne.jp/wimax/index.html)
        
    *   [クラウドストレージ](https://biz.biglobe.ne.jp/storage/index.html)
        
    
    *   [クラウド型CMS](https://biz.biglobe.ne.jp/cms/index.html)
        
    *   [ホームページ制作ツール](https://biz.biglobe.ne.jp/fc/index.html)
        
    *   [法人向け独自ドメイン](https://biz.biglobe.ne.jp/domain/index.html)
        
    
    *   [クラウドホスティング](https://biz.biglobe.ne.jp/hosting/index.html)
        
    *   [クラウドストレージ](https://biz.biglobe.ne.jp/storage/index.html)
        
    
*   [導入事例](https://biz.biglobe.ne.jp/case/index.html)
    
*   [コラム・活用方法](https://biz.biglobe.ne.jp/column/index.html)
    
*   [サポート](https://biz.biglobe.ne.jp/member/index.html)
    
*   [お問い合わせ](https://biz.biglobe.ne.jp/member/request/index.html)
    

ログイン

*   [BIGLOBEオフィスサービス](https://biz-mypage.sso.biglobe.ne.jp/mng/top)
    
*   [BIGLOBEメール](https://webmail.biglobe.ne.jp/)
    
*   [クラウドホスティング](https://biz.biglobe.ne.jp/hosting/login/index.html)
    

 [![法人BIGLOBEモバイル](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/main_250711_mobile.png) ![法人BIGLOBEモバイル](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/main_250711_mobile_sp.png)](https://biz.biglobe.ne.jp/sim/index.html)

 [![法人向けBIGLOBE光](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/mv_biglobe_hikari_top_pc.png) ![法人向けBIGLOBE光](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/mv_biglobe_hikari_top_sp.png)](https://biz.biglobe.ne.jp/hikari/index.html)

 [![法人向けBIGLOBE光 10ギガ](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/mv_biglobe_hikari_10g_pc.png) ![法人向けBIGLOBE光 10ギガ](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/mv_biglobe_hikari_10g_sp.png)](https://biz.biglobe.ne.jp/hikari/10g.html)

 [![法人向けプロバイダサービス](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/mv_prov_pc01.png) ![法人向けプロバイダサービス](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/mv_prov_sp01.png)](https://biz.biglobe.ne.jp/member/office/provider.html)

 [![法人BIGLOBEモバイル](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/main_250711_mobile.png) ![法人BIGLOBEモバイル](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/main_250711_mobile_sp.png)](https://biz.biglobe.ne.jp/sim/index.html)

 [![法人向けBIGLOBE光](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/mv_biglobe_hikari_top_pc.png) ![法人向けBIGLOBE光](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/mv_biglobe_hikari_top_sp.png)](https://biz.biglobe.ne.jp/hikari/index.html)

 [![法人向けBIGLOBE光 10ギガ](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/mv_biglobe_hikari_10g_pc.png) ![法人向けBIGLOBE光 10ギガ](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/mv_biglobe_hikari_10g_sp.png)](https://biz.biglobe.ne.jp/hikari/10g.html)

 [![法人向けプロバイダサービス](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/mv_prov_pc01.png) ![法人向けプロバイダサービス](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/mv_prov_sp01.png)](https://biz.biglobe.ne.jp/member/office/provider.html)

 [![法人BIGLOBEモバイル](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/main_250711_mobile.png) ![法人BIGLOBEモバイル](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/main_250711_mobile_sp.png)](https://biz.biglobe.ne.jp/sim/index.html)

*   1
*   2
*   3
*   4

サービス
----

インターネット接続

モバイル

セキュリティ

ネットワーク

IaaS(データセンタ)・Webサイト・DNS

メール

[![BIGLOBE光](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/service_biglobe_hikari_pc.png)![BIGLOBE光](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/service_biglobe_hikari_sp.png)](https://biz.biglobe.ne.jp/hikari/index.html)

### [BIGLOBE光](https://biz.biglobe.ne.jp/hikari/index.html)

NTT東西の光回線とプロバイダーサービスが一体化した光コラボサービス。1ギガ・10ギガタイプ(10ギガは一部エリアでの提供)から選べ、IPv6接続(IPoE方式)による高速通信に対応。シンプルな料金体系に加え、特典や充実したサポートも魅力です。

[サービス詳細をみる](https://biz.biglobe.ne.jp/hikari/index.html)

[お問い合わせ](https://biz-mypage.sso.biglobe.ne.jp/mng/no_auth/inquiries/hikari/edit)

[![BIGLOBE法人光パックNeo with フレッツ](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/service_flets_hikari_pc.png)![BIGLOBE法人光パックNeo with フレッツ](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/service_flets_hikari_sp.png)](https://biz.biglobe.ne.jp/flets/index.html)

### [BIGLOBE法人光パックNeo with フレッツ](https://biz.biglobe.ne.jp/flets/index.html)

NTT東西が提供する全国対応の光回線インターネットサービス。フレッツ回線をNTT東西、プロバイダーは通信事業35年以上の信頼と実績を誇るビッグローブと契約する形態で、サービスの柔軟なカスタマイズが可能です。

[サービス詳細をみる](https://biz.biglobe.ne.jp/flets/index.html)

[お問い合わせ](https://biz-mypage.sso.biglobe.ne.jp/mng/no_auth/inquiries/flets/edit)

[![法人向けプロバイダサービス](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/service_provider_pc.png)![法人向けプロバイダサービス](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/service_provider_sp.png)](https://biz.biglobe.ne.jp/member/office/provider.html)

### [法人向けプロバイダサービス](https://biz.biglobe.ne.jp/member/office/provider.html)

回線契約はフレッツ光のまま、プロバイダのみを他社から乗り換えてビッグローブをご利用いただくサービス。現在の光回線を利用しながらプロバイダのみを変更するので、工事や初期費用も不要です。乗り換え時にインターネットが利用できない期間も発生しません。

[サービス詳細をみる](https://biz.biglobe.ne.jp/member/office/provider.html)

[お問い合わせ](https://biz-mypage.sso.biglobe.ne.jp/mng/no_auth/inquiries/ask/edit)

[![アパート・マンション向け無料インターネット](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/service_apartment_isp_pc.png)![アパート・マンション向け無料インターネット](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/service_apartment_isp_sp.png)](https://biz.biglobe.ne.jp/mansion_isp/index.html)

### [アパート・マンション向け無料インターネット](https://biz.biglobe.ne.jp/mansion_isp/index.html)

アパート・マンション向け光回線サービス。「BIGLOBE IPv6サービス(IPIP)」を採用し、多数の同時接続が可能。全国134万戸の導入実績(2025年4⽉30日ギガプライズ調べ)を誇るギガプライズの技術とサポートで、快適なインターネット環境を提供します。

[サービス詳細をみる](https://biz.biglobe.ne.jp/mansion_isp/index.html)

[無料見積り相談をする](https://pd.biglobe.ne.jp/contact/hikari/mansion_isp)

[![BIGLOBEモバイル](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/service_biglobe_mobile_pc.png)![BIGLOBEモバイル](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/service_biglobe_mobile_sp.png)](https://biz.biglobe.ne.jp/sim/index.html)

### [BIGLOBEモバイル](https://biz.biglobe.ne.jp/sim/index.html)

ドコモとau の2キャリアに対応。使いたい機能に応じて「SIMの種類」と「データ量」を自由に組み合わせ可能！導入前に無料お試しができ、最短2営業日でSIMカードや端末を発送。法人格のないPTAや組合、任意団体でも契約可能(弊社所定の審査あり)。

[サービス詳細をみる](https://biz.biglobe.ne.jp/sim/index.html)

[お問い合わせ](https://biz-mypage.sso.biglobe.ne.jp/mng/no_auth/inquiries/2/edit)

[![BIGLOBE WiMAX +5G](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/service_biglolbe_wimax_pc.png)![BIGLOBE WiMAX +5G](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/service_biglolbe_wimax_sp.png)](https://biz.biglobe.ne.jp/wimax/index.html)

### [BIGLOBE WiMAX +5G](https://biz.biglobe.ne.jp/wimax/index.html)

オフィス、外出先、家庭で使えるWi-Fiルータ(ホームルータ、モバイルルータ)のサービス。工事不要で最短3日でルータをお届け、セットアップも簡単。届いたその日からすぐにインターネットを利用いただけます。WiMAX 2+、au 4G LTE、au 5Gのエリアに対応。

[サービス詳細をみる](https://biz.biglobe.ne.jp/wimax/index.html)

[お問い合わせ](https://biz-mypage.sso.biglobe.ne.jp/mng/no_auth/inquiries/ask/edit)

[![マカフィー® マルチ アクセス](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/service_mma_pc.png)![マカフィー® マルチ アクセス](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/service_mma_sp.png)](https://biz.biglobe.ne.jp/mma/index.html)

### [マカフィー® マルチ アクセス](https://biz.biglobe.ne.jp/mma/index.html)

パソコン、スマホ、タブレット対応の総合セキュリティソフト。自動で最新版にアップデートされ、管理者用画面で使用者の確認や追加が可能。不正アクセスやウイルスからデバイスを守ります。マカフィーのセキュリティ関連製品・サービスは世界で多くの方に利用されています。

[サービス詳細をみる](https://biz.biglobe.ne.jp/mma/index.html)

[お問い合わせ](https://biz-mypage.sso.biglobe.ne.jp/mng/no_auth/inquiries/mma/edit)

[![Flow分析プラットフォームサービス](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/service_flow_pc.png)![Flow分析プラットフォームサービス](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/service_flow_sp.png)](https://biz.biglobe.ne.jp/flow/index.html)

### [Flow分析プラットフォームサービス](https://biz.biglobe.ne.jp/flow/index.html)

NetFlow/sFlow/IPFIXに対応したフローコレクタ機能をクラウド型で提供しフロー情報を収集、分析、可視化できるサービス。GenieATMでDDoS攻撃検知やネットワーク安定化、コスト削減を実現。フロー情報の可視化により、セキュリティ強化と効率的運用が可能です。

[サービス詳細をみる](https://biz.biglobe.ne.jp/flow/index.html)

[お問い合わせ](https://pd.biglobe.ne.jp/contact/flow/biz/form)

[![BIGLOBE IPトランジットサービス](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/service_ip_transit_service_pc.png)![BIGLOBE IPトランジットサービス](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/service_ip_transit_service_sp.png)](https://biz.biglobe.ne.jp/transit/index.html)

### [BIGLOBE IPトランジットサービス](https://biz.biglobe.ne.jp/transit/index.html)

国内外の主要IX、大手コンテンツプロバイダ、モバイルキャリアと直接接続し、高品質な接続性を提供。国内有数の大規模バックボーンとビッグローブのIPネットワーク(AS2518)の運用実績を活かし、高速・安定したインターネット接続と信頼性の高い通信環境を実現します。

[サービス詳細をみる](https://biz.biglobe.ne.jp/transit/index.html)

[お問い合わせ](https://pd.biglobe.ne.jp/contact/transit/biz/form)

[![Pattern Style CMS](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/service_pattern-style-cms_pc.png)![Pattern Style CMS](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/service_pattern-style-cms_sp.png)](https://biz.biglobe.ne.jp/cms/index.html)

### [Pattern Style CMS](https://biz.biglobe.ne.jp/cms/index.html)

エンタープライズCMS(WebRelease2)とマネージド型ホスティングサービスをセットで提供し、サイトの設計、運用、保守をフルサポート。数千ページ以上の大規模サイトも快適に運用可能。セキュリティパッチ適用、バージョンアップ、バックアップもBIGLOBEが実施し、最適なサーバ状態を維持。安心の24時間365日運用監視で支えます。

[サービス詳細をみる](https://biz.biglobe.ne.jp/cms/index.html)

[お問い合わせ](https://pd.biglobe.ne.jp/contact/cms/consultation/input)

[![Feather cloud](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/service_feather_cloud_pc.png)![Feather cloud](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/service_feather_cloud_sp.png)](https://biz.biglobe.ne.jp/fc/index.html)

### [Feather cloud](https://biz.biglobe.ne.jp/fc/index.html)

Web制作のさまざまなニーズに応えるホームページサービス。豊富なテンプレートの中から、お客さまのイメージに合うテンプレートをお選びいただき、文字や画像を変更するだけで簡単にWebサイトを作成できます。スマートフォン対応のレスポンシブ表示にも対応し、HTMLやサーバーなどの専門知識は不要です。

[サービス詳細をみる](https://biz.biglobe.ne.jp/fc/index.html)

[無料で試してみる](https://biz.biglobe.ne.jp/fc/index.html#free)

[![BIGLOBEクラウドストレージ](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/service_biglolbe_cloud_storage_pc.png)![BIGLOBEクラウドストレージ](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/service_biglolbe_cloud_storage_sp.png)](https://biz.biglobe.ne.jp/storage/index.html)

### [BIGLOBEクラウドストレージ](https://biz.biglobe.ne.jp/storage/index.html)

法人向けに特化したクラウドストレージサービス。利用状況に応じてID数や容量を1ID・1GBから変更できる柔軟性を備えています。通信やファイルは暗号化され情報を守り、24時間有人監視の国内データセンターと公的認定で、安心・安全で迅速なファイル共有を実現します。

[サービス詳細をみる](https://biz.biglobe.ne.jp/storage/index.html)

[無料で試してみる](https://bcst.sso.biglobe.ne.jp/regist/free/)

[![BIGLOBEクラウドホスティング](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/service_biglolbe_cloud_hosting_pc.png)![BIGLOBEクラウドホスティング](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/service_biglolbe_cloud_hosting_sp.png)](https://biz.biglobe.ne.jp/hosting/index.html)

### [BIGLOBEクラウドホスティング](https://biz.biglobe.ne.jp/hosting/index.html)

サーバリソースをオンデマンド利用できる国産パブリッククラウド(IaaS)。導入実績4000社以上！(2024年3月現在)ファイルサーバ・Webサイト・各種業務システムのクラウド化を支援。VMware採用、専用電話窓口で24時間365日サポート。お客さまのビジネスを確実に支えます。

[サービス詳細をみる](https://biz.biglobe.ne.jp/hosting/index.html)

[お問い合わせ](https://business.biglobe.ne.jp/form/form1.php?service=ask&no=53&lang=ja)

[![法人向け独自ドメインサービス](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/service_domain_pc.png)![法人向け独自ドメインサービス](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/service_domain_sp.png)](https://biz.biglobe.ne.jp/domain/index.html)

### [法人向け独自ドメインサービス](https://biz.biglobe.ne.jp/domain/index.html)

年次更新無料で、どのドメインも一律290円(税別)/月で登録可能。新規ドメイン登録時の初期設定料やドメイン移管(受入)時の初期設定料と受入費用は0円。ドメイン名は自動更新のため、お客さまによるドメイン登録期限日ごとのお手続きも不要です。

[サービス詳細をみる](https://biz.biglobe.ne.jp/domain/index.html)

[![DNSマネージャ](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/service_dns_pc.png)![DNSマネージャ](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/service_dns_sp.png)](https://biz.biglobe.ne.jp/domain/dns/index.html)

### [DNSマネージャ](https://biz.biglobe.ne.jp/domain/dns/index.html)

企業向けの高速・高信頼性DNSソリューション。安定したドメイン名解決を実現し、強固なセキュリティ対策と使いやすい管理機能で、安全かつスムーズな運用を支援。ビジネスサイトの安定稼働を強力にサポートします。

[サービス詳細をみる](https://biz.biglobe.ne.jp/domain/dns/index.html)

[![BIGLOBEメール](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/service_biglobe_mail_pc.png)![BIGLOBEメール](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/service_biglobe_mail_sp.png)](https://biz.biglobe.ne.jp/bmail/index.html)

### [BIGLOBEメール](https://biz.biglobe.ne.jp/bmail/index.html)

「BIGLOBEオフィスサービス」をお申し込みいただくとBIGLOBEドメインのメールアドレスがご利用できます。メールボックス容量は5GBの大容量。さらに、無料で利用できるセキュリティ対策サービスもご用意しております。

[サービス詳細をみる](https://biz.biglobe.ne.jp/bmail/index.html)

[お問い合わせ](https://biz-mypage.sso.biglobe.ne.jp/mng/no_auth/inquiries/ask/edit)

[![独自ドメインメール](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/service_domain_mail_pc.png)![独自ドメインメール](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/service_domain_mail_sp.png)](https://biz.biglobe.ne.jp/domain/mail/index.html)

### [独自ドメインメール](https://biz.biglobe.ne.jp/domain/mail/index.html)

取得した独自ドメインのメールアドレスを追加費用なしで設定可能。事前に独自ドメインを登録し、BIGLOBE biz.のマイページで設定、解除、参照が簡単に行えます。企業のブランド力を高め、セキュリティ対策も強化されています。

[サービス詳細をみる](https://biz.biglobe.ne.jp/domain/mail/index.html)

[![メールウイルスチェックプラス](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/service_mail_check_pc.png)![メールウイルスチェックプラス](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/service_mail_check_sp.png)](https://email.biglobe.ne.jp/vcheck/index.html)

### [メールウイルスチェックプラス](https://email.biglobe.ne.jp/vcheck/index.html)

メール送信・受信時にBIGLOBEサーバでウイルスを自動検知するサービス。難しい設定やバージョンアップ作業は不要で、手軽に導入でき、安心してメールを利用できます。

[サービス詳細をみる](https://email.biglobe.ne.jp/vcheck/index.html)

[![迷惑メールブロックサービス](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/service_mail_block_pc.png)![迷惑メールブロックサービス](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/service_mail_block_sp.png)](https://email.biglobe.ne.jp/spam/index.html)

### [迷惑メールブロックサービス](https://email.biglobe.ne.jp/spam/index.html)

お申し込み後すぐに迷惑メールが届かなくなります。間違って迷惑メールを開いてしまったり、迷惑メールを見つけて削除する手間がなくなるのでメールチェックも快適です。

[サービス詳細をみる](https://email.biglobe.ne.jp/spam/index.html)

導入事例
----

これまで 50,000以上の企業にご導入いただいております。大手企業から個人事業主の方まで広くご利用いただいております。

BIGLOBE光

[![香川トヨタ自動車株式会社](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/thum_kagawa_toyota.png)](https://biz.biglobe.ne.jp/case/kagawa-toyota.html)

[全店舗に導入。お客さま向けWi-Fi環境が整い、顧客満足が向上](https://biz.biglobe.ne.jp/case/kagawa-toyota.html)

お客さまが快適に利用できるWi-Fi環境を提供するため、BIGLOBE光を導入。長時間の待機中に動画視聴やカタログ閲覧が可能となり、CX(顧客体験)の向上に繋がりました。

[続きをみる](https://biz.biglobe.ne.jp/case/kagawa-toyota.html)

香川トヨタ自動車株式会社

*   業種：製造
*   利用人数：約 20人
*   所在地：香川県

BIGLOBE光

[![株式会社アドシード](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/thum_adseed.png)](https://biz.biglobe.ne.jp/case/adseed.html)

[オンライン会議の不具合が解消され、社内外のコミュニケーションが円滑化](https://biz.biglobe.ne.jp/case/adseed.html)

オフィスのインターネット回線としてBIGLOBE光 10ギガを導入。高速で安定した通信環境により開発作業が円滑に進みストレスなく業務に集中できるようになりました。

[続きをみる](https://biz.biglobe.ne.jp/case/adseed.html)

株式会社アドシード

*   業種：IT
*   利用人数：約 60人
*   所在地：東京都

BIGLOBE光

[![有限会社コスモファーム](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/thum_cosmofarm.png)](https://biz.biglobe.ne.jp/case/cosmofarm.html)

[実習生たちは快適にインターネットを利用でき、通信状況も非常に良好！](https://biz.biglobe.ne.jp/case/cosmofarm.html)

実習生の日本語学習や動画視聴のため、寮内にBIGLOBE光を導入。快適な通信環境で不具合なく運用され、安定したインターネット利用が可能になりました。

[続きをみる](https://biz.biglobe.ne.jp/case/cosmofarm.html)

有限会社コスモファーム

*   業種：農業
*   利用人数：約 15人
*   所在地：福岡県

BIGLOBE光

[![株式会社 グリーンヴァレー](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/thum_green_valley.png)](https://biz.biglobe.ne.jp/case/green_valley.html)

[安心して導入が進み、非常に満足。社宅の通信環境が改善](https://biz.biglobe.ne.jp/case/green_valley.html)

技能実習生の福利厚生として社宅に光回線を導入。専任営業と連携しスムーズに導入でき、通信環境が大幅に改善。実習生が安心してインターネットを利用できるようになりました。

[続きをみる](https://biz.biglobe.ne.jp/case/green_valley.html)

株式会社 グリーンヴァレー

*   業種：農業
*   利用人数：約 10人
*   所在地：北海道

BIGLOBE光

[![株式会社 JAPANNEXT](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/thum_japannext.png)](https://biz.biglobe.ne.jp/case/japannext.html)

[業務に集中できる環境が整い、生産性向上に繋がる](https://biz.biglobe.ne.jp/case/japannext.html)

業務用回線としてBIGLOBE光を導入。安定した接続により、社内業務や顧客対応が円滑になり、生産性向上に貢献。快適なネット環境で業務効率が大幅に向上しました。

[続きをみる](https://biz.biglobe.ne.jp/case/japannext.html)

株式会社 JAPANNEXT

*   業種：製造
*   利用人数：約 40人
*   所在地：千葉県

BIGLOBE光

[![株式会社 要建設](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/thum_kaname.jpg)](https://biz.biglobe.ne.jp/case/kaname-k.html)

[安定した通信により、ゲスト満足度向上と効率的な施設運営が実現可能に](https://biz.biglobe.ne.jp/case/kaname-k.html)

観光客受け入れ強化のため、民泊施設の通信環境を改善。安定したWi-Fiにより、ゲスト満足度と施設運営の効率が向上し、快適で利便性の高い環境を実現しました。

[続きをみる](https://biz.biglobe.ne.jp/case/kaname-k.html)

株式会社 要建設

*   業種：旅行
*   利用人数：約 50人
*   所在地：茨城県

[導入一覧はこちら](https://biz.biglobe.ne.jp/case/index.html)

コラム
---

[![通信事業35年以上のノウハウをもとに コラムを執筆・発信](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/img_column_thumbnail_pc.png)![通信事業35年以上のノウハウをもとに コラムを執筆・発信](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/img_column_thumbnail_sp.png)](https://biz.biglobe.ne.jp/column/index.html)

### 新着コラム

[![社内ネットワークが遅い原因を切り分けて解説！対処法6選と速度の調査方法も紹介](https://biz.biglobe.ne.jp/column/a3c3n000000d3lge-img/internal_network_thumbnail.jpg)](https://biz.biglobe.ne.jp/column/internal_network.html)

#### [社内ネットワークが遅い原因を切り分けて解説！対処法6選と速度の調査方法も紹介](https://biz.biglobe.ne.jp/column/internal_network.html)

*   [BIGLOBE光](https://biz.biglobe.ne.jp/hikari/index.html)
    
*   [フレッツ光](https://biz.biglobe.ne.jp/flets/index.html)
    
*   [コスト削減](https://biz.biglobe.ne.jp/keyword/cost_reduction.html)
    
*   [業務効率化](https://biz.biglobe.ne.jp/keyword/work_efficiency.html)
    

[![ベストエフォート型の光回線とは？ メリット・デメリットや選び方のポイントを解説](https://biz.biglobe.ne.jp/column/a3c3n000000cmp0c-img/img_optical_line_best_effort_thumbnail.png)](https://biz.biglobe.ne.jp/column/optical_line_best_effort.html)

#### [ベストエフォート型の光回線とは？ メリット・デメリットや選び方のポイントを解説](https://biz.biglobe.ne.jp/column/optical_line_best_effort.html)

*   [BIGLOBE光](https://biz.biglobe.ne.jp/hikari/index.html)
    
*   [フレッツ光](https://biz.biglobe.ne.jp/flets/index.html)
    
*   [業務効率化](https://biz.biglobe.ne.jp/keyword/work_efficiency.html)
    

[![光回線に10ギガは必要？法人オフィスに導入するメリットやデメリットを紹介](https://biz.biglobe.ne.jp/column/a3c3n000000crms4-img/img_10g_optical_line_need_thumbnail.png)](https://biz.biglobe.ne.jp/column/10g_optical_line_need.html)

#### [光回線に10ギガは必要？法人オフィスに導入するメリットやデメリットを紹介](https://biz.biglobe.ne.jp/column/10g_optical_line_need.html)

*   [BIGLOBE光](https://biz.biglobe.ne.jp/hikari/index.html)
    
*   [フレッツ光](https://biz.biglobe.ne.jp/flets/index.html)
    
*   [セキュリティ強化](https://biz.biglobe.ne.jp/keyword/security.html)
    
*   [インフラ強化](https://biz.biglobe.ne.jp/keyword/infrastructure.html)
    
*   [コスト削減](https://biz.biglobe.ne.jp/keyword/cost_reduction.html)
    
*   [業務効率化](https://biz.biglobe.ne.jp/keyword/work_efficiency.html)
    

[コラム一覧はこちら](https://biz.biglobe.ne.jp/column/index.html)

実施中の特典
------

\* 本特典は、予告なく変更または終了することがあります。

[![法人向けBIGLOBE光 特典](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/img_tokuten_hikari_discount_pc.png)\
\
![法人向けBIGLOBE光 特典](https://biz.biglobe.ne.jp/a3c3n000000c7cxg-img/img_tokuten_hikari_discount_sp.png)](https://biz.biglobe.ne.jp/hikari/charge.html)

[BIGLOBE光](https://biz.biglobe.ne.jp/hikari/charge.html)

月額料金値引き、申込手数料値引き特典[](https://biz.biglobe.ne.jp/hikari/charge.html)

お知らせ
----

*   2025.6.18
    
    [【重要】法人BIGLOBEモバイル 料金体系および割引内容の変更に関するお知らせ](https://biz.biglobe.ne.jp/member/info/20250618.html)
    
*   2025.6.18
    
    [【重要】法人BIGLOBE WiMAX 料金体系および割引内容の変更に関するお知らせ](https://biz.biglobe.ne.jp/member/info/20250618_2.html)
    
*   2023.3.15
    
    [法人向けBIGLOBEモバイル SMS機能付きデータSIMお申し込み受付時の本人確認手続き導入のお知らせ](https://biz.biglobe.ne.jp/member/info/20230216.html)
    

お問い合わせ
------

わたしたちビッグローブは充実したサービスとお客さまの声を大事にしたサポートを心がけています。

法人サービスをお探しのお客さまはお気軽にお問合せください。  
サービス内容に関してはもちろん、最適プランのご提案、お見積りのご提案もいたします。

[お問い合わせはこちら](https://biz.biglobe.ne.jp/member/request/index.html)

[](https://www.biglobe.ne.jp/)

*   [](https://twitter.com/biglobe)
    
*   [](https://www.instagram.com/biglobe_official/)
    
*   [](https://www.facebook.com/BIGLOBE)
    
*   [](https://www.youtube.com/user/BIGLOBEchannel)
    

個人のお客さま

通信サービス

*   [BIGLOBE光](https://join.biglobe.ne.jp/ftth/hikari/?cl=global_footer_hikari)
    
*   [auひかり](https://join.biglobe.ne.jp/ftth/one/?cl=global_footer_one)
    
*   [BIGLOBEモバイル](https://join.biglobe.ne.jp/mobile/?cl=global_footer_mobile)
    
*   [BIGLOBE WiMAX](https://join.biglobe.ne.jp/mobile/wimax/?cl=global_footer_wimax)
    

オプションサービス

*   [お助けサポート＋](https://otasuke.biglobe.ne.jp/otasuke_plus/)
    
*   [インターネット端末保証サービス](https://service.biglobe.ne.jp/internethosho/)
    
*   [トータル・ネットセキュリティ](https://security.biglobe.ne.jp/tns/)
    
*   [U-NEXT for BIGLOBE](https://vod.biglobe.ne.jp/unext/)
    
*   [その他オプション](https://service.biglobe.ne.jp/)
    

Webメディア

*   [温泉大賞](https://biz.biglobe.ne.jp/onsen/award/)
    
*   [しむぐらし](https://join.biglobe.ne.jp/mobile/sim/gurashi/)
    
*   [あしたメディア](https://ashita.biglobe.co.jp/)
    

法人のお客さま

*   [BIGLOBE biz.](https://biz.biglobe.ne.jp/index.html)
    
*   [BIGLOBE光](https://biz.biglobe.ne.jp/hikari/index.html)
    
*   [フレッツ光](https://biz.biglobe.ne.jp/flets/index.html)
    
*   [プロバイダサービス](https://biz.biglobe.ne.jp/member/office/provider.html)
    
*   [光回線用 固定IPアドレス](https://biz.biglobe.ne.jp/ip/index.html)
    
*   [BIGLOBEモバイル](https://biz.biglobe.ne.jp/sim/index.html)
    
*   [BIGLOBE WiMAX](https://biz.biglobe.ne.jp/wimax/index.html)
    
*   [IPトランジット](https://biz.biglobe.ne.jp/transit/index.html)
    
*   [マカフィー®マルチ アクセス](https://biz.biglobe.ne.jp/mma/index.html)
    
*   [法人向け独自ドメイン](https://biz.biglobe.ne.jp/domain/index.html)
    
*   [ONSENWORK](https://workation.biglobe.ne.jp/onsen/)
    

企業情報

*   [企業情報](https://www.biglobe.co.jp/outline)
    
*   [トップメッセージ](https://www.biglobe.co.jp/outline/message)
    
*   [ブランド](https://www.biglobe.co.jp/outline/brand)
    
*   [サステナビリティ](https://www.biglobe.co.jp/sustainability)
    
*   [ニュース](https://www.biglobe.co.jp/pressroom)
    
*   [採用情報](https://www.biglobe.co.jp/recruit)
    
*   [BIGLOBE Style](https://style.biglobe.co.jp/)
    
*   [ソーシャルメディア](https://www.biglobe.co.jp/social)
    

ご利用中の方

*   [マイページ](https://mypage.sso.biglobe.ne.jp/?cl=global_footer_mypage)
    
*   [メール](https://auth.sso.biglobe.ne.jp/mail/?cl=global_footer_mail)
    
*   [会員サポート](https://support.biglobe.ne.jp/?cl=global_footer_support)
    

*   [お問い合わせ](https://www.biglobe.co.jp/inquire)
    
*   [消費税の表示](https://support.biglobe.ne.jp/salestax.html)
    
*   [ウェブアクセシビリティの取り組み](https://support.biglobe.ne.jp/accessibility/)
    
*   [個人情報保護ポリシー](https://www.biglobe.ne.jp/privacy.html)
    
*   [プライバシーポータル](https://www.biglobe.ne.jp/privacy-portal.html)
    
*   [Cookieポリシー](https://www.biglobe.ne.jp/cookie.html)
    
*   [特定商取引法に基づく表記](https://support.biglobe.ne.jp/tokusyo.html)
    
*   [古物営業法に基づく表記](https://support.biglobe.ne.jp/kobutsusyo.html)
    
*   [情報セキュリティ基本方針](https://www.biglobe.co.jp/security)
    
*   [商標について](https://join.biglobe.ne.jp/trademark/)
    
*   [BIGLOBEトップ](https://www.biglobe.ne.jp/)
    

[![プライバシーマーク](https://top.bcdn.jp/images/PrivacyMark.png)](https://privacymark.jp/)

[![セキュリティ認証](https://top.bcdn.jp/images/ISP.png)](https://www.biglobe.ne.jp/safesecurity.html)

[![ETOCマーク](https://top.bcdn.jp/images/ETOC.png)](https://www.etoc.jp/elite/0037)

Copyright ©BIGLOBE Inc. 2025. All rights reserved.
