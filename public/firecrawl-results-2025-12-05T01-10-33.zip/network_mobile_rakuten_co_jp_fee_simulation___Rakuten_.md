# 料金シミュレーション（料金比較） | Rakuten最強プラン（料金プラン） | 楽天モバイル

URL: https://network.mobile.rakuten.co.jp/fee/simulation/

---

![](https://secure.rat.rakuten.co.jp/?cpkg_none=%7B%22acc%22%3A1312%2C%22aid%22%3A1%2C%22bid%22%3A%2217648966807148ea52658%22%2C%22url%22%3A%22https%3A%2F%2Fnetwork.mobile.rakuten.co.jp%2Ffee%2Fsimulation%2F%22%2C%22ua%22%3A%22Mozilla%2F5.0%20(Linux%3B%20Android%2010%3B%20K)%20AppleWebKit%2F537.36%20(KHTML%2C%20like%20Gecko)%20Chrome%2F141.0.0.0%20Mobile%20Safari%2F537.36%22%2C%22etype%22%3A%22async%22%2C%22phoenix_pattern%22%3A%22network.mobile.rakuten.co.jp%7C%2Ffee%2Fsimulation%2F%7Cmnopj_fee_simulation_responsive%7Cdefault%22%2C%22cp%22%3A%7B%22phxcampaign%22%3A%22mnopj_fee_simulation_responsive%22%2C%22phxexperiment%22%3A25882%2C%22phxpattern%22%3A%22default%22%2C%22phxbanditpattern%22%3A%22default%22%2C%22phxversion%22%3A%223.2.2%22%2C%22phxcmpruntime%22%3A0.001%2C%22phxapiresptime%22%3A0%2C%22phxpatternloadtime%22%3A0%7D%7D)

*   個人のお客様
*   [法人のお客様](https://business.mobile.rakuten.co.jp/?scid=wi_rmb_pers_header)
    

[Rakuten Mobile](https://network.mobile.rakuten.co.jp/?l-id=gnavi_logo_b)

[![おかげさまで950万回線](https://network.mobile.rakuten.co.jp/assets/img/common/logo-thankyou-950-magenta.svg)](https://network.mobile.rakuten.co.jp/feature/why-rakuten-mobile/?l-id=gnavi_banner_why-rakuten-mobile_b)

*   プラン・  
    製品
    
    スマートフォン
    
    *   [Rakuten最強プラン](https://network.mobile.rakuten.co.jp/fee/saikyo-plan/?l-id=gnavi_fee_saikyo-plan_b)
        *   [データタイプ](https://network.mobile.rakuten.co.jp/fee/saikyo-plan/data-type/?l-id=gnavi_fee_saikyo-plan_data-type_b)
            
    *   [![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-unext.svg)Rakuten最強U-NEXT](https://network.mobile.rakuten.co.jp/fee/unext/?l-id=gnavi_fee_unext_b)
        
        ![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-reduction.svg)割引プログラム
        
        *   [最強家族割\
            \
            家族でトクしたい方に](https://network.mobile.rakuten.co.jp/fee/family/?l-id=gnavi_fee_family_b)
            
        *   [最強こども割\
            \
            12歳までとーってもおトク](https://network.mobile.rakuten.co.jp/fee/kids/?l-id=gnavi_fee_kids_b)
            
        *   [最強青春割\
            \
            22歳までずーっとおトク](https://network.mobile.rakuten.co.jp/fee/youth/?l-id=gnavi_fee_youth_b)
            
        *   [最強シニアプログラム\
            \
            65歳以上から  \
            ずーっと安心&おトク](https://network.mobile.rakuten.co.jp/fee/senior/?l-id=gnavi_fee_senior_b)
            
        
    
    *   [![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-fee-simulation.svg)料金シミュレーション](https://network.mobile.rakuten.co.jp/fee/simulation/?l-id=gnavi_fee_un-limit_simulation_b)
        
    *   [製品](https://network.mobile.rakuten.co.jp/product/?l-id=gnavi_product_b)
        *   [iPhone](https://network.mobile.rakuten.co.jp/product/iphone/?l-id=gnavi_product_iphone_b)
            
        *   [Apple Watch](https://network.mobile.rakuten.co.jp/product/apple-watch/?l-id=gnavi_product_apple-watch_b)
            
        *   [Android](https://network.mobile.rakuten.co.jp/product/smartphone/?l-id=gnavi_product_smartphone_b)
            
        *   [Wi-Fiルーター](https://network.mobile.rakuten.co.jp/product/internet/?l-id=gnavi_product_internet_b)
            
        *   [アクセサリ](https://network.mobile.rakuten.co.jp/product/accessory/?l-id=gnavi_product_accessory_b)
            
        *   [その他オススメ製品](https://network.mobile.rakuten.co.jp/product/ichiba-recommended/?l-id=gnavi_product_ichiba-recommended_b)
            
    *   [オプションサービス](https://network.mobile.rakuten.co.jp/service/?l-id=gnavi_service_b)
        
    
    *   [![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-sim.svg)SIM](https://network.mobile.rakuten.co.jp/product/sim/?l-id=gnavi_product_sim_b)
        *   [eSIM](https://network.mobile.rakuten.co.jp/product/sim/esim/?l-id=gnavi_product_sim_esim_b)
            
        *   [デュアルSIM](https://network.mobile.rakuten.co.jp/product/sim/dual-sim/?l-id=gnavi_product_sim_dual-sim_b)
            
        *   [ご利用製品の対応確認](https://network.mobile.rakuten.co.jp/product/byod/?l-id=gnavi_product_byod_b)
            
    
    インターネット・電気
    
    *   [Rakuten Turbo](https://network.mobile.rakuten.co.jp/internet/turbo/?l-id=gnavi_internet_turbo_b)
        *   [料金プラン](https://network.mobile.rakuten.co.jp/internet/turbo/fee/?l-id=gnavi_internet_turbo_fee_b)
            
    
    *   [楽天ひかり](https://network.mobile.rakuten.co.jp/hikari/?l-id=gnavi_hikari_b)
        *   [料金プラン](https://network.mobile.rakuten.co.jp/hikari/fee/pricelist/?l-id=gnavi_hikari_fee_b)
            
    
    *   [![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-energy.svg)楽天でんき](https://energy.rakuten.co.jp/electricity/?scid=wi_rmb_gnavi_top)
        *   [料金プラン](https://energy.rakuten.co.jp/electricity/fee/?scid=wi_rmb_gnavi_plan)
            
    
    スマホとセットでおトク
    
    *   [![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-saikyo-program.svg)最強おうちプログラム](https://network.mobile.rakuten.co.jp/campaign/home-internet/?l-id=gnavi_campaign_home-internet_b)
        *   [スマホ＋Rakuten Turbo\
            \
            Rakuten Turbo 初めて申し込みで毎月1,000ポイント還元](https://network.mobile.rakuten.co.jp/internet/turbo/campaign/home-internet/?l-id=gnavi_internet_turbo_campaign_home-internet_b)
            
        *   [スマホ＋楽天ひかり\
            \
            楽天ひかり初めて申し込みで毎月1,000ポイント還元](https://network.mobile.rakuten.co.jp/hikari/campaign/home-internet/?l-id=gnavi_hikari_campaign_home-internet_b)
            
    
*   通信エリア・  
    店舗
    
    通信エリア
    
    *   [スマートフォン](https://network.mobile.rakuten.co.jp/area/?l-id=gnavi_area_b)
        
    *   [Rakuten Turbo](https://network.mobile.rakuten.co.jp/internet/turbo/area/?l-id=gnavi_internet_turbo_area_b)
        
    
    ご来店のお客様へ
    
    *   [ショップ（店舗）](https://network.mobile.rakuten.co.jp/shop/?l-id=gnavi_shop_b)
        
    
*   キャンペーン
    
    キャンペーン
    
    *   [スマートフォン](https://network.mobile.rakuten.co.jp/campaign/?l-id=gnavi_campaign_b)
        
    *   [Rakuten Turbo](https://network.mobile.rakuten.co.jp/internet/turbo/campaign/home-internet/?l-id=gnavi_internet_turbo_campaign_home-internet_b)
        
    *   [楽天ひかり](https://network.mobile.rakuten.co.jp/hikari/campaign/home-internet/?l-id=gnavi_hikari_campaign_home-internet_b)
        
    *   [![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-energy.svg)楽天でんき](https://energy.rakuten.co.jp/campaign/lp/mobilelink/?scid=wi_rmb_gnavi_cpn)
        
    
*   お知らせ・  
    サポート
    
    お知らせ・その他
    
    *   [お知らせ](https://network.mobile.rakuten.co.jp/information/?l-id=gnavi_info_b)
        *   [スーパーホーダイ／組み合わせプランを  \
            ご利用中の方](https://mobile.rakuten.co.jp/mvno/?l-id=gnavi_mvno_b)
            
    
    ご検討中の方へ
    
    *   [![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-new-user.svg)お申し込みガイド](https://network.mobile.rakuten.co.jp/guide/procedure/?l-id=gnavi_guide_procedure_b)
        
    *   [なぜ今楽天モバイルなのか](https://network.mobile.rakuten.co.jp/feature/why-rakuten-mobile/?l-id=gnavi_feature_why-rakuten-mobile_b)
        
    *   [お客様の声](https://network.mobile.rakuten.co.jp/uservoice/?l-id=gnavi_uservoice_b)
        
    *   [スマホ活用術を学ぶ](https://network.mobile.rakuten.co.jp/sumakatsu/?l-id=gnavi_sumakatsu_b)
        
    
    お客様サポート
    
    *   [楽天モバイル](https://network.mobile.rakuten.co.jp/support/?l-id=gnavi_support_b)
        
    *   [Rakuten Turbo](https://network.mobile.rakuten.co.jp/internet/turbo/support/?l-id=gnavi_internet_turbo_support_b)
        
    *   [楽天ひかり](https://network.mobile.rakuten.co.jp/hikari/support/?l-id=gnavi_hikari_support_b)
        
    *   [![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-energy.svg)楽天でんき](https://energy.rakuten.co.jp/faq/?scid=wi_rmb_gnavi_qa)
        
    

メニュー

検索

[my 楽天モバイル](https://portal.mobile.rakuten.co.jp/my-rakuten-mobile?l-id=network_gnavi_ecare_b)

[お申し込み](https://network.mobile.rakuten.co.jp/guide/application/?ref=header&lid-r=gnavi_onboarding_b)

[お申し込み](https://network.mobile.rakuten.co.jp/guide/application/?ref=header&lid-r=burger_onboarding_b)
[my 楽天モバイル](https://portal.mobile.rakuten.co.jp/my-rakuten-mobile?l-id=network_burger_ecare_b)

*   ご検討中の方へ
    
*   料金プラン・製品
    
*   通信エリア
    
*   [ショップ（店舗）](https://network.mobile.rakuten.co.jp/shop/?l-id=burger_shop_b)
    
*   キャンペーン
    
*   [お知らせ](https://network.mobile.rakuten.co.jp/information/?l-id=burger_info_b)
    
*   お客様サポート
    

[スーパーホーダイ／組み合わせプランをご利用中の方](https://mobile.rakuten.co.jp/mvno/?l-id=burger_mvno_b)

[法人のお客様](https://business.mobile.rakuten.co.jp/?scid=wi_rmb_pers_burger)

料金プラン・製品

スマートフォン

*   料金プラン
    
*   [![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-fee-simulation.svg)料金シミュレーション](https://network.mobile.rakuten.co.jp/fee/simulation/?l-id=burger_fee_un-limit_simulation_b)
    
*   [オプションサービス](https://network.mobile.rakuten.co.jp/service/?l-id=burger_service_b)
    
*   製品
    
*   ![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-sim.svg)SIM
    

おトクな割引・還元プログラムも必見

[![最強家族割](https://network.mobile.rakuten.co.jp/assets/img/common/img-family-251118.png)](https://network.mobile.rakuten.co.jp/fee/family/?l-id=burger_banner_fee-family_b)

[![最強こども割](https://network.mobile.rakuten.co.jp/assets/img/common/img-kids-251118.png)](https://network.mobile.rakuten.co.jp/fee/kids/?l-id=burger_banner_fee-kids_b)

[![最強青春割](https://network.mobile.rakuten.co.jp/assets/img/common/img-youth-251118.png)](https://network.mobile.rakuten.co.jp/fee/youth/?l-id=burger_banner_fee-youth_b)

[![最強シニアプログラム](https://network.mobile.rakuten.co.jp/assets/img/common/img-senior-251118.png)](https://network.mobile.rakuten.co.jp/fee/senior/?l-id=burger_banner_fee_senior_b)

インターネット・電気

*   Rakuten Turbo
    
*   楽天ひかり
    
*   ![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-energy.svg)楽天でんき
    

スマホとセットでおトク

*   ![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-saikyo-program.svg)最強おうちプログラム
    

料金プラン

料金プラン

*   [Rakuten最強プラン\
    \
    シンプルで使いやすいプラン](https://network.mobile.rakuten.co.jp/fee/saikyo-plan/?l-id=burger_fee_saikyo-plan_b)
    
*   [Rakuten最強プラン データタイプ\
    \
    データ通信のみ必要な方に](https://network.mobile.rakuten.co.jp/fee/saikyo-plan/data-type/?l-id=burger_fee_saikyo-plan_data-type_b)
    
*   [Rakuten最強U-NEXT\
    \
    動画や雑誌も楽しみたい方に](https://network.mobile.rakuten.co.jp/fee/unext/?l-id=burger_fee_unext_b)
    

割引プログラム

*   [最強家族割\
    \
    家族でトクしたい方に](https://network.mobile.rakuten.co.jp/fee/family/?l-id=burger_fee_family_b)
    
*   [最強こども割\
    \
    12歳までとーってもおトク](https://network.mobile.rakuten.co.jp/fee/kids/?l-id=burger_fee_kids_b)
    
*   [最強青春割\
    \
    22歳までずーっとおトク](https://network.mobile.rakuten.co.jp/fee/youth/?l-id=burger_fee_youth_b)
    
*   [最強シニアプログラム\
    \
    65歳以上からずーっと安心＆おトク](https://network.mobile.rakuten.co.jp/fee/senior/?l-id=burger_fee_senior_b)
    

製品

*   [製品トップ](https://network.mobile.rakuten.co.jp/product/?l-id=burger_product_b)
    
*   [iPhone](https://network.mobile.rakuten.co.jp/product/iphone/?l-id=burger_product_iphone_b)
    
*   [Apple Watch](https://network.mobile.rakuten.co.jp/product/apple-watch/?l-id=burger_product_apple-watch_b)
    
*   [Android](https://network.mobile.rakuten.co.jp/product/smartphone/?l-id=burger_product_smartphone_b)
    
*   [Wi-Fiルーター](https://network.mobile.rakuten.co.jp/product/internet/?l-id=burger_product_internet_b)
    
*   [アクセサリ](https://network.mobile.rakuten.co.jp/product/accessory/?l-id=burger_product_accessory_b)
    
*   [その他オススメ製品](https://network.mobile.rakuten.co.jp/product/ichiba-recommended/?l-id=burger_product_ichiba-recommended_b)
    

![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-sim.svg)SIM

*   [SIM](https://network.mobile.rakuten.co.jp/product/sim/?l-id=burger_product_sim_b)
    
*   [eSIM](https://network.mobile.rakuten.co.jp/product/sim/esim/?l-id=burger_product_sim_esim_b)
    
*   [デュアルSIM](https://network.mobile.rakuten.co.jp/product/sim/dual-sim/?l-id=burger_product_sim_dual-sim_b)
    
*   [ご利用製品の対応確認](https://network.mobile.rakuten.co.jp/product/byod/?l-id=burger_product_byod_b)
    

Rakuten Turbo

*   [トップ](https://network.mobile.rakuten.co.jp/internet/turbo/?l-id=burger_internet_turbo_b)
    
*   [料金プラン](https://network.mobile.rakuten.co.jp/internet/turbo/fee/?l-id=burger_internet_turbo_fee_b)
    

楽天ひかり

*   [トップ](https://network.mobile.rakuten.co.jp/hikari/?l-id=burger_hikari_b)
    
*   [料金プラン](https://network.mobile.rakuten.co.jp/hikari/fee/pricelist/?l-id=burger_hikari_fee_b)
    

通信エリア

*   [スマートフォン](https://network.mobile.rakuten.co.jp/area/?l-id=burger_area_b)
    
*   [Rakuten Turbo](https://network.mobile.rakuten.co.jp/internet/turbo/area/?l-id=burger_internet_turbo_area_b)
    

キャンペーン

*   [スマートフォン](https://network.mobile.rakuten.co.jp/campaign/?l-id=burger_campaign_b)
    
*   [Rakuten Turbo](https://network.mobile.rakuten.co.jp/internet/turbo/campaign/home-internet/?l-id=burger_internet_turbo_campaign_home-internet_b)
    
*   [楽天ひかり](https://network.mobile.rakuten.co.jp/hikari/campaign/home-internet/?l-id=burger_hikari_campaign_home-internet_b)
    
*   [楽天でんき](https://energy.rakuten.co.jp/campaign/lp/mobilelink/?scid=wi_rmb_gnavi_cpn)
    

ご検討中の方へ

*   [お申し込みガイド](https://network.mobile.rakuten.co.jp/guide/procedure/?l-id=burger_guide_procedure_b)
    
*   [なぜ今楽天モバイルなのか](https://network.mobile.rakuten.co.jp/feature/why-rakuten-mobile/?l-id=burger_feature_why-rakuten-mobile_b)
    
*   [お客様の声](https://network.mobile.rakuten.co.jp/uservoice/?l-id=burger_uservoice_b)
    
*   [スマホ活用術を学ぶ](https://network.mobile.rakuten.co.jp/sumakatsu/?l-id=burger_sumakatsu_b)
    

お客様サポート

*   [楽天モバイル](https://network.mobile.rakuten.co.jp/support/?l-id=burger_support_b)
    
*   [Rakuten Turbo](https://network.mobile.rakuten.co.jp/internet/turbo/support/?l-id=burger_internet_turbo_support_b)
    
*   [楽天ひかり](https://network.mobile.rakuten.co.jp/hikari/support/?l-id=burger_hikari_support_b)
    
*   [楽天でんき](https://energy.rakuten.co.jp/faq/?scid=wi_rmb_gnavi_qa)
    

![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-energy.svg)楽天でんき

*   [トップ](https://energy.rakuten.co.jp/electricity/?scid=wi_rmb_gnavi_top)
    
*   [料金プラン](https://energy.rakuten.co.jp/electricity/fee/?scid=wi_rmb_gnavi_plan)
    

![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-saikyo-program.svg)最強おうちプログラム

*   [トップ](https://network.mobile.rakuten.co.jp/campaign/home-internet/?l-id=burger_campaign_home-internet_c)
    
*   [スマホ＋Rakuten Turbo\
    \
    Rakuten Turbo 初めて申し込みで毎月1,000ポイント還元](https://network.mobile.rakuten.co.jp/internet/turbo/campaign/home-internet/?l-id=burger_internet_turbo_campaign_home-internet_c)
    
*   [スマホ＋楽天ひかり\
    \
    楽天ひかり初めて申し込みで毎月1,000ポイント還元](https://network.mobile.rakuten.co.jp/hikari/campaign/home-internet/?l-id=burger_hikari_campaign_home-internet_c)
    

*   [トップ](https://network.mobile.rakuten.co.jp/)
    
*   [Rakuten最強プラン（料金プラン）](https://network.mobile.rakuten.co.jp/fee/saikyo-plan/)
    
*   料金シミュレーション（料金比較）

![料金＆ポイントシミュレーション！楽天モバイルと他社プランで比較！毎月どれだけおトクになる？3ステップでわかる！](https://network.mobile.rakuten.co.jp/assets/img/fee/simulation/kv-pc-241203.png)
===========================================================================================================================================

![STEP1](https://network.mobile.rakuten.co.jp/assets/img/fee/simulation/step1-pc.png)

![](https://network.mobile.rakuten.co.jp/assets/img/fee/simulation/ask2-icon.png)いまどの携帯電話会社を  
使っていますか？
-------------------------------------------------------------------------------------------------------

![](https://network.mobile.rakuten.co.jp/assets/img/fee/simulation/panda-2-240419.png)

docomo  
\-従来のプラン\-docomo  
\-eximo\-docomo  
\-irumo\-docomo  
\-mini/MAX\-au  
\-従来のプラン\-au  
\-バリューリンク\-SoftBankSoftBank  
\-ペイトク\-Y!mobile  
\-従来のプラン\-Y!mobile  
\-シンプル2\-UQ mobile  
\-従来のプラン-UQ mobile  
\-コミコミ/トクトク-ahamopovo2.0LINEMO  
\-ベストプラン\-その他

![](https://network.mobile.rakuten.co.jp/assets/img/fee/simulation/arrow-pc.png)

![STEP2](https://network.mobile.rakuten.co.jp/assets/img/fee/simulation/step2-pc.png)

![](https://network.mobile.rakuten.co.jp/assets/img/fee/simulation/ask1-icon.png)どのくらいデータを  
使いますか？
---------------------------------------------------------------------------------------------------

Wi-Fi接続時のデータ利用は含めずに選択してね

![](https://network.mobile.rakuten.co.jp/assets/img/fee/simulation/panda-1-240419.png)

*   データ利用量で選ぶ
*   利用頻度で選ぶ

### ![](https://network.mobile.rakuten.co.jp/assets/img/fee/simulation/steptab1-icon.png)1カ月の利用量はどのくらいですか？

選択してください

### ![](https://network.mobile.rakuten.co.jp/assets/img/fee/simulation/ask2-sub1-icon.png)LINEやメールで、文字やスタンプを1日にどのくらいやりとりしますか？

![](https://network.mobile.rakuten.co.jp/assets/img/fee/simulation/panda-4-240419.png)

ほとんどしない10回30回50回100回以上

### ![](https://network.mobile.rakuten.co.jp/assets/img/fee/simulation/ask2-sub2-icon.png)写真や動画などのデータを1日にどのくらいやりとりしますか？

ほとんどしない5回10回30回50回以上

### ![](https://network.mobile.rakuten.co.jp/assets/img/fee/simulation/ask2-sub3-icon.png)SNSやWebサイトは１日に何時間くらい見ますか？

![](https://network.mobile.rakuten.co.jp/assets/img/fee/simulation/panda-5-240419.png)

ほとんど見ない10分30分1時間3時間5時間以上

### ![](https://network.mobile.rakuten.co.jp/assets/img/fee/simulation/ask2-sub4-icon.png)動画は1日に何時間くらい見ますか？

ほとんど見ない10分30分1時間3時間5時間以上

![](https://network.mobile.rakuten.co.jp/assets/img/fee/simulation/arrow-pc.png)

![STEP3](https://network.mobile.rakuten.co.jp/assets/img/fee/simulation/step3-pc.png)

![](https://network.mobile.rakuten.co.jp/assets/img/fee/simulation/ask1-icon.png)家族割引を  
使っていますか？
-------------------------------------------------------------------------------------------------

ご契約中の回線数を選択してね

![](https://network.mobile.rakuten.co.jp/assets/img/fee/simulation/panda-3-240419.png)

なし2回線3回線以上

![](https://network.mobile.rakuten.co.jp/assets/img/fee/simulation/panda-btn.png)

シミュレーション結果を見る

※掲載している情報は2025年8月12日時点の情報です。あくまでも目安の金額です。実際のご利用状況によりご請求額とは異なる場合があります。結果情報の一部は楽天モバイルがサービス向上のために使用します。

データ利用量の消費の目安ってどのくらい？

*   ※下記はあくまで1コンテンツを単独で利用した目安のデータ量です。写真や動画については画質やサイズなどによって使用するデータ通信量が変動いたします
*   ※ご利用状況や操作内容の組み合わせにより、ご利用できる内容は変動します
*   ※掲載の商品名称やサービス名称などは、一般に各社の商標または登録商標です
*   ※各社の商標記載においては™や®などの商標表示を省略する場合があります

#### ■Google（Web検索）

約1.8MB／1ページ

| データ利用量 | 利用可能目安 |
| --- | --- |
| 1GB | 約625ページ |

※1ページ閲覧で1.8MB消費した場合

#### ■Google マップ

約1MB／1経路検索

| データ利用量 | 利用可能目安 |
| --- | --- |
| 1GB | 約1,000回 |

※1経路の検索あたり約1MB消費した場合

#### ■Google 翻訳

約2MB／10文

| データ利用量 | 利用可能目安 |
| --- | --- |
| 1GB | 約5,000文 |

※10文の翻訳で約2MB消費した場合

#### ■メール送信

テキスト送信：約5KB／1通

| データ利用量 | 利用可能目安 |
| --- | --- |
| 1GB | 約20万通 |

※1通のテキスト送信で約5KB消費した場合

写真添付送信：約500KB／1通

| データ利用量 | 利用可能目安 |
| --- | --- |
| 1GB | 約2,000通 |

※1通の写真添付送信で約500KB消費した場合

#### ■LINE

テキスト送信：約3KB／1トーク

| データ利用量 | 利用可能目安 |
| --- | --- |
| 1GB | 約33万回 |

※1トーク送信するのに約3KB消費した場合

無料通話：約0.3MB／1分

| データ利用量 | 利用可能目安 |
| --- | --- |
| 1GB | 約55時間 |

※1分無料通話するのに約0.3MB消費した場合

ビデオ通話：約5.1MB／1分

| データ利用量 | 利用可能目安 |
| --- | --- |
| 1GB | 約3時間 |

※1分ビデオ通話するのに約5.1MB消費した場合

#### ■YouTube

標準画質：約450MB／1時間

| データ利用量 | 利用可能目安 |
| --- | --- |
| 1GB | 約2.2時間 |

※標準画質で1時間視聴するのに約450MB消費した場合

#### ■動画配信サービス（Netflix）

Netflix（HD画質）：約1,300MB／1時間

| データ利用量 | 利用可能目安 |
| --- | --- |
| 1GB | 約0.8時間 |

※Netflix（HD画質）で1時間視聴するのに約1,300MB消費した場合

※製品代、契約事務手数料、データチャージを含むオプション料、通話料等は別費用。

※掲載している情報は2025年8月12日時点の情報です。以下の利用量でシミュレーションしています。あくまでも目安です。実際のご利用状況によりデータ利用量は変動します。1カ月は30日で計算しています。

■LINEやメールのやりとり：7KB／1回あたりで計算  
※メール：約500KB／1通（添付ファイル含む）  
※LINE（文字）：約3KB／1トーク  
※LINE（スタンプ）：約5〜10KB／1回  
※ほとんどしない：月5回で計算

■写真や動画のやりとり（送受信）：3MB／1回で計算  
※写真：300KB／1枚（低画質の場合）3MB／1枚（オリジナル画質の場合）  
※動画：約6MB（30秒）  
※画質やサイズにより異なる  
※ほとんどしない：月5回で計算

■SNSやWebサイト閲覧：400MB／1時間で計算  
※SNSはサービスによって異なる  
※Google Web検索：約1.8MB／1ページ  
※ほとんど見ない：月30分で計算

■動画閲覧：600MB／1時間で計算  
※YouTubeをSD画質で閲覧した場合  
※ほとんど見ない：月30分で計算

続けてこちらをチェック
-----------

*   [料金プランRakuten最強プランの詳細、お申し込みはこちらから](https://network.mobile.rakuten.co.jp/fee/saikyo-plan/?l-id=footer_fee_saikyo)
    
*   [製品楽天モバイル対応、5G対応スマートフォンはこちら](https://network.mobile.rakuten.co.jp/product/?l-id=footer_product)
    
*   [ショップお近くの楽天モバイルショップ検索はこちらから](https://network.mobile.rakuten.co.jp/shop/?l-id=footer_shop)
    

*   [トップ](https://network.mobile.rakuten.co.jp/)
    
*   [Rakuten最強プラン（料金プラン）](https://network.mobile.rakuten.co.jp/fee/saikyo-plan/)
    
*   料金シミュレーション（料金比較）

*   [会社概要](https://corp.mobile.rakuten.co.jp/)
    
*   [法人のお客様](https://business.mobile.rakuten.co.jp/?scid=wi_rmb_pers_footer)
    
*   [法人パートナープログラム](https://business.mobile.rakuten.co.jp/partner/?scid=wi_rmb_pers_footer)
    
*   [個人情報の取扱いについて](https://corp.mobile.rakuten.co.jp/guide/privacy/)
    
*   [情報セキュリティポリシー](https://corp.mobile.rakuten.co.jp/guide/security/)
    
*   [商標・登録商標について](https://corp.mobile.rakuten.co.jp/guide/trademark/)
    
*   [古物営業法に基づく表示](https://network.mobile.rakuten.co.jp/secondhand-dealer/)
    
*   [利用規約](https://network.mobile.rakuten.co.jp/terms/)
    
*   [外部送信される情報の取り扱いについて](https://network.mobile.rakuten.co.jp/optout/)
    

© Rakuten Mobile, Inc.

[![AIも、楽天グループなら安心](https://network.mobile.rakuten.co.jp/assets/img/common/bnr-ai-safety-240-75-250530.png)](https://corp.rakuten.co.jp/ai/ai-safety/?scid=wi_rmb_aisafety)

[![【Go Green Together】同社の従来ネットワーク比較 消費電力約20%削減へ 募金キャンペーン実施中](https://network.mobile.rakuten.co.jp/assets/img/common/bnr-green-charity-240-75-250530.png)](https://network.mobile.rakuten.co.jp/campaign/green-charity/?l-id=footer_campaign_green-charity)

*   楽天グループ
*   [サービス一覧](https://www.rakuten.co.jp/sitemap/)
    
*   [お問い合わせ一覧](https://www.rakuten.co.jp/sitemap/inquiry.html)
    
*   [サステナビリティ](https://corp.rakuten.co.jp/sustainability/)
    

[![申し込み・相談 AIサポート](https://network.mobile.rakuten.co.jp/assets/img/common/gen-ai-link-balloon-pc-250804.svg)![](https://network.mobile.rakuten.co.jp/assets/img/common/gen-ai-link-icon-pc-250804.svg)](https://network.mobile.rakuten.co.jp/chat/?l-id=assist-ai)
![閉じる](https://network.mobile.rakuten.co.jp/assets/img/common/gen-ai-close.svg)
