# J:COM 公式サイト | ケーブルテレビ（CATV）・インターネット・電話・格安スマホ・電気

URL: https://www.jcom.co.jp/

---

[![あたらしいを、あたりまえに。 J:COM](https://www.jcom.co.jp/common_v10/images/logo-jcom-white.svg)](https://www.jcom.co.jp/?sc_pid=common_jcomlogo_01)

===========================================================================================================================================

*   [はじめての方へ](https://www.jcom.co.jp/beginner/?sc_pid=globalnavi_beginner_01)
    
*   ご利用中の方
*   [オンラインショップ](https://onlineshop.jcom.co.jp/?sc_pid=globalnavi_ols_01)
    

J:COMサービスご利用中の方

[ご契約内容確認・変更  \
マイページログイン](https://mypage.jcom.co.jp/?sc_pid=common_mypage_01)
 [お困りごと解決・よくあるご質問  \
お客さまサポート](https://cs.myjcom.jp/?sc_pid=common_suppot_01)
 [もっとJ:COMを楽しみたい  \
テレビ番組情報／プレゼント・優待  \
Fun! J:COM](https://www.myjcom.jp/?sc_pid=common_myj_01)

    ![検索](https://www.jcom.co.jp/common_v10/images/snav-icn-search-submit.svg)

*   [あなたへの  \
    お知らせ](https://id.zaq.ne.jp/id/script/connect/authz_req/endpoint.seam?response_type=code&client_id=JCOM_COJP&redirect_uri=https%3A%2F%2Fwww.jcom.co.jp%2F&scope=http%3A%2F%2Fjcom.co.jp%2Fconnect%2Fprofile%2Fstandard_new&nonce=1527334654&state=&prompt=)
    
*   [あなたへの  \
    お知らせ](https://www.jcom.co.jp/#)
    

Language

*   日本語
*   English
*   简体中文
*   한국어
*   Tiếng Việt
*   Português

*   サービス
*   [料金一覧](https://www.jcom.co.jp/price/)
    
*   [キャンペーン・  \
    特典](https://www.jcom.co.jp/campaign/)
    
*   お申し込み・  
    各種変更
*   サポート
*   企業サイト

[サービス紹介 トップ](https://www.jcom.co.jp/service/)

[テレビ](https://www.jcom.co.jp/service/tv/)
 [ネット](https://www.jcom.co.jp/service/net/)
 [スマホ](https://www.jcom.co.jp/service/mobile/)
 [でんき](https://www.jcom.co.jp/service/electricity/)
 [固定電話](https://www.jcom.co.jp/service/phone/)
 [ガス](https://www.jcom.co.jp/service/gas/)
 [ほけん](https://www.jcom.co.jp/service/ssi/)
 [ローン](https://www.jcom-financial.co.jp/)
 [防犯カメラ](https://www.jcom.co.jp/guide/starter/home_security/)
 [オンライン診療](https://www.jcom.co.jp/service/telemedicine/)
 [法人・自治体向けサービス![J:COM BUSINESS](https://www.jcom.co.jp/common_v10/images/logo_jcombusiness.webp)](https://business.jcom.co.jp/)

[お申し込み・お問い合わせ](https://www.jcom.co.jp/contactus/)

新規ご加入の方

[新規ご加入の方  \
お申し込み](https://onlineshop.jcom.co.jp/planSelect)

[新規ご加入の方  \
お問い合わせ](https://www.jcom.co.jp/contactus/#entry)

J:COMサービスご利用中の方

[ご利用中の方  \
各種お手続き](https://r.jcom.jp/eG4nLSC)

[お困りごと・お問い合わせ  \
（チャット）](https://prod8-live-chat.sprinklr.com/page?appId=67af27d73657336d345e4a96_app_9070639&did=CHAT_vivr_cojp_top&enableClose=true&skin=MODERN&userContext__c_679c8b53cb85b007fab0f6ea=DirectLink&utm_campaign=IVRSMS&utm_medium=referral&utm_source=did&webview=true&zoom=false)

あなたにピッタリのプランがすぐわかる

[料金シミュレーション](https://onlineshop.jcom.co.jp/Simulation/Simulation)

無料・特別料金の物件も！

対応エリア・物件をご案内

[企業サイト](https://www.jcom.co.jp/corporate/)

[企業理念](https://www.jcom.co.jp/corporate/philosophy_brand/)

[サステナビリティ](https://www.jcom.co.jp/corporate/sustainability/)

[中期経営計画](https://www.jcom.co.jp/corporate/managementplan/)

[ニュースリリース](https://newsreleases.jcom.co.jp/)

[会社案内](https://www.jcom.co.jp/corporate/company/)

[採用情報](https://recruit.jcom.co.jp/)

[サポート トップ](https://cs.myjcom.jp/)

[テレビ](https://cs.myjcom.jp/categories/support/67ab976bf07f5244a208cb97)
 [ネット](https://cs.myjcom.jp/categories/support/67ab9788f07f5244a208cced)
 [スマホ](https://cs.myjcom.jp/categories/support/67ab979df07f5244a208cdc9)
 [でんき](https://cs.myjcom.jp/categories/support/67ab97b5f07f5244a208cec9)
 [固定電話](https://cs.myjcom.jp/categories/support/67ab97abf07f5244a208ce4e)
 [ガス](https://cs.myjcom.jp/categories/support/67ab97b8f07f5244a208ceda)
 [ほけん](https://cs.myjcom.jp/categories/support/67ab97c5f07f5244a208cf2f)
 [オンライン診療](https://cs.myjcom.jp/categories/support/67ab97c2f07f5244a208cf1b)
 [ホームIoT](https://cs.myjcom.jp/categories/support/67ab97bcf07f5244a208cee6)
 [防犯カメラ](https://cs.myjcom.jp/categories/support/67ab97f5f07f5244a208d09b)

[J:COM STREAM](https://cs.myjcom.jp/categories/support/67ab97c9f07f5244a208cf49)

[えんかくサポート](https://cs.myjcom.jp/categories/support/67ab97faf07f5244a208d0c2)

[おうちサポート](https://cs.myjcom.jp/categories/support/67ab97d4f07f5244a208cf92)

[防災情報サービス](https://cs.myjcom.jp/categories/support/67ab97d8f07f5244a208cfa0)

[自転車生活サポート](https://cs.myjcom.jp/categories/support/67ab97e8f07f5244a208d023)

[J:COMブックス](https://cs.myjcom.jp/categories/support/67ab97e4f07f5244a208d003)

[WiMAX](https://cs.myjcom.jp/categories/support/67ab97f1f07f5244a208d074)

[障害・メンテナンス情報](https://information.myjcom.jp/maintenance_outage/)

各種お手続き

[パーソナルID](https://cs.myjcom.jp/categories/support/67ab9803f07f5244a208d113)

[料金・支払い](https://cs.myjcom.jp/categories/support/67ab9805f07f5244a208d139)

[引越し・建替え](https://cs.myjcom.jp/categories/support/67ab980cf07f5244a208d184)

[訪問・窓口](https://cs.myjcom.jp/categories/support/67ab980ff07f5244a208d1a4)

[契約関連](https://cs.myjcom.jp/categories/support/67ab9806f07f5244a208d150)

[休止・解約](https://cs.myjcom.jp/categories/support/67ab980cf07f5244a208d188)

[加入特典](https://cs.myjcom.jp/categories/support/67ab980df07f5244a208d18c)

[![あたらしいを、あたりまえに J:COM](https://www.jcom.co.jp/common_v10/images/logo-jcom-white.svg)](https://www.jcom.co.jp/?sc_pid=common_jcomlogo_01)

[![あたらしいを、あたりまえに J:COM](https://www.jcom.co.jp/common_v10/images/logo-jcom.svg)](https://www.jcom.co.jp/)

*   サービス
*   [料金一覧](https://www.jcom.co.jp/price/)
    
*   [キャンペーン・  \
    特典](https://www.jcom.co.jp/campaign/)
    
*   お申し込み・  
    各種変更
*   サポート
*   企業サイト

![検索する](https://www.jcom.co.jp/common_v10/images/fixed-nav-icn-search.svg)

    ![検索](https://www.jcom.co.jp/common_v10/images/snav-icn-search-submit.svg)

[サービス紹介 トップ](https://www.jcom.co.jp/service/)

[テレビ](https://www.jcom.co.jp/service/tv/)
 [ネット](https://www.jcom.co.jp/service/net/)
 [スマホ](https://www.jcom.co.jp/service/mobile/)
 [でんき](https://www.jcom.co.jp/service/electricity/)
 [固定電話](https://www.jcom.co.jp/service/phone/)
 [ガス](https://www.jcom.co.jp/service/gas/)
 [ほけん](https://www.jcom.co.jp/service/ssi/)
 [ローン](https://www.jcom-financial.co.jp/)
 [防犯カメラ](https://www.jcom.co.jp/guide/starter/home_security/)
 [オンライン診療](https://www.jcom.co.jp/service/telemedicine/)
 [法人・自治体向けサービス![J:COM BUSINESS](https://www.jcom.co.jp/common_v10/images/logo_jcombusiness.webp)](https://business.jcom.co.jp/)

[お申し込み・お問い合わせ](https://www.jcom.co.jp/contactus/)

新規ご加入の方

[新規ご加入の方  \
お申し込み](https://onlineshop.jcom.co.jp/planSelect)

[新規ご加入の方  \
お問い合わせ](https://www.jcom.co.jp/contactus/#entry)

J:COMサービスご利用中の方

[ご利用中の方  \
各種お手続き](https://r.jcom.jp/eG4nLSC)

[お困りごと・お問い合わせ  \
（チャット）](https://prod8-live-chat.sprinklr.com/page?appId=67af27d73657336d345e4a96_app_9070639&did=CHAT_vivr_cojp_top&enableClose=true&skin=MODERN&userContext__c_679c8b53cb85b007fab0f6ea=DirectLink&utm_campaign=IVRSMS&utm_medium=referral&utm_source=did&webview=true&zoom=false)

あなたにピッタリのプランがすぐわかる

[料金シミュレーション](https://onlineshop.jcom.co.jp/Simulation/Simulation)

無料・特別料金の物件も！

対応エリア・物件をご案内

[企業サイト](https://www.jcom.co.jp/corporate/)

[企業理念](https://www.jcom.co.jp/corporate/philosophy_brand/)

[サステナビリティ](https://www.jcom.co.jp/corporate/sustainability/)

[中期経営計画](https://www.jcom.co.jp/corporate/managementplan/)

[ニュースリリース](https://newsreleases.jcom.co.jp/)

[会社案内](https://www.jcom.co.jp/corporate/company/)

[採用情報](https://recruit.jcom.co.jp/)

[サポート トップ](https://cs.myjcom.jp/)

[テレビ](https://cs.myjcom.jp/categories/support/67ab976bf07f5244a208cb97)
 [ネット](https://cs.myjcom.jp/categories/support/67ab9788f07f5244a208cced)
 [スマホ](https://cs.myjcom.jp/categories/support/67ab979df07f5244a208cdc9)
 [でんき](https://cs.myjcom.jp/categories/support/67ab97b5f07f5244a208cec9)
 [固定電話](https://cs.myjcom.jp/categories/support/67ab97abf07f5244a208ce4e)
 [ガス](https://cs.myjcom.jp/categories/support/67ab97b8f07f5244a208ceda)
 [ほけん](https://cs.myjcom.jp/categories/support/67ab97c5f07f5244a208cf2f)
 [オンライン診療](https://cs.myjcom.jp/categories/support/67ab97c2f07f5244a208cf1b)
 [ホームIoT](https://cs.myjcom.jp/categories/support/67ab97bcf07f5244a208cee6)
 [防犯カメラ](https://cs.myjcom.jp/categories/support/67ab97f5f07f5244a208d09b)

[J:COM STREAM](https://cs.myjcom.jp/categories/support/67ab97c9f07f5244a208cf49)

[えんかくサポート](https://cs.myjcom.jp/categories/support/67ab97faf07f5244a208d0c2)

[おうちサポート](https://cs.myjcom.jp/categories/support/67ab97d4f07f5244a208cf92)

[防災情報サービス](https://cs.myjcom.jp/categories/support/67ab97d8f07f5244a208cfa0)

[自転車生活サポート](https://cs.myjcom.jp/categories/support/67ab97e8f07f5244a208d023)

[J:COMブックス](https://cs.myjcom.jp/categories/support/67ab97e4f07f5244a208d003)

[WiMAX](https://cs.myjcom.jp/categories/support/67ab97f1f07f5244a208d074)

[障害・メンテナンス情報](https://information.myjcom.jp/maintenance_outage/)

各種お手続き

[パーソナルID](https://cs.myjcom.jp/categories/support/67ab9803f07f5244a208d113)

[料金・支払い](https://cs.myjcom.jp/categories/support/67ab9805f07f5244a208d139)

[引越し・建替え](https://cs.myjcom.jp/categories/support/67ab980cf07f5244a208d184)

[訪問・窓口](https://cs.myjcom.jp/categories/support/67ab980ff07f5244a208d1a4)

[契約関連](https://cs.myjcom.jp/categories/support/67ab9806f07f5244a208d150)

[休止・解約](https://cs.myjcom.jp/categories/support/67ab980cf07f5244a208d188)

[加入特典](https://cs.myjcom.jp/categories/support/67ab980df07f5244a208d18c)

*   ![メニュー](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/text-menu.svg)
*   ![お申し込み](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/text-entry.svg)
*   ![テレビ](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/text-jcom-tv.svg)
*   ![ネット](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/text-jcom-net.svg)
*   ![スマホ](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/text-jcom-mobile.svg)
*   ![電気](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/text-jcom-electricity.svg)
*   ![その他のサービス](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/text-other.svg)
*   [![サポート](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/text-support.svg)](https://cs.myjcom.jp/)
    

*   [![あたらしいを、あたりまえに　J:COM](https://www.jcom.co.jp/common_v10/images/logo-jcom-only-white.svg)](https://www.jcom.co.jp/)
     ![メニューを閉じる](https://www.jcom.co.jp/common_v10/images/sp-menu/menu-close-white.svg)
    
    [J:COMのサービス](https://www.jcom.co.jp/service/)
    
    *   [![テレビ](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-tv-item.svg)](https://www.jcom.co.jp/service/tv/)
        
    *   [![ネット](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-net-item.svg)](https://www.jcom.co.jp/service/net/)
        
    *   [![スマホ](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-mobile-item.svg)](https://www.jcom.co.jp/service/mobile/)
        
    
    *   [![電気](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-electricity-item.svg)](https://www.jcom.co.jp/service/electricity/)
        
    *   [![固定電話](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-phone-item.svg)](https://www.jcom.co.jp/service/phone/)
        
    *   [![ガス](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-gas-item.svg)](https://www.jcom.co.jp/service/gas/)
        
    *   [![ほけん](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-ssi-item.svg)](https://www.jcom.co.jp/service/ssi/)
        
    *   [ローン](https://www.jcom-financial.co.jp/)
        
    *   [![ホームIoT](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-home-item.svg)](https://www.jcom.co.jp/service/home/)
        
    *   [防犯カメラ](https://www.jcom.co.jp/guide/starter/home_security/)
        
    *   [![オンライン診療](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-telemedicine-item.svg)](https://www.jcom.co.jp/service/telemedicine/)
        
    
    [法人・自治体向けサービス  \
    ![J:COM BUSINESS](https://www.jcom.co.jp/common_v10/images/logo_jcombusiness.webp)](https://business.jcom.co.jp/)
    
    サービス一覧
    
    [料金一覧](https://www.jcom.co.jp/price/)
     [キャンペーン・特典](https://www.jcom.co.jp/campaign/)
     [サポート](https://cs.myjcom.jp/)
     [お申し込み・各種変更](https://www.jcom.co.jp/contactus/)
    
        ![検索](https://www.jcom.co.jp/common_v10/images/snav-icn-search-submit-sp.svg)
    
    [J:COM トップ](https://www.jcom.co.jp/)
    
    *   [サービス情報](https://www.jcom.co.jp/)
        
    *   [オンライン  \
        ショップ](https://onlineshop.jcom.co.jp/)
        
    *   [サポート](https://cs.myjcom.jp/)
        
    *   [Fun! J:COM](https://www.myjcom.jp/)
        
    *   [マイページ](https://mypage.jcom.co.jp/)
        
    *   [企業サイト](https://www.jcom.co.jp/corporate/)
        
    
*   [お申し込み・お問い合わせ](https://www.jcom.co.jp/contactus/)
     ![メニューを閉じる](https://www.jcom.co.jp/common_v10/images/sp-menu/menu-close.svg)
    
    新規ご加入の方
    
    [新規ご加入の方 お申し込み](https://onlineshop.jcom.co.jp/planSelect)
     [新規ご加入の方 お問い合わせ](https://www.jcom.co.jp/contactus/#entry)
    
    あなたにピッタリの  
    プランがすぐわかる
    
    無料・特別料金  
    の物件も！
    
    [料金シミュ  \
    レーション](https://onlineshop.jcom.co.jp/Simulation/Simulation)
    
    [対応エリア・  \
    物件をご案内](https://www.jcom.co.jp/#)
    
    J:COMサービスご利用中の方
    
    [ご利用中の方  \
    各種お手続き](https://r.jcom.jp/eG4nLSC)
    
    [お困りごと・  \
    お問い合わせ](https://prod8-live-chat.sprinklr.com/page?appId=67af27d73657336d345e4a96_app_9070639&did=CHAT_vivr_cojp_top&enableClose=true&skin=MODERN&userContext__c_679c8b53cb85b007fab0f6ea=DirectLink&utm_campaign=IVRSMS&utm_medium=referral&utm_source=did&webview=true&zoom=false)
    
*   [![J:COM TV](https://www.jcom.co.jp/common_v10/images/icn-jcom-tv.svg)テレビ](https://www.jcom.co.jp/service/tv/)
     ![メニューを閉じる](https://www.jcom.co.jp/common_v10/images/sp-menu/menu-close.svg)
    
    [![](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom-tv/slide/menu/mv-middle.webp)\
    \
    あなたの見たいを叶える\
    \
    トップ](https://www.jcom.co.jp/service/tv/)
    
    *   料金・コース
        
        *   [料金・コース トップ](https://www.jcom.co.jp/service/tv/course/)
            
        *   [J:COM TV シン・スタンダード](https://www.jcom.co.jp/service/tv/course/standard.html)
            
        *   [J:COM TV シン・スタンダードプラス](https://www.jcom.co.jp/service/tv/course/standard_plus.html)
            
        *   [J:COM TV セレクト](https://www.jcom.co.jp/service/tv/course/select.html)
            
        
    *   多彩なコンテンツ
        
        *   [多彩なコンテンツ トップ](https://www.jcom.co.jp/service/tv/channel/)
            
        *   [チャンネルラインアップ](https://www.jcom.co.jp/service/tv/channel/list/)
            
        *   [オプションチャンネル](https://www.jcom.co.jp/service/tv/channel/option_ch/)
            
        *   [コース別チャンネル比較表](https://www.jcom.co.jp/service/tv/channel/comparison/)
            
        
    *   [ネット動画](https://www.jcom.co.jp/service/tv/smart/ott.html)
        
    *   [便利な機能](https://www.jcom.co.jp/service/tv/smart/)
        
    *   オプション
        
        *   [オプション トップ](https://www.jcom.co.jp/service/tv/accessories/)
            
        *   [J:COM Netflixセット](https://www.jcom.co.jp/guide/starter/netflix/)
            
        *   [録画用ハードディスク](https://www.jcom.co.jp/service/tv/accessories/hdd/)
            
        *   [J:COM LINK mini](https://www.jcom.co.jp/service/tv/accessories/linkmini/)
            
        
    *   [お申し込みの流れ](https://www.jcom.co.jp/service/tv/guide/)
        
    
*   [![J:COM NET](https://www.jcom.co.jp/common_v10/images/icn-jcom-net.svg)ネット](https://www.jcom.co.jp/service/net/)
     ![メニューを閉じる](https://www.jcom.co.jp/common_v10/images/sp-menu/menu-close-white.svg)
    
    [![](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom-net/slide/menu/mv-middle.webp)\
    \
    もっと速く、もっと快適に\
    \
    トップ](https://www.jcom.co.jp/service/net/)
    
    *   [料金・コース](https://www.jcom.co.jp/service/net/course/)
        
    *   オプション
        
        *   [オプション トップ](https://www.jcom.co.jp/service/net/option/)
            
        *   [メッシュWi-Fi](https://www.jcom.co.jp/service/net/option/mesh-wi-fi/)
            
        *   [J:COM LINK mini](https://www.jcom.co.jp/service/net/option/linkmini/)
            
        
    *   [サポート](https://www.jcom.co.jp/service/net/support/)
        
    *   [お申し込みの流れ](https://www.jcom.co.jp/service/net/guide/)
        
    
*   [![J:COM MOBILE](https://www.jcom.co.jp/common_v10/images/icn-jcom-mobile.svg)スマホ](https://www.jcom.co.jp/service/mobile/)
     ![メニューを閉じる](https://www.jcom.co.jp/common_v10/images/sp-menu/menu-close-white.svg)
    
    [![](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom-mobile/slide/menu/mv-middle.webp)\
    \
    ずーっとおトク\
    \
    トップ](https://www.jcom.co.jp/service/mobile/)
    
    *   料金
        
        *   [料金 トップ](https://www.jcom.co.jp/service/mobile/price/)
            
        *   [通話料・SMS通信料](https://www.jcom.co.jp/service/mobile/price/detail/)
            
        *   [データ盛](https://www.jcom.co.jp/service/mobile/price/datamori/)
            
        *   [お子さま向けプラン](https://www.jcom.co.jp/service/mobile/price/kids/)
            
        *   [シニア向けプラン](https://www.jcom.co.jp/service/mobile/campaign/senior/)
            
        *   [5Gについて](https://www.jcom.co.jp/service/mobile/special/5g/)
            
        *   [3Gサービス終了について](https://www.jcom.co.jp/service/mobile/special/3g/)
            
        
    *   製品
        
        *   [製品 トップ](https://www.jcom.co.jp/service/mobile/device/)
            
        *   [iPhone 16e](https://www.jcom.co.jp/service/mobile/device/iphone_16e/)
            
        *   [iPhone 15](https://www.jcom.co.jp/service/mobile/device/iphone_15/)
            
        *   [Google Pixel 8a](https://www.jcom.co.jp/service/mobile/device/pixel_8a/)
            
        *   [AQUOS sense10](https://www.jcom.co.jp/service/mobile/device/aquos_sense10/)
            
        *   [Samsung Galaxy A25 5G](https://www.jcom.co.jp/service/mobile/device/galaxy_a25_5g/)
            
        *   [BASIO active2](https://www.jcom.co.jp/service/mobile/device/basio_active2/)
            
        
    *   SIM
        
        *   [格安SIM トップ](https://www.jcom.co.jp/service/mobile/device/sim/)
            
        *   [eSIM](https://www.jcom.co.jp/service/mobile/device/sim/esim/)
            
        *   [詳細](https://www.jcom.co.jp/service/mobile/device/sim/detail/)
            
        *   [動作確認端末チェッカー](https://www.jcom.co.jp/service/mobile/device/sim/detail/device.html)
            
        *   [SIMロック解除について](https://www.jcom.co.jp/service/mobile/device/sim/detail/simunlock.html)
            
        
    *   オプション
        
        *   [オプション トップ](https://www.jcom.co.jp/service/mobile/option/)
            
        *   [かけ放題](https://www.jcom.co.jp/service/mobile/option/kakehodai/)
            
        *   [迷惑電話・メッセージブロック](https://www.jcom.co.jp/service/mobile/option/block/)
            
        *   [家族のスマホ保険](https://www.jcom.co.jp/service/ssi/kazoku_sumaho/)
            
        *   [安心端末保証60](https://www.jcom.co.jp/service/mobile/option/guaranty60/)
            
        *   [AppleCare+ for iPhone](https://www.jcom.co.jp/service/mobile/device/support/applecare.html)
            
        *   [あんしんフィルター for J:COM](https://www.jcom.co.jp/service/mobile/option/anshin_filter/)
            
        *   [アクセサリーの追加購入](https://www.jcom.co.jp/service/mobile/option/accessories/add/)
            
        
    *   初期設定サポート
        
        *   [初期設定サポート　トップ](https://www.jcom.co.jp/service/mobile/support/)
            
        *   [よくある質問](https://www.jcom.co.jp/service/mobile/support/faq/)
            
        *   [スマホ乗り換え Q&A](https://www.jcom.co.jp/service/mobile/support/qa/)
            
        
    *   [お申し込みの流れ](https://www.jcom.co.jp/service/mobile/usage/)
        
    *   [ご利用中の方](https://cs.myjcom.jp/jcomMobile)
        
    *   [法人の方](https://business.jcom.co.jp/smb/mobile/)
        
    
*   [![J:COM でんき](https://www.jcom.co.jp/common_v10/images/icn-jcom-electricity.svg)でんき](https://www.jcom.co.jp/service/electricity/)
     ![メニューを閉じる](https://www.jcom.co.jp/common_v10/images/sp-menu/menu-close-white.svg)
    
    [![](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom-electricity/slide/menu/mv-middle.webp)\
    \
    品質そのままで安心\
    \
    トップ](https://www.jcom.co.jp/service/electricity/)
    
    *   料金メニュー
        
        *   [料金メニュー トップ](https://www.jcom.co.jp/service/electricity/price/)
            
        *   [東京電力エリア](https://www.jcom.co.jp/service/electricity/price/tokyo_juryo.html)
            
        *   [関西電力エリア](https://www.jcom.co.jp/service/electricity/price/kansai_juryo.html)
            
        *   [東北電力エリア](https://www.jcom.co.jp/service/electricity/price/tohoku_juryo.html)
            
        *   [中国電力エリア](https://www.jcom.co.jp/service/electricity/price/chugoku_juryo.html)
            
        *   [九州電力エリア](https://www.jcom.co.jp/service/electricity/price/kyushu_juryo.html)
            
        *   [北海道電力エリア](https://www.jcom.co.jp/service/electricity/price/hokkaido_juryo.html)
            
        
    *   グリーンメニュー
        
        *   [グリーンメニュー トップ](https://www.jcom.co.jp/service/electricity/price/green/)
            
        *   [料金](https://www.jcom.co.jp/service/electricity/price/green/price_list/)
            
        
    *   [J:COMでんきの  \
        しくみ](https://www.jcom.co.jp/service/electricity/feature/)
        
    *   [お申し込みの流れ](https://www.jcom.co.jp/service/electricity/flow/)
        
    *   [ご利用中の方](https://cs.myjcom.jp/ele)
        
    
*   [![あたらしいを、あたりまえに　J:COM](https://www.jcom.co.jp/common_v10/images/logo-jcom-only.svg)](https://www.jcom.co.jp/)
     ![メニューを閉じる](https://www.jcom.co.jp/common_v10/images/sp-menu/menu-close.svg)
    
    [固定電話](https://www.jcom.co.jp/service/phone/)
     [ガス](https://www.jcom.co.jp/service/gas/)
     [ほけん](https://www.jcom.co.jp/service/ssi/)
     [ローン](https://www.jcom-financial.co.jp/)
     [ホームIoT](https://www.jcom.co.jp/service/home/)
     [防犯カメラ](https://www.jcom.co.jp/guide/starter/home_security/)
     [オンライン  \
    診療](https://www.jcom.co.jp/service/telemedicine/)
    
    [サービス一覧](https://www.jcom.co.jp/service/)
    
    [法人・自治体向けサービス  \
    ![J:COM BUSINESS](https://www.jcom.co.jp/common_v10/images/logo_jcombusiness.webp)](https://business.jcom.co.jp/)
    

重要なお知らせ
-------

2025年11月19日

[令和7年11月18日大分市佐賀関の大規模火災に伴う支援について](https://notices.jcom.co.jp/notice/94032.html)

_+_

![](https://www.jcom.co.jp/images_v10/hero_img_bg.webp)

 [![想いは、光より速い。 J:COM STORIES J:COM ブランドサイト](https://www.jcom.co.jp/images_v10/hero_img.webp)](https://www.jcom.co.jp/brand/)

[↓](https://www.jcom.co.jp/#topics)

新規ご加入の方

[新規ご加入の方  \
お申し込み](https://onlineshop.jcom.co.jp/planSelect)

[新規ご加入の方  \
お問い合わせ](https://www.jcom.co.jp/#)

ご利用中の方

[ご利用中の方  \
各種お手続き](https://r.jcom.jp/eG4nLSC)

[お困りごと・  \
お問い合わせ  \
（チャット）](https://prod8-live-chat.sprinklr.com/page?appId=67af27d73657336d345e4a96_app_9070639&did=CHAT_vivr_cojp_top&enableClose=true&skin=MODERN&userContext__c_679c8b53cb85b007fab0f6ea=DirectLink&utm_campaign=IVRSMS&utm_medium=referral&utm_source=did&webview=true&zoom=false)

あなたにピッタリの  
プランがすぐわかる

[料金シミュ  \
レーション](https://onlineshop.jcom.co.jp/Simulation/Simulation)

無料・特別料金の物件も！

対応エリア・  
物件をご案内

新規ご加入の方

[お申し込み](https://onlineshop.jcom.co.jp/planSelect?sc_pid=common_upper_entry_02)

[![](https://www.jcom.co.jp/common_v10/images/icn-think-black.svg)Applications and Inquiries](https://www.jcom.co.jp/#)

[![](https://www.jcom.co.jp/common_v10/images/icn-think-black.svg)申请・咨询](https://www.jcom.co.jp/zh-CHS/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[电话咨询  \
050-1722-1733](tel:050-1722-1733)
 9:00-18:00【全年无休】／有翻译 [日本語での通話は  \
こちら](https://www.jcom.co.jp/#)

[![](https://www.jcom.co.jp/common_v10/images/icn-think-black.svg)신청·문의](https://www.jcom.co.jp/ko/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[신청·문의  \
050-1722-1733](tel:050-1722-1733)
 9:00-18:00【연중무휴】／통역 있음 [日本語での通話は  \
こちら](https://www.jcom.co.jp/#)

[![](https://www.jcom.co.jp/common_v10/images/icn-think-black.svg)Ứng dụng / Yêu cầu](https://www.jcom.co.jp/vi/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Ứng dụng / Yêu cầu  \
050-1722-1733](tel:050-1722-1733)
 9:00-18:00【mở cửa quanh năm】／có phiên dịch [日本語での通話は  \
こちら](https://www.jcom.co.jp/#)

[![](https://www.jcom.co.jp/common_v10/images/icn-think-black.svg)Solicitação/Consultas](https://www.jcom.co.jp/pt/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Solicitação/Consultas  \
050-1722-1733](tel:050-1722-1733)
 9:00-18:00【aberto todo o ano】／com intérprete [日本語での通話は  \
こちら](https://www.jcom.co.jp/#)

ご利用中の方

[契約内容  \
確認・変更  \
日本語のみ](https://www2.myjcom.jp/join/?ac_id=btm_change&sc_pid=common_upper_join_02)

[![](https://www.jcom.co.jp/common_v10/images/icn-member.svg)Inquiries](https://www.jcom.co.jp/#)

[![](https://www.jcom.co.jp/common_v10/images/icn-member.svg)联系我们](https://www.jcom.co.jp/#)

[![](https://www.jcom.co.jp/common_v10/images/icn-member.svg)문의](https://www.jcom.co.jp/#)

[![](https://www.jcom.co.jp/common_v10/images/icn-member.svg)Hỏi đáp](https://www.jcom.co.jp/#)

[![](https://www.jcom.co.jp/common_v10/images/icn-member.svg)Consultar](https://www.jcom.co.jp/#)

あなたにピッタリの  
プランがすぐわかる

[料金シミュ  \
レーション](https://onlineshop.jcom.co.jp/Simulation/Simulation?sc_pid=common_upper_simu_02)

無料・特別料金の物件も！

対応エリア・  
物件をご案内

[](https://www.jcom.co.jp/#)

新規ご加入の方　  
お問い合わせ

[Webでお問い合わせ](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

J:COMよりメールまたはお電話で回答いたします。

お電話でのお問い合わせ(通話無料)はこちら

[0120-989-970](tel:0120-989-970)

9:00～18:00［年中無休］

[工事日の確認・変更について](https://www.jcom.co.jp/#)

[閉じる](https://www.jcom.co.jp/#)

[](https://www.jcom.co.jp/#)

新規ご加入の方　  
お問い合わせ

[Webでお問い合わせ](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

J:COMよりメールまたはお電話で回答いたします。

お電話でのお問い合わせ(通話無料)はこちら

[0120-989-970](tel:0120-989-970)

9:00～18:00［年中無休］

[閉じる](https://www.jcom.co.jp/#)

[](https://www.jcom.co.jp/#)

新規ご加入の方　  
お問い合わせ

[Webでお問い合わせ](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

J:COMよりメールまたはお電話で回答いたします。

お電話でのお問い合わせ(通話無料)はこちら

[0120-989-970](tel:0120-989-970)

9:00～18:00［年中無休］

[閉じる](https://www.jcom.co.jp/#)

[](https://www.jcom.co.jp/#)

ご利用中の方　  
お問い合わせ

ご契約内容の確認・変更  
はこちらから

[マイページログイン](https://mypage.jcom.co.jp/)

* * *

お困り事解決・よくあるご質問  
はこちらから

[お客さまサポート](https://cs.myjcom.jp/)

* * *

サービス・オプションの追加や変更  
はこちらから

[サービスの追加・変更](https://www2.myjcom.jp/join/)

[閉じる](https://www.jcom.co.jp/#)

[](https://www.jcom.co.jp/#)

ご利用中の方　  
お問い合わせ

ご契約内容の確認・変更  
はこちらから

[マイページログイン](https://mypage.jcom.co.jp/)

* * *

お困り事解決・よくあるご質問  
はこちらから

[お客さまサポート](https://cs.myjcom.jp/)

* * *

サービス・オプションの追加や変更  
はこちらから

[サービスの追加・変更](https://www2.myjcom.jp/join/)

[閉じる](https://www.jcom.co.jp/#)

[](https://www.jcom.co.jp/#)

ご利用中の方　  
お問い合わせ

ご契約内容の確認・変更  
はこちらから

[マイページログイン](https://mypage.jcom.co.jp/)

* * *

お困り事解決・よくあるご質問  
はこちらから

[お客さまサポート](https://cs.myjcom.jp/)

* * *

サービス・オプションの追加や変更  
はこちらから

[サービスの追加・変更](https://www2.myjcom.jp/join/)

[閉じる](https://www.jcom.co.jp/#)

[](https://www.jcom.co.jp/#)

ご利用中の方　  
お申し込み

J:COM TVをご利用でない方

[J:COM TV  \
シン・スタンダードプラスの  \
お申し込み](https://r.jcom.jp/24KC2mS)

既にJ:COM TVをご利用中の方

[J:COM TV  \
シン・スタンダードプラスへ  \
コース変更](https://r.jcom.jp/0JLPOoy)

[閉じる](https://www.jcom.co.jp/#)

[](https://www.jcom.co.jp/#)

ご利用中の方　  
お申し込み

J:COM TVをご利用でない方

[J:COM TV  \
シン・スタンダードプラスの  \
お申し込み](https://r.jcom.jp/24KC2mS)

既にJ:COM TVをご利用中の方

[J:COM TV  \
シン・スタンダードプラスへ  \
コース変更](https://r.jcom.jp/0JLPOoy)

[閉じる](https://www.jcom.co.jp/#)

[](https://www.jcom.co.jp/#)

ご利用中の方　  
お申し込み

J:COM TVをご利用でない方

[J:COM TV  \
シン・スタンダードプラスの  \
お申し込み](https://r.jcom.jp/24KC2mS)

既にJ:COM TVをご利用中の方

[J:COM TV  \
シン・スタンダードプラスへ  \
コース変更](https://r.jcom.jp/0JLPOoy)

[閉じる](https://www.jcom.co.jp/#)

[](https://www.jcom.co.jp/#)

工事日の確認・変更について

訪問工事の日程確認・変更・キャンセルは、マイページで行うことができます。

[マイページログイン](https://mypage.jcom.co.jp/)

[マイページのご確認手順はこちら](https://cs.myjcom.jp/articles/support/6790bf45ad2e841b2e3362cf)

J:COM NET 光 (N)の工事日はマイページでは変更いただけません。[カスタマーセンター](https://www.jcom.co.jp/contactus/call_rgu.html#phone)
にお問い合わせください。

[閉じる](https://www.jcom.co.jp/#)

[](https://www.jcom.co.jp/#)

New Customers　  
Applications and Inquiries

[Applications and Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[0120-989-970](tel:0120-989-970)

Business hours : 9:00-18:00  
\[open all year round\]

[閉じる](https://www.jcom.co.jp/#)

[](https://www.jcom.co.jp/#)

New Customers　  
Applications and Inquiries

[Applications and Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[0120-989-970](tel:0120-989-970)

Business hours : 9:00-18:00  
\[open all year round\]

[閉じる](https://www.jcom.co.jp/#)

[](https://www.jcom.co.jp/#)

New Customers　  
Applications and Inquiries

[Applications and Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[0120-989-970](tel:0120-989-970)

Business hours : 9:00-18:00  
\[open all year round\]

[閉じる](https://www.jcom.co.jp/#)

[](https://www.jcom.co.jp/#)

Current Customers　  
Inquiries

[Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[0120-989-970](tel:0120-989-970)

Business hours : 9:00-18:00  
\[open all year round\]

[閉じる](https://www.jcom.co.jp/#)

[](https://www.jcom.co.jp/#)

Current Customers　  
Inquiries

[Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[0120-989-970](tel:0120-989-970)

Business hours : 9:00-18:00  
\[open all year round\]

[閉じる](https://www.jcom.co.jp/#)

[](https://www.jcom.co.jp/#)

Current Customers　  
Inquiries

[Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[0120-989-970](tel:0120-989-970)

Business hours : 9:00-18:00  
\[open all year round\]

[閉じる](https://www.jcom.co.jp/#)

[](https://www.jcom.co.jp/#)

新用户　  
申请・咨询

신규가입 고객　  
신청·문의

Đối với khách hàng mới tham gia　  
Ứng dụng / Yêu cầu

Novos assinantes　  
Solicitação/Consultas

电话咨询（有翻译）

전화 상담(통역 있음)

Tư vấn qua điện thoại (có phiên dịch)

Consulta por telefone (com intérprete)

[050-1722-1733](tel:050-1722-1733)

9:00-18:00 ［年中無休］

[日本語での通話はこちら](https://www.jcom.co.jp/#)

[申请・咨询](https://www.jcom.co.jp/zh-CHS/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[신청·문의](https://www.jcom.co.jp/ko/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Ứng dụng / Yêu cầu](https://www.jcom.co.jp/vi/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Solicitação/Consultas](https://www.jcom.co.jp/pt/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[閉じる](https://www.jcom.co.jp/#)

[](https://www.jcom.co.jp/#)

新用户　  
申请・咨询

신규가입 고객　  
신청·문의

Đối với khách hàng mới tham gia　  
Ứng dụng / Yêu cầu

Novos assinantes　  
Solicitação/Consultas

电话咨询（有翻译）

전화 상담(통역 있음)

Tư vấn qua điện thoại (có phiên dịch)

Consulta por telefone (com intérprete)

[050-1722-1733](tel:050-1722-1733)

9:00-18:00 ［年中無休］

[日本語での通話はこちら](https://www.jcom.co.jp/#)

[申请・咨询](https://www.jcom.co.jp/zh-CHS/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[신청·문의](https://www.jcom.co.jp/ko/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Ứng dụng / Yêu cầu](https://www.jcom.co.jp/vi/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Solicitação/Consultas](https://www.jcom.co.jp/pt/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[閉じる](https://www.jcom.co.jp/#)

[](https://www.jcom.co.jp/#)

新用户　  
申请・咨询

신규가입 고객　  
신청·문의

Đối với khách hàng mới tham gia　  
Ứng dụng / Yêu cầu

Novos assinantes　  
Solicitação/Consultas

电话咨询（有翻译）

전화 상담(통역 있음)

Tư vấn qua điện thoại (có phiên dịch)

Consulta por telefone (com intérprete)

[050-1722-1733](tel:050-1722-1733)

9:00-18:00 ［年中無休］

[日本語での通話はこちら](https://www.jcom.co.jp/#)

[申请・咨询](https://www.jcom.co.jp/zh-CHS/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[신청·문의](https://www.jcom.co.jp/ko/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Ứng dụng / Yêu cầu](https://www.jcom.co.jp/vi/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Solicitação/Consultas](https://www.jcom.co.jp/pt/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[閉じる](https://www.jcom.co.jp/#)

[](https://www.jcom.co.jp/#)

会员　  
联系我们

이용 중인 고객　  
문의

Khách hàng đang sử dụng　  
Hỏi đáp

Utilizadores　  
Consultar

电话咨询（有翻译）

전화 상담(통역 있음)

Tư vấn qua điện thoại (có phiên dịch)

Consulta por telefone (com intérprete)

[050-1722-1733](tel:050-1722-1733)

9:00-18:00 ［年中無休］

[日本語での通話はこちら](https://www.jcom.co.jp/#)

[联系我们](https://www.jcom.co.jp/zh-CHS/sim_contact/entry_request.php?form_type=eng_inquires)

[문의](https://www.jcom.co.jp/ko/sim_contact/entry_request.php?form_type=eng_inquires)

[Hỏi đáp](https://www.jcom.co.jp/vi/sim_contact/entry_request.php?form_type=eng_inquires)

[Consultar](https://www.jcom.co.jp/pt/sim_contact/entry_request.php?form_type=eng_inquires)

[閉じる](https://www.jcom.co.jp/#)

[](https://www.jcom.co.jp/#)

会员　  
联系我们

이용 중인 고객　  
문의

Khách hàng đang sử dụng　  
Hỏi đáp

Utilizadores　  
Consultar

电话咨询（有翻译）

전화 상담(통역 있음)

Tư vấn qua điện thoại (có phiên dịch)

Consulta por telefone (com intérprete)

[050-1722-1733](tel:050-1722-1733)

9:00-18:00 ［年中無休］

[日本語での通話はこちら](https://www.jcom.co.jp/#)

[联系我们](https://www.jcom.co.jp/zh-CHS/sim_contact/entry_request.php?form_type=eng_inquires)

[문의](https://www.jcom.co.jp/ko/sim_contact/entry_request.php?form_type=eng_inquires)

[Hỏi đáp](https://www.jcom.co.jp/vi/sim_contact/entry_request.php?form_type=eng_inquires)

[Consultar](https://www.jcom.co.jp/pt/sim_contact/entry_request.php?form_type=eng_inquires)

[閉じる](https://www.jcom.co.jp/#)

[](https://www.jcom.co.jp/#)

会员　  
联系我们

이용 중인 고객　  
문의

Khách hàng đang sử dụng　  
Hỏi đáp

Utilizadores　  
Consultar

电话咨询（有翻译）

전화 상담(통역 있음)

Tư vấn qua điện thoại (có phiên dịch)

Consulta por telefone (com intérprete)

[050-1722-1733](tel:050-1722-1733)

9:00-18:00 ［年中無休］

[日本語での通話はこちら](https://www.jcom.co.jp/#)

[联系我们](https://www.jcom.co.jp/zh-CHS/sim_contact/entry_request.php?form_type=eng_inquires)

[문의](https://www.jcom.co.jp/ko/sim_contact/entry_request.php?form_type=eng_inquires)

[Hỏi đáp](https://www.jcom.co.jp/vi/sim_contact/entry_request.php?form_type=eng_inquires)

[Consultar](https://www.jcom.co.jp/pt/sim_contact/entry_request.php?form_type=eng_inquires)

[閉じる](https://www.jcom.co.jp/#)

[](https://www.jcom.co.jp/#)

日本語でのお問い合わせ

[海外にお住まいの方](https://cs.myjcom.jp/knowledgeDetail?an=004897372)

[日本国内にお住まいの方](https://www.jcom.co.jp/contactus/call_rgu.html)

[閉じる](https://www.jcom.co.jp/#)

[](https://www.jcom.co.jp/#)

日本語でのお問い合わせ

[海外にお住まいの方](https://cs.myjcom.jp/knowledgeDetail?an=004897372)

[日本国内にお住まいの方](https://www.jcom.co.jp/contactus/call_rgu.html)

[閉じる](https://www.jcom.co.jp/#)

パーソナルIDでログイン中です。

ご利用中の方へ  
おすすめ情報をご案内

[![ログイン](https://www.jcom.co.jp/common_v10/images/login_b.webp)](https://id.zaq.ne.jp/id/script/connect/authz_req/endpoint.seam?response_type=code&client_id=JCOM_COJP&redirect_uri=https%3A%2F%2Fwww.jcom.co.jp%2F&scope=http%3A%2F%2Fjcom.co.jp%2Fconnect%2Fprofile%2Fstandard_new&nonce=1527334654&state=&prompt=)

トピックス
-----

 [![見る楽しさ。見つける楽しさ。J:COM TV シン・スタンダード](https://www.jcom.co.jp/images_v10/topics_shinsta.webp)](https://www.jcom.co.jp/guide/starter/tv/)

 [![世界最速規格 Wi-Fi 7 あたらしいJ:COM 光はじまる。 ★Wi-Fi通信規格の理論上最大速度比。未提供エリア有。詳しくはこちら。](https://www.jcom.co.jp/images_v10/topics_wifi7.webp)](https://www.jcom.co.jp/service/net/)

 [![Wi-Fi 7対応 J:COM 光 10ギガ 6カ月間実質0円 ※一戸建ての場合。7カ月目以降6,160円/月～、未提供エリア有。](https://www.jcom.co.jp/images_v10/topics_newlife_v3.webp)](https://www.jcom.co.jp/guide/starter/shinlife/price/?ad=sdu01)

 [![暮らしに寄り添う、頼れるミカタ。J:COM プレミアムローン 誕生](https://www.jcom.co.jp/images_v10/topics_loan.webp)](https://www.jcom-financial.co.jp/)

 [![2025-26 大同生命 SV.LEAGUE J SPORTSオンデマンドで男女全試合をLIVE配信！](https://www.jcom.co.jp/images_v10/topics_svliague2025.webp)](https://www2.myjcom.jp/special/tv/sports/volleyball/svleague/)

 [![NETFLIX 夢中になれるシアワセを。 J:COM Netflixセット新登場 ずーっと330円/月割引](https://www.jcom.co.jp/images_v10/topics_netflix.webp)](https://www.jcom.co.jp/guide/starter/netflix/)

 [![J:COM TV 見る楽しさ。見つける楽しさ。シン・スタンダード 3カ月間500円（税込）/月 ※WEB限定スタート割適用、4カ月目以降4,950（税込）/月～。2年契約、自動更新。途中解約は解除料要。](https://www.jcom.co.jp/images_v10/topics_shinsta.webp)](https://www.jcom.co.jp/guide/starter/tv/)

 [![J:COM MOBILE eSIMなら即日開通 ずーっと5GB 980円（税込1,078円）※データ盛適用時。 対応機種要。指定プランの場合。通話料等別途要。](https://www.jcom.co.jp/images_v10/topics_mobile_esim.webp)](https://www.jcom.co.jp/service/mobile/device/sim/esim/)

 [![世界最速規格 Wi-Fi 7 あたらしいJ:COM 光はじまる。 ★Wi-Fi通信規格の理論上最大速度比。未提供エリア有。詳しくはこちら。](https://www.jcom.co.jp/images_v10/topics_wifi7.webp)](https://www.jcom.co.jp/service/net/)

 [![Wi-Fi 7対応 J:COM 光 10ギガ 6カ月間実質0円 ※一戸建ての場合。7カ月目以降6,160円/月～、未提供エリア有。](https://www.jcom.co.jp/images_v10/topics_newlife_v3.webp)](https://www.jcom.co.jp/guide/starter/shinlife/price/?ad=sdu01)

 [![暮らしに寄り添う、頼れるミカタ。J:COM プレミアムローン 誕生](https://www.jcom.co.jp/images_v10/topics_loan.webp)](https://www.jcom-financial.co.jp/)

 [![2025-26 大同生命 SV.LEAGUE J SPORTSオンデマンドで男女全試合をLIVE配信！](https://www.jcom.co.jp/images_v10/topics_svliague2025.webp)](https://www2.myjcom.jp/special/tv/sports/volleyball/svleague/)

 [![NETFLIX 夢中になれるシアワセを。 J:COM Netflixセット新登場 ずーっと330円/月割引](https://www.jcom.co.jp/images_v10/topics_netflix.webp)](https://www.jcom.co.jp/guide/starter/netflix/)

 [![J:COM TV 見る楽しさ。見つける楽しさ。シン・スタンダード 3カ月間500円（税込）/月 ※WEB限定スタート割適用、4カ月目以降4,950（税込）/月～。2年契約、自動更新。途中解約は解除料要。](https://www.jcom.co.jp/images_v10/topics_shinsta.webp)](https://www.jcom.co.jp/guide/starter/tv/)

 [![J:COM MOBILE eSIMなら即日開通 ずーっと5GB 980円（税込1,078円）※データ盛適用時。 対応機種要。指定プランの場合。通話料等別途要。](https://www.jcom.co.jp/images_v10/topics_mobile_esim.webp)](https://www.jcom.co.jp/service/mobile/device/sim/esim/)

 [![世界最速規格 Wi-Fi 7 あたらしいJ:COM 光はじまる。 ★Wi-Fi通信規格の理論上最大速度比。未提供エリア有。詳しくはこちら。](https://www.jcom.co.jp/images_v10/topics_wifi7.webp)](https://www.jcom.co.jp/service/net/)

 [![Wi-Fi 7対応 J:COM 光 10ギガ 6カ月間実質0円 ※一戸建ての場合。7カ月目以降6,160円/月～、未提供エリア有。](https://www.jcom.co.jp/images_v10/topics_newlife_v3.webp)](https://www.jcom.co.jp/guide/starter/shinlife/price/?ad=sdu01)

 [![暮らしに寄り添う、頼れるミカタ。J:COM プレミアムローン 誕生](https://www.jcom.co.jp/images_v10/topics_loan.webp)](https://www.jcom-financial.co.jp/)

 [![2025-26 大同生命 SV.LEAGUE J SPORTSオンデマンドで男女全試合をLIVE配信！](https://www.jcom.co.jp/images_v10/topics_svliague2025.webp)](https://www2.myjcom.jp/special/tv/sports/volleyball/svleague/)

 [![NETFLIX 夢中になれるシアワセを。 J:COM Netflixセット新登場 ずーっと330円/月割引](https://www.jcom.co.jp/images_v10/topics_netflix.webp)](https://www.jcom.co.jp/guide/starter/netflix/)

 [![J:COM TV 見る楽しさ。見つける楽しさ。シン・スタンダード 3カ月間500円（税込）/月 ※WEB限定スタート割適用、4カ月目以降4,950（税込）/月～。2年契約、自動更新。途中解約は解除料要。](https://www.jcom.co.jp/images_v10/topics_shinsta.webp)](https://www.jcom.co.jp/guide/starter/tv/)

 [![J:COM MOBILE eSIMなら即日開通 ずーっと5GB 980円（税込1,078円）※データ盛適用時。 対応機種要。指定プランの場合。通話料等別途要。](https://www.jcom.co.jp/images_v10/topics_mobile_esim.webp)](https://www.jcom.co.jp/service/mobile/device/sim/esim/)

暮らしを快適にする  
さまざまなサービス
---------------------

理想の生活を  
J:COMで

多彩なサービスで暮らしを  
もっと楽しく便利に。  
J:COMなら、自分にあった  
プランが見つかる。

[詳しくはこちら](https://www.jcom.co.jp/beginner/)

[![](https://www.jcom.co.jp/images_v10/img-service-tv.webp)\
\
### ![](https://www.jcom.co.jp/common_v10/images/icn-jcom-tv.svg)テレビ\
\
#### あなたの見たいを叶える\
\
J:COM TV トップ](https://www.jcom.co.jp/service/tv/)

[料金・コース](https://www.jcom.co.jp/service/tv/course/)
 [多彩なコンテンツ](https://www.jcom.co.jp/service/tv/channel/)
 [ネット動画](https://www.jcom.co.jp/service/tv/smart/ott.html)
 [便利な機能](https://www.jcom.co.jp/service/tv/smart/)
 [オプション](https://www.jcom.co.jp/service/tv/accessories/)
 [お申し込みの流れ](https://www.jcom.co.jp/service/tv/guide/)

[![](https://www.jcom.co.jp/images_v10/img-service-net.webp)\
\
### ![](https://www.jcom.co.jp/common_v10/images/icn-jcom-net.svg)ネット\
\
#### もっと速く、もっと快適に\
\
J:COM NET トップ](https://www.jcom.co.jp/service/net/)

[料金・コース](https://www.jcom.co.jp/service/net/course/)
 [オプション](https://www.jcom.co.jp/service/net/option/)
  
[サポート](https://www.jcom.co.jp/service/net/support/)
 [お申し込みの流れ](https://www.jcom.co.jp/service/net/guide/)

[![](https://www.jcom.co.jp/images_v10/img-service-mobile.webp)\
\
### ![](https://www.jcom.co.jp/common_v10/images/icn-jcom-mobile.svg)スマホ\
\
#### ずーっとおトク\
\
J:COM MOBILE トップ](https://www.jcom.co.jp/service/mobile/)

[料金・サービス](https://www.jcom.co.jp/service/mobile/price/)
 [製品](https://www.jcom.co.jp/service/mobile/device/)
 [格安SIM](https://www.jcom.co.jp/service/mobile/device/sim/)
 [オプション](https://www.jcom.co.jp/service/mobile/option/)
 [サポート](https://www.jcom.co.jp/service/mobile/support/)
 [お申し込みの流れ](https://www.jcom.co.jp/service/mobile/usage/)

[![](https://www.jcom.co.jp/images_v10/img-service-electricity.webp)\
\
### ![](https://www.jcom.co.jp/common_v10/images/icn-jcom-electricity.svg)でんき\
\
#### 品質そのままで安心\
\
J:COM でんき トップ](https://www.jcom.co.jp/service/electricity/)

[料金メニュー](https://www.jcom.co.jp/service/electricity/price/)
 [グリーンメニュー](https://www.jcom.co.jp/service/electricity/price/green/)
 [でんきのしくみ](https://www.jcom.co.jp/service/electricity/feature/)
 [お申し込みの流れ](https://www.jcom.co.jp/service/electricity/flow/)

 [![](https://www.jcom.co.jp/images_v10/img-service-phone.webp)\
\
![](https://www.jcom.co.jp/common_v10/images/icn-jcom-phone.svg) 固定電話](https://www.jcom.co.jp/service/phone/)
 [![](https://www.jcom.co.jp/images_v10/img-service-gas.webp)\
\
![](https://www.jcom.co.jp/common_v10/images/icn-jcom-gas.svg) ガス](https://www.jcom.co.jp/service/gas/)
 [![](https://www.jcom.co.jp/images_v10/img-service-ssi.webp)\
\
![](https://www.jcom.co.jp/common_v10/images/icn-jcom-ssi.svg) ほけん](https://www.jcom.co.jp/service/ssi/)
 [![](https://www.jcom.co.jp/images_v10/img-service-loan.webp)\
\
![](https://www.jcom.co.jp/common_v10/images/icn-jcom-loan.svg) ローン](https://www.jcom-financial.co.jp/)
 [![](https://www.jcom.co.jp/images_v10/img-service-home.webp)\
\
![](https://www.jcom.co.jp/common_v10/images/icn-jcom-home.svg) ホームIoT防犯カメラ](https://www.jcom.co.jp/guide/starter/home_security/)
 [![](https://www.jcom.co.jp/images_v10/img-service-telemedicine_v2.webp)\
\
![](https://www.jcom.co.jp/common_v10/images/icn-jcom-telemedicine.svg) オンライン診療](https://www.jcom.co.jp/service/telemedicine/)

[おてがるサービス診断 あなたに合ったサービスをご提案 詳しく見る\
\
 ![](https://www.jcom.co.jp/images_v10/img_lifestyle_check_v2.webp)](https://www.jcom.co.jp/lifestyle/)
 

[サービス一覧](https://www.jcom.co.jp/service/)

[地域とともに、一歩先のビジネスへ ![](https://www.jcom.co.jp/images_v10/icn.webp)法人・自治体向けサービス  \
![J:COM BUSINESS](https://www.jcom.co.jp/common_v10/images/logo_jcombusiness.webp) 詳しく見る\
\
 ![](https://www.jcom.co.jp/images_v10/img_business.webp)](https://business.jcom.co.jp/)
 

### お好みのサービスで  
組み合わせ自由！

![テレビ](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-tv-item.svg)

![ネット](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-net-item.svg)

![固定電話](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-phone-item.svg)

![スマホ](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-mobile-item.svg)

![でんき](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-electricity-item.svg)

![ガス](https://www.jcom.co.jp/common_v10/images/sp-menu/jcom/slide/service-jcom-gas-item.svg)

おすすめプランはこちら

[料金一覧](https://www.jcom.co.jp/price/#plan)

おてがる料金チェック！

[料金シミュレーション](https://onlineshop.jcom.co.jp/Simulation/Simulation)

[ヨシタカ先生  \
スペシャルサイト](https://www.jcom.co.jp/cm/)

キャンペーン・特典
---------

 [![WEB限定スタート割](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_start.webp)](https://www.jcom.co.jp/campaign/start_jcom/)
[![青春22割・青春26割](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_u26.webp)](https://www.jcom.co.jp/campaign/u26/)
[![J:COM金利優遇割引](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_au_loan.webp)](https://www.jcom.co.jp/price/au_loan/)

[![WEB限定スタート割](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_start.webp)](https://www.jcom.co.jp/campaign/start_jcom/)

[![青春22割・青春26割](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_u26.webp)](https://www.jcom.co.jp/campaign/u26/)

[![J:COM金利優遇割引](https://www.jcom.co.jp/campaign/images_v10/banner/bnr_au_loan.webp)](https://www.jcom.co.jp/price/au_loan/)

[キャンペーン・特典](https://www.jcom.co.jp/campaign/)

###  ![J:COMなら毎日がおもしろいであふれる！](https://www.jcom.co.jp/images_v10/ttl-pr.webp)

[![見たい！がみつかる テレビ番組ガイド](https://www.jcom.co.jp/images_v10/pr-slide-img-2.webp)](https://www2.myjcom.jp/tv/)

[![料金・サポート・番組表 これひとつで MY J:COMアプリ](https://www.jcom.co.jp/images_v10/pr-slide-img-5.webp)](https://www2.myjcom.jp/special/app/myjcom/)

[![J:COM × NETFLIX テレビでNetflix見るならJ:COM おすすめ作品はこちら](https://www.jcom.co.jp/images_v10/pr-slide-img-2_v2.webp)](https://www2.myjcom.jp/special/tv/netflix/)

[![応募&参加無料！ イベント・プレゼント](https://www.jcom.co.jp/images_v10/pr-slide-img-3.webp)](https://c.myjcom.jp/user/)

[![優待価格など、おトク情報が満載 加入者優待](https://www.jcom.co.jp/images_v10/pr-slide-img-4.webp)](https://www2.myjcom.jp/yutai/)

[![見たい！がみつかる テレビ番組ガイド](https://www.jcom.co.jp/images_v10/pr-slide-img-2.webp)](https://www2.myjcom.jp/tv/)

[![料金・サポート・番組表 これひとつで MY J:COMアプリ](https://www.jcom.co.jp/images_v10/pr-slide-img-5.webp)](https://www2.myjcom.jp/special/app/myjcom/)

[![J:COM × NETFLIX テレビでNetflix見るならJ:COM おすすめ作品はこちら](https://www.jcom.co.jp/images_v10/pr-slide-img-2_v2.webp)](https://www2.myjcom.jp/special/tv/netflix/)

[![応募&参加無料！ イベント・プレゼント](https://www.jcom.co.jp/images_v10/pr-slide-img-3.webp)](https://c.myjcom.jp/user/)

[![優待価格など、おトク情報が満載 加入者優待](https://www.jcom.co.jp/images_v10/pr-slide-img-4.webp)](https://www2.myjcom.jp/yutai/)

[![見たい！がみつかる テレビ番組ガイド](https://www.jcom.co.jp/images_v10/pr-slide-img-2.webp)](https://www2.myjcom.jp/tv/)

[![料金・サポート・番組表 これひとつで MY J:COMアプリ](https://www.jcom.co.jp/images_v10/pr-slide-img-5.webp)](https://www2.myjcom.jp/special/app/myjcom/)

[![J:COM × NETFLIX テレビでNetflix見るならJ:COM おすすめ作品はこちら](https://www.jcom.co.jp/images_v10/pr-slide-img-2_v2.webp)](https://www2.myjcom.jp/special/tv/netflix/)

[![応募&参加無料！ イベント・プレゼント](https://www.jcom.co.jp/images_v10/pr-slide-img-3.webp)](https://c.myjcom.jp/user/)

[![優待価格など、おトク情報が満載 加入者優待](https://www.jcom.co.jp/images_v10/pr-slide-img-4.webp)](https://www2.myjcom.jp/yutai/)

お客さまの声
------

### 決め手は手厚い  
カスタマーサービス

手厚いカスタマーサービスが契約の決め手でした。契約の相談や機器の設置を、社員さんや作業員の方が直接家まで来てやっていただけるので、安心して継続することができています。

30代／男性

### いざという時の  
地域情報が助かります

地域の災害時の情報がNHKやネットの気象庁より早いこと。また、河川の様子や幹線道路の冠水状況もライブ映像で配信されるので大変助かります。

40代／女性

### あれこれ聞ける  
ショップの窓口が良い

なんといっても近くにショップがあるので、「このサービスはどんなところがいいんだろう？」と新しく入ろうか迷った時には直接お店に行って聞いてます。電話で聞いたりもできますが、「え？」って思った時にもう一度聞くのは気がひけたり…。でも店頭だとわかるまで一緒に考えてくださって、助かってます。

50代／女性

### まとめて手続き  
できて便利

テレビ、インターネットだけでなく、電気など生活全般にわたるサービスを受けることができ、引越しなどの際もワンストップで手続きできるのが便利です。

60代／男性

### カスタマーセンターの対応が  
素晴らしい

カスタマーセンターに問い合わせしましたが、相談～工事・開通までの流れがとてもスムーズで、対応も素晴らしかったです。J:COM LINKやネット回線の品質にも満足しています。

70代／女性

### アンテナが不要で  
嬉しい

ネット回線は安定しており、テレビのコンテンツも地域密着型の「Jテレ」などがあって良いです。アンテナを設置する必要もなく、家の外観もすっきりしました。

40代／男性

 [![お客さまの声公開中](https://www.jcom.co.jp/beginner/images/voice_650%C3%97150.webp)](https://www.jcom.co.jp/service/voice/)

新規ご加入・サービス追加をご検討中の方

### お申し込みのご案内

新規ご加入の方

[新規ご加入の方  \
お申し込み](https://onlineshop.jcom.co.jp/planSelect)

[新規ご加入の方  \
お問い合わせ](https://www.jcom.co.jp/#)

ご利用中の方

[ご利用中の方  \
各種お手続き](https://r.jcom.jp/eG4nLSC)

[お困りごと・  \
お問い合わせ  \
（チャット）](https://prod8-live-chat.sprinklr.com/page?appId=67af27d73657336d345e4a96_app_9070639&did=CHAT_vivr_cojp_top&enableClose=true&skin=MODERN&userContext__c_679c8b53cb85b007fab0f6ea=DirectLink&utm_campaign=IVRSMS&utm_medium=referral&utm_source=did&webview=true&zoom=false)

あなたにピッタリの  
プランがすぐわかる

[料金シミュ  \
レーション](https://onlineshop.jcom.co.jp/Simulation/Simulation)

無料・特別料金の物件も！

対応エリア・  
物件をご案内

新規ご加入・サービス追加をご検討中の方

### お申し込みのご案内

新規ご加入の方

[お申し込み](https://onlineshop.jcom.co.jp/planSelect?sc_pid=common_bottom_entry_02)

[![](https://www.jcom.co.jp/common_v10/images/icn-think-black.svg)Applications and Inquiries](https://www.jcom.co.jp/#)

[![](https://www.jcom.co.jp/common_v10/images/icn-think-black.svg)申请・咨询](https://www.jcom.co.jp/zh-CHS/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[电话咨询  \
050-1722-1733](tel:050-1722-1733)
 9:00-18:00【全年无休】／有翻译 [日本語での通話は  \
こちら](https://www.jcom.co.jp/#)

[![](https://www.jcom.co.jp/common_v10/images/icn-think-black.svg)신청·문의](https://www.jcom.co.jp/ko/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[신청·문의  \
050-1722-1733](tel:050-1722-1733)
 9:00-18:00【연중무휴】／통역 있음 [日本語での通話は  \
こちら](https://www.jcom.co.jp/#)

[![](https://www.jcom.co.jp/common_v10/images/icn-think-black.svg)Ứng dụng / Yêu cầu](https://www.jcom.co.jp/vi/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Ứng dụng / Yêu cầu  \
050-1722-1733](tel:050-1722-1733)
 9:00-18:00【mở cửa quanh năm】／có phiên dịch [日本語での通話は  \
こちら](https://www.jcom.co.jp/#)

[![](https://www.jcom.co.jp/common_v10/images/icn-think-black.svg)Solicitação/Consultas](https://www.jcom.co.jp/pt/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Solicitação/Consultas  \
050-1722-1733](tel:050-1722-1733)
 9:00-18:00【aberto todo o ano】／com intérprete [日本語での通話は  \
こちら](https://www.jcom.co.jp/#)

ご利用中の方

[契約内容  \
確認・変更  \
日本語のみ](https://www2.myjcom.jp/join/?ac_id=btm_change&sc_pid=common_bottom_join_02)

[![](https://www.jcom.co.jp/common_v10/images/icn-member.svg)Inquiries](https://www.jcom.co.jp/#)

[![](https://www.jcom.co.jp/common_v10/images/icn-member.svg)联系我们](https://www.jcom.co.jp/#)

[![](https://www.jcom.co.jp/common_v10/images/icn-member.svg)문의](https://www.jcom.co.jp/#)

[![](https://www.jcom.co.jp/common_v10/images/icn-member.svg)Hỏi đáp](https://www.jcom.co.jp/#)

[![](https://www.jcom.co.jp/common_v10/images/icn-member.svg)Consultar](https://www.jcom.co.jp/#)

あなたにピッタリの  
プランがすぐわかる

[料金シミュ  \
レーション](https://onlineshop.jcom.co.jp/Simulation/Simulation?sc_pid=common_bottom_simu_02)

無料・特別料金の物件も！

対応エリア・  
物件をご案内

[](https://www.jcom.co.jp/#)

新規ご加入の方　  
お問い合わせ

[Webでお問い合わせ](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

J:COMよりメールまたはお電話で回答いたします。

お電話でのお問い合わせ(通話無料)はこちら

[0120-989-970](tel:0120-989-970)

9:00～18:00［年中無休］

[閉じる](https://www.jcom.co.jp/#)

[](https://www.jcom.co.jp/#)

新規ご加入の方　  
お問い合わせ

[Webでお問い合わせ](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

J:COMよりメールまたはお電話で回答いたします。

お電話でのお問い合わせ(通話無料)はこちら

[0120-989-970](tel:0120-989-970)

9:00～18:00［年中無休］

[閉じる](https://www.jcom.co.jp/#)

[](https://www.jcom.co.jp/#)

新規ご加入の方　  
お問い合わせ

[Webでお問い合わせ](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

J:COMよりメールまたはお電話で回答いたします。

お電話でのお問い合わせ(通話無料)はこちら

[0120-989-970](tel:0120-989-970)

9:00～18:00［年中無休］

[閉じる](https://www.jcom.co.jp/#)

[](https://www.jcom.co.jp/#)

ご利用中の方　  
お問い合わせ

ご契約内容の確認・変更  
はこちらから

[マイページログイン](https://mypage.jcom.co.jp/)

* * *

お困り事解決・よくあるご質問  
はこちらから

[お客さまサポート](https://cs.myjcom.jp/)

* * *

サービス・オプションの追加や変更  
はこちらから

[サービスの追加・変更](https://www2.myjcom.jp/join/)

[閉じる](https://www.jcom.co.jp/#)

[](https://www.jcom.co.jp/#)

ご利用中の方　  
お問い合わせ

ご契約内容の確認・変更  
はこちらから

[マイページログイン](https://mypage.jcom.co.jp/)

* * *

お困り事解決・よくあるご質問  
はこちらから

[お客さまサポート](https://cs.myjcom.jp/)

* * *

サービス・オプションの追加や変更  
はこちらから

[サービスの追加・変更](https://www2.myjcom.jp/join/)

[閉じる](https://www.jcom.co.jp/#)

[](https://www.jcom.co.jp/#)

ご利用中の方　  
お問い合わせ

ご契約内容の確認・変更  
はこちらから

[マイページログイン](https://mypage.jcom.co.jp/)

* * *

お困り事解決・よくあるご質問  
はこちらから

[お客さまサポート](https://cs.myjcom.jp/)

* * *

サービス・オプションの追加や変更  
はこちらから

[サービスの追加・変更](https://www2.myjcom.jp/join/)

[閉じる](https://www.jcom.co.jp/#)

[](https://www.jcom.co.jp/#)

ご利用中の方　  
お申し込み

J:COM TVをご利用でない方

[J:COM TV  \
シン・スタンダードプラスの  \
お申し込み](https://r.jcom.jp/24KC2mS)

既にJ:COM TVをご利用中の方

[J:COM TV  \
シン・スタンダードプラスへ  \
コース変更](https://r.jcom.jp/0JLPOoy)

[閉じる](https://www.jcom.co.jp/#)

[](https://www.jcom.co.jp/#)

ご利用中の方　  
お申し込み

J:COM TVをご利用でない方

[J:COM TV  \
シン・スタンダードプラスの  \
お申し込み](https://r.jcom.jp/24KC2mS)

既にJ:COM TVをご利用中の方

[J:COM TV  \
シン・スタンダードプラスへ  \
コース変更](https://r.jcom.jp/0JLPOoy)

[閉じる](https://www.jcom.co.jp/#)

[](https://www.jcom.co.jp/#)

ご利用中の方　  
お申し込み

J:COM TVをご利用でない方

[J:COM TV  \
シン・スタンダードプラスの  \
お申し込み](https://r.jcom.jp/24KC2mS)

既にJ:COM TVをご利用中の方

[J:COM TV  \
シン・スタンダードプラスへ  \
コース変更](https://r.jcom.jp/0JLPOoy)

[閉じる](https://www.jcom.co.jp/#)

[](https://www.jcom.co.jp/#)

工事日の確認・変更について

訪問工事の日程確認・変更・キャンセルは、マイページで行うことができます。

[マイページログイン](https://mypage.jcom.co.jp/)

[マイページのご確認手順はこちら](https://cs.myjcom.jp/articles/support/6790bf45ad2e841b2e3362cf)

J:COM NET 光 (N)の工事日はマイページでは変更いただけません。[カスタマーセンター](https://www.jcom.co.jp/contactus/call_rgu.html#phone)
にお問い合わせください。

[閉じる](https://www.jcom.co.jp/#)

[](https://www.jcom.co.jp/#)

New Customers　  
Applications and Inquiries

[Applications and Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[0120-989-970](tel:0120-989-970)

Business hours : 9:00-18:00  
\[open all year round\]

[閉じる](https://www.jcom.co.jp/#)

[](https://www.jcom.co.jp/#)

New Customers　  
Applications and Inquiries

[Applications and Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[0120-989-970](tel:0120-989-970)

Business hours : 9:00-18:00  
\[open all year round\]

[閉じる](https://www.jcom.co.jp/#)

[](https://www.jcom.co.jp/#)

New Customers　  
Applications and Inquiries

[Applications and Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[0120-989-970](tel:0120-989-970)

Business hours : 9:00-18:00  
\[open all year round\]

[閉じる](https://www.jcom.co.jp/#)

[](https://www.jcom.co.jp/#)

Current Customers　  
Inquiries

[Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[0120-989-970](tel:0120-989-970)

Business hours : 9:00-18:00  
\[open all year round\]

[閉じる](https://www.jcom.co.jp/#)

[](https://www.jcom.co.jp/#)

Current Customers　  
Inquiries

[Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[0120-989-970](tel:0120-989-970)

Business hours : 9:00-18:00  
\[open all year round\]

[閉じる](https://www.jcom.co.jp/#)

[](https://www.jcom.co.jp/#)

Current Customers　  
Inquiries

[Inquiries](https://www.jcom.co.jp/en/sim_contact/entry_request.php?form_type=eng_inquires)

[0120-989-970](tel:0120-989-970)

Business hours : 9:00-18:00  
\[open all year round\]

[閉じる](https://www.jcom.co.jp/#)

[](https://www.jcom.co.jp/#)

新用户　  
申请・咨询

신규가입 고객　  
신청·문의

Đối với khách hàng mới tham gia　  
Ứng dụng / Yêu cầu

Novos assinantes　  
Solicitação/Consultas

电话咨询（有翻译）

전화 상담(통역 있음)

Tư vấn qua điện thoại (có phiên dịch)

Consulta por telefone (com intérprete)

[050-1722-1733](tel:050-1722-1733)

9:00-18:00 ［年中無休］

[日本語での通話はこちら](https://www.jcom.co.jp/#)

[申请・咨询](https://www.jcom.co.jp/zh-CHS/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[신청·문의](https://www.jcom.co.jp/ko/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Ứng dụng / Yêu cầu](https://www.jcom.co.jp/vi/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Solicitação/Consultas](https://www.jcom.co.jp/pt/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[閉じる](https://www.jcom.co.jp/#)

[](https://www.jcom.co.jp/#)

新用户　  
申请・咨询

신규가입 고객　  
신청·문의

Đối với khách hàng mới tham gia　  
Ứng dụng / Yêu cầu

Novos assinantes　  
Solicitação/Consultas

电话咨询（有翻译）

전화 상담(통역 있음)

Tư vấn qua điện thoại (có phiên dịch)

Consulta por telefone (com intérprete)

[050-1722-1733](tel:050-1722-1733)

9:00-18:00 ［年中無休］

[日本語での通話はこちら](https://www.jcom.co.jp/#)

[申请・咨询](https://www.jcom.co.jp/zh-CHS/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[신청·문의](https://www.jcom.co.jp/ko/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Ứng dụng / Yêu cầu](https://www.jcom.co.jp/vi/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Solicitação/Consultas](https://www.jcom.co.jp/pt/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[閉じる](https://www.jcom.co.jp/#)

[](https://www.jcom.co.jp/#)

新用户　  
申请・咨询

신규가입 고객　  
신청·문의

Đối với khách hàng mới tham gia　  
Ứng dụng / Yêu cầu

Novos assinantes　  
Solicitação/Consultas

电话咨询（有翻译）

전화 상담(통역 있음)

Tư vấn qua điện thoại (có phiên dịch)

Consulta por telefone (com intérprete)

[050-1722-1733](tel:050-1722-1733)

9:00-18:00 ［年中無休］

[日本語での通話はこちら](https://www.jcom.co.jp/#)

[申请・咨询](https://www.jcom.co.jp/zh-CHS/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[신청·문의](https://www.jcom.co.jp/ko/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Ứng dụng / Yêu cầu](https://www.jcom.co.jp/vi/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[Solicitação/Consultas](https://www.jcom.co.jp/pt/sim_contact/entry_request.php?form_type=eng_applications_inquiries)

[閉じる](https://www.jcom.co.jp/#)

[](https://www.jcom.co.jp/#)

会员　  
联系我们

이용 중인 고객　  
문의

Khách hàng đang sử dụng　  
Hỏi đáp

Utilizadores　  
Consultar

电话咨询（有翻译）

전화 상담(통역 있음)

Tư vấn qua điện thoại (có phiên dịch)

Consulta por telefone (com intérprete)

[050-1722-1733](tel:050-1722-1733)

9:00-18:00 ［年中無休］

[日本語での通話はこちら](https://www.jcom.co.jp/#)

[联系我们](https://www.jcom.co.jp/zh-CHS/sim_contact/entry_request.php?form_type=eng_inquires)

[문의](https://www.jcom.co.jp/ko/sim_contact/entry_request.php?form_type=eng_inquires)

[Hỏi đáp](https://www.jcom.co.jp/vi/sim_contact/entry_request.php?form_type=eng_inquires)

[Consultar](https://www.jcom.co.jp/pt/sim_contact/entry_request.php?form_type=eng_inquires)

[閉じる](https://www.jcom.co.jp/#)

[](https://www.jcom.co.jp/#)

会员　  
联系我们

이용 중인 고객　  
문의

Khách hàng đang sử dụng　  
Hỏi đáp

Utilizadores　  
Consultar

电话咨询（有翻译）

전화 상담(통역 있음)

Tư vấn qua điện thoại (có phiên dịch)

Consulta por telefone (com intérprete)

[050-1722-1733](tel:050-1722-1733)

9:00-18:00 ［年中無休］

[日本語での通話はこちら](https://www.jcom.co.jp/#)

[联系我们](https://www.jcom.co.jp/zh-CHS/sim_contact/entry_request.php?form_type=eng_inquires)

[문의](https://www.jcom.co.jp/ko/sim_contact/entry_request.php?form_type=eng_inquires)

[Hỏi đáp](https://www.jcom.co.jp/vi/sim_contact/entry_request.php?form_type=eng_inquires)

[Consultar](https://www.jcom.co.jp/pt/sim_contact/entry_request.php?form_type=eng_inquires)

[閉じる](https://www.jcom.co.jp/#)

[](https://www.jcom.co.jp/#)

会员　  
联系我们

이용 중인 고객　  
문의

Khách hàng đang sử dụng　  
Hỏi đáp

Utilizadores　  
Consultar

电话咨询（有翻译）

전화 상담(통역 있음)

Tư vấn qua điện thoại (có phiên dịch)

Consulta por telefone (com intérprete)

[050-1722-1733](tel:050-1722-1733)

9:00-18:00 ［年中無休］

[日本語での通話はこちら](https://www.jcom.co.jp/#)

[联系我们](https://www.jcom.co.jp/zh-CHS/sim_contact/entry_request.php?form_type=eng_inquires)

[문의](https://www.jcom.co.jp/ko/sim_contact/entry_request.php?form_type=eng_inquires)

[Hỏi đáp](https://www.jcom.co.jp/vi/sim_contact/entry_request.php?form_type=eng_inquires)

[Consultar](https://www.jcom.co.jp/pt/sim_contact/entry_request.php?form_type=eng_inquires)

[閉じる](https://www.jcom.co.jp/#)

[](https://www.jcom.co.jp/#)

日本語でのお問い合わせ

[海外にお住まいの方](https://cs.myjcom.jp/knowledgeDetail?an=004897372)

[日本国内にお住まいの方](https://www.jcom.co.jp/contactus/call_rgu.html)

[閉じる](https://www.jcom.co.jp/#)

[](https://www.jcom.co.jp/#)

日本語でのお問い合わせ

[海外にお住まいの方](https://cs.myjcom.jp/knowledgeDetail?an=004897372)

[日本国内にお住まいの方](https://www.jcom.co.jp/contactus/call_rgu.html)

[閉じる](https://www.jcom.co.jp/#)

ご検討中の方の疑問にお答えします

[よくあるご質問](https://www.jcom.co.jp/contactus/#anc_faq)

J:COMからのお知らせ
------------

*   大切な  
    お知らせ
*   お知らせ

メンテ2025年12月03日

[【12月6日(土) AM6:20～】システムメンテナンスに伴うWebページ閲覧停止のお知らせ](https://notices.jcom.co.jp/notice/94042.html)

MOBILE2025年11月18日

[J:COM MOBILE Aプランへのメッセージサービス「RCS」提供について](https://notices.jcom.co.jp/notice/93991.html)

MOBILE2025年11月04日

[NTTドコモ 3G（FOMA）サービス終了に伴う弊社通信サービスへの影響について](https://notices.jcom.co.jp/notice/93984.html)

[お知らせ一覧](https://notices.jcom.co.jp/)

[障害・メンテナンス情報](https://information.myjcom.jp/maintenance_outage/)

TV2025年12月03日

[「エンタメ～テレHD☆シネドラバラエティ」リニューアルおよび「ダンスチャンネル by エンタメ～テレ」放送終了のお知らせ](https://notices.jcom.co.jp/notice/94041.html)

MOBILE2025年12月02日

[【J:COM MOBILE】一部機種での「LINE」アプリサポート終了に伴う利用不可について](https://notices.jcom.co.jp/notice/93981.html)

電力2025年12月01日

[【J:COMでんき/電力】2025年12月分（1月検針分）の燃料費等調整単価について](https://notices.jcom.co.jp/notice/94036.html)

サービス2025年11月29日

[訪問サポートのご利用条件変更について](https://notices.jcom.co.jp/notice/94040.html)

その他2025年11月28日

[ファイル共有ソフト利用による著作権侵害についてご注意ください](https://notices.jcom.co.jp/notice/93989.html)

TV2025年11月28日

[オプションチャンネル「J SPORTS 1＋2＋3＋4chセット」「J SPORTS・ゴルフネットワークセット」新規受付終了のお知らせ](https://notices.jcom.co.jp/notice/94037.html)

[お知らせ一覧](https://notices.jcom.co.jp/#noticeAnchorLink)

[障害・メンテナンス情報](https://information.myjcom.jp/maintenance_outage/)

ショップ・オンラインルーム

[![ジェイコムショップ](https://www.jcom.co.jp/images_v10/banner-under1.webp)](https://www.jcom.co.jp/shop/)

[![J:COMオンラインルーム ※ご予約が必要です](https://www.jcom.co.jp/images_v10/banner-under5_v2.webp)](https://www.jcom.co.jp/guide/online/)

J:COM放送の地域チャンネル

[![J:COMチャンネル](https://www.jcom.co.jp/images_v10/banner-under3.webp)](https://c.myjcom.jp/jch/)

[![J:テレ](https://www.jcom.co.jp/images_v10/banner-under4_2.webp)](https://c.myjcom.jp/jtele/)

サステナビリティ

J:COMでは、企業理念とSDGsから生まれた4つの約束を果たすべく、サステナビリティ経営に取り組んでまいります。[詳しくはこちら](https://www.jcom.co.jp/corporate/sustainability/)

[シェアする](https://www.jcom.co.jp/)

[Tweet](https://twitter.com/share?ref_src=twsrc%5Etfw)

【税込金額について】

*   表記の金額は特に記載のある場合を除き税込金額。
*   インボイス制度下における消費税の端数処理方法変更により消費税差額が生じる場合があります。

[古物営業法に基づく表示](https://www.jcom.co.jp/service/kobutu/?sc_pid=newtop_other_kobutu)

[![ページ上部へ戻る](https://www.jcom.co.jp/common_v10/images/PageTop.webp)](https://www.jcom.co.jp/#header)

[ページトップへ戻る](https://www.jcom.co.jp/#header)

[サービス情報](https://www.jcom.co.jp/?sc_pid=common_footer_unav_service_01)

[オンラインショップ](https://onlineshop.jcom.co.jp/?sc_pid=common_footer_unav_ols_01)

[サポートお困りごと解決・よくあるご質問](https://cs.myjcom.jp/?sc_pid=common_footer_unav_csmyjcom_01)

[Fun! J:COMテレビ番組情報／プレゼント・優待](https://www.myjcom.jp/?sc_pid=common_footer_unav_myjcom_01)

[マイページ契約内容確認・変更](https://mypage.jcom.co.jp/?sc_pid=common_footer_unav_mypage_01)

[企業サイト](https://www.jcom.co.jp/corporate/?sc_pid=common_footer_unav_corporate_01)

*   [![Twitter](https://www.jcom.co.jp/common_v10/images/icn-x.svg)](https://twitter.com/jcom_info?sc_pid=common_footer_sns_twitter_01)
    
*   [![instagram](https://www.jcom.co.jp/common_v10/images/icn-instagram.svg)](https://www.instagram.com/jcom.official/?sc_pid=common_footer_sns_instagram_01)
    
*   [![Facebook](https://www.jcom.co.jp/common_v10/images/icn-facebook.svg)](https://www.facebook.com/JCOM.ZAQ?sc_pid=common_footer_sns_facebook_01)
    
*   [![LINE](https://www.jcom.co.jp/common_v10/images/icn-line.svg)](https://www.jcom.co.jp/social/campaign/line/?sc_pid=common_footer_sns_line_01)
    
*   [![note](https://www.jcom.co.jp/common_v10/images/icn-note.svg)](https://note.jcom.co.jp/?sc_pid=common_footer_sns_note_01)
    

[アカウント一覧](https://www.jcom.co.jp/service/social/?sc_pid=common_footer_sns_list_01)

[![あたらしいを、あたりまえに J:COMはおかげさまで30周年。 J:COM 30th ANNIVERSARY](https://www.jcom.co.jp/common_v10/images/logo-jcom-horizontal.svg)](https://www.jcom.co.jp/special/30th/)

*   [サイトマップ](https://www.jcom.co.jp/sitemap/?sc_pid=common_footer_sitemap)
    
*   [プライバシーポータル](https://www.jcom.co.jp/corporate/site_info/privacy-portal/?sc_pid=common_footer_privacybasic)
    
*   [プライバシーポリシー](https://www.jcom.co.jp/corporate/site_info/privacy_policy/?sc_pid=common_footer_privacy)
    
*   [ウェブアクセシビリティの取り組み](https://www.jcom.co.jp/corporate/site_info/accessibility/?sc_pid=common_footer_accessibility)
    
*   [セキュリティーポリシー](https://www.jcom.co.jp/corporate/site_info/security_policy/?sc_pid=common_footer_security)
    
*   [ソーシャルメディアポリシー](https://www.jcom.co.jp/corporate/site_info/socialmedia_policy/?sc_pid=common_footer_social)
    
*   [人権方針](https://www.jcom.co.jp/corporate/sustainability/well_being/hrp/?sc_pid=common_footer_hrp#policy)
    
*   [Cookie情報の利用、広告配信などについて](https://www.jcom.co.jp/corporate/site_info/privacy_policy/cookie/?sc_pid=common_footer_cookie)
    
*   [お問い合わせ](https://www.jcom.co.jp/contactus/?sc_pid=common_footer_contactus)
    
*   [企業サイト](https://www.jcom.co.jp/corporate/?sc_pid=common_footer_corporate)
    
*   [採用情報](https://recruit.jcom.co.jp/?sc_pid=common_footer_recruit)
    
*   [法人のお客さま](https://business.jcom.co.jp/?sc_pid=common_footer_business)
    
*   [当サイトについて](https://www.jcom.co.jp/site_info/?sc_pid=common_footer_siteinfo)
    

Copyright © JCOM Co., Ltd. All Rights Reserved.

[](https://www.jcom.co.jp/#)

エリアを設定する

郵便番号を入力してください。

〒

ハイフン（-）は不要です

住居タイプを選択してください。

![icon](https://www.jcom.co.jp/common_v10/images/icn-apartment.svg)集合住宅

![icon](https://www.jcom.co.jp/common_v10/images/icn-house.svg)戸建住宅

該当する年齢を選択してください。  
（ご紹介できるプランが変わります。）

27歳以上

26歳以下

22歳以下

次へ

[](https://www.jcom.co.jp/#)

エリアを設定する

郵便番号を入力してください。

〒

 

住居タイプを選択してください。

![icon](https://www.jcom.co.jp/common_v10/images/icn-apartment.svg)集合住宅

![icon](https://www.jcom.co.jp/common_v10/images/icn-house.svg)戸建住宅

次へ

[](https://www.jcom.co.jp/#)

エリアを設定する

郵便番号を入力してください。

〒

 

住居タイプを選択してください。

![icon](https://www.jcom.co.jp/common_v10/images/icn-apartment.svg)集合住宅

![icon](https://www.jcom.co.jp/common_v10/images/icn-house.svg)戸建住宅

次へ

[](https://www.jcom.co.jp/#)

エリアを設定する

郵便番号を入力してください。

〒

ハイフン（-）は不要です

次へ

[](https://www.jcom.co.jp/#)

エリアを設定する

郵便番号を入力してください。

〒

 

住居タイプを選択してください。

![icon](https://www.jcom.co.jp/common_v10/images/icn-apartment.svg)集合住宅

![icon](https://www.jcom.co.jp/common_v10/images/icn-house.svg)戸建住宅

次へ

[](https://www.jcom.co.jp/#)

サービスの確認

転居先の郵便番号を入力してください。

〒

 

次へ

[](https://www.jcom.co.jp/#)

J:COM オンライン診療　提供エリアの確認

郵便番号を入力してください。

〒

ハイフン（-）は不要です

住居タイプを選択してください。

![icon](https://www.jcom.co.jp/common_v10/images/icn-apartment.svg)集合住宅

![icon](https://www.jcom.co.jp/common_v10/images/icn-house.svg)戸建住宅

次へ

[](https://www.jcom.co.jp/#)

都道府県を選択

必須都道府県を選択してください。

北海道・東北

[北海道](https://www.jcom.co.jp/#)
 [宮城県](https://www.jcom.co.jp/#)

関東

[東京都](https://www.jcom.co.jp/#)
 [神奈川県](https://www.jcom.co.jp/#)
 [千葉県](https://www.jcom.co.jp/#)
 [埼玉県](https://www.jcom.co.jp/#)
 [群馬県](https://www.jcom.co.jp/#)
 [茨城県](https://www.jcom.co.jp/#)

関西

[大阪府](https://www.jcom.co.jp/#)
 [京都府](https://www.jcom.co.jp/#)
 [和歌山県](https://www.jcom.co.jp/#)
 [兵庫県](https://www.jcom.co.jp/#)

九州・山口

[福岡県](https://www.jcom.co.jp/#)
 [熊本県](https://www.jcom.co.jp/#)
 [大分県](https://www.jcom.co.jp/#)
 [山口県](https://www.jcom.co.jp/#)

[戻る](https://www.jcom.co.jp/#)

[](https://www.jcom.co.jp/#)

市区町村を選択

必須市区町村を選択してください。

現在の選択：東京都

*   あ
*   か
*   さ
*   た
*   な
*   は
*   ま
*   や
*   ら
*   わ

[昭島市](https://www.jcom.co.jp/#)
 [あきる野市](https://www.jcom.co.jp/#)
 [足立区](https://www.jcom.co.jp/#)
 [板橋区](https://www.jcom.co.jp/#)
 [稲城市](https://www.jcom.co.jp/#)
 [江戸川区](https://www.jcom.co.jp/#)
 [大田区](https://www.jcom.co.jp/#)

「か」のコンテンツ内容

「あ」行から始まる地域

[昭島市](https://www.jcom.co.jp/#)
 [あきる野市](https://www.jcom.co.jp/#)
 [足立区](https://www.jcom.co.jp/#)
 [板橋区](https://www.jcom.co.jp/#)
 [稲城市](https://www.jcom.co.jp/#)
 [江戸川区](https://www.jcom.co.jp/#)
 [大田区](https://www.jcom.co.jp/#)

「か」行から始まる地域

「さ」行から始まる地域

「た」行から始まる地域

「な」行から始まる地域

[戻る](https://www.jcom.co.jp/#)

[](https://www.jcom.co.jp/#)

エリアを設定する

〒 1070052

ご入力いただいた郵便番号には、複数のエリア候補があります。  
以下のリストから住所を選択してください

選択して下さい 1 2 3 テキストテキストテキスト

設定する

[戻る](https://www.jcom.co.jp/#)

[](https://www.jcom.co.jp/#)

エリアを設定する

〒 \-------

続く住所情報を選択してください。

  

選択して下さい 1 2 3 テキストテキストテキスト

次へ

[戻る](https://www.jcom.co.jp/#)

[](https://www.jcom.co.jp/#)

ギガ提供エリアの確認

〒 1070052 (J:COM 町田・川崎)は

J:COM NET 1Gコース  
の提供エリアです。

※ 「J:COM NET 1Gコース」はケーブルテレビ回線でご利用いただける1ギガサービスです。

光10G・5G・1Gコース  
の提供エリアです。

※ 光は一部エリアで未提供（順次拡大）[詳しくはこちらよりお問い合わせください](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

光10G・5G・1Gコース※1  
の提供エリア拡大中です。

J:COM NET 1Gコース※2  
の提供エリアです。

※1 光は一部エリアで未提供（順次拡大）[詳しくはこちらよりお問い合わせください](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

※2 「J:COM NET 1Gコース」はケーブルテレビ回線でご利用いただける1ギガサービスです。

光10G・5G・1Gコース  
J:COM NET 1Gコース  
の提供エリアです。

※ 一部エリアで未提供（順次拡大）[詳しくはこちらよりお問い合わせください](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

※ 「J:COM NET 1Gコース」はケーブルテレビ回線でご利用いただける1ギガサービスです。

J:COM NET 1Gコース  
の提供エリア外です。（順次提供エリア拡大中）

320Mコース  
の提供エリアです。

320Mコース  
の提供エリアです。

J:COM NET 1Gコースの提供エリアは順次拡大中です。

[提供エリアの詳しい情報はこちらよりお問い合わせください](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=service_contact)

J:COM大分（大分ケーブルテレコム株式会社）のサービスエリアです。  
[J:COM大分（大分ケーブルテレコム株式会社）のホームページ](https://wwwjcom.oct-net.ne.jp/)
をご覧ください。

横浜ケーブルビジョン（YCV）のサービスエリアです。  
[横浜ケーブルビジョン（YCV）のホームページ](https://www.catv-yokohama.ne.jp/)
をご覧ください。

[お申し込み](https://www.jcom.co.jp/sim_contact/entry_request.php?refresh=new&net_service=1)

[お申し込みの流れを確認する](https://www.jcom.co.jp/service/guide/sdu/)

一部地域は提供エリア外の場合があります。

[料金・コースを見る](https://www.jcom.co.jp/service/net/)

戻る

[](https://www.jcom.co.jp/#)

ギガ提供エリアの確認

〒 1070052 (町田・川崎)は

光 10G・5G・1Gコース  
J:COM NET 1Gコース  
の提供エリアです。

※ 「J:COM NET 1Gコース」はケーブルテレビ回線でご利用いただける1ギガサービスです。

光 10G・5G・1Gコース  
の提供エリアです。

光 1Gコース  
J:COM NET 1Gコース  
の提供エリアです。

※ 「J:COM NET 1Gコース」はケーブルテレビ回線でご利用いただける1ギガサービスです。

光 1Gコース  
の提供エリアです。

320Mコース  
の提供エリアです。

[お申し込み](https://www.jcom.co.jp/sim_contact/entry_request.php?refresh=new&net_service=1)

[お申し込みの流れを確認する](https://www.jcom.co.jp/service/guide/sdu/)

一部地域は提供エリア外の場合があります。

料金・コースを見る

[料金シミュレーション](https://onlineshop.jcom.co.jp/Simulation/Simulation)

戻る

[](https://www.jcom.co.jp/#)

ギガ提供エリアの確認

〒 1070052 

J:COM NET  
の提供エリア外です。

J:COM WiMAX  
の提供エリアです。

[お申し込み](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=wimax2p)

[お申し込みの流れを確認する](https://www.jcom.co.jp/service/guide/sdu/)

一部地域は提供エリア外の場合があります。

[料金・コースを見る](https://www.jcom.co.jp/service/wimax/)

戻る

[](https://www.jcom.co.jp/#)

提供エリアの確認

〒 \------- 

J:COM大分（大分ケーブルテレコム株式会社）のサービスエリアです。  
[J:COM大分（大分ケーブルテレコム株式会社）のホームページ](https://wwwjcom.oct-net.ne.jp/)
をご覧ください。

横浜ケーブルビジョン（YCV）のサービスエリアです。  
[横浜ケーブルビジョン（YCV）のホームページ](https://www.catv-yokohama.ne.jp/)
をご覧ください。

以下のサービスをご利用いただけます。

   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-mobile.svg) ![J:COM MOBILE](https://www.jcom.co.jp/common_v10/images/logo-jcom-mobile.svg)](https://www.jcom.co.jp/service/mobile/)   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-electricity.svg) ![J:COM でんき](https://www.jcom.co.jp/common_v10/images/logo-jcom-electricity.svg)](https://www.jcom.co.jp/service/electricity/)
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-gas.svg) ![J:COM ガス](https://www.jcom.co.jp/common_v10/images/logo-jcom-gas.svg)](https://www.jcom.co.jp/service/gas/)
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-ssi.svg) ![J:COM ほけん](https://www.jcom.co.jp/common_v10/images/logo-jcom-ssi.svg)](https://www.jcom.co.jp/service/ssi/)
  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-telemedicine.svg) ![J:COM オンライン診療](https://www.jcom.co.jp/common_v10/images/logo-jcom-telemedicine.svg)](https://www.jcom.co.jp/service/telemedicine/)

以下サービスは[料金シミュレーション](https://onlineshop.jcom.co.jp/Simulation/Simulation)
で  
エリアをご確認ください。

  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-net.svg)\
\
![J:COM NET](https://www.jcom.co.jp/common_v10/images/logo-jcom-net.svg) 光10G/光1G](https://www.jcom.co.jp/price/hikari-n/)  ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-tv.svg) 地デジ・BSデジ  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-phone.svg) ひかり電話](https://www.jcom.co.jp/price/hikari-n/phone-op/)

J:COM NETは NTT回線でご提供となります。

[お申し込み](https://onlineshop.jcom.co.jp/planSelect)

[料金シミュレーション](https://onlineshop.jcom.co.jp/Simulation/Simulation)

地域のケーブルテレビをご希望の方は [こちら](https://www.catv-jcta.jp/search/index)

戻る

お住まいの地域によって、一部サービスがご利用いただけない場合がございます。

[](https://www.jcom.co.jp/#)

サービスの確認

〒 1070052 は

J:COM大分（大分ケーブルテレコム株式会社）のサービスエリアです。提供サービスの確認は、[J:COM大分（大分ケーブルテレコム株式会社）のホームページ](https://wwwjcom.oct-net.ne.jp/)
をご覧ください。

横浜ケーブルビジョン（YCV）のサービスエリアです。  
[横浜ケーブルビジョン（YCV）のホームページ](https://www.catv-yokohama.ne.jp/)
をご覧ください。

以下のサービスをご利用いただけます。

   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-tv.svg) ![J:COM TV](https://www.jcom.co.jp/common_v10/images/logo-jcom-tv.svg)](https://www.jcom.co.jp/service/tv/)   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-net.svg) ![J:COM NET](https://www.jcom.co.jp/common_v10/images/logo-jcom-net.svg)](https://www.jcom.co.jp/service/net/)
  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-mobile.svg) ![J:COM MOBILE](https://www.jcom.co.jp/common_v10/images/logo-jcom-mobile.svg)](https://www.jcom.co.jp/service/mobile/)
  
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-phone.svg) ![J:COM PHONE](https://www.jcom.co.jp/common_v10/images/logo-jcom-phone.svg)](https://www.jcom.co.jp/service/phone/)   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-ssi.svg) ![J:COM ほけん](https://www.jcom.co.jp/common_v10/images/logo-jcom-ssi.svg)](https://www.jcom.co.jp/service/ssi/)
  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-telemedicine.svg) ![J:COM オンライン診療](https://www.jcom.co.jp/common_v10/images/logo-jcom-telemedicine.svg)](https://www.jcom.co.jp/service/telemedicine/)

[J:COMご加入中の方  \
お引越しのお手続き](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=contact_move)

郵便番号入力に戻る

[](https://www.jcom.co.jp/#)

提供エリアの確認

〒 1070052 (J:COM 町田・川崎)は

以下のサービスをご利用いただけます。

   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-tv.svg) ![J:COM TV](https://www.jcom.co.jp/common_v10/images/logo-jcom-tv.svg)](https://www.jcom.co.jp/service/tv/)   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-net.svg) ![J:COM NET](https://www.jcom.co.jp/common_v10/images/logo-jcom-net.svg)](https://www.jcom.co.jp/service/net/)
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-mobile.svg) ![J:COM MOBILE](https://www.jcom.co.jp/common_v10/images/logo-jcom-mobile.svg)](https://www.jcom.co.jp/service/mobile/)
  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-electricity.svg) ![J:COM でんき](https://www.jcom.co.jp/common_v10/images/logo-jcom-electricity.svg)](https://www.jcom.co.jp/service/electricity/)
  
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-phone.svg) ![J:COM PHONE](https://www.jcom.co.jp/common_v10/images/logo-jcom-phone.svg)](https://www.jcom.co.jp/service/phone/)   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-gas.svg) ![J:COM ガス](https://www.jcom.co.jp/common_v10/images/logo-jcom-gas.svg)](https://www.jcom.co.jp/service/gas/)
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-ssi.svg) ![J:COM ほけん](https://www.jcom.co.jp/common_v10/images/logo-jcom-ssi.svg)](https://www.jcom.co.jp/service/ssi/)
   [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-home.svg) ![J:COM HOME](https://www.jcom.co.jp/common_v10/images/logo-jcom-home.svg)](https://www.jcom.co.jp/service/home/)
  [![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-telemedicine.svg) ![J:COM オンライン診療](https://www.jcom.co.jp/common_v10/images/logo-jcom-telemedicine.svg)](https://www.jcom.co.jp/service/telemedicine/)

[お申し込み](https://onlineshop.jcom.co.jp/planSelect)
 [お申し込み](https://onlineshop.jcom.co.jp/planSelect)

[お申し込みの流れを確認する](https://www.jcom.co.jp/service/guide/sdu/)

料金シミュレーション

戻る

[](https://www.jcom.co.jp/#)

サービスの確認

〒 1070052 (J:COM 町田・川崎)は

以下のサービスをご利用いただけます。

   ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-tv.svg) ![J:COM TV](https://www.jcom.co.jp/common_v10/images/logo-jcom-tv.svg) ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-net.svg) ![J:COM NET](https://www.jcom.co.jp/common_v10/images/logo-jcom-net.svg)  ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-mobile.svg) ![J:COM MOBILE](https://www.jcom.co.jp/common_v10/images/logo-jcom-mobile.svg)  ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-electricity.svg) ![J:COM でんき](https://www.jcom.co.jp/common_v10/images/logo-jcom-electricity.svg)  
   ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-phone.svg) ![J:COM PHONE](https://www.jcom.co.jp/common_v10/images/logo-jcom-phone.svg) ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-gas.svg) ![J:COM ガス](https://www.jcom.co.jp/common_v10/images/logo-jcom-gas.svg)  ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-home.svg) ![J:COM HOME](https://www.jcom.co.jp/common_v10/images/logo-jcom-home.svg)

[J:COMご加入中の方  \
お引越しのお手続き](https://www.jcom.co.jp/sim_contact/entry_request.php?form_type=contact_move)

郵便番号入力に戻る

[](https://www.jcom.co.jp/#)

提供エリアの確認

サービスをお選びください。

テレビとネットがセットでおトク！

 ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-tv.svg)  
![J:COM TV](https://www.jcom.co.jp/common_v10/images/logo-jcom-tv.svg)![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-net.svg)  
![J:COM NET](https://www.jcom.co.jp/common_v10/images/logo-jcom-net.svg) ![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-phone.svg)  
![J:COM PHONE](https://www.jcom.co.jp/common_v10/images/logo-jcom-phone.svg)

[料金シミュレーション](https://onlineshop.jcom.co.jp/Simulation/Simulation)

月々のスマホ代をもっとおトクに。

![icon](https://www.jcom.co.jp/common_v10/images/icn-jcom-mobile.svg)  
![J:COM MOBILE](https://www.jcom.co.jp/common_v10/images/logo-jcom-mobile.svg)

[料金シミュレーション](https://www.jcom.co.jp/service/mobile/simulator/)

戻る

[](https://www.jcom.co.jp/#)

J:COM ガス提供エリアの確認

〒 1070052 (J:COM ----)は

![](https://www.jcom.co.jp/common_form/img/common/logo/logo_gas_osaka.png)

の提供エリアです。

一部地域は提供エリア外の場合があります。

![](https://www.jcom.co.jp/common_form/img/common/logo/logo_gas_tokyo.png)

の提供エリアです。

一部地域は提供エリア外の場合があります。

![](https://www.jcom.co.jp/common_form/img/common/logo/logo_gas_keiyo.png)

の提供エリアです。

一部地域は提供エリア外の場合があります。

J:COM ガス  
の提供エリア外です。

（株）エナジー宇宙の【越谷・春日部地区/蓮田南地区】【取手・我孫子地区】の  
都市ガス供給エリアにお住まいの方は

東京ガス for J:COM「ずっともガス」

がご利用いただけます。

[詳しく見る](https://www.jcom.co.jp/service/tokyo_gas/)

J:COM ガス  
の提供エリア外です。

戻る

[](https://www.jcom.co.jp/#)

J:COM オンライン診療　提供エリアの確認

〒 1070052 (J:COM ----)は

J:COM オンライン診療  
の提供エリアです。

一部地域は提供エリア外の場合があります。

[医療機関一覧を見る](https://www.jcom.co.jp/service/telemedicine/clinic/)

[料金を見る](https://www.jcom.co.jp/service/telemedicine/price/)

J:COM オンライン診療  
の提供エリア外です。

戻る

    

[](https://www.jcom.co.jp/#)

あなたへのお知らせ
---------

[ログアウト](https://www.jcom.co.jp/common/logout.html)
