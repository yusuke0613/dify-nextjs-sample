# 【公式】光回線インターネットサービス｜期間限定キャンペーン実施中！NURO 光

URL: https://www.nuro.jp/hikari/

---

![このページの特典に加えて+ 20,000円キャッシュバック](https://www.nuro.jp/hikari/renewal/r/images/renewal-cashback-banner_pc.png?v=9e1de064ae)

![このページの特典に加えて+ 20,000円キャッシュバック](https://www.nuro.jp/hikari/renewal/r/images/renewal-cashback-banner_sp.png?v=96d8fe1ee2)

![SONY](https://www.nuro.jp/components/assets/img/common/logo_sony.png)

[![NURO光](https://www.nuro.jp/components/assets/img/common/logo_nuro_hikari.svg)](https://www.nuro.jp/hikari/)

===============================================================================================================

*   戸建て料金・プラン
*   マンション料金・プラン

[マイページ](https://www.nuro.jp/app/mypage/?_stcid=e6d9618b1bf7b20d08e2559d8cac18a1.a398171c2c7f42c788b47c5cfac67f4f)
[お申し込み\
\
![](https://www.nuro.jp/components/assets/img/common/icon_arrow_bg_white-red.svg)](https://www.nuro.jp/hikari/#applyArea)

*   [料金スペック](https://www.nuro.jp/hikari/house/price/)
    
*   [オプション](https://www.nuro.jp/hikari/house/option/)
    
*   [ご利用までの流れ](https://www.nuro.jp/hikari/house/flow/)
    

*   お知らせ
    
*   *   [お知らせ](https://www.nuro.jp/news_release/)
        
*   よくあるご質問
    
*   *   [契約をご検討中の方](https://www.nuro.jp/help/)
        
    *   [お申し込み済みの方](https://www.nuro.jp/support/?_stcid=e6d9618b1bf7b20d08e2559d8cac18a1.a398171c2c7f42c788b47c5cfac67f4f)
        

*   申込まで安心
    
*   *   [LINE公式アカウント](https://www.nuro.jp/hikari/line/)
        
*   開通まで安心
    
*   *   [レンタルWi-Fi](https://www.nuro.jp/hikari/flow_const.html#wifi)
        
*   もっとおトクに
    
*   *   [お友達紹介クーポン](https://www.nuro.jp/hikari/friend_coupon/)
        
    *   [モバイルセット割](https://www.nuro.jp/hikari/campaign/hikarimobileset/)
        

*   開通後も安心
    
*   *   [NURO会員アプリ](https://www.nuro.jp/hikari/app/)
        
    *   [会員サポート](https://www.nuro.jp/support/)
        
    *   [NURO会員特典](https://www.nuro.jp/member/benefit/)
        
    *   [NURO 光のお引越し](https://www.nuro.jp/hikari/campaign/hikkoshi/)
        
*   個人事業主・法人の方
    
*   *   [個人事業主・法人の方はこちら](https://www.nuro.jp/hikari/bizguide/)
        

料金・特典などのお悩みごとについて

*   [電話で相談する\
    \
    受付時間 9:00~21:00](https://www.nuro.jp/hikari/#applyArea_phone)
    
*   [よくあるご質問を  \
    確認する](https://www.nuro.jp/help/)
    

画面右下の「ご質問・ご相談」のバナーからチャットでもご相談をいただけます。

*   [料金スペック](https://www.nuro.jp/hikari/mansion/price/)
    
*   [オプション](https://www.nuro.jp/hikari/mansion/option/)
    
*   [ご利用までの流れ](https://www.nuro.jp/hikari/mansion/flow/)
    

*   お知らせ
    
*   *   [お知らせ](https://www.nuro.jp/news_release/)
        
*   よくあるご質問
    
*   *   [契約をご検討中の方](https://www.nuro.jp/help/)
        
    *   [お申し込み済みの方](https://www.nuro.jp/support/?_stcid=e6d9618b1bf7b20d08e2559d8cac18a1.a398171c2c7f42c788b47c5cfac67f4f)
        
*   申込まで安心
    
*   *   [LINE公式アカウント](https://www.nuro.jp/hikari/line/)
        

*   開通まで安心
    
*   *   [レンタルWi-Fi](https://www.nuro.jp/hikari/flow_const.html#wifi)
        
*   開通後も安心
    
*   *   [NURO会員アプリ](https://www.nuro.jp/hikari/app/)
        
    *   [会員サポート](https://www.nuro.jp/support/)
        
    *   [NURO会員特典](https://www.nuro.jp/member/benefit/)
        
    *   [NURO 光のお引越し](https://www.nuro.jp/hikari/campaign/hikkoshi/mansion/)
        

*   管理会社・管理組合・オーナーさまはこちら
    
*   *   [管理会社・管理組合・オーナーさまはこちら](https://www.nuro.jp/hikari/mansion/owner/)
        
*   販売パートナーをご検討の方はこちら
    
*   *   [販売パートナーをご検討の方はこちら](https://www.nuro.jp/hikari/partner/?a=plan02)
        
*   個人事業主・法人の方
    
*   *   [個人事業主・法人の方はこちら](https://www.nuro.jp/hikari/bizguide/)
        

料金・特典などのお悩みごとについて

*   [電話で相談する\
    \
    受付時間 9:00~21:00](https://www.nuro.jp/hikari/#applyArea_phone)
    
*   [よくあるご質問を  \
    確認する](https://www.nuro.jp/help/)
    

画面右下の「ご質問・ご相談」のバナーからチャットでもご相談をいただけます。

特に注記のない限り、記載の金額は全て税込金額です。

![2年間ずーっと！最大2,980円/月〜 Opensignal社 固定ブロードバンド・エクスペリエンス 通信速度・信頼性No.1](https://www.nuro.jp/assets/img/hikari/top/kv_sp.jpg?v=a460baa773)

1.  マンションの場合の金額です。（戸建ての場合は3,980円/月）価格は2025年11月現在のものです。お申し込み前に[注意事項](https://www.nuro.jp/hikari/#attentionArea)
    をご確認ください。
    
2.  [「固定ブロードバンド・エクスペリエンス」、全国 - ワイヤーライン結果について](https://www.nuro.jp/hikari/)
    

[![NUROモバイルへお申し込みの方NURO会員なら4つのプラン共通で3年間ずーっと割引　リンクを開く](https://www.nuro.jp/hikari/top/img/kv_sub_hikarimobileset.png?v=8ce1bfc667)](https://www.nuro.jp/hikari/campaign/hikarimobileset/)

[![U29　応援割　最大4年間ずっと定額　リンクを開く](https://www.nuro.jp/hikari/top/img/kv_sub_u29.png?v=b7e14dadb6)](https://www.nuro.jp/hikari/#anc-u29)

[![お友達紹介クーポンでそれぞれキャッシュバック！　リンクを開く](https://www.nuro.jp/hikari/top/img/kv_sub_coupon.png?v=19e0b905f5)](https://www.nuro.jp/hikari/friend_coupon/?_stcid=e6d9618b1bf7b20d08e2559d8cac18a1.a398171c2c7f42c788b47c5cfac67f4f)

[![感動を止めるな。豪華賞品が当たるキャンペーン実施中　リンクを開く](https://www.nuro.jp/hikari/top/img/kv_sub_brand.png?v=eee74703a1)](https://www.nuro.jp/hikari/campaign/brand/)

[![NUROへまとめてキャッシュバック でんき ひかりTV ガス でんわ 最大44,000円還元　リンクを開く](https://www.nuro.jp/hikari/top/img/kv_sub_cashback.png?v=6c390bc96d)](https://www.nuro.jp/hikari/house/option/)

[![NUROモバイルへお申し込みの方NURO会員なら4つのプラン共通で3年間ずーっと割引　リンクを開く](https://www.nuro.jp/hikari/top/img/kv_sub_hikarimobileset.png?v=8ce1bfc667)](https://www.nuro.jp/hikari/campaign/hikarimobileset/)

[![U29　応援割　最大4年間ずっと定額　リンクを開く](https://www.nuro.jp/hikari/top/img/kv_sub_u29.png?v=b7e14dadb6)](https://www.nuro.jp/hikari/#anc-u29)

[![お友達紹介クーポンでそれぞれキャッシュバック！　リンクを開く](https://www.nuro.jp/hikari/top/img/kv_sub_coupon.png?v=19e0b905f5)](https://www.nuro.jp/hikari/friend_coupon/?_stcid=e6d9618b1bf7b20d08e2559d8cac18a1.a398171c2c7f42c788b47c5cfac67f4f)

[![感動を止めるな。豪華賞品が当たるキャンペーン実施中　リンクを開く](https://www.nuro.jp/hikari/top/img/kv_sub_brand.png?v=eee74703a1)](https://www.nuro.jp/hikari/campaign/brand/)

[![NUROへまとめてキャッシュバック でんき ひかりTV ガス でんわ 最大44,000円還元　リンクを開く](https://www.nuro.jp/hikari/top/img/kv_sub_cashback.png?v=6c390bc96d)](https://www.nuro.jp/hikari/house/option/)

[![NUROモバイルへお申し込みの方NURO会員なら4つのプラン共通で3年間ずーっと割引　リンクを開く](https://www.nuro.jp/hikari/top/img/kv_sub_hikarimobileset.png?v=8ce1bfc667)](https://www.nuro.jp/hikari/campaign/hikarimobileset/)

2025年10月1日より、公式サイトで新規お申し込みいただける戸建て向けプラン「NURO 光（戸建て）」を一本化いたします。（プラン名：NURO 光 One）  
契約期間の縛りがなく、1回の開通工事でご利用いただけます。[料金詳細・お申し込みはこちら](https://www.nuro.jp/hikari/house/price/)

[![通信速度 信頼性 No.1 Opensignal社「固定ブロードバンド・エクスペリエンス」、全国-ワイヤーライン結果についてはこちらをクリック](https://www.nuro.jp/assets/img/share_opensignal/os.jpg?v=01b1440aff)](https://www.nuro.jp/hikari/)

![NURO 光 顧客満足度9年連続No.1 J.D.パワー 固定インターネットサービス 関東エリア J.D.パワー調査の詳細はjapan.jdpower.com/awardsをご参照ください。](https://www.nuro.jp/assets/img/share_opensignal/jdp.jpg?v=daa3df14e5)

[![通信速度 信頼性 No.1 Opensignal社「固定ブロードバンド・エクスペリエンス」、全国-ワイヤーライン結果についてはこちらをクリック](https://www.nuro.jp/assets/img/share_opensignal/os.jpg?v=01b1440aff)](https://www.nuro.jp/hikari/)

![NURO 光 顧客満足度9年連続No.1 J.D.パワー 固定インターネットサービス 関東エリア J.D.パワー調査の詳細はjapan.jdpower.com/awardsをご参照ください。](https://www.nuro.jp/assets/img/share_opensignal/jdp.jpg?v=daa3df14e5)

*   *   [NURO 光の特長①\
        \
        高速回線で動画・ゲーム、テレワークも快適](https://www.nuro.jp/hikari/#introArea)
        
    *   [NURO 光の特長②\
        \
        みんなに嬉しい  \
        特典・  \
        サポートが充実](https://www.nuro.jp/hikari/#supportArea)
        
*   [![](https://www.nuro.jp/hikari/top/img/anchor_illust.png?v=1b94eb668a)\
    \
    Web/電話から\
    \
    提供エリア確認・  \
    お申し込み](https://www.nuro.jp/hikari/#applyArea)
    

高速回線で動画・ゲー  
ム、テレワークも快適
-----------------------

![](https://www.nuro.jp/components/assets/img/common/nuro_intro_image_pc.png?v=e5b20bc70e)![](https://www.nuro.jp/components/assets/img/common/nuro_intro_image_sp.png?v=e5b20bc70e)

### 使い方にあわせて選べる2つのプラン

![高速インターネットをお得に！ 2ギガプラン](https://www.nuro.jp/hikari/top/img/nuro_plan_2g_pc.jpg?v=75f9c24f22)![高速インターネットをお得に！ 2ギガプラン](https://www.nuro.jp/hikari/top/img/nuro_plan_2g_sp.jpg?v=cae3f4f26e)

![速度重視で快適に！ 10ギガプラン](https://www.nuro.jp/hikari/top/img/nuro_plan_10g_pc.jpg?v=8fbe0cacc9)![速度重視で快適に！ 10ギガプラン](https://www.nuro.jp/hikari/top/img/nuro_plan_10g_sp.jpg?v=95c74ea7fe)

*   [通信速度（Gbps）とは？](https://www.nuro.jp/hikari/)
    
*   [通信速度に関する注意事項](https://www.nuro.jp/hikari/)
    

#### ネットワーク設備増強中！

ネットワーク設備を順次増強しているので、快適で安定したサービスをご利用いただけます。

[詳細はこちら](https://www.nuro.jp/quality/network_enhancement/?_stcid=e6d9618b1bf7b20d08e2559d8cac18a1.a398171c2c7f42c788b47c5cfac67f4f)

![REJECT](https://www.nuro.jp/hikari/top/img/nuro_reject.jpg?v=0c1b3ab28c)

### プロeスポーツ×NURO 光

日本有数のプロeスポーツチーム「REJECT」もNURO 光を愛用。安定したネット回線が重要となるeスポーツを、通信の面からサポートしています。

回線スピードレポート公開中！[詳細はこちら](https://www.nuro.jp/hikari/reject/index.html#anc-speedReport)

![通信速度・信頼性 No.1受賞！Opensignal社 固定フロードバンド・エクスペリエンス 4部門1位](https://www.nuro.jp/assets/img/share_opensignal/os_01_sp.jpg?v=36cd9eb23e)

*   [「固定ブロードバンド・エクスペリエンス」、全国 - ワイヤーライン結果について](https://www.nuro.jp/hikari/)
    

みんなに嬉しい  
特典・サポートが充実
--------------------

![](https://www.nuro.jp/components/assets/img/common/nuro_present_image.png?v=344846cf5f)

### 充実した特典でおトクにスタート

手続き不要で自動的に適用される特典を多数ご利用いただけます。

[![基本工事費 実質無料 0円　モーダルを開く](https://www.nuro.jp/hikari/top/img/nuro_benefit_01_blue_sp.png?v=6574cc4085)](https://www.nuro.jp/hikari/)

[![他社解約費用 最大3万円還元　モーダルを開く](https://www.nuro.jp/hikari/top/img/nuro_benefit_05_blue_sp.jpg?v=e77734acbf)](https://www.nuro.jp/hikari/)

[![設定サポート1回無料　モーダルを開く](https://www.nuro.jp/hikari/top/img/nuro_benefit_03_blue.jpg?v=8c219f1c50)](https://www.nuro.jp/hikari/)

[![解約費用 最大2か月無料　モーダルを開く](https://www.nuro.jp/hikari/top/img/nuro_benefit_04_blue.jpg?v=eefb2be842)](https://www.nuro.jp/hikari/)

![NURO 光 開通までの期間も安心 レンタルWi-Fi](https://www.nuro.jp/components/assets/img/common/rental-wifi.png?v=2c7227a3cf)

### お引越しに間に合わなくても安心

すぐに使えるレンタルWi-Fiを開通までご利用可能！  
安心してインターネットをご利用いただけます。

*   [選べる2タイプ  \
    詳しくはこちら](https://www.nuro.jp/hikari/)
    

### 開通まで安心のサポート

#### 現在の開通期間の目安

*   ![戸建て アイコン](https://www.nuro.jp/images/icon-kodate.png?v=b95a847aea)
    
    戸建て
    
    1〜2か月程度
    
*   ![マンション アイコン](https://www.nuro.jp/images/icon-mansion.png?v=e3bdb2fa98)
    
    マンション
    
    タイプSの場合：  
    1〜3か月程度
    
      
    
    タイプLの場合：  
    最短1～2週間
    
    [タイプの違い・確認方法はこちら](https://www.nuro.jp/hikari/)
    

[開通期間目安に関する注意事項](https://www.nuro.jp/hikari/)

![戸建て マンション 10ギガプラン4,400円/月 より同時接続に強い！　10Gbps　戸建て マンション 2ギガプラン3,850円/月　2Gbps　※戸建ての場合、3ねん定額割適用が必要です。](https://www.nuro.jp/components/assets/img/common/rental-wifi.png?v=2c7227a3cf)

### お引越しに間に合わなくても安心

すぐに使えるレンタルWi-Fiを開通までご利用可能！  
安心してインターネットをご利用いただけます。

*   [選べる2タイプ  \
    詳しくはこちら](https://www.nuro.jp/hikari/)
    

提供エリア確認・お申し込み
-------------

誤った住宅タイプを選択されると再申し込みが必要となり開通までにお時間がかかります。[お申し込み前に住宅タイプを確認ください](https://www.nuro.jp/hikari/)

2ギガも10ギガも定額でおトクに！

![戸建ての方 3年間 3,980円/月](https://www.nuro.jp/assets/img/hikari/top/title_house_pc.png?v=70dd5e4b47)

4年目以降  
2ギガ：5,500円/月 10ギガ：6,050円/月

[料金詳細はこちら](https://www.nuro.jp/hikari/house/price/)

![マンションの方 2年間 2,980円/月](https://www.nuro.jp/assets/img/hikari/top/title_mansion_pc.png?v=10fd9b5a9b)

3年目以降  
2ギガ：3,850円/月 10ギガ：4,400円/月

[料金詳細はこちら](https://www.nuro.jp/hikari/mansion/price/index.html)

[提供エリア確認・お申し込み](https://www.nuro.jp/app/nurohikari-directolsu/area/?coupon=intro&cust=per&route_code=30DM0119,31DM0113,9DMW0184,11DM0184,10DM0182,12DM0182&_stcid=e6d9618b1bf7b20d08e2559d8cac18a1.a398171c2c7f42c788b47c5cfac67f4f)

[![29歳以下なら+1年間おトク！ U29応援割　リンクを開く](https://www.nuro.jp/hikari/top/img/banner_u29_pc.png?v=089d548162)](https://www.nuro.jp/app/nurohikari-directolsu/area/?coupon=intro&cust=per&route_code=30DM0121,31DM0115,9DMW0185,11DM0185,10DM0183,12DM0183&_stcid=e6d9618b1bf7b20d08e2559d8cac18a1.a398171c2c7f42c788b47c5cfac67f4f)
[![29歳以下なら+1年間おトク！ U29応援割　リンクを開く](https://www.nuro.jp/hikari/top/img/banner_u29_sp.png?v=293011c131)](https://www.nuro.jp/app/nurohikari-directolsu/area/?coupon=intro&cust=per&route_code=30DM0121,31DM0115,9DMW0185,11DM0185,10DM0183,12DM0183&_stcid=e6d9618b1bf7b20d08e2559d8cac18a1.a398171c2c7f42c788b47c5cfac67f4f)

[戸建ての料金詳細](https://www.nuro.jp/hikari/house/price/)

[マンションの料金詳細](https://www.nuro.jp/hikari/mansion/price/index.html)

※お支払い方法はクレジットカード、携帯電話料金（ドコモ・ソフトバンク・au）と合わせてのお支払い、口座振替からお選びいただけます。口座振替の手数料については[こちら](https://www.nuro.jp/hikari/)

### 電話での相談・お申し込み

0120-117-260

[0120-117-260](tel:0120-117-260)

受付時間 9:00~21:00

*   1月1日、2日及び弊社指定のメンテナンス日を除き、年中無休です。
    

本窓口にてご契約を頂く場合、お電話にて重要事項を説明させていただきます。書面を手元にご用意のうえ、口頭でご説明を希望する場合は、オペレーターにその旨をお申し付けください。

お客様から多く寄せられているご質問は[FAQ](https://www.nuro.jp/help/)
に記載しています。

電話でのお申し込みについて

Webからのお申し込みであれば10分程度でお手続きいただけます。  
チャットでもご質問を承っておりますので、ぜひご利用ください。

*   お客さまのご要望に正確かつ迅速に対応するため、通話内容を録音させていただいております。対応終了後、消去いたします。
    
*   電話番号のおかけ間違いにはご注意ください。
    

[電話で相談・申し込む](tel:0120-117-260)

サービス提供エリア
---------

2ギガプラン 10ギガプラン

*   北海道
    
*   関東
    
    *   東京
        
    *   神奈川
        
    *   埼玉
        
    *   千葉
        
    *   茨城
        
    *   栃木
        
    *   群馬
        
    
*   東海
    
    *   愛知
        
    *   静岡
        
    *   岐阜
        
    *   三重
        
    

*   関西
    
    *   大阪
        
    *   兵庫
        
    *   京都
        
    *   滋賀
        
    *   奈良
        
    
*   中国
    
    *   広島
        
    *   岡山
        
    
*   九州
    
    *   福岡
        
    *   佐賀
        
    

*   北海道
    
*   東北
    
    *   宮城
        
    *   福島
        
    *   山形
        
    
*   関東
    
    *   東京
        
    *   神奈川
        
    *   埼玉
        
    *   千葉
        
    *   茨城
        
    *   栃木
        
    *   群馬
        
    
*   東海
    
    *   愛知
        
    *   静岡
        
    *   岐阜
        
    *   三重
        
    

*   関西
    
    *   大阪
        
    *   兵庫
        
    *   京都
        
    *   滋賀
        
    *   奈良
        
    
*   中国
    
    *   広島
        
    *   岡山
        
    
*   九州
    
    *   福岡
        
    *   佐賀
        
    

注意事項
----

お申し込みの前に

NURO 光コースは、サービスの特性上お申し込みにあたってのご注意事項、利用制限事項等がございます。[こちらから規約をご確認](https://www.nuro.jp/hikari/legal/)
の上、お申し込みください。プラン料金が改訂された場合、お支払額も変更されます。(割引額も変更となる可能性があります)

NURO 光 2ギガ提供エリア  
サービス提供エリアは、北海道、東京、神奈川、埼玉、千葉、茨城、栃木、群馬、愛知、静岡、岐阜、三重、大阪、兵庫、京都、滋賀、奈良、広島、岡山、福岡、佐賀 です(一部エリアを除く)。

NURO 光 10ギガ提供エリア  
サービス提供エリアは、北海道、宮城、福島、山形、東京、神奈川、埼玉、千葉、茨城、栃木、群馬、愛知、静岡、岐阜、三重、大阪、兵庫、京都、滋賀、奈良、広島、岡山、福岡、佐賀 です(一部エリアを除く)。

特典について

*   特典は予告なく終了・変更させていただく場合があります。予めご了承ください。
    
*   本ページに記載する新規入会特典以外の他の特典・キャンペーンとの併用はできません。
    
*   弊社によって適用が不適切と判断された場合、特典対象外とさせていただきます。
    
*   お申し込み完了後の特典・キャンペーンの変更はできません。
    
*   新規入会され、お申し込みから12か月後の月末までに開通された方が対象となります。
    
*   お支払方法が未登録の場合、特典をお受け取りいただけない場合がございます。本特典が定める期日までに、ご登録をお願いいたします。
    
*   用紙にて口座振替登録手続を行う場合は登録完了までに1-2か月要する場合があります。特典付与条件の決済登録期限を超過する可能性がある場合、マイページからの決済登録をお願いいたします。
    

ご利用開始について（戸建て）

*   お申し込み後に工事予約を行い、開通工事をもってご利用開始となります。
    
*   お客さま宅へ開通工事日の 1 週間前を目処にWi-Fiルーター（ONU）を配送しますので、必ず工事日までにお受け取りください。
    
*   開通工事完了後、お客さまにて機器の設置をお願いいたします。設置完了後、すぐにインターネットをご利用いただけます。
    

*   開通工事の完了日がNURO 光のご利用開始日=開通月となります。
    
*   機器を接続されない場合も、ご利用料金は発生しますのでご注意ください。
    
*   工事日までに機器をお受け取りいただけない場合も、工事は実施されますのでご注意ください。
    
*   設置方法は同梱の説明書をご覧ください。
    
*   もしもの時はサポート窓口にお問い合わせいただくか、設定サポート（1回無料）をご活用ください。
    

基本工事費実質無料について

「NURO 光 2ギガ（戸建て）」、「NURO 光 10ギガ（戸建て）」の場合：  
基本工事費(49,500円)は開通1か月目から24か月目まで24回の分割となります。  
基本工事費はNURO 光開通月の当月より発生します。なお、特典適用により24か月目までご利用いただけた場合、実質無料となります。  
開通1か月目~24か月目までの基本工事費割賦について:基本工事費割賦として開通1か月目2,074円/月、開通2か月目~24か月目2,062円発生いたしますが、同額を同月のご請求額から割引いたします。

「NURO 光 2ギガ(マンション)」、「NURO 光 10ギガ(マンション)」の場合：  
基本工事費(44,000円)は開通1か月目から24か月目まで24回の分割となります。  
基本工事費はNURO 光開通月の当月より発生します。なお、特典適用により24か月目までご利用いただけた場合、実質無料となります。  
開通1か月目~24か月目までの基本工事費割賦について:基本工事費割賦として開通1か月目1,841円/月、開通2か月目~24か月目1,833円発生いたしますが、同額を同月のご請求額から割引いたします。

※諸条件を満たす場合の工事について

*   解約済のNURO 回線が残置されており、かつ一定の条件を満たす場合は、無派遣工事（お客さまの立ち会い不要）となります。その場合、窓口から工事日調整のご連絡をいたします。
    
*   無派遣工事となった際の基本工事費は9,900 円（1～6 か月目各 1,650 円の分割払い）となりますが、同額を同月のご請求額から割引いたします。
    

解約費用最大2か月0円について

NURO 光のご利用開始月を含む2か月目の末日までに解約された場合、NURO 光 2ギガ（戸建て）、NURO 光 10ギガ（戸建て）、NURO 光 2ギガ(マンション)、NURO 光 10ギガ(マンション)プランの基本工事費残債を無償化いたします。

*   回線撤去をご希望の場合は、別途費用が発生いたします。
    

速度について

「10Gbps」という通信速度は、ネットワークから宅内終端装置へ提供する技術規格上の最大速度です。  
端末機器1台における技術規格上利用可能な最大通信速度は、有線接続(10GBASE-Tポート利用)時で概ね10Gbps、無線接続時で概ね4.8Gbps(NURO 光 10ギガ(戸建て)の場合、弊社が設置する宅内終端装置の機種によっては2.4Gbps)です。  
速度は、お客さまのご利用環境(接続するLANケーブル・HUB等の性能および端末機器の仕様等)や回線混雑状況等により、低下する場合があります。

「2Gbps」という通信速度は、ネットワークから宅内終端装置へ提供する技術規格上の下りの最大速度です。お客さまが使用する個々の端末機器までの通信速度を示すものではありません。  
端末機器1台における技術規格上利用可能な下りの最大通信速度は、以下の通りです。

■NURO 光 2ギガ(戸建て)  
有線接続(1000BASE-T　1ポート利用)時：概ね1Gbps  
無線接続時：概ね1.3Gbps(IEEE802.11acの場合の速度です。弊社が設置する宅内終端装置の機種により対応していない場合があります。)

■NURO 光 2ギガ(マンション)  
有線接続(2.5GBASE-Tポート利用)時：概ね2Gbps  
無線接続時：概ね2Gbps  
速度は、お客さまのご利用環境(接続するLANケーブル・HUB等の性能および端末機器の仕様等)や回線混雑状況等により、低下する場合があります。

開通月の月額基本料金について(戸建て)

開通月の月額基本料金は日割り計算となります。開通の翌月に日割りの月額基本料金\[割引額\]にてご請求させていただきます。

設定サポート1回無料

インターネットやNURO 光 でんわの接続設定、メールソフト設定、セキュリティソフトの設定など、インターネットに関わる設定サポートが無料でご利用いただけます。

レンタルWi-Fiについて

【ご利用料金について】  
レンタルWi-Fiは2つのプランからご選択いただけます。

■最大2か月500円プラン  
ご利用開始月を1か月目とし2か月目までのご利用料金が500円となります。3か月以降は通常料金5,148円(税込)が発生いたします。  
別途、初期費用として事務手数料2,200円が発生いたします。  
ご利用開始月は1か月分の月額基本料金が発生します。日割り計算は行わず、月額基本料金から割引適用した料金をご請求させていただきます。  
3日間における累計の通信データ量が3日間で10GBに達した場合、通信速度を700Kbps以下に制限させて頂きます。  
お一人様1台限りお申し込みいただけます。

■データ通信量完全無制限プラン  
1日目～31日目は4,950 円(税込)、32日目～62日目は159 円/日(税込)、63日目～の176 円/日(税込)の料金が発生いたします。  
受取手数料は、宅配便、コンビニ受取の場合、1台あたり550円(税込)が発生いたします。  
返却手数料は、宅配便の場合、返送料はお客様のご負担、ポスト返却の場合、1台517円(税込)が発生いたします。

【品質/通信速度について】  
本サービスは、ベストエフォート型のサービスです。本サービスに通信速度の記載がある場合であっても、当該記載は実際の通信速度の上限を示すものではなく、接続状況・お客さまが使用するSIMカード・情報通信機器・ネットワーク環境・その他の理由により変化し、通信速度が低下する場合があります。  
通信時間が一定時間を超えるとき、またはその通信容量が一定容量を超えるときは、その通信を制限、もしくは切断することがあります。  
その他オプションサービスにお申し込みいただく場合は別途料金が発生いたします。  
多くのお申し込みをいただいているため、発送が遅れる場合や提供できない場合もございます。発送日、配達日の目安はレンタルWi-Fiをお申し込みの際に専用URLより確認ください。  
本サービスはNURO 光 2ギガ/10ギガ、NURO 光 2ギガ(マンション)/10ギガ(マンション)、にお申し込みいただいた方限定のサービスとなります。サービスに関する詳細はNURO 光お申し込み後のマイページに記載されている専用URLよりご確認ください。  
予告なく終了・変更させていただく場合がございますので予めご了承ください。

光回線再利用でお申し込みの方

光回線再利用でお申し込みの場合は、以下から注意事項をご確認の上お申し込みください。  
[＞お申し込みはこちら](https://www.nuro.jp/hikari/carrier/)

*   戸建て、もしくは2階建て以下の集合住宅の場合のみお申し込み可能です。  
    10ギガプランはお申し込み不可のため、ご注意ください。
    
*   電話窓口限定でのお申し込み受付となっております。
    

解約について

「NURO 光 2ギガ（戸建て）」、「NURO 光 10ギガ（戸建て）」の場合：  
特典適用期間中に解約される場合、解約翌月から特典は適用されません。

解約に伴い発生する費用についての詳細は[こちら](https://www.nuro.jp/hikari/price/rel_price.html)

引越し起因の解約であっても、工事費割賦残債は発生いたします。  
基本工事費(49,500円)は開通1か月目から24か月目まで24回の分割となります。24か月目未満で解約をされる場合は、お支払いいただいていない残債額を一括で請求いたします。

「NURO 光 2ギガ(マンション)」、「NURO 光 10ギガ(マンション)」の場合：  
特典適用期間中に解約される場合、解約翌月から特典は適用されません。

解約に伴い発生する費用についての詳細は[こちら](https://www.nuro.jp/hikari/price/rel_price.html)

引越し起因の解約であっても、工事費割賦残債は発生いたします。  
基本工事費(44,000円)は開通1か月目から24か月目まで24回の分割となります。24か月目未満で解約をされる場合は、お支払いいただいていない残債額を一括で請求いたします。

戸建て向け

*   [料金・スペック](https://www.nuro.jp/hikari/house/price/)
    
*   [オプション](https://www.nuro.jp/hikari/house/option/)
    
*   [ご利用までの流れ](https://www.nuro.jp/hikari/house/flow/)
    

*   よくあるご質問
    
*   [契約をご検討中の方](https://www.nuro.jp/help/)
    
*   [お申し込み済みの方](https://www.nuro.jp/support/?_stcid=e6d9618b1bf7b20d08e2559d8cac18a1.a398171c2c7f42c788b47c5cfac67f4f)
    

*   もっとおトクに
    
*   [お友達紹介クーポン](https://www.nuro.jp/hikari/friend_coupon/)
    
*   [モバイルセット割](https://www.nuro.jp/hikari/campaign/hikarimobileset/)
    

マンション向け

*   [料金・スペック](https://www.nuro.jp/hikari/mansion/price/)
    
*   [オプション](https://www.nuro.jp/hikari/mansion/option/)
    
*   [ご利用までの流れ](https://www.nuro.jp/hikari/mansion/flow/)
    

[管理会社・管理組合・オーナーさまはこちら](https://www.nuro.jp/hikari/mansion/owner/)

*   よくあるご質問
    
*   [契約をご検討中の方](https://www.nuro.jp/help/)
    
*   [お申し込み済みの方](https://www.nuro.jp/support/?_stcid=e6d9618b1bf7b20d08e2559d8cac18a1.a398171c2c7f42c788b47c5cfac67f4f)
    

*   もっとおトクに
    
*   [お友達紹介クーポン](https://www.nuro.jp/hikari/friend_coupon/)
    
*   [モバイルセット割](https://www.nuro.jp/hikari/campaign/hikarimobileset/)
    

*   申込まで安心
    
*   [LINE公式アカウント](https://www.nuro.jp/hikari/line/)
    

*   開通まで安心
    
*   [レンタルWi-Fi](https://www.nuro.jp/hikari/flow_const.html#wifi)
    

*   開通後も安心
    
*   [マイページ](https://www.nuro.jp/app/mypage/?_stcid=e6d9618b1bf7b20d08e2559d8cac18a1.a398171c2c7f42c788b47c5cfac67f4f)
    
*   [NURO会員アプリ](https://www.nuro.jp/hikari/app/)
    
*   [会員サポート](https://www.nuro.jp/support/?_stcid=e6d9618b1bf7b20d08e2559d8cac18a1.a398171c2c7f42c788b47c5cfac67f4f)
    
*   [NURO会員特典](https://www.nuro.jp/member/benefit/)
    
*   [NURO 光のお引越し](https://www.nuro.jp/hikari/campaign/hikkoshi/)
    

*   NURO 光からのお知らせ
    
*   [お知らせ一覧](https://www.nuro.jp/news_release/)
    

*   その他
    
*   [NURO スマートホームスタートプラン](https://www.nuro.jp/hikari/smarthome/)
    
*   [ホームAI「MANOMA」 ![別窓で開く](https://www.nuro.jp/common/assets/images/1.0/icon_new_window.png)](https://manoma.jp/?utm_source=house_nuro&utm_medium=footer_links)
     
*   [入会勧誘トラブルについて ![別窓で開く](https://www.nuro.jp/common/assets/images/1.0/icon_new_window.png)](https://www.nuro.jp/news_release/trouble/160323.html)
     
*   [説明書面一覧](https://www.nuro.jp/Instruction-side/)
    
*   [NURO 光　正規代理店マークについて](https://www.nuro.jp/hikari/agency/mark/)
    

*   販売パートナー
    
*   [![販売パートナー募集](https://www.nuro.jp/hikari/renewal/top/images/partner_banner02.png)](https://www.nuro.jp/hikari/partner/)
    
*   NURO 光のFVNO
    
*   [![FVNO 回線卸 / リブランディング 新規お取り組み募集中！お問い合わせはこちら](https://www.nuro.jp/assets/img/f2k7qp9x/fvno/partner/bn_fvno.png)](https://www.nuro.jp/f2k7qp9x/fvno/partner/)
    

*   販売パートナー
    
*   [![販売パートナー募集](https://www.nuro.jp/hikari/renewal/top/images/partner_banner02.png)](https://www.nuro.jp/help/)
    
*   NURO 光のFVNO
    
*   [![FVNO 回線卸 / リブランディング 新規お取り組み募集中！お問い合わせはこちら](https://www.nuro.jp/assets/img/f2k7qp9x/fvno/partner/bn_fvno.png)](https://www.nuro.jp/f2k7qp9x/fvno/partner/)
    

*   [個人のお客さま\
    \
    NURO 光 20G / NURO Wireless 5G](https://www.nuro.jp/index.html?data-tab=plan01)
    
*   [個人事業主・法人のお客さま](https://www.nuro.jp/hikari/bizguide/)
     
*   [集合住宅オーナーさま\
    \
    NURO 光 Connect](https://www.nuro.jp/index.html?data-tab=plan02)
    

*   [IPv6対応](https://www.nuro.jp/ipv6.html)
    
*   [個人情報保護の取り組み ![別窓で開く](https://www.nuro.jp/common/assets/images/1.0/icon_new_window.png)](http://www.so-net.ne.jp/corporation/safety/)
     
*   [著作権・商標 ![別窓で開く](https://www.nuro.jp/common/assets/images/1.0/icon_new_window.png)](http://www.so-net.ne.jp/siteinfo/copyright.html)
     
*   [ウェブサイトのご利用条件](https://www.nuro.jp/siteinfo/nuro/)
    
*   [So-net ![別窓で開く](https://www.nuro.jp/common/assets/images/1.0/icon_new_window.png)](http://www.so-net.ne.jp/)
     
*   [ソニーネットワークコミュニケーションズ株式会社 ![別窓で開く](https://www.nuro.jp/common/assets/images/1.0/icon_new_window.png)](http://www.so-net.ne.jp/corporation/)
     

電気通信事業者 登録番号:関第94号、代理店届出番号:第C1903019号

*    [![NURO](https://www.nuro.jp/hikari/renewal/common/images/footer_logo-nuro.png) ![別窓で開く](https://www.nuro.jp/common/assets/images/1.0/icon_new_window--white.png)](https://www.sonynetwork.co.jp/corporation/nuro_rebrand2021/)
    
*   © Sony Network Communications Inc.

![閉じる](https://www.nuro.jp/components/assets/img/common/icon_modal_close_btn.svg) ![閉じる](https://www.nuro.jp/components/assets/img/common/icon_modal_close_btn_white.svg)

### 通信速度(Gbps)とは？

「Gbps」という通信速度は、ネットワークから宅内終端装置へ提供する技術規格上の下りの速度です。

![](https://www.nuro.jp/components/assets/img/modal/nuro_illustration_02_pc.png)![](https://www.nuro.jp/components/assets/img/modal/nuro_illustration_02.png)

### 10Gbpsならよりスマホやゲームなど複数端末を同時接続に強い！

1本の光回線を複数デバイスで共有する際は、WANエリアまでの回線容量をデバイスの数で分け合う形になります。

あくまで分かりやすくするための簡易イメージにはなりますが、つまり、NURO 光のようにWANエリアまでの回線容量が2Gbpsであれば、パソコンやスマホ、家族の端末などを仮に4台接続した際に、1台あたりの理論上の通信速度は下り最大0.5Gbpsとなる計算です。

2Gbps÷4台＝0.5Gbps

一方で、WANエリアまでの回線容量が1Gbpsである一般的な光回線の場合、同じ条件で4台の端末を接続すると、1台あたりの理論上の通信速度は下り最大0.25Gbpsとなります。

1Gbps÷4台＝0.25Gbps

NURO 光も他の一般的な光回線もLAN環境下における「1台あたりの下り最大速度」は1Gbpsと変わらないものの、2台以上の端末を同時に接続した場合にその差が大きく出るというわけです。

これが、実測値で2Gbpsが出ていないにもかかわらず、「NURO 光は速い」と多くの方に実感いただいている大きな理由です。

閉じる

![閉じる](https://www.nuro.jp/components/assets/img/common/icon_modal_close_btn.svg) ![閉じる](https://www.nuro.jp/components/assets/img/common/icon_modal_close_btn_white.svg)

### 通信速度に関する注意事項

*   「10Gbps」という通信速度は、ネットワークから宅内終端装置へ提供する技術規格上の最大速度です。
    
*   端末機器1台における技術規格上利用可能な最大通信速度は、有線接続(10GBASE-Tポート利用)時で概ね10Gbps、無線接続時で概ね4.8Gbps(NURO 光 10ギガ（戸建て）の場合、弊社が設置する宅内終端装置の機種によっては2.4Gbps)です。
    
*   速度は、お客さまのご利用環境(接続するLANケーブル・HUB等の性能および端末機器の仕様等)や回線混雑状況等により、低下する場合があります。
    

*   「2Gbps」という通信速度は、ネットワークから宅内終端装置へ提供する技術規格上の下りの最大速度です。お客さまが使用する個々の端末機器までの通信速度を示すものではありません。
    
*   端末機器1台における技術規格上利用可能な下りの最大通信速度は、以下の通りです。
    
    ■NURO 光 2ギガ（戸建て）
    
    *   有線接続(1000BASE-T　1ポート利用)時：概ね1Gbps
        
    *   無線接続時：概ね1.3Gbps(IEEE802.11acの場合の速度です。弊社が設置する宅内終端装置の機種により対応していない場合があります。)
        
    
    ■NURO 光 2ギガ（マンション）
    
    *   有線接続(2.5GBASE-Tポート利用)時：概ね2Gbps
        
    *   無線接続時：概ね2Gbps
        
*   速度は、お客さまのご利用環境(接続するLANケーブル・HUB等の性能および端末機器の仕様等)や回線混雑状況等により、低下する場合があります。
    

閉じる

![閉じる](https://www.nuro.jp/components/assets/img/common/icon_modal_close_btn.svg) ![閉じる](https://www.nuro.jp/components/assets/img/common/icon_modal_close_btn_white.svg)

### 基本工事費実質無料について

「NURO 光 2ギガ（戸建て）」、「NURO 光 10ギガ（戸建て）」の場合：  
基本工事費(49,500円)は開通1か月目から24か月目まで24回の分割となります。  
基本工事費はNURO 光開通月の当月より発生します。なお、特典適用により24か月目までご利用いただけた場合、実質無料となります。  
開通1か月目~24か月目までの基本工事費割賦について:基本工事費割賦として開通1か月目2,074円/月、開通2か月目~24か月目2,062円発生いたしますが、同額を同月のご請求額から割引いたします。

「NURO 光 2ギガ(マンション)」、「NURO 光 10ギガ(マンション)」の場合：  
基本工事費(44,000円)は開通1か月目から24か月目まで24回の分割となります。  
基本工事費はNURO 光開通月の当月より発生します。なお、特典適用により24か月目までご利用いただけた場合、実質無料となります。  
開通1か月目~24か月目までの基本工事費割賦について:基本工事費割賦として開通1か月目1,841円/月、開通2か月目~24か月目1,833円発生いたしますが、同額を同月のご請求額から割引いたします。

※諸条件を満たす場合の工事について

*   解約済のNURO 回線が残置されており、かつ一定の条件を満たす場合は、無派遣工事（お客さまの立ち会い不要）となります。その場合、窓口から工事日調整のご連絡をいたします。
    
*   無派遣工事となった際の基本工事費は9,900 円（1～6 か月目各 1,650 円の分割払い）となりますが、同額を同月のご請求額から割引いたします。
    

#### NURO 光 2ギガ（戸建て）、NURO 光 10ギガ（戸建て）の場合のお支払い例

| 開通月 | 1か月目 | 2～24か月目 | 24か月目～ |
| --- | --- | --- | --- |
| 基本工事費※1 | 2,074円 | 2,062円 | ー   |
| 特典割引 | 工事費相当割引<br><br>\-2,074円 | 工事費相当割引<br><br>\-2,062円 | ー   |
| お支払い工事費 | 0円  | 0円  | ー   |

閉じる

![閉じる](https://www.nuro.jp/components/assets/img/common/icon_modal_close_btn.svg) ![閉じる](https://www.nuro.jp/components/assets/img/common/icon_modal_close_btn_white.svg)

### 設定サポート 1回無料について

インターネットやNURO 光 でんわの接続設定、メールソフト設定、セキュリティソフトの設定など、インターネットに関わる設定サポートが無料でご利用いただけます。

#### 受取・適用期間

有効期限はNURO 光コースの申込月を1か月目として12か月後末日までとなります。

#### 受取・適用方法

マイページ上のWebフォームよりお申し込みください。

*   お申込みはWebフォームからのみの受付となります。
    
*   専用Webフォームはお申込み手続き後マイページにてご確認いただけます。
    

#### 受取・適用条件

以下をご確認いただきお申し込みください。

*   NURO 光コースの宅内、屋外工事日が確定していること
    
*   お客さま番号とNURO マイページ ログインID、ログインパスワード（『契約内容のご案内』に記載）のご準備
    
*   「ひかりTV for NURO」の設定をご希望の方はエントリーコードのご準備
    
*   設定サポートに必要な機器類・部材・ソフトのご準備
    
*   設定サポートサービス[ご利用規約](https://www.nuro.jp/r/option/support?_stcid=e6d9618b1bf7b20d08e2559d8cac18a1.a398171c2c7f42c788b47c5cfac67f4f)
    への同意
    
*   *   お申込をいただいた際、同規約に同意いただいたものといたします。
        

以下の場合、本特典の権利失効対象となり、再訪問をご希望の場合は再訪問保証料として5,500円(税込)を頂戴いたします。

*   設定対応日は回線開通工事日の翌日以降とさせていただきます。設定対応日を工事日同日に設定され、工事の遅延などにより開始予定時間から30分以内に作業を開始できなかった場合。
    
*   スタッフが設定対応時、機器の故障、付属品の不足、工事の遅延やお客さま不在など、回線事業者またはお客さまの都合で作業が開始できなかった場合。
    
*   設定対応当日に日時変更される場合。(日時変更は設定対応日前日の18時までに「0120-535-099」へお電話ください。)
    

#### 注意事項等

*   接続設定は、ゲーム機／インターネット対応テレビ／タブレット端末それぞれ1台をPC1台とみなして設定を行うことができます(PCやインターネットの基本操作指導、PCのトラブル診断やウイルス駆除等は含まれません)。
    
*   サポート対象OSは、日本語版、かつ、マイクロソフト、アップルまたはグーグルがサポートしている範囲内となります。
    
*   対象OS以外のPCおよび上記対象OS以外に関わる周辺機器・ソフトウェア・サービス等は設定サポートの対象外となります。
    
*   サポート対象OSへの対応表明がされていない周辺機器・ソフトウェア・サービス等の設定サポートをご希望の場合、ご希望に添えない場合がございます。
    
*   設定を行うWebブラウザ 、電子メールソフトはOS に標準搭載のソフトになります。標準搭載以外の設定をご希望の場合は、サポートスタッフまたは作業スタッフにお問い合わせください。
    
*   「ひかりTV for NURO」の視聴設定をご希望の場合、株式会社NTTドコモの動作確認がされていない機器は、設定対応が完了できない場合がございます。また、動作保障についてもいたしかねます。
    
*   「NURO 光 でんわ」の接続設定は、お客さまの電話機と工事業者が持参したIP電話機器との配線を作業範囲とします。
    
*   セキュリティサービスの設定をご希望の場合、対象外のOSもございます。
    
*   回線に関わる専用機器は回線事業者が動作保証したものを対象とさせていただきます。
    
*   お客様番号、NURO マイページログインID、ログインパスワードは「契約内容のご案内」に記載があります。
    
*   外国語での設定サポート、マルチブートマシンへの設定作業、室内の配線工事、リモートサポート（お客さまのパソコンを遠隔で操作）には対応しておりません。
    
*   訪問するエリア(一部離島)によっては、別途交通費等を申し受ける場合がございます。
    
*   データの保証は致しかねます。必要なデータは作業前までにお客さまご自身でバックアップを行ってください。
    
*   「設定サポートサービス」は、ソニーネットワークコミュニケーションズ株式会社からの業務委託により日本PCサービス株式会社が実施・運営しております。
    

閉じる

![閉じる](https://www.nuro.jp/components/assets/img/common/icon_modal_close_btn.svg) ![閉じる](https://www.nuro.jp/components/assets/img/common/icon_modal_close_btn_white.svg)

### 解約費用最大2か月0円について

NURO 光のご利用開始月を含む2か月目の末日までに解約された場合、NURO 光 2ギガ（戸建て）、NURO 光 10ギガ（戸建て）、NURO 光 2ギガ(マンション)、NURO 光 10ギガ(マンション)プランの基本工事費残債を無償化いたします。

*   回線撤去をご希望の場合は、別途費用が発生いたします。
    

閉じる

![閉じる](https://www.nuro.jp/components/assets/img/common/icon_modal_close_btn.svg) ![閉じる](https://www.nuro.jp/components/assets/img/common/icon_modal_close_btn_white.svg)

口座振替でお支払いの場合はご請求毎に220円の決済事務手数料が発生いたします。  
また、お申込み後にマイページから口座振替登録がお済みでない場合はコンビニ払込票でのお支払いとなり、ご請求毎に330円の払込票発行料が発生いたします。

閉じる

![閉じる](https://www.nuro.jp/hikari/guideline/images/modal_close_btn.png) ![閉じる](https://www.nuro.jp/hikari/guideline/images/modal_close_btn_black.png)

期間限定！最大20,000円キャッシュバックキャンペーン実施中12/7まで
-------------------------------------

![期間限定！最大20,000円キャッシュバックキャンペーン実施中](https://www.nuro.jp/hikari/)![期間限定！最大20,000円キャッシュバックキャンペーン実施中](https://www.nuro.jp/hikari/)

キャンペーン内容

*   ＜キャッシュバックキャンペーン＞
    
    | プラン(速度) | 10ギガ | 2ギガ |
    | --- | --- | --- |
    | キャッシュバック | 20,000円 | 10,000円 |
    
*   キャンペーンは予告なく終了・変更させていただく場合があります。予めご了承ください。
    
*   キャンペーンの適用に関しては、各種諸条件があります。お申し込み前に注意事項をご確認ください。
    

キャンペーン適用条件

*   キャンペーン期間内に対象の特典に申し込みいただき、12か月後の月末までにNURO 光が開通された方、かつお支払い方法の登録がお済みの方
    
*   対象特典  
    \[戸建て\]３ねん定額割、U29応援割  
    \[マンション\]２ねん定額割、U29応援割
    
    ・キャッシュバックのお受け取りまで、NURO 光を継続してご利用された方
    

キャッシュバック受け取りのタイミング

*   ご利用開始から17か月後にキャッシュバックいたします。
    

注意事項

キャッシュバックのお受取手続きについて

開通17か月後（例：本年1月5日に開通した方は翌年6月5日）にキャッシュバックのお受取手続きご案内メールをお申し込み時にご登録いただきましたメールアドレス宛にお送りします。ご案内メールの内容に沿って、マイページより、受取口座をご指定ください。

案内メール配信に関する注意事項

ご利用開始16か月後の末日までにお支払い方法（決済情報）と連絡先メールアドレスをご登録いただいていないお客さまには、ご案内メールが配信されませんので、ご注意ください。

キャッシュバックお受け取り対象

キャッシュバックのお受取りが可能になるまで、NURO 光を継続してご利用ください。キャッシュバックのお受取り前にコースの変更や退会された場合は対象外となります。

キャッシュバック受取手続き期間

キャッシュバック受取手続き期間は45日間です。期間内にお手続きいただけなかった場合、無効となりますのでご注意ください。

消費税率変更に伴う、キャッシュバック金額について

消費税率が変更されてもキャッシュバック金額の変更はございません。

お申し込み特典の適用に関して

本キャンペーン対象のお申し込み特典の適用に関しては各種諸条件があります。詳しくは各お申し込み特典のページをご確認ください。

NURO 光の開通工事の遅延によるキャンペーン・特典の適用条件について

NURO光の開通工事の遅延により、お申し込みいただいたキャンペーン・特典の適用条件として定められている開通期限を超えてしまった場合につきましては、キャンペーン・特典の適用対象外に至った理由が、お客さまに起因するものではないと弊社が判断した場合、キャンペーン・特典に関する開通期限の延長対応を行わせていただきます。

閉じる

![閉じる](https://www.nuro.jp/components/assets/img/common/icon_modal_close_btn.svg) ![閉じる](https://www.nuro.jp/components/assets/img/common/icon_modal_close_btn_white.svg)

![NURO光開通までの期間も安心 レンタルWi-Fi](https://www.nuro.jp/components/assets/img/modal/kv_rental_wifi_pc.png)![NURO光開通までの期間も安心 レンタルWi-Fi](https://www.nuro.jp/components/assets/img/modal/kv_rental_wifi_sp.png)

### 選べる2タイプ

*   最大2か月500円
    
    ![最大2か月500円](https://www.nuro.jp/common/images/wifi-recommend/img_card01.png)
    
    |     |     |
    | --- | --- |
    | 月間通信量 | **制限なし ※** |
    | 月額  | **500円～** |
    
    *   当日を含む3日間の合計データ通信量が、規定値（10GB）を超えた場合、通信速度を制限させていただきます。
        
    
*   データ通信量完全無制限
    
    ![データ通信量完全無制限](https://www.nuro.jp/common/images/wifi-recommend/img_card02.png)
    
    |     |     |
    | --- | --- |
    | 月間通信量 | **制限なし** |
    | 月額  | **4,950円〜** |
    

NURO 光にお申し込みなら、すぐに使えるレンタルWi-Fiをお得な料金でご利用いただけます。

ご利用料金について

レンタルWi-Fiは2つのプランからご選択いただけます。

*   **最大2か月500円**  
    ご利用開始月を1か月目とし2か月目までのご利用料金が500円となります。3か月以降は通常料金5,148円(税込)が発生いたします。  
    ※別途、初期費用として事務手数料2,200円が発生いたします。  
    ※ご利用開始月は1か月分の月額基本料金が発生します。日割り計算は行わず、月額基本料金から割引適用した料金をご請求させていただきます。  
    3日間における累計の通信データ量が3日間で10GBに達した場合、通信速度を700Kbps以下に制限させて頂きます。  
    お一人様1台限りお申し込みいただけます。
    
*   **データ通信量完全無制限プラン**  
    1日目～31日目は4,950 円(税込)、32日目～62日目は159 円/日(税込)、63日目～の176 円/日(税込)の料金が発生いたします。  
    受取手数料は、宅配便、コンビニ受取の場合、1台あたり550円（税込）が発生いたします。  
    返却手数料は、宅配便の場合、返送料はお客様のご負担、ポスト返却の場合、1台517円（税込）が発生いたします。
    

品質/通信速度について

*   本サービスは、ベストエフォート型のサービスです。本サービスに通信速度の記載がある場合であっても、当該記載は実際の通信速度の上限を示すものではなく、接続状況・お客さまが使用するSIMカード・情報通信機器・ネットワーク環境・その他の理由により変化し、通信速度が低下する場合があります。
    
*   通信時間が一定時間を超えるとき、またはその通信容量が一定容量を超えるときは、その通信を制限、もしくは切断することがあります。
    
*   その他オプションサービスにお申し込みいただく場合は別途料金が発生いたします。
    
*   予告なく終了・変更させていただく場合がございますので予めご了承ください。
    
*   ご解約後に貸し出し機器（付属品含む）を返却いただけない場合は機器損害金が発生いたします。
    
*   多くのお申し込みをいただいているため、発送が遅れる場合や提供できない場合もございます。
    
*   NURO 光 2ギガ/10ギガ、NURO 光 2ギガ/10ギガ(マンション)にお申し込みいただいた方限定のサービスとなります。サービスに関する詳細はNURO 光お申し込み後のマイページに記載されている専用URLよりご確認ください。
    
*   NURO 光お申し込み完了メールは、NURO 光お申し込み時にご登録いただく連絡先メールアドレス宛にお送りいたします。
    

**ご利用までの流れ**

*   お申し込みURLにアクセス
    
    NURO 光お申し込み後の「お申し込み完了メール」もしくは「マイページ」に記載されているレンタルWi-fiお申し込みURLからアクセス  
    ※マンション タイプLをお申し込みの方はマイページのみのURL記載になります。
    
    **＜マイページからのURL確認方法＞**  
    マイページにログイン後、「特典・キャンペーン」＞「詳細を確認する」＞「キャンペーン内容」よりご確認いただけます。
    
*   お申し込み
    
    レンタルWi-Fiお申し込みページでお申し込み
    
*   お届け・ご利用開始
    
    4日程度でお届け！
    

**よくあるご質問**

クレジットカード以外の支払い方法は選択できますか？

お支払いはクレジットカードのみになります。ご利用できるカードはVISA、Master、JCB、Diners、American Expressの5ブランドで、国内発行のクレジットカードがご利用いただけます。

解約料はかかりますか？

解約金、違約金はかかりません。解約月の月額費用は満額発生いたします。

SIMカードはどこにありますか？

SIMカードはレンタルWi-Fi機器に差し込み済です。なお、返却時にSIMカードも返却が必要です。SIMカードをレンタルWi-Fi機器から外さないようお願いいたします。

機器到着日はいつになりますか？

レンタルWi-Fi（最大2か月500円）は、お申し込み日より最短4日後から指定可能です。

課金開始日はいつからとなりますか？

機器をお受け取りになった日が利用開始日（課金開始日）となります。

プラン別で利用料金はどうかわりますか？

*   **最大2か月500円**
    
*   *   ご利用開始月を1か月目とし2か月目までのご利用料金が500円となります。3か月以降は通常料金5,148円(税込)が発生いたします。  
        ※別途、初期費用として事務手数料2,200円が発生いたします。  
        ※ご利用開始月は1か月分の月額基本料金が発生します。日割り計算は行わず、月額基本料金から割引適用した料金をご請求させていただきます。
        

*   **データ通信量完全無制限プラン**
    
*   *   1日目～31日目は4,950 円(税込)、32日目～62日目は159 円/日(税込)、63日目～の176 円/日(税込)の料金が発生いたします。
        
    *   受取手数料は、宅配便、コンビニ受取の場合、1台あたり550円（税込）が発生いたします。
        
    *   返却手数料は、宅配便の場合、返送料はお客様のご負担、ポスト返却の場合、1台517円（税込）が発生いたします。
        

閉じる

![閉じる](https://www.nuro.jp/components/assets/img/common/icon_modal_close_btn.svg) ![閉じる](https://www.nuro.jp/components/assets/img/common/icon_modal_close_btn_white.svg)

### お申し込みの前に住宅タイプを確認

住宅の形状に応じて工事内容が異なるため、誤った住宅タイプを選択されると再申し込みが必要となり開通までにお時間がかかります。正しい住宅タイプをご選択ください。

*   お申し込みされるお住まいが、NURO 光で定義する「戸建住宅」に該当しない場合、住宅タイプは「集合住宅」となります。
    

戸建住宅 集合住宅

#### NURO 光での「戸建住宅」の定義

*   ![一戸一世帯の独立している建物](https://www.nuro.jp/components/assets/img/common/houseType01.png)
    
    一戸一世帯の独立している建物
    
*   ![建物内が一部共有型の二世帯住宅](https://www.nuro.jp/components/assets/img/common/houseType02.png)
    
    建物内が一部共有型の二世帯住宅
    
    内扉がある一部共有型の二世帯住宅が該当します。  
    三世帯以上の場合も含みます。
    
    *   完全分離型の二世帯住宅の住宅タイプは「集合住宅」となります。
        
    
*   ![店舗兼住宅（一店舗一住宅）](https://www.nuro.jp/components/assets/img/common/houseType03.png)
    
    店舗兼住宅（一店舗一住宅）
    
    住宅にはオーナー世帯のみ居住している場合のみです。
    
    *   店舗以外に賃貸等で他居住者がいない場合、住宅タイプは「戸建住宅」、他居住者がいる場合、住宅タイプは「集合住宅」になります。
        
    

#### NURO 光での「集合住宅」の定義

*   ![一つの建物の中に複数の住戸が集まっている住宅](https://www.nuro.jp/components/assets/img/common/houseType_mansion01.png)
    
    一つの建物の中に複数の住戸が集まっている住宅
    
    *   マンション・アパート・シェアハウス含む
        
    
*   ![建物内が完全分離型の二世帯住宅](https://www.nuro.jp/components/assets/img/common/houseType_mansion02.png)
    
    建物内が完全分離型の二世帯住宅
    
    内扉がない完全分離型の二世帯住宅が該当します。  
    三世帯以上の場合も含みます。
    
    *   一部共有型の二世帯住宅の住宅タイプは「戸建住宅」となります。
        
    
*   ![店舗兼住宅](https://www.nuro.jp/components/assets/img/common/houseType_mansion03.png)
    
    店舗兼住宅
    
    住宅にはオーナー世帯以外の世帯も居住している建物です。
    
    *   店舗以外に賃貸等で他居住者がいない場合、住宅タイプは「戸建住宅」、他居住者がいる場合、住宅タイプは「集合住宅」になります。
        
    
*   ![メゾネット・テラスハウス（長屋含む）](https://www.nuro.jp/components/assets/img/common/houseType_mansion04.png)
    
    メゾネット・テラスハウス（長屋含む）
    
    |     |     |
    | --- | --- |
    | メゾネット | 集合住宅の一住戸の中に2階層以上の間取りをもつ住宅 |
    | テラスハウス | 隣の住居と境界部分の壁を共有している複数の建物が連なった形式の住宅 |
    

閉じる

![閉じる](https://www.nuro.jp/components/assets/img/common/icon_modal_close_btn.svg) ![閉じる](https://www.nuro.jp/components/assets/img/common/icon_modal_close_btn_white.svg)

NURO 光は、国際的分析機関であるOpensignal社が2025年7月に発表した日本市場全体の有線接続ユーザーを対象とした分析結果で、回線の利用で重要な「ダウンロード・スピード」「アップロード・スピード」「信頼性エクスペリエンス」などの4部門でNo.1を受賞しています。

日本の5都市（札幌、東京、横浜など）を対象とした分析結果において、25の賞のうち6つの賞を1位、14の賞を共同受賞。国内通信サービスの中で最多受賞となっています。

*   Opensignal社「固定ブロードバンド・エクスペリエンス」2025年7月  
    [https://www.opensignal.com/reports/2025/07/japan/fixed-broadband-experience](https://www.opensignal.com/reports/2025/07/japan/fixed-broadband-experience)
    
*   「信頼性エクスペリエンス」…一般家庭で安定してインターネットに接続し、動画のストリーミング・閲覧などのタスクをどれだけ正常に完了できるかを測定する指標
    

![](https://www.nuro.jp/assets/img/share_opensignal/ranking.jpg?v=9c7213169d)

閉じる

![閉じる](https://www.nuro.jp/components/assets/img/common/icon_modal_close_btn.svg) ![閉じる](https://www.nuro.jp/components/assets/img/common/icon_modal_close_btn_white.svg)

### 乗り換え特典について

特典内容

*   NURO 光へお乗り換え前にご利用されていた光回線・家庭用Wi-Fi・ホームルーター・モバイルルーター等の解約時に発生する解約違約金・工事費残債額、機器残債の費用について最大30,000円までキャッシュバックいたします。
    

対象となる費用（いずれか1回線分）

*   固定ブロードバンド回線の場合
    
*   *   解約違約金、契約解除料
        
    *   工事費残債額
        
    *   撤去工事費
        
    *   回線解約に伴い必要となったテレビアンテナ設置費用
        
*   モバイルブロードバンド回線（ホームルーター含む）の場合
    
*   *   解約違約金
        
    *   機器/端末残債（家庭用Wi-Fi/ホームルーター、モバイルルーター）
        
*   対象外（一例）
    
*   *   解約月の月額料金
        
    *   オプションサービスの解約違約金
        
    *   携帯電話、タブレットなどの解約違約金
        
    *   NURO 光の解約にかかる費用
        

お受け取りの流れ

*   NURO 光のご利用開始後に送付されるシートへ必要事項のご記入と必要書類を貼付の上、所定の期日までに当社指定封筒にてご返送いただきます。
    
*   当社でシートの確認後不備がなければ、NUROマイページで後日ご登録いただく銀行口座でキャッシュバックをお受け取りいただけます。
    
*   詳細な時期や期日は以下の通りです。
    
*   *   STEP1：NURO 光のご利用開始を1か月目として5～7か月目末日までにシート（名称：解約違約金証明書貼付シート）を発送いたします。
        
    *   STEP2：シートへ必要事項をご記入いただき、「対象となる費用」の証明書類またはWEB画面のコピーを貼付の上、シート発送から2か月後の末日(必着)までに、当社指定の封筒にてご返送ください。
        
    *   STEP3：当社でシート確認後不備がなければ、シートを受領した日から45日以内に、ご登録いただきましたメールアドレス宛に特典受取のご案内をいたします。
        
    *   STEP4：ご案内後から45日以内にNUROマイページよりお受け取り口座をご指定ください。お手続き後に、ご登録のメールアドレス宛にお手続き結果メールをお送りします。
        

適用対象

*   対象の特典に申し込みいただき、12か月後の月末までにNURO 光が開通された方、かつお支払い方法の登録がお済みの方。
    
*   NURO 光のご利用開始から6か月後の末日までに連絡先メールアドレスのご登録を完了された方。
    
*   キャッシュバックのお受け取りまで、NURO 光を継続してご利用された方。
    
*   証明書類の「ご契約者さま」とNURO 光の「お申し込み者さま」が同一であることが必要です。 契約者さまご本人以外の場合、ご契約者さまとお申し込み者さまの苗字が同一であることが必須です。
    
*   対象サービスお申し込みにあたっての他社サービス解約で発生する費用に限ります。
    
*   お乗り換え前に複数の固定ブロードバンド回線またはモバイルブロードバンドのご契約があった場合でも、1回線分のみの合計金額が対象となります。
    

証明書類について

*   対象となる費用の証明書類が複数枚に分かれている場合、全ての証明書類をシートに貼付し1通で送付いただきます。
    
*   書類に不備があった場合は特典対象外となります。
    
*   シートご返送前にコピーをお取りいただき、ご申告された金額の控えをお手元に残していただきますようお願いいたします。
    
*   『証明書類』は、お乗り換え前の固定ブロードバンド回線及びテレビアンテナ工事会社または、モバイルブロードバンド提供事業者が発行したもので、『サービス名』と『ご契約者さま名もしくはお申し込み者さま名』と『対象情報（『解約違約金』『工事費残債額』『テレビアンテナ設置費用』『モバイルルータの機器残債額』等）の項目名と金額』が表記されたものが必須です。証明書類の紙の発行がなく、会員サイトよりご利用料金を閲覧されているお客さまは、前述の必須項目が記載されたWEB画面のコピーが必須です。
    

注意事項

*   『解約違約金証明書貼付シート』には還元金額を必ずご記入いただきます。記載のない場合は、本特典適用外となります。
    
*   ご記入の金額に適用対象外の金額が含まれている場合は、その分を差し引いた金額となります。
    
*   『解約違約金証明書貼付シート』による本特典へのお申し込みは、1回限り有効です。複数回お申し込みの場合は、初回お申し込みの内容で受付いたします。
    
*   機器/端末費用は、残債のある場合のみ対象です。割賦支払いを完了している場合は対象外です。
    
*   本内容はNURO 光公式サイトでお申し込みいただく「乗り換え特典：最大30,000円」の内容です。別のお申し込み先や特典では異なる場合があります。
    
*   『解約違約金証明書貼付シート』にご記入された内容は本特典の処理のみに利用いたします。お客さまの許可なく、そのほかの目的に使用いたしません。対応完了後、本件に関わる個人情報は消去いたします。
    

閉じる

 ![閉じる](https://www.nuro.jp/components/assets/img/common/icon_modal_close_btn.svg?v=ab993c440a)![閉じる](https://www.nuro.jp/components/assets/img/common/icon_modal_close_btn_white.svg?v=c0c74468d3)

### タイプについて

マンションによって、お申し込みいただけるタイプが異なります。

どちらのタイプでも、基本的なサービス内容に違いはありません。

*   お客さまによるタイプの選択はできません。
    
*   工事方法／お支払い方法／提供オプション等の一部が異なります。
    
    *   工事方法…タイプS：宅内・屋外工事、タイプL：宅内工事のみ
        
    *   お支払い方法…タイプL：口座振替不可
        
*   10ギガプランの提供エリアは異なります。
    

### タイプの確認方法

[こちらのページ](https://www.nuro.jp/hikari/?#applyArea)
の「お申し込み」ボタンから住所入力するとご確認いただけます。

![](https://www.nuro.jp/hikari/mansion/common/img/img_screen01.png?v=a878819cfc)

閉じる

 ![閉じる](https://www.nuro.jp/components/assets/img/common/icon_modal_close_btn.svg?v=ab993c440a)![閉じる](https://www.nuro.jp/components/assets/img/common/icon_modal_close_btn_white.svg?v=c0c74468d3)

### 開通期間目安に関する注意事項

*   中国エリア、東北エリアは工事状況により、さらに1～2か月お時間をいただく場合がございます。お住まいの環境によっては、光ファイバーの提供準備における大規模な工事や申請等が必要となり、お申し込みから開通までに通常よりも更にお時間を要する場合や提供できない場合がございます。
    
*   タイプLの場合：設備状況や周辺事情などにより、ご提供までにさらに期間を要する場合や、ご提供できない場合があります。物件へ導入された設備によっては、複数回の工事が必要な場合があります。
    

閉じる

![](https://event-va1.pubmatic.com/?adv=26162&cb=1764896633466&ref=https%3A%2F%2Fwww.nuro.jp%2Fhikari%2F&page=https%3A%2F%2Fwww.nuro.jp%2Fhikari%2F&order_id={{order_id}}&item_count={{item_count}}&value={{value}}&gdpr_consent=${GDPR_CONSENT_76}&gdpr=${GDPR}&us_privacy=${US_PRIVACY})             

![](https://bat.bing.com/action/0?ti=97114800&Ver=2&mid=4301cc15-59a6-448e-b0d3-2a6a444d714f&bo=1&sid=458c5120d17611f0b3f97d5de59d77bd&vid=458c71a0d17611f097d7131b93bcafe5&vids=1&msclkid=N&uach=pv%3D10.0&pi=0&lg=en-US@posix&sw=1280&sh=800&sc=24&nwd=1&tl=%E3%80%90%E5%85%AC%E5%BC%8F%E3%80%91%E5%85%89%E5%9B%9E%E7%B7%9A%E3%82%A4%E3%83%B3%E3%82%BF%E3%83%BC%E3%83%8D%E3%83%83%E3%83%88%E3%82%B5%E3%83%BC%E3%83%93%E3%82%B9%EF%BD%9C%E6%9C%9F%E9%96%93%E9%99%90%E5%AE%9A%E3%82%AD%E3%83%A3%E3%83%B3%E3%83%9A%E3%83%BC%E3%83%B3%E5%AE%9F%E6%96%BD%E4%B8%AD%EF%BC%81NURO%20%E5%85%89&kw=NURO,%E3%83%8C%E3%83%AD,%E3%83%8B%E3%83%A5%E3%83%BC%E3%83%AD,%E9%AB%98%E9%80%9F,%E5%85%89%E3%83%95%E3%82%A1%E3%82%A4%E3%83%90%E3%83%BC,%E3%83%96%E3%83%AD%E3%83%BC%E3%83%89%E3%83%90%E3%83%B3%E3%83%89,%E3%82%A4%E3%83%B3%E3%82%BF%E3%83%BC%E3%83%8D%E3%83%83%E3%83%88%E6%8E%A5%E7%B6%9A,So-net,%E3%82%BD%E3%83%8D%E3%83%83%E3%83%88,SonyNetworkCommunications,%E3%82%BD%E3%83%8B%E3%83%BC%E3%83%8D%E3%83%83%E3%83%88%E3%83%AF%E3%83%BC%E3%82%AF%E3%82%B3%E3%83%9F%E3%83%A5%E3%83%8B%E3%82%B1%E3%83%BC%E3%82%B7%E3%83%A7%E3%83%B3%E3%82%BA&p=https%3A%2F%2Fwww.nuro.jp%2Fhikari%2F&r=&lt=2985&evt=pageLoad&sv=2&cdb=AQAQ&rn=993608)

![](https://bat.bing.com/action/0?ti=343048056&Ver=2&mid=e3af0669-c460-44ac-ada5-c15cf90b15f7&bo=1&sid=458c5120d17611f0b3f97d5de59d77bd&vid=458c71a0d17611f097d7131b93bcafe5&vids=0&msclkid=N&uach=pv%3D10.0&pi=0&lg=en-US@posix&sw=1280&sh=800&sc=24&nwd=1&tl=%E3%80%90%E5%85%AC%E5%BC%8F%E3%80%91%E5%85%89%E5%9B%9E%E7%B7%9A%E3%82%A4%E3%83%B3%E3%82%BF%E3%83%BC%E3%83%8D%E3%83%83%E3%83%88%E3%82%B5%E3%83%BC%E3%83%93%E3%82%B9%EF%BD%9C%E6%9C%9F%E9%96%93%E9%99%90%E5%AE%9A%E3%82%AD%E3%83%A3%E3%83%B3%E3%83%9A%E3%83%BC%E3%83%B3%E5%AE%9F%E6%96%BD%E4%B8%AD%EF%BC%81NURO%20%E5%85%89&kw=NURO,%E3%83%8C%E3%83%AD,%E3%83%8B%E3%83%A5%E3%83%BC%E3%83%AD,%E9%AB%98%E9%80%9F,%E5%85%89%E3%83%95%E3%82%A1%E3%82%A4%E3%83%90%E3%83%BC,%E3%83%96%E3%83%AD%E3%83%BC%E3%83%89%E3%83%90%E3%83%B3%E3%83%89,%E3%82%A4%E3%83%B3%E3%82%BF%E3%83%BC%E3%83%8D%E3%83%83%E3%83%88%E6%8E%A5%E7%B6%9A,So-net,%E3%82%BD%E3%83%8D%E3%83%83%E3%83%88,SonyNetworkCommunications,%E3%82%BD%E3%83%8B%E3%83%BC%E3%83%8D%E3%83%83%E3%83%88%E3%83%AF%E3%83%BC%E3%82%AF%E3%82%B3%E3%83%9F%E3%83%A5%E3%83%8B%E3%82%B1%E3%83%BC%E3%82%B7%E3%83%A7%E3%83%B3%E3%82%BA&p=https%3A%2F%2Fwww.nuro.jp%2Fhikari%2F&r=&lt=2985&evt=pageLoad&sv=2&cdb=AQAQ&rn=644882)

![](https://bat.bing.com/action/0?ti=343062041&Ver=2&mid=59f85ace-d39a-4aba-8550-901347929296&bo=1&sid=458c5120d17611f0b3f97d5de59d77bd&vid=458c71a0d17611f097d7131b93bcafe5&vids=0&msclkid=N&uach=pv%3D10.0&pi=0&lg=en-US@posix&sw=1280&sh=800&sc=24&nwd=1&tl=%E3%80%90%E5%85%AC%E5%BC%8F%E3%80%91%E5%85%89%E5%9B%9E%E7%B7%9A%E3%82%A4%E3%83%B3%E3%82%BF%E3%83%BC%E3%83%8D%E3%83%83%E3%83%88%E3%82%B5%E3%83%BC%E3%83%93%E3%82%B9%EF%BD%9C%E6%9C%9F%E9%96%93%E9%99%90%E5%AE%9A%E3%82%AD%E3%83%A3%E3%83%B3%E3%83%9A%E3%83%BC%E3%83%B3%E5%AE%9F%E6%96%BD%E4%B8%AD%EF%BC%81NURO%20%E5%85%89&kw=NURO,%E3%83%8C%E3%83%AD,%E3%83%8B%E3%83%A5%E3%83%BC%E3%83%AD,%E9%AB%98%E9%80%9F,%E5%85%89%E3%83%95%E3%82%A1%E3%82%A4%E3%83%90%E3%83%BC,%E3%83%96%E3%83%AD%E3%83%BC%E3%83%89%E3%83%90%E3%83%B3%E3%83%89,%E3%82%A4%E3%83%B3%E3%82%BF%E3%83%BC%E3%83%8D%E3%83%83%E3%83%88%E6%8E%A5%E7%B6%9A,So-net,%E3%82%BD%E3%83%8D%E3%83%83%E3%83%88,SonyNetworkCommunications,%E3%82%BD%E3%83%8B%E3%83%BC%E3%83%8D%E3%83%83%E3%83%88%E3%83%AF%E3%83%BC%E3%82%AF%E3%82%B3%E3%83%9F%E3%83%A5%E3%83%8B%E3%82%B1%E3%83%BC%E3%82%B7%E3%83%A7%E3%83%B3%E3%82%BA&p=https%3A%2F%2Fwww.nuro.jp%2Fhikari%2F&r=&lt=2985&evt=pageLoad&sv=2&cdb=AQAQ&rn=982497)

▼ 新しいメッセージがあります

[](http://www.showtalk.jp/)
[コンシェル呼び出し](https://www.nuro.jp/)

送 信

応対品質の向上のため 簡単なアンケートにご協力お願いいたします。

チャットにより疑問は解決できましたか？

すべて解決できた

だいたい解決できた

あまり解決できなかった

まったく解決できなかった

チャットの対応は満足いただけましたか？

非常に満足

やや満足

やや不満

非常に不満

ホームページにどのような情報があれば、チャットを使わずに済みましたか？（複数選択可）

プラン・料金の比較がわかりやすい

提供エリアがすぐに確認できる

工事の内容について詳しく書いてある

申し込みから開通までの流れが詳しく説明されている

キャッシュバックやキャンペーンの条件・内容がわかりやすい

オプションサービスの料金や内容がわかりやすい

用語の説明があったりして理解しやすい

申し込み画面でスムーズに入力ができる

FAQが見やすく整理されている

その他

チャットでは、どんな情報を期待していましたか？（複数選択可）

自分に合ったプランや料金について

提供エリアについて

工事の日程や流れについて

申し込み手順について

キャンペーンや特典について

オプションなどの詳細

他社との違いやメリットについて

単に話を聞きながら検討したかった

その他

NURO 光に「これがあれば申し込みたい！」と思える要素は何ですか？（複数選択可）

月額基本料金の安さ（割引特典含む）

回線速度の速さ・安定性

工事費が実質無料であること

工事日の調整が簡単で早いこと

オプション同時申し込みで特典があること

一定期間お試しができること

NUROモバイルセット割引があること

開通までWi-Fiレンタルが使えること

ソニー製ONUが使えること

申し込み手続きが簡単であること

サポートがしっかりしていること

口コミ

その他

比較中の他社があれば教えてください。（複数選択可）

ソフトバンク光

So-net 光

楽天ひかり

auひかり

BIGLOBE光

ドコモ光

GMOとくとくBB

SoftBank Air

ホームルーター・モバイルルーター

その他

お申し込みにあたって、お悩みがあれば教えてください。（複数選択可）

料金に不満がある

実際に支払う金額が分かりにくい

回線品質が気になる

開通時期に不安がある

工事内容に不安がある

建物所有者の許可が必要

エリア外のため申込できない

他社と比べてメリットが分からない

利用したい機能がない

その他

送　信

　

![#](https://www.nuro.jp/hikari/)

チャットで質問

![](https://ib.adnxs.com/setuid?entity=315&code=pLstc11WyAX1pzgvW6cSXwSNQBgdJyoJEU3g5pwEM1s&consent=1)![](https://aw.dw.impact-ad.jp/ut/rep?u=4934&v=1&r=https%3A%2F%2Fwww.nuro.jp%2Fhikari%2F&t=1741)
