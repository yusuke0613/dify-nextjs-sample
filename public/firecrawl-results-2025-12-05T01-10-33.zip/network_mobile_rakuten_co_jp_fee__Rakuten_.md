# Rakuten最強プラン（料金プラン） | 楽天モバイル

URL: https://network.mobile.rakuten.co.jp/fee/

---

![](https://secure.rat.rakuten.co.jp/?cpkg_none=%7B%22acc%22%3A1312%2C%22aid%22%3A1%2C%22bid%22%3A%221764896690704c41bebf4%22%2C%22url%22%3A%22https%3A%2F%2Fnetwork.mobile.rakuten.co.jp%2Ffee%2Fsaikyo-plan%2F%22%2C%22ua%22%3A%22Mozilla%2F5.0%20(iPhone%3B%20CPU%20iPhone%20OS%2026_0_1%20like%20Mac%20OS%20X)%20AppleWebKit%2F605.1.15%20(KHTML%2C%20like%20Gecko)%20CriOS%2F141.0.7390.41%20Mobile%2F15E148%20Safari%2F604.1%22%2C%22etype%22%3A%22async%22%2C%22phoenix_pattern%22%3A%22network.mobile.rakuten.co.jp%7C%2Ffee%2Fsaikyo-plan%2F%7Cmnoprj_plan_floating_responsive%7Ctarget__root__else_segment%22%2C%22cp%22%3A%7B%22phxcampaign%22%3A%22mnoprj_plan_floating_responsive%22%2C%22phxexperiment%22%3A21652%2C%22phxpattern%22%3A%22target__root__else_segment%22%2C%22phxbanditpattern%22%3A%22target__118245__361147%22%2C%22phxversion%22%3A%223.2.2%22%2C%22phxcmpruntime%22%3A0.001%2C%22phxapiresptime%22%3A0.001%2C%22phxpatternloadtime%22%3A0%7D%2C%22cks%22%3A%22eb1c34aa8455a7f15a9a0ecdd169322fad78ec7%22%7D)

*   個人のお客様
*   [法人のお客様](https://business.mobile.rakuten.co.jp/?scid=wi_rmb_pers_header)
    
*   Language
    
    *   日本語
    *   English
    *   简体中文
    *   繁體中文
    *   한국어
    *   tiếng việt
    *   Indonesia
    *   português
    

Choose your language for Rakuten Mobile !
-----------------------------------------

Our services are provided within the region and laws of Japan.

日本語English简体中文繁體中文한국어tiếng việtIndonesiaportuguês

Select Language

Our services are provided within the region and laws of Japan and we provide translations for your convenience.  
The Japanese version of our websites and applications, in which include Rakuten Membership Rules, Privacy Policy or other terms and conditions, is the definitive version , unless otherwise indicated.  
If there are any discrepancies, the Japanese version shall prevail.  
We do not guarantee that we always provide translation.  
The Japanese versions of all terms and conditions, policies, and other notices are the definitive versions. Any dispute related to the terms and conditions, policies, or other notices will be under the jurisdiction of Japanese law, regardless of any conflicting laws or principles.  
Certain features or messages (including customer services) may not be available in the selected language.

[Rakuten Mobile](https://network.mobile.rakuten.co.jp/?l-id=gnavi_logo_a)

[![おかげさまで950万回線](https://network.mobile.rakuten.co.jp/assets/img/common/logo-thankyou-950.png)](https://network.mobile.rakuten.co.jp/feature/why-rakuten-mobile/?l-id=gnavi_banner_why-rakuten-mobile_a)

*   プラン・  
    製品
    
    スマートフォン
    
    *   [Rakuten最強プラン](https://network.mobile.rakuten.co.jp/fee/saikyo-plan/?l-id=gnavi_fee_saikyo-plan_a)
        *   [データタイプ](https://network.mobile.rakuten.co.jp/fee/saikyo-plan/data-type/?l-id=gnavi_fee_saikyo-plan_data-type_a)
            
    *   [![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-unext.svg)Rakuten最強U-NEXT](https://network.mobile.rakuten.co.jp/fee/unext/?l-id=gnavi_fee_unext_a)
        
        ![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-reduction.svg)割引プログラム
        
        *   [最強家族割\
            \
            家族でトクしたい方に](https://network.mobile.rakuten.co.jp/fee/family/?l-id=gnavi_fee_family_a)
            
        *   [最強こども割\
            \
            12歳までとーってもおトク](https://network.mobile.rakuten.co.jp/fee/kids/?l-id=gnavi_fee_kids_a)
            
        *   [最強青春割\
            \
            22歳までずーっとおトク](https://network.mobile.rakuten.co.jp/fee/youth/?l-id=gnavi_fee_youth_a)
            
        *   [最強シニアプログラム\
            \
            65歳以上から  \
            ずーっと安心&おトク](https://network.mobile.rakuten.co.jp/fee/senior/?l-id=gnavi_fee_senior_a)
            
        
    
    *   [![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-fee-simulation.svg)料金シミュレーション](https://network.mobile.rakuten.co.jp/fee/simulation/?l-id=gnavi_fee_un-limit_simulation_a)
        
    *   [製品](https://network.mobile.rakuten.co.jp/product/?l-id=gnavi_product_a)
        *   [iPhone](https://network.mobile.rakuten.co.jp/product/iphone/?l-id=gnavi_product_iphone_a)
            
        *   [Apple Watch](https://network.mobile.rakuten.co.jp/product/apple-watch/?l-id=gnavi_product_apple-watch_a)
            
        *   [Android](https://network.mobile.rakuten.co.jp/product/smartphone/?l-id=gnavi_product_smartphone_a)
            
        *   [Wi-Fiルーター](https://network.mobile.rakuten.co.jp/product/internet/?l-id=gnavi_product_internet_a)
            
        *   [アクセサリ](https://network.mobile.rakuten.co.jp/product/accessory/?l-id=gnavi_product_accessory_a)
            
        *   [その他オススメ製品](https://network.mobile.rakuten.co.jp/product/ichiba-recommended/?l-id=gnavi_product_ichiba-recommended_a)
            
    *   [オプションサービス](https://network.mobile.rakuten.co.jp/service/?l-id=gnavi_service_a)
        
    
    *   [![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-sim.svg)SIM](https://network.mobile.rakuten.co.jp/product/sim/?l-id=gnavi_product_sim_a)
        *   [eSIM](https://network.mobile.rakuten.co.jp/product/sim/esim/?l-id=gnavi_product_sim_esim_a)
            
        *   [デュアルSIM](https://network.mobile.rakuten.co.jp/product/sim/dual-sim/?l-id=gnavi_product_sim_dual-sim_a)
            
        *   [ご利用製品の対応確認](https://network.mobile.rakuten.co.jp/product/byod/?l-id=gnavi_product_byod_a)
            
    
    インターネット・電気
    
    *   [Rakuten Turbo](https://network.mobile.rakuten.co.jp/internet/turbo/?l-id=gnavi_internet_turbo_a)
        *   [料金プラン](https://network.mobile.rakuten.co.jp/internet/turbo/fee/?l-id=gnavi_internet_turbo_fee_a)
            
    
    *   [楽天ひかり](https://network.mobile.rakuten.co.jp/hikari/?l-id=gnavi_hikari_a)
        *   [料金プラン](https://network.mobile.rakuten.co.jp/hikari/fee/pricelist/?l-id=gnavi_hikari_fee_a)
            
    
    *   [![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-energy.svg)楽天でんき](https://energy.rakuten.co.jp/electricity/?scid=wi_rmb_gnavi_top)
        *   [料金プラン](https://energy.rakuten.co.jp/electricity/fee/?scid=wi_rmb_gnavi_plan)
            
    
    スマホとセットでおトク
    
    *   [![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-saikyo-program.svg)最強おうちプログラム](https://network.mobile.rakuten.co.jp/campaign/home-internet/?l-id=gnavi_campaign_home-internet_a)
        *   [スマホ＋Rakuten Turbo\
            \
            Rakuten Turbo 初めて申し込みで毎月1,000ポイント還元](https://network.mobile.rakuten.co.jp/internet/turbo/campaign/home-internet/?l-id=gnavi_internet_turbo_campaign_home-internet_a)
            
        *   [スマホ＋楽天ひかり\
            \
            楽天ひかり初めて申し込みで毎月1,000ポイント還元](https://network.mobile.rakuten.co.jp/hikari/campaign/home-internet/?l-id=gnavi_hikari_campaign_home-internet_a)
            
    
*   通信エリア・  
    店舗
    
    通信エリア
    
    *   [スマートフォン](https://network.mobile.rakuten.co.jp/area/?l-id=gnavi_area_a)
        
    *   [Rakuten Turbo](https://network.mobile.rakuten.co.jp/internet/turbo/area/?l-id=gnavi_internet_turbo_area_a)
        
    
    ご来店のお客様へ
    
    *   [ショップ（店舗）](https://network.mobile.rakuten.co.jp/shop/?l-id=gnavi_shop_a)
        
    
*   キャンペーン
    
    キャンペーン
    
    *   [スマートフォン](https://network.mobile.rakuten.co.jp/campaign/?l-id=gnavi_campaign_a)
        
    *   [Rakuten Turbo](https://network.mobile.rakuten.co.jp/internet/turbo/campaign/home-internet/?l-id=gnavi_internet_turbo_campaign_home-internet_a)
        
    *   [楽天ひかり](https://network.mobile.rakuten.co.jp/hikari/campaign/home-internet/?l-id=gnavi_hikari_campaign_home-internet_a)
        
    *   [![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-energy.svg)楽天でんき](https://energy.rakuten.co.jp/campaign/lp/mobilelink/?scid=wi_rmb_gnavi_cpn)
        
    
*   お知らせ・  
    サポート
    
    お知らせ・その他
    
    *   [お知らせ](https://network.mobile.rakuten.co.jp/information/?l-id=gnavi_info_a)
        *   [スーパーホーダイ／組み合わせプランを  \
            ご利用中の方](https://mobile.rakuten.co.jp/mvno/?l-id=gnavi_mvno_a)
            
    
    ご検討中の方へ
    
    *   [![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-new-user.svg)お申し込みガイド](https://network.mobile.rakuten.co.jp/guide/procedure/?l-id=gnavi_guide_procedure_a)
        
    *   [なぜ今楽天モバイルなのか](https://network.mobile.rakuten.co.jp/feature/why-rakuten-mobile/?l-id=gnavi_feature_why-rakuten-mobile_a)
        
    *   [お客様の声](https://network.mobile.rakuten.co.jp/uservoice/?l-id=gnavi_uservoice_a)
        
    *   [スマホ活用術を学ぶ](https://network.mobile.rakuten.co.jp/sumakatsu/?l-id=gnavi_sumakatsu_a)
        
    
    お客様サポート
    
    *   [楽天モバイル](https://network.mobile.rakuten.co.jp/support/?l-id=gnavi_support_a)
        
    *   [Rakuten Turbo](https://network.mobile.rakuten.co.jp/internet/turbo/support/?l-id=gnavi_internet_turbo_support_a)
        
    *   [楽天ひかり](https://network.mobile.rakuten.co.jp/hikari/support/?l-id=gnavi_hikari_support_a)
        
    *   [![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-energy.svg)楽天でんき](https://energy.rakuten.co.jp/faq/?scid=wi_rmb_gnavi_qa)
        
    

メニュー

検索

[my 楽天モバイル](https://portal.mobile.rakuten.co.jp/my-rakuten-mobile?l-id=network_gnavi_ecare_a)

[お申し込み](https://network.mobile.rakuten.co.jp/guide/application/?ref=header&lid-r=gnavi_onboarding_a)

[お申し込み](https://network.mobile.rakuten.co.jp/guide/application/?ref=header&lid-r=burger_onboarding_a)
[my 楽天モバイル](https://portal.mobile.rakuten.co.jp/my-rakuten-mobile?l-id=network_burger_ecare_a)

*   ご検討中の方へ
    
*   料金プラン・製品
    
*   通信エリア
    
*   [ショップ（店舗）](https://network.mobile.rakuten.co.jp/shop/?l-id=burger_shop_a)
    
*   キャンペーン
    
*   [お知らせ](https://network.mobile.rakuten.co.jp/information/?l-id=burger_info_a)
    
*   お客様サポート
    

Language

日本語

*   日本語
*   English
*   简体中文
*   繁體中文
*   한국어
*   tiếng việt
*   Indonesia
*   português

[スーパーホーダイ／組み合わせプランをご利用中の方](https://mobile.rakuten.co.jp/mvno/?l-id=burger_mvno_a)

[法人のお客様](https://business.mobile.rakuten.co.jp/?scid=wi_rmb_pers_burger)

料金プラン・製品

スマートフォン

*   料金プラン
    
*   [![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-fee-simulation.svg)料金シミュレーション](https://network.mobile.rakuten.co.jp/fee/simulation/?l-id=burger_fee_un-limit_simulation_a)
    
*   [オプションサービス](https://network.mobile.rakuten.co.jp/service/?l-id=burger_service_a)
    
*   製品
    
*   ![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-sim.svg)SIM
    

おトクな割引・還元プログラムも必見

[![最強家族割](https://network.mobile.rakuten.co.jp/assets/img/common/img-family-251118.png)](https://network.mobile.rakuten.co.jp/fee/family/?l-id=burger_banner_fee-family_a)

[![最強こども割](https://network.mobile.rakuten.co.jp/assets/img/common/img-kids-251118.png)](https://network.mobile.rakuten.co.jp/fee/kids/?l-id=burger_banner_fee-kids_a)

[![最強青春割](https://network.mobile.rakuten.co.jp/assets/img/common/img-youth-251118.png)](https://network.mobile.rakuten.co.jp/fee/youth/?l-id=burger_banner_fee-youth_a)

[![最強シニアプログラム](https://network.mobile.rakuten.co.jp/assets/img/common/img-senior-251118.png)](https://network.mobile.rakuten.co.jp/fee/senior/?l-id=burger_banner_fee_senior_a)

インターネット・電気

*   Rakuten Turbo
    
*   楽天ひかり
    
*   ![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-energy.svg)楽天でんき
    

スマホとセットでおトク

*   ![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-saikyo-program.svg)最強おうちプログラム
    

料金プラン

料金プラン

*   [Rakuten最強プラン\
    \
    シンプルで使いやすいプラン](https://network.mobile.rakuten.co.jp/fee/saikyo-plan/?l-id=burger_fee_saikyo-plan_a)
    
*   [Rakuten最強プラン データタイプ\
    \
    データ通信のみ必要な方に](https://network.mobile.rakuten.co.jp/fee/saikyo-plan/data-type/?l-id=burger_fee_saikyo-plan_data-type_a)
    
*   [Rakuten最強U-NEXT\
    \
    動画や雑誌も楽しみたい方に](https://network.mobile.rakuten.co.jp/fee/unext/?l-id=burger_fee_unext_a)
    

割引プログラム

*   [最強家族割\
    \
    家族でトクしたい方に](https://network.mobile.rakuten.co.jp/fee/family/?l-id=burger_fee_family_a)
    
*   [最強こども割\
    \
    12歳までとーってもおトク](https://network.mobile.rakuten.co.jp/fee/kids/?l-id=burger_fee_kids_a)
    
*   [最強青春割\
    \
    22歳までずーっとおトク](https://network.mobile.rakuten.co.jp/fee/youth/?l-id=burger_fee_youth_a)
    
*   [最強シニアプログラム\
    \
    65歳以上からずーっと安心＆おトク](https://network.mobile.rakuten.co.jp/fee/senior/?l-id=burger_fee_senior_a)
    

製品

*   [製品トップ](https://network.mobile.rakuten.co.jp/product/?l-id=burger_product_a)
    
*   [iPhone](https://network.mobile.rakuten.co.jp/product/iphone/?l-id=burger_product_iphone_a)
    
*   [Apple Watch](https://network.mobile.rakuten.co.jp/product/apple-watch/?l-id=burger_product_apple-watch_a)
    
*   [Android](https://network.mobile.rakuten.co.jp/product/smartphone/?l-id=burger_product_smartphone_a)
    
*   [Wi-Fiルーター](https://network.mobile.rakuten.co.jp/product/internet/?l-id=burger_product_internet_a)
    
*   [アクセサリ](https://network.mobile.rakuten.co.jp/product/accessory/?l-id=burger_product_accessory_a)
    
*   [その他オススメ製品](https://network.mobile.rakuten.co.jp/product/ichiba-recommended/?l-id=burger_product_ichiba-recommended_a)
    

![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-sim.svg)SIM

*   [SIM](https://network.mobile.rakuten.co.jp/product/sim/?l-id=burger_product_sim_a)
    
*   [eSIM](https://network.mobile.rakuten.co.jp/product/sim/esim/?l-id=burger_product_sim_esim_a)
    
*   [デュアルSIM](https://network.mobile.rakuten.co.jp/product/sim/dual-sim/?l-id=burger_product_sim_dual-sim_a)
    
*   [ご利用製品の対応確認](https://network.mobile.rakuten.co.jp/product/byod/?l-id=burger_product_byod_a)
    

Rakuten Turbo

*   [トップ](https://network.mobile.rakuten.co.jp/internet/turbo/?l-id=burger_internet_turbo_a)
    
*   [料金プラン](https://network.mobile.rakuten.co.jp/internet/turbo/fee/?l-id=burger_internet_turbo_fee_a)
    

楽天ひかり

*   [トップ](https://network.mobile.rakuten.co.jp/hikari/?l-id=burger_hikari_a)
    
*   [料金プラン](https://network.mobile.rakuten.co.jp/hikari/fee/pricelist/?l-id=burger_hikari_fee_a)
    

通信エリア

*   [スマートフォン](https://network.mobile.rakuten.co.jp/area/?l-id=burger_area_a)
    
*   [Rakuten Turbo](https://network.mobile.rakuten.co.jp/internet/turbo/area/?l-id=burger_internet_turbo_area_a)
    

キャンペーン

*   [スマートフォン](https://network.mobile.rakuten.co.jp/campaign/?l-id=burger_campaign_a)
    
*   [Rakuten Turbo](https://network.mobile.rakuten.co.jp/internet/turbo/campaign/home-internet/?l-id=burger_internet_turbo_campaign_home-internet_a)
    
*   [楽天ひかり](https://network.mobile.rakuten.co.jp/hikari/campaign/home-internet/?l-id=burger_hikari_campaign_home-internet_a)
    
*   [楽天でんき](https://energy.rakuten.co.jp/campaign/lp/mobilelink/?scid=wi_rmb_gnavi_cpn)
    

ご検討中の方へ

*   [お申し込みガイド](https://network.mobile.rakuten.co.jp/guide/procedure/?l-id=burger_guide_procedure_a)
    
*   [なぜ今楽天モバイルなのか](https://network.mobile.rakuten.co.jp/feature/why-rakuten-mobile/?l-id=burger_feature_why-rakuten-mobile_a)
    
*   [お客様の声](https://network.mobile.rakuten.co.jp/uservoice/?l-id=burger_uservoice_a)
    
*   [スマホ活用術を学ぶ](https://network.mobile.rakuten.co.jp/sumakatsu/?l-id=burger_sumakatsu_a)
    

お客様サポート

*   [楽天モバイル](https://network.mobile.rakuten.co.jp/support/?l-id=burger_support_a)
    
*   [Rakuten Turbo](https://network.mobile.rakuten.co.jp/internet/turbo/support/?l-id=burger_internet_turbo_support_a)
    
*   [楽天ひかり](https://network.mobile.rakuten.co.jp/hikari/support/?l-id=burger_hikari_support_a)
    
*   [楽天でんき](https://energy.rakuten.co.jp/faq/?scid=wi_rmb_gnavi_qa)
    

![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-energy.svg)楽天でんき

*   [トップ](https://energy.rakuten.co.jp/electricity/?scid=wi_rmb_gnavi_top)
    
*   [料金プラン](https://energy.rakuten.co.jp/electricity/fee/?scid=wi_rmb_gnavi_plan)
    

![](https://network.mobile.rakuten.co.jp/assets/img/common/icon-saikyo-program.svg)最強おうちプログラム

*   [トップ](https://network.mobile.rakuten.co.jp/campaign/home-internet/?l-id=burger_campaign_home-internet_a)
    
*   [スマホ＋Rakuten Turbo\
    \
    Rakuten Turbo 初めて申し込みで毎月1,000ポイント還元](https://network.mobile.rakuten.co.jp/internet/turbo/campaign/home-internet/?l-id=burger_internet_turbo_campaign_home-internet_a)
    
*   [スマホ＋楽天ひかり\
    \
    楽天ひかり初めて申し込みで毎月1,000ポイント還元](https://network.mobile.rakuten.co.jp/hikari/campaign/home-internet/?l-id=burger_hikari_campaign_home-internet_a)
    

*   [トップ](https://network.mobile.rakuten.co.jp/)
    
*   Rakuten最強プラン（料金プラン）

ようこそ楽天モバイルへ

楽天モバイルご契約者ならSPU+4倍に！ポイントで料金支払いも可能！[ご利用可能なポイントを確認](https://grp03.id.rakuten.co.jp/rms/nid/login?service_id=rm005&client_id=rmn_app_web&redirect_uri=https%3A%2F%2Fnetwork.mobile.rakuten.co.jp%2Ffee%2Fsaikyo-plan%2F&err_redirect_uri=https%3A%2F%2Fnetwork.mobile.rakuten.co.jp%2F&scope=memberinfo_read_safebulk%2Cmemberinfo_read_point%2Cmemberinfo_get_card_token%2C30days%40Access%2C90days%40Refresh&contact_info_required=false&rae_service_id=rm005)

[ログイン](https://grp03.id.rakuten.co.jp/rms/nid/login?service_id=rm005&client_id=rmn_app_web&redirect_uri=https%3A%2F%2Fnetwork.mobile.rakuten.co.jp%2Ffee%2Fsaikyo-plan%2F&err_redirect_uri=https%3A%2F%2Fnetwork.mobile.rakuten.co.jp%2F&scope=memberinfo_read_safebulk%2Cmemberinfo_read_point%2Cmemberinfo_get_card_token%2C30days%40Access%2C90days%40Refresh&contact_info_required=false&rae_service_id=rm005)
 / [会員登録](https://grp01.id.rakuten.co.jp/rms/nid/registfwd?service_id=rm005)

![「Rakuten最強プラン」はギガもアプリ通話も無制限！※ 3GBまで880円/月（税込968円）、ギガ無制限※1 なら2,880円/月（税込3,168円）](https://network.mobile.rakuten.co.jp/assets/img/fee/saikyo-plan/hero-pc-251027.png)
=====================================================================================================================================================================

※1 混雑時など公平なサービス提供のため速度制御する場合あり。通話無制限はRakuten Linkアプリの利用が必要、一部対象外番号あり。2025年6月時点。4キャリアのギガ無制限プランの料金で比較 ※各種手数料等別 ※別途有料作品等あり

[新規／乗り換え（MNP）お申し込み](https://network.mobile.rakuten.co.jp/guide/application/?lid-r=fee_saikyo-plan_guide_application)

[お近くのショップを探す・来店予約](https://network.mobile.rakuten.co.jp/shop/search/fast/?l-id=fee_saikyo-plan_shop-search-fast)

[オペレーターと相談しながらお申し込み](https://network.mobile.rakuten.co.jp/guide/application-support/?l-id=fee_saikyo-plan_guide_application-support)

[楽天モバイル（ドコモ回線・au回線）からの変更手続き](https://members-station.mobile.rakuten.co.jp/members/rmb/login?language=J&campaign=web-rakuten&l-id=fee_saikyo-plan_ms&mno_migration=1)

[![楽天カード会員様対象 楽天モバイル初めてのお申し込みで20,000ポイント](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-card-mobile-majitoku-328-185-251201.png)](https://network.mobile.rakuten.co.jp/campaign/card-mobile-majitoku/?l-id=fee_banner_campaign_card-mobile-majitoku)
[![楽天モバイル初めてのお申し込み＋他社から電話番号そのまま乗り換え＋楽天市場でのお買い物で最大14,000ポイント](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-shop-limited-application-328-185-250919.png)](https://network.mobile.rakuten.co.jp/campaign/shop-limited-application/?l-id=fee_banner_campaign_shop-limited-application)
[![【要エントリー】楽天モバイル初めてお申し込みキャンペーンでお乗り換えは10,000ポイント・新規お申し込みは7,000ポイントプレゼント!](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-mnp-328-185-251201.png)](https://network.mobile.rakuten.co.jp/campaign/mnp/?l-id=fee_banner_campaign_mnp)
[![【要エントリー】最新機種のiPhone 17やiPhone 17 Proなどが対象！対象iPhoneを購入+楽天モバイルへ初めて申し込み+他社から電話番号そのまま乗り換え+対象iPhone下取りで最大21,000ポイント！](https://network.mobile.rakuten.co.jp/assets/img/bnr/iphone-point-iphone-17-328-185-250912.png)](https://network.mobile.rakuten.co.jp/campaign/iphone-point-iphone-17/?l-id=fee_saikyo-plan_campaign_iphone-point-iphone-17)
[![楽天モバイル申し込み＋他社から電話番号そのまま乗り換え＋対象製品購入で1円！](https://network.mobile.rakuten.co.jp/fee/)](https://network.mobile.rakuten.co.jp/campaign/android-discount/?l-id=fee_banner_campaign_android-discount)
[![iPhone 16e（128GB）がおトク！他社から電話番号そのまま乗り換え＋楽天カード48回払いで1円/月～！（1～24回目まで、25回目以降4,365円/月～）](https://network.mobile.rakuten.co.jp/fee/)](https://network.mobile.rakuten.co.jp/campaign/iphone-point-iphone-16e/?l-id=fee_saikyo-plan_campaign_iphone-point-iphone-16e)
[![【要エントリー】iPhone 16やiPhone 16 Proが対象！一括または24回払いで対象iPhoneを購入＆楽天モバイルへ初めて申し込み＆他社から電話番号そのまま乗り換えで最大36,000円相当おトク！](https://network.mobile.rakuten.co.jp/fee/)](https://network.mobile.rakuten.co.jp/campaign/iphone-pointback/?l-id=fee_banner_campaign_iphone-pointback)
[![楽天モバイル申し込み＋他社から電話番号そのまま乗り換え＋対象製品購入で22,000円値引き](https://network.mobile.rakuten.co.jp/fee/)](https://network.mobile.rakuten.co.jp/campaign/android-sale/?l-id=fee_banner_campaign_android-sale)
[![iPhone 15やiPhone 15 Proが対象！一括または24回払いで対象iPhoneを購入＆楽天モバイルへ初めて申し込み＆他社から電話番号そのまま乗り換えで最大40,000円相当おトク！](https://network.mobile.rakuten.co.jp/fee/)](https://network.mobile.rakuten.co.jp/campaign/iphone-point-iphone-15/?l-id=fee_saikyo-plan_campaign_iphone-point-iphone-15)
[![Rakuten WiFi Pocket Platinumが楽天モバイルお申し込みで1円](https://network.mobile.rakuten.co.jp/fee/)](https://network.mobile.rakuten.co.jp/product/internet/rakuten-wifi-pocket-platinum/?l-id=fee_saikyo-plan_product_internet_rakuten-wifi-pocket-platinum)
[![65歳以上限定 敬老キャンペーン！「最強シニアプログラム」加入＆初めて申し込みでポイント還元、さらにオプションサービスもおトク！](https://network.mobile.rakuten.co.jp/fee/)](https://network.mobile.rakuten.co.jp/campaign/senior-pointback/?l-id=fee_banner_campaign_senior-pointback)
[![【要エントリー】対象iPhoneを一括または24回払いで購入＆楽天モバイルへ初めて申し込み＆他社から電話番号そのまま乗り換えで最大36,000円相当おトク！](https://network.mobile.rakuten.co.jp/fee/)](https://network.mobile.rakuten.co.jp/campaign/iphone-point/?l-id=fee_banner_campaign_iphone-point)
[![OPPO Reno11 AまたはPhone (3a) 256GB購入＋楽天モバイル申し込み＋他社から電話番号そのまま乗り換えで20,000ポイント還元！](https://network.mobile.rakuten.co.jp/fee/)](https://network.mobile.rakuten.co.jp/campaign/android-point/?l-id=fee_banner_campaign_android-point)
[![【要エントリー】楽天モバイルへ初めてお申し込み＋他社から電話番号そのまま乗り換え＋対象製品ご購入で最大16,000ポイント還元！さらにarrows Alphaなら＋10,000ポイント！他社から乗り換え以外の方でも最大13,000ポイント還元中](https://network.mobile.rakuten.co.jp/fee/)](https://network.mobile.rakuten.co.jp/campaign/start-point/?l-id=fee_banner_campaign_start-point)
[![楽天モバイル紹介キャンペーン！紹介1人につき7,000ポイント、紹介される方も最大13,000ポイントプレゼント！](https://network.mobile.rakuten.co.jp/fee/)](https://network.mobile.rakuten.co.jp/campaign/referral/?l-id=fee_banner_campaign_referral)
[![最強おうちプログラム　ネットとスマホ、セットでおトク！楽天モバイル＋Rakuten Turboまたは楽天ひかり初めてお申し込みで毎月1,000ポイント還元、データ3GB（家族割引適用後968円/月）を全額ポイント支払いでスマホ代のお支払いずーっと0円 ※通話料等別](https://network.mobile.rakuten.co.jp/fee/)](https://network.mobile.rakuten.co.jp/campaign/home-internet/?l-id=fee_banner_campaign_home_internet)

PreviousNext

0123

![たくさん使う人も、あまり使わない人にも。Rakuten最強プランがおすすめの理由](https://network.mobile.rakuten.co.jp/assets/img/fee/saikyo-plan/img-question-ttl-pc-251126.png)

*   [![料金・データ通信 自分に合ったプランが選べる！](https://network.mobile.rakuten.co.jp/assets/img/fee/saikyo-plan/anchor-price-pc-251126.png)](https://network.mobile.rakuten.co.jp/fee/#price)
    
*   [![通話 アプリ利用で国内通話無料※2](https://network.mobile.rakuten.co.jp/assets/img/fee/saikyo-plan/anchor-call-pc-251126.png)](https://network.mobile.rakuten.co.jp/fee/#call)
    
*   [![海外 90以上の国と地域で毎月2GB無料※3](https://network.mobile.rakuten.co.jp/assets/img/fee/saikyo-plan/anchor-overseas-pc-251126.png)](https://network.mobile.rakuten.co.jp/fee/#overseas)
    
*   [![特典：ポイント 楽天市場でポイント5倍※4](https://network.mobile.rakuten.co.jp/assets/img/fee/saikyo-plan/anchor-point-pc-251126.png)](https://network.mobile.rakuten.co.jp/fee/#benefits)
    
*   [![クラウドストレージ：大事なデータのバックアップに！楽天ドライブ50GB無料※5](https://network.mobile.rakuten.co.jp/assets/img/fee/saikyo-plan/anchor-rakuten-drive-pc-251126.png)](https://network.mobile.rakuten.co.jp/fee/#rakutenDrive)
    
*   [![特典：エンタメ パリーグ、ミュージック、マガジン無料※6](https://network.mobile.rakuten.co.jp/assets/img/fee/saikyo-plan/anchor-entertainment-pc-251126.png)](https://network.mobile.rakuten.co.jp/fee/#entertainment)
    

※2 一部対象外番号あり。Rakuten Linkアプリ未使用時30秒22円 ※3 プランのデータ利用量に加算。通話料等別。2GB超過後は最大128kbps ※4 要エントリー。毎月の獲得上限ポイントは2,000ポイント。期間限定ポイント ※5 サービスのご利用には別途通信料が発生 ※6 ミュージックは30日ごとに10時間無料。マガジンは1カ月ごとに3冊無料。ミュージックとマガジンの対象コンテンツに一部制限あり。各キャンペーンは予告なく変更・終了する場合あり。その他一部条件あり ※[その他条件詳細はこちら](https://network.mobile.rakuten.co.jp/fee/#anc_note)

[新規／乗り換え（MNP）お申し込み(MNP)](https://network.mobile.rakuten.co.jp/guide/application/?lid-r=fee_saikyo-plan_guide_application02)
[お近くのショップを探す](https://network.mobile.rakuten.co.jp/shop/search/fast/?l-id=fee_saikyo-plan_shop-search-fast02)

[](https://network.mobile.rakuten.co.jp/guide/procedure/?l-id=fee_saikyo-plan_guide_procedure)

![](https://network.mobile.rakuten.co.jp/assets/img/fee/saikyo-plan/icon-price.svg)料金・データ通信

自分に合った  
プランが選べる
----------------

[![動画や雑誌も楽しめる Rakuten 最強U-NEXT](https://network.mobile.rakuten.co.jp/assets/img/fee/saikyo-plan/plan-nav-unext-pc-251027.png)](https://network.mobile.rakuten.co.jp/fee/#price-u-next)

[![使った分だけお支払い Rakuten最強プラン](https://network.mobile.rakuten.co.jp/assets/img/fee/saikyo-plan/plan-nav-saikyo-pc-251027.png)](https://network.mobile.rakuten.co.jp/fee/#price-saikyo)

NEW

ギガ無制限で映画もアニメも見放題※10  
※11

![Rakuten 最強U-NEXT](https://network.mobile.rakuten.co.jp/assets/img/fee/saikyo-plan/plan-unext-title-pc.png)

月々の料金をチェック

通常料金

年齢に応じてさらにおトク！

12歳以下13歳～22歳65歳以上

### プラン料金（通常）

#### 対象の割引のお申し込みでおトクな料金に！

![月額3,980円（税込4,378円）でギガ無制限で映画やアニメも見放題！※10※11さらに最強家族割適用で110円引き。](https://network.mobile.rakuten.co.jp/assets/img/fee/saikyo-plan/img-plan-unext-regularprice-pc-251118.png)

![アプリ利用で国内通話無料 何分でも何回でもかけ放題！※2](https://network.mobile.rakuten.co.jp/assets/img/fee/saikyo-plan/img-plan-unext-domestic-call-pc-251027.png)

[Rakuten最強U-NEXTの詳細を見る](https://network.mobile.rakuten.co.jp/fee/unext/?l-id=fee_saikyo-plan_fee_unext)

![さらに今なら！](https://network.mobile.rakuten.co.jp/assets/img/fee/saikyo-plan/moreover-pc-251027.png)[![動画や雑誌も楽しめる Rakuten 最強U-NEXT](https://network.mobile.rakuten.co.jp/assets/img/fee/saikyo-plan/bnr-unext-pc-251027.png)](https://network.mobile.rakuten.co.jp/fee/unext/?l-id=fee_saikyo-plan_fee_unext01)

### 対象の割引

[![最強家族割 家族だれでも110円引き！](https://network.mobile.rakuten.co.jp/assets/img/fee/saikyo-plan/plan-link-family-pc-251118.png)](https://network.mobile.rakuten.co.jp/fee/family/?l-id=fee_saikyo-plan_price_family05)

※2一部対象外番号あり ※7 要申し込み※10 混雑時等公平なサービス提供のため速度制御する場合有。通話料等別 ※11 別途有料作品等あり

使った分だけお支払い

![Rakuten 最強プラン](https://network.mobile.rakuten.co.jp/assets/img/fee/saikyo-plan/plan-saikyo-title-pc.png)

月々の料金をチェック

通常料金

年齢に応じてさらにおトク！

12歳以下13歳～22歳65歳以上

### プラン料金（通常）

#### 対象の割引のお申し込みでおトクな料金に！

![最強家族割適用で、データ3GBまで880円（税込968円）、3GB超過後20GBまで1,880円（税込2,068円）、20GB超過後ギガ無制限で2,880円（税込3,168円）](https://network.mobile.rakuten.co.jp/assets/img/fee/saikyo-plan/img-plan-regularPrice-pc-251118.png)

![アプリ利用で国内通話無料 何分でも何回でもかけ放題！※2](https://network.mobile.rakuten.co.jp/assets/img/fee/saikyo-plan/img-plan-domestic-call-pc-250716.png)

### 対象の割引

[![最強家族割 家族だれでも110円引き！](https://network.mobile.rakuten.co.jp/assets/img/fee/saikyo-plan/plan-link-family-pc-251118.png)](https://network.mobile.rakuten.co.jp/fee/family/?l-id=fee_saikyo-plan_price_family)

[Rakuten最強プランの詳細を見る](https://network.mobile.rakuten.co.jp/fee/saikyo-plan/detail/?l-id=fee_saikyo-plan_saikyo-plan-detail)

※1 混雑時など公平なサービス提供のため速度制御する場合あり ※2 一部対象外番号あり。Rakuten Linkアプリ未使用時30秒22円 ※7 要申し込み

[![楽天モバイルに乗り換えると毎月いくらおトクになる？3ステップでわかる！料金＆ポイントかんたんシミュレーション！他社プランと比較もできる](https://network.mobile.rakuten.co.jp/assets/img/fee/saikyo-plan/bnr-fee-simulation-1032-50-250716.png)](https://network.mobile.rakuten.co.jp/fee/simulation/?l-id=fee_saikyo-plan_fee_simulation)

[他社プラン料金比較を確認する](https://network.mobile.rakuten.co.jp/fee/#compareother)

### おトクな年齢別割引・プログラム

[![最強こども割](https://network.mobile.rakuten.co.jp/assets/img/fee/saikyo-plan/bnr-kids-pc-251118.png)](https://network.mobile.rakuten.co.jp/fee/kids/?l-id=fee_saikyo-plan_fee_kids_)
[![最強青春割](https://network.mobile.rakuten.co.jp/assets/img/fee/saikyo-plan/bnr-youth-pc-251118.png)](https://network.mobile.rakuten.co.jp/fee/youth/?l-id=fee_saikyo-plan_fee_youth_)
[![最強シニアプログラム](https://network.mobile.rakuten.co.jp/assets/img/fee/saikyo-plan/bnr-senior-pc-251118.png)](https://network.mobile.rakuten.co.jp/fee/senior/?l-id=fee_saikyo-plan_fee_senior01_)

\*1 期間限定ポイント。要エントリー \*2 一部対象外番号あり。国内通話のみ対象。各種サービスには使用条件等あり \*3 要申し込み

[![65歳以上限定 敬老キャンペーン！「最強シニアプログラム」加入＆初めて申し込みでポイント還元、さらにオプションサービスもおトク！](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-senior-pointback-1032-160-251024.png)](https://network.mobile.rakuten.co.jp/campaign/senior-pointback/?l-id=fee_saikyo-plan_campaign_senior-pointback-02)

![日本全国の通信エリアどこでも、ギガ無制限で好きなだけ使える！ ※1](https://network.mobile.rakuten.co.jp/assets/img/fee/saikyo-plan/areabnr-ttl-pc-251126.png)

![※ 人口カバー率は99.9％ ※10](https://network.mobile.rakuten.co.jp/assets/img/fee/saikyo-plan/areabnr-img-pc-251126.png)

[通信エリアの詳細を見る](https://network.mobile.rakuten.co.jp/area/?l-id=saikyo-plan_area)

[1分でわかる！ご自宅の電波状況をチェック](https://network.mobile.rakuten.co.jp/area/connectivity-fitting/?l-id=saikyo-plan_area_connectivity-fitting)

※1 混雑時など公平なサービス提供のため速度制御する場合あり

※10 2024年12月時点。[詳細はこちら](https://network.mobile.rakuten.co.jp/fee/#anc_note)

契約事務手数料もおトク

![](https://network.mobile.rakuten.co.jp/assets/img/fee/saikyo-plan/contract-administration-fee.png)

ショップでの契約事務手数料

![楽天モバイル 累計4回線目まで無料*1、ドコモ/ソフトバンク4,950円、au3,850円](https://network.mobile.rakuten.co.jp/assets/img/fee/saikyo-plan/charge-table-pc-251119.png)

※2025年9月時点 \*1 同一名義で累計5回線以上ご契約の場合、2025年11月19日より1回線につき3,500円（税込3,850円、開通翌々月に確定）。「累計」とは、楽天モバイルがサービスを本格開始した2020年4月8日以降に契約されたすべての回線（解約済みの回線も含む）の合計数を指します。[契約事務手数料の詳細はこちら](https://network.mobile.rakuten.co.jp/guide/commission/?l-id=fee_saikyo-plan_commission)

![通話 アプリ利用で国内通話無料※2](https://network.mobile.rakuten.co.jp/assets/img/fee/saikyo-plan/call-ttl-pc-250716.png)
------------------------------------------------------------------------------------------------------------

![Rakuten Link利用で国内通話かけ放題！※3 固定電話にかけてもOK、データ消費なし、お使いの電話番号そのまま](https://network.mobile.rakuten.co.jp/assets/img/fee/saikyo-plan/call-img-pc-251126.png)

[Rakuten Linkアプリの詳細を見る](https://network.mobile.rakuten.co.jp/service/rakuten-link/?l-id=fee_saikyo-plan_service_rakuten-link)

※2 一部対象外番号あり。Rakuten Linkアプリ未使用時30秒22円

![海外 追加申し込みなしで海外でもおトクに使える](https://network.mobile.rakuten.co.jp/assets/img/fee/saikyo-plan/overseas-ttl-pc-251126.png)
----------------------------------------------------------------------------------------------------------------------

![海外指定90以上の国と地域で毎月2GBまで無料※3 ※プランのデータ利用量に加算](https://network.mobile.rakuten.co.jp/assets/img/fee/saikyo-plan/img-overseas-communication-pc-251126.png)![アプリ利用で日本の電話番号との国際通話無料 ※一部対象外番号あり](https://network.mobile.rakuten.co.jp/assets/img/fee/saikyo-plan/img-overseas-call-pc-251126.png)

[詳細を見る](https://network.mobile.rakuten.co.jp/service/global/overseas/?l-id=saikyo-plan_service_global_overseas)

※ご利用時にmy 楽天モバイルとスマホの設定が別途必要です ※3 通話料等別。2GB超過後は最大128kbps

![特典 ほかにもまだまだ!見逃せないおトクな特典](https://network.mobile.rakuten.co.jp/assets/img/fee/saikyo-plan/privilege-ttl-pc-251126.png)
-----------------------------------------------------------------------------------------------------------------------

楽天ポイントが  
貯まる！使える！

![Rakuten最強プランご契約者 は楽天市場でのお買い物ポイント毎日全員5倍 ※4](https://network.mobile.rakuten.co.jp/assets/img/fee/saikyo-plan/benefit-point-pc-251126.png)

[ポイントアップの詳細を見る](https://network.mobile.rakuten.co.jp/campaign/spu/?l-id=fee_saikyo-plan_campaign_spu)

※4 要エントリー。獲得ポイントに上限あり

![紹介で貯まる! 家族やお友達を紹介するほどポイントがもらえる! 紹介する方に：ご紹介1人につき7,000ポイントプレゼント。紹介された方にも：初めてのお申し込み＆他社から電話番号そのまま乗り換えで13,000ポイントプレゼント。※乗り換え（MNP）以外で初めてお申し込みの方は10,000ポイント 家族6人（紹介する方1人、紹介される方5人）の場合は合計10万ポイント獲得!!](https://network.mobile.rakuten.co.jp/assets/img/fee/saikyo-plan/benefit-referral-pc-251126.png)

[紹介キャンペーン詳細を見る](https://network.mobile.rakuten.co.jp/campaign/referral/?l-id=fee_saikyo-plan_campaign_referral)

※Rakuten Linkアプリ利用・「Rakuten最強プラン（データタイプ）」対象外等条件あり。ポイントは4カ月後から分割付与。期間限定ポイント※11 家族6人で、5人が家族からの紹介経由でお申し込みした場合

![貯まったポイントで全額支払えば、スマホ代のお支払いずーッと0円！](https://network.mobile.rakuten.co.jp/assets/img/fee/saikyo-plan/benefit-pay-pc-251126.png)

[お支払い0円をもっと詳しく](https://network.mobile.rakuten.co.jp/tips/zerotoku/?l-id=fee_saikyo-plan_tips_zerotoku)

NEW

大事なデータの  
バックアップもおトクに！

![クラウドストレージ：大事なデータのバックアップに！楽天ドライブ50GB無料※5](https://network.mobile.rakuten.co.jp/assets/img/fee/saikyo-plan/rakuten-drive-img-pc-251126.png)

[詳細を見る](https://network.mobile.rakuten.co.jp/service/rakuten-drive/?l-id=fee_saikyo-plan_service_rakuten-drive)

※5 サービスのご利用には別途通信料が発生。[その他詳細条件はこちら](https://network.mobile.rakuten.co.jp/fee/#anc_note)

エンタメコンテンツも  
盛りだくさん！

![パ・リーグ、ミュージック、マガジンが追加料金0円！※ミュージックは30日ごとに10時間無料。マガジンは1カ月ごとに3冊無料。ミュージックとマガジンの対象コンテンツに一部制限あり。各キャンペーンは予告なく変更・終了する場合あり。その他一部条件あり](https://network.mobile.rakuten.co.jp/assets/img/fee/saikyo-plan/entertainment-img-pc-251126.png)

[詳細を見る](https://network.mobile.rakuten.co.jp/campaign/digital-contents/?l-id=fee_saikyo-plan_campaign_digital_contents)

![Rakuten 最強U-NEXT 2025年10月以降開始！先行キャンペーン実施中！ギガもアプリ通話も無制限、U-NEXT見放題！](https://network.mobile.rakuten.co.jp/assets/img/fee/saikyo-plan/unext-img-pc-251126.png)

[詳細を見る](https://network.mobile.rakuten.co.jp/campaign/unext/?l-id=fee_saikyo-plan_campaign_unext02)

![Hulu いま話題の作品が見放題！初月無料+月額利用料20%ポイント還元！ DAZN 興奮のスポーツ観戦を手軽で快適に！月額利用料15%ポイント還元！DMMプレミアム アニメ・エンタメ見放題！月額利用料20%ポイント還元！](https://network.mobile.rakuten.co.jp/assets/img/fee/saikyo-plan/popular-video-pc-251126.png)

[詳細を見る](https://network.mobile.rakuten.co.jp/service/entertainment-selection/?l-id=fee_saikyo-plan_service_entertainment-selection)

※税別価格からポイント還元 ※各キャンペーンは予告なく変更・終了する場合あり。その他一部条件あり

### ご検討中の方へ

![オリコン顧客満足度®調査 携帯キャリア おかげさまで 2年連続No.1*1。 乗り換え検討 先No.1*2。在留外国人の契約率No.1 *3。*1 2024年 オリコン顧客満足度®調査 「携帯キャリア」 2年連続第1位。*2 MMD研究所による「2025年2月通信サービスの乗り換え検討に関する調査」の結果。*3 MMD研究所「在留外国人の通信サービスに関する調査/2025年4月」における直近1年の在留増加率トップ5か国における総合1位](https://network.mobile.rakuten.co.jp/assets/img/fee/saikyo-plan/img-oricon-pc-250717.png?250811)

\*1 2024年 オリコン顧客満足度®調査 「携帯キャリア」 2年連続第1位  
\*2 MMD研究所による「2025年2月通信サービスの乗り換え検討に関する調査」の結果  
\*3 MMD研究所「在留外国人の通信サービスに関する調査/2025年4月」における直近1年の在留増加率トップ5か国における総合1位

### お役立ち情報

[![お申し込み手続きでお困りごとはありますか？ はじめてでも安心！お申し込みガイド ご利用開始までかんたん4ステップでご案内します](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-apply-guide-1032-78-240221.png)](https://network.mobile.rakuten.co.jp/guide/procedure/?l-id=fee_saikyo-plan_guide_procedure01)

[![最強おうちプログラム ネットとスマホ、セットでおトク！楽天モバイル＋Rakuten Turboまたは楽天ひかり初めてお申し込みで毎月1,000ポイント還元](https://network.mobile.rakuten.co.jp/assets/img/bnr/bnr-campaign-home-internet-1032-50-251201.png)](https://network.mobile.rakuten.co.jp/campaign/home-internet/?l-id=fee_saikyo_plan_campaign_home_internet)

[![なぜ今楽天モバイルなのか シンプルで高品質なサービスの実現やおトクな楽天ポイント還元をご紹介](https://network.mobile.rakuten.co.jp/assets/img/fee/saikyo-plan/bnr-why-504-158-250716.png)](https://network.mobile.rakuten.co.jp/feature/why-rakuten-mobile/?l-id=fee_saikyo-plan_why-rakuten-mobile)
[![まだギガ制限気にしてる？楽天モバイルはギガ無制限！気になる実際のデータ利用量をチェック！※混雑時など公平なサービス提供のため速度制御する場合あり。](https://network.mobile.rakuten.co.jp/assets/img/fee/saikyo-plan/bnr-giga-504-158-250716.png)](https://network.mobile.rakuten.co.jp/ad/lp/uservoice/?l-id=fee_saikyo-plan_ad_lp_uservoice)

ご利用中のお客様の声
----------

*   [コスパの高さなら楽天モバイル！4回線契約して活用しています\
    \
    大山さん（仮名）（40 代男性・徳島県）\
    \
    ![](https://network.mobile.rakuten.co.jp/assets/img/uservoice/avator-80.png)](https://network.mobile.rakuten.co.jp/uservoice/80/?l-id=fee_saikyo-plan_uservoice_01)
    
*   [娘の進学を機に乗り換え！楽天ポイントで生活費の負担も軽減\
    \
    内村さん（仮名）（40代女性・千葉県）\
    \
    ![](https://network.mobile.rakuten.co.jp/assets/img/uservoice/avator-51.png)](https://network.mobile.rakuten.co.jp/uservoice/51/?l-id=fee_saikyo-plan_uservoice_02)
    

[お客様の声をみる](https://network.mobile.rakuten.co.jp/uservoice/?l-id=fee_saikyo-plan_uservoice_03)

キャンペーン・おすすめ情報
-------------

[![楽天カード会員様対象 楽天モバイル初めてのお申し込みで20,000ポイント](https://network.mobile.rakuten.co.jp/fee/)](https://network.mobile.rakuten.co.jp/campaign/card-mobile-majitoku/?l-id=include_carousel_campaign_card-mobile-majitoku)
[![【要エントリー】楽天モバイル初めてお申し込みキャンペーンでお乗り換えは10,000ポイント・新規お申し込みは7,000ポイントプレゼント! ](https://network.mobile.rakuten.co.jp/fee/)](https://network.mobile.rakuten.co.jp/campaign/mnp/?l-id=include_campaign_campaign_mnp)
[![【要エントリー】最新機種のiPhone 17やiPhone 17 Proなどが対象！対象iPhoneを購入+楽天モバイルへ初めて申し込み+他社から電話番号そのまま乗り換え+対象iPhone下取りで最大21,000ポイント！](https://network.mobile.rakuten.co.jp/fee/)](https://network.mobile.rakuten.co.jp/campaign/iphone-point-iphone-17/?l-id=include_campaign_campaign_iphone-point-iphone-17)
[![楽天モバイル申し込み＋他社から電話番号そのまま乗り換え＋対象製品購入で1円！](https://network.mobile.rakuten.co.jp/fee/)](https://network.mobile.rakuten.co.jp/campaign/android-discount/?l-id=include_campaign_campaign_android-discount)
[![iPhone 16e（128GB）がおトク！他社から電話番号そのまま乗り換え＋楽天カード48回払いで1円/月～！（1～24回目まで、25回目以降4,365円/月～）](https://network.mobile.rakuten.co.jp/fee/)](https://network.mobile.rakuten.co.jp/campaign/iphone-point-iphone-16e/?l-id=include_campaign_campaign_iphone-point-iphone-16e)
[![【要エントリー】iPhone 16やiPhone 16 Proが対象！一括または24回払いで対象iPhoneを購入＆楽天モバイルへ初めて申し込み＆他社から電話番号そのまま乗り換えで最大36,000円相当おトク！](https://network.mobile.rakuten.co.jp/fee/)](https://network.mobile.rakuten.co.jp/campaign/iphone-pointback/?l-id=include_campaign_campaign_iphone-pointback)
[![一括または24回払いでiPhone 15やiPhone 15 Proを購入＆楽天モバイルへ初めて申し込み＆他社から電話番号そのまま乗り換えで最大40,000円相当おトク！](https://network.mobile.rakuten.co.jp/fee/)](https://network.mobile.rakuten.co.jp/campaign/iphone-point-iphone-15/?l-id=include_campaign_campaign_iphone-point-iphone-15)
[![楽天モバイル初めてのお申し込み＋他社から電話番号そのまま乗り換え＋楽天市場でのお買い物で最大14,000ポイント](https://network.mobile.rakuten.co.jp/fee/)](https://network.mobile.rakuten.co.jp/campaign/shop-limited-application/?l-id=include_campaign_campaign_shop-limited-application)
[![Rakuten WiFi Pocket Platinumが楽天モバイルお申し込みで1円](https://network.mobile.rakuten.co.jp/fee/)](https://network.mobile.rakuten.co.jp/product/internet/rakuten-wifi-pocket-platinum/?l-id=include_campaign_product_internet_rakuten-wifi-pocket-platinum)
[![楽天モバイル申し込み＋他社から電話番号そのまま乗り換え＋対象製品購入で22,000円値引き](https://network.mobile.rakuten.co.jp/fee/)](https://network.mobile.rakuten.co.jp/campaign/android-sale/?l-id=include_campaign_campaign_android-sale)
[![OPPO Reno11 AまたはPhone (3a) 256GB購入＋楽天モバイル申し込み＋他社から電話番号そのまま乗り換えで20,000ポイント還元！](https://network.mobile.rakuten.co.jp/fee/)](https://network.mobile.rakuten.co.jp/campaign/android-point/?l-id=include_campaign_campaign_android-point)
[![【要エントリー】楽天モバイルへ初めてお申し込み＋他社から電話番号そのまま乗り換え＋対象製品ご購入で最大16,000ポイント還元！さらにarrows Alphaなら＋10,000ポイント！他社から乗り換え以外の方でも最大13,000ポイント還元中](https://network.mobile.rakuten.co.jp/fee/)](https://network.mobile.rakuten.co.jp/campaign/start-point/?l-id=include_campaign_campaign_start-point)
[![楽天モバイル紹介キャンペーン！紹介1人につき7,000ポイント、紹介される方も最大13,000ポイントプレゼント！](https://network.mobile.rakuten.co.jp/fee/)](https://network.mobile.rakuten.co.jp/campaign/referral/?l-id=include_campaign_campaign_referral)
[![楽天モバイルに乗り換えるだけでどれだけおトクになる？3ステップでわかる！料金＆ポイントかんたんシミュレーション！他社プランと比較もできる](https://network.mobile.rakuten.co.jp/fee/)](https://network.mobile.rakuten.co.jp/fee/simulation/?l-id=include_campaign_fee_simulation)
[![【要エントリー】Web限定！Apple Watch購入＋「電話番号シェアサービス」加入（550円/ 月）で最大25,000ポイントプレゼント！](https://network.mobile.rakuten.co.jp/fee/)](https://network.mobile.rakuten.co.jp/campaign/apple-watch-number-share/?l-id=include_campaign_campaign_apple-watch-number-share)
[![Rakuten Turbo初めてお申し込み＆楽天モバイルご利用で永年毎月1,000ポイント還元 ※期間限定ポイント。条件あり](https://network.mobile.rakuten.co.jp/fee/)](https://network.mobile.rakuten.co.jp/internet/turbo/campaign/home-internet/?l-id=include_campaign_internet_turbo_campaign_home-internet)
[![楽天ひかり初めてお申し込み＆楽天モバイルご利用で永年毎月1,000ポイント還元 ※期間限定ポイント。条件あり](https://network.mobile.rakuten.co.jp/fee/)](https://network.mobile.rakuten.co.jp/hikari/campaign/home-internet/?l-id=include_campaign_hikari_campaign_home-internet)
[![15分（標準）通話かけ放題がはじめてのお申し込みで1カ月無料！](https://network.mobile.rakuten.co.jp/fee/)](https://network.mobile.rakuten.co.jp/service/standard-free-call/?l-id=include_service_standard-free-call)
[![電源OFF時や通信圏外時にも使える 留守番電話 はじめてのお申し込みで初月無料※ 2025年6月19日（木）0:00～終了日未定 ※その他条件あり](https://network.mobile.rakuten.co.jp/fee/)](https://network.mobile.rakuten.co.jp/service/voice-mail/?l-id=include_campaign_service_voice-mail)
[![通話中の電話も保留にできる 割込通話 はじめてのお申し込みで初月無料※ 2025年6月19日（木）0:00～終了日未定 ※その他条件あり](https://network.mobile.rakuten.co.jp/fee/)](https://network.mobile.rakuten.co.jp/service/call-waiting/?l-id=include_campaign_service_call-waiting)
[![これで安心!オールインワンのスマホセキュリティサービス 最強保護 初回利用3ヶ月無料！※4キャリアにおいてノートン社の同等のセキュリティサービスと比較し最安。2025年8月自社調べ。](https://network.mobile.rakuten.co.jp/fee/)](https://network.mobile.rakuten.co.jp/service/saikyo-protection/?l-id=include_campaign_service_saikyo-protection)
[![お子さまのスマホもお出かけも見守る、あんしんオプションサービス あんしんコントロール初回3カ月無料！※1回線につき1回限り、月額550円が3カ月無料となります。](https://network.mobile.rakuten.co.jp/fee/)](https://network.mobile.rakuten.co.jp/service/anshin-control/?l-id=include_campaign_service_anshin-control)
[![トク得！エンタメセレクション 楽天モバイルからのお申し込みでエンタメコンテンツがおトクに楽しめる！ ずーっと月額利用料最大20%ポイント還元](https://network.mobile.rakuten.co.jp/fee/)](https://network.mobile.rakuten.co.jp/service/entertainment-selection/?l-id=include_campaign_service_entertainment-selection)
[![【要エントリー】Rakuten最強プランご契約で楽天市場のお買い物が毎日全員ポイント5倍 ※上限・条件あり](https://network.mobile.rakuten.co.jp/fee/)](https://network.mobile.rakuten.co.jp/campaign/spu/?l-id=include_campaign_campaign_spu)

[キャンペーン一覧を見る](https://network.mobile.rakuten.co.jp/campaign/?l-id=campaign_carousel_campaign-top)

#### さらにパワーアップしたRakuten最強プランにいますぐ申し込もう

*   [新規／乗り換え（MNP）お申し込み](https://network.mobile.rakuten.co.jp/guide/application/?lid-r=fee_saikyo-plan_guide_application03)
    
*   [お近くのショップを探す](https://network.mobile.rakuten.co.jp/shop/search/fast/?l-id=fee_saikyo-plan_shop-search-fast01)
    

[オペレーターと相談しながらお申し込み](https://network.mobile.rakuten.co.jp/guide/application-support/?l-id=fee_saikyo-plan_guide_application-support03)

ギガ無制限の提供がある各社料金プランの比較（家族割引適用時）
------------------------------

スクロールできます

![他社料金比較表](https://network.mobile.rakuten.co.jp/assets/img/fee/saikyo-plan/img-compare-02-fee-pc-250908.png)

※その他、各種キャンペーンによって、割引が適用される場合あり※記載された情報は2025年8月時点の情報（自社調べ）  
※[その他条件の詳細はこちら](https://network.mobile.rakuten.co.jp/fee/#anc_note)

注意事項
----

■料金プランについて

※ご契約1回線目において、一定期間以上回線のご利用がない場合は、回線の利用停止または解約をさせていただく場合がございます。  
※1つの楽天IDにつき最大10回線まで契約可能。詳しくは「[契約可能上限数を教えてください](https://network.mobile.rakuten.co.jp/faq/detail/00001243/?l-id=fee_saikyo-plan_faq_detail-00001243)
」をご確認ください。複数の楽天IDを作成/保有することは禁止しております。  
※各種手数料等別

■ギガ無制限について

※1 混雑時など公平なサービス提供のため速度制御する場合あり

■Rakuten Linkアプリ利用で国内通話無料について

※2（0180）（0570）などから始まる他社接続サービス、一部特番（188）への通話については、無料通話の対象外となります。OS標準の電話アプリを利用した場合、30秒22円

■海外は2GBまで無料について

※3 通話料等別。プランのデータ利用量に加算。2GB超過後は最大128kbps。対象エリアおよび条件は変更する場合あり。[対象エリア](https://network.mobile.rakuten.co.jp/service/global/overseas/#accordion-1)
をご確認ください。

■「楽天市場のお買い物ポイントが毎日全員5倍」について

※4 要エントリー。楽天会員1倍と楽天モバイルSPU＋4倍の合計値です。楽天モバイルSPUの毎月の獲得上限ポイント数は2,000ポイント。期間限定ポイントでの付与。詳細は[こちら](https://network.mobile.rakuten.co.jp/campaign/spu/)
をご確認ください。

■楽天ドライブについて

※5 当クラウドサービスは、高い信頼性と安全性を提供するよう設計されていますが、全てのデータの完全な保護を半永久的に保証するものではありません。

■エンタメ特典について

※6 ミュージックは30日ごとに10時間無料。マガジンは1カ月ごとに3冊無料。ミュージックとマガジンの対象コンテンツに一部制限あり。各キャンペーンは予告なく変更・終了する場合あり。その他一部条件あり

■「最強こども割」「最強青春割」について

※7 要申し込み。  
※「最強こども割」は13歳の誕生月前月まで適用。「最強青春割」は23歳の誕生月前月まで適用。  
\*3 要申し込み  
※18歳未満の方がご利用いただく場合、フィルタリングサービス（有償）ご契約が必須

■「最強シニアプログラム」について

※8 要エントリー。還元ポイントは全ての条件を満たしたことが確認された月の翌々月末ごろに期間限定ポイントで付与。ご本人名義でのご契約が必要  
※9 2カ月目以降は指定オプション2,200円が毎月最大1,100ポイント還元で実質1,000円/月（税込1,100円）  
\*1 期間限定ポイント。要エントリー  
\*2 一部対象外番号あり。国内通話のみ対象。各種サービスには使用条件等あり  
※「最強シニアプログラム」は65歳の誕生月より適用

■サービスエリアについて

※10 2024年12月時点。人口カバー率は、国勢調査に用いられる約500m区画において、50%以上の場所で通信可能なエリアを基に算出

■Youtube Premium3カ月無料について

※ YouTube Premium、YouTube Music Premium、YouTube Red、Google Play Music のうち、いずれかの定期購入や無料お試しを行ったことがある場合は対象外です。

■楽天IDについて

※ 楽天IDを使用せずに楽天モバイルにお申し込みされた場合、楽天ポイントは付与されません。また、Rakuten Linkアプリなど、楽天会員向けの特典やサービスが制限されます。[詳細はこちら](https://network.mobile.rakuten.co.jp/guide/flow/application/non-rakuten-id/?l-id=fee_saikyo-plan_02_guide_flow_application_non-rakuten-id)

■楽天ポイント利用について

※11 家族6人で、5人が家族からの紹介経由でお申し込みした場合  
※月々のお支払いに口座振替をご指定の場合は、楽天ポイントをご利用いただけません。  
※一度に利用できるポイント数は1～30,000（ダイヤモンド会員の方は～500,000）ポイントです。製品を分割払いでご購入の場合、初回のみポイントがご利用いただけます。分割払いの2回目以降のお支払いにはご利用いただけません。  
※ 楽天IDを使用せずに楽天モバイルにお申し込みされた場合、楽天ポイントは付与されないためご利用いただけません。[詳細はこちら](https://network.mobile.rakuten.co.jp/guide/flow/application/non-rakuten-id/?l-id=fee_saikyo-plan_01_guide_flow_application_non-rakuten-id)

■他社プラン比較条件について

※その他、各種キャンペーンによって、割引が適用される場合があります。  
\*1 混雑時など公平なサービス提供のため速度制御する場合あり  
\*2 毎月のデータ利用量によってプラン料金が変動いたします。データ利用量は日本全国の通信エリアおよび海外ローミングエリアのすべてのエリアでカウントされます。  
\*3（0570）などから始まる他社接続サービス、一部特番（188）への通話については、無料通話の対象外となります。OS標準の電話アプリを利用した場合、30秒22円。国内SMSは3円（税込3.3円）／70文字（全角）～。  
\*4 楽天モバイル「15分（標準）通話かけ放題」は、15分超過後は30秒22円。一部対象外番号あり。SMS送信件数は1日あたりの上限あり。  
\*5 国内通話5分かけ放題の5分超過後は30秒22円。一部対象外番号あり。  
\*6 一部対象外番号あり。

続けてこちらをチェック
-----------

*   [製品楽天モバイル対応、5G対応スマートフォンはこちら](https://network.mobile.rakuten.co.jp/product/?l-id=footer_product)
    
*   [通信・エリア楽天モバイル対応サービスエリア（4G LTE、5G、海外ローミングエリア）はこちらから](https://network.mobile.rakuten.co.jp/area/?l-id=footer_area)
    
*   [お客様サポートお申し込み、ご利用にあたっての疑問はここで解決](https://network.mobile.rakuten.co.jp/support/?l-id=footer_support)
    

*   [トップ](https://network.mobile.rakuten.co.jp/)
    
*   Rakuten最強プラン（料金プラン）

*   [会社概要](https://corp.mobile.rakuten.co.jp/)
    
*   [法人のお客様](https://business.mobile.rakuten.co.jp/?scid=wi_rmb_pers_footer)
    
*   [法人パートナープログラム](https://business.mobile.rakuten.co.jp/partner/?scid=wi_rmb_pers_footer)
    
*   [個人情報の取扱いについて](https://corp.mobile.rakuten.co.jp/guide/privacy/)
    
*   [情報セキュリティポリシー](https://corp.mobile.rakuten.co.jp/guide/security/)
    
*   [商標・登録商標について](https://corp.mobile.rakuten.co.jp/guide/trademark/)
    
*   [古物営業法に基づく表示](https://network.mobile.rakuten.co.jp/secondhand-dealer/)
    
*   [利用規約](https://network.mobile.rakuten.co.jp/terms/)
    
*   [外部送信される情報の取り扱いについて](https://network.mobile.rakuten.co.jp/optout/)
    

© Rakuten Mobile, Inc.

[![AIも、楽天グループなら安心](https://network.mobile.rakuten.co.jp/assets/img/common/bnr-ai-safety-240-75-250530.png)](https://corp.rakuten.co.jp/ai/ai-safety/?scid=wi_rmb_aisafety)

[![【Go Green Together】同社の従来ネットワーク比較 消費電力約20%削減へ 募金キャンペーン実施中](https://network.mobile.rakuten.co.jp/assets/img/common/bnr-green-charity-240-75-250530.png)](https://network.mobile.rakuten.co.jp/campaign/green-charity/?l-id=footer_campaign_green-charity)

*   楽天グループ
*   [サービス一覧](https://www.rakuten.co.jp/sitemap/)
    
*   [お問い合わせ一覧](https://www.rakuten.co.jp/sitemap/inquiry.html)
    
*   [サステナビリティ](https://corp.rakuten.co.jp/sustainability/)
    

[![申し込み・相談 AIサポート](https://network.mobile.rakuten.co.jp/assets/img/common/gen-ai-link-balloon-pc-250804.svg)![](https://network.mobile.rakuten.co.jp/assets/img/common/gen-ai-link-icon-pc-250804.svg)](https://network.mobile.rakuten.co.jp/chat/?l-id=assist-ai)
![閉じる](https://network.mobile.rakuten.co.jp/assets/img/common/gen-ai-close.svg)

日本語

English
