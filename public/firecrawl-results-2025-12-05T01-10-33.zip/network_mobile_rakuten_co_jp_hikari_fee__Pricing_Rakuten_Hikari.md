# Pricing | Rakuten Hikari

URL: https://network.mobile.rakuten.co.jp/hikari/fee/

---

[![Rakuten Mobile](https://cdn.rmc.contents.rakuten.co.jp/block/d40535ac09aac0ef32f8a23b8bb8e04bc2e8f9d6b0981fa98a16d0382f558d83/d72cbeb1-1b70-4fb2-b7e5-cb3c0a24841f/card20k_enddate_pc_1440x50.png)](https://cdn.rex.contents.rakuten.co.jp/webcx-redirect-module/1.3.0/index.html?clientId=d40535ac09aac0ef32f8a23b8bb8e04bc2e8f9d6b0981fa98a16d0382f558d83&version=2.73.0&sessionId=0b5273c1-4c5d-4e10-9bcc-ab9c40883930&screen=WB&issueId=F01184-001256&campaignId=2aadf4f2-55c7-4337-8472-22f617277367&contentId=4382487a-283f-4306-b0d1-11d8c70206b1&replacementId=9354c015-1ef6-41d2-8298-0bf372a98402&impressionId=9c67724e-d4e2-4d49-950c-986f654c721c&selector=mkdiv_header_pitari&redirect=aHR0cHM6Ly9yZC5yYWt1dGVuLmNvLmpwL3JhdD9SMj1odHRwczovL25ldHdvcmsubW9iaWxlLnJha3V0ZW4uY28uanAvY2FtcGFpZ24vY2FyZC1tb2JpbGUtbWFqaXRva3UvJTNGc2NpZCUzRHdpX3JtYl9ybWJfbWtkaXZfaGVhZGVyX3BpdGFyaV9jbW9fcGNfbmV3LWNhcmQtbm8td2ViY3hfY2FyZC1tb2JpbGUtbWFqaXRva3VfMjAyNTEyMDEmYWNjPTEzMTImYWlkPTEmZXR5cGU9Y2xpY2smc3NjPWNyb3NzdXNlX2NhbXBhaWduJnBnbj1jbW9fcGl0YXJpJnJlZj1odHRwczovL25ldHdvcmsubW9iaWxlLnJha3V0ZW4uY28uanAvaGlrYXJpL2ZlZS9wcmljZWxpc3QvJnRhcmdldF9lbGU9bmV3LWNhcmQtbm8td2ViY3hfY2FyZC1tb2JpbGUtbWFqaXRva3VfMjAyNTEyMDE=&origin=aHR0cHM6Ly9uZXR3b3JrLm1vYmlsZS5yYWt1dGVuLmNvLmpw)

[![Rakuten Mobile](https://network.mobile.rakuten.co.jp/assets/img/hikari/common-v2/header-logo-pink.svg)](https://network.mobile.rakuten.co.jp/?wovn=en&l-id=rhk_header_mno_01)

[Rakuten Mobile](https://network.mobile.rakuten.co.jp/?wovn=en&l-id=rhk_header_mno_02)
 ​ ​| ​ ​[Rakuten Turbo](https://network.mobile.rakuten.co.jp/internet/turbo/?wovn=en&l-id=rhk_header_mno_internet_turbo_01)
 ​ ​|

Language

*   日本語
*   English
*   简体中文
*   繁體中文
*   한국어
*   tiếng việt
*   Indonesia
*   português

[![Rakuten Hikari](https://network.mobile.rakuten.co.jp/assets/img/hikari/common-v2/header-logo-white.svg)](https://network.mobile.rakuten.co.jp/hikari/?wovn=en&l-id=rhk_gheader_top_01)

Search

[Member page](https://ms.fusioncom.co.jp/rbb/members/login?campaign=web-rakuten&l-id=rhk_gheader_ecare&_ebx=g1rjgkpzt4.1693291119.7s1i0ki)

[Apply Now](https://secure3.gol.com/mod-pl/rbb/rmch.cgi?scode=qngTI9rXJpRlc1l6roM&cpnkind=set2512h8&l-id=rhk_header_onb&ratck=Rp%3Db8676323b471e3fa1a1e4ec83f69322f9ebf62a)

Menu

*   Price
    
    *   [Price simulation](https://network.mobile.rakuten.co.jp/hikari/fee/simulation/?wovn=en&l-id=rhk_gheader_fee_simulation_01)
        
    *   [Price](https://network.mobile.rakuten.co.jp/hikari/fee/pricelist/?wovn=en&l-id=rhk_gheader_fee_pricelist_01)
        
    
*   Campaigns
    
    *   [Rakuten Hikari SAIKYO HOME Program](https://network.mobile.rakuten.co.jp/hikari/campaign/home-internet/?wovn=en&l-id=rhk_gheader_campaign_home-internet_01)
        
    *   [SPU (Super Point Up Program)](https://network.mobile.rakuten.co.jp/internet/turbo/campaign/spu/?wovn=en&l-id=rhk_gheader_mno_internet_turbo_campaign_spu_01)
        
    *   [Previous Campaign Rules](https://network.mobile.rakuten.co.jp/hikari/campaign/archive/?wovn=en&l-id=rhk_gheader_campaign_archive_01)
        
    
*   Those Considering Switching
    
    *   [Steps to Get Started](https://network.mobile.rakuten.co.jp/hikari/flow/?wovn=en&l-id=rhk_gheader_flow_01)
        
    *   [Speedy and stable](https://network.mobile.rakuten.co.jp/hikari/internet/?wovn=en&l-id=rhk_gheader_internet_01)
        
    
*   News & Support
    
    *   [News](https://network.mobile.rakuten.co.jp/hikari/information/?wovn=en&l-id=rhk_gheader_information_01)
        
    *   [Customer Support](https://network.mobile.rakuten.co.jp/hikari/support/?wovn=en&l-id=rhk_gheader_support_01)
        
    

*   [Top](https://network.mobile.rakuten.co.jp/hikari/?wovn=en&l-id=rhk_bct_top_01)
    
*   Price

\*The amounts listed are all incl. tax, unless otherwise specified.

よく検索されるワード
----------

検索履歴
----

[Apply](https://secure3.gol.com/mod-pl/rbb/rmch.cgi?scode=qngTI9rXJpRlc1l6roM&cpnkind=set2512h8&l-id=rhk_gmenu_onb&ratck=Rp%3Db8676323b471e3fa1a1e4ec83f69322f9ebf62a)
 ​ ​[Member page](https://ms.fusioncom.co.jp/rbb/members/login?campaign=web-rakuten&l-id=rhk_gmenu_ecare&_ebx=g1rjgkpzt4.1693291119.7s1i0ki)

*   Price
    
*   Campaigns
    
*   Those Considering Switching
    
*   News & Support
    
*   Language
    

[See Rakuten Turbo](https://network.mobile.rakuten.co.jp/internet/turbo/?wovn=en&l-id=rhk_gmenu_mno_internet_turbo_01)

[See Rakuten Mobile](https://network.mobile.rakuten.co.jp/?wovn=en&l-id=rhk_gmenu_mno_03)

Price

*   [Price simulation](https://network.mobile.rakuten.co.jp/hikari/fee/simulation/?wovn=en&l-id=rhk_gmenu_fee_simulation_01)
    
*   [Price](https://network.mobile.rakuten.co.jp/hikari/fee/pricelist/?wovn=en&l-id=rhk_gmenu_fee_pricelist_01)
    

Campaign

*   [Rakuten Hikari SAIKYO HOME Program](https://network.mobile.rakuten.co.jp/hikari/campaign/home-internet/?wovn=en&l-id=rhk_gmenu_campaign_home-internet_01)
    
*   [SPU (Super Point Up Program)](https://network.mobile.rakuten.co.jp/internet/turbo/campaign/spu/?wovn=en&l-id=rhk_gmenu_mno_internet_turbo_campaign_spu_01)
    
*   [Previous Campaign Rules](https://network.mobile.rakuten.co.jp/hikari/campaign/archive/?wovn=en&l-id=rhk_gmenu_campaign_archive_01)
    

Those Considering Switching

*   [Steps to Get Started](https://network.mobile.rakuten.co.jp/hikari/flow/?wovn=en&l-id=rhk_gmenu_flow_01)
    
*   [Speedy and stable](https://network.mobile.rakuten.co.jp/hikari/internet/?wovn=en&l-id=rhk_gmenu_internet_01)
    

News & 

*   [News](https://network.mobile.rakuten.co.jp/hikari/information/?wovn=en&l-id=rhk_gmenu_information_01)
    
*   [Customer Support](https://network.mobile.rakuten.co.jp/hikari/support/?wovn=en&l-id=rhk_gmenu_support_01)
    

Language

*   日本語
    
*   English
    
*   简体中文
    
*   繁體中文
    
*   한국어
    
*   tiếng việt
    
*   Indonesia
    
*   português
    

Choose your language for Rakuten Mobile !
-----------------------------------------

Our services are provided within the region and laws of Japan.

日本語 English 简体中文 繁體中文 한국어 tiếng việt Indonesia português

Select Language

Our services are provided within the region and laws of Japan and we provide translations for your convenience.  
The Japanese version of our websites and applications, in which include Rakuten Membership Rules, Privacy Policy or other terms and conditions, is the definitive version , unless otherwise indicated.  
If there are any discrepancies, the Japanese version shall prevail.  
We do not guarantee that we always provide translation.  
The Japanese versions of all terms and conditions, policies, and other notices are the definitive versions. Any dispute related to the terms and conditions, policies, or other notices will be under the jurisdiction of Japanese law, regardless of any conflicting laws or principles.  
Certain features or messages (including customer services) may not be available in the selected language.

Enjoy Rakuten Mobile in English!
--------------------------------

Our services are provided within the region and laws of Japan and we provide translations for your convenience.  
The Japanese version of our websites and applications, in which include Rakuten Membership Rules, Privacy Policy or other terms and conditions, is the definitive version , unless otherwise indicated.  
If there are any discrepancies, the Japanese version shall prevail.  
We do not guarantee that we always provide translation.  
The Japanese versions of all terms and conditions, policies, and other notices are the definitive versions. Any dispute related to the terms and conditions, policies, or other notices will be under the jurisdiction of Japanese law, regardless of any conflicting laws or principles.  
Certain features or messages (including customer services) may not be available in the selected language.

Price
=====

*   [Monthly basic fee](https://network.mobile.rakuten.co.jp/hikari/fee/#month)
    
*   [Initial registration fee](https://network.mobile.rakuten.co.jp/hikari/fee/#initialcost)
    
*   [Construction cost](https://network.mobile.rakuten.co.jp/hikari/fee/#construction)
    
*   [Options](https://network.mobile.rakuten.co.jp/hikari/fee/#option)
    
*   [Payment methods](https://network.mobile.rakuten.co.jp/hikari/fee/#payment)
    
*   [Contract cancellation fee](https://network.mobile.rakuten.co.jp/hikari/fee/#cancellationfee)
    

Monthly basic fee
-----------------

 
| Plan name | Monthly fee |
| --- | --- |
| Apartment Plan  <br>(Multi-unit building) | 3,800 yen (4,180 yen incl. tax) |
| Family Plan  <br>(House) | 4,800 yen (5,280 yen incl. tax) |

*   Even if you apply in the middle of the month, the first month will be free without prorated calculation.
*   We will clearly state the contract period and Contract cancellation fee on our website.

\*Contract period, Contract cancellation fee, and the period during which you can cancel for free vary depending on the campaign. For details, please refer to the campaign rules, the “Contract Information” email, or the Members’ Station.

Initial registration fee
------------------------

 
| Contract status | Initial registration fee |
| --- | --- |
| Those who do not use FLET'S HIKARI \*1 | ¥880 (incl. tax) |
| For those currently using FLET'S HIKARI (reuse) \*2 | ¥1,980 (incl. tax) |
| Currently using another provider's Hikari Collaboration (Business Transfer) \*3 | ¥1,980 (incl. tax) |

\*1 Those with no internet line contract, using a fiber optic line other than FLET'S HIKARI (e.g., NURO HIKARI, au HIKARI, SoftBank Air, cable TV internet, power company optical line, mobile Wi-Fi, etc.), or using an ADSL line.  
\*2 Those using FLET'S HIKARI and a provider (for those who wish to transfer).  
\*3 Those using another company's optical collaboration (e.g., SoftBank HIKARI, docomo HIKARI, OCN HIKARI, plala HIKARI, BIGLOBE HIKARI, So-net HIKARI Plus, etc.) and wish to change operators.

Installation fee
----------------

The installation fee is the total amount of standard installation cost for first-time fiber optic line users, plus additional installation costs for specified times or days.

### Standard installation fee

#### Apartment Plan (Multi-unit building)

   
|     | Construction by subcontractors |     | No dispatch construction |
| --- | --- | --- | --- |
| Wiring adjustment included | No wiring adjustments needed. |
| --- | --- | --- | --- |
| Lump-sum payment | ¥22,000 (incl. tax) | ¥11,660 (incl. tax) | 3,300 yen (incl. tax) |
| Installments (24) | ¥916 (incl. tax) / month\*1 | ¥485 (incl. tax) / month\*2 | 137 yen (incl. tax) / month\*3 |

Scroll down

#### Family Plan (House)

   
|     | Construction by subcontractors |     | No dispatch construction |
| --- | --- | --- | --- |
| Wiring adjustment included | No wiring adjustments needed. |
| --- | --- | --- | --- |
| Lump-sum payment | ¥22,000 (incl. tax) | ¥11,660 (incl. tax) | 3,300 yen (incl. tax) |
| Installments (24) | ¥916 (incl. tax) / month\*1 | ¥485 (incl. tax) / month\*2 | 137 yen (incl. tax) / month\*3 |

Scroll down

\*1 ¥932 will be charged in the final month. \*2 ¥505 will be charged in the final month. \*3 ¥149 will be charged in the final month.

\*The need for dispatched installation work, the installation of indoor wiring, and the cost of construction may vary depending on the environmental conditions of the installation site.

\*Even if there are existing wires in the building, the cost of the work may be the same as that for installing new wires due to reconnection or adjustment work in shared facilities (e.g., MDF room).

\*If you apply before June 30, 2022, the number of construction payments and the payment amount may differ.

#### Contractor change or transfer construction costs

We generally do not perform any construction work. However, the following types of construction work and associated costs may be incurred due to changes in NTT East/NTT West line types or device changes.

   
|     | Construction by subcontractors | No dispatch construction | No installation required. |
| --- | --- | --- | --- |
| Line type /  <br>Device change | Line type /  <br>Device change | Line type /  <br>Device unchanged |
| --- | --- | --- | --- |
| Lump-sum payment | ¥11,660 (incl. tax) | 3,300 yen (incl. tax) | 0 yen |
| Installments (24) | ¥485 (incl. tax) / month\*4 | 137 yen (incl. tax) / month\*5 | \-  |

Scroll down

\*4 ¥505 will be charged in the final month.

\*5 ¥149 will be charged in the final month.

\*If you apply before June 30, 2022, the number of construction payments and the payment amount may differ.

### If you want to specify the time and day  
(Additional construction cost / Overtime construction cost)

If you want to specify the time or day of the installation, the following additional charges will apply.

#### If you want to specify a time slot

 
| Time slot /  <br>1 hour selectable | Amount |
| --- | --- |
| Daytime (9:00~16:00) | ¥12,100 (incl. tax) |
| Evening (17:00~21:00) | East Japan Area 19,800 yen (incl. tax)  <br>West Japan Area 22,000 yen (incl. tax) |
| Night (22:00~8:00) | East Japan Area 30,800 yen (incl. tax)  <br>West Japan Area 33,000 yen (incl. tax) |

#### For night or late-night requests

 
| Time slot | Amount |
| --- | --- |
| Evening (17:00~22:00) | (Daytime construction cost - ¥1,100) × 1.3 times + ¥1,100 (incl. tax) |
| Late night (22:00~8:30) | (Daytime construction cost - ¥1,100) × 1.6 times + ¥1,100 (incl. tax) |

#### If you prefer weekends or holidays

 
| Date and time | Amount |
| --- | --- |
| Sat, Sun & Holidays | 3,300 yen (incl. tax) |

\*NTT West Japan area: If the total amount of construction costs exceeds 31,900 yen, an additional 3,850 yen will be charged for every 31,900 yen.

If you move to a new address and want to keep your Rakuten Hikari subscription

### Transfer construction fee

In principle, you will pay the installation fee together with your usage fee in the month following the installation completion date.

※For relocation construction costs due to work done after July 1, 2025, you will need to pay the entire amount at once.

#### Moving within the same area (East Japan or West Japan)

  
| Construction details |     | Amount |
| --- | --- | --- |
| Indoor wiring adjustment included | Detached house | ¥11,000 (incl. tax) |
| Apartment building | ¥11,000 (incl. tax) |
| No indoor wiring adjustments needed. | \-  | ¥9,900 (incl. tax) |
| No dispatch construction |     | 3,300 yen (incl. tax) |

#### Moving from the East Japan area to the West Japan area (or vice versa)

  
| Construction details |     | Amount |
| --- | --- | --- |
| Indoor wiring adjustment included | Detached house | ¥22,000 (incl. tax) |
| Apartment building | ¥22,000 (incl. tax) |
| No indoor wiring adjustments needed. | \-  | ¥11,660 (incl. tax) |
| No dispatch construction |     | 3,300 yen (incl. tax) |

#### NTT line type, cost of changing NTT equipment

|     |     |
| --- | --- | 
| Item change | 3,300 yen (incl. tax) |

#### Transfer registration fee

 
| Contract status | Transfer registration fee |
| --- | --- |
| Moving from the East Japan area to the West Japan area (or vice versa) | ¥880 (incl. tax) |

\*No transfer registration fee applies for moves within the same area (East Japan to East Japan or West Japan to West Japan).

When a fee is required

#### Administrative fee

  
| Payment method | Item | Amount |
| --- | --- | --- |
| Bank transfer | Automatic bank transfer service fee | 110 yen (incl. tax) |
| Bank transfer invoice/receipt issuance fee (bank transfer) | 110 yen (incl. tax) |
| Over-the-counter payment | Invoice issuance fee (over-the-counter payment) | ¥220 (incl. tax) |
| Credit card | Credit card administrative fee | Free |

\*If you use invoices or receipts by bank transfer, a total fee of 220 yen will be charged.

When the standard installation fee is waived

When switching from ADSL to Rakuten Hikari, the standard installation fee will be waived if the following conditions are met:

\*As of November 25, 2021

\*Campaign benefits are subject to change or cancellation without prior notice.

|     |     |
| --- | --- | 
| East Japan Area | Your information must be verifiable by NTT East through your use of FLET’S ADSL or FLET’S ISDN. Alternatively, you must have applied through one of the following providers, and your service and contract ID must be confirmed as active as of the end of November 2017.<br><br>Applicable Service Providers<br><br>SoftBank Corp., TOKAI Communications Corporation, Naganoken Kyodo Densan Co.,Ltd., Niigata Tsuushin Service Corporation, Iida Cable Television, Sayama Cable Television, Gyoda Cable Television, Academic Newtown Community Cable Service, NTT East |
| Western Japan Area | For users of FLET’S ADSL or FLET’S ISDN, your information must be verifiable by NTT West Japan. Alternatively, you must apply through one of the following service providers, with your service and contract ID confirmed as active as of September 2018.<br><br>Applicable Service Providers<br><br>SoftBank Corp., TOKAI Communications Corporation, Miyako Television Co., Ltd., Izumo Cable Vision, Inc., NTT West Corporation |

Options
-------

  
| Options | Monthly fee | Service Details |
| --- | --- | --- |
| [Phone Setup Support](https://network.mobile.rakuten.co.jp/hikari/fee/option/remote-support/?wovn=en&l-id=rhk_fee_option_remote-support_01) | ¥2,200 incl. tax / time \*1 | We provide support for internet connection issues on PCs and smartphones via phone or a dedicated remote tool.<br><br>\*“Phone Settings Support” is operated by SourceNext Co., Ltd. |
| [Super Security Multi-Platform Edition](https://network.mobile.rakuten.co.jp/hikari/fee/option/super-security/?wovn=en&l-id=rhk_fee_option_super-security_01) | Monthly 385 yen (incl. tax) \*2 | Security software equipped with the Bitdefender engine, offering both strong protection and lightweight performance. Available for use on up to 3 devices, with flexible combinations of Windows, Mac, and Android. |
| [Free email address](https://network.mobile.rakuten.co.jp/hikari/fee/option/free-mail/?wovn=en&l-id=rhk_fee_option_free-mail_01) | Free | Up to 10 email addresses available |
| [Mail Plus](https://network.mobile.rakuten.co.jp/hikari/fee/option/free-mail-plus/?wovn=en&l-id=rhk_fee_option_free-mail-plus_01) | 1,024MB: 506 yen (incl. tax)  <br>2,048MB: 1,012 yen (incl. tax)  <br>3,072MB: 1,518 yen (incl. tax) | A service that allows you to add extra capacity to your mailbox. You can increase the standard 200MB up to a maximum of 3,072MB.<br><br>\*Email addresses containing the domains "sannet.ne.jp" or "inet-osaka.or.jp" are not eligible for Mail Plus applications. |
| [Virus Filter Service](https://network.mobile.rakuten.co.jp/hikari/fee/option/virus-filter/?wovn=en&l-id=rhk_fee_option_virus-filter_01) | Free | A service that prevents virus infections via email. |
| [Advanced Spam Filter](https://network.mobile.rakuten.co.jp/hikari/fee/option/advanced-spam-filter/?wovn=en&l-id=rhk_fee_option_advanced-spam-filter_01) | Free | Advanced filtering enabled by learning function. A service that prevents spam emails on a per-server basis. |
| Wireless LAN card | East Japan Area: 330 yen/month (incl. tax)  <br>West Japan Area: 110 yen/month (incl. tax) | Wireless connection supporting 802.11ac with a maximum speed of 866 Mbps is available.<br><br>\*This service is provided on a best-effort basis. High speed and constant connectivity are not guaranteed and may vary depending on the situation. |
| NTT Home Gateway Equipment Rental | Monthly ¥220 (incl. tax) | ONU-integrated router compatible with wireless LAN card |
| Remote support  <br>[NTT East](https://flets.com/osa/remote/s_outline.html)<br>  <br>[NTT West](https://flets-w.com/opt/remote_support/) | ¥550 (incl. tax) | A support service provided by NTT East and NTT West. Offers guidance on internet connection settings, Wi-Fi settings for smartphones and tablets, and installation and operation of applicable software, available 365 days a year. |
| [Hikari Denwa](https://network.mobile.rakuten.co.jp/hikari/fee/option/hikari-denwa/?wovn=en&l-id=rhk_fee_option_hikari-denwa_01)<br>  <br>[NTT East Hikari Denwa](https://flets.com/hikaridenwa/order/)<br>  <br>[NTT West Hikari Denwa](https://flets-w.com/opt/hikaridenwa/#anchor03) | Charges for Rakuten Mobile services are billed by NTT East Japan or NTT West Japan. | Hikari Denwa requires a contract with NTT East Japan or NTT West Japan. |
| FLET’S TV  <br>[NTT East FLET’S TV](https://flets.com/ftv/order/)<br>  <br>[NTT West FLET’S TV](https://flets-w.com/opt/ftv/) | Charges for Rakuten Mobile services are billed by NTT East Japan or NTT West Japan. | FLET’S TV is contracted with NTT East Japan or NTT West Japan. |

\*1 One free support session is available within 60 days of your installation date.

\*2 Free for 12 months per subscriber.

\*If you're already a Rakuten Hikari subscriber and want to learn more about your current option services, please check the Members Station.

Scroll down

Payment methods
---------------

  
| Payment methods |     | Fees |
| --- | --- | --- |
| Credit card | Visa  /  Master  /  JCB  /  American Express  /  Diners Club  <br>Earn Points with Rakuten Card!  <br>[Learn More About Rakuten Card](https://www.rakuten-card.co.jp/) | Free |
| Debit card | Rakuten Bank Debit Card | Free |
| Bank transfer | Rakuten Bank | Free |
| Other banks  /  Shinkin banks  /  Credit unions  /  JA  /  Japan Post Bank | ¥110 (incl. tax) / month |

### Notes

*   If you do not register a credit card or bank account, we will issue a counter payment invoice for a fee (220 yen).
*   When applying for Rakuten Hikari online, payment methods are limited to credit card or Rakuten Bank direct debit. If you wish to pay through a financial institution other than Rakuten Bank, after applying, [Members Station](https://ms.fusioncom.co.jp/rbb/members/login?campaign=web-rakuten?l-id=rhk_ecare_01)
     Please request bank transfer request form from the "Request for Various Materials" page.
*   If you are already using Rakuten Hikari and have not registered a payment method, please register through the [Members Station](https://ms.fusioncom.co.jp/rbb/members/login?campaign=web-rakuten?l-id=rhk_ecare_02)
    .
*   Please note that any "Suruga Bank Debit Card" issued after February 2022 cannot be used. Cards issued before January 2022 will no longer be accepted as of Tuesday, January 31, 2023.
*   For customers who have been automatically migrated from SANNET, no bank transfer fees will be charged.

|     |     |
| --- | --- | 
| Credit card  <br>Free of charge | Visa  /  Master  /  JCB  /  American Express  /  Diners Club  <br>Earn Points with Rakuten Card!  <br>​ ​[Learn More About Rakuten Card](https://www.rakuten-card.co.jp/) |
| Debit card  <br>Free of charge | Rakuten Bank Debit Card |
| Bank transfer  <br>Free of charge | Rakuten Bank |
| Bank transfer  <br>Fee 110 yen/mo. | Other banks  /  Shinkin banks  /  Credit unions  /  JA  /  Japan Post Bank |

### Notes

*   If you do not register a credit card or bank account, we will issue a counter payment invoice for a fee (220 yen).
*   When applying for Rakuten Hikari online, payment methods are limited to credit card or Rakuten Bank direct debit. If you wish to pay through a financial institution other than Rakuten Bank, after applying, [Members Station](https://ms.fusioncom.co.jp/rbb/members/login?campaign=web-rakuten?l-id=rhk_ecare_01)
     Please request bank transfer request form from the "Request for Various Materials" page.
*   If you are already using Rakuten Hikari and have not registered a payment method, please register through the [Members Station](https://ms.fusioncom.co.jp/rbb/members/login?campaign=web-rakuten?l-id=rhk_ecare_02)
    .
*   Please note that Suruga Bank debit cards issued after February 2022 cannot be used. Cards issued before January 2022 will no longer be accepted as of Tuesday, January 31, 2023.
*   For customers who have been automatically migrated from SANNET, no bank transfer fees will be charged.

Contract cancellation fee
-------------------------

 
| Plan name | Contract cancellation fee |
| --- | --- |
| Apartment Plan  <br>(Multi-unit building) | ¥3,800  <br>(¥4,180 incl. tax) |
| Family Plan  <br>(House) | 4,800 yen  <br>(5,280 yen incl. tax) |

\*For customers who completed their application before June 30, 2022, the Contract cancellation fee varies depending on the period. Please check the Members Station or the “Contract Information” for details.

### NTT East/NTT West Rental Equipment Charges

If you do not return the rental equipment after we receive your cancellation request that involves line removal, you will be required to pay the following amount.

\*The billed amount listed is a cap and may differ from the actual billed amount calculated by us based on the usage period and other factors.

  
| NTT Rental Equipment |     | Billing amount (ceiling, non-taxable) |
| --- | --- | --- |
| Optical Network Unit (ONU) |     | 14,000 yen |
| VDSL indoor unit |     | 3,000 yen |
| Wireless LAN router function  <br>Router function connection device | Basic device | 12,000 yen |
| Additional wireless LAN card | 1,000 yen |
| Hikari Denwa-compatible router | Basic device | 12,000 yen |
| Additional wireless LAN card | 1,000 yen |
| Office type compatible adapter (VG・OG) 4xx／8xx |     | 58,000 yen |
| Office type compatible adapter (VG・OG) 23xx series |     | 360,000 yen |
| Video line terminal device |     | 12,000 yen |

Scroll down

### Monthly payment timing

Rakuten Hikari fees are charged in the month you start using the service and billed the following month.

For payment by credit card, the billing amount is finalized in mid-month of the month following usage. The withdrawal date from your account varies depending on the credit card company.

For bank transfer, the payment will be deducted from your account on the 27th of the month following the usage.

 ![Example](https://network.mobile.rakuten.co.jp/assets/en/img/hikari/fee/pricelist/img-table-03-pc.png)

Both Rakuten Turbo and Hikari offer great deals!
------------------------------------------------

[![Join Rakuten Turbo & use Rakuten Mobile for a lifetime of 1,000 point rebates monthly※Time-limited points. Conditions apply.](https://network.mobile.rakuten.co.jp/assets/en/img/hikari/bnr/bnr-set-plan-turbo-328-185-20250730.png)](https://network.mobile.rakuten.co.jp/internet/turbo/campaign/home-internet/?wovn=en&l-id=rhk_hikari_fee_pricelist_internet_turbo_campaign_home-internet_01)

[![Get 1,000 point rebates every month for life when you apply for Rakuten Hikari for the first time & use Rakuten Mobile.※Time-limited points. Conditions apply.](https://network.mobile.rakuten.co.jp/assets/en/img/hikari/bnr/bnr-set-plan-hikari-328-185-20250730.png)](https://network.mobile.rakuten.co.jp/hikari/campaign/home-internet/?wovn=en&l-id=rhk_hikari_fee_pricelist_hikari_campaign_home-internet_01)

### Learn More About Rakuten Hikari

[![](https://network.mobile.rakuten.co.jp/assets/img/hikari/common-v2/footer-simulation.png)\
\
Price simulation](https://network.mobile.rakuten.co.jp/hikari/fee/simulation/?wovn=en&l-id=rhk_footer_fee_simulation_01)
[![](https://network.mobile.rakuten.co.jp/assets/img/hikari/common-v2/footer-speed.png)\
\
Speedy and stable  \
IPv6 communication](https://network.mobile.rakuten.co.jp/hikari/internet/?wovn=en&l-id=rhk_footer_internet_01)
[![](https://network.mobile.rakuten.co.jp/assets/img/hikari/common-v2/footer-flow.png)\
\
Steps to Get Started  \
​](https://network.mobile.rakuten.co.jp/hikari/flow/?wovn=en&l-id=rhk_footer_flow_01)
[![](https://network.mobile.rakuten.co.jp/assets/img/hikari/common-v2/footer-support.png)\
\
Customer Support](https://network.mobile.rakuten.co.jp/hikari/support/?wovn=en&l-id=rhk_footer_support_01)

Was this page easy to understand?

1

2

3

4

5

Hard to understand

It was easy to understand.

[![](https://network.mobile.rakuten.co.jp/assets/img/hikari/common-v2/backtop.svg)\
\
Back to top](https://network.mobile.rakuten.co.jp/hikari/fee/#)

*   [Top](https://network.mobile.rakuten.co.jp/hikari/?wovn=en&l-id=rhk_bcb_top_01)
    
*   Price

*   [Company Overview](https://corp.mobile.rakuten.co.jp/)
    
*   [Handling of Personal Information](https://corp.mobile.rakuten.co.jp/guide/privacy/)
    
*   [Handling of Information Sent to External Parties](https://network.mobile.rakuten.co.jp/optout/?wovn=en&l-id=rhk_footer_mno_optout_01)
    
*   [Information Security Policy](https://corp.mobile.rakuten.co.jp/guide/security/)
    
*   [Trademarks and Registered Trademarks](https://corp.mobile.rakuten.co.jp/guide/trademark/)
    
*   [Terms of Use & important notices](https://network.mobile.rakuten.co.jp/hikari/terms/?wovn=en&l-id=rhk_footer_terms_01)
    
*   [Rakuten Group Customer Harassment Response Policy](https://corp.rakuten.co.jp/sustainability/human-rights/customer-harassment/)
    

© Rakuten Mobile, Inc.

[![Rakuten Mobile](https://cdn.rmc.contents.rakuten.co.jp/block/d40535ac09aac0ef32f8a23b8bb8e04bc2e8f9d6b0981fa98a16d0382f558d83/d72cbeb1-1b70-4fb2-b7e5-cb3c0a24841f/card20k_enddate_pc_1440x50.png)](https://cdn.rex.contents.rakuten.co.jp/webcx-redirect-module/1.3.0/index.html?clientId=d40535ac09aac0ef32f8a23b8bb8e04bc2e8f9d6b0981fa98a16d0382f558d83&version=2.73.0&sessionId=0b5273c1-4c5d-4e10-9bcc-ab9c40883930&screen=WB&issueId=F01184-001256&campaignId=2aadf4f2-55c7-4337-8472-22f617277367&contentId=4382487a-283f-4306-b0d1-11d8c70206b1&replacementId=81db9e56-ef96-4d72-a17a-b0e4899e9bca&impressionId=9c67724e-d4e2-4d49-950c-986f654c721c&selector=mkdiv_footer_pitari&redirect=aHR0cHM6Ly9yZC5yYWt1dGVuLmNvLmpwL3JhdD9SMj1odHRwczovL25ldHdvcmsubW9iaWxlLnJha3V0ZW4uY28uanAvY2FtcGFpZ24vY2FyZC1tb2JpbGUtbWFqaXRva3UvJTNGc2NpZCUzRHdpX3JtYl9ybWJfbWtkaXZfZm9vdGVyX3BpdGFyaV9jbW9fcGNfbmV3LWNhcmQtbm8td2ViY3hfY2FyZC1tb2JpbGUtbWFqaXRva3VfMjAyNTEyMDEmYWNjPTEzMTImYWlkPTEmZXR5cGU9Y2xpY2smc3NjPWNyb3NzdXNlX2NhbXBhaWduJnBnbj1jbW9fcGl0YXJpJnJlZj1odHRwczovL25ldHdvcmsubW9iaWxlLnJha3V0ZW4uY28uanAvaGlrYXJpL2ZlZS9wcmljZWxpc3QvJnRhcmdldF9lbGU9bmV3LWNhcmQtbm8td2ViY3hfY2FyZC1tb2JpbGUtbWFqaXRva3VfMjAyNTEyMDE=&origin=aHR0cHM6Ly9uZXR3b3JrLm1vYmlsZS5yYWt1dGVuLmNvLmpw)

*   Rakuten Group
*   [Services](https://www.rakuten.co.jp/sitemap/)
    
*   [Contact (us, form, etc..) list](https://www.rakuten.co.jp/sitemap/inquiry.html)
    
*   [SUSTAINABILITY](https://corp.rakuten.co.jp/sustainability/)
    

  

日本語

English
