# 初期設定サポートについて｜店舗｜格安スマホ・格安SIM【mineo(マイネオ)】

URL: https://mineo.jp/support/billing/

---

[![格安SIM・格安スマホのmineo](https://mineo.jp/asset/img/common/template/logo_mineo_white.png)](https://mineo.jp/)

*   [法人のお客さま](https://mineo.jp/r/biz/link_header.html)
    
*   [お知らせ](https://mineo.jp/#info)
    
*   [キャンペーン](https://mineo.jp/campaign/)
    
*   [特集](https://mineo.jp/special/)
    
*        ![検索](https://mineo.jp/asset/img/common/icon_search.png)
    

*   [![](https://mineo.jp/asset/img/common/template/icon_menu_feature.png)\
    \
    mineoの  \
    特長](https://mineo.jp/support/billing/#header-menu-feature)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_service.png)\
    \
    料金・  \
    サービス](https://mineo.jp/support/billing/#header-menu-service)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_device.png)\
    \
    端末](https://mineo.jp/support/billing/#header-menu-device)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_shop.png)\
    \
    店舗](https://mineo.jp/support/billing/#header-menu-shop)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_guide.png)\
    \
    申込ガイド](https://mineo.jp/support/billing/#header-menu-guide)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_support.png)\
    \
    サポート](https://mineo.jp/support/billing/#header-menu-support)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_king.png)\
    \
    コミュニティ](https://mineo.jp/support/billing/#header-menu-king)
    

*   [![](https://mineo.jp/asset/img/common/template/icon_mypage.png)\
    \
    マイページ](https://my.mineo.jp/)
    
*    [![](https://mineo.jp/asset/img/common/template/icon_apply_wh.png) ![](https://mineo.jp/asset/img/common/template/icon_apply_pink.png)\
    \
    お申し込み](https://mineo.jp/apply/)
    

メニュー

[![格安SIM・格安スマホのmineo](https://mineo.jp/asset/img/common/template/logo_mineo.png)](https://mineo.jp/)

*   [![](https://mineo.jp/asset/img/common/template/icon_menu_feature.png)\
    \
    mineoの  \
    特長](https://mineo.jp/support/billing/#header-menu-feature)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_service.png)\
    \
    料金・  \
    サービス](https://mineo.jp/support/billing/#header-menu-service)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_device.png)\
    \
    端末](https://mineo.jp/support/billing/#header-menu-device)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_shop.png)\
    \
    店舗](https://mineo.jp/support/billing/#header-menu-shop)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_guide.png)\
    \
    申込ガイド](https://mineo.jp/support/billing/#header-menu-guide)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_support.png)\
    \
    サポート](https://mineo.jp/support/billing/#header-menu-support)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_king.png)\
    \
    コミュニティ](https://mineo.jp/support/billing/#header-menu-king)
    

*   [![](https://mineo.jp/asset/img/common/template/icon_mypage.png)\
    \
    マイページ](https://my.mineo.jp/)
    
*    [![](https://mineo.jp/asset/img/common/template/icon_apply_wh.png) ![](https://mineo.jp/asset/img/common/template/icon_apply_pink.png)\
    \
    お申し込み](https://mineo.jp/apply/)
    

![](https://mineo.jp/asset/img/common/template/header_mark.png)

閉じる

     ![検索](https://mineo.jp/asset/img/common/icon_search.png)

*   [![](https://mineo.jp/asset/img/common/template/icon_mypage.png)\
    \
    マイページ](https://my.mineo.jp/)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_apply_wh.png)\
    \
    お申し込み](https://mineo.jp/apply/)
    

![](https://mineo.jp/asset/img/common/template/icon_menu_feature.png)

mineoの特長

[はじめての方へ](https://mineo.jp/beginner/)
 [mineoが選ばれる理由](https://mineo.jp/reason/)
 [Fun with Fans！](https://mineo.jp/brand/)

![](https://mineo.jp/asset/img/common/template/icon_menu_service.png)

料金・サービス

[料金表](https://mineo.jp/price/)
 [サービス・オプション一覧](https://mineo.jp/service/)
 [かんたん料金シミュレーション](https://mineo.jp/simulator/)

[![](https://mineo.jp/asset/img/common/template/icon_menu_campaign.png)\
\
キャンペーン](https://mineo.jp/campaign/)

![](https://mineo.jp/asset/img/common/template/icon_menu_device.png)

端末

[mineoで使う端末を選ぶ](https://mineo.jp/device/about/)
 [iPhone](https://mineo.jp/device/iphone/)
 [スマートフォン](https://mineo.jp/device/smartphone/)
 [タブレット・ルーター](https://mineo.jp/device/other/)
 [動作確認済み端末検索](https://mineo.jp/device/devicelist/)

![](https://mineo.jp/asset/img/common/template/icon_menu_shop.png)

店舗

[店舗を探す](https://mineo.jp/shop/)
 [店舗でできること](https://mineo.jp/shop/about/)
 [店舗でSIMを受け取る](https://mineo.jp/shop/online/counter/)

![](https://mineo.jp/asset/img/common/template/icon_menu_guide.png)

申込ガイド

[お手持ちの端末をそのまま使う方](https://mineo.jp/apply/simonly-flow/)
 [mineoで端末も一緒に買いたい方](https://mineo.jp/apply/device-flow/)
 [初期設定～ご利用開始の流れ](https://mineo.jp/apply/setup-flow/)
 [お申し込み](https://mineo.jp/apply/)

![](https://mineo.jp/asset/img/common/template/icon_menu_support.png)

サポート

[ユーザーサポートTOP](https://support.mineo.jp/)
 [初期設定・各種設定](https://support.mineo.jp/setup/guide/)
 [よくあるご質問](https://support.mineo.jp/usqa/)
 [AIチャットサポート](https://mineo.jp/r/mai_chat/)
 [お問い合わせ](https://support.mineo.jp/inquiry.html)

[![](https://mineo.jp/asset/img/common/template/icon_menu_king.png)\
\
コミュニティ](https://king.mineo.jp/)
[![](https://mineo.jp/asset/img/common/template/icon_menu_news.png)\
\
お知らせ](https://support.mineo.jp/news_list/)
[![](https://mineo.jp/asset/img/common/template/icon_menu_special.png)\
\
特集](https://mineo.jp/special/)
[![](https://mineo.jp/asset/img/common/template/icon_menu_column.png)\
\
お役立ちコラム](https://mineo.jp/column/)
[![](https://mineo.jp/asset/img/common/template/icon_menu_business.png)\
\
法人のお客さま](https://mineo.jp/r/biz/link_header.html)

[![](https://mineo.jp/asset/img/common/template/logo_mineo.svg)](https://mineo.jp/)

![](https://mineo.jp/asset/img/common/template/icon_menu_feature.png)

mineoの特長

[](https://mineo.jp/support/billing/#)

*   mineo（マイネオ）や格安スマホサービスがはじめての方へ
    
      [![](https://mineo.jp/asset/img/common/template/icon_feature_beginner.png?v20230614) ![](https://mineo.jp/asset/img/common/template/icon_feature_beginner.png?v20230614) はじめての方へ](https://mineo.jp/beginner/)
    
*   格安スマホサービスの中でも選ばれるのには理由があります！
    
      [![](https://mineo.jp/asset/img/common/template/icon_feature_reason.png?v20230614) ![](https://mineo.jp/asset/img/common/template/icon_feature_reason.png?v20230614) mineoが選ばれる理由](https://mineo.jp/reason/)
    
*    [![ブランドステートメント Fun with Fans!](https://mineo.jp/asset/img/common/template/feature-banner.png?v20190731) ![ブランドステートメント Fun with Fans!](https://mineo.jp/asset/img/common/template/sp/feature-banner.png?v20190731)](https://mineo.jp/brand/)
    

*   [![お役立ちコラム](https://mineo.jp/_mg/_uploads/files/4fce8fccb3fa0a96_mineo_Gnavi_bnr_B.jpg)](https://mineo.jp/column/)
    

![](https://mineo.jp/asset/img/common/template/icon_menu_service.png)

料金・サービス

[](https://mineo.jp/support/billing/#)

*     [![](https://mineo.jp/asset/img/common/template/icon_service_price.png) ![](https://mineo.jp/asset/img/common/template/icon_service_price.png) 料金表](https://mineo.jp/price/)
    
*    [![](https://mineo.jp/asset/img/common/template/icon_service_option.png) サービス・オプション一覧](https://mineo.jp/service/)
    
*     [![](https://mineo.jp/asset/img/common/template/icon_service_simulator.png?v20210401) ![](https://mineo.jp/asset/img/common/template/icon_service_simulator.png?v20210401) かんたん料金シミュレーション](https://mineo.jp/simulator/)
    

*   [![おトクなキャンペーン情報](https://mineo.jp/_mg/_uploads/files/3897e85cae780a5f_maipyon_banner.jpg)](https://mineo.jp/campaign/)
    
*   [![法人のお客さまはこちら](https://mineo.jp/_mg/_uploads/files/13c4fc24b5f50ae4_business.jpg)](https://mineo.jp/r/biz/link_drop/)
    

![](https://mineo.jp/asset/img/common/template/icon_menu_device.png)

端末

[](https://mineo.jp/support/billing/#)

*   持ち込みも買い替えも自由に選べる！
    
      [![](https://mineo.jp/asset/img/common/template/icon_device_about.png) ![](https://mineo.jp/asset/img/common/template/icon_device_about.png) mineoで使う  \
    端末を選ぶ](https://mineo.jp/device/about/)
    
*   mineoで端末を買う
    
     [![](https://mineo.jp/asset/img/common/template/icon_device_iphone.png) iPhone](https://mineo.jp/device/iphone/)
    [![](https://mineo.jp/asset/img/common/template/icon_device_smartphone.png) スマートフォン](https://mineo.jp/device/smartphone/)
    [![](https://mineo.jp/asset/img/common/template/icon_device_other.png) タブレット・ルーター](https://mineo.jp/device/other/)
    
*   お手持ちの端末を使う
    
      [![](https://mineo.jp/asset/img/common/template/icon_device_devicelist.png) ![](https://mineo.jp/asset/img/common/template/icon_device_devicelist.png) 動作確認済み  \
    端末検索](https://mineo.jp/device/devicelist/)
    

*   [![mineoスマホコーティング](https://mineo.jp/_mg/_uploads/files/ebd51d24a7bb0a3f_mineo_Gnavi_bnr_smartphone_coating_A.jpg)](https://mineo.jp/service/discount/coating/)
    

![](https://mineo.jp/asset/img/common/template/icon_menu_shop.png)

店舗

[](https://mineo.jp/support/billing/#)

Webでの新規申し込みが不安な方は、お気軽にご来店ください。

*     [![](https://mineo.jp/asset/img/common/template/icon_shop_search.png) ![](https://mineo.jp/asset/img/common/template/icon_shop_search.png) 店舗を探す](https://mineo.jp/shop/)
    
*     [![](https://mineo.jp/asset/img/common/template/icon_shop_about.png) ![](https://mineo.jp/asset/img/common/template/icon_shop_about.png) 店舗でできること](https://mineo.jp/shop/about/)
    
*     [![](https://mineo.jp/asset/img/common/template/icon_shop_online.png) ![](https://mineo.jp/asset/img/common/template/icon_shop_online.png) 店舗でSIMを受け取る](https://mineo.jp/shop/online/counter/)
    

![](https://mineo.jp/asset/img/common/template/icon_menu_guide.png)

申込ガイド

[](https://mineo.jp/support/billing/#)

*   準備からお申し込みの流れ
    
     [![](https://mineo.jp/asset/img/common/template/icon_apply_simonly.png) お手持ちの端末を  \
    そのまま使う方](https://mineo.jp/apply/simonly-flow/)
    [![](https://mineo.jp/asset/img/common/template/icon_apply_device.png) mineoで端末も  \
    一緒に買いたい方](https://mineo.jp/apply/device-flow/)
    
*   SIMカードや端末が届いたら
    
      [![](https://mineo.jp/asset/img/common/template/icon_apply_flow.png?v20211000) ![](https://mineo.jp/asset/img/common/template/icon_apply_flow.png?v20211000) 初期設定～  \
    ご利用開始の流れ](https://mineo.jp/apply/setup-flow/)
    
*   お申し込みページでご契約
    
      [![](https://mineo.jp/asset/img/common/template/icon_apply_entry.png) ![](https://mineo.jp/asset/img/common/template/icon_apply_entry.png) お申し込み](https://mineo.jp/apply/)
    

![](https://mineo.jp/asset/img/common/template/icon_menu_support.png)

サポート

[](https://mineo.jp/support/billing/#)

*   mineoユーザーサポート
    
      [![](https://mineo.jp/asset/img/common/template/icon_support_top.png?v20210401) ![](https://mineo.jp/asset/img/common/template/icon_support_top.png?v20210401) ユーザーサポートTOP](https://support.mineo.jp/)
    
*   設定でわからないことを調べる
    
     [![](https://mineo.jp/asset/img/common/template/icon_support_setup.png) 初期設定・各種設定](https://support.mineo.jp/setup/guide/)
    [![](https://mineo.jp/asset/img/common/template/icon_support_faq.png) よくあるご質問](https://support.mineo.jp/usqa/)
    
*   わからないこと、不安なことがあればお問い合わせを
    
     [![](https://mineo.jp/asset/img/common/template/icon_support_chat.png) AIチャットサポート](https://mineo.jp/r/mai_chat/)
    [![](https://mineo.jp/asset/img/common/template/icon_support_inquiry.png) お問い合わせ](https://support.mineo.jp/inquiry.html)
    

![](https://mineo.jp/asset/img/common/template/icon_menu_king.png)

コミュニティ

[](https://mineo.jp/support/billing/#)

*   マイネ王は、全国のmineoユーザーやmineoスタッフたちが交流しているコミュニティサイトです。
    
    [![](https://mineo.jp/asset/img/common/template/icon_king_guide.png)](https://king.mineo.jp/beginner_guide.html)
    
     [![](https://mineo.jp/asset/img/common/template/icon_king_top.png) コミュニティサイト  \
    マイネ王](https://king.mineo.jp/)
    
*   おすすめコンテンツ
    
    mineoのサービスや端末のレビュー [![](https://mineo.jp/asset/img/common/template/icon_king_review.png) レビュー](https://king.mineo.jp/reviews/)
    
    みんなの疑問と回答 [![](https://mineo.jp/asset/img/common/template/icon_king_faq.png) Q&A](https://king.mineo.jp/question-answer/)
    
*     
    
    mineoに対するみんなの提案 [![](https://mineo.jp/asset/img/common/template/icon_king_idea.png) アイデアファーム](https://king.mineo.jp/ideas/)
    
    パケットをシェアして助け合い [![](https://mineo.jp/asset/img/common/template/icon_king_freetank.png) フリータンク](https://king.mineo.jp/freetank/)
    

マイネ王は、全国のmineoユーザーや  
mineoスタッフたちが交流している  
コミュニティサイトです。 [![](https://mineo.jp/asset/img/common/template/icon_king_top.png) コミュニティサイト  \
マイネ王](https://king.mineo.jp/)

[![](https://mineo.jp/asset/img/common/template/icon_king_guide.png)](https://king.mineo.jp/beginner_guide.html)

おすすめコンテンツ

*   mineoのサービスや端末の  
    レビュー [![](https://mineo.jp/asset/img/common/template/icon_king_review.png) レビュー](https://king.mineo.jp/reviews/)
    
*   みんなの疑問と回答  
      
     [![](https://mineo.jp/asset/img/common/template/icon_king_faq.png) Q&A](https://king.mineo.jp/question-answer/)
    

*   mineoに対するみんなの提案 [![](https://mineo.jp/asset/img/common/template/icon_king_idea.png) アイデア  \
    ファーム](https://king.mineo.jp/ideas/)
    
*   パケットをシェアして助け合い [![](https://mineo.jp/asset/img/common/template/icon_king_freetank.png) フリータンク](https://king.mineo.jp/freetank/)
    

初期設定サポートをご希望の方
==============

Webなどですでにお申し込みが済んでいて、初期設定サポートを店舗でご希望される方

事前にMNP転入切替を  
お願いします
--------------------

![](https://mineo.jp/asset/img/shop/setup-support/icon_mnp.png)

今までの電話番号をmineoでも利用する場合は、ご来店前にMNP転入切替が必要です。

[MNPの切替方法を確認する](https://support.mineo.jp/manual/mnp_mc.html)

eoID・eoIDパスワード※を  
お持ちください
--------------------------

ご来店の際には、事前に店舗へご連絡をお願いします。  
店舗の混雑状況によっては、お待ちいただく場合や当日ご対応できない場合がございますのでご了承ください。

*   ※ mineoお申し込み時にご自身で設定されたeoID・eoIDパスワードをお持ちください。  
    Webからのお申し込みの場合、契約内容通知書に記載の「初期eoID・初期eoIDパスワード」とは異なりますのでご注意ください。

*   〇 eSIMの設定はmineoショップ(大阪・渋谷・神戸・ららぽーと和泉・イオンモール橿原)でのみ承っております。

*   [mineoホーム](https://mineo.jp/)
    
*   [店舗](https://mineo.jp/shop-index/)
    
*   初期設定サポートについて

*   [![facebook](https://mineo.jp/asset/img/common/template/icon_sns_fb.png)](https://www.facebook.com/mineo.jp)
    
*   [![LINE](https://mineo.jp/asset/img/common/template/icon_sns_ln.png)](https://line.me/R/ti/p/%40pdp9012a)
    
*   [![X](https://mineo.jp/asset/img/common/template/icon_sns_x.png)](https://twitter.com/mineojp)
    
*   [![YouTube](https://mineo.jp/asset/img/common/template/icon_sns_yt.png)](https://www.youtube.com/user/mineoofficial)
    
*   [![Instagram](https://mineo.jp/asset/img/common/template/icon_sns_ig.png)](https://www.instagram.com/mineo_jp/)
    

[![格安SIM・格安スマホのmineo](https://mineo.jp/asset/img/common/template/logo_mineo.png)](https://mineo.jp/)

*   mineoの特長
    
    *   [はじめての方へ](https://mineo.jp/beginner/)
        
    *   [mineoが選ばれる理由](https://mineo.jp/reason/)
        
    *   [ブランドステートメント](https://mineo.jp/brand/)
        
    
    料金・サービス
    
    *   [料金表](https://mineo.jp/price/)
        
    *   [サービス・オプション一覧](https://mineo.jp/service/)
        
    *   [かんたん料金シミュレーション](https://mineo.jp/simulator/)
        
    
*   端末
    
    *   [mineoで使う端末を選ぶ](https://mineo.jp/device/about/)
        
    *   mineoで端末を買う
    *   [iPhone](https://mineo.jp/device/iphone/)
        
    *   [スマートフォン](https://mineo.jp/device/smartphone/)
        
    *   [タブレット・ルーター](https://mineo.jp/device/other/)
        
    *   お手持ちの端末を使う
    *   [動作確認済み端末検索](https://mineo.jp/device/devicelist/)
        
    
    店舗
    
    *   [店舗を探す](https://mineo.jp/shop/)
        
    *   [店舗でできること](https://mineo.jp/shop/about/)
        
    *   [店舗でSIMを受け取る](https://mineo.jp/shop/online/counter/)
        
    
*   申込ガイド
    
    *   準備からお申し込みの流れ
    *   [お手持ちの端末をそのまま使う方](https://mineo.jp/apply/simonly-flow/)
        
    *   [mineoで端末も一緒に買いたい方](https://mineo.jp/apply/device-flow/)
        
    *   SIMカードや端末が届いたら
    *   [初期設定～ご利用開始の流れ](https://mineo.jp/apply/setup-flow/)
        
    
    サポート
    
    *   [ユーザーサポート](https://support.mineo.jp/)
        
    *   [初期設定・各種設定](https://support.mineo.jp/setup/guide/)
        
    *   [よくあるご質問](https://support.mineo.jp/usqa/)
        
    *   [AIチャットサポート](https://mineo.jp/r/mai_chat/)
        
    *   [お問い合わせ](https://support.mineo.jp/inquiry.html)
        
    
*   コミュニティ
    
    *   [マイネ王サイト](https://king.mineo.jp/)
        
    *   [マイネ王はじめてガイド](https://king.mineo.jp/beginner_guide.html)
        
    *   おすすめコンテンツ
    *   [レビュー](https://king.mineo.jp/reviews/)
        
    *   [Q&A](https://king.mineo.jp/question-answer/)
        
    *   [アイデアファーム](https://king.mineo.jp/ideas/)
        
    *   [フリータンク](https://king.mineo.jp/freetank/)
        
    

*   *   [![](https://mineo.jp/asset/img/common/template/icon_mypage.png)マイページ](https://my.mineo.jp/)
        
    *     [![](https://mineo.jp/asset/img/common/template/icon_apply_wh.png) ![](https://mineo.jp/asset/img/common/template/icon_apply_pink.png)お申し込み](https://mineo.jp/apply/)
        
*   *   [法人のお客さま](https://mineo.jp/r/biz/link_footer.html)
        
    *   [お知らせ](https://mineo.jp/#info)
        
    *   [キャンペーン](https://mineo.jp/campaign/)
        
    *   [特集](https://mineo.jp/special/)
        

     ![検索](https://mineo.jp/asset/img/common/icon_search.png)

記載の価格は税抜記載のものを除き税込です。税込価格は2021年4月1日現在の税率（10%）に基づく金額です。税率に応じて金額は変更されます。

[![株式会社オプテージ](https://mineo.jp/asset/img/common/template/logo_optage.png)](https://optage.co.jp/)

*   [第三者認証](https://optage.co.jp/company/authorization/safesecurityisp.html)
    
*   [情報セキュリティポリシー](https://optage.co.jp/info/security.html)
    
*   [プライバシーポリシー](https://optage.co.jp/info/privacy/)
    
*   [Cookie等の外部送信について](https://optage.co.jp/info/informative.html)
    
*   [サイトのご利用にあたって](https://mineo.jp/site/terms/)
    
*   [特定商取引法に基づく表示](https://mineo.jp/site/law/)
    
*   [ユニバーサルサービス料について](https://optage.co.jp/info/universal.html)
    
*   [電話リレーサービス料について](https://optage.co.jp/info/telephonerelay.html)
    
*   [企業情報](https://optage.co.jp/company/)
    
*   [古物営業法に基づく表示](https://optage.co.jp/company/authorization/)
    

© OPTAGE Inc.

![](https://acv.mira-dsp.com/v1/image?tag_id=9060bb35-fbb5-484f-8045-5cd2db32902c)
