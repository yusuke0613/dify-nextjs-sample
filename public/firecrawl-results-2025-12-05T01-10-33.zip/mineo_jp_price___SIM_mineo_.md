# 料金表｜格安スマホ・格安SIM【mineo(マイネオ)】

URL: https://mineo.jp/price/

---

[![格安SIM・格安スマホのmineo](https://mineo.jp/asset/img/common/template/logo_mineo_white.png)](https://mineo.jp/)

*   [法人のお客さま](https://mineo.jp/r/biz/link_header.html)
    
*   [お知らせ](https://mineo.jp/#info)
    
*   [キャンペーン](https://mineo.jp/campaign/)
    
*   [特集](https://mineo.jp/special/)
    
*        ![検索](https://mineo.jp/asset/img/common/icon_search.png)
    

*   [![](https://mineo.jp/asset/img/common/template/icon_menu_feature.png)\
    \
    mineoの  \
    特長](https://mineo.jp/price/#header-menu-feature)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_service.png)\
    \
    料金・  \
    サービス](https://mineo.jp/price/#header-menu-service)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_device.png)\
    \
    端末](https://mineo.jp/price/#header-menu-device)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_shop.png)\
    \
    店舗](https://mineo.jp/price/#header-menu-shop)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_guide.png)\
    \
    申込ガイド](https://mineo.jp/price/#header-menu-guide)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_support.png)\
    \
    サポート](https://mineo.jp/price/#header-menu-support)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_king.png)\
    \
    コミュニティ](https://mineo.jp/price/#header-menu-king)
    

*   [![](https://mineo.jp/asset/img/common/template/icon_mypage.png)\
    \
    マイページ](https://my.mineo.jp/)
    
*    [![](https://mineo.jp/asset/img/common/template/icon_apply_wh.png) ![](https://mineo.jp/asset/img/common/template/icon_apply_pink.png)\
    \
    お申し込み](https://mineo.jp/apply/)
    

メニュー

[![格安SIM・格安スマホのmineo](https://mineo.jp/asset/img/common/template/logo_mineo.png)](https://mineo.jp/)

*   [![](https://mineo.jp/asset/img/common/template/icon_menu_feature.png)\
    \
    mineoの  \
    特長](https://mineo.jp/price/#header-menu-feature)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_service.png)\
    \
    料金・  \
    サービス](https://mineo.jp/price/#header-menu-service)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_device.png)\
    \
    端末](https://mineo.jp/price/#header-menu-device)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_shop.png)\
    \
    店舗](https://mineo.jp/price/#header-menu-shop)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_guide.png)\
    \
    申込ガイド](https://mineo.jp/price/#header-menu-guide)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_support.png)\
    \
    サポート](https://mineo.jp/price/#header-menu-support)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_king.png)\
    \
    コミュニティ](https://mineo.jp/price/#header-menu-king)
    

*   [![](https://mineo.jp/asset/img/common/template/icon_mypage.png)\
    \
    マイページ](https://my.mineo.jp/)
    
*    [![](https://mineo.jp/asset/img/common/template/icon_apply_wh.png) ![](https://mineo.jp/asset/img/common/template/icon_apply_pink.png)\
    \
    お申し込み](https://mineo.jp/apply/)
    

![](https://mineo.jp/asset/img/common/template/header_mark.png)

閉じる

     ![検索](https://mineo.jp/asset/img/common/icon_search.png)

*   [![](https://mineo.jp/asset/img/common/template/icon_mypage.png)\
    \
    マイページ](https://my.mineo.jp/)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_apply_wh.png)\
    \
    お申し込み](https://mineo.jp/apply/)
    

![](https://mineo.jp/asset/img/common/template/icon_menu_feature.png)

mineoの特長

[はじめての方へ](https://mineo.jp/beginner/)
 [mineoが選ばれる理由](https://mineo.jp/reason/)
 [Fun with Fans！](https://mineo.jp/brand/)

![](https://mineo.jp/asset/img/common/template/icon_menu_service.png)

料金・サービス

[料金表](https://mineo.jp/price/)
 [サービス・オプション一覧](https://mineo.jp/service/)
 [かんたん料金シミュレーション](https://mineo.jp/simulator/)

[![](https://mineo.jp/asset/img/common/template/icon_menu_campaign.png)\
\
キャンペーン](https://mineo.jp/campaign/)

![](https://mineo.jp/asset/img/common/template/icon_menu_device.png)

端末

[mineoで使う端末を選ぶ](https://mineo.jp/device/about/)
 [iPhone](https://mineo.jp/device/iphone/)
 [スマートフォン](https://mineo.jp/device/smartphone/)
 [タブレット・ルーター](https://mineo.jp/device/other/)
 [動作確認済み端末検索](https://mineo.jp/device/devicelist/)

![](https://mineo.jp/asset/img/common/template/icon_menu_shop.png)

店舗

[店舗を探す](https://mineo.jp/shop/)
 [店舗でできること](https://mineo.jp/shop/about/)
 [店舗でSIMを受け取る](https://mineo.jp/shop/online/counter/)

![](https://mineo.jp/asset/img/common/template/icon_menu_guide.png)

申込ガイド

[お手持ちの端末をそのまま使う方](https://mineo.jp/apply/simonly-flow/)
 [mineoで端末も一緒に買いたい方](https://mineo.jp/apply/device-flow/)
 [初期設定～ご利用開始の流れ](https://mineo.jp/apply/setup-flow/)
 [お申し込み](https://mineo.jp/apply/)

![](https://mineo.jp/asset/img/common/template/icon_menu_support.png)

サポート

[ユーザーサポートTOP](https://support.mineo.jp/)
 [初期設定・各種設定](https://support.mineo.jp/setup/guide/)
 [よくあるご質問](https://support.mineo.jp/usqa/)
 [AIチャットサポート](https://mineo.jp/r/mai_chat/)
 [お問い合わせ](https://support.mineo.jp/inquiry.html)

[![](https://mineo.jp/asset/img/common/template/icon_menu_king.png)\
\
コミュニティ](https://king.mineo.jp/)
[![](https://mineo.jp/asset/img/common/template/icon_menu_news.png)\
\
お知らせ](https://support.mineo.jp/news_list/)
[![](https://mineo.jp/asset/img/common/template/icon_menu_special.png)\
\
特集](https://mineo.jp/special/)
[![](https://mineo.jp/asset/img/common/template/icon_menu_column.png)\
\
お役立ちコラム](https://mineo.jp/column/)
[![](https://mineo.jp/asset/img/common/template/icon_menu_business.png)\
\
法人のお客さま](https://mineo.jp/r/biz/link_header.html)

[![](https://mineo.jp/asset/img/common/template/logo_mineo.svg)](https://mineo.jp/)

![](https://mineo.jp/asset/img/common/template/icon_menu_feature.png)

mineoの特長

[](https://mineo.jp/price/#)

*   mineo（マイネオ）や格安スマホサービスがはじめての方へ
    
      [![](https://mineo.jp/asset/img/common/template/icon_feature_beginner.png?v20230614) ![](https://mineo.jp/asset/img/common/template/icon_feature_beginner.png?v20230614) はじめての方へ](https://mineo.jp/beginner/)
    
*   格安スマホサービスの中でも選ばれるのには理由があります！
    
      [![](https://mineo.jp/asset/img/common/template/icon_feature_reason.png?v20230614) ![](https://mineo.jp/asset/img/common/template/icon_feature_reason.png?v20230614) mineoが選ばれる理由](https://mineo.jp/reason/)
    
*    [![ブランドステートメント Fun with Fans!](https://mineo.jp/asset/img/common/template/feature-banner.png?v20190731) ![ブランドステートメント Fun with Fans!](https://mineo.jp/asset/img/common/template/sp/feature-banner.png?v20190731)](https://mineo.jp/brand/)
    

*   [![お役立ちコラム](https://mineo.jp/_mg/_uploads/files/4fce8fccb3fa0a96_mineo_Gnavi_bnr_B.jpg)](https://mineo.jp/column/)
    

![](https://mineo.jp/asset/img/common/template/icon_menu_service.png)

料金・サービス

[](https://mineo.jp/price/#)

*     [![](https://mineo.jp/asset/img/common/template/icon_service_price.png) ![](https://mineo.jp/asset/img/common/template/icon_service_price.png) 料金表](https://mineo.jp/price/)
    
*    [![](https://mineo.jp/asset/img/common/template/icon_service_option.png) サービス・オプション一覧](https://mineo.jp/service/)
    
*     [![](https://mineo.jp/asset/img/common/template/icon_service_simulator.png?v20210401) ![](https://mineo.jp/asset/img/common/template/icon_service_simulator.png?v20210401) かんたん料金シミュレーション](https://mineo.jp/simulator/)
    

*   [![おトクなキャンペーン情報](https://mineo.jp/_mg/_uploads/files/3897e85cae780a5f_maipyon_banner.jpg)](https://mineo.jp/campaign/)
    
*   [![法人のお客さまはこちら](https://mineo.jp/_mg/_uploads/files/13c4fc24b5f50ae4_business.jpg)](https://mineo.jp/r/biz/link_drop/)
    

![](https://mineo.jp/asset/img/common/template/icon_menu_device.png)

端末

[](https://mineo.jp/price/#)

*   持ち込みも買い替えも自由に選べる！
    
      [![](https://mineo.jp/asset/img/common/template/icon_device_about.png) ![](https://mineo.jp/asset/img/common/template/icon_device_about.png) mineoで使う  \
    端末を選ぶ](https://mineo.jp/device/about/)
    
*   mineoで端末を買う
    
     [![](https://mineo.jp/asset/img/common/template/icon_device_iphone.png) iPhone](https://mineo.jp/device/iphone/)
    [![](https://mineo.jp/asset/img/common/template/icon_device_smartphone.png) スマートフォン](https://mineo.jp/device/smartphone/)
    [![](https://mineo.jp/asset/img/common/template/icon_device_other.png) タブレット・ルーター](https://mineo.jp/device/other/)
    
*   お手持ちの端末を使う
    
      [![](https://mineo.jp/asset/img/common/template/icon_device_devicelist.png) ![](https://mineo.jp/asset/img/common/template/icon_device_devicelist.png) 動作確認済み  \
    端末検索](https://mineo.jp/device/devicelist/)
    

*   [![mineoスマホコーティング](https://mineo.jp/_mg/_uploads/files/ebd51d24a7bb0a3f_mineo_Gnavi_bnr_smartphone_coating_A.jpg)](https://mineo.jp/service/discount/coating/)
    

![](https://mineo.jp/asset/img/common/template/icon_menu_shop.png)

店舗

[](https://mineo.jp/price/#)

Webでの新規申し込みが不安な方は、お気軽にご来店ください。

*     [![](https://mineo.jp/asset/img/common/template/icon_shop_search.png) ![](https://mineo.jp/asset/img/common/template/icon_shop_search.png) 店舗を探す](https://mineo.jp/shop/)
    
*     [![](https://mineo.jp/asset/img/common/template/icon_shop_about.png) ![](https://mineo.jp/asset/img/common/template/icon_shop_about.png) 店舗でできること](https://mineo.jp/shop/about/)
    
*     [![](https://mineo.jp/asset/img/common/template/icon_shop_online.png) ![](https://mineo.jp/asset/img/common/template/icon_shop_online.png) 店舗でSIMを受け取る](https://mineo.jp/shop/online/counter/)
    

![](https://mineo.jp/asset/img/common/template/icon_menu_guide.png)

申込ガイド

[](https://mineo.jp/price/#)

*   準備からお申し込みの流れ
    
     [![](https://mineo.jp/asset/img/common/template/icon_apply_simonly.png) お手持ちの端末を  \
    そのまま使う方](https://mineo.jp/apply/simonly-flow/)
    [![](https://mineo.jp/asset/img/common/template/icon_apply_device.png) mineoで端末も  \
    一緒に買いたい方](https://mineo.jp/apply/device-flow/)
    
*   SIMカードや端末が届いたら
    
      [![](https://mineo.jp/asset/img/common/template/icon_apply_flow.png?v20211000) ![](https://mineo.jp/asset/img/common/template/icon_apply_flow.png?v20211000) 初期設定～  \
    ご利用開始の流れ](https://mineo.jp/apply/setup-flow/)
    
*   お申し込みページでご契約
    
      [![](https://mineo.jp/asset/img/common/template/icon_apply_entry.png) ![](https://mineo.jp/asset/img/common/template/icon_apply_entry.png) お申し込み](https://mineo.jp/apply/)
    

![](https://mineo.jp/asset/img/common/template/icon_menu_support.png)

サポート

[](https://mineo.jp/price/#)

*   mineoユーザーサポート
    
      [![](https://mineo.jp/asset/img/common/template/icon_support_top.png?v20210401) ![](https://mineo.jp/asset/img/common/template/icon_support_top.png?v20210401) ユーザーサポートTOP](https://support.mineo.jp/)
    
*   設定でわからないことを調べる
    
     [![](https://mineo.jp/asset/img/common/template/icon_support_setup.png) 初期設定・各種設定](https://support.mineo.jp/setup/guide/)
    [![](https://mineo.jp/asset/img/common/template/icon_support_faq.png) よくあるご質問](https://support.mineo.jp/usqa/)
    
*   わからないこと、不安なことがあればお問い合わせを
    
     [![](https://mineo.jp/asset/img/common/template/icon_support_chat.png) AIチャットサポート](https://mineo.jp/r/mai_chat/)
    [![](https://mineo.jp/asset/img/common/template/icon_support_inquiry.png) お問い合わせ](https://support.mineo.jp/inquiry.html)
    

![](https://mineo.jp/asset/img/common/template/icon_menu_king.png)

コミュニティ

[](https://mineo.jp/price/#)

*   マイネ王は、全国のmineoユーザーやmineoスタッフたちが交流しているコミュニティサイトです。
    
    [![](https://mineo.jp/asset/img/common/template/icon_king_guide.png)](https://king.mineo.jp/beginner_guide.html)
    
     [![](https://mineo.jp/asset/img/common/template/icon_king_top.png) コミュニティサイト  \
    マイネ王](https://king.mineo.jp/)
    
*   おすすめコンテンツ
    
    mineoのサービスや端末のレビュー [![](https://mineo.jp/asset/img/common/template/icon_king_review.png) レビュー](https://king.mineo.jp/reviews/)
    
    みんなの疑問と回答 [![](https://mineo.jp/asset/img/common/template/icon_king_faq.png) Q&A](https://king.mineo.jp/question-answer/)
    
*     
    
    mineoに対するみんなの提案 [![](https://mineo.jp/asset/img/common/template/icon_king_idea.png) アイデアファーム](https://king.mineo.jp/ideas/)
    
    パケットをシェアして助け合い [![](https://mineo.jp/asset/img/common/template/icon_king_freetank.png) フリータンク](https://king.mineo.jp/freetank/)
    

マイネ王は、全国のmineoユーザーや  
mineoスタッフたちが交流している  
コミュニティサイトです。 [![](https://mineo.jp/asset/img/common/template/icon_king_top.png) コミュニティサイト  \
マイネ王](https://king.mineo.jp/)

[![](https://mineo.jp/asset/img/common/template/icon_king_guide.png)](https://king.mineo.jp/beginner_guide.html)

おすすめコンテンツ

*   mineoのサービスや端末の  
    レビュー [![](https://mineo.jp/asset/img/common/template/icon_king_review.png) レビュー](https://king.mineo.jp/reviews/)
    
*   みんなの疑問と回答  
      
     [![](https://mineo.jp/asset/img/common/template/icon_king_faq.png) Q&A](https://king.mineo.jp/question-answer/)
    

*   mineoに対するみんなの提案 [![](https://mineo.jp/asset/img/common/template/icon_king_idea.png) アイデア  \
    ファーム](https://king.mineo.jp/ideas/)
    
*   パケットをシェアして助け合い [![](https://mineo.jp/asset/img/common/template/icon_king_freetank.png) フリータンク](https://king.mineo.jp/freetank/)
    

料金表
===

[月額基本料金](https://mineo.jp/price/#basic)
 [通話料・SMS](https://mineo.jp/price/#voice-sms)
 [メール](https://mineo.jp/price/#mail)
 [通信](https://mineo.jp/price/#data)
 [初期費用](https://mineo.jp/price/#charge)
 [事務手数料](https://mineo.jp/price/#fee)
 [割引](https://mineo.jp/price/#discount)
 [サービス仕様](https://mineo.jp/price/#service-spec)

![](https://mineo.jp/asset/img/common/service/icon_price.png)月額基本料金
-------------------------------------------------------------------

*   [データ容量で選ぶ![マイピタ](https://mineo.jp/asset/img/price/logo_mypita.png)](https://mineo.jp/price/#mypita)
    
*   [通信速度で選ぶ![マイそく](https://mineo.jp/asset/img/price/logo_mysoku.png)](https://mineo.jp/price/#mysoku)
    

![毎月必要なデータ容量で選ぶマイピタ](https://mineo.jp/asset/img/price/mypita_title.png?v20240115)

*   7GB（デュアルタイプ）
    
    1,518円/月
    
    月々に必要な  
    データ容量に  
    合わせて選べる  
    料金プラン
    
*   *   3GB
    *   7GB
    
    *   15GB
    *   30GB
    *   50GB
    
    5つのコースから  
    “あなたにピッタリ”  
    が選べる！
    
*   ![](https://mineo.jp/asset/img/price/mypita_pic_03.png?v20241101)
    
    余ったデータ容量は  
    翌月に繰り越し！
    

マイピタ 15GB以上のコースを  
ご契約の場合

ネットも動画もデータ通信が使い放題（最大1.5Mbps）になる  
パケット放題 Plusの月額料金385円が無料！

*   ○ パケット放題 Plusの詳細は[こちら](https://mineo.jp/service/data/packet-free/)
    

### 月額基本料金

（税込価格）

|     | ![](https://mineo.jp/asset/img/common/service/icon_dual.png)<br><br>音声通話＋データ通信<br><br>（デュアルタイプ） | ![](https://mineo.jp/asset/img/common/service/icon_single.png)<br><br>データ通信のみ<br><br>（シングルタイプ） |
| --- | --- | --- |
| 3GB | 1,298円 | 880円 |
| 7GB | 1,518円 | 1,265円 |
| 15GB | 1,958円 | 1,705円 |
| 30GB | 2,178円 | 1,925円 |
| 50GB | 2,948円 | 2,695円 |

*   ○ 容量を使い切った後も最大200kbpsで通信可能です。

#### データ容量が足りなくなったときのチャージもかんたん！

|     |     |
| --- | --- |
| [パケット  <br>チャージ](https://mineo.jp/service/data/packet-charge/) | 55円/100MB |     |

[マイピタの詳細を見る](https://mineo.jp/price/mypita/)

[![2/2まで最大6カ月間無料キャンペーン パスケット パスケットの中に貯まっているパケットはずっと繰り越し可能！](https://mineo.jp/asset/img/price/bnr_pasket_20251126.jpg)](https://mineo.jp/service/data/pasket/)

[![マイピタ 料金そのままデータ増量！ 1GB→3GB 5GB→7GB 10GB→15GB 20GB→30GB さらに！パケット放題サービスをアップデート！](https://mineo.jp/asset/img/price/bnr_2025winter.jpg)](https://mineo.jp/special/2025winter/)

![データ無制限！最大通信速度※で選ぶマイそく](https://mineo.jp/asset/img/price/mysoku_title.png?v20240115)

*   ![](https://mineo.jp/asset/img/price/mysoku_pic_01.png)
    
    データ容量  
    気にせず  
    使い放題
    
*   ![最大32kbps 300kbps 最大1.5Mbps 最大5Mbps](https://mineo.jp/asset/img/price/mysoku_pic_02.png?v20250313)
    
    ライフスタイル  
    にあわせて  
    4つの速度から  
    選べる！
    
*   ![高速通信したいときも安心 24時間データ使い放題](https://mineo.jp/asset/img/price/mysoku_pic_03.png?v20241101)
    
    月曜～金曜のお  
    昼に通信速度が  
    制限される代わ  
    りにおトク！
    

*   ※ 月曜～金曜の12時台は最大32kbps（プレミアムのみ最大200kbps）になります。また混雑回避のための速度制限（3日間で10GB以上利用時）および通信最適化が適用されます。

### 月額基本料金

（税込価格）

|     | ![](https://mineo.jp/asset/img/common/service/icon_dual.png)<br><br>音声通話＋データ通信<br><br>（デュアルタイプ） | ![](https://mineo.jp/asset/img/common/service/icon_single.png)<br><br>データ通信のみ<br><br>（シングルタイプ） |
| --- | --- | --- |
| プレミアム  <br>（最大5Mbps） | 2,200円 |     |
| スタンダード  <br>（最大1.5Mbps） | 990円 |     |
| ライト  <br>（最大300kbps） | 660円 |     |
| スーパーライト  <br>（最大32kbps） | 250円 | \-  |

*   ○ 月曜～金曜の12時台は最大32kbps（プレミアムのみ最大200kbps）になります。音声通話は制限時間中も問題なくご利用いただけます。
*   ○ 混雑回避のための速度制限（3日間で10GB以上利用時）および通信最適化の適用が必須となります。
*   ○ 記載の通信速度はベストエフォート方式による提供となり、実際の通信速度は、通信環境やネットワークの混雑状況に応じて変化します。
*   ○ スーパーライトは新規お申し込み時のみ申込可能です。（他のコースからのコース変更はできません。）

#### mineo通常速度にいつでも切り替えられる！

|     |     |
| --- | --- |
| [24時間データ使い放題](https://mineo.jp/price/mysoku/#unlimited) | 198円/回 |     |

*   ○ 通信速度はベストエフォートとなり、使い放題利用中も通信最適化が適用されます。

[マイそくの詳細を見る](https://mineo.jp/price/mysoku/)

さあ、mineoをはじめよう！
---------------

*    [![](https://mineo.jp/asset/img/common/conversion_icon_apply.png) mineoに申し込む](https://mineo.jp/apply/)
    
*    [![](https://mineo.jp/asset/img/common/conversion_icon_sim.png) 料金をシミュレーションする](https://mineo.jp/simulator/)
    

![気軽にmineoをお試しできる mineoプチ体験](https://mineo.jp/asset/img/price/trial_logo.png?v20240115)

お試しとして200MBの少容量SIMをご用意。  
実際のつながりやすさや通信速度の確認が  
できます！

### 月額基本料金

（税込価格）

|     | ![](https://mineo.jp/asset/img/common/service/icon_dual.png)<br><br>音声通話＋データ通信<br><br>（デュアルタイプ） | ![](https://mineo.jp/asset/img/common/service/icon_single.png)<br><br>データ通信のみ<br><br>（シングルタイプ） |
| --- | --- | --- |
| [お試し  <br>200MB  <br>コース](https://mineo.jp/service/unique/prepaid/) | 1,100円 | 330円 |

*   ○ 契約事務手数料は550円となります。
*   ○ 利用期間（最大2カ月）満了後は自動的に3GBコースに移行します。詳細は[こちら](https://mineo.jp/service/unique/prepaid/)
    
*   ○ お試し200MBコースはWebでのみお申し込みいただけます。  
    店頭でのお申し込み・お渡しの場合にはお申し込みいただけません。

[お試し200MBコースを申し込む](https://mineo.jp/apply/)

![](https://mineo.jp/asset/img/common/service/icon_voice.png)通話料・SMS
--------------------------------------------------------------------

### 通話料

（税込価格）

|     | A<br><br>Aプラン | D<br><br>Dプラン | S<br><br>Sプラン |
| --- | --- | --- | --- |
| 国内通話料 | 22円/30秒 |     |     |
| 国際通話料 | ![○](https://mineo.jp/asset/img/common/icon_maru.svg)<br><br>[条件詳細](http://www.kddi.com/corporate/kddi/public/mvno/user/) | ![○](https://mineo.jp/asset/img/common/icon_maru.svg)<br><br>[条件詳細](https://www.docomo.ne.jp/corporate/disclosure/mvno/user/index.html) | ![△](https://mineo.jp/asset/img/common/icon_sankaku.svg)<br><br>[条件詳細](https://www.softbank.jp/mobile/service/global/outgoing/call/services/) |

*   ※1 Aプランの場合の通話料は、[au(LTE)通信サービス契約約款](http://media3.kddi.com/extlib/files/corporate/kddi/kokai/keiyaku_yakkan/pdf/honbun_kddi_lte.pdf)
    および[au(WIN)通信サービス契約約款](https://media3.kddi.com/extlib/files/corporate/kddi/kokai/keiyaku_yakkan/pdf/honbun_kddi_win.pdf)
    にて定められた額と同額になります。
*   ※2 Sプランの場合、日本から海外に電話をかけることはできますが、海外から日本への電話（国際ローミングサービス）は利用できません。

![](https://mineo.jp/asset/img/price/title_line_l.png)

mineoでは  
おトクに通話ができる  
サービスをご用意！

![](https://mineo.jp/asset/img/price/title_line_r.png)

*   ![](https://mineo.jp/asset/img/price/icon_kakehoudai01.png)
    
    時間無制限かけ放題
    
    1,210円/月
    
    通話時間に制限がなく、  
    何回でもかけ放題！
    
*   ![](https://mineo.jp/asset/img/price/icon_kakehoudai02.png)
    
    10分かけ放題
    
    550円/月
    
    10分以内の通話が  
    何回でもかけ放題！
    

[通話オプションサービスをみる](https://mineo.jp/service/#voice)

### SMS基本料

（税込価格）

|     | A<br><br>Aプラン | D<br><br>Dプラン | S<br><br>Sプラン |
| --- | --- | --- | --- |
| シングルタイプ | 無料※1 | 132円/月※2※3 | 198円/月※2 |
| デュアルタイプ | 無料※4 |     |     |

*   ※1 シングルタイプをお申し込みの場合は、SMSオプションをお申し込みいただくことにより利用が可能となります。
*   ※2 シングルタイプ申し込み時にSMSあり・なしを選択できます。マイそくコースご契約の場合は無料です。  
    ご利用開始後にSMSあり・なしを変更した場合、変更事務手数料とSIMカード発行料が別途必要になります。
*   ※3 5G通信オプションはご利用いただけません。
*   ※4 デュアルタイプをお申し込みの場合は、自動的にSMSの利用が可能となります。

### SMS送受信料

（税込価格）

|     | A<br><br>Aプラン | D<br><br>Dプラン | S<br><br>Sプラン |
| --- | --- | --- | --- |
| 送信  | 3～33円/通※ |     |     |
| 受信  | 無料  |     |     |

*   ※ 送信料は送信文字数により異なります。国内での1送信毎の送信料の詳細は、[mineo通信サービス契約約款\[PDF:1.81MB\]](https://support.mineo.jp/contract/pdf/service_agreement.pdf)
    をご確認ください。

*   ○ 最大文字数は全角670文字、半角1,530文字までとなります。端末により送信可能な文字数が最大文字数を下回る場合があります。
*   ○ 1日に送受信可能な件数は最大200件までとなります。
*   ○ SMSのメッセージ機能から、メールアドレス宛てのメッセージ送信はご利用いただけません。
*   ○ mineoプリペイドパックでは、SMSはご利用いただけません。

### 国際SMS・海外SMS

（税込価格）

|     | A<br><br>Aプラン | D<br><br>Dプラン | S<br><br>Sプラン |
| --- | --- | --- | --- |
| 日本国内にて  <br>受信 | 無料  |     |     |
| 日本国内から  <br>送信 | 100〜1,000円  <br>（免税）/通※1 | 50〜500円  <br>（免税）/通※1 | 100〜1,000円  <br>（免税）/通※1 |
| 海外にて  <br>受信 | 無料  | 無料※2 | ご利用いただけません |
| 海外から  <br>送信 | 100円  <br>（免税）/通 | 100〜170円  <br>（免税）/通※2※3 |

*   ※1 送信文字数によって変動します。国際SMS送信料の詳細は[こちら\[PDF:156KB\]](https://support.mineo.jp/contract/pdf/international-sms.pdf)
    をご確認ください。
*   ※2 シングルタイプに追加いただいたSMSサービスではご利用いただけません。
*   ※3 航空機や船舶から送信する場合170円（免税）となります。これに当てはまらない場合は一律100円（免税）となります。

*   ○ 最大文字数は全角670文字、半角1,530文字までとなります。端末により送信可能な文字数が最大文字数を下回る場合があります。
*   ○ 1日に送受信可能な件数は最大200件までとなります。

![](https://mineo.jp/asset/img/common/service/icon_mail.png)メール
---------------------------------------------------------------

|     |     |
| --- | --- |
| mineoメール  <br>オプション | 無料<br><br>*   ○ @mineo.jpのメールアドレス、基本メールボックス（容量200MB、保存期間60日）をご利用いただけます。<br>*   ○ 回線のご契約時、または[マイページ](https://my.mineo.jp/)<br>    よりmineoメールオプションのお申し込みが必要です。<br>*   ○ メールサービスをご利用いただくにはメールアカウントの設定※が必要です。 |
| メールボックス  <br>容量追加 | 無料<br><br>*   ○ メールボックス容量を5GBまで増やし、保存期間を無期限にすることができます。  <br>    [マイページ](https://my.mineo.jp/)<br>    よりお申し込みが必要です。 |

*   ※ Android™端末の設定は[こちら](https://support.mineo.jp/setup/guide/mail_account.html)
     / iOS端末の設定は[こちら](https://support.mineo.jp/setup/guide/ios_mail_account.html)
    

![](https://mineo.jp/asset/img/common/service/icon_data.png)通信
--------------------------------------------------------------

（税込価格）

|     | A<br><br>Aプラン | D<br><br>Dプラン | S<br><br>Sプラン |
| --- | --- | --- | --- |
| [5G通信  <br>オプション](https://mineo.jp/service/data/5g/) | 無料※ |     |     |
| [パケット  <br>チャージ](https://mineo.jp/service/data/packet-charge/) | 55円/100MB |     |     |
| [24時間  <br>データ使い放題](https://mineo.jp/price/mysoku/#unlimited) | マイそく専用オプション  <br>1回（24時間）：198円 |     |     |

*   ※ Dプランの場合、本サービスをご契約いただくと3G(FOMA)通信がご利用いただけなくなります。  
    Dプランの場合、シングルタイプSMS機能有りではご利用いただけません。

![](https://mineo.jp/asset/img/common/service/icon_initialcost.png)初期費用
-----------------------------------------------------------------------

（税込価格）

|     | A<br><br>Aプラン | D<br><br>Dプラン | S<br><br>Sプラン |
| --- | --- | --- | --- |
| 契約事務手数料 | 3,300円 |     |     |
| （SIMカードをご利用する場合）  <br>SIMカード  <br>発行料 | 440円 |     |     |
| （eSIMをご利用する場合）  <br>eSIMプロファイル発行料 | 440円 |     | eSIM未提供 |

![](https://mineo.jp/asset/img/common/service/icon_fee.png)事務手数料
----------------------------------------------------------------

### 変更費用

（税込価格）

*   SIMカードをご利用する場合
*   eSIMをご利用する場合

|     | A<br><br>Aプラン | D<br><br>Dプラン | S<br><br>Sプラン |
| --- | --- | --- | --- |
| プラン変更時※1  <br>（Aプラン⇔Dプラン⇔Sプラン） | 変更事務手数料：3,300円※2  <br>SIMカード発行料：440円※2 |     |     |
| タイプ変更時※1  <br>（シングル⇒デュアル） | 変更事務手数料：無料  <br>SIMカード発行料：440円※2 |     |     |
| タイプ変更時※1  <br>（デュアル⇒シングル） | 変更事務手数料：3,300円※2  <br>SIMカード発行料：440円※2 |     |     |
| コース変更時  <br>（基本データ容量/速度変更）  <br>*   ○ 同一プラン・タイプ内に限る | 変更事務手数料：なし  <br>SIMカード発行料：－ |     |     |
| SMS契約変更時  <br>（SMS無し⇔SMSあり） | 変更事務手数料：－  <br>SIMカード発行料：－ | 変更事務手数料：3,300円  <br>SIMカード発行料：440円 |     |
| SIMカード変更・再発行時※3 | SIMカード再発行事務手数料：2,200円  <br>SIMカード発行料：440円 |     |     |
| 回線譲渡 | 契約譲渡手数料：3,300円※4 |     |     |

*   ※1 プラン変更とタイプ変更は同時にお手続きができます。その場合は変更事務手数料とSIMカード発行料が必要となります。  
    ただし、シングルタイプ⇒デュアルタイプへ変更する場合は変更事務手数料が無料となります。
*   ※2 Aプラン nano SIMまたはmicro SIMをご利用のお客さまは変更事務手数料・SIMカード発行料ともに無料となります。
*   ※3 Aプラン nano SIMまたはmicro SIMをご利用のお客さまは、au VoLTE対応SIMへの変更に限り変更事務手数料・SIMカード発行料ともに無料となります。
*   ※4 家族間（三親等以内）は無料となります。mineoの定める三親等は[こちら](https://mineo.jp/service/discount/family-discount/#family-level-in)
    

|     | A<br><br>Aプラン | D<br><br>Dプラン |
| --- | --- | --- |
| プラン変更時※1  <br>（Sプラン⇒Aプラン/Dプラン  <br>Aプラン⇔Dプラン） | 変更事務手数料：3,300円※2  <br>eSIMプロファイル発行料：440円 |     |
| タイプ変更時※1  <br>（シングル⇒デュアル） | 変更事務手数料：無料  <br>eSIMプロファイル発行料：440円 |     |
| タイプ変更時※1  <br>（デュアル⇒シングル） | 変更事務手数料：3,300円※2  <br>eSIMプロファイル発行料：440円 |     |
| コース変更時  <br>（基本データ容量/速度変更）  <br>*   ○ 同一プラン・タイプ内に限る | 変更事務手数料：なし  <br>eSIMプロファイル発行料：－ |     |
| SMS契約変更時  <br>（SMS無し⇒SMSあり） | 変更事務手数料：\-  <br>eSIMプロファイル発行料：\- | 変更事務手数料：3,300円  <br>eSIMプロファイル発行料：  <br>440円 |
| eSIM変更・  <br>再発行時 | eSIM再発行事務手数料：無料  <br>eSIMプロファイル発行料：440円 |     |

*   ※1 プラン変更とタイプ変更は同時にお手続きができます。その場合は変更事務手数料とeSIMプロファイル発行料が必要となります。  
    ただし、シングルタイプ⇒デュアルタイプへ変更する場合は変更事務手数料が無料となります。
*   ※2 Aプラン nano SIMまたはmicro SIMをご利用のお客さまは変更事務手数料・eSIMプロファイル発行料ともに無料となります。

### 解約関係費用

|     | A<br><br>Aプラン | D<br><br>Dプラン | S<br><br>Sプラン |
| --- | --- | --- | --- |
| 解約手数料 | 無料  |     |     |
| MNP転出手数料 | 無料  |     |     |

![](https://mineo.jp/asset/img/common/service/icon_benefit.png)割引
-----------------------------------------------------------------

（税込価格）

|     | A<br><br>Aプラン | D<br><br>Dプラン | S<br><br>Sプラン |
| --- | --- | --- | --- |
| [家族割引](https://mineo.jp/service/discount/family-discount/) | \-55円/月・回線  <br>デュアルタイプ3回線目以降：\-165円/月・回線 |     |     |
| [複数回線割引](https://mineo.jp/service/discount/multiline-discount/) | \-55円/月・回線 |     |     |
| [おかえり割引](https://mineo.jp/service/discount/okaeri-discount/) | 初期事務手数料無料 |     |     |

![](https://mineo.jp/asset/img/common/service/icon_service.png)サービス仕様
---------------------------------------------------------------------

|     | A<br><br>Aプラン | D<br><br>Dプラン | S<br><br>Sプラン |
| --- | --- | --- | --- |
| 通話エリア | au 4G LTEサービスエリア※1<br><br>[条件詳細](http://www.kddi.com/corporate/kddi/public/mvno/user/) | Xi （クロッシィ）およびFOMA相当※2<br><br>[条件詳細](https://www.docomo.ne.jp/corporate/disclosure/mvno/user/index.html) | SoftBank 4G LTEエリア<br><br>[条件詳細](https://www.softbank.jp/corp/aboutus/public/mvno/user/) |
| 通信エリア | au 4G LTEサービスエリア、au 5Gサービスエリア※2<br><br>[条件詳細](http://www.kddi.com/corporate/kddi/public/mvno/user/) | Xi （クロッシィ）エリア、FOMAエリア※3、ドコモ 5Gエリア※2<br><br>[条件詳細](https://www.docomo.ne.jp/corporate/disclosure/mvno/user/index.html) | SoftBank 4G LTEおよびSoftBank 4Gエリア、SoftBank 5Gエリア※2<br><br>[条件詳細](https://www.softbank.jp/corp/aboutus/public/mvno/user/) |
| 通信速度 | au 4G LTEおよびau 5G相当※2<br><br>[条件詳細](http://www.kddi.com/corporate/kddi/public/mvno/user/) | Xi （クロッシィ）、FOMA※3およびドコモ 5G相当※2<br><br>[条件詳細](https://www.docomo.ne.jp/corporate/disclosure/mvno/user/index.html) | SoftBank 4G LTE、SoftBank 4GおよびSoftBank 5G相当※2<br><br>[条件詳細](https://www.softbank.jp/corp/aboutus/public/mvno/user/) |
| SIM形状 | SIMカード<br><br>[eSIM](https://mineo.jp/service/data/esim/) |     | SIMカード |
| テザリング | 無料  <br>iPhone、iPad: ![○](https://mineo.jp/asset/img/common/icon_maru.svg)  <br>その他端末: ![△](https://mineo.jp/asset/img/common/icon_sankaku.svg)※4 | 無料  <br>iPhone、iPad: ![○](https://mineo.jp/asset/img/common/icon_maru.svg)  <br>その他端末: ![△](https://mineo.jp/asset/img/common/icon_sankaku.svg)※4 |     |

*   ※1 au VoLTE対応SIM、および対応端末でのご利用時には、au 4G LTEサービスエリアとなります。
*   ※2 5Gエリア・通信速度でのご利用には、「5G通信オプション」のご利用、および5G通信に対応する端末が必要となります。本サービスにおける5G通信は、4G通信と設備を共用するため、5Gエリアにてアンテナピクト上は切り替りますが、混雑時の通信速度は必ずしも改善を保証するものではありません。
*   ※3 3G(FOMA)通信は「5G通信オプション」をご利用時はお使いいただけません。
*   ※4 SIMフリー端末等、一部端末はテザリング可能です。

ご注意事項

*   ・電話番号を引き継ぎされる方のみ番号ポータビリティ(MNP)が必要です。
*   ・音声通話とは、090/080/070で始まる電話番号での音声通話です。
*   ・別途[ユニバーサルサービス料](https://optage.co.jp/info/universal.html)
    および[電話リレーサービス料](https://optage.co.jp/info/telephonerelay.html)
    が必要となります。シングルタイプの020で始まる番号の回線は対象外です。
*   ・通信速度は、送受信時の技術規格上の最大値であり、実際の通信速度を示すものではありません。ベストエフォート方式による提供となり、実際の通信速度は、通信環境やネットワークの混雑状況に応じて変化します。

さあ、mineoをはじめよう！
---------------

*    [![](https://mineo.jp/asset/img/common/conversion_icon_apply.png) mineoに申し込む](https://mineo.jp/apply/)
    
*    [![](https://mineo.jp/asset/img/common/conversion_icon_sim.png) 料金をシミュレーションする](https://mineo.jp/simulator/)
    

### ご検討の方は、こちらもチェック！

*   [![](https://mineo.jp/asset/img/common/card_icon/card_icon_reason.png)\
    \
    mineoが選ばれる理由\
    \
    ほかの会社とどこが違うの？](https://mineo.jp/reason/)
    
*   [![](https://mineo.jp/asset/img/common/card_icon/card_icon_guide.png)\
    \
    申込ガイド\
    \
    申し込みの流れは？](https://mineo.jp/apply/simonly-flow/)
    

[料金シミュレーション](https://mineo.jp/simulator/)

*   [mineoホーム](https://mineo.jp/)
    
*   [料金・サービス](https://mineo.jp/price-service/)
    
*   料金表

*   [![facebook](https://mineo.jp/asset/img/common/template/icon_sns_fb.png)](https://www.facebook.com/mineo.jp)
    
*   [![LINE](https://mineo.jp/asset/img/common/template/icon_sns_ln.png)](https://line.me/R/ti/p/%40pdp9012a)
    
*   [![X](https://mineo.jp/asset/img/common/template/icon_sns_x.png)](https://twitter.com/mineojp)
    
*   [![YouTube](https://mineo.jp/asset/img/common/template/icon_sns_yt.png)](https://www.youtube.com/user/mineoofficial)
    
*   [![Instagram](https://mineo.jp/asset/img/common/template/icon_sns_ig.png)](https://www.instagram.com/mineo_jp/)
    

[![格安SIM・格安スマホのmineo](https://mineo.jp/asset/img/common/template/logo_mineo.png)](https://mineo.jp/)

*   mineoの特長
    
    *   [はじめての方へ](https://mineo.jp/beginner/)
        
    *   [mineoが選ばれる理由](https://mineo.jp/reason/)
        
    *   [ブランドステートメント](https://mineo.jp/brand/)
        
    
    料金・サービス
    
    *   [料金表](https://mineo.jp/price/)
        
    *   [サービス・オプション一覧](https://mineo.jp/service/)
        
    *   [かんたん料金シミュレーション](https://mineo.jp/simulator/)
        
    
*   端末
    
    *   [mineoで使う端末を選ぶ](https://mineo.jp/device/about/)
        
    *   mineoで端末を買う
    *   [iPhone](https://mineo.jp/device/iphone/)
        
    *   [スマートフォン](https://mineo.jp/device/smartphone/)
        
    *   [タブレット・ルーター](https://mineo.jp/device/other/)
        
    *   お手持ちの端末を使う
    *   [動作確認済み端末検索](https://mineo.jp/device/devicelist/)
        
    
    店舗
    
    *   [店舗を探す](https://mineo.jp/shop/)
        
    *   [店舗でできること](https://mineo.jp/shop/about/)
        
    *   [店舗でSIMを受け取る](https://mineo.jp/shop/online/counter/)
        
    
*   申込ガイド
    
    *   準備からお申し込みの流れ
    *   [お手持ちの端末をそのまま使う方](https://mineo.jp/apply/simonly-flow/)
        
    *   [mineoで端末も一緒に買いたい方](https://mineo.jp/apply/device-flow/)
        
    *   SIMカードや端末が届いたら
    *   [初期設定～ご利用開始の流れ](https://mineo.jp/apply/setup-flow/)
        
    
    サポート
    
    *   [ユーザーサポート](https://support.mineo.jp/)
        
    *   [初期設定・各種設定](https://support.mineo.jp/setup/guide/)
        
    *   [よくあるご質問](https://support.mineo.jp/usqa/)
        
    *   [AIチャットサポート](https://mineo.jp/r/mai_chat/)
        
    *   [お問い合わせ](https://support.mineo.jp/inquiry.html)
        
    
*   コミュニティ
    
    *   [マイネ王サイト](https://king.mineo.jp/)
        
    *   [マイネ王はじめてガイド](https://king.mineo.jp/beginner_guide.html)
        
    *   おすすめコンテンツ
    *   [レビュー](https://king.mineo.jp/reviews/)
        
    *   [Q&A](https://king.mineo.jp/question-answer/)
        
    *   [アイデアファーム](https://king.mineo.jp/ideas/)
        
    *   [フリータンク](https://king.mineo.jp/freetank/)
        
    

*   *   [![](https://mineo.jp/asset/img/common/template/icon_mypage.png)マイページ](https://my.mineo.jp/)
        
    *     [![](https://mineo.jp/asset/img/common/template/icon_apply_wh.png) ![](https://mineo.jp/asset/img/common/template/icon_apply_pink.png)お申し込み](https://mineo.jp/apply/)
        
*   *   [法人のお客さま](https://mineo.jp/r/biz/link_footer.html)
        
    *   [お知らせ](https://mineo.jp/#info)
        
    *   [キャンペーン](https://mineo.jp/campaign/)
        
    *   [特集](https://mineo.jp/special/)
        

     ![検索](https://mineo.jp/asset/img/common/icon_search.png)

記載の価格は税抜記載のものを除き税込です。税込価格は2021年4月1日現在の税率（10%）に基づく金額です。税率に応じて金額は変更されます。

[![株式会社オプテージ](https://mineo.jp/asset/img/common/template/logo_optage.png)](https://optage.co.jp/)

*   [第三者認証](https://optage.co.jp/company/authorization/safesecurityisp.html)
    
*   [情報セキュリティポリシー](https://optage.co.jp/info/security.html)
    
*   [プライバシーポリシー](https://optage.co.jp/info/privacy/)
    
*   [Cookie等の外部送信について](https://optage.co.jp/info/informative.html)
    
*   [サイトのご利用にあたって](https://mineo.jp/site/terms/)
    
*   [特定商取引法に基づく表示](https://mineo.jp/site/law/)
    
*   [ユニバーサルサービス料について](https://optage.co.jp/info/universal.html)
    
*   [電話リレーサービス料について](https://optage.co.jp/info/telephonerelay.html)
    
*   [企業情報](https://optage.co.jp/company/)
    
*   [古物営業法に基づく表示](https://optage.co.jp/company/authorization/)
    

© OPTAGE Inc.

[月額基本料金](https://mineo.jp/price/#basic)
 [通話料・SMS](https://mineo.jp/price/#voice-sms)
 [メール](https://mineo.jp/price/#mail)
 [通信](https://mineo.jp/price/#data)
 [初期費用](https://mineo.jp/price/#charge)
 [事務手数料](https://mineo.jp/price/#fee)
 [割引](https://mineo.jp/price/#discount)
 [サービス仕様](https://mineo.jp/price/#service-spec)
