# マイピタ｜料金表｜格安スマホ・格安SIM【mineo(マイネオ)】

URL: https://mineo.jp/price/mypita/

---

[![格安SIM・格安スマホのmineo](https://mineo.jp/asset/img/common/template/logo_mineo_white.png)](https://mineo.jp/)

*   [法人のお客さま](https://mineo.jp/r/biz/link_header.html)
    
*   [お知らせ](https://mineo.jp/#info)
    
*   [キャンペーン](https://mineo.jp/campaign/)
    
*   [特集](https://mineo.jp/special/)
    
*        ![検索](https://mineo.jp/asset/img/common/icon_search.png)
    

*   [![](https://mineo.jp/asset/img/common/template/icon_menu_feature.png)\
    \
    mineoの  \
    特長](https://mineo.jp/price/mypita/#header-menu-feature)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_service.png)\
    \
    料金・  \
    サービス](https://mineo.jp/price/mypita/#header-menu-service)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_device.png)\
    \
    端末](https://mineo.jp/price/mypita/#header-menu-device)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_shop.png)\
    \
    店舗](https://mineo.jp/price/mypita/#header-menu-shop)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_guide.png)\
    \
    申込ガイド](https://mineo.jp/price/mypita/#header-menu-guide)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_support.png)\
    \
    サポート](https://mineo.jp/price/mypita/#header-menu-support)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_king.png)\
    \
    コミュニティ](https://mineo.jp/price/mypita/#header-menu-king)
    

*   [![](https://mineo.jp/asset/img/common/template/icon_mypage.png)\
    \
    マイページ](https://my.mineo.jp/)
    
*    [![](https://mineo.jp/asset/img/common/template/icon_apply_wh.png) ![](https://mineo.jp/asset/img/common/template/icon_apply_pink.png)\
    \
    お申し込み](https://mineo.jp/apply/)
    

メニュー

[![格安SIM・格安スマホのmineo](https://mineo.jp/asset/img/common/template/logo_mineo.png)](https://mineo.jp/)

*   [![](https://mineo.jp/asset/img/common/template/icon_menu_feature.png)\
    \
    mineoの  \
    特長](https://mineo.jp/price/mypita/#header-menu-feature)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_service.png)\
    \
    料金・  \
    サービス](https://mineo.jp/price/mypita/#header-menu-service)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_device.png)\
    \
    端末](https://mineo.jp/price/mypita/#header-menu-device)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_shop.png)\
    \
    店舗](https://mineo.jp/price/mypita/#header-menu-shop)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_guide.png)\
    \
    申込ガイド](https://mineo.jp/price/mypita/#header-menu-guide)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_support.png)\
    \
    サポート](https://mineo.jp/price/mypita/#header-menu-support)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_menu_king.png)\
    \
    コミュニティ](https://mineo.jp/price/mypita/#header-menu-king)
    

*   [![](https://mineo.jp/asset/img/common/template/icon_mypage.png)\
    \
    マイページ](https://my.mineo.jp/)
    
*    [![](https://mineo.jp/asset/img/common/template/icon_apply_wh.png) ![](https://mineo.jp/asset/img/common/template/icon_apply_pink.png)\
    \
    お申し込み](https://mineo.jp/apply/)
    

![](https://mineo.jp/asset/img/common/template/header_mark.png)

閉じる

     ![検索](https://mineo.jp/asset/img/common/icon_search.png)

*   [![](https://mineo.jp/asset/img/common/template/icon_mypage.png)\
    \
    マイページ](https://my.mineo.jp/)
    
*   [![](https://mineo.jp/asset/img/common/template/icon_apply_wh.png)\
    \
    お申し込み](https://mineo.jp/apply/)
    

![](https://mineo.jp/asset/img/common/template/icon_menu_feature.png)

mineoの特長

[はじめての方へ](https://mineo.jp/beginner/)
 [mineoが選ばれる理由](https://mineo.jp/reason/)
 [Fun with Fans！](https://mineo.jp/brand/)

![](https://mineo.jp/asset/img/common/template/icon_menu_service.png)

料金・サービス

[料金表](https://mineo.jp/price/)
 [サービス・オプション一覧](https://mineo.jp/service/)
 [かんたん料金シミュレーション](https://mineo.jp/simulator/)

[![](https://mineo.jp/asset/img/common/template/icon_menu_campaign.png)\
\
キャンペーン](https://mineo.jp/campaign/)

![](https://mineo.jp/asset/img/common/template/icon_menu_device.png)

端末

[mineoで使う端末を選ぶ](https://mineo.jp/device/about/)
 [iPhone](https://mineo.jp/device/iphone/)
 [スマートフォン](https://mineo.jp/device/smartphone/)
 [タブレット・ルーター](https://mineo.jp/device/other/)
 [動作確認済み端末検索](https://mineo.jp/device/devicelist/)

![](https://mineo.jp/asset/img/common/template/icon_menu_shop.png)

店舗

[店舗を探す](https://mineo.jp/shop/)
 [店舗でできること](https://mineo.jp/shop/about/)
 [店舗でSIMを受け取る](https://mineo.jp/shop/online/counter/)

![](https://mineo.jp/asset/img/common/template/icon_menu_guide.png)

申込ガイド

[お手持ちの端末をそのまま使う方](https://mineo.jp/apply/simonly-flow/)
 [mineoで端末も一緒に買いたい方](https://mineo.jp/apply/device-flow/)
 [初期設定～ご利用開始の流れ](https://mineo.jp/apply/setup-flow/)
 [お申し込み](https://mineo.jp/apply/)

![](https://mineo.jp/asset/img/common/template/icon_menu_support.png)

サポート

[ユーザーサポートTOP](https://support.mineo.jp/)
 [初期設定・各種設定](https://support.mineo.jp/setup/guide/)
 [よくあるご質問](https://support.mineo.jp/usqa/)
 [AIチャットサポート](https://mineo.jp/r/mai_chat/)
 [お問い合わせ](https://support.mineo.jp/inquiry.html)

[![](https://mineo.jp/asset/img/common/template/icon_menu_king.png)\
\
コミュニティ](https://king.mineo.jp/)
[![](https://mineo.jp/asset/img/common/template/icon_menu_news.png)\
\
お知らせ](https://support.mineo.jp/news_list/)
[![](https://mineo.jp/asset/img/common/template/icon_menu_special.png)\
\
特集](https://mineo.jp/special/)
[![](https://mineo.jp/asset/img/common/template/icon_menu_column.png)\
\
お役立ちコラム](https://mineo.jp/column/)
[![](https://mineo.jp/asset/img/common/template/icon_menu_business.png)\
\
法人のお客さま](https://mineo.jp/r/biz/link_header.html)

[![](https://mineo.jp/asset/img/common/template/logo_mineo.svg)](https://mineo.jp/)

![](https://mineo.jp/asset/img/common/template/icon_menu_feature.png)

mineoの特長

[](https://mineo.jp/price/mypita/#)

*   mineo（マイネオ）や格安スマホサービスがはじめての方へ
    
      [![](https://mineo.jp/asset/img/common/template/icon_feature_beginner.png?v20230614) ![](https://mineo.jp/asset/img/common/template/icon_feature_beginner.png?v20230614) はじめての方へ](https://mineo.jp/beginner/)
    
*   格安スマホサービスの中でも選ばれるのには理由があります！
    
      [![](https://mineo.jp/asset/img/common/template/icon_feature_reason.png?v20230614) ![](https://mineo.jp/asset/img/common/template/icon_feature_reason.png?v20230614) mineoが選ばれる理由](https://mineo.jp/reason/)
    
*    [![ブランドステートメント Fun with Fans!](https://mineo.jp/asset/img/common/template/feature-banner.png?v20190731) ![ブランドステートメント Fun with Fans!](https://mineo.jp/asset/img/common/template/sp/feature-banner.png?v20190731)](https://mineo.jp/brand/)
    

*   [![お役立ちコラム](https://mineo.jp/_mg/_uploads/files/4fce8fccb3fa0a96_mineo_Gnavi_bnr_B.jpg)](https://mineo.jp/column/)
    

![](https://mineo.jp/asset/img/common/template/icon_menu_service.png)

料金・サービス

[](https://mineo.jp/price/mypita/#)

*     [![](https://mineo.jp/asset/img/common/template/icon_service_price.png) ![](https://mineo.jp/asset/img/common/template/icon_service_price.png) 料金表](https://mineo.jp/price/)
    
*    [![](https://mineo.jp/asset/img/common/template/icon_service_option.png) サービス・オプション一覧](https://mineo.jp/service/)
    
*     [![](https://mineo.jp/asset/img/common/template/icon_service_simulator.png?v20210401) ![](https://mineo.jp/asset/img/common/template/icon_service_simulator.png?v20210401) かんたん料金シミュレーション](https://mineo.jp/simulator/)
    

*   [![おトクなキャンペーン情報](https://mineo.jp/_mg/_uploads/files/3897e85cae780a5f_maipyon_banner.jpg)](https://mineo.jp/campaign/)
    
*   [![法人のお客さまはこちら](https://mineo.jp/_mg/_uploads/files/13c4fc24b5f50ae4_business.jpg)](https://mineo.jp/r/biz/link_drop/)
    

![](https://mineo.jp/asset/img/common/template/icon_menu_device.png)

端末

[](https://mineo.jp/price/mypita/#)

*   持ち込みも買い替えも自由に選べる！
    
      [![](https://mineo.jp/asset/img/common/template/icon_device_about.png) ![](https://mineo.jp/asset/img/common/template/icon_device_about.png) mineoで使う  \
    端末を選ぶ](https://mineo.jp/device/about/)
    
*   mineoで端末を買う
    
     [![](https://mineo.jp/asset/img/common/template/icon_device_iphone.png) iPhone](https://mineo.jp/device/iphone/)
    [![](https://mineo.jp/asset/img/common/template/icon_device_smartphone.png) スマートフォン](https://mineo.jp/device/smartphone/)
    [![](https://mineo.jp/asset/img/common/template/icon_device_other.png) タブレット・ルーター](https://mineo.jp/device/other/)
    
*   お手持ちの端末を使う
    
      [![](https://mineo.jp/asset/img/common/template/icon_device_devicelist.png) ![](https://mineo.jp/asset/img/common/template/icon_device_devicelist.png) 動作確認済み  \
    端末検索](https://mineo.jp/device/devicelist/)
    

*   [![mineoスマホコーティング](https://mineo.jp/_mg/_uploads/files/ebd51d24a7bb0a3f_mineo_Gnavi_bnr_smartphone_coating_A.jpg)](https://mineo.jp/service/discount/coating/)
    

![](https://mineo.jp/asset/img/common/template/icon_menu_shop.png)

店舗

[](https://mineo.jp/price/mypita/#)

Webでの新規申し込みが不安な方は、お気軽にご来店ください。

*     [![](https://mineo.jp/asset/img/common/template/icon_shop_search.png) ![](https://mineo.jp/asset/img/common/template/icon_shop_search.png) 店舗を探す](https://mineo.jp/shop/)
    
*     [![](https://mineo.jp/asset/img/common/template/icon_shop_about.png) ![](https://mineo.jp/asset/img/common/template/icon_shop_about.png) 店舗でできること](https://mineo.jp/shop/about/)
    
*     [![](https://mineo.jp/asset/img/common/template/icon_shop_online.png) ![](https://mineo.jp/asset/img/common/template/icon_shop_online.png) 店舗でSIMを受け取る](https://mineo.jp/shop/online/counter/)
    

![](https://mineo.jp/asset/img/common/template/icon_menu_guide.png)

申込ガイド

[](https://mineo.jp/price/mypita/#)

*   準備からお申し込みの流れ
    
     [![](https://mineo.jp/asset/img/common/template/icon_apply_simonly.png) お手持ちの端末を  \
    そのまま使う方](https://mineo.jp/apply/simonly-flow/)
    [![](https://mineo.jp/asset/img/common/template/icon_apply_device.png) mineoで端末も  \
    一緒に買いたい方](https://mineo.jp/apply/device-flow/)
    
*   SIMカードや端末が届いたら
    
      [![](https://mineo.jp/asset/img/common/template/icon_apply_flow.png?v20211000) ![](https://mineo.jp/asset/img/common/template/icon_apply_flow.png?v20211000) 初期設定～  \
    ご利用開始の流れ](https://mineo.jp/apply/setup-flow/)
    
*   お申し込みページでご契約
    
      [![](https://mineo.jp/asset/img/common/template/icon_apply_entry.png) ![](https://mineo.jp/asset/img/common/template/icon_apply_entry.png) お申し込み](https://mineo.jp/apply/)
    

![](https://mineo.jp/asset/img/common/template/icon_menu_support.png)

サポート

[](https://mineo.jp/price/mypita/#)

*   mineoユーザーサポート
    
      [![](https://mineo.jp/asset/img/common/template/icon_support_top.png?v20210401) ![](https://mineo.jp/asset/img/common/template/icon_support_top.png?v20210401) ユーザーサポートTOP](https://support.mineo.jp/)
    
*   設定でわからないことを調べる
    
     [![](https://mineo.jp/asset/img/common/template/icon_support_setup.png) 初期設定・各種設定](https://support.mineo.jp/setup/guide/)
    [![](https://mineo.jp/asset/img/common/template/icon_support_faq.png) よくあるご質問](https://support.mineo.jp/usqa/)
    
*   わからないこと、不安なことがあればお問い合わせを
    
     [![](https://mineo.jp/asset/img/common/template/icon_support_chat.png) AIチャットサポート](https://mineo.jp/r/mai_chat/)
    [![](https://mineo.jp/asset/img/common/template/icon_support_inquiry.png) お問い合わせ](https://support.mineo.jp/inquiry.html)
    

![](https://mineo.jp/asset/img/common/template/icon_menu_king.png)

コミュニティ

[](https://mineo.jp/price/mypita/#)

*   マイネ王は、全国のmineoユーザーやmineoスタッフたちが交流しているコミュニティサイトです。
    
    [![](https://mineo.jp/asset/img/common/template/icon_king_guide.png)](https://king.mineo.jp/beginner_guide.html)
    
     [![](https://mineo.jp/asset/img/common/template/icon_king_top.png) コミュニティサイト  \
    マイネ王](https://king.mineo.jp/)
    
*   おすすめコンテンツ
    
    mineoのサービスや端末のレビュー [![](https://mineo.jp/asset/img/common/template/icon_king_review.png) レビュー](https://king.mineo.jp/reviews/)
    
    みんなの疑問と回答 [![](https://mineo.jp/asset/img/common/template/icon_king_faq.png) Q&A](https://king.mineo.jp/question-answer/)
    
*     
    
    mineoに対するみんなの提案 [![](https://mineo.jp/asset/img/common/template/icon_king_idea.png) アイデアファーム](https://king.mineo.jp/ideas/)
    
    パケットをシェアして助け合い [![](https://mineo.jp/asset/img/common/template/icon_king_freetank.png) フリータンク](https://king.mineo.jp/freetank/)
    

マイネ王は、全国のmineoユーザーや  
mineoスタッフたちが交流している  
コミュニティサイトです。 [![](https://mineo.jp/asset/img/common/template/icon_king_top.png) コミュニティサイト  \
マイネ王](https://king.mineo.jp/)

[![](https://mineo.jp/asset/img/common/template/icon_king_guide.png)](https://king.mineo.jp/beginner_guide.html)

おすすめコンテンツ

*   mineoのサービスや端末の  
    レビュー [![](https://mineo.jp/asset/img/common/template/icon_king_review.png) レビュー](https://king.mineo.jp/reviews/)
    
*   みんなの疑問と回答  
      
     [![](https://mineo.jp/asset/img/common/template/icon_king_faq.png) Q&A](https://king.mineo.jp/question-answer/)
    

*   mineoに対するみんなの提案 [![](https://mineo.jp/asset/img/common/template/icon_king_idea.png) アイデア  \
    ファーム](https://king.mineo.jp/ideas/)
    
*   パケットをシェアして助け合い [![](https://mineo.jp/asset/img/common/template/icon_king_freetank.png) フリータンク](https://king.mineo.jp/freetank/)
    

マイピタ
====

 ![毎月必要なデータ容量で選ぶ マイピタ](https://mineo.jp/asset/img/price/mypita/sp/mv.jpg)

マイピタって？
-------

自分に合ったデータ容量を  
選べるので  
ムダなくおトクに  
使える料金プラン！

*   POINT1
    
    データ容量は5種類から選べる
    
    *   3GB
    *   7GB
    *   15GB
    *   30GB
    *   50GB
*   POINT2
    
    余ったデータ容量は翌月に繰り越せる
    
    ![](https://mineo.jp/asset/img/price/mypita/about_pic_01.png)
    

### あなたにぴったりの  
コースが選べる！  
無料でオプションが  
使えるコースも！

3GB

 ![](https://mineo.jp/asset/img/price/mypita/sp/course_pic_01.png)

音声通話＋データ通信

（デュアルタイプ）

1,298円/月

データ通信のみ

（シングルタイプ）

880円/月

7GB

 ![](https://mineo.jp/asset/img/price/mypita/sp/course_pic_02.png)

音声通話＋データ通信

（デュアルタイプ）

1,518円/月

データ通信のみ

（シングルタイプ）

1,265円/月

15GB

 ![](https://mineo.jp/asset/img/price/mypita/sp/course_pic_03.png)

音声通話＋データ通信

（デュアルタイプ）

1,958円/月

データ通信のみ

（シングルタイプ）

1,705円/月

パケット放題 Plusが無料で使える！

*   [![](https://mineo.jp/asset/img/price/mypita/icon_packetfree.png)\
    \
    パケット放題 Plus\
    \
    最大1.5Mbpsで  \
    データ通信が使い放題！\
    \
    *   ○ 混雑回避のための速度制限（3日間で10GB以上利用時）があります。](https://mineo.jp/service/data/packet-free/)
    

*   ○ オプションのご利用には別途お申し込みが必要です。

30GB

 ![](https://mineo.jp/asset/img/price/mypita/sp/course_pic_04.png)

音声通話＋データ通信

（デュアルタイプ）

2,178円/月

データ通信のみ

（シングルタイプ）

1,925円/月

パケット放題 Plusが無料で使える！

*   [![](https://mineo.jp/asset/img/price/mypita/icon_packetfree.png)\
    \
    パケット放題 Plus\
    \
    最大1.5Mbpsで  \
    データ通信が使い放題！\
    \
    *   ○ 混雑回避のための速度制限（3日間で10GB以上利用時）があります。](https://mineo.jp/service/data/packet-free/)
    

*   ○ オプションのご利用には別途お申し込みが必要です。

50GB

 ![](https://mineo.jp/asset/img/price/mypita/sp/course_pic_05.png)

音声通話＋データ通信

（デュアルタイプ）

2,948円/月

データ通信のみ

（シングルタイプ）

2,695円/月

3つのオプションが無料で使える！

*   [![](https://mineo.jp/asset/img/price/mypita/icon_packetfree.png)\
    \
    パケット放題 Plus\
    \
    最大1.5Mbpsで  \
    データ通信が使い放題！\
    \
    *   ○ 混雑回避のための速度制限（3日間で10GB以上利用時）があります。](https://mineo.jp/service/data/packet-free/)
    
*   [![](https://mineo.jp/asset/img/price/mypita/icon_pasket.png)\
    \
    パスケット\
    \
    余ったパケットを  \
    無期限で繰り越し！](https://mineo.jp/service/data/pasket/)
    
*   [![](https://mineo.jp/asset/img/price/mypita/icon_nightfree.png)\
    \
    夜間フリー\
    \
    夜間（22時半～7時半）の  \
    データ通信が使い放題！](https://mineo.jp/service/data/nightfree/)
    

*   ○ 各オプションのご利用には別途お申し込みが必要です。

 ![おすすめのオプションサービスが今ならおトク！](https://mineo.jp/asset/img/price/mypita/sp/cp_title.png?v20251126)

[![2/2まで最大6カ月間無料キャンペーン パスケット パスケットの中に貯まっているパケットはずっと繰り越し可能！](https://mineo.jp/asset/img/price/bnr_pasket_20251126.jpg)](https://mineo.jp/service/data/pasket/)

便利で多様な  
パケットサービスも使える！

*   [![](https://mineo.jp/asset/img/price/mypita/icon_freetank.png)\
    \
    フリータンク\
    \
    全国のmineoユーザーで  \
    パケットをシェア！](https://mineo.jp/service/data/freetank/)
    
*   [![](https://mineo.jp/asset/img/price/mypita/icon_packetgift.png)\
    \
    パケットギフト\
    \
    余ったパケットをギフトとして  \
    家族や友人に贈ることができる！](https://mineo.jp/service/data/packet-gift/)
    
*   [![](https://mineo.jp/asset/img/price/mypita/icon_packetshare.png)\
    \
    パケットシェア\
    \
    繰り越したパケットを  \
    パケットシェアメンバーで共有！](https://mineo.jp/service/data/packet-share/)
    

よくあるご質問
-------

データ容量を使い切ったらどうなるの？

データ通信量が当月利用分の上限（基本データ容量）を超えた場合、通信速度が「200kbps」に制限され、最大通信速度でご利用いただけなくなります。  
[パケットチャージ](https://mineo.jp/service/data/packet-charge/)
をご利用いただくことで、チャージした分の制限が解除され、最大通信速度にてご利用いただけます。

使い切れなかったパケットを繰り越しすることはできる？

当月に使い切れなかったパケットは容量に制限なくすべて、翌月に自動で繰り越しされます。翌月に繰り越したパケットは、優先的に消費されます。  
翌月中にも消費されない繰り越し分のパケットは、翌々月以降は消滅します。

コース変更（基本データ容量の変更／マイピタ⇔マイそくの変更）はできる？

コース変更（基本データ容量の変更／マイピタ⇔マイそくの変更）は、「[マイページ](https://my.mineo.jp/)
」よりお手続きいただけます。コース変更に伴う手数料は無料です。  
（毎月25日までに変更のお手続きをされた場合、お手続きの翌月から変更が適用となります。26日から月末まではお申し込みいただけませんので、ご注意ください。）

解約時に手数料はかかるの？

解約時の手数料は発生しません。他社へ乗り換える場合も無料です。最低利用期間もありませんので、ご安心ください。

ご注意事項

*   ・容量を使い切った後も最大200kbpsで通信可能です。
*   ・初期費用として、契約事務手数料、SIMカード発行料またはeSIMプロファイル発行料が必要です。
*   ・別途ユニバーサルサービス料および電話リレーサービス料が必要となります。
*   ・従来のデータ容量で選ぶマイピタとマイそくは月に一度コース変更することができます。
*   ・マイピタおよびマイそくの他コースからマイそく スーパーライトへコース変更することはできません。
*   ・パケット放題 Plusは、基本データ容量3GB以下のデータ通信のみ（シングルタイプ）ではお申し込みいただけません。

*   #### 新規の方はこちら
    
    [mineoに新規お申し込み](https://mineo.jp/apply/)
    
*   #### ご利用中のmineo回線を変更
    
    [コース変更お申し込み](https://my.mineo.jp/)
    

気軽にお試しできる

[mineo プチ体験](https://mineo.jp/service/unique/prepaid/)

 ![もうひとつの料金プラン『マイそく』もチェック](https://mineo.jp/asset/img/price/mypita/sp/mysoku_title.png)

 [![最大通信速度で選ぶデータ無制限※プラン マイそく](https://mineo.jp/asset/img/price/mypita/sp/bnr_mysoku.png)](https://mineo.jp/price/mysoku/)

*   ※ 月曜～金曜の12時台は最大32kbps（プレミアムのみ最大200kbps）になります。  
    また混雑回避のための速度制限（3日間で10GB以上利用時）および通信最適化が適用されます。

[料金をシミュレーションする](https://mineo.jp/simulator/)

*   [mineoホーム](https://mineo.jp/)
    
*   [料金表](https://mineo.jp/price/)
    
*   マイピタ

*   [![facebook](https://mineo.jp/asset/img/common/template/icon_sns_fb.png)](https://www.facebook.com/mineo.jp)
    
*   [![LINE](https://mineo.jp/asset/img/common/template/icon_sns_ln.png)](https://line.me/R/ti/p/%40pdp9012a)
    
*   [![X](https://mineo.jp/asset/img/common/template/icon_sns_x.png)](https://twitter.com/mineojp)
    
*   [![YouTube](https://mineo.jp/asset/img/common/template/icon_sns_yt.png)](https://www.youtube.com/user/mineoofficial)
    
*   [![Instagram](https://mineo.jp/asset/img/common/template/icon_sns_ig.png)](https://www.instagram.com/mineo_jp/)
    

[![格安SIM・格安スマホのmineo](https://mineo.jp/asset/img/common/template/logo_mineo.png)](https://mineo.jp/)

*   mineoの特長
    
    *   [はじめての方へ](https://mineo.jp/beginner/)
        
    *   [mineoが選ばれる理由](https://mineo.jp/reason/)
        
    *   [ブランドステートメント](https://mineo.jp/brand/)
        
    
    料金・サービス
    
    *   [料金表](https://mineo.jp/price/)
        
    *   [サービス・オプション一覧](https://mineo.jp/service/)
        
    *   [かんたん料金シミュレーション](https://mineo.jp/simulator/)
        
    
*   端末
    
    *   [mineoで使う端末を選ぶ](https://mineo.jp/device/about/)
        
    *   mineoで端末を買う
    *   [iPhone](https://mineo.jp/device/iphone/)
        
    *   [スマートフォン](https://mineo.jp/device/smartphone/)
        
    *   [タブレット・ルーター](https://mineo.jp/device/other/)
        
    *   お手持ちの端末を使う
    *   [動作確認済み端末検索](https://mineo.jp/device/devicelist/)
        
    
    店舗
    
    *   [店舗を探す](https://mineo.jp/shop/)
        
    *   [店舗でできること](https://mineo.jp/shop/about/)
        
    *   [店舗でSIMを受け取る](https://mineo.jp/shop/online/counter/)
        
    
*   申込ガイド
    
    *   準備からお申し込みの流れ
    *   [お手持ちの端末をそのまま使う方](https://mineo.jp/apply/simonly-flow/)
        
    *   [mineoで端末も一緒に買いたい方](https://mineo.jp/apply/device-flow/)
        
    *   SIMカードや端末が届いたら
    *   [初期設定～ご利用開始の流れ](https://mineo.jp/apply/setup-flow/)
        
    
    サポート
    
    *   [ユーザーサポート](https://support.mineo.jp/)
        
    *   [初期設定・各種設定](https://support.mineo.jp/setup/guide/)
        
    *   [よくあるご質問](https://support.mineo.jp/usqa/)
        
    *   [AIチャットサポート](https://mineo.jp/r/mai_chat/)
        
    *   [お問い合わせ](https://support.mineo.jp/inquiry.html)
        
    
*   コミュニティ
    
    *   [マイネ王サイト](https://king.mineo.jp/)
        
    *   [マイネ王はじめてガイド](https://king.mineo.jp/beginner_guide.html)
        
    *   おすすめコンテンツ
    *   [レビュー](https://king.mineo.jp/reviews/)
        
    *   [Q&A](https://king.mineo.jp/question-answer/)
        
    *   [アイデアファーム](https://king.mineo.jp/ideas/)
        
    *   [フリータンク](https://king.mineo.jp/freetank/)
        
    

*   *   [![](https://mineo.jp/asset/img/common/template/icon_mypage.png)マイページ](https://my.mineo.jp/)
        
    *     [![](https://mineo.jp/asset/img/common/template/icon_apply_wh.png) ![](https://mineo.jp/asset/img/common/template/icon_apply_pink.png)お申し込み](https://mineo.jp/apply/)
        
*   *   [法人のお客さま](https://mineo.jp/r/biz/link_footer.html)
        
    *   [お知らせ](https://mineo.jp/#info)
        
    *   [キャンペーン](https://mineo.jp/campaign/)
        
    *   [特集](https://mineo.jp/special/)
        

     ![検索](https://mineo.jp/asset/img/common/icon_search.png)

記載の価格は税抜記載のものを除き税込です。税込価格は2021年4月1日現在の税率（10%）に基づく金額です。税率に応じて金額は変更されます。

[![株式会社オプテージ](https://mineo.jp/asset/img/common/template/logo_optage.png)](https://optage.co.jp/)

*   [第三者認証](https://optage.co.jp/company/authorization/safesecurityisp.html)
    
*   [情報セキュリティポリシー](https://optage.co.jp/info/security.html)
    
*   [プライバシーポリシー](https://optage.co.jp/info/privacy/)
    
*   [Cookie等の外部送信について](https://optage.co.jp/info/informative.html)
    
*   [サイトのご利用にあたって](https://mineo.jp/site/terms/)
    
*   [特定商取引法に基づく表示](https://mineo.jp/site/law/)
    
*   [ユニバーサルサービス料について](https://optage.co.jp/info/universal.html)
    
*   [電話リレーサービス料について](https://optage.co.jp/info/telephonerelay.html)
    
*   [企業情報](https://optage.co.jp/company/)
    
*   [古物営業法に基づく表示](https://optage.co.jp/company/authorization/)
    

© OPTAGE Inc.

![](https://acv.mira-dsp.com/v1/image?tag_id=9060bb35-fbb5-484f-8045-5cd2db32902c)
