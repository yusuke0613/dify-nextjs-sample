# 【公式】NURO 光 高速 光回線インターネット

URL: https://www.nuro.jp/

---

![SONY](https://www.nuro.jp/common/assets/images/1.0/logo_sony.png)

[![NURO光](https://www.nuro.jp/common/assets/images/1.0/header_logo-hikari.png)](https://www.nuro.jp/hikari/)

=============================================================================================================

[会員サポート](https://www.nuro.jp/support/)

個人向けサービス

[NURO 光 2ギガ/10ギガプラン](https://www.nuro.jp/hikari/)

[NURO 光 20ギガプラン](https://www.nuro.jp/s_plan/20gs/)

[NURO Wireless 5G](https://wireless.nuro.jp/)

法人向けサービス

[NURO Biz](https://biz.nuro.jp/)

[NURO 光 Connect](https://sonyncc.co.jp/cp2/)

[MOREVE](https://wireless.nuro.jp/moreve/)

お問い合わせ

[NURO 光 会員サポート](https://www.nuro.jp/support/)

*   [障害・メンテナンス情報](https://www.nuro.jp/emerge/)
    
*   [ご提供する機器について](https://www.nuro.jp/device.html)
    
*   [ウェブサイトご利用条件](https://www.nuro.jp/siteinfo/nuro/)
    

![](https://www.nuro.jp/guideline/images/kv_bg_pc.png?v=721b5037d6)

![NURO 光](https://www.nuro.jp/guideline/images/logo.png?v=cd05c1f67d)

*   ![個人のお客さま](https://www.nuro.jp/guideline/images/kv_img_01.png?v=c0703ae5b7)
    
    個人のお客さま
    
*   ![法人・集合住宅オーナーさま](https://www.nuro.jp/guideline/images/kv_img_02.png?v=9a7b44e1c2)
    
    法人のお客さま  
    集合住宅オーナーさま
    

お知らせ
----

[お知らせ一覧](https://www.nuro.jp/news_release/)

*   [2025年11月24日ネットワーク設備の増強について【2025年11月24日更新】](https://www.nuro.jp/quality/network_enhancement/)
    
*   *   [2025年10月1日自動口座振替サービス ご請求方法の変更について](https://www.nuro.jp/news_release/20251001/)
        
    *   [2025年9月17日令和７年９月12日からの大雨に伴う災害に係る 災害救助法の適用について](https://www.nuro.jp/news_release/20250917/)
        
    *   [2025年9月15日NUROサービス 会員規約本則の改訂について](https://www.nuro.jp/news_release/20250915/)
        
    *   [2025年9月10日令和７年８月６日からの低気圧と前線による大雨に伴う災害に係る 災害救助法の適用について](https://www.nuro.jp/news_release/20250910/)
        
    *   [2025年9月9日令和７年台風第15号等に伴う災害に係る 災害救助法の適用について](https://www.nuro.jp/news_release/20250909/)
        
    *   [2025年9月1日NURO 光 契約約款改定のお知らせ](https://www.nuro.jp/news_release/20250901/)
        
    *   [2025年8月27日NUROサービス 会員規約本則の改訂について](https://www.nuro.jp/news_release/20250827/)
        
    *   [2025年8月1日令和７年カムチャツカ半島付近の地震に伴う津波にかかる 災害救助法の適用について](https://www.nuro.jp/news_release/20250801/)
        
    *   [2025年6月2日NURO 光 契約解除料 改定のお知らせ](https://www.nuro.jp/news_release/20250602/)
        
    *   [2025年5月19日ユニバーサルサービス料　改定のお知らせ](https://www.nuro.jp/news_release/20250519/)
        
    *   [2025年4月1日NURO 光 でんわ契約約款の改訂について](https://www.nuro.jp/news_release/20250401-2/)
        
    *   [2025年4月1日2025年度の電話リレーサービス料について](https://www.nuro.jp/news_release/20250401/)
        
    *   [2025年3月24日NTTドコモ合算請求 システムメンテナンス実施のお知らせ](https://www.nuro.jp/news_release/20250324/)
        
    *   [2025年3月10日クレジットカード本人認証サービス「3Dセキュア」導入のお知らせ](https://www.nuro.jp/news_release/20250310/)
        
    *   [2025年3月1日NURO光 契約約款の誤記の修正について](https://www.nuro.jp/news_release/20250301/)
        
    *   [2025年2月13日流域下水道管の破損に起因する道路陥没事故にかかる災害救助法の適用について](https://www.nuro.jp/news_release/20250213/)
        
    *   [2025年2月11日令和7年2月4日からの大雪にかかる 災害救助法の適用について](https://www.nuro.jp/news_release/20250211/)
        
    *   [2025年1月27日「NURO 光 でんわ」双方向番号ポータビリティ開始にあたっての移行期間対応](https://www.nuro.jp/news_release/20241211/)
        
    *   [2024年12月11日「NURO 光 でんわ One Type」双方向番号ポータビリティ開始にあたっての移行期間対応](https://www.nuro.jp/news_release/20241211-2/)
        
    *   [2024年12月6日インターネットの悪質な乗り換え勧誘について](https://www.nuro.jp/news_release/20230809/)
        
    *   [2024年10月1日集合住宅向け新プランの提供および「NURO 光 for マンション」新規受付終了について](https://www.nuro.jp/news_release/20241001/)
        
    *   [2024年9月18日「NURO 光 for マンション」価格変更のご案内](https://www.nuro.jp/news_release/20240412/)
        
    *   [2024年8月30日令和6年台風第10号に伴う災害にかかる災害救助法の適用について](https://www.nuro.jp/news_release/20240830/)
        
    *   [2024年7月27日令和6年7月25日からの大雨にかかる災害救助法の適用について](https://www.nuro.jp/news_release/20240727/)
        
    *   [2024年6月11日So-netメールリニューアルについて](https://www.nuro.jp/news_release/20231101/)
        
    *   [2024年3月27日2024年度の電話リレーサービス料について](https://www.nuro.jp/news_release/20240327/)
        
    *   [2024年2月14日NUROサービス 会員規約本則の改訂について](https://www.nuro.jp/news_release/20240214/)
        
    *   [2024年1月26日令和6年1月23日からの大雪等による災害にかかる災害救助法の適用について](https://www.nuro.jp/news_release/20240126/)
        
    *   [2023年10月10日インボイス制度に関するお知らせ](https://www.nuro.jp/news_release/20231010/)
        
    *   [2023年9月12日令和５年台風第13号に伴う災害にかかる災害救助法の適用について](https://www.nuro.jp/news_release/20230912-2/)
        
    *   [2023年9月12日ご利用履歴のないメールアドレスの削除について](https://www.nuro.jp/news_release/20230912/)
        
    *   [2023年9月1日NUROサービス 会員規約本則の改訂について](https://www.nuro.jp/news_release/20230901/)
        
    *   [2023年7月14日令和５年７月７日からの大雨による災害にかかる災害救助法の適用について](https://www.nuro.jp/news_release/20230713/)
        
    *   [2023年6月26日【重要】クレジットカード 国際ブランドVisa決済ルール変更に伴う情報更新についてのご案内](https://www.nuro.jp/news_release/20230616/)
        
    *   [2023年6月23日【重要】クレジットカード「ヤフーカード」から「PayPayカード」に切替となったお客さまへ、クレジットカード情報更新のお願い](https://www.nuro.jp/news_release/20230623/)
        
    *   [2023年6月1日NUROサービス会員規約本則の改訂について](https://www.nuro.jp/news_release/20230601)
        
    *   [2023年4月1日【重要】 携帯料金合算請求 決済事務手数料に関するお知らせ](https://www.nuro.jp/news_release/20230401)
        
    *   [2023年3月27日2023年度の電話リレーサービス料について](https://www.nuro.jp/news_release/20230327)
        
    *   [2023年3月20日NURO 光×ロックマンエグゼ アドバンスドコレクション コラボキャンペーン開始のお知らせ](https://www.nuro.jp/news_release/20230320-2/)
        

* * *

もっと見る

*   [ネットワーク設備の増強](https://www.nuro.jp/quality/network_enhancement/)
    
*   [NURO 光 品質改善について](https://www.nuro.jp/quality/)
    

![NURO光 J.D.パワー 固定インターネット顧客満足度9年連続No1 関東エリア](https://www.nuro.jp/guideline/images/oricon_pc.png?v=58c58d861e)

提供サービス
------

個人のお客さま 法人のお客さま / 集合住宅オーナーさま

*   [![NURO 光 2ギガ/10ギガプラン](https://www.nuro.jp/assets/img/top/hikari.jpg?v=1d3be50fd3)\
    \
    CMでおなじみの人気プラン\
    \
    戸建住宅、集合住宅（マンション/アパート）向け\
    \
    多くの方が加入しているベーシックなプランです。選べるお申し込み特典を多数ご用意しています。\
    \
    詳細を見る](https://www.nuro.jp/hikari/)
    
    *   通信速度に関する注意事項
    
*   [![NURO 光 Wireless 5G](https://www.nuro.jp/assets/img/top/wireless5g.jpg?v=28a1d8dfe4)\
    \
    ホームルーターをコンセントに挿すだけ\
    \
    ローカル5Gを利用したインターネット接続サービスです。ホームルーターをコンセントに挿すだけで高速インターネットをご利用いただけます。\
    \
    詳細を見る](https://wireless.nuro.jp/?SmRcid=gr_snc_nurofltop&_stcid=e6d9618b1bf7b20d08e2559d8cac18a1.2e88250472cd1fa40c2ec52f264a8252)
    
*   [![NURO 光 20ギガプラン](https://www.nuro.jp/assets/img/top/hikari20g.jpg?v=eced1e406b)\
    \
    速度を追求したい方に\
    \
    何よりも速度を追求したい方にオススメのプランです。\
    \
    詳細を見る](https://www.nuro.jp/s_plan/20gs/)
    
    *   通信速度に関する注意事項
    

*   [![NURO Biz](https://www.nuro.jp/assets/img/top/biz.jpg?v=6bd4f0030e)\
    \
    法人向けインターネット接続サービス\
    \
    法人向けインターネット接続サービス「NUROアクセス」を中心に、ネットワーク、セキュリティ、クラウドサービスをワンストップでご提供します。\
    \
    詳細を見る](https://biz.nuro.jp/)
    
*   [![NURO 光 2ギガ/10ギガプラン](https://www.nuro.jp/assets/img/top/hikari.jpg?v=1d3be50fd3)\
    \
    個人事業主/小規模法人の方向けサービス\
    \
    お申し込み特典を多数ご用意しています。\
    \
    詳細を見る](https://www.nuro.jp/hikari/bizguide/)
    
*   [![NURO 光 Connect](https://www.nuro.jp/assets/img/top/connect.jpg?v=787cb40161)\
    \
    集合住宅全戸加入サービス\
    \
    高速通信とリーズナブルな価格が特長の集合住宅専用：住戸一括で導入できるインターネットサービスです。\
    \
    詳細を見る](https://sonyncc.co.jp/cp2/)
    
*   [![MOREVE](https://www.nuro.jp/assets/img/top/moreve.jpg?v=538e9853df)\
    \
    法人向けローカル5Gプラットフォームサービス\
    \
    エンタテインメントシーンに寄り添い、感動体験を実現する法人向けローカル5Gプラットフォームサービスです。\
    \
    詳細を見る](https://wireless.nuro.jp/moreve/)
    

[![世界は変わるのを待っている。感動を止めるな。NURO](https://www.nuro.jp/common/assets/images/banner/banner_mobile_pc.png?v=750c9c39f2)](https://www.nuro.jp/brand/)

 ![閉じる](https://www.nuro.jp/components/assets/img/common/icon_modal_close_btn.svg?v=ab993c440a)![閉じる](https://www.nuro.jp/components/assets/img/common/icon_modal_close_btn_white.svg?v=c0c74468d3)

通信速度に関する注意事項

*   「10Gbps」という通信速度は、ネットワークから宅内終端装置へ提供する技術規格上の最大速度です。
    
*   端末機器1台における技術規格上利用可能な最大通信速度は、有線接続（10GBASE-Tポート利用）時で概ね10Gbps、無線接続時で概ね4.8Gbpsです。
    
*   速度は、お客さまのご利用環境（接続するLANケーブル・HUB等の性能および端末機器の仕様等）や回線混雑状況等により、低下する場合があります。
    

* * *

*   「2Gbps」という通信速度は、ネットワークから宅内終端装置へ提供する技術規格上の下りの最大速度です。
    
*   端末機器1台における技術規格上利用可能な下りの最大通信速度は、有線接続（2.5GBASE-Tポート利用）時で概ね2Gbps、無線接続時で概ね2Gbpsです。
    
*   速度は、お客さまのご利用環境（接続するLANケーブル・HUB等の性能および端末機器の仕様等）や回線混雑状況等により、低下する場合があります。
    

閉じる

 ![閉じる](https://www.nuro.jp/components/assets/img/common/icon_modal_close_btn.svg?v=ab993c440a)![閉じる](https://www.nuro.jp/components/assets/img/common/icon_modal_close_btn_white.svg?v=c0c74468d3)

通信速度に関する注意事項

*   「20Gbps」という通信速度は、ネットワークから宅内終端装置へ提供する技術規格上の最大速度です。お客さまが使用する個々の端末機器までの通信速度を示すものではありません。
    
*   端末機器1台における技術規格上利用可能な最大通信速度は、有線接続(10GBASE-T　1ポート利用)時で概ね10Gbps、無線接続時で概ね4.8Gbps(IEEE802.11axの場合の速度)です。
    
*   速度は、お客さまのご利用環境(接続するLANケーブル・HUB等の性能および端末機器の仕様等)や回線混雑状況等により、低下する場合があります。
    

閉じる

個人向けサービス

[NURO 光 2ギガ/10ギガプラン](https://www.nuro.jp/hikari/)

[NURO 光 20ギガプラン](https://www.nuro.jp/s_plan/20gs/)

[NURO Wireless 5G](https://wireless.nuro.jp/)

法人向けサービス

[NURO Biz](https://biz.nuro.jp/)

[NURO 光 Connect](https://sonyncc.co.jp/cp2/)

[MOREVE](https://wireless.nuro.jp/moreve/)

お問い合わせ

[NURO 光 会員サポート](https://www.nuro.jp/support/)

*   [障害・メンテナンス情報](https://www.nuro.jp/emerge/)
    
*   [ご提供する機器について](https://www.nuro.jp/device.html)
    
*   [ウェブサイトご利用条件](https://www.nuro.jp/siteinfo/nuro/)
    

電気通信事業者 登録番号:関第94号、代理店届出番号:第C1903019号

[![NURO](https://www.nuro.jp/hikari/renewal/common/images/footer_logo-nuro.png?v=cb2501f9ba)](https://www.sonynetwork.co.jp/corporation/nuro_rebrand2021/)

© Sony Network Communications Inc.

![](https://event-va1.pubmatic.com/?adv=26162&cb=1764896659483&ref=https%3A%2F%2Fwww.nuro.jp%2F&page=https%3A%2F%2Fwww.nuro.jp%2F&order_id={{order_id}}&item_count={{item_count}}&value={{value}}&gdpr_consent=${GDPR_CONSENT_76}&gdpr=${GDPR}&us_privacy=${US_PRIVACY})        

![](https://bat.bing.com/action/0?ti=97114800&Ver=2&mid=afcf2ce8-dba3-4013-81ce-29e44ae25982&bo=1&sid=54635950d17611f083e493f870a3716a&vid=5465d620d17611f0a4056da19cda965a&vids=1&msclkid=N&uach=pv%3D10.0&pi=0&lg=en-US@posix&sw=1280&sh=800&sc=24&nwd=1&tl=%E3%80%90%E5%85%AC%E5%BC%8F%E3%80%91NURO%20%E5%85%89%20%E9%AB%98%E9%80%9F%20%E5%85%89%E5%9B%9E%E7%B7%9A%E3%82%A4%E3%83%B3%E3%82%BF%E3%83%BC%E3%83%8D%E3%83%83%E3%83%88&kw=NURO,%E3%83%8C%E3%83%AD,%E3%83%8B%E3%83%A5%E3%83%BC%E3%83%AD,%E9%AB%98%E9%80%9F,%E5%85%89%E3%83%95%E3%82%A1%E3%82%A4%E3%83%90%E3%83%BC,%E3%83%96%E3%83%AD%E3%83%BC%E3%83%89%E3%83%90%E3%83%B3%E3%83%89,%E3%82%A4%E3%83%B3%E3%82%BF%E3%83%BC%E3%83%8D%E3%83%83%E3%83%88%E6%8E%A5%E7%B6%9A,So-net,%E3%82%BD%E3%83%8D%E3%83%83%E3%83%88,SonyNetworkCommunications,%E3%82%BD%E3%83%8B%E3%83%BC%E3%83%8D%E3%83%83%E3%83%88%E3%83%AF%E3%83%BC%E3%82%AF%E3%82%B3%E3%83%9F%E3%83%A5%E3%83%8B%E3%82%B1%E3%83%BC%E3%82%B7%E3%83%A7%E3%83%B3%E3%82%BA&p=https%3A%2F%2Fwww.nuro.jp%2F&r=&evt=pageLoad&sv=2&cdb=AQAQ&rn=485918)

![](https://bat.bing.com/action/0?ti=343062041&Ver=2&mid=ee182e81-c968-4b3f-8c35-ce8d5852a9f8&bo=1&sid=54635950d17611f083e493f870a3716a&vid=5465d620d17611f0a4056da19cda965a&vids=0&msclkid=N&uach=pv%3D10.0&pi=0&lg=en-US@posix&sw=1280&sh=800&sc=24&nwd=1&tl=%E3%80%90%E5%85%AC%E5%BC%8F%E3%80%91NURO%20%E5%85%89%20%E9%AB%98%E9%80%9F%20%E5%85%89%E5%9B%9E%E7%B7%9A%E3%82%A4%E3%83%B3%E3%82%BF%E3%83%BC%E3%83%8D%E3%83%83%E3%83%88&kw=NURO,%E3%83%8C%E3%83%AD,%E3%83%8B%E3%83%A5%E3%83%BC%E3%83%AD,%E9%AB%98%E9%80%9F,%E5%85%89%E3%83%95%E3%82%A1%E3%82%A4%E3%83%90%E3%83%BC,%E3%83%96%E3%83%AD%E3%83%BC%E3%83%89%E3%83%90%E3%83%B3%E3%83%89,%E3%82%A4%E3%83%B3%E3%82%BF%E3%83%BC%E3%83%8D%E3%83%83%E3%83%88%E6%8E%A5%E7%B6%9A,So-net,%E3%82%BD%E3%83%8D%E3%83%83%E3%83%88,SonyNetworkCommunications,%E3%82%BD%E3%83%8B%E3%83%BC%E3%83%8D%E3%83%83%E3%83%88%E3%83%AF%E3%83%BC%E3%82%AF%E3%82%B3%E3%83%9F%E3%83%A5%E3%83%8B%E3%82%B1%E3%83%BC%E3%82%B7%E3%83%A7%E3%83%B3%E3%82%BA&p=https%3A%2F%2Fwww.nuro.jp%2F&r=&evt=pageLoad&sv=2&cdb=AQAQ&rn=454074)

![](https://bat.bing.com/action/0?ti=343048056&Ver=2&mid=a351f119-1cbe-4bdc-918f-83f1ef43511c&bo=1&sid=54635950d17611f083e493f870a3716a&vid=5465d620d17611f0a4056da19cda965a&vids=0&msclkid=N&uach=pv%3D10.0&pi=0&lg=en-US@posix&sw=1280&sh=800&sc=24&nwd=1&tl=%E3%80%90%E5%85%AC%E5%BC%8F%E3%80%91NURO%20%E5%85%89%20%E9%AB%98%E9%80%9F%20%E5%85%89%E5%9B%9E%E7%B7%9A%E3%82%A4%E3%83%B3%E3%82%BF%E3%83%BC%E3%83%8D%E3%83%83%E3%83%88&kw=NURO,%E3%83%8C%E3%83%AD,%E3%83%8B%E3%83%A5%E3%83%BC%E3%83%AD,%E9%AB%98%E9%80%9F,%E5%85%89%E3%83%95%E3%82%A1%E3%82%A4%E3%83%90%E3%83%BC,%E3%83%96%E3%83%AD%E3%83%BC%E3%83%89%E3%83%90%E3%83%B3%E3%83%89,%E3%82%A4%E3%83%B3%E3%82%BF%E3%83%BC%E3%83%8D%E3%83%83%E3%83%88%E6%8E%A5%E7%B6%9A,So-net,%E3%82%BD%E3%83%8D%E3%83%83%E3%83%88,SonyNetworkCommunications,%E3%82%BD%E3%83%8B%E3%83%BC%E3%83%8D%E3%83%83%E3%83%88%E3%83%AF%E3%83%BC%E3%82%AF%E3%82%B3%E3%83%9F%E3%83%A5%E3%83%8B%E3%82%B1%E3%83%BC%E3%82%B7%E3%83%A7%E3%83%B3%E3%82%BA&p=https%3A%2F%2Fwww.nuro.jp%2F&r=&evt=pageLoad&sv=2&cdb=AQAQ&rn=720322)

![](https://ib.adnxs.com/setuid?entity=315&code=MH31GQ29UD3CZqIpaq1dQdIZDJ8vvZsD2QkB7NTKq2w&consent=1)![](https://aw.dw.impact-ad.jp/ut/rep?u=4934&v=1&r=https%3A%2F%2Fwww.nuro.jp%2F&t=993)
