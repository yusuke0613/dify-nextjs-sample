# 【楽天PointClub】：楽天ポイント総合サイト

URL: https://point.rakuten.co.jp/

---

[![Rakuten Mobile](https://cdn.rmc.contents.rakuten.co.jp/block/d40535ac09aac0ef32f8a23b8bb8e04bc2e8f9d6b0981fa98a16d0382f558d83/d72cbeb1-1b70-4fb2-b7e5-cb3c0a24841f/card20k_enddate_pc_1440x50.png)](https://cdn.rex.contents.rakuten.co.jp/webcx-redirect-module/1.3.0/index.html?clientId=d40535ac09aac0ef32f8a23b8bb8e04bc2e8f9d6b0981fa98a16d0382f558d83&version=2.73.0&sessionId=bcdb8160-b1c2-4776-b554-6e3a7f769a54&screen=WB&issueId=F01184-001256&campaignId=2aadf4f2-55c7-4337-8472-22f617277367&contentId=4382487a-283f-4306-b0d1-11d8c70206b1&replacementId=9354c015-1ef6-41d2-8298-0bf372a98402&impressionId=dd726933-713b-472e-b67e-26363155ae5a&selector=mkdiv_header_pitari&redirect=aHR0cHM6Ly9yZC5yYWt1dGVuLmNvLmpwL3JhdD9SMj1odHRwczovL25ldHdvcmsubW9iaWxlLnJha3V0ZW4uY28uanAvY2FtcGFpZ24vY2FyZC1tb2JpbGUtbWFqaXRva3UvJTNGc2NpZCUzRHdpX3BjbF9ybWJfbWtkaXZfaGVhZGVyX3BpdGFyaV9jbW9fc3BfbmV3LWNhcmQtbm8td2ViY3hfY2FyZC1tb2JpbGUtbWFqaXRva3VfMjAyNTEyMDEmYWNjPTEzMTImYWlkPTEmZXR5cGU9Y2xpY2smc3NjPWNyb3NzdXNlX2NhbXBhaWduJnBnbj1jbW9fcGl0YXJpJnJlZj1odHRwczovL3BvaW50LnJha3V0ZW4uY28uanAvJnRhcmdldF9lbGU9bmV3LWNhcmQtbm8td2ViY3hfY2FyZC1tb2JpbGUtbWFqaXRva3VfMjAyNTEyMDE=&origin=aHR0cHM6Ly9wb2ludC5yYWt1dGVuLmNvLmpw)

**

*   [![RakutenPointClub](https://point.rakuten.co.jp/img/common/logo-sp.svg)](https://point.rakuten.co.jp/?l-id=point_header_logo_sp)
    



**

*   [メニュー](https://point.rakuten.co.jp/#)
    
*   [閉じる](https://point.rakuten.co.jp/#)
    

*   [楽天PointClubトップ](https://point.rakuten.co.jp/?l-id=point_header_top_sp)
    
*   [ポイント実績](https://point.rakuten.co.jp/history/?l-id=point_header_history_sp)
    
*   [ランク優待](https://point.rakuten.co.jp/club/rank/reward/?l-id=point_header_rank_sp)
    

*   楽天ポイントを貯めたい
*   [スタート1000](https://event.rakuten.co.jp/group/sbc/?scid=wi_grp_gmx_sbcex_ptc_header_sp)
    
*   [楽天ポイントが貯まるサービス](https://point.rakuten.co.jp/get/?l-id=point_header_get_sp)
    
*   [楽天グループのキャンペーン](https://point.rakuten.co.jp/campaign/?l-id=point_header_campaign_sp)
    
*   [キャンペーンエントリー履歴](https://oubo.rakuten.co.jp/list?spk=313e23&scid=wi_grp_gmx_oubo_pcb_header_sp)
    
*   [他社ポイントからの交換](https://point.rakuten.co.jp/exchange/?l-id=point_header_exchange_sp)
    

*   楽天ポイントを増やしたい
*   [ポイント利息](https://point.rakuten.co.jp/interest/redirect/?l-id=point_header_interest_sp)
    
*   [ポイント運用](https://point.rakuten.co.jp/invest/?l-id=point_header_invest_sp)
    
*   [ポイントビットコイン](https://point.rakuten.co.jp/club/app/bitcoin/redirect/?l-id=point_header_bitcoin_sp)
    
*   [ポイント楽天株](https://point.rakuten.co.jp/rstock/?l-id=point_header_rstock_sp)
    
*   [ポイント定期](https://point.rakuten.co.jp/fixed_term/redirect/?l-id=point_header_fixedterm_sp)
    

*   楽天ポイントを使いたい
*   [楽天ポイントが使えるサービス](https://point.rakuten.co.jp/use/?l-id=point_header_use_sp)
    
*   [楽天Edyにチャージ](https://edy.rakuten.co.jp/howto/pointcharge/?scid=wi_grp_gmx_edy_ptc_header_sp)
    

*   ご案内
*   [楽天ポイントお楽しみ図鑑](https://event.rakuten.co.jp/group/point/pointzukan/?scid=wi_grp_gmx_pointzukan_ptc_header_sp)
    
*   [楽天ポイントガイド](https://point.rakuten.co.jp/guidance/?l-id=point_header_guidance_sp)
    
*   [楽天PointClubアプリのご紹介](https://point.rakuten.co.jp/doc/app/download/?l-id=point_header_download_sp)
    

*   関連サービス
*   [楽天ポイントカード](https://pointcard.rakuten.co.jp/?scid=wi_grp_gmx_rpc_ptc_header_sp)
    
*   [楽天ギフトカード](https://giftcard.cash.rakuten.co.jp/?l-id=point_header_gift_sp)
    
*   [楽天キャッシュ](https://cash.rakuten.co.jp/Top/TopDisplayCash/?randNum=2128400526&scid=wi_grp_gmx_topdisplaycash_ptc_header_sp)
    
*   [myクーポン](https://coupon.rakuten.co.jp/myCoupon?scid=wi_grp_gmx_mycoupon_ptc_header_sp)
    
*   [楽天グループのサービス](https://www.rakuten.co.jp/sitemap/?scid=wi_grp_gmx_sitemap_ptc_header_sp)
    

*   法人向けサービス
*   [楽天ポイントギフト（法人向け）](https://point.rakuten.co.jp/giftcard/?scid=wi_adw_pointgift_ptc_gnavi)
    

*   その他
*   [会員情報の確認・変更](https://my.rakuten.co.jp/?scid=wi_grp_gmx_myr_ptc_header_sp)
    
*   [ログアウト](https://point.rakuten.co.jp/common/logout/?scid=wi_grp_gmx_ich_ptc_header_sp)
    

ポイント実績、楽天キャッシュ、口座番号の  
確認にはログインが必要になります

[ログイン](https://point.rakuten.co.jp/common/login/?return_url=/)

初めての方はこちら

[楽天会員登録(無料)](https://point.rakuten.co.jp/signup/)

![楽天PointClubアプリ](https://point.rakuten.co.jp/_assets/img/sp/common/mobile_mock.png)

PointClubアプリ

ポイント確認のついでに  
ポイントも貯まる。  
アプリでもっとお得♪

[詳しく見る>>](http://point.rakuten.co.jp/doc/app/manga/sp/)

[![App Storeからダウンロード](https://point.rakuten.co.jp/doc/app/manga/sp/img/index-btn-appstore.png)](https://itunes.apple.com/app/apple-store/id641501350?pt=242067&ct=btn_Login&mt=8)

[![Google Playで手に入れよう](https://point.rakuten.co.jp/doc/app/manga/sp/img/index-btn-googleplay.png)](https://play.google.com/store/apps/details?id=jp.co.rakuten.pointclub.android&referrer=utm_source%3Dbtn_Login%26utm_medium%3Dbanner)

[![Google Playで手に入れよう](https://point.rakuten.co.jp/doc/app/manga/sp/img/index-btn-googleplay.png)](https://play.google.com/store/apps/details?id=jp.co.rakuten.pointclub.android&referrer=utm_source%3Dbtn_Login%26utm_medium%3Dbanner)

[![](https://point.rakuten.co.jp/img/crossuse/footer-banner/bnr-orange.png)](https://itunes.apple.com/app/apple-store/id641501350?pt=242067&ct=ft_sp02&mt=8)

*   アプリのご案内
    
    *   [楽天PointClubアプリのご紹介](https://point.rakuten.co.jp/doc/app/manga/sp/?l-id=point_nav_app_sp)
        
    
*   ポイントに関するご案内
    
    *   [楽天ポイントガイド](https://point.rakuten.co.jp/guidance/?l-id=point_nav_guidance_sp)
        
    *   [ポイント利用方法](https://point.rakuten.co.jp/guidance/usemethod/?l-id=point_nav_usemethod_sp)
        
    *   [ポイント実績確認方法](https://point.rakuten.co.jp/guidance/historycheck/?l-id=point_nav_historycheck_sp)
        
    *   [ポイント進呈ルール](https://point.rakuten.co.jp/guidance/rule/?l-id=point_nav_rule_sp)
        
    *   [期間限定ポイントとは](https://point.rakuten.co.jp/guidance/terms/?l-id=point_nav_term_sp)
        
    *   [楽天ポイントに換える](https://point.rakuten.co.jp/guidance/info/?l-id=point_nav_info_sp)
        
    *   [ポイント利息について](https://point.rakuten.co.jp/interest/redirect/?l-id=point_nav_interest_sp)
        
    *   [ポイント運用について](https://point.rakuten.co.jp/invest/?l-id=point_nav_invest_sp)
        
    *   [ポイントビットコインについて](https://point.rakuten.co.jp/club/app/bitcoin/redirect/?l-id=point_nav_bitcoin_sp)
        
    *   [ポイント楽天株について](https://point.rakuten.co.jp/rstock/?l-id=point_nav_rstock_sp)
        
    *   [ポイント定期について](https://point.rakuten.co.jp/fixed_term/redirect/?l-id=point_nav_fixedterm_sp)
        
    
*   会員ランクに関するご案内
    
    *   [ランク特典とは](https://point.rakuten.co.jp/guidance/rank/?l-id=point_nav_rank_sp)
        
    *   [ランクアップ・キープの仕組み](https://point.rakuten.co.jp/guidance/rankkeep/?l-id=point_nav_rankkeep_sp)
        
    *   [ランクアップ条件の見方とは](https://point.rakuten.co.jp/guidance/rankcondition/?l-id=point_nav_rankcondition_sp)
        
    *   [ランク会員専用ページへのご案内](https://point.rakuten.co.jp/club/rank/reward/?scid=wi_grp_gmx_rank_access_sp)
        
    
*   キャンペーンに関するご案内
    
    *   [ポイント倍率の仕組み](https://ichiba.faq.rakuten.net/detail/000011407)
        
    
*   楽天ポイントギフト
    
    *   [楽天ポイントの受け取り](https://giftcard.cash.rakuten.co.jp/?l-id=point_nav_pointgift_sp)
        
    
*   よくある質問・お問い合わせ
    
    *   [お問い合わせ](https://chat.ichiba.faq.rakuten.co.jp/)
        
    *   [Q&A](https://ichiba-smp.faq.rakuten.net/)
        
    *   [規約](https://corp.rakuten.co.jp/terms/?tab=point&scid=wi_grp_gmx_corp_pcb_nav_faq_sp)
        
    

*   [企業情報](https://corp.rakuten.co.jp/)
    
*   [個人情報保護方針](https://privacy.rakuten.co.jp/)
    
*   [社会的責任\[CSR\]](https://corp.rakuten.co.jp/csr/)
    
*   [採用情報](https://corp.rakuten.co.jp/careers/)
    

[![Go Green Together 本サービスは再生可能エネルギー100%](https://point.rakuten.co.jp/_assets/img/common/go_green_together.svg)](https://corp.rakuten.co.jp/event/climateaction/#slide_1?scid=wi_crp_gogreen_footer)

© Rakuten Group, Inc.

楽天グループ
------

*   [アプリ一覧](https://www.rakuten.co.jp/sitemap/sp/app.html)
    
*   [お問い合わせ一覧](https://www.rakuten.co.jp/sitemap/inquiry.html)
    

  

            ![](https://pzd.rakuten.co.jp/?menu=RgCookie)
