# 【公式】クレジットカードなら、楽天カード

URL: https://www.rakuten-card.co.jp/

---

![](https://rat.rakuten.co.jp/?cpkg_none=%7B%22acc%22%3A486%2C%22aid%22%3A1%2C%22bid%22%3A%22176489666703091fd4a6b%22%2C%22url%22%3A%22https%3A%2F%2Fwww.rakuten-card.co.jp%2F%22%2C%22ua%22%3A%22Mozilla%2F5.0%20(iPhone%3B%20CPU%20iPhone%20OS%2018_6_2%20like%20Mac%20OS%20X)%20AppleWebKit%2F605.1.15%20(KHTML%2C%20like%20Gecko)%20Version%2F18.6%20Mobile%2F15E148%20Safari%2F604.1%22%2C%22etype%22%3A%22async%22%2C%22phoenix_pattern%22%3A%22www.rakuten-card.co.jp%7C%2F%7Crc-gp-sp_banner_scv_sp%7Cdefault%22%2C%22cp%22%3A%7B%22phxcampaign%22%3A%22rc-gp-sp_banner_scv_sp%22%2C%22phxexperiment%22%3A14887%2C%22phxpattern%22%3A%22default%22%2C%22phxbanditpattern%22%3A%22default%22%2C%22phxversion%22%3A%222.8.1%22%2C%22phxcmpruntime%22%3A0.001%2C%22phxapiresptime%22%3A0%2C%22phxpatternloadtime%22%3A0%7D%7D)    

[![Rakuten Mobile](https://cdn.rmc.contents.rakuten.co.jp/block/d40535ac09aac0ef32f8a23b8bb8e04bc2e8f9d6b0981fa98a16d0382f558d83/d72cbeb1-1b70-4fb2-b7e5-cb3c0a24841f/card20k_enddate_pc_1440x50.png)](https://cdn.rex.contents.rakuten.co.jp/webcx-redirect-module/1.3.0/index.html?clientId=d40535ac09aac0ef32f8a23b8bb8e04bc2e8f9d6b0981fa98a16d0382f558d83&version=2.73.0&sessionId=cecb8485-569c-4a2c-aebb-6d29af1f17e7&screen=WB&issueId=F01184-001256&campaignId=2aadf4f2-55c7-4337-8472-22f617277367&contentId=4382487a-283f-4306-b0d1-11d8c70206b1&replacementId=9354c015-1ef6-41d2-8298-0bf372a98402&impressionId=f7572b81-dda6-4368-aa3e-5b9b187e7164&selector=mkdiv_header_pitari&redirect=aHR0cHM6Ly9yZC5yYWt1dGVuLmNvLmpwL3JhdD9SMj1odHRwczovL25ldHdvcmsubW9iaWxlLnJha3V0ZW4uY28uanAvY2FtcGFpZ24vY2FyZC1tb2JpbGUtbWFqaXRva3UvJTNGc2NpZCUzRHdpX3JrY19ybWJfbWtkaXZfaGVhZGVyX3BpdGFyaV9jbW9fc3BfbmV3LWNhcmQtbm8td2ViY3hfY2FyZC1tb2JpbGUtbWFqaXRva3VfMjAyNTEyMDEmYWNjPTEzMTImYWlkPTEmZXR5cGU9Y2xpY2smc3NjPWNyb3NzdXNlX2NhbXBhaWduJnBnbj1jbW9fcGl0YXJpJnJlZj1odHRwczovL3d3dy5yYWt1dGVuLWNhcmQuY28uanAvJnRhcmdldF9lbGU9bmV3LWNhcmQtbm8td2ViY3hfY2FyZC1tb2JpbGUtbWFqaXRva3VfMjAyNTEyMDE=&origin=aHR0cHM6Ly93d3cucmFrdXRlbi1jYXJkLmNvLmpw)

メニュー

[![楽天カード](https://image.card.jp.rakuten-static.com/card_corp/common/logo/logo_vertical-2.0.0.svg)](https://www.rakuten-card.co.jp/)

====================================================================================================================================

*   検索
    
    サイト内を検索
    
    ※楽天カードに関係するキーワードをご入力ください。
    
    よく検索されるキーワード
    
    [家族カード](https://www.rakuten-card.co.jp/sitesearch/?q=%E5%AE%B6%E6%97%8F%E3%82%AB%E3%83%BC%E3%83%89&l-id=corp_oo_corp_sitesearch-button_to_result-family_sp)
    [ETC](https://www.rakuten-card.co.jp/sitesearch/?q=ETC&l-id=corp_oo_corp_sitesearch-button_to_result-etc_sp)
    [口座変更](https://www.rakuten-card.co.jp/sitesearch/?q=%E5%8F%A3%E5%BA%A7%E5%A4%89%E6%9B%B4&l-id=corp_oo_corp_sitesearch-button_to_result-bank-account_sp)
    [利用明細](https://www.rakuten-card.co.jp/sitesearch/?q=%E5%88%A9%E7%94%A8%E6%98%8E%E7%B4%B0&l-id=corp_oo_corp_sitesearch-button_to_result-bill_sp)
    [ログイン](https://www.rakuten-card.co.jp/sitesearch/?q=%E3%83%AD%E3%82%B0%E3%82%A4%E3%83%B3&l-id=corp_oo_corp_sitesearch-button_to_result-login-support_sp)
    [2枚目のカード](https://www.rakuten-card.co.jp/sitesearch/?q=2%E6%9E%9A%E7%9B%AE%E3%81%AE%E3%82%AB%E3%83%BC%E3%83%89&l-id=corp_oo_corp_sitesearch-button_to_result-add-card_sp)
    
*   [ログイン](https://www.rakuten-card.co.jp/e-navi/sd/index.xhtml?l-id=corp_oo_login_to_enavi)
    

メニュー

閉じる

*   [楽天カードトップ](https://www.rakuten-card.co.jp/?l-id=corp_oo_gnav_top_sp)
    
*   カードをつくる
    
    *   [すべてのカードから選ぶ](https://www.rakuten-card.co.jp/card/?l-id=corp_oo_gnav_product_sp)
        
    *   [デザインから選ぶ](https://www.rakuten-card.co.jp/design-card/?l-id=corp_oo_gnav_to_design_sp)
        
    *   [付帯サービスから選ぶ](https://www.rakuten-card.co.jp/product-service?l-id=corp_rc_gnav_to_product-service_sp)
        
    
    *   [学生向けページを見る](https://www.rakuten-card.co.jp/campaign/rakuten_card/student/?l-id=corp_oo_gnav_to_genz_sp)
        
    *   [2枚目のカードをつくる](https://www.rakuten-card.co.jp/add-card/?l-id=corp_oo_from_gnav_to_add-card_sp)
        
    *   [家族カードをつくる](https://www.rakuten-card.co.jp/service/family-card/?l-id=corp_oo_from_gnav_to_family-card_sp)
        
    *   [カード発行状況](https://r10.to/hMzRZh)
        
    
*   [キャンペーン](https://www.rakuten-card.co.jp/campaign/?l-id=corp_oo_gnav_campaign_sp)
    
*   楽天カードが選ばれる理由
    
    *   [ポイント](https://www.rakuten-card.co.jp/point/?l-id=corp_oo_from_gnav_to_point_sp)
        
    *   [セキュリティ](https://www.rakuten-card.co.jp/security/?l-id=corp_oo_from_gnav_to_security_sp)
        
    *   [海外・トラベル](https://www.rakuten-card.co.jp/overseas/?l-id=corp_oo_from_gnav_to_overseas_sp)
        
    *   [お客様満足への取り組み](https://www.rakuten-card.co.jp/support/customer/?l-id=corp_oo_from_gnav_to_customer_sp)
        
    
*   機能・サービス
    
    *   [お支払い関連・キャッシング](https://www.rakuten-card.co.jp/adjustment/?l-id=corp_oo_from_gnav_to_adjustment_sp)
        
    *   [キャッシュレスサービス](https://www.rakuten-card.co.jp/cashless/?l-id=corp_oo_from_gnav_to_cashless_sp)
        
    *   [役立つサービス](https://www.rakuten-card.co.jp/service/?l-id=corp_oo_from_gnav_to_service_sp)
        
    *   [楽天カード会員様特典](https://www.rakuten-card.co.jp/fintech/?l-id=corp_oo_from_gnav_to_fintech_sp)
        
    *   [携帯・公共料金などのお支払い](https://www.rakuten-card.co.jp/utility/?l-id=corp_oo_from_gnav_to_utility_sp)
        
    
*   [お客様サポート](https://www.rakuten-card.co.jp/support/?l-id=corp_oo_gnav_support_sp)
    

関連サービス

*   [法人・加盟店の方](https://www.rakuten-card.co.jp/merchant/?l-id=corp_oo_gnav_merchant_sp)
    
*   楽天グループサービス
    
    *   [楽天銀行](https://www.rakuten-bank.co.jp/?scid=wi_rkc_corporate_sp_header)
        
    *   [楽天ペイ](https://pay.rakuten.co.jp/detail/?scid=wi_rkc_sp_header_rglink)
        
    *   [楽天ポイントカード](https://pointcard.rakuten.co.jp/?scid=wi_rkc_oneapp_sp_header)
        
    *   [楽天Edy](https://edy.rakuten.co.jp/?scid=wi_rkc_fin_edy_sp_header)
        
    *   [楽天保険の総合窓口](https://www.rakuten-insurance.co.jp/?scid=wi_rkc_fintech_card_sp_header)
        
    *   [サービス一覧](https://r10.to/hsXhgb)
        
    

アプリ

*   [![](https://image.card.jp.rakuten-static.com/card_corp/common/icon/icon_appli.svg)楽天カードアプリ](https://applink.rakuten-card.co.jp/corp_menu)
    
*   [![](https://image.card.jp.rakuten-static.com/card_corp/common/icon/icon_appli_lite.svg)Rakuten Card Lite  \
    楽天カードの英語対応アプリ](https://www.rakuten-card.co.jp/service/app/rakutencardlite/?l-id=corp_oo_gnav_to_lapp_sp)
    

SNS

*   [![](https://image.card.jp.rakuten-static.com/card_corp/common/icon/icon_instagram.svg)Instagram](https://r10.to/hNTpWe)
    
*   [![](https://image.card.jp.rakuten-static.com/card_corp/lay2.0/assets/logo/sns/sns_x_white_circle.svg)X](https://r10.to/hNmegk)
    

その他

*   [企業情報](https://www.rakuten-card.co.jp/corporate/?l-id=corp_de_sp_footer_0003)
    
*   [採用情報](https://www.rakuten-card.co.jp/corporate/career/?l-id=corp_oo_spmenu_to_career_sp)
    

[![12月23日10時までのラストチャンス！新規入会&3回利用で10,000ポイントもらえる！楽天カードドラゴンボールDAIMAデザイン　詳細はこちらv](https://cdn-eu.dynamicyield.com/api/9881514/images/00232c9281fd.png)](https://r10.to/h5XvrS)

あなたらしい

1枚を見つけよう

![楽天カード、楽天カードアプリ](https://image.card.jp.rakuten-static.com/card_corp/smart/top/rakuten-card_v3.png) [![14色から選べる](https://image.card.jp.rakuten-static.com/card_corp/pc/top/mycolor_anchor.png)](https://www.rakuten-card.co.jp/#mycolor)

年会費永年無料！ 新規入会＆3回 利用で 5,000 ポイント！
================================

ポイント（期間限定含む）の進呈には条件がございます。  
必ずご確認ください。 [条件を確認する](https://www.rakuten-card.co.jp/campaign/rakuten_card/corp/?l-id=corp_rc_new_fv_to_cpn_rule_card_sp#rule_detail)
  
※要「楽天e-NAVI」登録・要口座振替設定

お申し込みはこちらから

[楽天会員の方\
\
（ログインをしてお申し込み）](https://r10.to/n-CRP043R0)
[楽天会員でない方\
\
（楽天会員登録をしてお申し込み）](https://r10.to/n-CRP043H0)

![](https://image.card.jp.rakuten-static.com/r-enavi/WebImages/enavi/login/rexicon-32-sign-info-l.svg)

不審メールに伴うお知らせ【2025/12/01】

楽天カードや国際ブランド（Visa、Mastercard、JCB、Amex）をかたり、リンクをクリックさせようとする不審メールが確認されています。  
不審メールの確認事項をご確認いただき、くれぐれもご注意ください。

[不審メールの確認事項はこちら](https://www.rakuten-card.co.jp/security/security-info/phishingmail/)

[お得な  \
入会特典\
\
![ポイントコイン](https://image.card.jp.rakuten-static.com/card_corp/smart/top/coin.png?20231220)\
\
![](https://image.card.jp.rakuten-static.com/card_corp/smart/top/anchor-icon_gray.svg)](https://www.rakuten-card.co.jp/#rakuten-card_campaign)
[カードの  \
ラインナップ\
\
![楽天カードのイラスト](https://image.card.jp.rakuten-static.com/card_corp/smart/top/lineup.svg)\
\
![](https://image.card.jp.rakuten-static.com/card_corp/smart/top/anchor-icon_gray.svg)](https://www.rakuten-card.co.jp/#rakuten-card_lineup)
[楽天カードが  \
選ばれる理由\
\
![楽天カードマンのイラスト](https://image.card.jp.rakuten-static.com/card_corp/smart/top/cardman.png)\
\
![](https://image.card.jp.rakuten-static.com/card_corp/smart/top/anchor-icon_gray.svg)](https://www.rakuten-card.co.jp/#rakuten-card_merit)

 [![ポイントコイン](https://image.card.jp.rakuten-static.com/card_corp/smart/top/coin.png?20231220) お得な  \
入会特典](https://www.rakuten-card.co.jp/#rakuten-card_campaign)
[![楽天カードのイラスト](https://image.card.jp.rakuten-static.com/card_corp/smart/top/card.svg) ライン  \
ナップ](https://www.rakuten-card.co.jp/#rakuten-card_lineup)
[![楽天カードマンのイラスト](https://image.card.jp.rakuten-static.com/card_corp/smart/top/cardman_pink.png) 選ばれる  \
理由](https://www.rakuten-card.co.jp/#rakuten-card_merit)

Special

お得な入会特典
-------

![](https://image.card.jp.rakuten-static.com/card_corp/smart/top/title-decoration.png?20231220)

[![楽天マジ得フェスティバル開催中！](https://image.card.jp.rakuten-static.com/card_corp/smart/top/251121_majitokuhub_588x380.png)](https://www.rakuten-card.co.jp/campaign/jack/index.html?l-id=corp_mk_corptop_new_to_majitokuhub)
[![楽天カード新規入会&3回利用+楽天ペイはじめてのお支払いで最大6,000ポイント](https://image.card.jp.rakuten-static.com/card_corp/smart/top/251201_pay_588x380.png)](https://www.rakuten-card.co.jp/campaign/rakuten_card/instant/payment/pay/bonus/?referrer=n-RSKa30R0&scid=wi_rkc_rc_corp_top_paybonus_sp)
[![楽天カード新規入会＆3回利用で5,000ポイント](https://image.card.jp.rakuten-static.com/card_corp/smart/top/251201_shiro_588x380.png)](https://www.rakuten-card.co.jp/campaign/rakuten_card/corp/?l-id=corp_rc_new_cpnbr_cpn_card_sp)
[![楽天プレミアムカード新規入会＆3回利用で5,000ポイント](https://image.card.jp.rakuten-static.com/card_corp/smart/top/251201_pre_new_default_588x380.png)](https://www.rakuten-card.co.jp/campaign/premium_card/?l-id=corp_oo_new_cpnbr_pre_pc)
[![楽天ゴールドカード新規入会＆3回利用で5,000ポイント](https://image.card.jp.rakuten-static.com/card_corp/smart/top/251201_gold_new_default_588x380.png)](https://www.rakuten-card.co.jp/campaign/gold_card/?l-id=corp_rc_corp_oo_new_cpnbr_gold_pc)
[![楽天カード アカデミー新規入会＆3回利用で5,000ポイント！](https://image.card.jp.rakuten-static.com/card_corp/smart/top/251201_academy_5000_588x380.png)](https://www.rakuten-card.co.jp/card/rakuten-card-academy/?l-id=corp_rc_new_cpnbr_ac_sp)
[![楽天カード紹介で紹介した方とされた方に合計7,000ポイント！※条件あり](https://image.card.jp.rakuten-static.com/card_corp/smart/top/251201_corp_shokai_7000_588x380.png)](https://www.rakuten-card.co.jp/campaign/rakuten_card/susumail/?l-id=corp_rc_corp_to_susumail_card)
[![楽天カード ドラゴンボールデザイン新規入会＆3回利用で10,000ポイント](https://image.card.jp.rakuten-static.com/card_corp/smart/top/251201_db_588x380.png)](https://r10.to/hPF05u)
[![【楽天モバイルx楽天カード】楽天ゴールドカード作成で初年度年会費無料！](https://image.card.jp.rakuten-static.com/card_corp/smart/top/251027_corp_annualfeefree_588x380.png)](https://www.rakuten-card.co.jp/campaign/goldcard/annualfeefree/?l-id=corp_rc_annualfree_corp_top_banner_sp)
[![楽天マジ得フェスティバル開催中！](https://image.card.jp.rakuten-static.com/card_corp/smart/top/251121_majitokuhub_588x380.png)](https://www.rakuten-card.co.jp/campaign/jack/index.html?l-id=corp_mk_corptop_new_to_majitokuhub)
[![楽天カード新規入会&3回利用+楽天ペイはじめてのお支払いで最大6,000ポイント](https://image.card.jp.rakuten-static.com/card_corp/smart/top/251201_pay_588x380.png)](https://www.rakuten-card.co.jp/campaign/rakuten_card/instant/payment/pay/bonus/?referrer=n-RSKa30R0&scid=wi_rkc_rc_corp_top_paybonus_sp)
[![楽天カード新規入会＆3回利用で5,000ポイント](https://image.card.jp.rakuten-static.com/card_corp/smart/top/251201_shiro_588x380.png)](https://www.rakuten-card.co.jp/campaign/rakuten_card/corp/?l-id=corp_rc_new_cpnbr_cpn_card_sp)
[![楽天プレミアムカード新規入会＆3回利用で5,000ポイント](https://image.card.jp.rakuten-static.com/card_corp/smart/top/251201_pre_new_default_588x380.png)](https://www.rakuten-card.co.jp/campaign/premium_card/?l-id=corp_oo_new_cpnbr_pre_pc)
[![楽天ゴールドカード新規入会＆3回利用で5,000ポイント](https://image.card.jp.rakuten-static.com/card_corp/smart/top/251201_gold_new_default_588x380.png)](https://www.rakuten-card.co.jp/campaign/gold_card/?l-id=corp_rc_corp_oo_new_cpnbr_gold_pc)
[![楽天カード アカデミー新規入会＆3回利用で5,000ポイント！](https://image.card.jp.rakuten-static.com/card_corp/smart/top/251201_academy_5000_588x380.png)](https://www.rakuten-card.co.jp/card/rakuten-card-academy/?l-id=corp_rc_new_cpnbr_ac_sp)
[![楽天カード紹介で紹介した方とされた方に合計7,000ポイント！※条件あり](https://image.card.jp.rakuten-static.com/card_corp/smart/top/251201_corp_shokai_7000_588x380.png)](https://www.rakuten-card.co.jp/campaign/rakuten_card/susumail/?l-id=corp_rc_corp_to_susumail_card)
[![楽天カード ドラゴンボールデザイン新規入会＆3回利用で10,000ポイント](https://image.card.jp.rakuten-static.com/card_corp/smart/top/251201_db_588x380.png)](https://r10.to/hPF05u)
[![【楽天モバイルx楽天カード】楽天ゴールドカード作成で初年度年会費無料！](https://image.card.jp.rakuten-static.com/card_corp/smart/top/251027_corp_annualfeefree_588x380.png)](https://www.rakuten-card.co.jp/campaign/goldcard/annualfeefree/?l-id=corp_rc_annualfree_corp_top_banner_sp)
[![楽天マジ得フェスティバル開催中！](https://image.card.jp.rakuten-static.com/card_corp/smart/top/251121_majitokuhub_588x380.png)](https://www.rakuten-card.co.jp/campaign/jack/index.html?l-id=corp_mk_corptop_new_to_majitokuhub)
[![楽天カード新規入会&3回利用+楽天ペイはじめてのお支払いで最大6,000ポイント](https://image.card.jp.rakuten-static.com/card_corp/smart/top/251201_pay_588x380.png)](https://www.rakuten-card.co.jp/campaign/rakuten_card/instant/payment/pay/bonus/?referrer=n-RSKa30R0&scid=wi_rkc_rc_corp_top_paybonus_sp)

*   1
*   2
*   3
*   4
*   5
*   6
*   7
*   8
*   9

[その他のキャンペーンを見る](https://www.rakuten-card.co.jp/campaign/?l-id=corp_rc_new_cpnbr_cpn_list_sp)

 ![考える楽天カードマンのイラスト](https://image.card.jp.rakuten-static.com/card_corp/smart/top/rakuten-cardman_accordion.png) ポイントってどうしたらもらえるの？

![1](https://image.card.jp.rakuten-static.com/card_corp/smart/top/number1.svg) 新規入会特典 2,000ポイント

カード到着後、会員様専用オンラインサービス「楽天e-NAVI」に登録（無料）でポイントゲット！  
※カードは約1週間でお届け

![2](https://image.card.jp.rakuten-static.com/card_corp/smart/top/number2.svg) カード利用特典   3,000 ポイント

街でのお買い物でもネットショッピングでも、楽天カードを3回 以上ご利用してポイントゲット！

[詳細を確認する](https://www.rakuten-card.co.jp/service/2000point/?l-id=corp_rc_new_point_detail_sp)

Lineup

カードラインナップ
---------

![](https://image.card.jp.rakuten-static.com/card_corp/smart/top/title-decoration.png?20231220)

### 楽天カード

一番人気！初めての1枚におすすめ！

![楽天カード](https://image.card.jp.rakuten-static.com/card_corp/smart/top/n_visa_rp_e_front.png) ![年会費永年無料](https://image.card.jp.rakuten-static.com/card_corp/smart/top/silver_annual-fee.svg)

![Visa](https://image.card.jp.rakuten-static.com/card_corp/lay2.0/assets/logo/logo_visa.svg)

![Mastercard](https://image.card.jp.rakuten-static.com/card_corp/lay2.0/assets/logo/logo_master.svg)

![JCB](https://image.card.jp.rakuten-static.com/card_corp/lay2.0/assets/logo/logo_jcb.svg)

![American Express](https://image.card.jp.rakuten-static.com/card_corp/lay2.0/assets/logo/logo_amex_alternate_28-39px.svg)

![タッチ決済](https://image.card.jp.rakuten-static.com/card_corp/common/logo/logo_touch_symbol.svg)

すべての国際ブランドがタッチ決済対応です。

[申し込む](https://www.rakuten-card.co.jp/campaign/rakuten_card/corp/?l-id=corp_rc_new_lineup_silver_to_lp_sp)
 [詳細を見る](https://www.rakuten-card.co.jp/card/rakuten-card/?l-id=corp_rc_new_lineup_silver_to_detail_sp)

楽天カードは14色から選べる！

#### マイカラーセレクション

![楽天カード マイカラーセレクション](https://image.card.jp.rakuten-static.com/card_corp/pc/top/mycolor_cardface.png)

![年会費永年無料](https://image.card.jp.rakuten-static.com/card_corp/smart/top/sp_mycolor-annual-fee.png)

#### カラーラインナップ（全14色）

*   ![マイカラーセレクション レッド](https://image.card.jp.rakuten-static.com/card_corp/common/cardface/cardface_mycolor_red_row_Mastercard_rp_e_front_480x304.png)
    
*   ![マイカラーセレクション オレンジ](https://image.card.jp.rakuten-static.com/card_corp/common/cardface/cardface_mycolor_orange_row_Mastercard_rp_e_front_480x304.png)
    
*   ![マイカラーセレクション イエロー](https://image.card.jp.rakuten-static.com/card_corp/common/cardface/cardface_mycolor_yellow_row_Mastercard_rp_e_front_480x304.png)
    
*   ![マイカラーセレクション ライトグリーン](https://image.card.jp.rakuten-static.com/card_corp/common/cardface/cardface_mycolor_lightgreen_row_Mastercard_rp_e_front_480x304.png)
    
*   ![マイカラーセレクション グリーン](https://image.card.jp.rakuten-static.com/card_corp/common/cardface/cardface_mycolor_green_row_Mastercard_rp_e_front_480x304.png)
    
*   ![マイカラーセレクション ミント](https://image.card.jp.rakuten-static.com/card_corp/common/cardface/cardface_mycolor_mint_row_Mastercard_rp_e_front_480x304.png)
    
*   ![マイカラーセレクション ライトブルー](https://image.card.jp.rakuten-static.com/card_corp/common/cardface/cardface_mycolor_lightblue_row_Mastercard_rp_e_front_480x304.png)
    
*   ![マイカラーセレクション ブルー](https://image.card.jp.rakuten-static.com/card_corp/common/cardface/cardface_mycolor_blue_row_Mastercard_rp_e_front_480x304.png)
    
*   ![マイカラーセレクション パープル](https://image.card.jp.rakuten-static.com/card_corp/common/cardface/cardface_mycolor_purple_row_Mastercard_rp_e_front_480x304.png)
    
*   ![マイカラーセレクション ピンク](https://image.card.jp.rakuten-static.com/card_corp/common/cardface/cardface_mycolor_pink_row_Mastercard_rp_e_front_480x304.png)
    
*   ![マイカラーセレクション コーラル](https://image.card.jp.rakuten-static.com/card_corp/common/cardface/cardface_mycolor_coral_row_Mastercard_rp_e_front_480x304.png)
    
*   ![マイカラーセレクション キャメル](https://image.card.jp.rakuten-static.com/card_corp/common/cardface/cardface_mycolor_camel_row_Mastercard_rp_e_front_480x304.png)
    
*   ![マイカラーセレクション グレー](https://image.card.jp.rakuten-static.com/card_corp/common/cardface/cardface_mycolor_gray_row_Mastercard_rp_e_front_480x304.png)
    
*   ![マイカラーセレクション ブラック](https://image.card.jp.rakuten-static.com/card_corp/common/cardface/cardface_mycolor_black_row_Mastercard_rp_e_front_480x304.png)
    

[申し込む](https://r10.to/n-MCS012R0)

[詳細を見る](https://www.rakuten-card.co.jp/design-card/?referrer=n-002R0&l-id=corp_rc_ondemand_top_design_mcs)

楽天カードのデザイン
----------

[もっと見る](https://www.rakuten-card.co.jp/design-card/?l-id=corp_rc_new_lineup_to_design_list_sp)

*   [＼新登場／\
    \
    ![楽天カード ドラゴンボールZデザイン](https://image.card.jp.rakuten-static.com/card_corp/common/cardface/cardface_dbZ_n_visa_rp_e_front_666_450.png)\
    \
    楽天カード  \
    ドラゴンボールZ  \
    デザイン](https://r10.to/dbz_8)
    
*   [＼新登場／\
    \
    ![楽天カードアルファベットセレクション](https://image.card.jp.rakuten-static.com/card_corp/common/cardface/cardface_panda-alphabet_a_row_Mastercard_rp_e_front_480x304.png)\
    \
    楽天カード  \
    お買いものパンダ  \
    アルファベットセレクション](https://www.rakuten-card.co.jp/card/panda-design-card/?referrer=n-APD012R0&l-id=corp_rc_ondemand_top_design_apdc)
    
*   [＼新登場／\
    \
    ![楽天カード こぎみゅん デザイン](https://image.card.jp.rakuten-static.com/card_corp/common/cardface/cardface_cogimyun_n_visa_rp_e_front_666_447.png)\
    \
    楽天カード  \
    こぎみゅん デザイン](https://r10.to/cogimyun_5)
    
*   [＼新登場／\
    \
    ![楽天カード キキ＆ララ 星降る夜の願い事デザイン](https://image.card.jp.rakuten-static.com/card_corp/common/cardface/cardface_kikilalaStar_n_visa_rp_e_front_666_447.png)\
    \
    楽天カード  \
    キキ＆ララ デザイン](https://r10.to/kikilala_5)
    
*    [![楽天カード ドラゴンボールDAIMAデザイン](https://image.card.jp.rakuten-static.com/card_corp/common/cardface/cardface_DBdaima_n_visa_rp_e_front_666_450.png)\
    \
    楽天カード  \
    ドラゴンボールDAIMAデザイン](https://r10.to/hYJgk1)
    
*    [![楽天カード（ミニーマウス デザイン）](https://image.card.jp.rakuten-static.com/card_corp/common/cardface/cardface_disney_minnie_n_jcb_rp_e_front_234_164.png)\
    \
    楽天カード  \
    ミニーマウスデザイン](https://www.rakuten-card.co.jp/card/disney-design-card/?l-id=corp_rc_new_lineup_design_disney_minnie_sp)
    
*    [![楽天カード（ミッキーマウス デザイン）](https://image.card.jp.rakuten-static.com/card_corp/common/cardface/cardface_disney_n_jcb_rp_e_front_234_164.png)\
    \
    楽天カード  \
    ミッキーマウスデザイン](https://www.rakuten-card.co.jp/card/disney-design-card/?l-id=corp_rc_new_lineup_design_disney_mickey_sp)
    

### 楽天ゴールドカード

手軽に持てるゴールドカード

![楽天ゴールドカード](https://image.card.jp.rakuten-static.com/card_corp/smart/top/g_visa_rp_e_front.png) ![年会費2,200円（税込み）](https://image.card.jp.rakuten-static.com/card_corp/smart/top/gold_annual-fee.svg)

![Visa](https://image.card.jp.rakuten-static.com/card_corp/lay2.0/assets/logo/logo_visa.svg)

![Mastercard](https://image.card.jp.rakuten-static.com/card_corp/lay2.0/assets/logo/logo_master.svg)

![JCB](https://image.card.jp.rakuten-static.com/card_corp/lay2.0/assets/logo/logo_jcb.svg)

![タッチ決済](https://image.card.jp.rakuten-static.com/card_corp/common/logo/logo_touch_symbol.svg)

すべての国際ブランドがタッチ決済対応です。

[申し込む](https://www.rakuten-card.co.jp/campaign/gold_card/?l-id=corp_rc_new_lineup_gold_to_lp_sp)
 [詳細を見る](https://www.rakuten-card.co.jp/card/rakuten-gold-card/?l-id=corp_rc_new_lineup_gold_to_detail_sp)

### 楽天プレミアムカード

充実のサービスでワンランク上の毎日へ

![楽天プレミアムカード](https://image.card.jp.rakuten-static.com/card_corp/smart/top/p_visa_rp_e_front.png) ![年会費11,000円（税込み）](https://image.card.jp.rakuten-static.com/card_corp/smart/top/premium_annual-fee.svg)

![Visa](https://image.card.jp.rakuten-static.com/card_corp/lay2.0/assets/logo/logo_visa.svg)

![Mastercard](https://image.card.jp.rakuten-static.com/card_corp/lay2.0/assets/logo/logo_master.svg)

![JCB](https://image.card.jp.rakuten-static.com/card_corp/lay2.0/assets/logo/logo_jcb.svg)

![American Express](https://image.card.jp.rakuten-static.com/card_corp/lay2.0/assets/logo/logo_amex_alternate_28-39px.svg)

![タッチ決済](https://image.card.jp.rakuten-static.com/card_corp/common/logo/logo_touch_symbol.svg)

すべての国際ブランドがタッチ決済対応です。

[申し込む](https://www.rakuten-card.co.jp/campaign/premium_card/?l-id=corp_rc_new_lineup_pre_to_lp_sp)
 [詳細を見る](https://www.rakuten-card.co.jp/card/rakuten-premium-card/?l-id=corp_rc_new_lineup_pre_to_detail_sp)

![](https://image.card.jp.rakuten-static.com/card_corp/smart/top/dot_divider.png)

迷っている方はCheck！

[カードの特徴から選ぶ](https://www.rakuten-card.co.jp/card/?l-id=corp_rc_new_lineup_to_cardlist_sp#card-list)
 [デザインから選ぶ](https://www.rakuten-card.co.jp/design-card/?l-id=corp_rc_new_lineup_design_hub_sp)
 [カードの付帯サービスを比較する](https://www.rakuten-card.co.jp/#hierarchy_modal)

![楽天カードマンのイラスト](https://image.card.jp.rakuten-static.com/card_corp/smart/top/rakuten-cardman_merit.png)

Reason

楽天カードが  
選ばれる3つの理由
------------------

![](https://image.card.jp.rakuten-static.com/card_corp/smart/top/title-decoration.png?20231220)

Reason1

楽天ポイントが貯まりやすい！

街中のお店で貯める

100円につき１ポイント貯まる！

![100円玉とポイントコイン](https://image.card.jp.rakuten-static.com/card_corp/smart/top/100yen-1point.png?20231220)

※ 一部ポイント還元の対象外となる場合がございます。[条件を確認する](https://www.rakuten-card.co.jp/point/pointrate/?l-id=corp_rc_new_r1_point_detail_sp)

楽天グループサービスで貯める

例えば…

![楽天ペイのロゴ](https://image.card.jp.rakuten-static.com/card_corp/smart/top/logo_rakuten-pay.png)

楽天ペイのチャージ払いで  
最大1.5％還元！※

![チャージ&お支払いで最大1.5％還元！](https://image.card.jp.rakuten-static.com/card_corp/smart/top/rakuten-pay_merit.png?20240603)

[楽天ポイントの貯め方をもっと知る](https://www.rakuten-card.co.jp/point/?l-id=corp_rc_new_r1_point_charge_sp)
  
※一部対象外の店舗や進呈条件等がございます。  
詳細は[こちら](https://pay.rakuten.co.jp/topics/pointprogram)
をご確認ください。

Reason2

楽天ポイントが使いやすい！

街中のお店で使う

1ポイント＝1円相当として  
ご利用いただけます！

![楽天カード加盟店](https://image.card.jp.rakuten-static.com/card_corp/smart/top/V2_merchant_logo.png)

![楽天カード加盟店](https://image.card.jp.rakuten-static.com/card_corp/smart/top/V2_merchant_logo.png)

※ 一部のお店・商品・サービスは楽天ポイントカードご利用対象外となります。

[楽天ポイントが使えるお店を見る](https://pointcard.rakuten.co.jp/partner/?l-id=corp_rc_new_r2_point_partner_sp)

楽天グループサービスで使う

豊富なジャンルの楽天のサービスで  
貯まったポイントを利用できます！

![Rakuten Rakutenブックス RakutenBeauty Rakutenトラベル RakutenTV Rakutenペイ 楽天銀行](https://image.card.jp.rakuten-static.com/card_corp/smart/top/logo_rakuten-group_v2.png?20231220)

使用事例 ①

楽天市場で！  
ポイントで目当ての商品をGet！

使用事例 ②

楽天トラベルで！  
ポイントでホテルをグレードアップ！

使用事例 ③

楽天ペイで！  
ポイントを使ってコンビニでお買い物！

Previous

![楽天トラベルでホテルをグレードアップするイラスト](https://image.card.jp.rakuten-static.com/card_corp/smart/top/merit_rakuten-travel.png)

![楽天ペイでコンビニでお買い物するイラスト](https://image.card.jp.rakuten-static.com/card_corp/smart/top/merit_rakuten-pay.png)

![楽天市場で目当てのスニーカーを購入するイラスト](https://image.card.jp.rakuten-static.com/card_corp/smart/top/merit_rakuten-ichiba.png)

![楽天トラベルでホテルをグレードアップするイラスト](https://image.card.jp.rakuten-static.com/card_corp/smart/top/merit_rakuten-travel.png)

![楽天ペイでコンビニでお買い物するイラスト](https://image.card.jp.rakuten-static.com/card_corp/smart/top/merit_rakuten-pay.png)

![楽天市場で目当てのスニーカーを購入するイラスト](https://image.card.jp.rakuten-static.com/card_corp/smart/top/merit_rakuten-ichiba.png)

![楽天トラベルでホテルをグレードアップするイラスト](https://image.card.jp.rakuten-static.com/card_corp/smart/top/merit_rakuten-travel.png)

![楽天ペイでコンビニでお買い物するイラスト](https://image.card.jp.rakuten-static.com/card_corp/smart/top/merit_rakuten-pay.png)

Next

*   1
*   2
*   3

[楽天ポイントの使い方をもっと知る](https://www.rakuten-card.co.jp/point/?l-id=corp_rc_new_r2_point_guidance_use_sp)

Reason3

楽天カードアプリで  
明細確認も、支出管理もラクラク！

![楽天カードアプリの明細と家計簿のイメージ](https://image.card.jp.rakuten-static.com/card_corp/smart/top/app-images.png)

[楽天カードアプリについて知る](https://www.rakuten-card.co.jp/service/app/?l-id=corp_rc_new_r3_card_app_sp)

[楽天カードを申し込む](https://www.rakuten-card.co.jp/campaign/rakuten_card/corp/?l-id=corp_rc_new_apply_bottom_to_lp_sp)

[![30日以内にカードお申し込み情報を一時保存された方](https://image.card.jp.rakuten-static.com/card_corp/smart/contents/icon/infosave.svg)\
\
30日以内にカードお申し込み情報を一時保存された方](https://apply.card.rakuten.co.jp/?tc=rc&l-id=corp_rc_top_to_save_sp)

* * *

[![カード申し込み・発行状況の確認](https://image.card.jp.rakuten-static.com/card_corp/smart/contents/icon/question01.svg)\
\
カード申し込み・発行状況の確認](https://r10.to/hu4SVN)

* * *

[![お申し込みから新規入会特典進呈までの流れ](https://image.card.jp.rakuten-static.com/card_corp/smart/contents/icon/applying.svg)\
\
お申し込みから新規入会特典進呈までの流れ](https://www.rakuten-card.co.jp/support/guide/apply-flow/?l-id=corp_rc_top_to_aplication_faq_sp)

Previous

[![楽天ブラックカード、楽天プレミアムカードお持ちの方へ 楽天モバイルで使えるギガ割引クーポンを毎月最大10GB進呈！](https://image.card.jp.rakuten-static.com/card_corp/lay2.0/top/250620_premiumprogram--hoyu_SP.png)](https://www.rakuten-card.co.jp/premiumprogram/rakuten-mobile/?l-id=corp_oo_premiumprogram_gigawari_corpcarousel_sp)

[詳細はこちら](https://www.rakuten-card.co.jp/premiumprogram/rakuten-mobile/?l-id=corp_oo_premiumprogram_gigawari_corpcarousel_sp)

※進呈条件あり。本ギガ割引クーポン適用により月のデータ利用量が0GBになる場合でも、プラン料金が最大980円（税込1,078円）請求されます。

[![【超還元祭FINAL】スタンプを貯めてもれなくポイントゲット！ワクワクゥ~っスタンプカード！さらに1万名様に1万ポイントのチャンス！？](https://image.card.jp.rakuten-static.com/card_corp/lay2.0/top/251201_20th_anniversary--hoyu_SP.png)](https://www.rakuten-card.co.jp/campaign/spt/20th_anniversary_stampcard?l-id=corp_sp_20th_count_sp)

[詳細はこちら](https://www.rakuten-card.co.jp/campaign/spt/20th_anniversary_stampcard?l-id=corp_sp_20th_count_sp)

※条件あり

[![2枚目の楽天カードを作成で500ポイント](https://image.card.jp.rakuten-static.com/card_corp/lay2.0/top/250630_jack-cpn-slide--additional_SP.png)](https://www.rakuten-card.co.jp/campaign/add-card/?l-id=corp_rc_2ndcard_ccarousel)

[詳細はこちら](https://www.rakuten-card.co.jp/campaign/add-card/?l-id=corp_rc_2ndcard_ccarousel)

※進呈ポイントは期間限定ポイントになります。特典進呈には上限や条件がございます。[詳細はこちら](https://www.rakuten-card.co.jp/campaign/add-card/?l-id=corp_rc_2ndcard_ccarousel)

[![楽天カード紹介キャンペーン 条件達成から最短3日後にポイント進呈！※2 紹介した方に1,000ポイント※1 紹介された方に6,000ポイント※1 常時開催](https://image.card.jp.rakuten-static.com/card_corp/lay2.0/top/250407_syokaicpn--hoyu_SP.png)](https://www.rakuten-card.co.jp/campaign/rakuten_card/susumail/?l-id=corp_oo_kv_cpn_ex_susumail_sp)

[詳細はこちら](https://www.rakuten-card.co.jp/campaign/rakuten_card/susumail/?l-id=corp_oo_kv_cpn_ex_susumail_sp)

※1 ポイント（期間限定ポイント含む）の進呈には条件がございます。  
※2 条件達成から最短3日後にポイント進呈となるのは紹介キャンペーン特典のみとなります。[詳細はこちら](https://www.rakuten-card.co.jp/campaign/rakuten_card/susumail/?l-id=corp_oo_kv_cpn_ex_susumail_sp)

楽天カード  
（ナンバーレス）
================

カード情報はアプリから確認

[![楽天カード（ナンバーレス）](https://image.card.jp.rakuten-static.com/card_corp/lay2.0/top/numberless_card_sp.png)](https://www.rakuten-card.co.jp/card/rakuten-numberless-card/?l-id=corp_rc_corp-top_to_numberless_sp)

![タッチ決済](https://image.card.jp.rakuten-static.com/card_corp/common/logo/logo_touch_symbol.svg) Visaはタッチ決済対応です。

年会費  
永年無料

ポイントが  
ザクザク貯まる

![](https://image.card.jp.rakuten-static.com/card_corp/lay2.0/top/numberless_card_icon-security.png)

クレジットカード情報が  
カードに記載なし

[詳細を見る](https://www.rakuten-card.co.jp/card/rakuten-numberless-card/?l-id=corp_rc_corp-top_to_numberless_sp)

家族カード
=====

家計管理を簡単に

[![家族カード](https://image.card.jp.rakuten-static.com/card_corp/lay2.0/top/img_hero_card_family_visa_touch_SP@2x.png)](https://r10.to/hblWNp)

![タッチ決済](https://image.card.jp.rakuten-static.com/card_corp/common/logo/logo_touch_symbol.svg) すべての国際ブランドが  
タッチ決済対応です。

ポイントが  
ザクザクたまる

ご請求は  
まとめて口座振替

年会費  
永年無料※

※楽天ゴールドカード、楽天プレミアムカードは550円(税込み)

[カンタン申し込み](https://r10.to/hb9x9H)
 [詳細](https://r10.to/hIP0is)

楽天プレミアムカード
==========

海外で使える特典が充実

[![楽天プレミアムカード](https://image.card.jp.rakuten-static.com/card_corp/common/cardface/cardface_p_visa_rp_e_front_touch_440_279.png)](https://www.rakuten-card.co.jp/card/rakuten-premium-card/?l-id=corp_oo_kv_detail_ex_pre_sp_b)

![Visa](https://image.card.jp.rakuten-static.com/card_corp/lay2.0/assets/logo/logo_visa.svg)

![Mastercard](https://image.card.jp.rakuten-static.com/card_corp/lay2.0/assets/logo/logo_master.svg)

![JCB](https://image.card.jp.rakuten-static.com/card_corp/lay2.0/assets/logo/logo_jcb.svg)

![American Express](https://image.card.jp.rakuten-static.com/card_corp/lay2.0/assets/logo/logo_amex_alternate_28-39px.svg)

![タッチ決済](https://image.card.jp.rakuten-static.com/card_corp/common/logo/logo_touch_symbol.svg) すべての国際ブランドが  
タッチ決済対応です。

プライオリティ・  
パスが無料

海外保険が  
自動付帯

トラベルデスクで  
旅をサポート

[詳細を見る](https://www.rakuten-card.co.jp/card/rakuten-premium-card/?l-id=corp_oo_kv_detail_ex_pre_sp_b)

楽天ゴールドカード
=========

手軽に持てるゴールドカード

[![楽天ゴールドカード](https://image.card.jp.rakuten-static.com/card_corp/common/cardface/cardface_g_visa_touch_rp_e_front_440_279.png)](https://www.rakuten-card.co.jp/card/rakuten-gold-card/?l-id=corp_oo_kv_detail_ex_gold_sp_b)

![Visa](https://image.card.jp.rakuten-static.com/card_corp/lay2.0/assets/logo/logo_visa.svg)

![Mastercard](https://image.card.jp.rakuten-static.com/card_corp/lay2.0/assets/logo/logo_master.svg)

![JCB](https://image.card.jp.rakuten-static.com/card_corp/lay2.0/assets/logo/logo_jcb.svg)

![タッチ決済](https://image.card.jp.rakuten-static.com/card_corp/common/logo/logo_touch_symbol.svg) すべての国際ブランドが  
タッチ決済対応です。

年会費わずか  
2,200円(税込)

ETCカードの  
年会費無料

国内空港ラウンジ  
年間2回無料

[詳細を見る](https://www.rakuten-card.co.jp/card/rakuten-gold-card/?l-id=corp_oo_kv_detail_ex_gold_sp_b)

[![楽天ブラックカード、楽天プレミアムカードお持ちの方へ 楽天モバイルで使えるギガ割引クーポンを毎月最大10GB進呈！](https://image.card.jp.rakuten-static.com/card_corp/lay2.0/top/250620_premiumprogram--hoyu_SP.png)](https://www.rakuten-card.co.jp/premiumprogram/rakuten-mobile/?l-id=corp_oo_premiumprogram_gigawari_corpcarousel_sp)

[詳細はこちら](https://www.rakuten-card.co.jp/premiumprogram/rakuten-mobile/?l-id=corp_oo_premiumprogram_gigawari_corpcarousel_sp)

※進呈条件あり。本ギガ割引クーポン適用により月のデータ利用量が0GBになる場合でも、プラン料金が最大980円（税込1,078円）請求されます。

[![【超還元祭FINAL】スタンプを貯めてもれなくポイントゲット！ワクワクゥ~っスタンプカード！さらに1万名様に1万ポイントのチャンス！？](https://image.card.jp.rakuten-static.com/card_corp/lay2.0/top/251201_20th_anniversary--hoyu_SP.png)](https://www.rakuten-card.co.jp/campaign/spt/20th_anniversary_stampcard?l-id=corp_sp_20th_count_sp)

[詳細はこちら](https://www.rakuten-card.co.jp/campaign/spt/20th_anniversary_stampcard?l-id=corp_sp_20th_count_sp)

※条件あり

[![2枚目の楽天カードを作成で500ポイント](https://image.card.jp.rakuten-static.com/card_corp/lay2.0/top/250630_jack-cpn-slide--additional_SP.png)](https://www.rakuten-card.co.jp/campaign/add-card/?l-id=corp_rc_2ndcard_ccarousel)

[詳細はこちら](https://www.rakuten-card.co.jp/campaign/add-card/?l-id=corp_rc_2ndcard_ccarousel)

※進呈ポイントは期間限定ポイントになります。特典進呈には上限や条件がございます。[詳細はこちら](https://www.rakuten-card.co.jp/campaign/add-card/?l-id=corp_rc_2ndcard_ccarousel)

[![楽天カード紹介キャンペーン 条件達成から最短3日後にポイント進呈！※2 紹介した方に1,000ポイント※1 紹介された方に6,000ポイント※1 常時開催](https://image.card.jp.rakuten-static.com/card_corp/lay2.0/top/250407_syokaicpn--hoyu_SP.png)](https://www.rakuten-card.co.jp/campaign/rakuten_card/susumail/?l-id=corp_oo_kv_cpn_ex_susumail_sp)

[詳細はこちら](https://www.rakuten-card.co.jp/campaign/rakuten_card/susumail/?l-id=corp_oo_kv_cpn_ex_susumail_sp)

※1 ポイント（期間限定ポイント含む）の進呈には条件がございます。  
※2 条件達成から最短3日後にポイント進呈となるのは紹介キャンペーン特典のみとなります。[詳細はこちら](https://www.rakuten-card.co.jp/campaign/rakuten_card/susumail/?l-id=corp_oo_kv_cpn_ex_susumail_sp)

楽天カード  
（ナンバーレス）
================

カード情報はアプリから確認

[![楽天カード（ナンバーレス）](https://image.card.jp.rakuten-static.com/card_corp/lay2.0/top/numberless_card_sp.png)](https://www.rakuten-card.co.jp/card/rakuten-numberless-card/?l-id=corp_rc_corp-top_to_numberless_sp)

![タッチ決済](https://image.card.jp.rakuten-static.com/card_corp/common/logo/logo_touch_symbol.svg) Visaはタッチ決済対応です。

年会費  
永年無料

ポイントが  
ザクザク貯まる

![](https://image.card.jp.rakuten-static.com/card_corp/lay2.0/top/numberless_card_icon-security.png)

クレジットカード情報が  
カードに記載なし

[詳細を見る](https://www.rakuten-card.co.jp/card/rakuten-numberless-card/?l-id=corp_rc_corp-top_to_numberless_sp)

家族カード
=====

家計管理を簡単に

[![家族カード](https://image.card.jp.rakuten-static.com/card_corp/lay2.0/top/img_hero_card_family_visa_touch_SP@2x.png)](https://r10.to/hblWNp)

![タッチ決済](https://image.card.jp.rakuten-static.com/card_corp/common/logo/logo_touch_symbol.svg) すべての国際ブランドが  
タッチ決済対応です。

ポイントが  
ザクザクたまる

ご請求は  
まとめて口座振替

年会費  
永年無料※

※楽天ゴールドカード、楽天プレミアムカードは550円(税込み)

[カンタン申し込み](https://r10.to/hb9x9H)
 [詳細](https://r10.to/hIP0is)

楽天プレミアムカード
==========

海外で使える特典が充実

[![楽天プレミアムカード](https://image.card.jp.rakuten-static.com/card_corp/common/cardface/cardface_p_visa_rp_e_front_touch_440_279.png)](https://www.rakuten-card.co.jp/card/rakuten-premium-card/?l-id=corp_oo_kv_detail_ex_pre_sp_b)

![Visa](https://image.card.jp.rakuten-static.com/card_corp/lay2.0/assets/logo/logo_visa.svg)

![Mastercard](https://image.card.jp.rakuten-static.com/card_corp/lay2.0/assets/logo/logo_master.svg)

![JCB](https://image.card.jp.rakuten-static.com/card_corp/lay2.0/assets/logo/logo_jcb.svg)

![American Express](https://image.card.jp.rakuten-static.com/card_corp/lay2.0/assets/logo/logo_amex_alternate_28-39px.svg)

![タッチ決済](https://image.card.jp.rakuten-static.com/card_corp/common/logo/logo_touch_symbol.svg) すべての国際ブランドが  
タッチ決済対応です。

プライオリティ・  
パスが無料

海外保険が  
自動付帯

トラベルデスクで  
旅をサポート

[詳細を見る](https://www.rakuten-card.co.jp/card/rakuten-premium-card/?l-id=corp_oo_kv_detail_ex_pre_sp_b)

楽天ゴールドカード
=========

手軽に持てるゴールドカード

[![楽天ゴールドカード](https://image.card.jp.rakuten-static.com/card_corp/common/cardface/cardface_g_visa_touch_rp_e_front_440_279.png)](https://www.rakuten-card.co.jp/card/rakuten-gold-card/?l-id=corp_oo_kv_detail_ex_gold_sp_b)

![Visa](https://image.card.jp.rakuten-static.com/card_corp/lay2.0/assets/logo/logo_visa.svg)

![Mastercard](https://image.card.jp.rakuten-static.com/card_corp/lay2.0/assets/logo/logo_master.svg)

![JCB](https://image.card.jp.rakuten-static.com/card_corp/lay2.0/assets/logo/logo_jcb.svg)

![タッチ決済](https://image.card.jp.rakuten-static.com/card_corp/common/logo/logo_touch_symbol.svg) すべての国際ブランドが  
タッチ決済対応です。

年会費わずか  
2,200円(税込)

ETCカードの  
年会費無料

国内空港ラウンジ  
年間2回無料

[詳細を見る](https://www.rakuten-card.co.jp/card/rakuten-gold-card/?l-id=corp_oo_kv_detail_ex_gold_sp_b)

[![楽天ブラックカード、楽天プレミアムカードお持ちの方へ 楽天モバイルで使えるギガ割引クーポンを毎月最大10GB進呈！](https://image.card.jp.rakuten-static.com/card_corp/lay2.0/top/250620_premiumprogram--hoyu_SP.png)](https://www.rakuten-card.co.jp/premiumprogram/rakuten-mobile/?l-id=corp_oo_premiumprogram_gigawari_corpcarousel_sp)

[詳細はこちら](https://www.rakuten-card.co.jp/premiumprogram/rakuten-mobile/?l-id=corp_oo_premiumprogram_gigawari_corpcarousel_sp)

※進呈条件あり。本ギガ割引クーポン適用により月のデータ利用量が0GBになる場合でも、プラン料金が最大980円（税込1,078円）請求されます。

Next

*   1
*   2
*   3
*   4
*   5
*   6
*   7
*   8

![](https://image.card.jp.rakuten-static.com/r-enavi/WebImages/enavi/login/rexicon-32-sign-info-l.svg)

不審メールに伴うお知らせ【2025/12/01】

楽天カードや国際ブランド（Visa、Mastercard、JCB、Amex）をかたり、リンクをクリックさせようとする不審メールが確認されています。  
不審メールの確認事項をご確認いただき、くれぐれもご注意ください。

[不審メールの確認事項はこちら](https://www.rakuten-card.co.jp/security/security-info/phishingmail/)

* * *

イチオシのご紹介
--------

 [![楽天経済圏 START GUIDE 楽天経済圏の簡単なはじめ方](https://image.card.jp.rakuten-static.com/card_corp/smart/contents/banner/recommend/231006_startguide_640x240.png)](https://www.rakuten-card.co.jp/rakuten-eco/?l-id=corp_sp_ecosystem_corp_ichioshi_sp)
[![楽天ふるさと納税 × Rakuten Card。楽天カードで地域を応援！心ときめく逸品を見つけませんか？](https://image.card.jp.rakuten-static.com/card_corp/smart/contents/banner/recommend/251201_furusato_640x240.png)](https://www.rakuten-card.co.jp/rakuten-eco/area/?l-id=corptop20251201)

[![2枚目の楽天カードを作成＆利用でもれなく500ポイント 要エントリー/条件あり/期間限定ポイントにて進呈](https://image.card.jp.rakuten-static.com/card_corp/smart/contents/banner/recommend/251121_addcardcpn_640_240.png)](https://www.rakuten-card.co.jp/campaign/add-card/?l-id=corp_rc_2ndcard_ichioshi)

 [![楽天経済圏 START GUIDE 楽天経済圏の簡単なはじめ方](https://image.card.jp.rakuten-static.com/card_corp/smart/contents/banner/recommend/231006_startguide_640x240.png)](https://www.rakuten-card.co.jp/rakuten-eco/?l-id=corp_sp_ecosystem_corp_ichioshi_sp)
[![楽天ふるさと納税 × Rakuten Card。楽天カードで地域を応援！心ときめく逸品を見つけませんか？](https://image.card.jp.rakuten-static.com/card_corp/smart/contents/banner/recommend/251201_furusato_640x240.png)](https://www.rakuten-card.co.jp/rakuten-eco/area/?l-id=corptop20251201)

[![2枚目の楽天カードを作成＆利用でもれなく500ポイント 要エントリー/条件あり/期間限定ポイントにて進呈](https://image.card.jp.rakuten-static.com/card_corp/smart/contents/banner/recommend/251121_addcardcpn_640_240.png)](https://www.rakuten-card.co.jp/campaign/add-card/?l-id=corp_rc_2ndcard_ichioshi)

 [![楽天経済圏 START GUIDE 楽天経済圏の簡単なはじめ方](https://image.card.jp.rakuten-static.com/card_corp/smart/contents/banner/recommend/231006_startguide_640x240.png)](https://www.rakuten-card.co.jp/rakuten-eco/?l-id=corp_sp_ecosystem_corp_ichioshi_sp)
[![楽天ふるさと納税 × Rakuten Card。楽天カードで地域を応援！心ときめく逸品を見つけませんか？](https://image.card.jp.rakuten-static.com/card_corp/smart/contents/banner/recommend/251201_furusato_640x240.png)](https://www.rakuten-card.co.jp/rakuten-eco/area/?l-id=corptop20251201)

*   1
*   2

* * *

キャンペーン
------

[一覧へ](https://www.rakuten-card.co.jp/campaign/?l-id=corp_oo_cpnbr_cpn_list_sp_b)

     [![お買い忘れはありませんか？欲しかったものが楽天市場ならお得に買えるかも！まずはクーポンをチェック](https://image.card.jp.rakuten-static.com/card_corp/common/bana/250707_btaca_640x240.png) ![楽天スーパーSALE開催中 お買い忘れはありませんか？欲しかったものが楽天市場ならお得に買えるかも！まずはクーポンをチェック](https://image.card.jp.rakuten-static.com/card_corp/common/bana/251015_btaca_ss_640x240.png) ![お買い物マラソン開催中 お買い忘れはありませんか？欲しかったものが楽天市場ならお得に買えるかも！まずはクーポンをチェック](https://image.card.jp.rakuten-static.com/card_corp/common/bana/251015_btaca_marathon_640x240.png) ![5と0のつく日開催中 お買い忘れはありませんか？欲しかったものが楽天市場ならお得に買えるかも！まずはクーポンをチェック](https://image.card.jp.rakuten-static.com/card_corp/common/bana/251015_btaca_5and0_640x240.png) ![ワンダフルデー開催中 お買い忘れはありませんか？欲しかったものが楽天市場ならお得に買えるかも！まずはクーポンをチェック](https://image.card.jp.rakuten-static.com/card_corp/common/bana/251015_btaca_wonderful_640x240.png) ![ご愛顧感謝デー開催中 お買い忘れはありませんか？欲しかったものが楽天市場ならお得に買えるかも！まずはクーポンをチェック](https://image.card.jp.rakuten-static.com/card_corp/common/bana/251015_btaca_18day_640x240.png)](https://www.rakuten-card.co.jp/campaign/sales/ichiba_recommend/?l-id=corp_ad_top_cpn_sp)

[![楽天モバイル初めてお申し込みで20,000ポイント](https://image.card.jp.rakuten-static.com/card_corp/common/bana/251121_mobile_640x240.png)](https://ac.ebis.ne.jp/tr_set.php?argument=ZMhPE4GP&ai=rgp_mno_006937)

[![楽天プレミアムカードの作成で1,500ポイント](https://image.card.jp.rakuten-static.com/card_corp/common/bana/250630_pre_switch_default_640x240.png)](https://www.rakuten-card.co.jp/campaign/premium_card/hoyu/?l-id=corp_rc_corp_oo_cpnbr_list_pre_sw)

     [![お買い忘れはありませんか？欲しかったものが楽天市場ならお得に買えるかも！まずはクーポンをチェック](https://image.card.jp.rakuten-static.com/card_corp/common/bana/250707_btaca_640x240.png) ![楽天スーパーSALE開催中 お買い忘れはありませんか？欲しかったものが楽天市場ならお得に買えるかも！まずはクーポンをチェック](https://image.card.jp.rakuten-static.com/card_corp/common/bana/251015_btaca_ss_640x240.png) ![お買い物マラソン開催中 お買い忘れはありませんか？欲しかったものが楽天市場ならお得に買えるかも！まずはクーポンをチェック](https://image.card.jp.rakuten-static.com/card_corp/common/bana/251015_btaca_marathon_640x240.png) ![5と0のつく日開催中 お買い忘れはありませんか？欲しかったものが楽天市場ならお得に買えるかも！まずはクーポンをチェック](https://image.card.jp.rakuten-static.com/card_corp/common/bana/251015_btaca_5and0_640x240.png) ![ワンダフルデー開催中 お買い忘れはありませんか？欲しかったものが楽天市場ならお得に買えるかも！まずはクーポンをチェック](https://image.card.jp.rakuten-static.com/card_corp/common/bana/251015_btaca_wonderful_640x240.png) ![ご愛顧感謝デー開催中 お買い忘れはありませんか？欲しかったものが楽天市場ならお得に買えるかも！まずはクーポンをチェック](https://image.card.jp.rakuten-static.com/card_corp/common/bana/251015_btaca_18day_640x240.png)](https://www.rakuten-card.co.jp/campaign/sales/ichiba_recommend/?l-id=corp_ad_top_cpn_sp)

[![楽天モバイル初めてお申し込みで20,000ポイント](https://image.card.jp.rakuten-static.com/card_corp/common/bana/251121_mobile_640x240.png)](https://ac.ebis.ne.jp/tr_set.php?argument=ZMhPE4GP&ai=rgp_mno_006937)

[![楽天プレミアムカードの作成で1,500ポイント](https://image.card.jp.rakuten-static.com/card_corp/common/bana/250630_pre_switch_default_640x240.png)](https://www.rakuten-card.co.jp/campaign/premium_card/hoyu/?l-id=corp_rc_corp_oo_cpnbr_list_pre_sw)

     [![お買い忘れはありませんか？欲しかったものが楽天市場ならお得に買えるかも！まずはクーポンをチェック](https://image.card.jp.rakuten-static.com/card_corp/common/bana/250707_btaca_640x240.png) ![楽天スーパーSALE開催中 お買い忘れはありませんか？欲しかったものが楽天市場ならお得に買えるかも！まずはクーポンをチェック](https://image.card.jp.rakuten-static.com/card_corp/common/bana/251015_btaca_ss_640x240.png) ![お買い物マラソン開催中 お買い忘れはありませんか？欲しかったものが楽天市場ならお得に買えるかも！まずはクーポンをチェック](https://image.card.jp.rakuten-static.com/card_corp/common/bana/251015_btaca_marathon_640x240.png) ![5と0のつく日開催中 お買い忘れはありませんか？欲しかったものが楽天市場ならお得に買えるかも！まずはクーポンをチェック](https://image.card.jp.rakuten-static.com/card_corp/common/bana/251015_btaca_5and0_640x240.png) ![ワンダフルデー開催中 お買い忘れはありませんか？欲しかったものが楽天市場ならお得に買えるかも！まずはクーポンをチェック](https://image.card.jp.rakuten-static.com/card_corp/common/bana/251015_btaca_wonderful_640x240.png) ![ご愛顧感謝デー開催中 お買い忘れはありませんか？欲しかったものが楽天市場ならお得に買えるかも！まずはクーポンをチェック](https://image.card.jp.rakuten-static.com/card_corp/common/bana/251015_btaca_18day_640x240.png)](https://www.rakuten-card.co.jp/campaign/sales/ichiba_recommend/?l-id=corp_ad_top_cpn_sp)

*   1
*   2
*   3

* * *

おすすめの  
クレジットカード
----------------

[一覧へ](https://www.rakuten-card.co.jp/card/?l-id=corp_oo_cchoice_cardlineup_sp#card-list)

*   [![楽天カード](https://image.card.jp.rakuten-static.com/card_corp/common/cardface/cardface_n_visa_rp_e_front_touch_224_142.png)\
    \
    楽天カード](https://www.rakuten-card.co.jp/card/rakuten-card/?l-id=corp_oo_cchoice_detail_card_sp)
    
*   [![楽天カード（ミニーマウス デザイン）](https://image.card.jp.rakuten-static.com/card_corp/common/cardface/cardface_disney_minnie_n_jcb_rp_e_front_234_164.png)\
    \
    楽天カード（ミニーマウス デザイン）](https://www.rakuten-card.co.jp/card/disney-design-card/)
    
*   [![楽天カード（ミッキーマウス デザイン）](https://image.card.jp.rakuten-static.com/card_corp/common/cardface/cardface_disney_n_jcb_rp_e_front_234_164.png)\
    \
    楽天カード（ミッキーマウス デザイン）](https://www.rakuten-card.co.jp/card/disney-design-card/)
    
*   [![楽天カード お買いものパンダデザイン](https://image.card.jp.rakuten-static.com/card_corp/common/cardface/cardface_panda_n_visa_rp_e_front_224_142.png)\
    \
    楽天カードお買いものパンダデザイン](https://www.rakuten-card.co.jp/card/panda-design-card/)
    
*   [![楽天プレミアムカード](https://image.card.jp.rakuten-static.com/card_corp/common/cardface/cardface_p_visa_rp_e_front_touch_224_142.png)\
    \
    楽天プレミアムカード](https://www.rakuten-card.co.jp/card/rakuten-premium-card/?l-id=corp_oo_cchoice_detail_pre_sp)
    
*   [![楽天ANAマイレージクラブカード](https://image.card.jp.rakuten-static.com/card_corp/common/cardface/cardface_bl_n_visa_rp_e_front_224_142.png)\
    \
    楽天ANAマイレージクラブカード](https://www.rakuten-card.co.jp/card/rakuten-amc-card/?l-id=corp_oo_cchoice_detail_amc_sp)
    

[カードの付帯サービスを比較する](https://www.rakuten-card.co.jp/#hierarchy_modal)

![スクロールヒント](https://image.card.jp.rakuten-static.com/card_corp/smart/contents/product-service/ScrollHint_4s.gif)

カード付帯特典

基本情報 モバイル＆ショッピング 金融 トラベル＆  
エンタメ

|     | ![](https://image.card.jp.rakuten-static.com/card_corp/common/hierarchy_include/card__silver.png)<br><br>楽天カード<br><br>[詳細を見る](https://www.rakuten-card.co.jp/campaign/rakuten_card/listing/a.html?referrer=n-LTG012&l-id=corp_rc_comparative_chart_silver_lp) | ![](https://image.card.jp.rakuten-static.com/card_corp/common/hierarchy_include/card__gold.png)<br><br>楽天ゴールド  <br>カード<br><br>[詳細を見る](https://www.rakuten-card.co.jp/campaign/gold_card/?referrer=n-RCA410&l-id=corp_rc_comparative_chart_gold_new) | ![](https://image.card.jp.rakuten-static.com/card_corp/common/hierarchy_include/card__premium.png)<br><br>楽天プレミアム  <br>カード<br><br>[詳細を見る](https://www.rakuten-card.co.jp/campaign/premium_card/?referrer=n-RDA412&l-id=corp_rc_comparative_chart_pre_new) | ![](https://image.card.jp.rakuten-static.com/card_corp/smart/contents/product-service/caed__black.png)<br><br>楽天ブラック  <br>カード<br><br>[詳細を見る](https://www.rakuten-card.co.jp/card/black_card/) |
| --- | --- | --- | --- | --- |
| 年会費 | 年会費無料 | 2,200円  <br>(税込み) | 11,000円  <br>(税込み) | 33,000円  <br>(税込み) |
| ご利用可能枠 | 最高  <br>100万円 | 最高  <br>200万円 | 最高  <br>300万円 | 最高  <br>1,000万円 |
| 通常還元率  <br>※1 | 1％還元（100円につき1ポイント） |     |     |     |
| ETC年会費 | 550円  <br>(税込み)※2 | 無料  | 無料  | 無料  |

ご利用における注意事項  
※1～※2についてはこちらをクリックして必ずご確認ください。
--------------------------------------------

*   一部ポイント還元率が異なるご利用先がございます。
    *   [カード利用獲得ポイントの還元率が異なる  \
        ご利用先を見る](https://www.rakuten-card.co.jp/point/pointrate)
        
*   会員ランクがダイヤモンド会員・プラチナ会員の方は無料となります。
    *   [楽天ETCカードの詳細を見る](https://www.rakuten-card.co.jp/service/etc-card/)
        

|     | ![](https://image.card.jp.rakuten-static.com/card_corp/common/hierarchy_include/card__silver.png)<br><br>楽天カード<br><br>[詳細を見る](https://www.rakuten-card.co.jp/campaign/rakuten_card/listing/a.html?referrer=n-LTG012&l-id=corp_rc_comparative_chart_silver_lp) | ![](https://image.card.jp.rakuten-static.com/card_corp/common/hierarchy_include/card__gold.png)<br><br>楽天ゴールド  <br>カード<br><br>[詳細を見る](https://www.rakuten-card.co.jp/card/rakuten-gold-card/?l-id=corp_rc_gold_compare) | ![](https://image.card.jp.rakuten-static.com/card_corp/common/hierarchy_include/card__premium.png)<br><br>楽天プレミアム  <br>カード<br><br>[詳細を見る](https://www.rakuten-card.co.jp/card/rakuten-premium-card/?l-id=corp_rc_pre_compare) | ![](https://image.card.jp.rakuten-static.com/card_corp/smart/contents/product-service/caed__black.png)<br><br>楽天ブラック  <br>カード<br><br>[詳細を見る](https://www.rakuten-card.co.jp/card/black_card/) |
| --- | --- | --- | --- | --- |
| ![プレミアムプログラム対象](https://image.card.jp.rakuten-static.com/card_corp/smart/contents/product-service/premium_program_sp.png) ![楽天モバイル](https://image.card.jp.rakuten-static.com/card_corp/smart/contents/fintech/rakuten-mobile.png) ギガ割引クーポン適用で  <br>楽天モバイル料金が最大1,100円  <br>（税込）割引  <br>※1 | \-  | \-  | 5GB/月 | 10GB/月 |
| ![プレミアムプログラム対象](https://image.card.jp.rakuten-static.com/card_corp/smart/contents/product-service/premium_program_sp.png)  <br>楽天市場での  <br>お買い物  <br>※2 | 3倍  | 3倍  | 3倍  | 3倍  |
| ![プレミアムプログラム対象](https://image.card.jp.rakuten-static.com/card_corp/smart/contents/product-service/premium_program_sp.png)  <br>お誕生月特典  <br>進呈条件あり ※3 | \-  | +1倍 | +1倍 | +1倍 |
| ![プレミアムプログラム対象](https://image.card.jp.rakuten-static.com/card_corp/smart/contents/product-service/premium_program_sp.png)  <br>楽天市場特典  <br>進呈条件あり ※4 | \-  | \-  | +1倍 | +1倍 |

特典（期間限定ポイント含む）進呈には上限や条件があります。詳細は以下をご覧ください。  
※1～※4の特典（期間限定ポイント含む）進呈には上限や条件があります。こちらをクリックして必ずご確認ください。
----------------------------------------------------------------------------------------------------

*   *   本ギガ割引クーポンの進呈には条件がございます。
    *   本ギガ割引クーポンは毎月中旬頃に楽天カードよりメールにて進呈いたします。
    *   本ギガ割引クーポン適用により月のデータ利用量が0GBになる場合でも、プラン料金が最大980円（税込1,078円）請求されます。
    *   ギガ割引クーポンの詳細は[こちら](https://www.rakuten-card.co.jp/premiumprogram/rakuten-mobile)
        からご確認ください。
*   楽天市場ご利用分、楽天カード通常分、楽天カード特典分を合算したものになります。  
    楽天市場ご利用分は、商品ごとのお買い物金額（税抜き・クーポン利用後）100円につき1ポイント（通常ポイント）となります。  
    楽天カード通常分は、楽天市場でのカードご利用額100円につき1ポイント（通常ポイント）となります。  
    楽天カード特典分は、楽天市場でのカードご利用額（消費税・送料・ラッピング料除く）100円につき1ポイント（期間限定ポイント）となります。  
    獲得ポイントには上限があります（楽天ブラックカード、楽天プレミアムカード：月間5,000ポイント、その他のカード：月間1,000ポイント）。
*   お誕生月特典は、楽天市場・楽天ブックスでの楽天ゴールドカード・楽天プレミアムカード、楽天ブラックカードご利用額100円につき1ポイント（通常ポイント）となります。獲得ポイントには上限があります（楽天ゴールドカード：月間2,000ポイント、楽天プレミアムカード、楽天ブラックカード：月間10,000ポイント）。
*   楽天市場特典分は、毎週火曜・木曜の楽天市場でのカードご利用額100円につき1ポイント（通常ポイント）となります。  
    楽天プレミアムカード会員様は楽天市場特典を選んでいる場合に対象となります。  
    獲得ポイントには上限があります。  
    楽天プレミアムカード：月間10,000ポイント  
    楽天ブラックカード：月間10,000ポイント（楽天市場でのご利用分、楽天トラベル（オンライン決済）でのご利用分、楽天ブックス・Rakuten TVでのご利用分の合計）

|     | ![](https://image.card.jp.rakuten-static.com/card_corp/common/hierarchy_include/card__silver.png)<br><br>楽天カード<br><br>[詳細を見る](https://www.rakuten-card.co.jp/campaign/rakuten_card/?referrer=n-CRP045) | ![](https://image.card.jp.rakuten-static.com/card_corp/common/hierarchy_include/card__gold.png)<br><br>楽天ゴールド  <br>カード<br><br>[詳細を見る](https://www.rakuten-card.co.jp/card/rakuten-gold-card/?l-id=corp_rc_gold_compare) | ![](https://image.card.jp.rakuten-static.com/card_corp/common/hierarchy_include/card__premium.png)<br><br>楽天プレミアム  <br>カード<br><br>[詳細を見る](https://www.rakuten-card.co.jp/card/rakuten-premium-card/?l-id=corp_rc_pre_compare) | ![](https://image.card.jp.rakuten-static.com/card_corp/smart/contents/product-service/caed__black.png)<br><br>楽天ブラック  <br>カード<br><br>[詳細を見る](https://www.rakuten-card.co.jp/card/black_card/) |
| --- | --- | --- | --- | --- |
| ![プレミアムプログラム対象](https://image.card.jp.rakuten-static.com/card_corp/smart/contents/product-service/premium_program_sp.png) ![楽天銀行](https://image.card.jp.rakuten-static.com/card_corp/pc/contents/fintech/rakuten-bank.png) 楽天カードの利用代金引き落としでの普通預金金利  <br>（税引後の金利）  <br>※1 | 年0.22％  <br>（年0.175％）<br><br>年0.23％  <br>（年0.183％）<br><br>年0.24％  <br>（年0.191％）<br><br>年0.28％  <br>（年0.223％）<br><br>※2025年3月3日現在のものです。※楽天銀行調べ |     |     |     |
| ![プレミアムプログラム対象](https://image.card.jp.rakuten-static.com/card_corp/smart/contents/product-service/premium_program_sp.png) ![楽天証券](https://image.card.jp.rakuten-static.com/card_corp/pc/contents/fintech/rakuten_sonpo.png) 楽天カードの券種別ポイント進呈率  <br>※2 | 2.5% | 3.0% | 3.0% | 3.0% |
| ![プレミアムプログラム対象](https://image.card.jp.rakuten-static.com/card_corp/smart/contents/product-service/premium_program_sp.png) ![楽天証券](https://image.card.jp.rakuten-static.com/card_corp/pc/contents/fintech/rakuten-sec.png) 投信積立  <br>楽天カードクレジット決済でのポイント進呈率  <br>※3 | 0.5% | 0.75% | 1.0% | 2.0% |

ご利用における注意事項  
※1～※3についてはこちらをクリックして必ずご確認ください。
--------------------------------------------

*   楽天銀行の普通預金金利は年0.20％（税引き後年0.159%）です。※2025年3月3日時点  
    楽天銀行口座からの楽天カードのカード利用代金の引き落としがある会員様は年0.22％（税引き後0.175％）の「優遇金利」が適用されます。  
    さらにカードの種類に応じた「ボーナス金利」が上乗せされます。
    
    【優遇金利】
    
    *   楽天銀行口座からの楽天カードのカード利用金額の引き落とし（入出金明細には ラクテンカードサービス と表示されます）がある会員様に、引き落としがあった日が属する月の翌月1カ月間適用される優遇金利です。
    *   利息には復興特別所得税が課され、源泉分離課税20.315％（国税15.315％、地方税5％）となります。
    *   複数の金利優遇の条件を達成した場合でも、適用される金利は最も高い優遇金利のみとなります。
    *   毎日の午前0時における最終残高1,000円以上について毎年3月31日と9月30日に、Webページ上表示する毎日の利率によって1年を365日とする日割計算のうえ普通預金に組み入れます。
    *   付利対象期間は、3月31日の場合は9月30日から3月30日まで、9月30日の場合は3月31日から9月29日までとし、いずれも両端入れとします。
    *   規定の支払日（27日（土・日・祝日の場合は翌営業日））に楽天銀行口座から引き落としがされなかった場合、優遇金利は適用されません。
    *   OKB支店・NCB支店・JRE BANK口座の各支店は適用対象外となります。
    *   普通預金金利は変動金利です。お預入れ後の金利は、金融情勢等により予告なく変更する場合があります。
    
    【ボーナス金利】
    *   前月末時点で楽天銀行に引落設定を完了している必要があります。
    *   適用金利は普通預金残高300万円が上限となります。
    *   利息は以下のスケジュールで、対象期間の各月ごとの平均残高に利率を掛け合わせ、普通預金に組入れます。  
        普通預金への組入れ期間：毎年3月21日～3月31日  
        └対象期間：9月1日から2月28日（※閏年の場合は2月29日）  
        普通預金への組入れ期間：毎年9月21日～9月30日  
        └対象期間：3月1日から8月31日
    *   楽天銀行口座からの楽天カードのカード利用金額の引き落とし（入出金明細には ラクテンカードサービス と表示されます）がある会員様に、引き落としがあった日が属する月の翌月1カ月間適用されるボーナス金利です。
    *   利息には復興特別所得税が課され、源泉分離課税20.315％（国税15.315％、地方税5％）となります。
    *   規定の支払日（27日（土・日・祝日の場合は翌営業日））に楽天銀行口座から引き落としがされなかった場合、優遇金利は適用されません。
    *   第一生命支店・OKB支店・NCB支店・JRE BANK口座の各支店は適用対象外となります。
    *   普通預金金利は変動金利です。お預入れ後の金利は、金融情勢等により予告なく変更する場合があります。
*   *   ■
    *   対象商品保険料の1％～2％
    
    *   対象商品
    
    *   サイクルアシスト（傷害総合保険）
    *   ゴルフアシスト（傷害総合保険）
    
    *   └「2025年1月14日以降に申し込まれた新規契約」は決済するクレジットカードによって進呈率が異なります。
    *   （「2025年1月13日以前に申し込まれた新規契約」と「継続契約」は対象保険料の1％）
    
    *   【楽天ブラックカード、楽天プレミアムカード、楽天ゴールドカード会員様】
    *   楽天損保・楽天カードからの進呈率は下記の通りです。
    
    |     |     |     |     |
    | --- | --- | --- | --- |
    |     | ポイント払いなし | 一部ポイント払い | 全額ポイント払い |
    | 楽天損保  <br>ポイント進呈率 | 2.0% | 2.0% | 1.0% |
    | 楽天カードクレジット決済  <br>ポイント還元率 | 1.0% | 1.0%  <br>（ポイント払い分を除く） | 対象外 |
    | 合計  | 3.0% | 最大3.0% | 1.0% |
    
    *   【楽天カード会員様】
    *   楽天損保・楽天カードからの進呈率は下記の通りです。
    
    |     |     |     |     |
    | --- | --- | --- | --- |
    |     | ポイント払いなし | 一部ポイント払い | 全額ポイント払い |
    | 楽天損保  <br>ポイント進呈率 | 1.5% | 1.5% | 1.0% |
    | 楽天カード  <br>クレジット決済  <br>ポイント還元率 | 1.0% | 1.0%  <br>（ポイント払い分を除く） | 対象外 |
    | 合計  | 2.5% | 最大2.5% | 1.0% |
    
*   *   信託報酬のうち販売会社が受け取る手数料（代行手数料）が年率0.4％（税込）未満のファンドが対象となります。
    *   代行手数料が年率0.4％（税込）以上のファンドは、楽天ブラックカードは2％還元、その他のカードは一律1％還元です。

*   [楽天銀行で楽天カードのお引き落としがある場合の普通預金の商品詳細説明書について詳細を見る](https://www.rakuten-bank.co.jp/assets/fixeddep/savings/rakuten-card.html)
    
*   [楽天カードボーナス金利の商品詳細説明書について詳細を見る](https://www.rakuten-bank.co.jp/assets/fixeddep/savings/card-bonus.html?scid=wi_rkc_premiumpgm_card_to_bank)
    
*   [普通預金の商品詳細説明書を見る](https://www.rakuten-bank.co.jp/assets/fixeddep/savings/)
    
*   [銀行代理業について詳細を見る](https://www.rakuten-card.co.jp/corporate/licence/bank/)
    

|     | ![](https://image.card.jp.rakuten-static.com/card_corp/common/hierarchy_include/card__silver.png)<br><br>楽天カード<br><br>[詳細を見る](https://www.rakuten-card.co.jp/campaign/rakuten_card/?referrer=n-CRP045) | ![](https://image.card.jp.rakuten-static.com/card_corp/common/hierarchy_include/card__gold.png)<br><br>楽天ゴールド  <br>カード<br><br>[詳細を見る](https://www.rakuten-card.co.jp/card/rakuten-gold-card/?l-id=corp_rc_gold_compare) | ![](https://image.card.jp.rakuten-static.com/card_corp/common/hierarchy_include/card__premium.png)<br><br>楽天プレミアム  <br>カード<br><br>[詳細を見る](https://www.rakuten-card.co.jp/card/rakuten-premium-card/?l-id=corp_rc_pre_compare) | ![](https://image.card.jp.rakuten-static.com/card_corp/smart/contents/product-service/caed__black.png)<br><br>楽天ブラック  <br>カード<br><br>[詳細を見る](https://www.rakuten-card.co.jp/card/black_card/) |
| --- | --- | --- | --- | --- |
| 国内空港  <br>ラウンジ  <br>※1 | \-  | 年2回まで  <br>無料 | 回数制限なし | 回数制限なし |
| 海外空港  <br>ラウンジ  <br>※2 | \-  | \-  | 年間5回まで無料、6回目以降は1回あたりUS35$ | 回数制限なし |
| 海外旅行  <br>傷害保険  <br>※3 | 最高  <br>2,000万円 | 最高  <br>2,000万円 | 最高  <br>5,000万円 | 最高  <br>1億円 |
| 国内旅行  <br>傷害保険  <br>※4 | \-  | \-  | 最高  <br>5,000万円 | 最高  <br>5,000万円 |
| ![プレミアムプログラム対象](https://image.card.jp.rakuten-static.com/card_corp/smart/contents/product-service/premium_program_sp.png) 常時開催中  <br>楽天トラベル予約時の楽天カード事前決済特典  <br>※5（要エントリー） | ポイント還元率  <br>2.5倍 | ポイント還元率  <br>3倍 | ポイント還元率  <br>3.5倍 | ポイント還元率  <br>3.5倍 |
| ![プレミアムプログラム対象](https://image.card.jp.rakuten-static.com/card_corp/smart/contents/product-service/premium_program_sp.png) 2025年10月1日(水)  <br>リリース  <br>楽天ぐるなび  <br>対象コースを  <br>ネット予約・来店での  <br>ポイント還元率  <br>※6 | \-  | \-  | ポイント還元率  <br>3% | ポイント還元率  <br>5% |
| ![プレミアムプログラム対象](https://image.card.jp.rakuten-static.com/card_corp/smart/contents/product-service/premium_program_sp.png) ![楽天マガジン](https://image.card.jp.rakuten-static.com/card_corp/smart/contents/product-service/rakuten-magazine.png)  <br>雑誌の閲読  <br>※7 | \-  | \-  | 月3冊まで無料 | 月3冊まで無料 |
| ![プレミアムプログラム対象](https://image.card.jp.rakuten-static.com/card_corp/smart/contents/product-service/premium_program_sp.png) ![楽天ミュージック](https://image.card.jp.rakuten-static.com/card_corp/smart/contents/product-service/rakuten-music.png)  <br>楽曲の再生  <br>※8 | \-  | \-  | 30日ごとに  <br>5時間まで無料 | 30日ごとに  <br>5時間まで無料 |

※1～※8における注意事項  
※5の特典進呈には条件達成が必要です。こちらをクリックして必ずご確認ください。
-------------------------------------------------------

*   楽天ゴールドカード、楽天プレミアムカード、楽天ブラックカードと当日航空券（もしくは半券）のご提示で空港ラウンジを無料でご利用いただけます（楽天ゴールドカードは年2回まで）。
    *   [国内空港ラウンジの詳細を見る](https://www.rakuten-card.co.jp/overseas/privilege/lounge/japan/)
        
*   海外空港ラウンジは無料でお申し込みいただけるプライオリティ・パスによるサービスです。別途、楽天e-NAVIよりお申込手続きが必要となります。
    *   [プライオリティ・パスの詳細を見る](https://www.rakuten-card.co.jp/overseas/privilege/lounge/overseas/)
        
*   海外旅行傷害保険：傷害死亡・後遺障害保険金における最高額。適用条件あり。
    *   [海外旅行傷害保険の詳細を見る](https://www.rakuten-card.co.jp/overseas/insurance/)
        
*   国内旅行傷害保険：傷害死亡・後遺障害保険金における最高額。適用条件あり。
    *   [国内旅行傷害保険の詳細を見る](https://static.card.jp.rakuten-static.com/card_corp/pc/pdf/view/prev/p/premium_card/protection/20140916_pr_domestic.pdf)
        
*   *   本特典はエントリーが必須です。[こちら](https://travel.rakuten.co.jp/card/campaign/)
        からエントリーをお願いいたします。
    *   付与ポイントの内訳は以下となります。  
        通常ポイント（1倍）※1＋楽天カード通常分（1倍）※2＋本キャンペーン特典分（0.5倍）※3。  
        （※1楽天トラベルサイト上で成立している料金（税抜き）100円につき1ポイント（通常ポイント）となります。  
        ※2楽天トラベルサイトでのカードご利用額100円につき1ポイント（通常ポイント）となります。  
        ※3楽天トラベルサイト上で成立している料金（税抜き）200円につき1ポイント（通常ポイント）となります。  
        ※楽天ゴールドカード会員様なら本キャンペーン特典分は1倍（100円につき1ポイント）、楽天ブラックカードおよび楽天プレミアムカード会員様なら本キャンペーン特典分は1.5倍（100円につき1ポイント＋200円につき1ポイント）を進呈いたします。）
    *   特典進呈には条件達成が必要です。詳細を必ずご確認ください。[エントリー・詳細はこちらから](https://travel.rakuten.co.jp/card/campaign/)
        
*   楽天ぐるなびにて、対象店舗の対象コースを2名以上でネット予約・来店すると、お持ちの楽天カードの券種によって決まる「幹事ランク」に応じた幹事ポイント（楽天ポイント）を進呈いたします。  
    楽天ブラックカード：エース幹事ランクが付帯（コース料金（税抜）の5%が還元されます）  
    楽天プレミアムカード：レギュラー幹事ランクが付帯（コース料金（税抜）の3%が還元されます）
    
    *   家族カードは対象外です
    *   「幹事ポイント対象店」のラベルが付いたお店の対象コースを予約・来店した場合、幹事ポイント進呈対象予約となります。
    *   ご予約・来店されたコース金額（税抜）×来店人数に対して、ランクに応じた幹事ポイントを進呈します。
    *   ご予約金額と実際のコース金額に差異がある場合には、いずれか低い方の金額を基準といたします。
    *   進呈ポイントには、予約・来店ポイントが含まれます。
    *   幹事ポイントが予約・来店ポイントを下回る場合には、予約・来店ポイントを進呈いたします。
    
    [幹事ランクの詳細はこちらをご確認ください](https://member.gnavi.co.jp/kanjirank/)
    
*   サービスのご利用には別途お申し込みが必要です。楽天ブラックカードまたは楽天プレミアムカードを新規ご契約された場合、楽天マガジンでの認証に楽天ブラックカードまたは楽天プレミアムカードのお受け取りから1日から2日ほどお待ちいただく場合がございます。
    *   [楽天マガジン優待の詳細を見る](https://magazine.rakuten.co.jp/lite/card/info.html?scid=we_card_lite_202407_AppNA&argument=vqhTTgFN&dmai=a6667c91d3d0d6)
        
*   一部フル再生及びダウンロード対象外楽曲がございます。楽天ブラックカードまたは楽天プレミアムカードを新規ご契約された場合、楽天ミュージックでの認証に楽天ブラックカードまたは楽天プレミアムカードのお受け取りから1日から2日ほどお待ちいただく場合がございます。
    *   [楽天ミュージック優待の詳細を見る](https://music.rakuten.co.jp/plan/bundle/?scid=wi_rcd_msc_comparison_table_bundle_all)
        

* * *

楽天カードの取り組み
----------

[![セキュリティ](https://image.card.jp.rakuten-static.com/card_corp/smart/contents/icon/security.svg)\
\
安心のセキュリティ](https://www.rakuten-card.co.jp/security/?l-id=corp_oo_about_security_sp)
[![お客様の声](https://image.card.jp.rakuten-static.com/card_corp/smart/contents/icon/voice.svg)\
\
お客様の声を実現しました](https://www.rakuten-card.co.jp/support/customer/voice/?l-id=corp_oo_about_voice_sp)

* * *

お知らせ
----

[一覧へ](https://www.rakuten-card.co.jp/info/news/?l-id=corp_oo_top_to_information_sp)

 新着情報  セキュリティ情報

[お客様の声2025/11/28\
\
【お客様の声を実現】ご利用覚えのない請求に関するご案内メールをリニューアルいたしました。](https://www.rakuten-card.co.jp/support/customer/voice/)
[2025/11/12\
\
令和7年台風第22号に伴う災害により被害を受けられた皆さまへ](https://www.rakuten-card.co.jp/info/news/20251009_2/)
[お客様の声2025/10/31\
\
【お客様の声を実現】増枠の審査結果通知メールをリニューアルいたしました。](https://www.rakuten-card.co.jp/support/customer/voice/)
[![犯罪収益移転防止法にもとづく本人確認手続きについて](https://image.card.jp.rakuten-static.com/card_corp/smart/contents/icon/icon_authentication.svg)\
\
犯罪収益移転防止法にもとづく本人確認手続きについて](https://www.rakuten-card.co.jp/support/guide/identification/?l-id=corp_oo_top_to_identification_sp)
[![安全なクレジットカード取引への取り組み](https://image.card.jp.rakuten-static.com/card_corp/smart/contents/icon/icon_security_shield.svg)\
\
安全なクレジットカード取引への取り組み](https://www.rakuten-card.co.jp/security/risk_prevention/?l-id=corp_oo_top_to_risk_prevention_sp)
[![システムメンテナンス情報](https://image.card.jp.rakuten-static.com/card_corp/smart/contents/icon/system-maintenance.svg)\
\
システムメンテナンス情報](https://www.rakuten-card.co.jp/info/rules/maintenance/?l-id=corp_oo_top_to_maintenance_sp)

[2025/12/04\
\
株式会社駿河屋「駿河屋」における不正アクセスによるお客様情報流出について](https://www.rakuten-card.co.jp/info/news/20251204/)
[2025/11/17\
\
有限会社ベルコーポレーション「リサイクル着物おりいぶ」における不正アクセスによるお客様情報流出について](https://www.rakuten-card.co.jp/info/news/20251117/)
[2025/10/31\
\
株式会社オフィスバスターズ「ビジフォン舗」における不正アクセスによるお客様情報流出について](https://www.rakuten-card.co.jp/info/news/20251031/)
[2025/10/31\
\
BLBG株式会社「ヴァルカナイズロンドンオンラインストア」における不正アクセスによるお客様情報流出について](https://www.rakuten-card.co.jp/info/news/20251030/)
[![フィッシング詐欺](https://image.card.jp.rakuten-static.com/card_corp/smart/contents/icon/phishing.svg)\
\
楽天及び楽天カードを装った不審なメールにご注意ください](https://www.rakuten-card.co.jp/security/security-info/phishingmail/?l-id=corp_oo_top_to_phishingmail_sp)

* * *

便利なサービス
-------

[![楽天e-NAVI](https://image.card.jp.rakuten-static.com/card_corp/common/logo/logo_e-navi.svg)\
\
楽天e-NAVI\
\
会員様専用オンラインサービス](https://www.rakuten-card.co.jp/service/e-navi/?l-id=corp_top_to_enavi_sp)
[![楽天カードアプリ](https://image.card.jp.rakuten-static.com/card_corp/common/icon/icon_appli.svg)\
\
楽天カード公式アプリ\
\
明細確認、支出管理も楽々](https://www.rakuten-card.co.jp/service/app/?l-id=corp_de_app_pull_021)
[![Rakuten Card Lite](https://image.card.jp.rakuten-static.com/card_corp/common/icon/icon_appli_lite.svg)\
\
Rakuten Card Lite\
\
楽天カードの英語対応アプリ](https://www.rakuten-card.co.jp/service/app/rakutencardlite/?l-id=corp_top_to_lapp_sp)
[![楽天ペイ](https://image.card.jp.rakuten-static.com/card_corp/common/icon/icon_rpay.svg)\
\
楽天ペイアプリ\
\
楽天カードのお支払いをスマホで](https://www.rakuten-card.co.jp/cashless/rakuten-pay/?l-id=corp_oo_top_to_rakuten-pay_sp)
[![楽天銀行](https://image.card.jp.rakuten-static.com/card_corp/common/icon/icon_rbank.svg)\
\
楽天銀行\
\
銀行代理業\
\
引き落とし口座にするとおトク](https://www.rakuten-bank.co.jp/account/?scid=wi_rkc_cardtop_convenientservice)
[![楽天証券](https://image.card.jp.rakuten-static.com/card_corp/common/icon/icon_rsecurity.svg)\
\
楽天証券\
\
楽天カードでの積立でポイントが貯まる](https://r10.to/h5EL9o)

* * *

会員様だけのご優待
---------

*   [![楽天カードポイントプラス 楽天ポイントが貯まる！当たる！ショップが満載 毎月更新](https://image.card.jp.rakuten-static.com/card_corp/smart/contents/banner/xlo_2_v3@2x.png)](https://www.rakuten-card.co.jp/point/shop-point/?l-id=corp_oo_shop-point_sp)
    

* * *

楽天カードの動画・読みもの
-------------

[![楽天経済圏START GUIDE](https://image.card.jp.rakuten-static.com/card_corp/smart/contents/bg_rzone.png)\
\
![楽天経済圏START GUIDE](https://image.card.jp.rakuten-static.com/card_corp/common/logo/logo_rzone.png)\
\
楽天経済圏の簡単なはじめ方をご紹介](https://www.rakuten-card.co.jp/rakuten-eco/?l-id=corp_sp_ecosystem_corp_yomimono_sp)
[![みんなのマネ活](https://image.card.jp.rakuten-static.com/card_corp/smart/contents/bg_funpay@2x.jpg)\
\
![みんなのマネ活](https://image.card.jp.rakuten-static.com/card_corp/common/logo/logo_minna_01.png)\
\
みんなでつくる！暮らしのマネーメディア](https://www.rakuten-card.co.jp/minna-money/?lid=rkc)
[![はじめよう！楽天カードライフ](https://image.card.jp.rakuten-static.com/card_corp/smart/contents/bg_start-cardlife.jpg)\
\
![はじめよう！楽天カードライフ](https://image.card.jp.rakuten-static.com/card_corp/smart/contents/start-cardlife_title.png)\
\
安心・安全にご利用いただくための基本情報をご紹介](https://www.rakuten-card.co.jp/support/guide/start-cardlife?l-id=corp_sp_top_to_start-cardlife)
[![CM・動画](https://image.card.jp.rakuten-static.com/card_corp/smart/contents/v2_bg_cm@2x.jpg)\
\
CM・動画\
\
楽天カードのテレビCMやメイキング映像をご紹介](https://www.rakuten-card.co.jp/card/cm/?l-id=corp_oo_top_banner_to_cm_gallery_sp)

* * *

お金の知識を学ぶならマネ活
-------------

[![](https://www.rakuten-card.co.jp/minna-money/credit-card/use/article_2307_80233/img/OGP.jpg)\
\
生活 2025/12/04\
\
キャッシュレス決済での家計管理は難しい？管理のコツや家計簿のつけ方を解説](https://www.rakuten-card.co.jp/minna-money/credit-card/use/article_2307_80233/)

[![](https://www.rakuten-card.co.jp/minna-money/credit-card/knowledge/article_2110_00003/OGP.png)\
\
生活 2025/12/04\
\
楽天カードでのキャッシング利用方法！注意点やATM操作も解説](https://www.rakuten-card.co.jp/minna-money/credit-card/knowledge/article_2110_00003/)

[![](https://www.rakuten-card.co.jp/minna-money/credit-card/use/article_2309_80371/img/OGP.png)\
\
生活 2025/12/04\
\
税金をコンビニで支払うときにクレジットカードは使える？支払方法や注意点も解説](https://www.rakuten-card.co.jp/minna-money/credit-card/use/article_2309_80371/)

[![](https://www.rakuten-card.co.jp/minna-money/credit-card/use/article_2306_80171/ogp.png)\
\
生活 2025/12/04\
\
海外でクレジットカードが使えない？確認事項や注意点について解説](https://www.rakuten-card.co.jp/minna-money/credit-card/use/article_2306_80171/)

[他の記事を見る](https://www.rakuten-card.co.jp/minna-money/?scid=wi_mny_card_corp_top)

* * *

返済シミュレーション
----------

[![リボ払いで返済](https://image.card.jp.rakuten-static.com/card_corp/smart/contents/icon/revolving.svg)\
\
ショッピングリボ払い](https://www.rakuten-card.co.jp/revo/simulation/20180910/?l-id=corp_re_top_revo-simulation_sp)
[![分割払いで返済](https://image.card.jp.rakuten-static.com/card_corp/multiple/adjustment/icon_divided.svg)\
\
分割払い](https://www.rakuten-card.co.jp/adjustment/installment/simulation/?l-id=corp_re_top_to_installment-simulation_sp)
[![キャッシングで返済](https://image.card.jp.rakuten-static.com/card_corp/smart/contents/icon/cashing.svg)\
\
キャッシング](https://www.rakuten-card.co.jp/cashing/simulation/?l-id=corp_re_top_ca-simulation_sp)

* * *

－住所変更手続きのお願い－
-------------

お引越し等で住所が変わられた際には、当社宛にお早めに住所変更の届出をお願いします。 お届けいただけない場合、当社からの重要なお知らせが届かない場合もありますのでご注意ください。

[住所変更手続きはこちらから](https://www.rakuten-card.co.jp/e-navi/members/information/customer/)

* * *

お問い合わせ
------

[![カードの紛失・盗難](https://image.card.jp.rakuten-static.com/card_corp/smart/contents/icon/lost.svg)\
\
カードの紛失・盗難](https://www.rakuten-card.co.jp/contact/robbery/?l-id=corp_re_top_robbery_sp)
[![よくあるご質問](https://image.card.jp.rakuten-static.com/card_corp/smart/contents/icon/question.svg)\
\
よくあるご質問](https://support.rakuten-card.jp/?site_domain=guest)
[![お客様サポート](https://image.card.jp.rakuten-static.com/card_corp/smart/contents/icon/contact.svg)\
\
お客様サポート](https://www.rakuten-card.co.jp/support/?l-id=corp_oo_top_to_support_sp)

* * *

HDI格付けで三つ星獲得
------------

サポートサービスにおける世界最大のメンバーシップ団体HDIの日本拠点HDI-Japan（運営：シンクサービス株式会社）が主催するHDI格付けベンチマークにおいて、三つ星を獲得いたしました（2025年5月9日時点）。

この評価は、お客様へのサポート品質が、HDIの国際標準において最高レベルであることが証明されたものです。専門知識を持ったオペレーターがお客様一人ひとりに寄り添い、丁寧にご案内いたします。

【問合せ窓口格付け】

![](https://image.card.jp.rakuten-static.com/card_corp/multiple/contents/hdi/customer_service.jpg)

【Webサポート格付け】

![](https://image.card.jp.rakuten-static.com/card_corp/multiple/contents/hdi/support_portal.jpg)

* * *

企業情報
----

楽天カード株式会社

東京都港区南青山二丁目6番21号  
楽天クリムゾンハウス青山  
電話番号　03-6740-6740

貸金業登録番号 関東財務局長(5) 第01486号  
日本貸金業協会会員 第005692号

*   [会社概要](https://www.rakuten-card.co.jp/corporate/?l-id=corp_re_top_corporate_sp)
    
*   [プレスリリース](https://www.rakuten-card.co.jp/corporate/news_release/?l-id=corp_re_top_pressrelease_sp)
    
*   [採用情報](https://r10.to/hs05eU)
    

*   [![X](https://image.card.jp.rakuten-static.com/card_corp/lay2.0/assets/logo/sns/sns_x_white_circle.svg)](https://www.rakuten-card.co.jp/service/twitter/?l-id=corp_oo_from_top_to_twitter_sp)
    
*   [![facebook](https://image.card.jp.rakuten-static.com/card_corp/common/icon/icon_facebook_circle.svg)](https://www.facebook.com/RakutenCard)
    
*   [![line](https://image.card.jp.rakuten-static.com/card_corp/common/icon/icon_line_circle.svg)](https://www.rakuten-card.co.jp/service/line/)
    
*   [![instagram](https://image.card.jp.rakuten-static.com/card_corp/common/icon/icon_instagram.svg)](https://www.rakuten-card.co.jp/service/instagram/?l-id=corp_oo_corptop_to_ig_sp)
    

当社が契約する貸金業務にかかる指定紛争解決機関  
日本貸金業協会　貸金業相談・紛争解決センター  
電話番号 03-5739-3861  

[紛争解決手続（ADRについて）](http://www.j-fsa.or.jp/personal/contact/adr.php)

※キャッシングをご利用の際は、貸付条件の確認をし、計画的にご利用ください。[貸付条件表はこちら](https://static.card.jp.rakuten-static.com/card_corp/pc/pdf/contents/agreement/cashing_guidance_202404.pdf)

* * *

[![グリーンな未来を一緒につくろう！キャンペーン実施中！](https://image.card.jp.rakuten-static.com/card_corp/smart/contents/banner/2207_gogreen_600x140.jpg)](https://corp.rakuten.co.jp/event/gogreen/?scid=wi_rkc_gogreen_001_sp)

* * *

[![楽天ふるさと納税 × Rakuten Card。楽天カードで地域を応援！心ときめく逸品を見つけませんか？](https://image.card.jp.rakuten-static.com/card_corp/smart/contents/banner/20251201_furusato_640x140.png)](https://www.rakuten-card.co.jp/rakuten-eco/area/?l-id=corptop20251201)

[![全国屈指の水産都市、北海道根室市　根室かに祭り](https://image.card.jp.rakuten-static.com/card_corp/smart/contents/banner/2511_furusato_600x140.png)](https://www.rakuten-card.co.jp/rakuten-eco/area/nemuro/citypromotion/?l-id=corptop20251101)

* * *

楽天グループのお得な情報
------------

*   [![グループサービスを使えば使うほどポイントアップ！](https://image.card.jp.rakuten-static.com/card_corp/smart/contents/banner/250131_spu_banner_240x240.gif)](https://event.rakuten.co.jp/campaign/point-up/everyday/point/)
    
*   [![5の倍数の日に楽天市場で楽天カードをご利用でポイント4倍！](https://image.card.jp.rakuten-static.com/card_corp/smart/contents/banner/231205_card5x_240x240.png)](https://event.rakuten.co.jp/campaign/card/pointday/?scid=corp_5bai_sp)
    
*   [![スポーツくじ1等最高12億円！楽天カードなら簡単利用登録！](https://image.card.jp.rakuten-static.com/card_corp/smart/contents/banner/220425_toto_240x240.png)](https://toto.rakuten.co.jp/big/mega/?tsi=10100)
    

楽天グループサービス

*   [![](https://image.card.jp.rakuten-static.com/card_corp/smart/common/footer/icon_rbank.svg)楽天銀行](https://www.rakuten-bank.co.jp/?scid=wi_rkc_oneapp_card_sp)
    
*   [![](https://image.card.jp.rakuten-static.com/card_corp/smart/common/footer/icon_rpay.svg)楽天ペイ](https://pay.rakuten.co.jp/detail/?scid=wi_rkc_sp_footer_rglink)
    
*   [![](https://image.card.jp.rakuten-static.com/card_corp/smart/common/footer/icon_redy.svg)楽天Edy](https://edy.rakuten.co.jp/?scid=wi_edy_oneapp_ich_sp_grp)
    
*   [![](https://image.card.jp.rakuten-static.com/card_corp/smart/common/footer/icon_richiba.svg)楽天市場](https://www.rakuten.co.jp/?scid=wi_rkc_oneapp_ich_sp_grp)
    
*   [![](https://image.card.jp.rakuten-static.com/card_corp/smart/common/footer/icon_rmobile.svg)楽天モバイル](https://ac.ebis.ne.jp/tr_set.php?argument=ZMhPE4GP&ai=rgp_mno_002952)
    
*   [![](https://image.card.jp.rakuten-static.com/card_corp/smart/common/footer/icon_rsec.svg)楽天証券](https://r10.to/ha0Xae)
    

*   [企業情報](https://www.rakuten-card.co.jp/corporate/?l-id=corp_de_sp_footer_0003)
    
*   [プレスリリース](https://www.rakuten-card.co.jp/corporate/press_release/?l-id=corp_de_sp_footer_0006)
    
*   [会員規約](https://www.rakuten-card.co.jp/agreement/?l-id=corp_de_sp_footer_0005)
    
*   [セキュリティ](https://www.rakuten-card.co.jp/security/?l-id=corp_de_sp_footer_0013_secu)
    
*   [サイトマップ](https://www.rakuten-card.co.jp/sitemap/?l-id=corp_de_sp_footer_0012)
    
*   [日本クレジット協会](http://www.j-credit.or.jp/)
    
*   [お客様サポート](https://www.rakuten-card.co.jp/support/?l-id=corp_de_sp_footer_0001_support)
    
*   [紛失・盗難・拾得](https://www.rakuten-card.co.jp/contact/robbery/?l-id=corp_de_sp_footer_0002)
    

サイトについて

*   [サイトのご利用案内](https://www.rakuten-card.co.jp/info/rules/site/?l-id=corp_de_sp_footer_0008)
    
*   [免責事項](https://www.rakuten-card.co.jp/info/rules/menseki/?l-id=corp_de_sp_footer_0010)
    

方針・規程等

*   [個人情報保護方針](https://www.rakuten-card.co.jp/personal/statement/?l-id=corp_de_sp_footer_0004)
    
*   [クレジットポリシー](https://www.rakuten-card.co.jp/info/rules/credit_policy/?l-id=corp_de_sp_footer_0007)
    
*   [お客様応対基本方針](https://www.rakuten-card.co.jp/info/rules/customer_policy/)
    
*   [反社会的勢力に対する基本方針](https://www.rakuten-card.co.jp/info/rules/antisocialforces/?l-id=corp_de_sp_footer_0011)
    
*   [マネー・ローンダリングおよびテロ資金供与対策、拡散金融対策に関する取り組み](https://www.rakuten-card.co.jp/info/rules/maneron/?l-id=corp_de_sp_footer_0014_maneron)
    

*   [サステナビリティ](https://www.rakuten-card.co.jp/corporate/sustainability/)
    
*   [採用情報](https://www.rakuten-card.co.jp/corporate/career/?l-id=corp_de_sp_footer_0015_career)
    
*   [弊社会員様の代理人の方へ](https://www.rakuten-card.co.jp/info/junin-uketsuke/)
    

© Rakuten Card Co., Ltd.

楽天グループ

[アプリ一覧](https://www.rakuten.co.jp/sitemap/sp/app.html)

[お問い合わせ一覧](https://www.rakuten.co.jp/sitemap/sp/inquiry.html)
