# 【公式】dポイントクラブ［dポイントカード］| NTTドコモ

URL: https://dpoint.docomo.ne.jp/

---

[![d POINT CLUB](https://dpoint.docomo.ne.jp/common/img/logo_red.png)](https://dpoint.docomo.ne.jp/index.html)

[![](https://dpoint.docomo.ne.jp/common/img/icon/hdr_entry.png)\
\
dポイント  \
カード](https://dpoint.onelink.me/roGT?af_xp=custom&pid=dpointcard&af_dp=dpoint%3A%2F%2Ftop&af_ios_url=https%3A%2F%2Fdpoint.docomo.ne.jp%2Fguide%2Fabout_dpointcard%2Fapp_mobile%2Findex.html&af_android_url=https%3A%2F%2Fdpoint.docomo.ne.jp%2Fguide%2Fabout_dpointcard%2Fapp_mobile%2Findex.html&af_web_dp=https%3A%2F%2Fdpoint.docomo.ne.jp%2Fguide%2Fabout_dpointcard%2Fapp_mobile%2Findex.html)

[![dアカウントでログイン](https://dpoint.docomo.ne.jp/common/img/hdr_login_button.png)](https://cfg.smt.docomo.ne.jp/auth/cgi/anidlogin?rl=https%3A%2F%2Fdpoint%2edocomo%2ene%2ejp%2F)

[![dポイント](https://dpoint.docomo.ne.jp/common/img/icon/icon_dlogo.png)\
\
最大％還元\
\
登録で最大％](https://dpoint.docomo.ne.jp/member/point_info/index.html)

[![dポイント](https://dpoint.docomo.ne.jp/common/img/icon/icon_dlogo.png)\
\
\*\*\*\*P\
\
ポイント\*\*\*倍](https://dpoint.docomo.ne.jp/index.html)

[![dポイント](https://dpoint.docomo.ne.jp/common/img/icon/icon_dlogo.png)\
\
\---P\
\
最大\--%還元](https://dpoint.docomo.ne.jp/index.html)

*   [ホーム](https://dpoint.docomo.ne.jp/index.html)
    
*   [ためる](https://dpoint.docomo.ne.jp/acc.html)
    
*   [お店](https://dpoint.docomo.ne.jp/store/index.html)
    
*   [つかう](https://dpoint.docomo.ne.jp/use.html)
    
*   [クーポン](https://dpoint.docomo.ne.jp/coupon.html)
    

[令和7年11月大分県大規模火災支援募金](https://dpoint.docomo.ne.jp/use/charity/index.html)

Previous

*   [![camp_税抜5,000円以上購入した方で50万pt山分け！](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/251205_834333_830739.jpg)](https://dmarket.docomo.ne.jp/campaign/blackfriday2025/?utm_source=dpointclub&utm_medium=free-display&utm_campaign=dpm_202511_cam_0004048)
    
*   [![camp_d払いご利用でdポイント最大20倍！](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/251230_834978_834265.png)](https://service.smt.docomo.ne.jp/keitai_payment/campaign/dpay_mcdonalds_251203_6941/index.html?utm_source=dpointclub&utm_medium=free-display&utm_campaign=dpayment_mcd_202512&utm_content=dpc_cpn)
    
*   [![LAND_1日1回！最大100pt当たるチャンス！](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/251215_834751_832564.jpg)](https://dmarket.docomo.ne.jp/kuji/?utm_source=dpointclub&utm_medium=free-display&utm_campaign=dpm_202512_kuj_0003192)
    
*   [![camp_【増額中】スタンプをためてポイントGET](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/251231_834627_830098.png)](https://dpoint.docomo.ne.jp/cp_3/stamp_payment_promotion/index.html?utm_source=dpointclub&utm_medium=free-display&utm_campaign=dpc_202403_kessaistamp-dpointclubsite-1)
    
*   [![land_ダブルで当たるチャンス！さっそく運試し★](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_671478_763681.jpg)](https://hiroba.dpoint.docomo.ne.jp/kuji/daily?utm_source=dpointclub&utm_medium=referral&utm_campaign=everyday&utm_content=dpc_referral_cpn_everyday&mks_referer_event=dpc_referral_cpn_everyday)
    
*   [![LAND_毎日くじ​](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_742689_819449.png)](https://service.smt.docomo.ne.jp/portal/special/collab/topics/src/dmenukuji_01.html?utm_source=dpointclub&utm_medium=free-display&utm_campaign=dpc_site_2410_new_user)
    
*   [![dポイント10周年施策第3弾](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/251231_832887_832888.png)](https://dpoint.docomo.ne.jp/cp_7/list_251117_6845/index.html?utm_source=dpointclub&utm_medium=other&utm_campaign=dpc_202511_6845&utm_content=brand-panel)
    
*   [![全額還元CP](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/251231_833696_833697.png)](https://service.smt.docomo.ne.jp/keitai_payment/campaign/zengakucp202512/index.html?utm_source=dpointclub&utm_medium=free-display&utm_campaign=dpayment_202512_zengakucp-dpointclubsite-1)
    
*   [![camp_税抜5,000円以上購入した方で50万pt山分け！](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/251205_834333_830739.jpg)](https://dmarket.docomo.ne.jp/campaign/blackfriday2025/?utm_source=dpointclub&utm_medium=free-display&utm_campaign=dpm_202511_cam_0004048)
    
*   [![camp_d払いご利用でdポイント最大20倍！](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/251230_834978_834265.png)](https://service.smt.docomo.ne.jp/keitai_payment/campaign/dpay_mcdonalds_251203_6941/index.html?utm_source=dpointclub&utm_medium=free-display&utm_campaign=dpayment_mcd_202512&utm_content=dpc_cpn)
    
*   [![LAND_1日1回！最大100pt当たるチャンス！](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/251215_834751_832564.jpg)](https://dmarket.docomo.ne.jp/kuji/?utm_source=dpointclub&utm_medium=free-display&utm_campaign=dpm_202512_kuj_0003192)
    
*   [![camp_【増額中】スタンプをためてポイントGET](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/251231_834627_830098.png)](https://dpoint.docomo.ne.jp/cp_3/stamp_payment_promotion/index.html?utm_source=dpointclub&utm_medium=free-display&utm_campaign=dpc_202403_kessaistamp-dpointclubsite-1)
    
*   [![land_ダブルで当たるチャンス！さっそく運試し★](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_671478_763681.jpg)](https://hiroba.dpoint.docomo.ne.jp/kuji/daily?utm_source=dpointclub&utm_medium=referral&utm_campaign=everyday&utm_content=dpc_referral_cpn_everyday&mks_referer_event=dpc_referral_cpn_everyday)
    
*   [![LAND_毎日くじ​](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_742689_819449.png)](https://service.smt.docomo.ne.jp/portal/special/collab/topics/src/dmenukuji_01.html?utm_source=dpointclub&utm_medium=free-display&utm_campaign=dpc_site_2410_new_user)
    
*   [![dポイント10周年施策第3弾](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/251231_832887_832888.png)](https://dpoint.docomo.ne.jp/cp_7/list_251117_6845/index.html?utm_source=dpointclub&utm_medium=other&utm_campaign=dpc_202511_6845&utm_content=brand-panel)
    
*   [![全額還元CP](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/251231_833696_833697.png)](https://service.smt.docomo.ne.jp/keitai_payment/campaign/zengakucp202512/index.html?utm_source=dpointclub&utm_medium=free-display&utm_campaign=dpayment_202512_zengakucp-dpointclubsite-1)
    
*   [![camp_税抜5,000円以上購入した方で50万pt山分け！](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/251205_834333_830739.jpg)](https://dmarket.docomo.ne.jp/campaign/blackfriday2025/?utm_source=dpointclub&utm_medium=free-display&utm_campaign=dpm_202511_cam_0004048)
    
*   [![camp_d払いご利用でdポイント最大20倍！](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/251230_834978_834265.png)](https://service.smt.docomo.ne.jp/keitai_payment/campaign/dpay_mcdonalds_251203_6941/index.html?utm_source=dpointclub&utm_medium=free-display&utm_campaign=dpayment_mcd_202512&utm_content=dpc_cpn)
    

Next

  ![一時停止](https://dpoint.docomo.ne.jp/common/img/icon/icon_slider_pause.png)  ![再生](https://dpoint.docomo.ne.jp/common/img/icon/icon_slider_start.png)

＼ ログインしてポイント・ランクを確認する ／

[dアカウントでログイン](https://cfg.smt.docomo.ne.jp/auth/cgi/anidlogin?rl=https%3A%2F%2Fdpoint%2edocomo%2ene%2ejp%2F%3Fdpc_home_adflg%3Dfalse)

[dアカウントの新規登録はこちら](https://id.smt.docomo.ne.jp/cgi8/id/tpl/REG101?serviceurl=https%3A%2F%2Fdpoint.docomo.ne.jp%2Findex.html&servicereferer=https%3A%2F%2Fdpoint%2edocomo%2ene%2ejp%2F)

[dポイントカードの利用者情報登録はこちら](https://dpoint.docomo.ne.jp/ctrw/register/s-001.html)

ポイント非表示設定中です

*   [![毎日くじ](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_493458_828328.png)](https://service.smt.docomo.ne.jp/portal/special/collab/topics/src/dmenukuji_01.html?utm_source=dpointclub&utm_medium=owned&utm_campaign=dpc_202105_owned-dpc-top-fixedicon-01)
    
*   [![ミッション](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_493526_813269.png)](https://dpoint.onelink.me/roGT?af_ios_url=https%3A%2F%2Fdpoint.docomo.ne.jp%2Fdpc%2Fmisstion_lp%2Findex.html&af_android_url=https%3A%2F%2Fdpoint.docomo.ne.jp%2Fdpc%2Fmisstion_lp%2Findex.html&af_web_dp=https%3A%2F%2Fdpoint.docomo.ne.jp%2Fdpc%2Fmisstion_lp%2Findex.html&af_xp=custom&pid=mission&af_dp=dpoint%3A%2F%2Fnormal_mission_list)
    
*   [![動画でためる](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_493487_812818.png)](https://dpoint.onelink.me/roGT?af_ios_url=https%3A%2F%2Fdpoint.docomo.ne.jp%2Fguide%2Fhowto_dpoint%2Fapp%2Fmovie_mission%2Findex.html&af_android_url=https%3A%2F%2Fdpoint.docomo.ne.jp%2Fguide%2Fhowto_dpoint%2Fapp%2Fmovie_mission%2Findex.html&af_web_dp=https%3A%2F%2Fdpoint.docomo.ne.jp%2Fguide%2Fhowto_dpoint%2Fapp%2Fmovie_mission%2Findex.html&af_xp=custom&pid=daily_movie&af_dp=dpoint%3A%2F%2Fdaily_movie)
    
*   [![アンケート](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_493506_825966.png)](https://dpcq.macaron.docomo.ne.jp/?utm_source=dpointclub&utm_medium=owned&utm_campaign=dpc_202212_home)
    
*   [![遊んでためる](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_493495_822642.png)](https://dpoint.docomo.ne.jp/content/land/index.html)
    
*   [![dﾎﾟｲﾝﾄｽﾀﾝﾌﾟ](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_576137_778413.png)](https://dpoint.docomo.ne.jp/guide/howto_dpoint/app/shopping_stamp/index.html?af_xp=custom&pid=shopping_stamp)
    
*   [![d払いdｶｰﾄﾞｽﾀﾝﾌﾟ](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_697105_832145.png)](https://dpoint.docomo.ne.jp/stamp/payment/index.html?utm_source=dpointclub&utm_medium=free-display&utm_campaign=dpc_202403_kessaistamp-dpointclub-sitetop-shortcuticon)
    
*   [![くじ・プレゼント](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_748936_823667.png)](https://dmarket.docomo.ne.jp/kuji/?utm_source=dpointclub&utm_medium=owned&utm_campaign=dpm_202412_kuj_0002809)
    
*   [![dポイント運用](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_493520_831192.png)](https://dpoint-inv.smt.docomo.ne.jp/portal/top?from=dpointclub_app&utm_source=dpointclub_site_icon&utm_medium=owned&utm_campaign=pi_dpointclub-site-icon_nm_shortcut_202308089_07)
    
*   [![Amazon](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_716273_834298.png)](https://www.amazon.co.jp/dp/B0CRDKH9M9?ref_=jp_d_dcm_enrl_dpc_icon_0602)
    
*   [![スキマ時間でためる](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_596949_739680.png)](https://sw.djob.docomo.ne.jp/lp?utm_source=dpointclub&utm_medium=free-display&utm_campaign=djob_sukimajikan_site&utm_content=txt&ch_param=free-display_dpointclub_djob_sukimajikan_site)
    
*   [![毎週抽選/プレゼント](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_533824_836530.png)](https://dpoint.docomo.ne.jp/content/present_3ple/index.html)
    
*   [![ポイント広場](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_570852_572437.png)](https://hiroba.dpoint.docomo.ne.jp/?utm_source=dpointclub&utm_medium=referral&utm_campaign=hiroba&utm_content=dpc_referral_shortcut_hiroba&mks_referer_event=dpc_referral_shortcut_hiroba)
    
*   [![ﾎﾟｲﾝﾄを送る](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_797800_797802.png)](https://dpoint.docomo.ne.jp/use/transfer/index.html)
    
*   [![もっとみる](https://dpoint.docomo.ne.jp/img/shortcut_icon/ico_more.png)](https://dpoint.docomo.ne.jp/guide/service_category/index.html)
    

*   [![毎日くじ](https://dpoint.docomo.ne.jp/img/shortcut_icon/ico_mainichi_kuji.png)](https://service.smt.docomo.ne.jp/portal/special/collab/topics/src/dmenukuji_01.html?utm_source=dpointclub&utm_medium=owned&utm_campaign=dpc_202105_owned-dpc-top-fixedicon-01)
    
*   [![アンケート](https://dpoint.docomo.ne.jp/img/shortcut_icon/ico_survey.png)](https://dpcq.macaron.docomo.ne.jp/?utm_source=dpointclub&utm_medium=owned&utm_campaign=dpc_202212_home)
    
*   [![キャンペーン](https://dpoint.docomo.ne.jp/img/shortcut_icon/ico_campaign.png)](https://dpoint.docomo.ne.jp/campaign/)
    
*   [![遊んでためる](https://dpoint.docomo.ne.jp/img/shortcut_icon/ico_game.png)](https://dpoint.docomo.ne.jp/content/land/index.html)
    
*   [![カード登録](https://dpoint.docomo.ne.jp/img/shortcut_icon/icon_card_l.png)](https://dpoint.docomo.ne.jp/ctrw/register/s-001.html)
    [![ミッション](https://dpoint.docomo.ne.jp/img/shortcut_icon/ico_mission.png)](https://dpoint.onelink.me/roGT?af_ios_url=https%3A%2F%2Fdpoint.docomo.ne.jp%2Fdpc%2Fmisstion_lp%2Findex.html&af_android_url=https%3A%2F%2Fdpoint.docomo.ne.jp%2Fdpc%2Fmisstion_lp%2Findex.html&af_web_dp=https%3A%2F%2Fdpoint.docomo.ne.jp%2Fdpc%2Fmisstion_lp%2Findex.html&af_xp=custom&pid=mission&af_dp=dpoint%3A%2F%2Fnormal_mission_list)
    
*   [![毎週当たる](https://dpoint.docomo.ne.jp/img/shortcut_icon/ico_3ple.png)](https://dpoint.docomo.ne.jp/content/present_3ple/index.html)
    
*   [![ポイント履歴](https://dpoint.docomo.ne.jp/img/shortcut_icon/ico_point_history.png)](https://dpoint.docomo.ne.jp/member/point_history/index.html)
    
*   [![料金に充当](https://dpoint.docomo.ne.jp/img/shortcut_icon/ico_payment.png)](https://dpoint.docomo.ne.jp/use/payment/index.html)
    
*   [![dポイント運用](https://dpoint.docomo.ne.jp/img/shortcut_icon/ico_investment.png)](https://dpoint-inv.smt.docomo.ne.jp/portal/top?from=dpointclub_app&utm_source=dpointclub_site_icon&utm_medium=owned&utm_campaign=pi_dpointclub-site-icon_nm_shortcut_202308089_07)
    
*   [![すべて](https://dpoint.docomo.ne.jp/img/shortcut_icon/ico_more.png)](https://dpoint.docomo.ne.jp/guide/service_category/index.html)
    

現在あなたは1つ星

[ランク詳細を見る](https://dpoint.docomo.ne.jp/)

*   [2つ星特典 ①\
    \
    ![dポイントカード](https://dpoint.docomo.ne.jp/common/img/contents_icon_color/ico_dpointcard.png)\
    \
    dポイントカード](https://dpoint.docomo.ne.jp/member/stage_info/index.html#next_rank_check)
    
*   [2つ星特典 ②\
    \
    ![dポイントマーケット](https://dpoint.docomo.ne.jp/common/img/contents_icon_color/ico_dpointmarket.png)\
    \
    dポイントマーケット\
    \
    0.75％還元](https://dpoint.docomo.ne.jp/member/stage_info/index.html#next_rank_check)
    

※dポイントマーケットはベースポイントを含む還元率です。

*   [![dポイントカード](https://dpoint.docomo.ne.jp/common/img/contents_icon_color/ico_dpointcard.png)\
    \
    dポイント  \
    カード\
    \
    ポイント倍](https://dpoint.docomo.ne.jp/)
    
*   [![d払い](https://dpoint.docomo.ne.jp/common/img/contents_icon_color/ico_dpay.png)\
    \
    d払い\
    \
    最大％還元](https://dpoint.docomo.ne.jp/)
    
*   [![dポイントマーケット](https://dpoint.docomo.ne.jp/common/img/contents_icon_color/ico_dpointmarket.png)\
    \
    dポイント  \
    マーケット\
    \
    ％還元](https://dpoint.docomo.ne.jp/)
    
*   [![料金充当](https://dpoint.docomo.ne.jp/common/img/contents_icon_color/ico_payment.png)\
    \
    ｹｰﾀｲ料金に  \
    つかう\
    \
    追加充当%](https://dpoint.docomo.ne.jp/)
    

※d払いの特典には適用条件があります。またd払いの特典はdカードご契約状況で還元率が異なります。

遊んでためる
------

[さらに見る](https://dpoint.docomo.ne.jp/content/land/index.html)

*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_399741_821420.png)\
    \
    クイズに答えてdポイントをゲットしよう★\
    \
    ![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_399096_399098.png)](https://game.hiroba.dpoint.docomo.ne.jp/quiz?utm_source=dpointclub&utm_medium=referral&utm_campaign=quiz&utm_content=dpc_referral_cb_quiz&mks_referer_event=dpc_referral_cb_quiz)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/251215_832563_832565.jpg)\
    \
    1日1回！最大100pt当たるチャンス！\
    \
    ![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_324759_728816.png)](https://dmarket.docomo.ne.jp/kuji/?utm_source=dpointclub&utm_medium=free-display&utm_campaign=dpm_202512_kuj_0003192)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/260331_795741_794483.png)\
    \
    ミッションクリアでポイント当たる！\
    \
    ![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_116613_123056.png)](https://dpoint.docomo.ne.jp/cp_7/dpc_lp_rdt_common/index.html?utm_source=dpointclub&utm_medium=owned&utm_campaign=dpc_202506_1111&utm_content=web&redirectID=https%3A%2F%2Fhousequestworld.spexperts.jp%2F)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_827872_819450.png)\
    \
    最大1,000pt当たる毎日くじ開催中！\
    \
    ![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_116613_123056.png)](https://service.smt.docomo.ne.jp/portal/special/collab/topics/src/dmenukuji_01.html?utm_source=dpointclub&utm_medium=free-display&utm_campaign=dpc_site_land_banner)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_399769_399750.png)\
    \
    ミッションクリアで毎日ポイントGET！\
    \
    ![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_399096_399098.png)](https://game.hiroba.dpoint.docomo.ne.jp/easygame?utm_source=dpointclub&utm_medium=referral&utm_campaign=adgame&utm_content=dpc_referral_cb_adgame&mks_referer_event=dpc_referral_cb_adgame)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_774971_774974.png)\
    \
    遊んでdポイントをためよう！\
    \
    ![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_399096_399098.png)](https://game.hiroba.dpoint.docomo.ne.jp/easygame/ranking/409?utm_source=dpointclub&utm_medium=referral&utm_campaign=adgame&utm_content=dpc_referral_cb_adgame_409&mks_referer_event=dpc_referral_cb_adgame_409)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/251225_833732_833737.jpg)\
    \
    ゲームでdポイントをためよう♪\
    \
    ![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_399096_399098.png)](https://game.hiroba.dpoint.docomo.ne.jp/easygame/ranking/461?utm_source=dpointclub&utm_medium=referral&utm_campaign=adgame&utm_content=dpc_referral_cb_adgame_461&mks_referer_event=dpc_referral_cb_adgame_461)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/251231_815325_832955.png)\
    \
    毎日最大1,000ptゲットのチャンス！\
    \
    ![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_709775_709880.png)](https://dmarket.docomo.ne.jp/kuji/go_to_kuji_page.html?id=1tXEeU77&utm_source=smartnews&utm_medium=free-display&utm_campaign=dpm_202505_kuj_0003047)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/251231_831213_834389.png)\
    \
    最大1,000pt当たる！クイズに挑戦\
    \
    ![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_116613_123056.png)](https://money.smt.docomo.ne.jp/contents/kabukaquiz_12?utm_source=dpointclub&utm_medium=landpointget&utm_campaign=stock-quiz)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_738069_738071.jpg)\
    \
    最大10,000pt！無料でチャレンジ\
    \
    ![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_559552_562903.png)](https://dmarket.docomo.ne.jp/kuji/go_to_kuji_page.html?id=abAvv4wA&utm_source=sportskuji&utm_medium=free-display&utm_campaign=dpm_202410_kuj_0002504)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/251231_802941_800335.png)\
    \
    カンタン2ステップでポイントがあたる！\
    \
    ![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_116613_123056.png)](https://dpoint.docomo.ne.jp/cp_6/mustbuy/messagebox_dpoint_250801_MI0098/index.html?utm_source=dpointclub&utm_medium=free-display&utm_campaign=uiux_messagebox)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_399738_399740.png)\
    \
    毎月挑戦☆1等30,000pt当たる！\
    \
    ![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_399096_399098.png)](https://hiroba.dpoint.docomo.ne.jp/kuji/garagara?utm_source=dpointclub&utm_medium=referral&utm_campaign=garagara&utm_content=dpc_referral_cb_garagara&mks_referer_event=dpc_referral_cb_garagara)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/251231_832664_832666.png)\
    \
    【dポイント100万pt分】山分け！\
    \
    ![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_399096_399098.png)](https://gd.gesoten.com/m/ap-hiroba/campaign/detail/202512_kyoryu?utm_source=dpointclub&utm_medium=referral&utm_campaign=gesoten&utm_content=dpc_referral_cb_gesoten_202512_kyoryu&mks_referer_event=dpc_referral_cb_gesoten_202512_kyoryu&utm_geso=dpoint_banner_202512_kyoryu)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_399723_763682.jpg)\
    \
    ダブルで当たるチャンス！さっそく運試し★\
    \
    ![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_399096_399098.png)](https://hiroba.dpoint.docomo.ne.jp/kuji/daily?utm_source=dpointclub&utm_medium=referral&utm_campaign=everyday&utm_content=dpc_referral_cb_everyday&mks_referer_event=dpc_referral_cb_everyday)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_401464_640848.png)\
    \
    最大100P当たる！1日1回くじ\
    \
    ![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_49177_49710.png)](https://dmarket.docomo.ne.jp/kuji/go_to_kuji_page.html?id=1cpxtacB&utm_source=dpointclub&utm_medium=free-display&utm_campaign=dpm_202410_kuj_0002666)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/251216_831545_823114.png)\
    \
    毎日開催｜正解するまで何度も挑戦できる♪\
    \
    ![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_116613_123056.png)](https://money.smt.docomo.ne.jp/quiz/money-quiz?utm_source=dpointclub&utm_medium=landpointget&utm_campaign=money_quiz)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/251231_832680_832682.png)\
    \
    翔んで埼玉～世界埼玉化計画～\
    \
    ![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_399096_399098.png)](https://gd.gesoten.com/m/ap-hiroba/campaign/detail/202512_saitama?utm_source=dpointclub&utm_medium=referral&utm_campaign=gesoten&utm_content=dpc_referral_cb_gesoten_202512_saitama&mks_referer_event=dpc_referral_cb_gesoten_202512_saitama&utm_geso=dpoint_banner_202512_saitama)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/260331_781775_781783.png)\
    \
    読んでクリック！最大2,000pt進呈\
    \
    ![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_116613_123056.png)](https://dpoint.docomo.ne.jp/cp_6/mustbuy/tokusuru_dpoint_250501_MI0082/index.html?utm_source=dpointclub&utm_medium=pointget&utm_campaign=uiux_MI)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_561579_564473.png)\
    \
    今日の運勢No.1星座は？\
    \
    ![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_399096_399098.png)](https://hiroba.dpoint.docomo.ne.jp/fortune?utm_source=dpointclub&utm_medium=referral&utm_campaign=fortune&utm_content=dpc_referral_cb_fortune&mks_referer_event=dpc_referral_cb_fortune)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_401458_640855.png)\
    \
    最大100P当たる！1日1回くじ\
    \
    ![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_12873_13680.png)](https://dmarket.docomo.ne.jp/kuji/go_to_kuji_page.html?id=6DznlB6Z&utm_source=dpointclub&utm_medium=free-display&utm_campaign=dpm_202410_kuj_0002667)
    

キャンペーン
------

[さらに見る](https://dpoint.docomo.ne.jp/campaign/)

*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/251205_834356_774901.png)\
    \
    dショッピング\
    \
    毎月5のつく日はdポイント最大20倍！\
    \
    2025/12/05まで\
    \
    要エントリー](https://dshopping.docomo.ne.jp/campaign/cp202200500/?utm_source=dpointclub&utm_medium=free-display&utm_campaign=dshopping_20251205_dcardday_dpccp)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/260331_829219_829240.png)\
    \
    d払い\
    \
    最大全額還元当たる！今すぐエントリー\
    \
    2026/03/31まで\
    \
    要エントリー](https://service.smt.docomo.ne.jp/keitai_payment/campaign/zengakucp202512/index.html?utm_source=dpointclub&utm_medium=free-display&utm_campaign=dpayment_202512_zengakucp-dpointclubsite-1)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/260331_832272_832284.png)\
    \
    d払い\
    \
    d払い決済ご利用でdポイント10％還元！\
    \
    2025/12/31まで\
    \
    要エントリー](https://service.smt.docomo.ne.jp/keitai_payment/campaign/dpay_heiando_251205_6912/?utm_source=dpointclub&utm_medium=owned&utm_campaign=dpc_202512_6912)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/251209_832360_799886.png)\
    \
    【爆アゲ】Spotify Premium\
    \
    ドコモからお申込みで毎月dポイント25％還元！\
    \
    常時開催\
    \
    エントリー不要](https://ssw.web.docomo.ne.jp/bakuage/spotifypremium/?utm_source=dpointclub&utm_medium=free-display&utm_campaign=bakuage_202506_spt_0000129)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/260206_833670_834800.png)\
    \
    dポイントクラブ\
    \
    最大15,000pt当たる！ドコモでんき抽選キャンペーン♪\
    \
    2026/01/06まで\
    \
    要エントリー](https://denki.docomo.ne.jp/pages/202510-15000cp/?utm_source=dpointclub&utm_medium=owned&utm_campaign=202512_833670_denki_15%2C000ptcp&utm_content=denki-0694)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/260331_832432_832440.png)\
    \
    サンリブ\
    \
    dポイントカード提示＆d払いでのお支払いで当たるチャンス！\
    \
    2025/12/31まで\
    \
    要エントリー](https://dpoint.docomo.ne.jp/cp_7/sunlive_251201_6904/index.html?utm_source=dpointclub&utm_medium=owned&utm_campaign=dpc_202512_6904)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/260330_829977_829981.png)\
    \
    やよい軒\
    \
    d払いを利用して最大1万ポイント当てよう！\
    \
    2025/12/30まで\
    \
    要エントリー](https://dpoint.docomo.ne.jp/cp_7/yayoiken_251201_6894/index.html?utm_source=dpointclub&utm_medium=owned&utm_campaign=dpc_202512_6894)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/260331_831289_807250.png)\
    \
    エディオン\
    \
    エディオンアプリ会員新規登録とお買物でもれなくプレゼント！\
    \
    2025/12/31まで\
    \
    要エントリー](https://dpoint.docomo.ne.jp/cp_7/edion_251201_6251/index.html?utm_source=dpointclub&utm_medium=owned&utm_campaign=dpc_202512_6251)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/260331_830325_830331.png)\
    \
    ホームセンタータイム\
    \
    d払いで歳末ダブル抽選！おトクなチャンス♪\
    \
    2025/12/31まで\
    \
    エントリー不要](https://dpoint.docomo.ne.jp/cp_2/section/poincosquare/time_dpaycp_2512/index.html?utm_source=dpointclub&utm_medium=owned&utm_campaign=dpc_202512_6892)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/260131_833957_833963.jpg)\
    \
    高島屋、高島屋日本橋店、高島屋新宿店、高島屋玉川店、高島屋横浜店、高島屋大宮店、高島屋柏店、高島屋高崎店、高島屋大阪店、高島屋堺店\
    \
    高島屋×dカード 年末年始dポイント大抽選会\
    \
    2026/01/31まで\
    \
    要エントリー](https://dcard.docomo.ne.jp/std/campaigns/202512_rs/cpn-takashimaya/index.html?utm_source=dpointclub&utm_medium=owned&utm_campaign=202512_833957_rs_202512_cpn-takashimaya)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/260131_831258_831263.jpg)\
    \
    kikito\
    \
    dポイント還元 Wチャンスキャンペーン！\
    \
    2026/01/31まで\
    \
    要エントリー](https://rental.kikito.docomo.ne.jp/portal/promotions/12996/?utm_source=dpointclub&utm_medium=owned&utm_campaign=202512_831258_kikito_2512_dpointCP-dpc)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/251231_815270_822599.jpg)\
    \
    ドコモスポーツくじ\
    \
    最高1万pt当たるチャンス！\
    \
    常時開催\
    \
    要エントリー](https://toto.docomo.ne.jp/contents_lp/docomomaxcampaign/index.html?utm_source=dpointclub&utm_medium=owned&utm_campaign=member_register-20251201-cpd0322-dpc0001-notuse)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/251224_828088_830735.jpg)\
    \
    dマガジン\
    \
    100ポイントプレゼント☆スゴ得ご契約者さま\
    \
    2025/12/25まで\
    \
    要エントリー](https://dmagazine.docomo.ne.jp/campaign/detail/sugotoku-202511/?utm_source=dpointclub&utm_medium=free-display&utm_campaign=dmagazine_202511_1-dpcscpb-sugotokucollabo)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/260127_831566_831572.jpg)\
    \
    コスモ石油\
    \
    コスモMyカーリースの新規契約でdポイント2万ポイント進呈！\
    \
    2026/01/31まで\
    \
    エントリー不要](https://dpoint.docomo.ne.jp/cp_7/dpc_lp_rdt_common/index.html?utm_source=dpointclub&utm_medium=owned&utm_campaign=dpc_202512_7017&redirectID=https%3A%2F%2Fwww.cosmo-mycar.com%2Fdpoint-campaign%2F)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/260131_832891_832893.jpg)\
    \
    dヒッツ\
    \
    【dヒッツ】冬の入会キャンペーン\
    \
    2026/01/31まで\
    \
    要エントリー](https://dhits.docomo.ne.jp/ft/sys00483?utm_source=dpointclub&utm_medium=owned&utm_campaign=202512_832891_dhits_202512_w_pt_cp_1)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/251225_833018_833025.jpg)\
    \
    dブック\
    \
    5のつく日はdカード支払いのご購入がdポイント5倍！\
    \
    定期開催\
    \
    要エントリー](https://dbook.docomo.ne.jp/campaign/detail/dcardcp/?utm_source=dpointclub&utm_medium=free-display&utm_campaign=dbook_202512_dptccp1-2&utm_content=dcp_non_non_non_02)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/260523_830444_830446.jpg)\
    \
    ジョリーロジャー、零星のレディオドラグーン\
    \
    新規プレイヤー限定｜もれなく貰える！条件達成でポイントGET\
    \
    2026/03/31まで\
    \
    エントリー不要](https://dpoint.docomo.ne.jp/cp_7/dpc_lp_rdt_common/index.html?utm_source=dpointclub&utm_medium=owned&utm_campaign=dpc_202512_6903&redirectID=https%3A%2F%2Fplatform.razest.net%2Flp%2F20250515%2F)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/260331_832273_832276.png)\
    \
    ローソン、ローソンストア100\
    \
    抽選でdポイント最大888倍あたる！\
    \
    2025/12/31まで\
    \
    要エントリー](https://dpoint.docomo.ne.jp/cp_7/lawson_251101_6839/index.html?utm_source=dpointclub&utm_medium=owned&utm_campaign=dpc_202512_6840)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/260331_832468_832471.png)\
    \
    新潟らーめん 無尽蔵、喜多方ラーメン 大安食堂、五頭の山茂登、ブーランジェリー リリッカ、らーめん風伯\
    \
    抽選で最大5,000ポイントがあたる！\
    \
    2025/12/31まで\
    \
    要エントリー](https://dpoint.docomo.ne.jp/branch/kse/kitakata_251201_6915/index.html?utm_source=dpointclub&utm_medium=owned&utm_campaign=dpc_202512_6915)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/260331_830833_798638.png)\
    \
    dスマホローン\
    \
    dスマホローン契約でポイントプレゼント\
    \
    常時開催\
    \
    要エントリー](https://loan.docomo.ne.jp/campaign/202211_point02/?utm_source=dpointclub&utm_medium=owned&utm_campaign=DSL221102_reg_20241125)
    

活用ヒント
-----

[さらに見る](https://dpoint.docomo.ne.jp/article/index.html)

*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_346684_346677.jpg)\
    \
    ミスタードーナツでおトクにドーナツ\
    \
    ![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_263292_264463.png)](https://dpoint.docomo.ne.jp/content/feature/store/good_deal/misterdonut.html)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_632974_828186.png)\
    \
    つかわないともったいない！\
    \
    ![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_116613_123056.png)](https://dpoint.docomo.ne.jp/content/feature/point_realstore.html)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_651351_651657.png)\
    \
    dポイントをつかうなら！家族とおトクにはま寿司\
    \
    ![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_152679_436236.png)](https://dpoint.docomo.ne.jp/content/feature/store/hamazushi.html)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_648921_830822.png)\
    \
    必見！街のお店でのお買物ならこのため方がおトク！\
    \
    ![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_116613_123056.png)](https://dpoint.docomo.ne.jp/content/good_deal/index.html)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_409014_574334.jpg)\
    \
    dポイントがたまる・つかえる！お店特集\
    \
    ![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_116613_123056.png)](https://dpoint.docomo.ne.jp/dpc/carlife_article/index.html)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_622037_622039.png)\
    \
    秒でわかる！dポイントのため方・つかい方！\
    \
    ![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_116613_123056.png)](https://dpoint.docomo.ne.jp/article/pat_spat/index.html)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_622043_622248.png)\
    \
    楽しみながらdポイントをためよう！\
    \
    ![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_116613_123056.png)](https://dpoint.docomo.ne.jp/dpc/acclp_01/index.html)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_622055_622056.png)\
    \
    STEP2　dポイントアプリをおトクにつかう\
    \
    ![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_116613_123056.png)](https://dpoint.docomo.ne.jp/dpc/welcomeapp_prom02_02/index.html)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_314238_761269.png)\
    \
    Amazonでdポイントがたまる！つかえる！\
    \
    ![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_103768_815824.png)](https://service.smt.docomo.ne.jp/keitai_payment/shop/shop_amazon.html?utm_source=dpointclub&utm_medium=owned&utm_campaign=dpayment_201812_dpay-shop-amazon&utm_content=dpc_shop)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_622052_622054.png)\
    \
    STEP1　dポイントアプリをおトクにつかう\
    \
    ![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_116613_123056.png)](https://dpoint.docomo.ne.jp/dpc/welcomeapp_prom02_01/index.html)
    

特集・セール
------

[さらに見る](https://dpoint.docomo.ne.jp/content/index.html)

*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/260123_820981_743257.jpg)\
    \
    家電セール開催中！人気商品もお買い得！\
    \
    ![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_12809_92044.png)](https://dshopping.docomo.ne.jp/products_search?sales_distribution=2&genre_code=5&utm_source=dpointclub&utm_medium=free-display&utm_campaign=dshopping_20251023_kadensale_dpcitem)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/260228_833503_754457.jpg)\
    \
    定番・ノンアル・地ビールなど種類も様々！\
    \
    ![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_12809_92044.png)](https://dshopping.docomo.ne.jp/matome/detail/100000000151/?utm_source=dpointclub&utm_medium=free-display&utm_campaign=dshopping_20250125_beer_dpcitem)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/251223_834030_834032.png)\
    \
    櫻坂46のライブを見るならLemino！\
    \
    ![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_12862_623862.png)](https://lemino.docomo.ne.jp/?crid=Y3JpZDovL3BsYWxhLmlwdHZmLmpwL2dyb3VwL2IxMDQzYjY%3D&utm_source=dpointclub&utm_medium=free-display&utm_campaign=lemino_202512_s46_13thsg-backslive&utm_content=use)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/251214_827362_829560.png)\
    \
    「新参者 二〇二五 LIVE」リピート配信！\
    \
    ![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_12862_623862.png)](https://lemino.docomo.ne.jp/live/banner?summarize_id=live_s_00001222&utm_source=dpointclub&utm_medium=free-display&utm_campaign=lemino_202511_szm&utm_content=use)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/251223_823669_827955.jpg)\
    \
    ドコモ回線契約者限定！スマホアクセサリーがおトク\
    \
    ![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_108656_329694.png)](https://onlineshop.docomo.ne.jp/products/accessories/limited-options/coupon?utm_source=dpointclub&utm_medium=applink&utm_campaign=cc_202510_dscoupon_cp_251031)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/260131_833030_833032.jpg)\
    \
    dブックで宿泊券など豪華賞品を手に入れよう！\
    \
    ![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_12875_403076.png)](https://dbook.docomo.ne.jp/campaign/static/dbo-2512-shueisha-mangasai/?utm_source=dpointclub&utm_medium=free-display&utm_campaign=dbook_202512_item1-2&utm_content=pub_syu_non_mangasai)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/260109_833485_830861.jpg)\
    \
    AI 25周年記念ツアー 独占見逃し配信！\
    \
    ![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_12862_623862.png)](https://lemino.docomo.ne.jp/?crid=Y3JpZDovL3BsYWxhLmlwdHZmLmpwL2dyb3VwL2IxMDQyOWI%3D&utm_source=dpointclub&utm_medium=free-display&utm_campaign=lemino_202511_ai-25thbesttour&utm_content=use)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/260128_822722_738629.jpg)\
    \
    お部屋の中を快適に♪あったかアイテム特集\
    \
    ![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_12809_92044.png)](https://dshopping.docomo.ne.jp/matome/detail/warmitems/?utm_source=dpointclub&utm_medium=free-display&utm_campaign=dshopping_20251029_warmitems_dpcitem)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/251207_829590_829592.png)\
    \
    乃木坂46のライブを見るならLemino！\
    \
    ![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_12862_623862.png)](https://lemino.docomo.ne.jp/live/banner?summarize_id=live_s_00001256&utm_source=dpointclub&utm_medium=free-display&utm_campaign=lemino_202511_n46-kubograduation&utm_content=use)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/251224_831104_831107.png)\
    \
    クリスマス特集♪絶品グルメやギフトなど♪\
    \
    ![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_12809_92044.png)](https://dshopping.docomo.ne.jp/matome/detail/xmas/?utm_source=dpointclub&utm_medium=free-display&utm_campaign=dshopping_20251119_xmas_dpcitem)
    

アンケート
-----

スキマ時間を有効活用！  
簡単なアンケートに答えるだけでdポイントがたまります

![](https://dpoint.docomo.ne.jp/img/bnnr/acc_enq.png)

[dポイントクラブアンケートでためる](https://dpcq.macaron.docomo.ne.jp/?utm_source=dpointclub&utm_medium=owned&utm_campaign=dpc_enqdetameru_202301)

[dジョブアンケートでためる](https://sw.djob.docomo.ne.jp/search?prj_major_cate_cd%5B%5D=07&smt=1&tile=enq2&utm_source=dpointclub&utm_medium=free-display&utm_campaign=djob_202212_enq_site&utm_content=txt&ch_param=free-display_dpointclub_djob_202212_enq_site)

ドコモのたまる・つかえるサービス
----------------

*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_712411_712412.jpg)\
    \
    dミュージック powered by レコチョク\
    \
    たまる\
    \
    つかえる](https://dmusic.docomo.ne.jp/?utm_source=dpointclub&utm_medium=owned&utm_campaign=dmusic_202405_)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_720516_632013.png)\
    \
    ドコモサービスのご利用でためる\
    \
    たまる](https://dpoint.docomo.ne.jp/acc/mobile_use/index.html)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_720514_651348.png)\
    \
    dカード\
    \
    たまる](https://dcard.docomo.ne.jp/std/campaigns/202410_1cm/dcard/index.html?utm_source=dcard_service&utm_medium=free-display&utm_campaign=dcard_202502_dpc-save-0227&argument=WUUq3J3f&dmai=a67bd66595a2a4)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_720519_632491.png)\
    \
    dジョブ スマホワーク\
    \
    たまる](https://sw.djob.docomo.ne.jp/mymenu/luckybox?utm_source=dpointclub&utm_medium=free-display&utm_campaign=djob_202304_dpointclub_acc&utm_content=bnr_mission_202304&ch_param=free-display_dpointclub_djob_202304_dpointclub_acc)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_804375_804376.png)\
    \
    かんたん資産運用\
    \
    たまる](https://aawg.adj.st/deeplink?type=0&function_id=13002&url=https://monex.docomo.ne.jp/easy-nisa/auth/index.html&adj_t=1pn3goyu&adj_deep_link=dpayment%3A%2F%2Fdeeplink%3Ftype%3D0%26function_id%3D13002%26url%3Dhttps%3A%2F%2Fmonex.docomo.ne.jp%2Feasy-nisa%2Fauth%2Findex.html&adj_redirect=https%3A%2F%2Fmonex.docomo.ne.jp%2Feasy-nisa%2Flp%2Fweb%2F%3Futm_source%3Ddpc%26utm_medium%3Ddpc_pull_app_program%26utm_content%3D1002_docomo%26utm_term%3Deasy-nisa-lp-web_easydebut_dpoint%26acOpenChannel%3Dd02i12234)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_720566_92712.png)\
    \
    ドコモ商品につかう\
    \
    つかえる](https://dpoint.docomo.ne.jp/use/buy_products/index.html)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_712417_712418.png)\
    \
    d fashion\
    \
    たまる\
    \
    つかえる](https://dfashion.docomo.ne.jp/?utm_medium=free-display&utm_source=dpointclub&utm_campaign=dfashion_top_202405_accuse)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_712405_712406.png)\
    \
    dブック\
    \
    たまる\
    \
    つかえる](https://dbook.docomo.ne.jp/top/promotion/?utm_source=dpointclub&utm_medium=free-display&utm_campaign=dbook_202405_toppatu1&utm_content=dcp_non_non_muryo)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_712407_712409.png)\
    \
    dアニメストア\
    \
    つかえる](https://animestore.docomo.ne.jp/animestore/book/tp?utm_source=dpointmarket&utm_medium=free-display&utm_campaign=danime_202405_dpointuse)
    
*   [![](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_825951_825952.png)\
    \
    dポイント運用\
    \
    たまる\
    \
    つかえる](https://dpoint-inv.smt.docomo.ne.jp/portal/top?from=dpointclub_app&utm_source=dpointclub&utm_medium=free-display&utm_campaign=dpointinv_202511_nm_portal_dpointclub_app_pull_dpc-service-program_001)
    

ドコモのたまる・つかえるプログラム
-----------------

*   [ドコモ料金への充当\
    \
    *   つかえる](https://dpoint.docomo.ne.jp/use/payment/index.html)
    
*   [comotto\
    \
    *   たまる](https://www.docomo.ne.jp/service/parenting_support/index.html?utm_source=dpointclub_CRP-SVC-parentsup-pcsp&utm_medium=web&utm_campaign=dpointclub_CRP-SVC-parentsup-pcsp_dpc-pt01-pc_PARENTSUP_parent-sup_1611_00003_prm)
    
*   [海外でためる・つかう\
    \
    *   たまる\
    *   つかえる](https://docomo-kaigai.com/kaigaidp/?utm_source=dpointclub&utm_medium=free-display&utm_campaign=kokusai_2001_dp_tukau_TOP)
    
*   [dポイント還元で爆アゲ！\
    \
    *   たまる](https://ssw.web.docomo.ne.jp/bakuage/?utm_source=dpointclub&utm_medium=free-display&utm_campaign=bakuage_202305_top_0000035)
    
*   [ポイントを送る\
    \
    *   つかえる](https://dpoint.docomo.ne.jp/use/transfer/index.html)
    

[さらにサービス・プログラムを見る](https://dpoint.docomo.ne.jp/service/index.html)

お店でポイントをためて目指せランクアップ！  
たまる・つかえるお店
----------------------------------

[![コレが両方あるお店は dポイントが二重ドリできます！ おトクなため方をチェック！](https://dpoint.docomo.ne.jp/common/img/bnr/bnr_wpoint.png)](https://dpoint.docomo.ne.jp/content/good_deal/index.html)

対応サービスについて

*   [![Amazon](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_103768_815824.png)](https://dpoint.docomo.ne.jp/static/store/103768/)
    
    ![dpoint](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_card_connect_on.png)![dpay](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpay_on.png)
    
*   [![セブン‐イレブン](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_264549_264566.png)](https://dpoint.docomo.ne.jp/static/store/264549/)
    
    ![dpay](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpay_on.png)
    
*   [![WINTICKET](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_638876_638877.png)](https://dpoint.docomo.ne.jp/static/store/638876/)
    
    ![dpoint](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_card_connect_on.png)![dpay](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpay_on.png)
    
*   [![コスモ石油](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_134281_327755.png)](https://dpoint.docomo.ne.jp/static/store/134281/)
    
    ![dpoint](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpcd_on.png)![dpay](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpay_on.png)
    
*   [![HOT PEPPER Beauty](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_409560_409561.png)](https://dpoint.docomo.ne.jp/static/store/409560/)
    
    ![dpoint](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_card_connect_on.png)
    
*   [![高島屋](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_7751_400921.png)](https://dpoint.docomo.ne.jp/static/store/7751/)
    
    ![dpoint](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpcd_on.png)![dpay](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpay_on.png)
    
*   [![ドトールコーヒーショップ](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_8111_153266.png)](https://dpoint.docomo.ne.jp/static/store/8111/)
    
    ![dpoint](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpcd_on.png)![dpay](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpay_on.png)
    
*   [![ココカラファイン](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_263200_818910.png)](https://dpoint.docomo.ne.jp/static/store/263200/)
    
    ![dpoint](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpcd_on.png)![dpay](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpay_on.png)
    
*   [![ロイズ](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_264805_263858.png)](https://dpoint.docomo.ne.jp/static/store/264805/)
    
    ![dpay](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpay_on.png)
    
*   [![apollostation](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_678622_678623.png)](https://dpoint.docomo.ne.jp/static/store/678622/)
    
    ![dpoint](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpcd_on.png)![dpay](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpay_on.png)
    
*   [![メルカリ](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_13322_101952.png)](https://dpoint.docomo.ne.jp/static/store/13322/)
    
    ![dpoint](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_card_connect_on.png)![dpay](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpay_on.png)
    
*   [![ミスタードーナツ](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_263292_264463.png)](https://dpoint.docomo.ne.jp/static/store/263292/)
    
    ![dpoint](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpcd_on.png)![dpay](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpay_on.png)
    
*   [![PLANT](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_327785_327790.png)](https://dpoint.docomo.ne.jp/static/store/327785/)
    
    ![dpoint](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpcd_on.png)![dpay](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpay_on.png)
    
*   [![ローソンストア100](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_43052_617726.png)](https://dpoint.docomo.ne.jp/static/store/43052/)
    
    ![dpoint](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpcd_on.png)![dpay](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpay_on.png)
    
*   [![ＥＮＥＯＳ](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_7731_496428.png)](https://dpoint.docomo.ne.jp/static/store/7731/)
    
    ![dpoint](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpcd_on.png)
    
*   [![マクドナルド](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_7833_111146.png)](https://dpoint.docomo.ne.jp/static/store/7833/)
    
    ![dpay](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpay_on.png)
    

[さらにお店を見る](https://dpoint.docomo.ne.jp/store/index.html)

[地図で街のお店を探す](https://dpoint.docomo.ne.jp/map/)

※現在地情報を用いて近くのお店を表示します。  
[サイトご利用にあたって](https://dpoint.docomo.ne.jp/guide/attention/index.html)
をご確認ください。

ネットのお買物がポイントアップ
---------------

dポイントマーケットを経由することでポイントがさらにたまる！

[![いつものお買物でdポイントがプラスでたまる｜dポイントマーケット](https://dpoint.docomo.ne.jp/img/bnnr/bnnr_dpmarket.png)](https://dmarket.docomo.ne.jp/common/owned?utm_source=dpointclub&utm_medium=owned&utm_campaign=dpm_202412_own_0000015)

[![](https://dpoint.docomo.ne.jp/common/img/service_icon/store_partner.png)\
\
#### 5つ星なら付与率は\
\
1.5％\
\
#### あなたのポイント還元率\
\
1.5%](https://dpoint.docomo.ne.jp/member/stage_info/index.html#rank_dpm_benefit)

対応サービスについて

おトクになるお店
--------

*   [![GU](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_327820_331873.png)](https://dmarket.docomo.ne.jp/shop/10138/?utm_source=dpointclub&utm_medium=owned&utm_campaign=dpm_202411_own_0000012_10138)
    
    ![dpay](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpay_on.png)![dポイントマーケット](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpm_on.png)
    
*   [![マツキヨココカラオンラインストア](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_67424_705453.png)](https://dmarket.docomo.ne.jp/shop/10518/?utm_source=dpointclub&utm_medium=owned&utm_campaign=dpm_202509_own_0000012_10518)
    
    ![dpay](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpay_on.png)![dポイントマーケット](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpm_on.png)
    
*   [![DHCオンラインショップ](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_9375_753223.png)](https://dmarket.docomo.ne.jp/shop/10257/?utm_source=dpointclub&utm_medium=owned&utm_campaign=dpm_202411_own_0000012_10257)
    
    ![dpay](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpay_on.png)![dポイントマーケット](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpm_on.png)
    
*   [![グローバルファッションブランド「SHEIN（シーイン）」](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_805927_802327.jpeg)](https://dmarket.docomo.ne.jp/shop/10319/?utm_source=dpointclub&utm_medium=owned&utm_campaign=dpm_202411_own_0000012_10319)
    
    ![dポイントマーケット](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpm_on.png)
    
*   [![Qoo10](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_737573_782040.jpg)](https://dmarket.docomo.ne.jp/shop/10217/?utm_source=dpointclub&utm_medium=owned&utm_campaign=dpm_202411_own_0000012_10217)
    
    ![dポイントマーケット](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpm_on.png)
    
*   [![PAL CLOSET](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_659066_659067.png)](https://dmarket.docomo.ne.jp/shop/10314/?utm_source=dpointclub&utm_medium=owned&utm_campaign=dpm_202411_own_0000012_10314)
    
    ![dpay](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpay_on.png)![dポイントマーケット](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpm_on.png)
    
*   [![ニッセンオンライン](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_13323_135834.png)](https://dmarket.docomo.ne.jp/shop/10163/?utm_source=dpointclub&utm_medium=owned&utm_campaign=dpm_202411_own_0000012_10163)
    
    ![dpay](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpay_on.png)![dポイントマーケット](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpm_on.png)
    
*   [![ビックカメラ.com](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_737598_747810.png)](https://dmarket.docomo.ne.jp/shop/10154/?utm_source=dpointclub&utm_medium=owned&utm_campaign=dpm_202411_own_0000012_10154)
    
    ![dpay](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpay_on.png)![dポイントマーケット](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpm_on.png)
    
*   [![ベルメゾン](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_737579_737257.jpg)](https://dmarket.docomo.ne.jp/shop/10136/?utm_source=dpointclub&utm_medium=owned&utm_campaign=dpm_202411_own_0000012_10136)
    
    ![dポイントマーケット](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpm_on.png)
    
*   [![サンドラッグ Online Store](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_608272_612375.png)](https://dmarket.docomo.ne.jp/shop/10119/?utm_source=dpointclub&utm_medium=owned&utm_campaign=dpm_202411_own_0000012_10119)
    
    ![dpay](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpay_on.png)![dポイントマーケット](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpm_on.png)
    
*   [![資生堂オンラインストア](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_66186_720345.png)](https://dmarket.docomo.ne.jp/shop/10236/?utm_source=dpointclub&utm_medium=owned&utm_campaign=dpm_202411_own_0000012_10236)
    
    ![dpay](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpay_on.png)![dポイントマーケット](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpm_on.png)
    
*   [![セシールオンラインショップ](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_535537_828419.jpg)](https://dmarket.docomo.ne.jp/shop/10177/?utm_source=dpointclub&utm_medium=owned&utm_campaign=dpm_202411_own_0000012_10177)
    
    ![dpay](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpay_on.png)![dポイントマーケット](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpm_on.png)
    
*   [![dショッピング サンプル百貨店](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_737465_737125.jpg)](https://dmarket.docomo.ne.jp/shop/10002/?utm_source=dpointclub&utm_medium=owned&utm_campaign=dpm_202411_own_0000012_10002)
    
    ![dポイントマーケット](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpm_on.png)
    
*   [![ディノスオンラインショップ](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_383122_383131.png)](https://dmarket.docomo.ne.jp/shop/10054/?utm_source=dpointclub&utm_medium=owned&utm_campaign=dpm_202411_own_0000012_10054)
    
    ![dpay](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpay_on.png)![dポイントマーケット](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpm_on.png)
    
*   [![セブンネットショッピング](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_805925_802331.jpeg)](https://dmarket.docomo.ne.jp/shop/10408/?utm_source=dpointclub&utm_medium=owned&utm_campaign=dpm_202411_own_0000012_10408)
    
    ![dポイントマーケット](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpm_on.png)
    
*   [![dショッピング](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_12809_92044.png)](https://dmarket.docomo.ne.jp/shop/10001/?utm_source=dpointclub&utm_medium=owned&utm_campaign=dpm_202411_own_0000012_10001)
    
    ![dポイントマーケット](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpm_on.png)
    
*   [![ショップジャパン](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_7785_13281.png)](https://dmarket.docomo.ne.jp/shop/10067/?utm_source=dpointclub&utm_medium=owned&utm_campaign=dpm_202411_own_0000012_10067)
    
    ![dpay](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpay_on.png)![dポイントマーケット](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpm_on.png)
    
*   [![d fashion](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_348109_353318.png)](https://dmarket.docomo.ne.jp/shop/10004/?utm_source=dpointclub&utm_medium=owned&utm_campaign=dpm_202411_own_0000012_10004)
    
    ![dポイントマーケット](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpm_on.png)
    
*   [![タカシマヤファッションスクエア](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_13349_51485.png)](https://dmarket.docomo.ne.jp/shop/10066/?utm_source=dpointclub&utm_medium=owned&utm_campaign=dpm_202411_own_0000012_10066)
    
    ![dpay](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpay_on.png)![dポイントマーケット](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpm_on.png)
    
*   [![Agoda](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/999999_540926_540927.png)](https://dmarket.docomo.ne.jp/shop/10254/?utm_source=dpointclub&utm_medium=owned&utm_campaign=dpm_202411_own_0000012_10254)
    
    ![dポイントマーケット](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpm_on.png)
    

[dポイントマーケットでおトクになるお店](https://dmarket.docomo.ne.jp/shoplist/?utm_source=dpointclub&utm_medium=owned&utm_campaign=dpm_202410_shp_0000001)

おトクにたまる！おすすめ商品
--------------

*   [![](https://dpm-affiliate.docomo.ne.jp/api/images?url=https%3A%2F%2Fimg.dinos.co.jp%2FdefaultMall%2Fimages%2Fgoods%2FNSH%2F0011%2Fetc%2FNH1050c1.jpg&advertiserId=10054&sku=NH1050-00-2282387)](https://dmarket.docomo.ne.jp/products/236721322/)
    
    [赤坂四川飯店　黒酢すぶた１５０ｇ](https://dmarket.docomo.ne.jp/products/236721322/)
    
    ￥1,090
    
    [ディノス](https://dmarket.docomo.ne.jp/shop/10054/)
    
    ![d払い](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpay_on.png)
    
*   [![](https://dpm-affiliate.docomo.ne.jp/api/images?url=https%3A%2F%2Fimg.dinos.co.jp%2FdefaultMall%2Fimages%2Fgoods%2FNSH%2F0019%2Fetc%2FNH0383c1.jpg&advertiserId=10054&sku=NH0383-00-2265479)](https://dmarket.docomo.ne.jp/products/146893524/)
    
    [オクラ海老詰め　３０個](https://dmarket.docomo.ne.jp/products/146893524/)
    
    ￥1,680
    
    [ディノス](https://dmarket.docomo.ne.jp/shop/10054/)
    
    ![d払い](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpay_on.png)
    
*   [![](https://dpm-affiliate.docomo.ne.jp/api/images?url=https%3A%2F%2Fwww.ringbell.co.jp%2Fgourmet%2Fcontents%2Fshohin%2Fimages%2F4864-162.jpg&advertiserId=10053&sku=64162)](https://dmarket.docomo.ne.jp/products/244680646/)
    
    [米・米加工品・パン・乳製品/米/特別栽培米 山形県産 雪若丸 1.5kg](https://dmarket.docomo.ne.jp/products/244680646/)
    
    ￥2,700
    
    [リンベル公式オンラインストア](https://dmarket.docomo.ne.jp/shop/10053/)
    
    ![d払い](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpay_on.png)
    
*   [![](https://dpm-affiliate.docomo.ne.jp/api/images?url=https%3A%2F%2Fwww.irisplaza.co.jp%2FIMAGE%2FHK%2FPRODUCT%2F312272.jpg&advertiserId=10128&sku=312272)](https://dmarket.docomo.ne.jp/products/127867547/)
    
    [長期保存生きりもち 個包装1kg](https://dmarket.docomo.ne.jp/products/127867547/)
    
    ￥1,480
    
    送料無料
    
    [アイリスプラザ](https://dmarket.docomo.ne.jp/shop/10128/)
    
    ![d払い](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpay_on.png)
    
*   [![](https://dpm-affiliate.docomo.ne.jp/api/images?url=https%3A%2F%2Fwww.irisplaza.co.jp%2FIMAGE%2FHK%2FPRODUCT%2FH311524.jpg&advertiserId=10128&sku=H311524)](https://dmarket.docomo.ne.jp/products/39398775/)
    
    [野菜入りおかゆ 250ｇ](https://dmarket.docomo.ne.jp/products/39398775/)
    
    ￥398
    
    [アイリスプラザ](https://dmarket.docomo.ne.jp/shop/10128/)
    
    ![d払い](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpay_on.png)
    
*   [![](https://dpm-affiliate.docomo.ne.jp/api/images?url=https%3A%2F%2Fwww.ringbell.co.jp%2Fgourmet%2Fcontents%2Fshohin%2Fimages%2F4858-044.jpg&advertiserId=10053&sku=58044)](https://dmarket.docomo.ne.jp/products/13933799/)
    
    [法要・香典返し/結婚祝い/出産内祝い/スイーツ(洋菓子)/結婚引出物/退職祝い/クッキー・焼菓子/ご自宅用/小分けギフト/結婚内祝い/快気祝い/出産祝い/記念品・景品/しっとりマドレーヌ 5個](https://dmarket.docomo.ne.jp/products/13933799/)
    
    ￥1,296
    
    [リンベル公式オンラインストア](https://dmarket.docomo.ne.jp/shop/10053/)
    
    ![d払い](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpay_on.png)
    
*   [![](https://dpm-affiliate.docomo.ne.jp/api/images?url=https%3A%2F%2Fsundrug-online.com%2Fcdn%2Fshop%2Fproducts%2F4901777018686x6_600x.jpg)](https://dmarket.docomo.ne.jp/products/50505521/)
    
    [◆サントリー 天然水 2L 【6個セット】](https://dmarket.docomo.ne.jp/products/50505521/)
    
    ￥999
    
    [サンドラッグ Online Store](https://dmarket.docomo.ne.jp/shop/10119/)
    
    ![d払い](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpay_on.png)
    
*   [![](https://dpm-affiliate.docomo.ne.jp/api/images?url=https%3A%2F%2Fimg.dinos.co.jp%2FdefaultMall%2Fimages%2Fgoods%2FKHC%2F2504%2Fetc%2FFK9040c1.jpg&advertiserId=10054&sku=FK9040-00-2281699)](https://dmarket.docomo.ne.jp/products/242804189/)
    
    [オークラ桃花林　焼餃子８個](https://dmarket.docomo.ne.jp/products/242804189/)
    
    ￥990
    
    [ディノス](https://dmarket.docomo.ne.jp/shop/10054/)
    
    ![d払い](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpay_on.png)
    
*   [![](https://dpm-affiliate.docomo.ne.jp/api/images?url=https%3A%2F%2Fimg.dinos.co.jp%2FdefaultMall%2Fimages%2Fgoods%2FNSH%2F0011%2Fetc%2FN97896c1.jpg&advertiserId=10054&sku=N97896-00-2170884)](https://dmarket.docomo.ne.jp/products/13283953/)
    
    [青森サーモンネギトロ](https://dmarket.docomo.ne.jp/products/13283953/)
    
    ￥1,000
    
    [ディノス](https://dmarket.docomo.ne.jp/shop/10054/)
    
    ![d払い](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpay_on.png)
    
*   [![](https://dpm-affiliate.docomo.ne.jp/api/images?url=https%3A%2F%2Fwww.irisplaza.co.jp%2FIMAGE%2FHK%2FPRODUCT%2F1919144.jpg&advertiserId=10128&sku=1919144)](https://dmarket.docomo.ne.jp/products/91624967/)
    
    [【仕送りセット】カレーライスセット (パックご飯180g×10食+カレー4袋入×2個)](https://dmarket.docomo.ne.jp/products/91624967/)
    
    ￥2,980
    
    送料無料
    
    [アイリスプラザ](https://dmarket.docomo.ne.jp/shop/10128/)
    
    ![d払い](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpay_on.png)
    
*   [![](https://dpm-affiliate.docomo.ne.jp/api/images?url=https%3A%2F%2Fwww.irisplaza.co.jp%2FIMAGE%2FHK%2FPRODUCT%2F7250223.jpg&advertiserId=10128&sku=7250223)](https://dmarket.docomo.ne.jp/products/49045082/)
    
    [【メール便】あえるパスタソース ツナマヨ](https://dmarket.docomo.ne.jp/products/49045082/)
    
    ￥550
    
    送料無料
    
    [アイリスプラザ](https://dmarket.docomo.ne.jp/shop/10128/)
    
    ![d払い](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpay_on.png)
    
*   [![](https://dpm-affiliate.docomo.ne.jp/api/images?url=https%3A%2F%2Fimg.dinos.co.jp%2FdefaultMall%2Fimages%2Fgoods%2FNSH%2F0011%2Fetc%2FNH0304c1.jpg&advertiserId=10054&sku=NH0304-00-2263187)](https://dmarket.docomo.ne.jp/products/145395073/)
    
    [海老好きのエビチリ](https://dmarket.docomo.ne.jp/products/145395073/)
    
    ￥1,790
    
    [ディノス](https://dmarket.docomo.ne.jp/shop/10054/)
    
    ![d払い](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpay_on.png)
    
*   [![](https://dpm-affiliate.docomo.ne.jp/api/images?url=https%3A%2F%2Fwww.irisplaza.co.jp%2FIMAGE%2FHK%2FPRODUCT%2F1912562.jpg&advertiserId=10128&sku=1912562)](https://dmarket.docomo.ne.jp/products/34962060/)
    
    [【8個セット】オートミール300gスタンドチャック付き](https://dmarket.docomo.ne.jp/products/34962060/)
    
    ￥2,540
    
    送料無料
    
    [アイリスプラザ](https://dmarket.docomo.ne.jp/shop/10128/)
    
    ![d払い](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpay_on.png)
    
*   [![](https://dpm-affiliate.docomo.ne.jp/api/images?url=https%3A%2F%2Fwww.ringbell.co.jp%2Fgourmet%2Fcontents%2Fshohin%2Fimages%2F4858-619.jpg&advertiserId=10053&sku=58619)](https://dmarket.docomo.ne.jp/products/13934155/)
    
    [(麺)/麺/ぴょんぴょん舎 冷麺三種詰合せ 4食](https://dmarket.docomo.ne.jp/products/13934155/)
    
    ￥2,700
    
    [リンベル公式オンラインストア](https://dmarket.docomo.ne.jp/shop/10053/)
    
    ![d払い](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpay_on.png)
    
*   [![](https://dpm-affiliate.docomo.ne.jp/api/images?url=https%3A%2F%2Fimg.dinos.co.jp%2FdefaultMall%2Fimages%2Fgoods%2FKHC%2F2504%2Fetc%2FFK9119c1.jpg&advertiserId=10054&sku=FK9119-00-2281649)](https://dmarket.docomo.ne.jp/products/242804216/)
    
    [うまかあじたたき６０ｇ](https://dmarket.docomo.ne.jp/products/242804216/)
    
    ￥860
    
    [ディノス](https://dmarket.docomo.ne.jp/shop/10054/)
    
    ![d払い](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpay_on.png)
    
*   [![](https://dpm-affiliate.docomo.ne.jp/api/images?url=https%3A%2F%2Fwww.irisplaza.co.jp%2FIMAGE%2FHK%2FPRODUCT%2F7249456.jpg&advertiserId=10128&sku=7249456)](https://dmarket.docomo.ne.jp/products/67368614/)
    
    [即席八丁味噌煮込みうどん 1944](https://dmarket.docomo.ne.jp/products/67368614/)
    
    ￥260
    
    [アイリスプラザ](https://dmarket.docomo.ne.jp/shop/10128/)
    
    ![d払い](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpay_on.png)
    
*   [![](https://dpm-affiliate.docomo.ne.jp/api/images?url=https%3A%2F%2Fwww.ringbell.co.jp%2Fgourmet%2Fcontents%2Fshohin%2Fimages%2F4855-693.jpg&advertiserId=10053&sku=55693)](https://dmarket.docomo.ne.jp/products/13933256/)
    
    [惣菜/三つ星餃子/結婚祝い/父の日/永年勤続表彰/惣菜/お歳暮・寒中見舞い/退職祝い/お酒のおつまみ/ご自宅用/中華惣菜(点心・中華料理)/入学内祝い/結婚内祝い/快気祝い/出産祝い/入学祝い/喪中見舞い/入進学/記念品・景品/山形県 五つ星餃子 20個](https://dmarket.docomo.ne.jp/products/13933256/)
    
    ￥2,160
    
    [リンベル公式オンラインストア](https://dmarket.docomo.ne.jp/shop/10053/)
    
    ![d払い](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpay_on.png)
    
*   [![](https://dpm-affiliate.docomo.ne.jp/api/images?url=https%3A%2F%2Fwww.ringbell.co.jp%2Fgourmet%2Fcontents%2Fshohin%2Fimages%2F4856-840.jpg&advertiserId=10053&sku=56840)](https://dmarket.docomo.ne.jp/products/13933569/)
    
    [結婚祝い/出産内祝い/永年勤続表彰/新築・引越し祝い/退職祝い/ご自宅用/誕生日祝い/麺/入学内祝い/快気祝い/出産祝い/入学祝い/うどん/記念品・景品/紅白一本うどん](https://dmarket.docomo.ne.jp/products/13933569/)
    
    ￥1,080
    
    [リンベル公式オンラインストア](https://dmarket.docomo.ne.jp/shop/10053/)
    
    ![d払い](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpay_on.png)
    
*   [![](https://dpm-affiliate.docomo.ne.jp/api/images?url=https%3A%2F%2Fimg.dinos.co.jp%2FdefaultMall%2Fimages%2Fgoods%2FNSH%2F0019%2Fetc%2FN99991c1.jpg&advertiserId=10054&sku=N99991-00-2246163)](https://dmarket.docomo.ne.jp/products/90215973/)
    
    [フルーティス　りんご酢　柚子はちみつ](https://dmarket.docomo.ne.jp/products/90215973/)
    
    ￥1,780
    
    [ディノス](https://dmarket.docomo.ne.jp/shop/10054/)
    
    ![d払い](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpay_on.png)
    
*   [![](https://dpm-affiliate.docomo.ne.jp/api/images?url=https%3A%2F%2Fwww.irisplaza.co.jp%2FIMAGE%2FHK%2FPRODUCT%2FH310321.jpg&advertiserId=10128&sku=H310321)](https://dmarket.docomo.ne.jp/products/34987981/)
    
    [低温製法米のパックご飯 120g×10パック　【プラザマーケット】](https://dmarket.docomo.ne.jp/products/34987981/)
    
    ￥1,680
    
    [アイリスプラザ](https://dmarket.docomo.ne.jp/shop/10128/)
    
    ![d払い](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpay_on.png)
    

*   表示金額はすべて税込です
*   商品および販売価格は予告なく終了・変更する場合があります
*   「あなたのポイント還元率」は基本還元率0.5％とランク特典（dポイントマーケット利用特典）を足し合わせたものを表示しています

[さらにdポイントマーケットで見る](https://dmarket.docomo.ne.jp/products/recommend/?utm_source=dpointclub&utm_medium=owned&utm_campaign=dpm_202410_rit_0000002)

dポイントクラブアプリ
-----------

![あなたのスマホがdポイントカードに！アプリひとつでdポイントがたまる・つかえる！](https://dpoint.docomo.ne.jp/img/bnnr/dpointclub_app_mobile_02.png)

### アプリ限定でたまる

*   [![](https://dpoint.docomo.ne.jp/common/img/contents_icon_color/ico_mission.png)\
    \
    ミッション](https://dpoint.docomo.ne.jp/dpc/misstion_lp/index.html)
    
*   [![](https://dpoint.docomo.ne.jp/common/img/contents_icon_color/ico_stamp.png)\
    \
    dポイント  \
    スタンプ](https://dpoint.docomo.ne.jp/guide/howto_dpoint/app/shopping_stamp/index.html)
    
*   [![](https://dpoint.docomo.ne.jp/common/img/contents_icon_color/ico_movie.png)\
    \
    動画でためる](https://dpoint.docomo.ne.jp/guide/howto_dpoint/app/movie_mission/index.html)
    
*   [![](https://dpoint.docomo.ne.jp/common/img/contents_icon_color/icon_game.png)\
    \
    アプリ限定  \
    毎日くじ](https://dpoint.docomo.ne.jp/content/daily_kuji/index.html)
    

[アプリについて詳しく見る](https://dpoint.docomo.ne.jp/guide/howto_dpoint/app/index.html)

お店で使えるクーポン
----------

[さらに見る](https://dpoint.docomo.ne.jp/coupon.html)

*   [![レディーススーツ1点ご購入](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/260301_832151_832252.jpg)](https://dpoint.docomo.ne.jp/static/store/10029/coupon_832151/)
    
*   [![ローストビーフとゴルゴンゾーラのピッツァ](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/251225_830810_830812.jpg)](https://dpoint.docomo.ne.jp/static/store/331887/coupon_830810/)
    
*   [![（単品）熟成ラウンドステーキ（約120g）＆広島県産大粒カキフライ](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/251211_814168_814237.jpg)](https://dpoint.docomo.ne.jp/static/store/335894/coupon_814168/)
    
*   [![【就活生限定】レディーススーツ1点](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/260401_410148_764054.jpg)](https://dpoint.docomo.ne.jp/static/store/7816/coupon_410148/)
    
*   [![シェフズダイニング「シンフォニー」（1F）](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/260301_337163_761654.jpg)](https://dpoint.docomo.ne.jp/static/store/8006/coupon_337163/)
    
*   [![お会計から](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/260301_513435_714733.jpg)](https://dpoint.docomo.ne.jp/static/store/446062/coupon_513435/)
    
*   [![日本料理「源氏香」（5F）](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/260301_337160_761651.jpg)](https://dpoint.docomo.ne.jp/static/store/8006/coupon_337160/)
    
*   [![メンズ＆レディスアイテム](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/260401_613682_791730.jpg)](https://dpoint.docomo.ne.jp/static/store/14267/coupon_613682/)
    
*   [![レディスアイテム](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/261201_572469_742731.jpg)](https://dpoint.docomo.ne.jp/static/store/374117/coupon_572469/)
    
*   [![メンズ・レディース パターンオーダースーツ1点](https://dvgggj7yvagun.cloudfront.net/portal/dpoint/img/260401_410019_730115.jpg)](https://dpoint.docomo.ne.jp/static/store/7815/coupon_410019/)
    

※表示金額はすべて税込

お店からのおすすめ情報
-----------

*   [![エディオン](https://v3.cntpf.web.docomo.ne.jp/uploads/brand/image/40111/63e4fa3e-03e9-4030-b9a7-3ecda84fa2ec.png)\
    \
    エディオン](https://dpoint.docomo.ne.jp/static/store/114743/)
    [![](https://v3.cntpf.web.docomo.ne.jp/uploads/post/image/content/1376655/4253a644-8174-406e-956f-ce439d2775ec.jpg)\
    \
    2025/12/04\
    \
    ｄポイントでも買えるお得な日用品！](https://service-info.edion.jp/sale/251200_happyFriday.html?utm_source=dpointclub_mkt&utm_medium=dpointclub&utm_campaign=hf)
    
*   [![エディオン](https://v3.cntpf.web.docomo.ne.jp/uploads/brand/image/40111/63e4fa3e-03e9-4030-b9a7-3ecda84fa2ec.png)\
    \
    エディオン](https://dpoint.docomo.ne.jp/static/store/114743/)
    [![](https://v3.cntpf.web.docomo.ne.jp/uploads/post/image/content/1384840/a74a6643-55ca-4acf-9fc8-f4f6a8b7c702.jpg)\
    \
    2025/12/04\
    \
    クリスマスプレゼントの準備はお早めに🎁](https://www.edion.com/ito/contents/special/lp/present_edion/index.html?utm_source=dpointclub_mkt&utm_medium=dpointclub&utm_campaign=matome)
    
*   [![ピザハット](https://v3.cntpf.web.docomo.ne.jp/uploads/brand/image/403/e8e123fa-840a-4a13-baab-a46195844791.png)\
    \
    ピザハット](https://dpoint.docomo.ne.jp/static/store/8102/)
    [![](https://v3.cntpf.web.docomo.ne.jp/uploads/post/image/content/1376085/c08ae49c-2a9c-4320-9f19-a0a0af187494.jpg)\
    \
    2025/12/02\
    \
    ピザハットの豪華でおトクなセットで美味しいクリスマスを♪](https://www.pizzahut.jp/topic/winter/premium4?utm_source=docomo_serps&utm_medium=dpointclub&utm_campaign=post_google251202)
    
*   [![ピザハット](https://v3.cntpf.web.docomo.ne.jp/uploads/brand/image/403/e8e123fa-840a-4a13-baab-a46195844791.png)\
    \
    ピザハット](https://dpoint.docomo.ne.jp/static/store/8102/)
    [![](https://v3.cntpf.web.docomo.ne.jp/uploads/post/image/content/1356572/959aaed3-e4bb-4ac8-8c61-ae7035b59893.jpg)\
    \
    2025/11/25\
    \
    クリスマスのごちそうはピザハットでおトクに楽しもう🎉](https://www.pizzahut.jp/topic/christmas/reservation?utm_source=docomo_serps&utm_medium=dpointclub&utm_campaign=post_google251125)
    
*   [![エディオン](https://v3.cntpf.web.docomo.ne.jp/uploads/brand/image/40111/63e4fa3e-03e9-4030-b9a7-3ecda84fa2ec.png)\
    \
    エディオン](https://dpoint.docomo.ne.jp/static/store/114743/)
    [![](https://v3.cntpf.web.docomo.ne.jp/uploads/post/image/content/1340991/c87bfb42-6cb5-4b20-a8e5-5523fbf6e4af.jpg)\
    \
    2025/11/16\
    \
    【家電のプロのクリーニングサービス】まとめるほどさらにおトク！](https://service-info.edion.jp/sale/cleaningCP.html?utm_source=dpointclub_mkt&utm_medium=dpointclub&utm_campaign=cleaning)
    
*   [![ピザハット](https://v3.cntpf.web.docomo.ne.jp/uploads/brand/image/403/e8e123fa-840a-4a13-baab-a46195844791.png)\
    \
    ピザハット](https://dpoint.docomo.ne.jp/static/store/8102/)
    [![](https://v3.cntpf.web.docomo.ne.jp/uploads/post/image/content/1327177/3940f6d1-5186-4c0d-b2d1-71a9f76f3d58.jpg)\
    \
    2025/11/11\
    \
    【「チージーロール」がパワーアップして再登場！】モチモチ生地に2種類のチーズとハニーメープルが至福の味わいです✨](https://www.pizzahut.jp/topic/cheesy/roll?utm_source=docomo_serps&utm_medium=dpointclub&utm_campaign=post_google251111)
    
*   [![ピザハット](https://v3.cntpf.web.docomo.ne.jp/uploads/brand/image/403/e8e123fa-840a-4a13-baab-a46195844791.png)\
    \
    ピザハット](https://dpoint.docomo.ne.jp/static/store/8102/)
    [![](https://v3.cntpf.web.docomo.ne.jp/uploads/post/image/content/1314367/8f36a7ac-e68f-40ec-b957-9accf0b67d74.jpg)\
    \
    2025/11/04\
    \
    この冬のごちそうはピザハットでぜひどうぞ♪](https://www.pizzahut.jp/topic/winter/premium4?utm_source=docomo_serps&utm_medium=dpointclub&utm_campaign=post_google251104)
    
*   [![エディオン](https://v3.cntpf.web.docomo.ne.jp/uploads/brand/image/40111/63e4fa3e-03e9-4030-b9a7-3ecda84fa2ec.png)\
    \
    エディオン](https://dpoint.docomo.ne.jp/static/store/114743/)
    [![](https://v3.cntpf.web.docomo.ne.jp/uploads/post/image/content/1321081/605dbd81-9beb-4496-b3d7-0d88d9f99d4b.jpg)\
    \
    2025/11/04\
    \
    クリスマスデザインのシールを集めよう🎄](https://service-info.edion.jp/sale/251101_kids_seal.html?utm_source=dpointclub_mkt&utm_medium=dpointclub&utm_campaign=1112kids)
    
*   [![ピザハット](https://v3.cntpf.web.docomo.ne.jp/uploads/brand/image/403/e8e123fa-840a-4a13-baab-a46195844791.png)\
    \
    ピザハット](https://dpoint.docomo.ne.jp/static/store/8102/)
    [![](https://v3.cntpf.web.docomo.ne.jp/uploads/post/image/content/1301874/af80501e-9a1c-4911-ab02-abc8b9237e5a.jpg)\
    \
    2025/10/28\
    \
    【みんなが選ぶ！人気のピザ ベストテン🍕】あなたの推しピザは入ってる？第1位は「ピザハット・マルゲリータ」！](https://www.pizzahut.jp/topic/best/pizza?utm_source=docomo_serps&utm_medium=dpointclub&utm_campaign=post_google251028)
    
*   [![ピザハット](https://v3.cntpf.web.docomo.ne.jp/uploads/brand/image/403/e8e123fa-840a-4a13-baab-a46195844791.png)\
    \
    ピザハット](https://dpoint.docomo.ne.jp/static/store/8102/)
    [![](https://v3.cntpf.web.docomo.ne.jp/uploads/post/image/content/1272702/e288e58b-64f0-4f93-b5c0-5415f3f729e0.jpg)\
    \
    2025/10/14\
    \
    【選べるサイドでおトクに楽しむ!ピザハット🍕 】ピザと一緒に♪人気サイド2品or3品を選んでおトクに満足✨](https://www.pizzahut.jp/topic/choice_set/side_menu?utm_source=docomo_serps&utm_medium=dpointclub&utm_campaign=post_google251014)
    

*   一部店舗では実施していない場合がございます。

dポイントクラブからのおすすめ
---------------

*   [![サンプル百貨店で無料サンプル当たる](https://dpoint.docomo.ne.jp/parts/validation/img/present_3ple.png)\
    \
    無料サンプルは毎週変わるので要チェック！](https://dpoint.docomo.ne.jp/content/present_3ple/index.html)
    
*   [![dポイントクラブで社会貢献](https://dpoint.docomo.ne.jp/parts/validation/img/dpc_sdgs.png)\
    \
    ドコモは社会貢献を通じてSDGs達成に貢献していきます](https://dpoint.docomo.ne.jp/content/sdgs/index.html)
    
*   [![あなたのまわりのおトクな情報をおとどけする生活サポートアプリ](https://dpoint.docomo.ne.jp/parts/validation/img/20220603_mydaiz_dpointosusume.jpg)\
    \
    普段の生活の中でmy daizが大活躍！](https://www.mydaiz.jp/cp/owned/point202205/index.html?utm_source=dpointclub&utm_medium=owned&utm_campaign=dagt_202205_ownedmedia&utm_content=1)
    
*   [![ご利用状況がすぐわかる！](https://dpoint.docomo.ne.jp/parts/validation/img/01B.png)\
    \
    ご確認・お手続きはＷＥＢでカンタン！My docomo](https://www.docomo.ne.jp/mydocomo/?utm_source=dpointclub&utm_medium=owned&utm_campaign=mydocomo_202206_dpc-home-osusume-to-myd-top)
    
*   [![ミッションに挑戦して特典をGET！](https://dpoint.docomo.ne.jp/parts/validation/img/app_mission.jpg)\
    \
    dポイントクラブアプリ限定！特典をもらってdポイントをためよう！](https://dpoint.docomo.ne.jp/dpc/misstion_lp/index.html)
    
*   [![かんたん運用でdポイントをふやそう！](https://dpoint.docomo.ne.jp/parts/validation/img/dpc_investment.png)\
    \
    気軽にできる投資体験で、ポイントを賢く増やそう](https://dpoint-inv.smt.docomo.ne.jp/portal/top?from=dpointclub_site&utm_source=dpointclub&utm_medium=owned&utm_campaign=pi_dpointclub_nm_dpcrecommend_202308089_10)
    
*   [![おススメゲーム特集](https://dpoint.docomo.ne.jp/parts/validation/img/game_bn.png)\
    \
    数あるゲームアプリの中からおススメを厳選してご紹介します！](https://dpoint.docomo.ne.jp/dpc/netstore_article_07/index.html)
    
*   [![dアカウントをより安心・便利に！](https://dpoint.docomo.ne.jp/parts/validation/img/dpt_rcmnd_02.png)\
    \
    dアカウント設定アプリを使ったパスワードレス認証でセキュリティを強化しよう！](https://id.smt.docomo.ne.jp/src/appli/ctop_appli.html?utm_source=dpointclub&utm_medium=free-display&utm_campaign=dac_202103_security-ctop-appli)
    

お知らせ
----

*   [【復旧】ポイント詳細画面における失効予定ポイントの表示不具合事象について\
    \
    2025-12-01 12:00](https://dpoint.docomo.ne.jp/info/article/index.html?id=834157)
    
*   [「dポイントクラブ会員規約」の改定について\
    \
    2025-12-01 00:00](https://dpoint.docomo.ne.jp/info/article/index.html?id=834200)
    
*   [契約解除時のdポイント利用の変更について\
    \
    2025-11-26 10:00](https://dpoint.docomo.ne.jp/info/article/index.html?id=834246)
    

[さらにお知らせを見る](https://dpoint.docomo.ne.jp/info/index.html)

### 広告目的でのIPアドレス利用

お客さまの興味関心に応じて推奨する「ドコモ広告」の表示や、対象サイト・アプリ（他社のものも含む）での広告閲覧等の確認のため、通信時にドコモが発行するIPアドレスでお客様を識別し、広告用IDを生成・利用することについて、「[詳しくはこちら](https://dpoint.docomo.ne.jp/guide/ad_permission/index.html)
」（※対象広告・サイト等も記載）をお読みの上ご協力頂ける場合は同意をお願い致します。

[同意する](javascript:void(0))

[今は同意しない](javascript:void(0))

dポイントクラブ公式SNS

*   [![X](https://dpoint.docomo.ne.jp/common/img/button/btn_sns_x.png)](https://x.com/dpoint_club)
    
*   [![Facebook](https://dpoint.docomo.ne.jp/common/img/button/btn_sns_instagram.png)](https://www.instagram.com/dpoint.official/)
    
*   [![LINE](https://dpoint.docomo.ne.jp/common/img/button/btn_sns_line.png)](https://lin.ee/A5cjmZZ)
    

*   [![](https://dpoint.docomo.ne.jp/common/img/contents_icon_color/ico_mainichi_kuji.png)\
    \
    毎日くじ](https://service.smt.docomo.ne.jp/portal/special/collab/topics/src/dmenukuji_01.html?utm_source=dpointclub&utm_medium=owned&utm_campaign=dpc_202302_9O5XAX-drawings)
    
*   [![](https://dpoint.docomo.ne.jp/common/img/contents_icon_color/ico_survey.png)\
    \
    アンケート](https://dpcq.macaron.docomo.ne.jp/?utm_source=dpointclub&utm_medium=owned&utm_campaign=dpc_202302_XDJX95-enquete)
    
*   [![](https://dpoint.docomo.ne.jp/common/img/contents_icon_color/ico_campaign.png)\
    \
    キャンペーン](https://dpoint.docomo.ne.jp/campaign/)
    
*   [![](https://dpoint.docomo.ne.jp/common/img/contents_icon_color/ico_game.png)\
    \
    遊んでためる](https://dpoint.docomo.ne.jp/content/land/index.html)
    
*   [![](https://dpoint.docomo.ne.jp/common/img/contents_icon_color/ico_mission.png)\
    \
    ミッション](https://dpoint.onelink.me/roGT?af_ios_url=https%3A%2F%2Fdpoint.docomo.ne.jp%2Fdpc%2Fmisstion_lp%2Findex.html&af_android_url=https%3A%2F%2Fdpoint.docomo.ne.jp%2Fdpc%2Fmisstion_lp%2Findex.html&af_xp=custom&pid=mission_appeal&af_dp=dpoint%3A%2F%2Fnormal_mission_list)
    
*   [![](https://dpoint.docomo.ne.jp/common/img/contents_icon_color/ico_dpay.png)\
    \
    d払い](https://app.adjust.com/qld7tcb?deeplink=dpayment%3A%2F%2Fdeeplink%3Ftype%3D0&redirect=https%3A%2F%2Fservice.smt.docomo.ne.jp%2Fkeitai_payment%2F)
    
*   [![](https://dpoint.docomo.ne.jp/common/img/contents_icon_color/ico_mydocomo.png)\
    \
    Mydocomo](https://www.docomo.ne.jp/mydocomo/?utm_source=dpointclub&utm_medium=owned&utm_campaign=dpc_202302_U4838O-mydocomo)
    
*   [![](https://dpoint.docomo.ne.jp/common/img/contents_icon_color/ico_dcard.png)\
    \
    dカード](https://dcard.docomo.ne.jp/st/index.html?utm_source=dpointclub&utm_medium=owned&utm_campaign=dpc_202302_DK89FZ-dcard)
    
*   [![](https://dpoint.docomo.ne.jp/common/img/contents_icon_color/ico_dpointmarket.png)\
    \
    dﾎﾟｲﾝﾄﾏ-ｹｯﾄ](https://dmarket.docomo.ne.jp/?utm_source=dpointclub&utm_medium=owned&utm_campaign=dpm_202410_dtp_0000009)
    
*   [![](https://dpoint.docomo.ne.jp/common/img/contents_icon_color/ico_all.png)\
    \
    すべて](https://dpoint.docomo.ne.jp/guide/service_category/index.html)
    

*   [dポイントクラブ会員番号の確認](https://dpoint.docomo.ne.jp/member/index.html)
    
*   [サイトご利用にあたって](https://dpoint.docomo.ne.jp/guide/attention/index.html)
    
*   [会員規約](https://dpoint.docomo.ne.jp/instruction/agreement/index.html)
    
*   [ログイン(別のdアカウント)](https://cfg.smt.docomo.ne.jp/auth/cgi/anidlogin?rl=https%3A%2F%2Fdpoint%2edocomo%2ene%2ejp%2F%3Fdpc_home_adflg%3Dfalse)
    
*   [ログアウト(dアカウント)](https://dpoint.docomo.ne.jp/api/logout.do?nl=https%3A%2F%2Fdpoint%2edocomo%2ene%2ejp%2F)
    

(c) NTT DOCOMO

*   [ホーム](https://dpoint.docomo.ne.jp/index.html)
    
*   [ためる](https://dpoint.docomo.ne.jp/acc.html)
    
*   [お店](https://dpoint.docomo.ne.jp/store/index.html)
    
*   [つかう](https://dpoint.docomo.ne.jp/use.html)
    
*   [クーポン](https://dpoint.docomo.ne.jp/coupon.html)
    

×

[ホーム](https://dpoint.docomo.ne.jp/index.html)

*   [ためる](https://dpoint.docomo.ne.jp/acc.html)
    
*   [つかう](https://dpoint.docomo.ne.jp/use.html)
    
*   [お店](https://dpoint.docomo.ne.jp/store/index.html)
    
*   [クーポン](https://dpoint.docomo.ne.jp/coupon.html)
    
*   [ポイント確認](https://dpoint.docomo.ne.jp/member/point_info/index.html)
    
*   [ランク確認](https://dpoint.docomo.ne.jp/member/stage_info/index.html)
    

設定・確認

*   [会員情報の確認・編集](https://profile.smt.docomo.ne.jp/VIEW_ESITE/mem/sc/main.jsp?nid=MEG002006BJP&dcmreturl=https%3A%2F%2Fdpoint%2edocomo%2ene%2ejp%2F)
    
*   [dポイントカード登録](https://dpoint.docomo.ne.jp/ctrw/register/s-001.html)
    
*   [dアカウント設定](https://id.smt.docomo.ne.jp/cgi7/id/menu?utm_source=dpointclub&utm_medium=owned&utm_campaign=dpc_202205_owned-dpc-daccount-menu)
    
*   [その他の設定・確認](https://dpoint.docomo.ne.jp/instruction/index.html)
    

サポート

*   [ご利用ガイド](https://dpoint.docomo.ne.jp/guide/index.html)
    
*   [よくあるご質問](https://dpoint.docomo.ne.jp/guide/faq/index.html)
    
*   [別のIDでログイン](https://cfg.smt.docomo.ne.jp/auth/cgi/anidlogin?rl=https%3A%2F%2Fdpoint%2edocomo%2ene%2ejp%2F%3Fdpc_home_adflg%3Dfalse)
    
*   [ログアウト](https://dpoint.docomo.ne.jp/api/logout.do?nl=https%3A%2F%2Fdpoint%2edocomo%2ene%2ejp%2F)
    

おすすめコンテンツ

*   [毎日くじ](https://service.smt.docomo.ne.jp/portal/special/collab/topics/src/dmenukuji_01.html?utm_source=dpointclub&utm_medium=owned&utm_campaign=dpc_202205_owned-dpc-daily-drawing)
    
*   [遊んでためる](https://dpoint.docomo.ne.jp/content/land/index.html)
    
*   [アンケートでためる](https://dpcq.macaron.docomo.ne.jp/?utm_source=dpointclub&utm_medium=owned&utm_campaign=dpc_202212_hmenu)
    
*   [キャンペーン](https://dpoint.docomo.ne.jp/campaign/)
    

たまる・つかえるお店

エリアからお店を探す

[地図から探す](https://dpoint.docomo.ne.jp/map/)
 [エリアから探す](https://dpoint.docomo.ne.jp/store/area/index.html)

サービス別でお店を探す

[dポイントカード（街のお店）](https://dpoint.docomo.ne.jp/store/real/index.html?sv=dpoint)
 [dポイント連携（ネットのお店）](https://dpoint.docomo.ne.jp/store/online/index.html?sv=dpoint)
 [d払い（街のお店）](https://dpoint.docomo.ne.jp/store/real/index.html?sv=dpay)
 [d払い（ネットのお店）](https://dpoint.docomo.ne.jp/store/online/index.html?sv=dpay)

ジャンルからお店を探す

[すべてのジャンルをみる](https://dpoint.docomo.ne.jp/store/category/index.html)
 [コンビニ](https://dpoint.docomo.ne.jp/static/store/category/st01/)
 [総合ネットショッピングサイト](https://dpoint.docomo.ne.jp/static/store/category/st30/)
 [ドラッグストア・化粧品](https://dpoint.docomo.ne.jp/static/store/category/st32/)
 [スーパーマーケット・ディスカウントストア](https://dpoint.docomo.ne.jp/static/store/category/st31/)
 [ショッピングセンター・ホームセンター](https://dpoint.docomo.ne.jp/static/store/category/st14/)
 [百貨店](https://dpoint.docomo.ne.jp/static/store/category/st15/)
 [家電量販店・AV機器](https://dpoint.docomo.ne.jp/static/store/category/st33/)
 [ファッション](https://dpoint.docomo.ne.jp/static/store/category/st02/)
 [食料品・日用品・生活雑貨](https://dpoint.docomo.ne.jp/static/store/category/st34/)
 [本・書籍・文房具](https://dpoint.docomo.ne.jp/static/store/category/st16/)
 [趣味（ショッピング）](https://dpoint.docomo.ne.jp/static/store/category/st35/)
 [その他ショッピング](https://dpoint.docomo.ne.jp/static/store/category/st36/)
 [ファーストフード](https://dpoint.docomo.ne.jp/static/store/category/st20/)
 [カフェ](https://dpoint.docomo.ne.jp/static/store/category/st21/)
 [スイーツ](https://dpoint.docomo.ne.jp/static/store/category/st38/)
 [レストラン](https://dpoint.docomo.ne.jp/static/store/category/st22/)
 [居酒屋・バー](https://dpoint.docomo.ne.jp/static/store/category/st23/)
 [デリバリー・テイクアウト](https://dpoint.docomo.ne.jp/static/store/category/st24/)
 [グルメ情報](https://dpoint.docomo.ne.jp/static/store/category/st03/)
 [レジャー](https://dpoint.docomo.ne.jp/static/store/category/st26/)
 [エンターテイメント・チケット](https://dpoint.docomo.ne.jp/static/store/category/st05/)
 [旅行](https://dpoint.docomo.ne.jp/static/store/category/st08/)
 [ホテル・旅館・宿泊施設](https://dpoint.docomo.ne.jp/static/store/category/st27/)
 [ガソリンスタンド](https://dpoint.docomo.ne.jp/static/store/category/st37/)
 [タクシー](https://dpoint.docomo.ne.jp/static/store/category/st06/)
 [車・レンタカー・駐車場](https://dpoint.docomo.ne.jp/static/store/category/st07/)
 [学習](https://dpoint.docomo.ne.jp/static/store/category/st11/)
 [趣味・カルチャー](https://dpoint.docomo.ne.jp/static/store/category/st25/)
 [新聞](https://dpoint.docomo.ne.jp/static/store/category/st09/)
 [エネルギー](https://dpoint.docomo.ne.jp/static/store/category/st04/)
 [ライフプラン](https://dpoint.docomo.ne.jp/static/store/category/st12/)
 [住まい・引越し](https://dpoint.docomo.ne.jp/static/store/category/st13/)
 [暮らし](https://dpoint.docomo.ne.jp/static/store/category/st10/)
 [美容・健康](https://dpoint.docomo.ne.jp/static/store/category/st19/)
 [海外](https://dpoint.docomo.ne.jp/static/store/category/st28/)
 [ポイント交換](https://dpoint.docomo.ne.jp/static/store/category/st17/)
 [その他のサービス](https://dpoint.docomo.ne.jp/static/store/category/st91/)

### 対応サービスについて

*   ![dポイントカード](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpcd_on.png)
    
    ### dポイントカード
    
    dポイントカードのご提示でたまる・つかえるお店です。詳しくは[こちら](https://dpoint.docomo.ne.jp/guide/about_dpointcard/index.html)
    
*   ![d払い](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpay_on.png)
    
    ### d払い
    
    d払いでお支払いいただけるお店です。詳しくは[こちら](https://service.smt.docomo.ne.jp/keitai_payment/?utm_source=dpointclub&utm_medium=owned&utm_campaign=dpc_202212_owned-dpc-dpayment-site-020904)
    
*   ![dポイントのアカウント連携](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_card_connect_on.png)
    
    ### dポイントのアカウント連携
    
    dポイントのアカウント連携でたまる・つかえるお店です。詳しくは[こちら](https://dpoint.docomo.ne.jp/guide/id_linkage/index.html)
    
*   ![dポイントマーケット](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpm_on.png)
    
    ### dポイントマーケット経由のご利用
    
    dポイントマーケットを経由することでさらにたまるお店です。詳しくは[こちら](https://dmarket.docomo.ne.jp/common/about/?utm_source=dpointclub&utm_medium=owned&utm_campaign=dpm_202410_int_0000001)
    

[他のサービスを確認する](https://dpoint.docomo.ne.jp/guide/about_dpointclub/store_service_icon/index.html)

### 対応サービスについて

*   ![dポイントのアカウント連携](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_card_connect_on.png)
    
    ### dポイントのアカウント連携
    
    dポイントのアカウント連携でたまる・つかえるお店です。詳しくは[こちら](https://dpoint.docomo.ne.jp/guide/id_linkage/index.html)
    
*   ![d払い](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpay_on.png)
    
    ### d払い
    
    d払いでお支払いいただけるお店です。詳しくは[こちら](https://service.smt.docomo.ne.jp/keitai_payment/?utm_source=dpointclub&utm_medium=owned&utm_campaign=dpc_202212_owned-dpc-dpayment-site-020904)
    
*   ![dポイントマーケット](https://dpoint.docomo.ne.jp/common/img/service_icon/store_ic_dpm_on.png)
    
    ### dポイントマーケット経由のご利用
    
    dポイントマーケットを経由することでさらにたまるお店です。詳しくは[こちら](https://dmarket.docomo.ne.jp/common/about/?utm_source=dpointclub&utm_medium=owned&utm_campaign=dpm_202410_int_0000001)
    

[他のサービスを確認する](https://dpoint.docomo.ne.jp/guide/about_dpointclub/store_service_icon/index.html)
