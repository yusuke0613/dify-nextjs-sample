# ahamo

URL: https://ahamo.com/

---

[申し込み](https://ahamo.com/store/pub/application/type)
[ログインページへ](https://ahamo.com/myportal/home/auth/)

*   [ホーム](https://ahamo.com/)
    
*   [ahamoについて](https://ahamo.com/about)
    
*   [申し込みの流れ](https://ahamo.com/flow)
    
*   [機種変更/eSIM変更の流れ](https://ahamo.com/flow/model-change/)
    
*   [料金/データ量](https://ahamo.com/plan)
    
*   [製品（一部製品割引中）](https://ahamo.com/products)
    
*   [予約の確認・キャンセル](https://ahamo.com/store/auth/reservation/)
    
*   [サービス](https://ahamo.com/services)
    
*   [キャンペーン](https://ahamo.com/campaigns)
    
*   [お知らせ](https://ahamo.com/news)
    
*   [通信・エリア](https://ahamo.com/area)
    
*   [おしえて！ahamoくん](https://ahamo.com/column)
    
*   [サポート](https://ahamo.com/support)
    
*   [よくある質問](https://faq.ahamo.com/?site_domain=default)
    
*   [問い合わせ](https://ahamo.com/contact)
    

*   [![Line](https://cache.cil.ahamo.com/assets/images/common/social-line.svg)](https://lin.ee/AypHcgi)
    
*   [![Facebook](https://cache.cil.ahamo.com/assets/images/common/social-facebook.svg)](https://m.facebook.com/ahamo.official/)
    
*   [![Instagram](https://cache.cil.ahamo.com/assets/images/common/social-instagram.svg)](https://www.instagram.com/ahamo_official/)
    
*   [![Twitter](https://cache.cil.ahamo.com/assets/images/common/social-twitter.svg)](https://twitter.com/ahamo_official)
    
*   [![Youtube](https://cache.cil.ahamo.com/assets/images/common/social-youtube.svg)](https://m.youtube.com/channel/UCkNj1J19_-2Zz2ZZNqhzTFA)
    

*   [企業情報](https://www.docomo.ne.jp/corporate/)
    
*   [当サイトについて  \
    （利用端末からの外部送信の案内含む）](https://ahamo.com/website)
    
*   [プライバシーポリシー](https://www.docomo.ne.jp/utility/privacy/)
    
*   [パーソナルデータについて](https://www.docomo.ne.jp/utility/personal_data/)
    
*   [約款・重要事項説明](https://ahamo.com/terms)
    
*   [特定商取引法に基づく表記](https://ahamo.com/assets/documents/specified_commerce.pdf)
    
*   [インターネット通信販売規約](https://ahamo.com/assets/documents/mailorder.pdf)
    
*   [古物商に基づく表記](https://ahamo.com/assets/documents/curio_dealer.pdf)
    

商品検索

おすすめ

[![ahamo](https://cache.cil.ahamo.com/assets/images/common/logo.svg)](https://ahamo.com/)

*   [ホーム](https://ahamo.com/)
    
*   [申し込みの流れ](https://ahamo.com/flow)
    
*   [料金/データ量](https://ahamo.com/plan)
    
*   [製品](https://ahamo.com/products)
    
*   [サポート](https://ahamo.com/support)
    

*   [申し込み](https://ahamo.com/store/pub/application/type/)
    
*   [ログイン](https://ahamo.com/myportal/home/auth/)
    

[![](https://cache.cil.ahamo.com/fsi0850000000qks-img/251119_ahamo_30GB_GR_banner_sitetop_pc.png)](https://ahamo.com/special/ahabaito/)

[今すぐ申し込み\
\
今すぐ申し込み](https://ahamo.com/store/pub/application/type/)
[申し込みの流れ\
\
申し込みの流れ](https://ahamo.com/flow/)

おすすめコンテンツやキャンペーン情報
------------------

*   [![ahamo紹介キャンペーン！ahamoを紹介すると7,000ポイント、紹介される方も最大13,000ポイントプレゼント！](https://cache.cil.ahamo.com/ima1bh00000049x4-img/referral_20251128.jpg)![ahamo紹介キャンペーン！ahamoを紹介すると7,000ポイント、紹介される方も最大13,000ポイントプレゼント！](https://cache.cil.ahamo.com/ima1bh00000049x4-img/referral_20251128.jpg)](https://ssw.web.docomo.ne.jp/ahamo/special/referral.html)
    
*   [![NBA docomo　アプリで楽しもう！！](https://cache.cil.ahamo.com/o3vi0o000000ibbj-img/nba_20251021.jpg)![NBA docomo　アプリで楽しもう！！](https://cache.cil.ahamo.com/o3vi0o000000ibbj-img/nba_20251021.jpg)](https://nba.docomo.ne.jp/lp/entry001/?utm_source=ahamo&utm_medium=owned&utm_campaign=nbaservicelp_202510_nbadocomo_ahamosplp1)
    
*   [![ahamo対象機種をおトクに購入しよう](https://cache.cil.ahamo.com/fb4je00000000bik-img/5g-welcome_wari_20251105.png)![ahamo対象機種をおトクに購入しよう](https://cache.cil.ahamo.com/fb4je00000000bik-img/5g-welcome_wari_20251105.png)](https://ahamo.com/special/lp/5g-welcome_wari.html)
    
*   [![今のスマホのまま他社から再びahamoへのお乗り換えでdポイントプレゼント！](https://cache.cil.ahamo.com/ima1bh0000001x2y-img/20251117_ahamo_okaeri.jpg)![今のスマホのまま他社から再びahamoへのお乗り換えでdポイントプレゼント！](https://cache.cil.ahamo.com/ima1bh0000001x2y-img/20251117_ahamo_okaeri.jpg)](https://ahamo.com/special/ahamo_okaeri/)
    
*   [![めちゃトク祭り｜ahamo](https://cache.cil.ahamo.com/fhqhpm0000009j06-img/metyatoku_251001.jpg)![めちゃトク祭り｜ahamo](https://cache.cil.ahamo.com/fhqhpm0000009j06-img/metyatoku_251001.jpg)](https://ahamo.com/special/metyatoku/)
    
*   [![ahamo×AI祭り｜ahamo](https://cache.cil.ahamo.com/o3vi0o000000g0cr-img/20250929_stellaai.jpg)![ahamo×AI祭り｜ahamo](https://cache.cil.ahamo.com/o3vi0o000000g0cr-img/20250929_stellaai.jpg)](https://ahamo.com/special/stellaai/)
    
*   [![若者ファーストのGOLDカード dカード GOLD U](https://cache.cil.ahamo.com/fhqhpm000000i7ij-img/GOLD_U_250701.jpg)![若者ファーストのGOLDカード dカード GOLD U](https://cache.cil.ahamo.com/fhqhpm000000i7ij-img/GOLD_U_250701.jpg)](https://dcard.docomo.ne.jp/std/campaigns/202410_1cm/dcard/index.html?tab=goldu&utm_source=callcenter&utm_medium=shortcut&utm_campaign=dcard_202507_ahamo-site&argument=WUUq3J3f&dmai=a6858d473ca599)
    
*   [![ahamo ポイ活　好評受付中！](https://cache.cil.ahamo.com/fb4je00000004elu-img/241201poikatsu_630%C3%97630.png)![ahamo ポイ活　好評受付中！](https://cache.cil.ahamo.com/fb4je00000004elu-img/241201poikatsu_630%C3%97630.png)](https://ahamo.com/special/poikatsu/)
    
*   [![ちょっと嬉しい特典がもらえるクエスト ahamoアプリで出現中 aha Quest 早速ahamoアプリをダウンロード！](https://cache.cil.ahamo.com/fsi0850000000cxg-img/230313_630x630.jpg)![ちょっと嬉しい特典がもらえるクエスト ahamoアプリで出現中 aha Quest 早速ahamoアプリをダウンロード！](https://cache.cil.ahamo.com/fsi0850000000cxg-img/230313_630x630.jpg)](https://ahamo.com/special/ahaquest_general/)
    
*   [![d NEOBANKからお知らせ　最大25,000円相当！今すぐ口座開設](https://cache.cil.ahamo.com/ima1bh0000003l22-img/dneobank_20251121.png)![d NEOBANKからお知らせ　最大25,000円相当！今すぐ口座開設](https://cache.cil.ahamo.com/ima1bh0000003l22-img/dneobank_20251121.png)](https://app.adjust.com/1uv7m0nd?redirect=https%3A%2F%2Fguide.netbk.co.jp%2Flp%2Fdneobank202510%2F)
    
*   [![ahamoへのお乗り換えでdポイントプレゼントキャンペーン](https://cache.cil.ahamo.com/fhqhpm0000002v11-img/dpointcp-20000pt_251008.jpg)![ahamoへのお乗り換えでdポイントプレゼントキャンペーン](https://cache.cil.ahamo.com/fhqhpm0000002v11-img/dpointcp-20000pt_251008.jpg)](https://ahamo.com/special/lp/dpointcp/001.html?utm_term=202410ahamoTOPspecial)
    
*   [![ahamo紹介キャンペーン！ahamoを紹介すると7,000ポイント、紹介される方も最大13,000ポイントプレゼント！](https://cache.cil.ahamo.com/ima1bh00000049x4-img/referral_20251128.jpg)![ahamo紹介キャンペーン！ahamoを紹介すると7,000ポイント、紹介される方も最大13,000ポイントプレゼント！](https://cache.cil.ahamo.com/ima1bh00000049x4-img/referral_20251128.jpg)](https://ssw.web.docomo.ne.jp/ahamo/special/referral.html)
    
*   [![NBA docomo　アプリで楽しもう！！](https://cache.cil.ahamo.com/o3vi0o000000ibbj-img/nba_20251021.jpg)![NBA docomo　アプリで楽しもう！！](https://cache.cil.ahamo.com/o3vi0o000000ibbj-img/nba_20251021.jpg)](https://nba.docomo.ne.jp/lp/entry001/?utm_source=ahamo&utm_medium=owned&utm_campaign=nbaservicelp_202510_nbadocomo_ahamosplp1)
    
*   [![ahamo対象機種をおトクに購入しよう](https://cache.cil.ahamo.com/fb4je00000000bik-img/5g-welcome_wari_20251105.png)![ahamo対象機種をおトクに購入しよう](https://cache.cil.ahamo.com/fb4je00000000bik-img/5g-welcome_wari_20251105.png)](https://ahamo.com/special/lp/5g-welcome_wari.html)
    
*   [![今のスマホのまま他社から再びahamoへのお乗り換えでdポイントプレゼント！](https://cache.cil.ahamo.com/ima1bh0000001x2y-img/20251117_ahamo_okaeri.jpg)![今のスマホのまま他社から再びahamoへのお乗り換えでdポイントプレゼント！](https://cache.cil.ahamo.com/ima1bh0000001x2y-img/20251117_ahamo_okaeri.jpg)](https://ahamo.com/special/ahamo_okaeri/)
    
*   [![めちゃトク祭り｜ahamo](https://cache.cil.ahamo.com/fhqhpm0000009j06-img/metyatoku_251001.jpg)![めちゃトク祭り｜ahamo](https://cache.cil.ahamo.com/fhqhpm0000009j06-img/metyatoku_251001.jpg)](https://ahamo.com/special/metyatoku/)
    
*   [![ahamo×AI祭り｜ahamo](https://cache.cil.ahamo.com/o3vi0o000000g0cr-img/20250929_stellaai.jpg)![ahamo×AI祭り｜ahamo](https://cache.cil.ahamo.com/o3vi0o000000g0cr-img/20250929_stellaai.jpg)](https://ahamo.com/special/stellaai/)
    
*   [![若者ファーストのGOLDカード dカード GOLD U](https://cache.cil.ahamo.com/fhqhpm000000i7ij-img/GOLD_U_250701.jpg)![若者ファーストのGOLDカード dカード GOLD U](https://cache.cil.ahamo.com/fhqhpm000000i7ij-img/GOLD_U_250701.jpg)](https://dcard.docomo.ne.jp/std/campaigns/202410_1cm/dcard/index.html?tab=goldu&utm_source=callcenter&utm_medium=shortcut&utm_campaign=dcard_202507_ahamo-site&argument=WUUq3J3f&dmai=a6858d473ca599)
    
*   [![ahamo ポイ活　好評受付中！](https://cache.cil.ahamo.com/fb4je00000004elu-img/241201poikatsu_630%C3%97630.png)![ahamo ポイ活　好評受付中！](https://cache.cil.ahamo.com/fb4je00000004elu-img/241201poikatsu_630%C3%97630.png)](https://ahamo.com/special/poikatsu/)
    
*   [![ちょっと嬉しい特典がもらえるクエスト ahamoアプリで出現中 aha Quest 早速ahamoアプリをダウンロード！](https://cache.cil.ahamo.com/fsi0850000000cxg-img/230313_630x630.jpg)![ちょっと嬉しい特典がもらえるクエスト ahamoアプリで出現中 aha Quest 早速ahamoアプリをダウンロード！](https://cache.cil.ahamo.com/fsi0850000000cxg-img/230313_630x630.jpg)](https://ahamo.com/special/ahaquest_general/)
    
*   [![d NEOBANKからお知らせ　最大25,000円相当！今すぐ口座開設](https://cache.cil.ahamo.com/ima1bh0000003l22-img/dneobank_20251121.png)![d NEOBANKからお知らせ　最大25,000円相当！今すぐ口座開設](https://cache.cil.ahamo.com/ima1bh0000003l22-img/dneobank_20251121.png)](https://app.adjust.com/1uv7m0nd?redirect=https%3A%2F%2Fguide.netbk.co.jp%2Flp%2Fdneobank202510%2F)
    
*   [![ahamoへのお乗り換えでdポイントプレゼントキャンペーン](https://cache.cil.ahamo.com/fhqhpm0000002v11-img/dpointcp-20000pt_251008.jpg)![ahamoへのお乗り換えでdポイントプレゼントキャンペーン](https://cache.cil.ahamo.com/fhqhpm0000002v11-img/dpointcp-20000pt_251008.jpg)](https://ahamo.com/special/lp/dpointcp/001.html?utm_term=202410ahamoTOPspecial)
    
*   [![ahamo紹介キャンペーン！ahamoを紹介すると7,000ポイント、紹介される方も最大13,000ポイントプレゼント！](https://cache.cil.ahamo.com/ima1bh00000049x4-img/referral_20251128.jpg)![ahamo紹介キャンペーン！ahamoを紹介すると7,000ポイント、紹介される方も最大13,000ポイントプレゼント！](https://cache.cil.ahamo.com/ima1bh00000049x4-img/referral_20251128.jpg)](https://ssw.web.docomo.ne.jp/ahamo/special/referral.html)
    
*   [![NBA docomo　アプリで楽しもう！！](https://cache.cil.ahamo.com/o3vi0o000000ibbj-img/nba_20251021.jpg)![NBA docomo　アプリで楽しもう！！](https://cache.cil.ahamo.com/o3vi0o000000ibbj-img/nba_20251021.jpg)](https://nba.docomo.ne.jp/lp/entry001/?utm_source=ahamo&utm_medium=owned&utm_campaign=nbaservicelp_202510_nbadocomo_ahamosplp1)
    
*   [![ahamo対象機種をおトクに購入しよう](https://cache.cil.ahamo.com/fb4je00000000bik-img/5g-welcome_wari_20251105.png)![ahamo対象機種をおトクに購入しよう](https://cache.cil.ahamo.com/fb4je00000000bik-img/5g-welcome_wari_20251105.png)](https://ahamo.com/special/lp/5g-welcome_wari.html)
    
*   [![今のスマホのまま他社から再びahamoへのお乗り換えでdポイントプレゼント！](https://cache.cil.ahamo.com/ima1bh0000001x2y-img/20251117_ahamo_okaeri.jpg)![今のスマホのまま他社から再びahamoへのお乗り換えでdポイントプレゼント！](https://cache.cil.ahamo.com/ima1bh0000001x2y-img/20251117_ahamo_okaeri.jpg)](https://ahamo.com/special/ahamo_okaeri/)
    
*   [![めちゃトク祭り｜ahamo](https://cache.cil.ahamo.com/fhqhpm0000009j06-img/metyatoku_251001.jpg)![めちゃトク祭り｜ahamo](https://cache.cil.ahamo.com/fhqhpm0000009j06-img/metyatoku_251001.jpg)](https://ahamo.com/special/metyatoku/)
    
*   [![ahamo×AI祭り｜ahamo](https://cache.cil.ahamo.com/o3vi0o000000g0cr-img/20250929_stellaai.jpg)![ahamo×AI祭り｜ahamo](https://cache.cil.ahamo.com/o3vi0o000000g0cr-img/20250929_stellaai.jpg)](https://ahamo.com/special/stellaai/)
    
*   [![若者ファーストのGOLDカード dカード GOLD U](https://cache.cil.ahamo.com/fhqhpm000000i7ij-img/GOLD_U_250701.jpg)![若者ファーストのGOLDカード dカード GOLD U](https://cache.cil.ahamo.com/fhqhpm000000i7ij-img/GOLD_U_250701.jpg)](https://dcard.docomo.ne.jp/std/campaigns/202410_1cm/dcard/index.html?tab=goldu&utm_source=callcenter&utm_medium=shortcut&utm_campaign=dcard_202507_ahamo-site&argument=WUUq3J3f&dmai=a6858d473ca599)
    
*   [![ahamo ポイ活　好評受付中！](https://cache.cil.ahamo.com/fb4je00000004elu-img/241201poikatsu_630%C3%97630.png)![ahamo ポイ活　好評受付中！](https://cache.cil.ahamo.com/fb4je00000004elu-img/241201poikatsu_630%C3%97630.png)](https://ahamo.com/special/poikatsu/)
    
*   [![ちょっと嬉しい特典がもらえるクエスト ahamoアプリで出現中 aha Quest 早速ahamoアプリをダウンロード！](https://cache.cil.ahamo.com/fsi0850000000cxg-img/230313_630x630.jpg)![ちょっと嬉しい特典がもらえるクエスト ahamoアプリで出現中 aha Quest 早速ahamoアプリをダウンロード！](https://cache.cil.ahamo.com/fsi0850000000cxg-img/230313_630x630.jpg)](https://ahamo.com/special/ahaquest_general/)
    

[キャンペーン一覧\
\
キャンペーン一覧](https://ahamo.com/campaigns)
[お知らせ\
\
お知らせ](https://ahamo.com/news)

1

プランはわかりやすく
----------

![](https://cache.cil.ahamo.com/assets/images/pages/top/balloon-plan-section.png)

20GBから  
パワーアップ！

![ahamo](https://cache.cil.ahamo.com/assets/images/common/logo-price-plan.svg)

基本料金

30

GB

2,970円

_

国内通話料金 5分/回 無料

  

テザリングOK

_

![ahamo-oomori](https://cache.cil.ahamo.com/assets/images/common/logo-oomori-price-plan.svg)

110

GB

＊1

4,950円

_

国内通話料金 5分/回 無料

  

テザリングOK

_

![](data:image/svg+xml,%3csvg height='18' width='18' xmlns='http://www.w3.org/2000/svg'%3e%3cg fill='white'%3e%3cpath d='M11.278 17.5H6.722v-6.223H.5V6.723h6.222V.5h4.556v6.223H17.5v4.554h-6.222V17z'/%3e%3cpath d='M10.778 17v-6.223H17V7.223h-6.222V1H7.222v6.223H1v3.554h6.222V17zm1 1H6.222v-6.223H0V6.223h6.222V0h5.556v6.223H18v5.554h-6.222z' fill='%23707070'/%3e%3c/g%3e%3c/svg%3e)

大盛り契約者限定！

![](https://cache.cil.ahamo.com/assets/images/common/point-activity-option.svg)

2,200円/月（税込）＊2＊3

d払い・  
dカード還元率

+3%＊4＊5

![](https://cache.cil.ahamo.com/assets/images/common/balloon-for-point-activity.png)

dポイント（期間用途限定）

最大4000pt還元

[ポイ活オプションについて](https://ahamo.com/special/poikatsu/)

*   30GB（2,970円/月）に80GBの大盛りオプション（1,980円/月）を追加した価格です。
*   ポイ活オプションの申し込みには大盛りオプションへの加入が必要です。
*   d払いの支払い方法を電話料金合算払い、dカードでの支払い、d払い残高に設定された支払いのみが対象です。電話料金合算払いの利用において、電話料金の支払い方法にdカード以外のクレジットカードを設定されている場合は、dポイント進呈の対象外となります。
*   d払い決済（ｄ払い商品等購入代金）の金額の還元率は、ahamo回線のご利用料金の支払い方法をdカード又はdカード GOLD U、 dカード GOLD、dカード PLATINUMに設定するとともに、ahamoの携帯電話番号をdカード GOLD U/dカード GOLDのご利用携帯電話番号として登録することで+5%還元、dカード PLATINUMのご利用携帯電話番号として登録することで+10%還元となります。
*   キャンペーン等により還元率が変動する場合があります。
*   機種代金が別途かかります。
*   SMS、他社接続サービスなどへの発信は、別途料金がかかります。

[料金・データ量](https://ahamo.com/plan#with-phone)

2

3

ahamoにする人、ぞくぞくと
---------------

オンラインでの申し込みが得意な人だけじゃない。  
ahamoはみんなが使えているよ！

ahamoは若者のためだけじゃない。  
世代を超えてみんなが使っているよ！

![現在も増加中](https://cache.cil.ahamo.com/assets/images/pages/top/balloon-area-section.png)

現在も  
増加中

2024年9月現在は

_600万人_いるよ！

[まずは、申込みの流れを確認！](https://ahamo.com/flow/)

3

4

いつでも、どこでもつながる
-------------

docomoと同じ電波が、国内はもちろん、  
海外でも最大2週間そのまま使える！

![いつでも、どこでもつながる](https://cache.cil.ahamo.com/assets/images/pages/top/balloon-join-section.png)

海外91カ国で  
データ通信可能

日本人の渡航先

_約98%_をカバー！

[海外データ通信を利用したい！](https://ahamo.com/services/roaming-data/)
[通信・エリア](https://ahamo.com/area/)

Line-up

ahamoおすすめの製品
------------

みんなに愛されるahamoおすすめの製品をご紹介。

*   [キャンペーン対象\
    \
    ![](https://cache.cil.ahamo.com/products/rtfh14000000hu78-img/aquos-wish5-sh-52f-thumbnail.jpg)\
    \
    AQUOS wish5 SH-52F](https://ahamo.com/products/android/aquos-wish5-sh52f/)
    
*   [![](https://cache.cil.ahamo.com/products/rtfh14000000hzvn-img/galaxy-a36-sc-54f-thumbnail.jpg)\
    \
    Samsung Galaxy A36 5G SC-54F](https://ahamo.com/products/android/samsung-galaxy-a36-5g-sc54f/)
    
*   [キャンペーン対象\
    \
    ![](https://cache.cil.ahamo.com/products/rtfh14000000y5dj-img/iPhone-17-Pro-thumbnail.jpg)\
    \
    iPhone 17 Pro](https://ahamo.com/products/iphone/iphone-17-pro/)
    
*   [キャンペーン対象\
    \
    ![](https://cache.cil.ahamo.com/products/rtfh14000000y37k-img/iPhone-17-Pro-Max-thumbnail.jpg)\
    \
    iPhone 17 Pro Max](https://ahamo.com/products/iphone/iphone-17-pro-max/)
    
*   [キャンペーン対象\
    \
    ![](https://cache.cil.ahamo.com/products/rtfh14000000y5wj-img/iPhone-Air-thumbnail.jpg)\
    \
    iPhone Air](https://ahamo.com/products/iphone/iphone-air/)
    
*   [キャンペーン対象\
    \
    ![](https://cache.cil.ahamo.com/products/rtfh14000000xqtf-img/iPhone-17-thumbnail.jpg)\
    \
    iPhone 17](https://ahamo.com/products/iphone/iphone-17/)
    
*   [キャンペーン対象\
    \
    ![](https://cache.cil.ahamo.com/products/rtfh14000000idqv-img/iphone-16-thumbnail.jpg)\
    \
    iPhone 16](https://ahamo.com/products/iphone/iphone-16/)
    
*   [キャンペーン対象\
    \
    ![](https://cache.cil.ahamo.com/products/rtfh14000000z8qp-img/google-pixel-10-thumbnail.jpg)\
    \
    Google Pixel 10 128GB](https://ahamo.com/products/android/google-pixel-10-128gb/)
    
*   [![](https://cache.cil.ahamo.com/products/rtfh14000000z90i-img/google-pixel-10-thumbnail.jpg)\
    \
    Google Pixel 10 256GB](https://ahamo.com/products/android/google-pixel-10-256gb/)
    
*   [キャンペーン対象\
    \
    ![](https://cache.cil.ahamo.com/products/rtfh14000000hu2r-img/google-pixel-9a-thumbnail.jpg)\
    \
    Google Pixel 9a 128GB](https://ahamo.com/products/android/google-pixel-9a-128gb)
    
*   [キャンペーン対象\
    \
    ![](https://cache.cil.ahamo.com/products/rtfh14000000hzzw-img/google-pixel-9a-thumbnail.jpg)\
    \
    Google Pixel 9a 256GB](https://ahamo.com/products/android/google-pixel-9a-256gb)
    
*   [キャンペーン対象\
    \
    ![](https://cache.cil.ahamo.com/products/rtfh14000000z9gv-img/motorola-razr-60d-M-51F-thumbnail.jpg)\
    \
    motorola razr 60d M-51F](https://ahamo.com/products/android/motorola-razr-60d-m51f/)
    
*   [キャンペーン対象\
    \
    ![](https://cache.cil.ahamo.com/products/rtfh14000000hu78-img/aquos-wish5-sh-52f-thumbnail.jpg)\
    \
    AQUOS wish5 SH-52F](https://ahamo.com/products/android/aquos-wish5-sh52f/)
    
*   [![](https://cache.cil.ahamo.com/products/rtfh14000000hzvn-img/galaxy-a36-sc-54f-thumbnail.jpg)\
    \
    Samsung Galaxy A36 5G SC-54F](https://ahamo.com/products/android/samsung-galaxy-a36-5g-sc54f/)
    
*   [キャンペーン対象\
    \
    ![](https://cache.cil.ahamo.com/products/rtfh14000000y5dj-img/iPhone-17-Pro-thumbnail.jpg)\
    \
    iPhone 17 Pro](https://ahamo.com/products/iphone/iphone-17-pro/)
    
*   [キャンペーン対象\
    \
    ![](https://cache.cil.ahamo.com/products/rtfh14000000y37k-img/iPhone-17-Pro-Max-thumbnail.jpg)\
    \
    iPhone 17 Pro Max](https://ahamo.com/products/iphone/iphone-17-pro-max/)
    

[製品一覧\
\
製品一覧](https://ahamo.com/products/)

[![新規契約・お乗り換えを検討中のあなたへ！ahamoでスマホをおトクに購入しよう！](https://cache.cil.ahamo.com/discount/fhqhpm000000lxic-img/60500-8800_1324_208.png)](https://ahamo.com/special/lp/5g-welcome_wari.html)

ahamoアプリで  
もっとおトクに、  
かんたんに
----------------------------

ahamoアプリをダウンロードしておくと、おトクな特典がもらえるよ。データ通信量等の確認もかんたん。

データ通信量の  
確認と  
大盛りへの  
変更ができる！

ahaクエストに  
挑戦して  
特典をGET！

いつでもサポートが  
受けられて  
あんしん！

累計500万ダウンロード

[![App Store からダウンロード](https://cache.cil.ahamo.com/assets/images/common/app-store-badge.svg)](https://apps.apple.com/jp/app/id1542920778)
[![Google Play で手に入れよう](https://cache.cil.ahamo.com/assets/images/common/google-play-badge.svg)](https://play.google.com/store/apps/details?id=com.nttdocomo.android.myahamo)

[アプリでできることを確認する](https://ahamo.com/app/)

さあこれから、 どんな自分に 会いに行こうか。 さあこれから、 どんな自分に会いに行こうか。 楽しい、うれしい、なるほど、ワクワク。 前向きな気持ちが全部詰まった モバイルサービス。 楽しい、うれしい、なるほど、ワクワク。 前向きな気持ちが全部詰まったモバイルサービス。

[ahamoについて\
\
ahamoについて](https://ahamo.com/about)

*   [![Line](https://cache.cil.ahamo.com/assets/images/common/social-line.svg)](https://lin.ee/AypHcgi)
    
*   [![Facebook](https://cache.cil.ahamo.com/assets/images/common/social-facebook.svg)](https://m.facebook.com/ahamo.official/)
    
*   [![Instagram](https://cache.cil.ahamo.com/assets/images/common/social-instagram.svg)](https://www.instagram.com/ahamo_official/)
    
*   [![Twitter](https://cache.cil.ahamo.com/assets/images/common/social-twitter.svg)](https://twitter.com/ahamo_official)
    
*   [![Youtube](https://cache.cil.ahamo.com/assets/images/common/social-youtube.svg)](https://m.youtube.com/channel/UCkNj1J19_-2Zz2ZZNqhzTFA)
    

*   メニュー
    
*   [申し込みの流れ](https://ahamo.com/flow)
    
*   [料金/データ量](https://ahamo.com/plan)
    
*   [製品](https://ahamo.com/products)
    
*   [サポート](https://ahamo.com/support)
    

©NTT DOCOMO, INC. All Rights Reserved.
