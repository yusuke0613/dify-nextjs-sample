# ドコモのクレジットカード ｜ dカード

URL: https://dcard.docomo.ne.jp/

---

[![dカード PLATINUMが100万会員突破！](https://dcard.docomo.ne.jp/st/images/PC_top_v12.jpg)](https://dcard.docomo.ne.jp/std/campaigns/1cm/platinum-1million/index.html?argument=WUUq3J3f&dmai=a690321f46e2be)

RECOMMEND CONTENT

おすすめコンテンツ
---------

[![期間中のiD利用で当たる！50％キャッシュバックキャンペーン実施中！](https://dcard.docomo.ne.jp/st/images/pict_mainimage_idcashback2512_sp.jpg)](https://id-credit.com/campaign/cashback2512/index.html?utm_source=web&utm_medium=dcard_top_sp&utm_campaign=cashback2512)

[![ドコモのスマート先輩ウォッチング](https://dcard.docomo.ne.jp/st/images/pict_mainimage_crosuse2504_sp.jpg)](https://www.docomo.ne.jp/product/promotion/cross_use/?movieid=soSJp0JcN1U&utm_source=dcard&utm_medium=free-display&utm_campaign=corp_202504_from-dcard-to-crp-prd-promotion-cross-use-250326)

[![【dポイントクラブ】dポイントとd払いで毎日たまって毎日おトクに！](https://dcard.docomo.ne.jp/st/images/pict_mainimage_newrank2504_sp.jpg)](https://dpoint.docomo.ne.jp/info/newrank_2024/index.html?utm_source=dcard_service&utm_medium=free-display&utm_campaign=dpayment_202410_newrank-site-cp-otokupage)

[![分割払いご利用で1億ポイント山分けキャンペーン](https://dcard.docomo.ne.jp/st/images/pict_mainimage_split100million2511_sp.jpg)](https://dcard.docomo.ne.jp/std/campaigns/202511_fn/cpn-split100million/index.html)

[![年末年始や冬、春旅行の計画はお早めに！dポイントがたまる旅行予約サイトをチェック](https://dcard.docomo.ne.jp/st/images/pict_mainimage_pointmall2512_sp.jpg)](https://pointmall.dcard.docomo.ne.jp/event/363/?utm_source=dcard&utm_medium=owned&utm_campaign=site_top_rotation_251201)

[![dNEOBANK|簡単サクッと開設！特典合算で最大2.5万円相当GET！](https://dcard.docomo.ne.jp/st/images/pict_mainimage_dneobank2512_sp.jpg)](https://app.adjust.com/1un9sre7?redirect=https%3A%2F%2Fguide.netbk.co.jp%2Flp%2Fdneobank202510%2F)

[![【毎月５のつく日がお得】エントリー＆dカード支払いで5,500円以上のお買い物がポイント10倍](https://dcard.docomo.ne.jp/st/images/pict_mainimage_dfashion_sp.jpg)](https://dfashion.docomo.ne.jp/static/cont/id_cpDCARD10)

[![dカード会員限定｜THE MUSIC STADIUM](https://dcard.docomo.ne.jp/st/images/pict_mainimage_oneokrock2512_sp.jpg)](https://ssw.web.docomo.ne.jp/ticket/themusicstadium/)

[![【かんたん資産運用】条件達成後、対象のお店にてd払いでお買物をすると決済額の20%をもれなくdポイントで還元！](https://dcard.docomo.ne.jp/st/images/pict_mainimage_monex2512_sp.jpg)](https://monex.docomo.ne.jp/campaign/dpay2512/index.html?utm_source=dcard&utm_medium=dcard_pull_site_top&utm_campaign=dpay2512&utm_term=dpay2512_dpay2512&utm_content=1952_docomo&acOpenChannel=d04a02656)

[![dカード・dカード GOLD会員限定！dスマホローン契約で1,000pt進呈](https://dcard.docomo.ne.jp/st/images/pict_mainimage_loan2411_sp.jpg)](https://lp.loan.docomo.ne.jp/lp/dcard/?utm_source=dcard&utm_medium=owned&utm_campaign=DSL221102_dpt_lp9&utm_term=top)

[![期間中のiD利用で当たる！50％キャッシュバックキャンペーン実施中！](https://dcard.docomo.ne.jp/st/images/pict_mainimage_idcashback2512_sp.jpg)](https://id-credit.com/campaign/cashback2512/index.html?utm_source=web&utm_medium=dcard_top_sp&utm_campaign=cashback2512)

[![ドコモのスマート先輩ウォッチング](https://dcard.docomo.ne.jp/st/images/pict_mainimage_crosuse2504_sp.jpg)](https://www.docomo.ne.jp/product/promotion/cross_use/?movieid=soSJp0JcN1U&utm_source=dcard&utm_medium=free-display&utm_campaign=corp_202504_from-dcard-to-crp-prd-promotion-cross-use-250326)

[![【dポイントクラブ】dポイントとd払いで毎日たまって毎日おトクに！](https://dcard.docomo.ne.jp/st/images/pict_mainimage_newrank2504_sp.jpg)](https://dpoint.docomo.ne.jp/info/newrank_2024/index.html?utm_source=dcard_service&utm_medium=free-display&utm_campaign=dpayment_202410_newrank-site-cp-otokupage)

[![分割払いご利用で1億ポイント山分けキャンペーン](https://dcard.docomo.ne.jp/st/images/pict_mainimage_split100million2511_sp.jpg)](https://dcard.docomo.ne.jp/std/campaigns/202511_fn/cpn-split100million/index.html)

[![年末年始や冬、春旅行の計画はお早めに！dポイントがたまる旅行予約サイトをチェック](https://dcard.docomo.ne.jp/st/images/pict_mainimage_pointmall2512_sp.jpg)](https://pointmall.dcard.docomo.ne.jp/event/363/?utm_source=dcard&utm_medium=owned&utm_campaign=site_top_rotation_251201)

[![dNEOBANK|簡単サクッと開設！特典合算で最大2.5万円相当GET！](https://dcard.docomo.ne.jp/st/images/pict_mainimage_dneobank2512_sp.jpg)](https://app.adjust.com/1un9sre7?redirect=https%3A%2F%2Fguide.netbk.co.jp%2Flp%2Fdneobank202510%2F)

[![【毎月５のつく日がお得】エントリー＆dカード支払いで5,500円以上のお買い物がポイント10倍](https://dcard.docomo.ne.jp/st/images/pict_mainimage_dfashion_sp.jpg)](https://dfashion.docomo.ne.jp/static/cont/id_cpDCARD10)

[![dカード会員限定｜THE MUSIC STADIUM](https://dcard.docomo.ne.jp/st/images/pict_mainimage_oneokrock2512_sp.jpg)](https://ssw.web.docomo.ne.jp/ticket/themusicstadium/)

[![【かんたん資産運用】条件達成後、対象のお店にてd払いでお買物をすると決済額の20%をもれなくdポイントで還元！](https://dcard.docomo.ne.jp/st/images/pict_mainimage_monex2512_sp.jpg)](https://monex.docomo.ne.jp/campaign/dpay2512/index.html?utm_source=dcard&utm_medium=dcard_pull_site_top&utm_campaign=dpay2512&utm_term=dpay2512_dpay2512&utm_content=1952_docomo&acOpenChannel=d04a02656)

[![dカード・dカード GOLD会員限定！dスマホローン契約で1,000pt進呈](https://dcard.docomo.ne.jp/st/images/pict_mainimage_loan2411_sp.jpg)](https://lp.loan.docomo.ne.jp/lp/dcard/?utm_source=dcard&utm_medium=owned&utm_campaign=DSL221102_dpt_lp9&utm_term=top)

*   [dカード PLATINUMの  \
    詳細と申し込みはこちら](https://dcard.docomo.ne.jp/st/dcard_platinum/index.html)
    
*   [dカード GOLDの  \
    詳細と申し込みはこちら](https://dcard.docomo.ne.jp/st/dcard_gold/index.html)
    
*   [dカード GOLD Uの  \
    詳細と申し込みはこちら](https://dcard.docomo.ne.jp/st/dcard_goldu/index.html)
    
*   [dカードの  \
    詳細と申し込みはこちら](https://dcard.docomo.ne.jp/st/dcard_dcard/index.html)
    

[ご利用状況の確認  \
(会員の方)はこちら](https://dcard.docomo.ne.jp/dsw/top/)

*   [dカード PLATINUMの  \
    詳細と申し込みはこちら](https://dcard.docomo.ne.jp/st/dcard_platinum/index.html)
    
*   [dカード GOLDの  \
    詳細と申し込みはこちら](https://dcard.docomo.ne.jp/st/dcard_gold/index.html)
    
*   [dカード GOLD Uの  \
    詳細と申し込みはこちら](https://dcard.docomo.ne.jp/st/dcard_goldu/index.html)
    
*   [新しいdカードの  \
    詳細と申し込みはこちら](https://dcard.docomo.ne.jp/st/s_dcard/index.html)
    

[ご利用状況の確認  \
(会員の方)はこちら](https://dcard.docomo.ne.jp/dsw/top/)

*   [dカード PLATINUMの  \
    詳細と申し込みはこちら](https://dcard.docomo.ne.jp/st/dcard_platinum/index.html)
    
*   [新しいdカードの  \
    詳細と申し込みはこちら](https://dcard.docomo.ne.jp/st/s_dcard/index.html)
    
*   [ご利用状況の確認  \
    (会員の方)はこちら](https://dcard.docomo.ne.jp/dsw/top/)
    

[ご利用状況の確認  \
(会員の方)はこちら](https://dcard.docomo.ne.jp/dsw/top/)

*   [dカード PLATINUMの  \
    詳細と申し込みはこちら](https://dcard.docomo.ne.jp/st/dcard_platinum/index.html)
    
*   [dカード GOLDの  \
    詳細と申し込みはこちら](https://dcard.docomo.ne.jp/st/dcard_gold/index.html)
    
*   [ご利用状況の確認  \
    (会員の方)はこちら](https://dcard.docomo.ne.jp/dsw/top/)
    

[![](https://dcard.docomo.ne.jp/common/images/dCARD_platinum_VISA.jpg)\
\
dカード PLATINUMの  \
詳細と申し込みはこちら](https://dcard.docomo.ne.jp/st/dcard_platinum/index.html)

[![](https://dcard.docomo.ne.jp/common/images/dCARD_gold_VISA.jpg)\
\
dカード GOLDの  \
詳細と申し込みはこちら](https://dcard.docomo.ne.jp/st/dcard_gold/index.html)

[![](https://dcard.docomo.ne.jp/common/images/dCARD_gold_u_VISA.png)\
\
dカード GOLD Uの  \
詳細と申し込みはこちら](https://dcard.docomo.ne.jp/st/dcard_goldu/index.html)

[![](https://dcard.docomo.ne.jp/common/images/dCARD_REGULAR_white_VISA.jpg)\
\
dカードの  \
詳細と申し込みはこちら](https://dcard.docomo.ne.jp/st/dcard_dcard/index.html)

[![](https://dcard.docomo.ne.jp/images/pict_goriyojokyo.jpg)\
\
ご利用状況の確認  \
(会員の方)はこちら](https://dcard.docomo.ne.jp/dsw/top/)

[![](https://dcard.docomo.ne.jp/common/images/dCARD_platinum_VISA.jpg)\
\
dカード PLATINUMの  \
詳細と申し込みはこちら](https://dcard.docomo.ne.jp/st/dcard_platinum/index.html)

[![](https://dcard.docomo.ne.jp/common/images/dCARD_gold_VISA.jpg)\
\
dカード GOLDの  \
詳細と申し込みはこちら](https://dcard.docomo.ne.jp/st/dcard_gold/index.html)

[![](https://dcard.docomo.ne.jp/common/images/dCARD_gold_u_VISA.png)\
\
dカード GOLD Uの  \
詳細と申し込みはこちら](https://dcard.docomo.ne.jp/st/dcard_goldu/index.html)

[![](https://dcard.docomo.ne.jp/common/images/dCARD_REGULAR_white_VISA.jpg)\
\
新しいdカードの  \
詳細と申し込みはこちら](https://dcard.docomo.ne.jp/st/s_dcard/index.html)

[![](https://dcard.docomo.ne.jp/images/pict_goriyojokyo.jpg)\
\
ご利用状況の確認  \
(会員の方)はこちら](https://dcard.docomo.ne.jp/dsw/top/)

[![](https://dcard.docomo.ne.jp/common/images/dCARD_platinum_VISA.jpg)\
\
dカード PLATINUMの  \
詳細と申し込みはこちら](https://dcard.docomo.ne.jp/st/dcard_platinum/index.html)

[![](https://dcard.docomo.ne.jp/common/images/dCARD_gold_VISA.jpg)\
\
新しいdカードの  \
詳細と申し込みはこちら](https://dcard.docomo.ne.jp/st/s_dcard/index.html)

[![](https://dcard.docomo.ne.jp/images/pict_goriyojokyo.jpg)\
\
ご利用状況の確認  \
(会員の方)はこちら](https://dcard.docomo.ne.jp/dsw/top/)

[![](https://dcard.docomo.ne.jp/images/pict_goriyojokyo.jpg)\
\
ご利用状況の確認  \
(会員の方)はこちら](https://dcard.docomo.ne.jp/dsw/top/)

[![](https://dcard.docomo.ne.jp/common/images/dCARD_platinum_VISA.jpg)\
\
dカード PLATINUMの  \
詳細と申し込みはこちら](https://dcard.docomo.ne.jp/st/dcard_platinum/index.html)

[![](https://dcard.docomo.ne.jp/common/images/dCARD_gold_VISA.jpg)\
\
dカード GOLDの  \
詳細と申し込みはこちら](https://dcard.docomo.ne.jp/st/dcard_gold/index.html)

[![](https://dcard.docomo.ne.jp/images/pict_goriyojokyo.jpg)\
\
ご利用状況の確認  \
(会員の方)はこちら](https://dcard.docomo.ne.jp/dsw/top/)

RECOMMEND CARD

おすすめカード
-------

還元率がプラチナ級

### dカード PLATINUM

ポインコデザイン（縦）

![ポインコデザイン（縦）](https://dcard.docomo.ne.jp/st/common/images/poinco_platinum_VISA_2--bg_none.png)

 

通常デザイン

![通常デザイン](https://dcard.docomo.ne.jp/st/common/images/dCARD_platinum_VISA_2--bg_none.png)

 

ポインコデザイン（横）

![ポインコデザイン（横）](https://dcard.docomo.ne.jp/st/common/images/poincoillust_platinum_VISA_2--bg_none.png)

 

ポインコデザイン（縦）

![ポインコデザイン（縦）](https://dcard.docomo.ne.jp/st/common/images/poinco_platinum_VISA_2--bg_none.png)

 

通常デザイン

![通常デザイン](https://dcard.docomo.ne.jp/st/common/images/dCARD_platinum_VISA_2--bg_none.png)

 

![通常デザイン](https://dcard.docomo.ne.jp/st/common/images/dCARD_platinum_VISA.jpg)

![ポインコデザイン（横）](https://dcard.docomo.ne.jp/st/common/images/poincoillust_platinum_VISA.jpg)

![ポインコデザイン（縦）](https://dcard.docomo.ne.jp/st/common/images/poinco_platinum_VISA_2--bg_none.png)

*   ![](https://dcard.docomo.ne.jp/images/img_top_icon_reduction.png)毎月のドコモケータイ／「ドコモ光」  
    ご利用料金の最大20%ポイント還元
*   ![](https://dcard.docomo.ne.jp/images/img_top_icon_compensation.png)ケータイ補償3年間で最大20万円
*   ![](https://dcard.docomo.ne.jp/images/img_top_icon_lounge.png)国内・海外の主要空港ラウンジ利用無料

[詳細とお申込み](https://dcard.docomo.ne.jp/st/dcard_platinum/index.html)

[Webエントリー&入会翌々月末までに  \
80万円(税込)以上のお買物で  \
20,000ポイント（期間・用途限定）進呈](https://dcard.docomo.ne.jp/std/campaigns/202506_1cm/cpn-platinumshinki-tokuten/index.html)

ドコモユーザーのために考え抜かれた一枚

### dカード GOLD

ポインコデザイン（イラスト）

![ポインコデザイン（イラスト）](https://dcard.docomo.ne.jp/st/common/images/poincoillust_gold_VISA--bg_none.png)

 

通常デザイン

![通常デザイン](https://dcard.docomo.ne.jp/st/common/images/dCARD_gold_VISA--bg_none.png)

 

ポインコデザイン（実写）

![ポインコデザイン（実写）](https://dcard.docomo.ne.jp/st/common/images/poinco_gold_VISA--bg_none.png)

 

ポインコデザイン（イラスト）

![ポインコデザイン（イラスト）](https://dcard.docomo.ne.jp/st/common/images/poincoillust_gold_VISA--bg_none.png)

 

通常デザイン

![通常デザイン](https://dcard.docomo.ne.jp/st/common/images/dCARD_gold_VISA--bg_none.png)

 

![通常デザイン](https://dcard.docomo.ne.jp/st/common/images/dCARD_gold_VISA.jpg)

![ポインコデザイン（実写）](https://dcard.docomo.ne.jp/st/common/images/poinco_gold_VISA.jpg)

![ポインコデザイン（イラスト）](https://dcard.docomo.ne.jp/st/common/images/poincoillust_gold_VISA.jpg)

*   ![](https://dcard.docomo.ne.jp/images/img_top_icon_reduction.png)毎月のドコモケータイ／「ドコモ光」  
    ご利用料金の10%ポイント還元
*   ![](https://dcard.docomo.ne.jp/images/img_top_icon_compensation.png)ケータイ補償3年間で最大10万円
*   ![](https://dcard.docomo.ne.jp/images/img_top_icon_lounge.png)国内・ハワイの主要空港ラウンジ利用無料

[詳細とお申込み](https://dcard.docomo.ne.jp/st/dcard_gold/index.html)

[入会＆利用＆Webエントリーで  \
最大3,000ポイント（期間・用途限定）進呈](https://dcard.docomo.ne.jp/std/campaigns/202506_1cm/cpn-goldshinki-tokuten/index.html)

若者ファーストのGOLDカード

### dカード GOLD U

ポインコデザイン（縦）

![ポインコデザイン（縦）](https://dcard.docomo.ne.jp/st/common/images/poinco_goldu_VISA_2--bg_none.png)

 

通常デザイン

![通常デザイン](https://dcard.docomo.ne.jp/st/common/images/dCARD_gold_u_VISA.png)

 

ポインコデザイン（縦）

![ポインコデザイン（縦）](https://dcard.docomo.ne.jp/st/common/images/poinco_goldu_VISA_2--bg_none.png)

 

通常デザイン

![通常デザイン](https://dcard.docomo.ne.jp/st/common/images/dCARD_gold_u_VISA.png)

 

![通常デザイン](https://dcard.docomo.ne.jp/st/common/images/dCARD_gold_u_VISA.png)

![ポインコデザイン（縦）](https://dcard.docomo.ne.jp/st/common/images/poinco_goldu_VISA_2--bg_none.png)

*   ![](https://dcard.docomo.ne.jp/images/img_top_icon_reduction.png)毎月のドコモケータイ／「ドコモ光」  
    ご利用料金の5%ポイント還元
*   ![](https://dcard.docomo.ne.jp/images/img_top_icon_compensation.png)ケータイ補償3年間で最大10万円
*   ![](https://dcard.docomo.ne.jp/images/img_top_icon_lounge.png)条件達成で年会費実質無料

[詳細とお申込み](https://dcard.docomo.ne.jp/st/dcard_goldu/index.html)

[入会＆利用＆Webエントリーで  \
最大3,000ポイント（期間・用途限定）進呈](https://dcard.docomo.ne.jp/std/campaigns/202506_1cm/cpn-goldushinki-tokuten/index.html)

永年年会費無料

### dカード

ポインコデザイン（レッド）

![ポインコデザイン（レッド）](https://dcard.docomo.ne.jp/st/common/images/poinco_REGULAR_red_VISA.jpg)

 

通常デザイン（ホワイト）

![通常デザイン（ホワイト）](https://dcard.docomo.ne.jp/st/common/images/dCARD_REGULAR_white_VISA.jpg)

 

通常デザイン（レッド）

![通常デザイン（レッド）](https://dcard.docomo.ne.jp/st/common/images/dCARD_REGULAR_red_VISA.jpg)

 

通常デザイン（ブルー）

![通常デザイン（ブルー）](https://dcard.docomo.ne.jp/st/common/images/dCARD_REGULAR_blue_VISA.jpg)

 

ポインコデザイン（ホワイト）

![ポインコデザイン（ホワイト）](https://dcard.docomo.ne.jp/st/common/images/poinco_REGULAR_white_VISA.jpg)

 

ポインコデザイン（レッド）

![ポインコデザイン（レッド）](https://dcard.docomo.ne.jp/st/common/images/poinco_REGULAR_red_VISA.jpg)

 

通常デザイン（ホワイト）

![通常デザイン（ホワイト）](https://dcard.docomo.ne.jp/st/common/images/dCARD_REGULAR_white_VISA.jpg)

 

![通常デザイン（ホワイト）](https://dcard.docomo.ne.jp/st/common/images/dCARD_REGULAR_white_VISA.jpg)

![通常デザイン（レッド）](https://dcard.docomo.ne.jp/st/common/images/dCARD_REGULAR_red_VISA.jpg)

![ポインコデザイン（ホワイト）](https://dcard.docomo.ne.jp/st/common/images/dCARD_REGULAR_blue_VISA.jpg)

![ポインコデザイン（ホワイト）](https://dcard.docomo.ne.jp/st/common/images/poinco_REGULAR_white_VISA.jpg)

![ポインコデザイン（レッド）](https://dcard.docomo.ne.jp/st/common/images/poinco_REGULAR_red_VISA.jpg)

*   ![](https://dcard.docomo.ne.jp/images/img_top_icon_dpoint.png)いつものお買物で1%dポイントがたまる！
*   ![](https://dcard.docomo.ne.jp/images/img_top_icon_cost.png)年会費永年無料

[詳細とお申込み](https://dcard.docomo.ne.jp/st/dcard_dcard/index.html)

カードの比較、  
その他プリペイドカードなどの  
情報はこちら。

[カード一覧](https://dcard.docomo.ne.jp/st/dcard_lineup/index.html)

[![dカードにおけるWeb申込みをお電話でサポートします 0120-930-636 営業時間：10:00～20:00（年末年始除き年中無休） 【dカード入会・アップグレード申込専用窓口】お申込み相談はこちら](https://dcard.docomo.ne.jp/st/images/pict_consultation_support_bnr-pc_small.png)](tel:0120930636)
 [![dカードにおけるWeb申込みをお電話でサポートします 0120-930-636 営業時間：10:00～20:00（年末年始を除き年中無休） 【dカード入会・アップグレード申込専用窓口】お申込み相談はこちら](https://dcard.docomo.ne.jp/st/images/pict_consultation_support_bnr-sp_small.png)](tel:0120930636)

 [![フィッシングに注意！ メールのリンク先から安易にクレジットカード番号を入力してはいけません！](https://dcard.docomo.ne.jp/st/images/phishing_bnr_sp.jpg)](https://www.jcca-office.gr.jp/feature/phishing/)

![dCARDの魅力](https://dcard.docomo.ne.jp/images/static_img_topTitle01.png)
------------------------------------------------------------------------

[![](https://dcard.docomo.ne.jp/images/static_img_DcardCharmLogo01.gif)\
\
Point1\
\
お買物でためる\
\
ショッピングで  \
いつでも1%たまる](https://dcard.docomo.ne.jp/st/dpoint_points/shopping/index.html)

[![](https://dcard.docomo.ne.jp/images/static_img_DcardCharmLogo02.gif)\
\
Point2\
\
サインも  \
チャージも不要\
\
カードでもケータイでも電子マネーがつかえる](https://dcard.docomo.ne.jp/st/service_electronicmoney/index.html)

[![](https://dcard.docomo.ne.jp/images/static_img_DcardCharmLogo03.gif)\
\
Point3\
\
ドコモユーザーなら  \
断然オススメ\
\
dカード GOLDならドコモのケータイ料金の10%ポイント還元](https://dcard.docomo.ne.jp/st/dpoint_present/index.html)

[![](https://dcard.docomo.ne.jp/images/static_img_DcardCharmLogo04.gif)\
\
Point4\
\
キャンペーン・特典でおトク\
\
ポイントがざくざくたまる！キャンペーンやおトクなdカードの特典をチェック！](https://dcard.docomo.ne.jp/st/campaigns/index.html)

[![](https://dcard.docomo.ne.jp/images/static_img_DcardCharmLogo05.gif)\
\
Point5\
\
入会時特典でおトク\
\
dカード／dカード GOLDに入会利用するとおトクな特典が付きます](https://dcard.docomo.ne.jp/std/campaigns/202306_hs/cpn-gold_cashlesstokuten/index.html)

[![](https://dcard.docomo.ne.jp/images/static_img_DcardCharmLogo06.gif)\
\
Point6\
\
ポイントの確認もカンタン!\
\
dカードアプリを設定すれば、dポイントやキャンペーン情報が簡単に確認できる](https://dcard.docomo.ne.jp/st/service_dcappli/about/index.html)

もっと見る

INFORMATION

会員向け  
おすすめ情報
-------------

### ![新しい年、新しい家電でスタート！](https://dcard.docomo.ne.jp/st/images/static_bnr_title_01.png)

[![ビックカメラ.com](https://dcard.docomo.ne.jp/st/images/static_bnr_biccamera.png)\
\
dカード ポイントモール経由でdポイント  \
1.5％たまる！](https://pointmall.dcard.docomo.ne.jp/shop/678/?utm_source=corp_co_electronic&utm_medium=251201&utm_campaign=678&_origin_keyword_=20251201-corp_co_electronic-251201-678)
[![コジマネット](https://dcard.docomo.ne.jp/st/images/static_bnr_06.jpg)\
\
dカード ポイントモール経由でdポイント  \
1％たまる！](https://pointmall.dcard.docomo.ne.jp/shop/453/?utm_source=corp_co_electronic&utm_medium=251201&utm_campaign=453&_origin_keyword_=20251201-corp_co_electronic-251201-453)
[![Joshin Webショップ](https://dcard.docomo.ne.jp/st/images/static_bnr_08.jpg)\
\
dカード ポイントモール経由でdポイント  \
0.5％たまる！](https://pointmall.dcard.docomo.ne.jp/shop/5/?utm_source=corp_co_electronic&utm_medium=251201&utm_campaign=5&_origin_keyword_=20251201-corp_co_electronic-251201-5)
[![ケーズデンキオンラインショップ](https://dcard.docomo.ne.jp/st/images/static_bnr_ksdenki.jpg)\
\
dカード ポイントモール経由でdポイント  \
0.5％たまる！](https://pointmall.dcard.docomo.ne.jp/shop/170/?utm_source=corp_co_electronic&utm_medium=251201&utm_campaign=170&_origin_keyword_=20251201-corp_co_electronic-251201-170)

### ![冬旅で心も体もあったかリフレッシュ！](https://dcard.docomo.ne.jp/st/images/static_bnr_title_02.png)

[![Trip.com（航空券）](https://dcard.docomo.ne.jp/st/images/static_bnr_09.jpg)\
\
dカード ポイントモール経由でdポイント  \
0.5％たまる！  \
GOLD・GOLD U・PLATINUMなら  \
1.5％たまる！](https://pointmall.dcard.docomo.ne.jp/shop/2213/?utm_source=corp_co_travel&utm_medium=251201&utm_campaign=2213&_origin_keyword_=20251201-corp_co_travel-251201-2213)
[![JTB【国内】](https://dcard.docomo.ne.jp/st/images/static_bnr_jtb.png)\
\
dカード ポイントモール経由でdポイント  \
1％たまる！](https://pointmall.dcard.docomo.ne.jp/shop/1251/?utm_source=corp_co_travel&utm_medium=251201&utm_campaign=1251&_origin_keyword_=20251201-corp_co_travel-251201-1251)
[![【海外・国内ホテル】旅行予約のエクスペディア](https://dcard.docomo.ne.jp/st/images/static_bnr_expedia.png)\
\
dカード ポイントモール経由でdポイント  \
5％たまる！  \
GOLD・GOLD U・PLATINUMなら  \
5.5％たまる！](https://pointmall.dcard.docomo.ne.jp/shop/907/?utm_source=corp_co_travel&utm_medium=251201&utm_campaign=907&_origin_keyword_=20251201-corp_co_travel-251201-907)
[![ホテルズドットコム](https://dcard.docomo.ne.jp/st/images/static_bnr_hotels.jpg)\
\
dカード ポイントモール経由でdポイント  \
4％たまる！  \
GOLD・GOLD U・PLATINUMなら  \
4.5％たまる！](https://pointmall.dcard.docomo.ne.jp/shop/1261/?utm_source=corp_co_travel&utm_medium=251201&utm_campaign=1261&_origin_keyword_=20251201-corp_co_travel-251201-1261)

PAYMENT METHOD

選べるお支払い方法
---------

もしものピンチも安心です！

[![キャッシングサービス](https://dcard.docomo.ne.jp/st/service_payment/images/pict_borrowcash_small.png)](https://dcard.docomo.ne.jp/st/service_cashing/borrow/index.html)

[24時間いつでも現金を  \
借りるには？](https://dcard.docomo.ne.jp/st/service_cashing/borrow/index.html)

自分のペースで計画的にお支払いいただけます

[![分割払い](https://dcard.docomo.ne.jp/st/service_payment/images/pict_carryover_small.png)](https://dcard.docomo.ne.jp/st/service_payment/carryover/index.html)

[お支払い回数を決めるには？](https://dcard.docomo.ne.jp/st/service_payment/carryover/index.html)

ご自身に合ったお支払い方法をお選びください

[![リボ？分割？](https://dcard.docomo.ne.jp/st/service_payment/images/pict_cardinstallment_small.png)](https://dcard.docomo.ne.jp/st/service_payment/cardinstallment/index.html)

[自分に合った  \
お支払い方法って？](https://dcard.docomo.ne.jp/st/service_payment/cardinstallment/index.html)

毎月のお支払い金額を自分で決められます

[![こえたらリボ](https://dcard.docomo.ne.jp/st/service_payment/images/pict_paymentterms_small.png)](https://dcard.docomo.ne.jp/st/service_payment/terms/index.html)

[お支払い額を決めるには？](https://dcard.docomo.ne.jp/st/service_payment/terms/index.html)

出費が増えた月でも安心できる方法があります

[![あとからリボ](https://dcard.docomo.ne.jp/st/service_payment/images/pict_paymentchange_small.png)](https://dcard.docomo.ne.jp/st/service_payment/change/index.html)

[あとからお支払い方法を  \
変えるには？](https://dcard.docomo.ne.jp/st/service_payment/change/index.html)

もしものピンチも安心です！

[![キャッシングサービス](https://dcard.docomo.ne.jp/st/service_payment/images/pict_borrowcash_small.png)](https://dcard.docomo.ne.jp/st/service_cashing/borrow/index.html)

[24時間いつでも現金を  \
借りるには？](https://dcard.docomo.ne.jp/st/service_cashing/borrow/index.html)

自分のペースで計画的にお支払いいただけます

[![分割払い](https://dcard.docomo.ne.jp/st/service_payment/images/pict_carryover_small.png)](https://dcard.docomo.ne.jp/st/service_payment/carryover/index.html)

[お支払い回数を決めるには？](https://dcard.docomo.ne.jp/st/service_payment/carryover/index.html)

ご自身に合ったお支払い方法をお選びください

[![リボ？分割？](https://dcard.docomo.ne.jp/st/service_payment/images/pict_cardinstallment_small.png)](https://dcard.docomo.ne.jp/st/service_payment/cardinstallment/index.html)

[自分に合った  \
お支払い方法って？](https://dcard.docomo.ne.jp/st/service_payment/cardinstallment/index.html)

毎月のお支払い金額を自分で決められます

[![こえたらリボ](https://dcard.docomo.ne.jp/st/service_payment/images/pict_paymentterms_small.png)](https://dcard.docomo.ne.jp/st/service_payment/terms/index.html)

[お支払い額を決めるには？](https://dcard.docomo.ne.jp/st/service_payment/terms/index.html)

出費が増えた月でも安心できる方法があります

[![あとからリボ](https://dcard.docomo.ne.jp/st/service_payment/images/pict_paymentchange_small.png)](https://dcard.docomo.ne.jp/st/service_payment/change/index.html)

[あとからお支払い方法を  \
変えるには？](https://dcard.docomo.ne.jp/st/service_payment/change/index.html)

もしものピンチも安心です！

[![キャッシングサービス](https://dcard.docomo.ne.jp/st/service_payment/images/pict_borrowcash_small.png)](https://dcard.docomo.ne.jp/st/service_cashing/borrow/index.html)

[24時間いつでも現金を  \
借りるには？](https://dcard.docomo.ne.jp/st/service_cashing/borrow/index.html)

NEWS

お知らせ
----

重要なお知らせ

*   新着
*   障害

*   [その他のお知らせはこちら](https://dcard.docomo.ne.jp/st/information/information.html)
    
*   [メンテナンス情報](https://dcard.docomo.ne.jp/std/supports/informations/maintenance.html)
    

 [![お客さまの声をカタチに dカードの改善事例をご紹介](https://dcard.docomo.ne.jp/st/images/customer_voice_bnr_sp.png)](https://dcard.docomo.ne.jp/st/voice/index.html)

 [![フィッシングに注意！ メールのリンク先から安易にクレジットカード番号を入力してはいけません！](https://dcard.docomo.ne.jp/st/images/phishing_bnr_sp.jpg)](https://www.jcca-office.gr.jp/feature/phishing/)

閉じる

tap

詳細とお申込み 詳細とお申込み 詳細とお申込み 詳細とお申込み

✕

*   dカードを申込む
*   [ご利用状況の確認  \
    (会員の方)はこちら](https://dcard.docomo.ne.jp/dsw/top/)
    

*   [ご利用状況の確認  \
    (会員の方)はこちら](https://dcard.docomo.ne.jp/dsw/top/)
    

お申込み

新規お申込みはこちらから

[dカード PLATINUMを申込む](https://dcard.docomo.ne.jp/st/dcard_platinum/index.html)
 [dカード GOLDを申込む](https://dcard.docomo.ne.jp/st/dcard_gold/index.html)
 [dカード GOLD Uを申込む](https://dcard.docomo.ne.jp/st/dcard_goldu/index.html)
 [dカードを申込む](https://dcard.docomo.ne.jp/st/dcard_dcard/index.html)

[各カードの違い、詳細はこちら](https://dcard.docomo.ne.jp/st/dcard_lineup/index.html)

×

Loading...
