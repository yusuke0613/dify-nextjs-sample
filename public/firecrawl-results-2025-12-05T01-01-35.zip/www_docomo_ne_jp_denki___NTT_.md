# ドコモでんき／ドコモ ガス | NTTドコモ

URL: https://www.docomo.ne.jp/denki/

---

[![NTT docomo](https://www.docomo.ne.jp/images_osp/common/newhf/header/cmn-rwd-header-logo.svg?ver=1751324418)](https://www.docomo.ne.jp/?icid=CRP_common_header_to_CRP_TOP)

*   [![別ウィンドウで開きます。my docomo](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-my-docomo-logo.svg)](https://www.docomo.ne.jp/mydocomo/?icid=CRP_outerhead_to_MYD_TOP)
    
*   [![別ウィンドウで開きます。Online Shop](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-online-shop-icon2.svg)](https://onlineshop.docomo.ne.jp/top-ols/?xcid=OLS_TOP_from_CRP_outerhead)
    

*   商品・サービス
    
    *   *   モバイル
        *   *   [iPhone](https://www.docomo.ne.jp/iphone/?icid=CRP_menu_to_CRP_IPH)
                
            *   [iPad](https://www.docomo.ne.jp/ipad/?icid=CRP_menu_to_CRP_IPA)
                
            *   [製品](https://www.docomo.ne.jp/product/?icid=CRP_menu_to_CRP_PRD)
                
            *   [料金・割引](https://www.docomo.ne.jp/charge/?icid=CRP_menu_to_CRP_CHA)
                
            *   [サービス・機能](https://www.docomo.ne.jp/service/?icid=CRP_menu_to_CRP_SER)
                
            *   [通信・エリア](https://www.docomo.ne.jp/area/?icid=CRP_menu_to_CRP_AREA)
                
    *   *   インターネット回線・固定電話
        *   *   [インターネット回線・固定電話トップ](https://www.docomo.ne.jp/internet/?icid=CRP_menu_to_CRP_INT)
                
            *   [ドコモ光](https://www.docomo.ne.jp/internet/hikari/?icid=CRP_menu_to_CRP_INT_hikari)
                
            *   [ahamo光](https://www.docomo.ne.jp/internet/ahamo_hikari/?icid=CRP_menu_to_CRP_internet_ahamo_hikari)
                
            *   [home 5G](https://www.docomo.ne.jp/home_5g/?icid=CRP_menu_to_CRP_HOM)
                
            *   [homeでんわ](https://www.docomo.ne.jp/home_denwa/?icid=CRP_menu_to_CRP_DENWA)
                
    *   *   スマートライフ
        *   *   [スマートライフ トップ](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_menu_to_CRP_SER_smart-life)
                
            *   [決済・保険・投資](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_menu_to_CRP_SER_smart-life_finance&tgl_entertainment=0&tgl_life-support=0&tgl_finance=1&tgl_shopping=0&tgl_healthcare=0#finance)
                
            *   [エンターテインメント](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_menu_to_CRP_SER_smart-life_entertainment&tgl_entertainment=1&tgl_life-support=0&tgl_finance=0&tgl_shopping=0&tgl_healthcare=0#entertainment)
                
            *   [ライフサポート](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_menu_to_CRP_SER_smart-life_life-support&tgl_entertainment=0&tgl_life-support=1&tgl_finance=0&tgl_shopping=0&tgl_healthcare=0#life-support)
                
            *   [ショッピング](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_menu_to_CRP_SER_smart-life_shopping&tgl_entertainment=0&tgl_life-support=0&tgl_finance=0&tgl_shopping=1&tgl_healthcare=0#shopping)
                
            *   [ヘルスケア](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_menu_to_CRP_SER_smart-life_healthcare&tgl_entertainment=0&tgl_life-support=0&tgl_finance=0&tgl_shopping=0&tgl_healthcare=1#healthcare)
                
    *   *   電気・ガス
        *   *   [ドコモでんき／  \
                ドコモ ガス トップ](https://www.docomo.ne.jp/denki/?icid=CRP_menu_to_CRP_DENKI)
                
    
*   お知らせ
    
    *   [お知らせトップ](https://www.docomo.ne.jp/info/?icid=CRP_menu_to_CRP_INFO)
        
    *   [ニュースルーム](https://www.docomo.ne.jp/info/update/?icid=CRP_menu_to_CRP_INFO_update)
        
    *   [報道発表](https://www.docomo.ne.jp/info/news_release/?icid=CRP_menu_to_CRP_INFO_news_release)
        
    *   [重要なお知らせ（通信障害）](https://www.docomo.ne.jp/info/network/?icid=CRP_menu_to_CRP_INFO_network)
        
    *   [携帯電話サービスの通信状況（地域別）](https://www.docomo.ne.jp/info/status/?icid=CRP_menu_to_CRP_INFO_status)
        
    *   [工事のお知らせ](https://www.docomo.ne.jp/info/construction/?icid=CRP_menu_to_CRP_INFO_construction)
        
    
*   企業情報
    
    *   [企業情報トップ](https://www.docomo.ne.jp/corporate/?icid=CRP_menu_to_CRP_CORP)
        
    *   [あなたとドコモ](https://www.docomo.ne.jp/corporate/anatatodocomo/?icid=CRP_menu_to_CRP_CORP_anatatodocomo)
        
    *   [企業理念・ビジョン](https://www.docomo.ne.jp/corporate/philosophy_vision/?icid=CRP_menu_to_CRP_CORP_philosophy_vision)
        
    *   [会社案内](https://www.docomo.ne.jp/corporate/about/?icid=CRP_menu_to_CRP_CORP_about)
        
    *   [サステナビリティ](https://www.docomo.ne.jp/corporate/csr/?icid=CRP_menu_to_CRP_CORP_csr)
        
    *   [技術とあんしん](https://www.docomo.ne.jp/corporate/technology_safety/?icid=CRP_menu_to_CRP_CORP_technology_safety)
        
    *   [IR情報](https://www.docomo.ne.jp/corporate/ir/library/?icid=CRP_menu_to_CRP_CORP_ir_library)
        
    *   [採用情報](https://www.docomo.ne.jp/corporate/recruit/?icid=CRP_menu_to_CRP_CORP_recruit)
        
    *   [NTTドコモグループ_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://nttdocomo-group.com/index.html)
        
    
*   法人のお客さま
    
    *   [NTTドコモビジネス_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.ntt.com/index.html)
        
    *   [NTTドコモ  \
        ソリューションズ_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.nttcom.co.jp/)
        
    *   [NTTドコモ・グローバル](https://www.docomo.ne.jp/global/?icid=CRP_TOP_to_CRP_global)
        
    
*   [![別ウィンドウで開きます。my docomo](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-my-docomo-logo.svg)](https://www.docomo.ne.jp/mydocomo/?icid=CRP_outerhead_to_MYD_TOP)
    
    [![別ウィンドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-online-shop-icon.svg)\
    \
    Online Shop](https://onlineshop.docomo.ne.jp/top-ols/?xcid=OLS_TOP_from_CRP_outerhead)
    
    [![別ウィンドウで開きます。のりかえ（MNP）](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-online-mnp-icon_pc.png)](https://onlineshop.docomo.ne.jp/special-contents/mnp?xcid=OLS_special-contents_mnp_flow_from_CRP_TOP_mnp_btn)
    
    [![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-switch-online-icon.svg)機種変更](https://www.docomo.ne.jp/support/switch_online/?icid=CRP_outerhead_to_SUP_switch_online)
    

 [![](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-daccount-logo.svg) ログインする](https://www.docomo.ne.jp/denki/)

[![dポイントクラブ](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-d-point-club-logo.svg)\
\
P\
\
![ランク](https://www.docomo.ne.jp/denki/)](https://www.docomo.ne.jp/denki/)
[![ドコモビジネスメンバーズ](https://www.docomo.ne.jp/images_osp/common/newhf/ico/ico_businessmembers.png)](https://www.docomo.ne.jp/denki/)

MENU

[![NTT docomo](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-header-logo.svg?ver=1751324418)](https://www.docomo.ne.jp/?icid=CRP_drawer_to_CRP_TOP)

[English](https://www.docomo.ne.jp/english/?icid=CRP_drawer_to_CRP_EN)

* * *

   ![検索する](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-header-search-icon.svg)

*    [![](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-my-docomo-logo.svg) My docomo _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.docomo.ne.jp/mydocomo/?icid=CRP_drawer_to_MYD_TOP)
     
*    [![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-online-shop-icon.svg) Online Shop _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://onlineshop.docomo.ne.jp/top-ols/?xcid=OLS_TOP_from_CRP_drawer)
     
*    [![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-docomo-shop-icon.svg) ドコモショップ _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://shop.smt.docomo.ne.jp/?xcid=DS_TOP_from_CRP_drawer)
     
*    [![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-customer-support-icon.svg) お客さまサポート](https://www.docomo.ne.jp/support/?icid=CRP_drawer_sup01_to_CRP_SUP)
    
*    [![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-campaign-icon.svg) キャンペーン・特典](https://www.docomo.ne.jp/campaign_event/?icid=CRP_drawer_to_CRP_CAM)
    
*    [![](https://www.docomo.ne.jp/assets/content/dam/corp/jp/ja/common/images/logo/cmn-rwd-d-point-club-logo.svg) dポイントクラブ _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://dpoint.docomo.ne.jp/)
     

*   *   *   商品・サービス
        *   *   ![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/ico_mobile.png) モバイル
                
                *   [iPhone](https://www.docomo.ne.jp/iphone/?icid=CRP_drawer_to_CRP_IPH)
                    
                *   [iPad](https://www.docomo.ne.jp/ipad/?icid=CRP_drawer_to_CRP_IPA)
                    
                *   [製品](https://www.docomo.ne.jp/product/?icid=CRP_drawer_to_CRP_PRD)
                    
                *   [料金・割引](https://www.docomo.ne.jp/charge/?icid=CRP_drawer_to_CRP_CHA)
                    
                *   [サービス・機能](https://www.docomo.ne.jp/service/?icid=CRP_drawer_to_CRP_SER)
                    
                *   [通信・エリア](https://www.docomo.ne.jp/area/?icid=CRP_drawer_to_CRP_AREA)
                    
                
            *   ![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/ico_internet.png) インターネット回線・固定電話
                
                *   [インターネット回線・固定電話トップ](https://www.docomo.ne.jp/internet/?icid=CRP_drawer_to_CRP_INT)
                    
                *   [ドコモ光](https://www.docomo.ne.jp/internet/hikari/?icid=CRP_drawer_to_CRP_INT_hikari)
                    
                *   [ahamo光](https://www.docomo.ne.jp/internet/ahamo_hikari/?icid=CRP_drawer_to_CRP_internet_ahamo_hikari)
                    
                *   [home 5G](https://www.docomo.ne.jp/home_5g/?icid=CRP_drawer_to_CRP_HOM)
                    
                *   [homeでんわ](https://www.docomo.ne.jp/home_denwa/?icid=CRP_drawer_to_CRP_DENWA)
                    
                
            *   ![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/ico_smartlife.png) スマートライフ
                
                *   [スマートライフ トップ](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_drawer_to_CRP_SER_smart-life)
                    
                *   [決済・保険・投資](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_drawer_to_CRP_SER_smart-life_finance&tgl_entertainment=0&tgl_life-support=0&tgl_finance=1&tgl_shopping=0&tgl_healthcare=0#finance)
                    
                *   [エンターテインメント](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_drawer_to_CRP_SER_smart-life_entertainment&tgl_entertainment=1&tgl_life-support=0&tgl_finance=0&tgl_shopping=0&tgl_healthcare=0#entertainment)
                    
                *   [ライフサポート](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_drawer_to_CRP_SER_smart-life_life-support&tgl_entertainment=0&tgl_life-support=1&tgl_finance=0&tgl_shopping=0&tgl_healthcare=0#life-support)
                    
                *   [ショッピング](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_drawer_to_CRP_SER_smart-life_shopping&tgl_entertainment=0&tgl_life-support=0&tgl_finance=0&tgl_shopping=1&tgl_healthcare=0#shopping)
                    
                *   [ヘルスケア](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_drawer_to_CRP_SER_smart-life_healthcare&tgl_entertainment=0&tgl_life-support=0&tgl_finance=0&tgl_shopping=0&tgl_healthcare=1#healthcare)
                    
                
            *   ![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/ico_denki.png?ver=1748827032) 電気・ガス
                
                *   [ドコモでんき／  \
                    ドコモ ガス トップ](https://www.docomo.ne.jp/denki/?icid=CRP_drawer_to_CRP_DENKI)
                    
                
    *   *   お知らせ
        *   *   お知らせ
                
                *   [お知らせ トップ](https://www.docomo.ne.jp/info/?icid=CRP_drawer_to_CRP_INFO)
                    
                *   [ニュースルーム](https://www.docomo.ne.jp/info/update/?icid=CRP_drawer_to_CRP_INFO_update)
                    
                *   [報道発表](https://www.docomo.ne.jp/info/news_release/?icid=CRP_drawer_to_CRP_INFO_news_release)
                    
                *   [重要なお知らせ（通信障害）](https://www.docomo.ne.jp/info/network/?icid=CRP_drawer_to_CRP_INFO_network)
                    
                *   [携帯電話サービスの通信状況（地域別）](https://www.docomo.ne.jp/info/status/?icid=CRP_drawer_to_CRP_INFO_status)
                    
                *   [工事のお知らせ](https://www.docomo.ne.jp/info/construction/?icid=CRP_drawer_to_CRP_INFO_construction)
                    
                
    *   *   企業情報
        *   *   企業情報
                
                *   [企業情報 トップ](https://www.docomo.ne.jp/corporate/?icid=CRP_drawer_to_CRP_CORP)
                    
                *   [あなたとドコモ](https://www.docomo.ne.jp/corporate/anatatodocomo/?icid=CRP_drawer_to_CRP_CORP_anatatodocomo)
                    
                *   [企業理念・ビジョン](https://www.docomo.ne.jp/corporate/philosophy_vision/?icid=CRP_drawer_to_CRP_CORP_philosophy_vision)
                    
                *   [会社案内](https://www.docomo.ne.jp/corporate/about/?icid=CRP_drawer_to_CRP_CORP_about)
                    
                *   [サステナビリティ](https://www.docomo.ne.jp/corporate/csr/?icid=CRP_drawer_to_CRP_CORP_csr)
                    
                *   [技術とあんしん](https://www.docomo.ne.jp/corporate/technology_safety/?icid=CRP_drawer_to_CRP_CORP_technology_safety)
                    
                *   [IR情報](https://www.docomo.ne.jp/corporate/ir/library/?icid=CRP_drawer_to_CRP_CORP_ir_library)
                    
                *   [採用情報](https://www.docomo.ne.jp/corporate/recruit/?icid=CRP_drawer_to_CRP_CORP_recruit)
                    
                *   [NTTドコモグループ_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://nttdocomo-group.com/index.html)
                    
                
*   *   地域別情報
        
        *   [北海道](https://www.docomo.ne.jp/hokkaido/?icid=CRP_drawer_to_hokkaido)
            
        *   [東北](https://www.docomo.ne.jp/tohoku/?icid=CRP_drawer_to_tohoku)
            
        *   [関東・甲信越](https://www.docomo.ne.jp/kanto/?icid=CRP_drawer_to_kanto)
            
        *   [東海](https://www.docomo.ne.jp/tokai/?icid=CRP_drawer_to_tokai)
            
        *   [北陸](https://www.docomo.ne.jp/hokuriku/?icid=CRP_drawer_to_hokuriku)
            
        *   [関西](https://www.docomo.ne.jp/kansai/?icid=CRP_drawer_to_kansai)
            
        *   [中国](https://www.docomo.ne.jp/chugoku/?icid=CRP_drawer_to_chugoku)
            
        *   [四国](https://www.docomo.ne.jp/shikoku/?icid=CRP_drawer_to_shikoku)
            
        *   [九州・沖縄](https://www.docomo.ne.jp/kyushu/?icid=CRP_drawer_to_kyushu)
            
        
    *   地域別情報
        
        *   [北海道](https://www.docomo.ne.jp/hokkaido/?icid=CRP_drawer_to_hokkaido)
            |
        *   [東北](https://www.docomo.ne.jp/tohoku/?icid=CRP_drawer_to_tohoku)
            |
        *   [関東・甲信越](https://www.docomo.ne.jp/kanto/?icid=CRP_drawer_to_kanto)
            |
        *   [東海](https://www.docomo.ne.jp/tokai/?icid=CRP_drawer_to_tokai)
            |
        *   [北陸](https://www.docomo.ne.jp/hokuriku/?icid=CRP_drawer_to_hokuriku)
            |
        *   [関西](https://www.docomo.ne.jp/kansai/?icid=CRP_drawer_to_kansai)
            |
        *   [中国](https://www.docomo.ne.jp/chugoku/?icid=CRP_drawer_to_chugoku)
            |
        *   [四国](https://www.docomo.ne.jp/shikoku/?icid=CRP_drawer_to_shikoku)
            |
        *   [九州・沖縄](https://www.docomo.ne.jp/kyushu/?icid=CRP_drawer_to_kyushu)
            
        
*   *   法人のお客さま
        
        *   [NTTドコモビジネス_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.ntt.com/index.html)
            
        *   [NTTドコモソリューションズ_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.nttcom.co.jp/)
            
        *   [NTTドコモ・グローバル](https://www.docomo.ne.jp/global/?icid=CRP_drawer_to_CRP_global)
            
        
    *   法人のお客さま
        
        *   [NTTドコモビジネス_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.ntt.com/index.html)
            |
        *   [NTTドコモソリューションズ_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.nttcom.co.jp/)
            |
        *   [NTTドコモ・グローバル](https://www.docomo.ne.jp/global/?icid=CRP_drawer_to_CRP_global)
            
        

[![](https://www.docomo.ne.jp/assets/content/dam/corp/jp/ja/common/images/logo/cmn-rwd-d-point-club-logo.svg)](https://www.docomo.ne.jp/denki/)

*   [dアカウントでもっと便利に](https://www.docomo.ne.jp/utility/daccount/?icid=CRP_drawer_to_CRP_UTI_daccount)
    
*   [別のIDでログイン](https://cfg.smt.docomo.ne.jp/auth/cgi/anidlogin?rl=https%3A%2F%2Fwww.docomo.ne.jp%2F)
    
*   [ログアウト](https://www.docomo.ne.jp/mydocomo/utility/confirm_logout/index.html)
    
*   [会員情報確認・変更_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon-white.svg)_](https://profile.smt.docomo.ne.jp/VIEW_ESITE/mem/sc/main.jsp?nid=MEG002006BJP)
    
*   [ログインでお困りの方_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon-white.svg)_](https://id.smt.docomo.ne.jp/src/utility/idpw_forget.html)
    
*   [２段階認証のお願い_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon-white.svg)_](https://id.smt.docomo.ne.jp/src/utility/sp/twostepauth.html)
    

オートログイン中

[![ランク](https://www.docomo.ne.jp/denki/#)](https://dpoint.docomo.ne.jp/member/stage_info/index.html)

* * *

[うち期間・用途限定](https://www.docomo.ne.jp/denki/)

* * *

[![ドコモビジネスメンバーズ](https://www.docomo.ne.jp/images_osp/common/newhf/ico/ico_businessmembers.png)](https://www.docomo.ne.jp/denki/)

*   [別のIDでログイン](https://cfg.smt.docomo.ne.jp/auth/cgi/anidlogin?rl=https%3A%2F%2Fwww.docomo.ne.jp%2F)
    
*   [ログアウト](https://www.docomo.ne.jp/mydocomo/utility/confirm_logout/index.html)
    
*   [会員情報確認・変更_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon-white.svg)_](https://profile.smt.docomo.ne.jp/VIEW_ESITE/mem/sc/main.jsp?nid=MEG002006BJP)
    
*   [２段階認証のお願い_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon-white.svg)_](https://id.smt.docomo.ne.jp/src/utility/sp/twostepauth.html)
    

*   [CMギャラリー_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.youtube.com/playlist?list=PLB334710B4B8111A8)
    
*   [よくあるご質問](https://faq.front.smt.docomo.ne.jp/?utm_source=docomo.ne.jp&utm_medium=api_linkage&utm_campaign=api_CRP_TOP)
    
*   [見やすさ・使いやすさの調整](https://www.docomo.ne.jp/utility/term/web_accessibility/faciliti/?icid=CRP_drawer_to_CRP_UTI_term_web_accessibility_faciliti)
    
*   [パーソナルデータ（個人情報など）について](https://www.docomo.ne.jp/utility/personal_data/?icid=CRP_drawer_to_CRP_UTI_personal_data)
    

*    [![](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-daccount-logo.svg) ログインする](https://www.docomo.ne.jp/denki/)
    
*   [![別ウィンドウで開きます。のりかえ（MNP）](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-online-mnp-icon_smt.png)](https://onlineshop.docomo.ne.jp/special-contents/mnp?xcid=OLS_special-contents_mnp_flow_from_CRP_TOP_mnp_btn)
    

*   [![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-switch-online-icon.svg)機種変更](https://www.docomo.ne.jp/support/switch_online/?icid=CRP_outerhead_to_SUP_switch_online)
    
*   [![](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-d-point-club-logo.svg)\
    \
    P\
    \
    ![](https://www.docomo.ne.jp/denki/)](https://www.docomo.ne.jp/denki/)
    

[![ドコモビジネスメンバーズ](https://www.docomo.ne.jp/images_osp/common/newhf/ico/ico_businessmembers.png)](https://www.docomo.ne.jp/denki/)

お客さまの設定により、お客さま情報が「非表示」となっております。お客さま情報を表示するにはdアカウントでログインしてください。  
[お客さま情報表示について](https://www.docomo.ne.jp/denki/)
へ

[お客さま情報表示について](https://www.docomo.ne.jp/denki/)
へ

*   [ホーム](https://www.docomo.ne.jp/)
    
*   ドコモでんき／ドコモ ガス

ドコモでんき／ドコモ ガス
=============

![ドコモでんきの画像](https://www.docomo.ne.jp/flcache_data/denki/images/img_main_pc.jpg?ver=1667352193)![ドコモでんきの画像](https://www.docomo.ne.jp/flcache_data/denki/images/img_main_smt.jpg?ver=1667352193)

![ドコモ ガス](https://www.docomo.ne.jp/flcache_data/denki/images/img_main_gas_pc.png?ver=1748827032)![ドコモ ガス](https://www.docomo.ne.jp/flcache_data/denki/images/img_main_gas_smt.png?ver=1748827032)

*   [ドコモでんきとは？__](https://www.docomo.ne.jp/denki/#anc-01)
    
*   [ドコモでんき2つのプラン__](https://www.docomo.ne.jp/denki/#anc-02)
    
*   [ご契約の流れ__](https://www.docomo.ne.jp/denki/#anc-03)
    
*   [電力エリアおよびドコモでんきの料金プラン__](https://www.docomo.ne.jp/denki/#anc-04)
    
*   [電気料金に対するdポイント還元率__](https://www.docomo.ne.jp/denki/#anc-05)
    
*   [でんきとセットでおトクなガスプラン！__](https://www.docomo.ne.jp/denki/#anc-10)
    
*   [ドコモ ガスのご紹介__](https://www.docomo.ne.jp/denki/#anc-11)
    
*   [キャンペーン__](https://www.docomo.ne.jp/denki/#anc-06)
    
*   [お知らせ__](https://www.docomo.ne.jp/denki/#anc-07)
    
*   [よくあるご質問__](https://www.docomo.ne.jp/denki/#anc-08)
    
*   [関連情報__](https://www.docomo.ne.jp/denki/#anc-09)
    

ドコモでんきとは？
---------

![電気の品質を変えることなく、dポイントがたまる。電気代ごとにdポイントがたまるドコモでんき Basicに加え、CO2フリーの再生可能エネルギーを活用したドコモでんき Greenをご用意。2つのプランで、暮らしにも地球にもうれしい電気をお届けします。※LNG火力などの電源に非化石証書を使用することでCO2排出量実質0](https://www.docomo.ne.jp/flcache_data/denki/images/img_about_01_pc.jpg?ver=1675329852)![電気の品質を変えることなく、dポイントがたまる。電気代ごとにdポイントがたまるドコモでんき Basicに加え、CO2フリーの再生可能エネルギーを活用したドコモでんき Greenをご用意。2つのプランで、暮らしにも地球にもうれしい電気をお届けします。※LNG火力などの電源に非化石証書を使用することでCO2排出量実質0](https://www.docomo.ne.jp/flcache_data/denki/images/img_about_01_smt.jpg?ver=1675329852)

![あんしん：切り替え期間中に電気が止まることは原則ありません。おトク：dポイントがザクザクたまる！カンタン：今の電力会社の解約手続きなし。切替工事原則不要。](https://www.docomo.ne.jp/flcache_data/denki/images/img_about_02_pc.png?ver=1737012431)![あんしん：切り替え期間中に電気が止まることは原則ありません。おトク：dポイントがザクザクたまる！カンタン：今の電力会社の解約手続きなし。切替工事原則不要。](https://www.docomo.ne.jp/flcache_data/denki/images/img_about_02_smt.png?ver=1737012431)

[![サービスサイトで詳細をチェックの画像](https://www.docomo.ne.jp/flcache_data/denki/images/bnr_denki_pc.jpg?ver=1709258410)![サービスサイトで詳細をチェックの画像](https://www.docomo.ne.jp/flcache_data/denki/images/bnr_denki_smt.jpg?ver=1709258410)_![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://denki.docomo.ne.jp/?utm_source=corp_service&utm_medium=free-display&utm_campaign=docomo-denki_202402_corptopbanner&utm_content=denki-0005)

ドコモでんき2つのプラン
------------

![ドコモでんきGreen](https://www.docomo.ne.jp/flcache_data/denki/images/txt_dcm_green.png?ver=1709258410)

**地球にやさしい再生可能エネルギー由来で  
dポイントもしっかり還元※1**

![▼](https://www.docomo.ne.jp/flcache_data/denki/images/ico_arrow_green.png?ver=1709258410)

**こんな方にオススメ**

![ご家族とお住まいの方のイメージ](https://www.docomo.ne.jp/flcache_data/denki/images/icon_family.png?ver=1709258410)

ご家族と  
お住まいの方

![dカード PLATINUM・GOLD・GOLD Uを検討中・お持ちの方のイメージ](https://www.docomo.ne.jp/flcache_data/denki/images/icon_platinum-gold.png?ver=1732496413)

dカード PLATINUM・GOLD・GOLD Uを  
検討中・お持ちの方

![地球に優しい電気を使いたい方のイメージ](https://www.docomo.ne.jp/flcache_data/denki/images/icon_eco.png?ver=1709258410)

地球に優しい  
電気を使いたい方

[Greenの詳細はこちら_![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03-strong_v2.png)_](https://denki.docomo.ne.jp/plan/green/?utm_source=corp_service&utm_medium=owned&utm_campaign=docomo-denki_202403_denkicorptop-green1)

1.  LNG火力などの電源に非化石証書を使用することでCO2排出量実質0。
    

![ドコモでんきBasic](https://www.docomo.ne.jp/flcache_data/denki/images/txt_dcm_basic.png?ver=1709258410)

**dポイントがおトクにたまる  
ドコモならではのベーシックプラン**

![▼](https://www.docomo.ne.jp/flcache_data/denki/images/ico_arrow_basic.png?ver=1709258410)

**こんな方にオススメ**

![お一人でお住まいの方のイメージ](https://www.docomo.ne.jp/flcache_data/denki/images/icon_alone.png?ver=1709258410)

お一人で  
お住まいの方

![dカードを検討中・お持ちの方のイメージ](https://www.docomo.ne.jp/flcache_data/denki/images/icon_card.png?ver=1725237013)

dカードを  
検討中・お持ちの方

![ポイントをためたい方のイメージ](https://www.docomo.ne.jp/flcache_data/denki/images/icon_point.png?ver=1709258410)

ポイントを  
ためたい方

[Basicの詳細はこちら_![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03-strong_v2.png)_](https://denki.docomo.ne.jp/plan/basic/?utm_source=corp_service&utm_medium=owned&utm_campaign=docomo-denki_202403_denkicorptop-basic1)

ご契約の流れ
------

現在の電力会社への解約手続きや、ご来店などは一切不要。  
工事などの費用も無料で、お申込み後は、ご利用開始までお客さまの作業は原則ありません。

![現在の電力会社への解約手続きなし](https://www.docomo.ne.jp/flcache_data/denki/images/img_construction_01.png?ver=1640239215)

![工事などの費用は無料](https://www.docomo.ne.jp/flcache_data/denki/images/img_construction_02.png?ver=1640239215)

![工事などの立会いは原則不要](https://www.docomo.ne.jp/flcache_data/denki/images/img_construction_03.png?ver=1720058712)

![ご来店は不要](https://www.docomo.ne.jp/flcache_data/denki/images/img_construction_04.png?ver=1640239215)

お申込み手続きはカンタン5分！  
わずか3STEPで申込み完了します。

![ステップ1：供給地点特定番号とお客さま番号情報の確認](https://www.docomo.ne.jp/flcache_data/denki/images/img_about_03_01_pc.png?ver=1646360781)![ステップ1：供給地点特定番号とお客さま番号情報の確認](https://www.docomo.ne.jp/flcache_data/denki/images/img_about_03_01_smt.png?ver=1646360780)

![ステップ2：基本情報の登録](https://www.docomo.ne.jp/flcache_data/denki/images/img_about_03_02_pc.png?ver=1646360780)![ステップ2：基本情報の登録](https://www.docomo.ne.jp/flcache_data/denki/images/img_about_03_02_smt.png?ver=1646360780)

![ステップ3：重要事項と登録内容の確認](https://www.docomo.ne.jp/flcache_data/denki/images/img_about_03_03_pc.png?ver=1646360780)![ステップ3：重要事項と登録内容の確認](https://www.docomo.ne.jp/flcache_data/denki/images/img_about_03_03_smt.png?ver=1646360781)

ドコモでんきの新規お申込みには、**現在ご契約中の以下の情報が**必要です。

**ご契約中の電力会社のマイページでご確認いただくか、**紙の検針票をご利用の方は**お手元に検針票をご用意ください。**

*   ご契約中の電力会社名
    
*   ご契約中の電力会社のお客さま番号
    
*   供給地点特定番号
    
*   ご契約者名義
    
*   ご利用中のアンペア容量
    

*   メンテナンスによりお申込みができない場合がございます。詳しくは、[メンテナンス情報_![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://denki.docomo.ne.jp/notice/maintenance/index.html)
    をご覧ください。
    

*   [ドコモでんき／ガス お申込み_![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window02.png)_](https://denki.docomo.ne.jp/application-select/?utm_source=corp_service&utm_medium=owned&utm_campaign=docomo-denki_202510&utm_content=denki-0634)
    

電力エリアおよび  
ドコモでんきの料金プラン
-----------------------

ドコモでんきは、沖縄電力エリア全域および離島を除く日本全国でご利用になれます。

![北海道電力エリア](https://www.docomo.ne.jp/flcache_data/denki/images/img_area_01.png?ver=1709258410)

![東北電力エリア](https://www.docomo.ne.jp/flcache_data/denki/images/img_area_02.png?ver=1709258410)

![東京電力エリア](https://www.docomo.ne.jp/flcache_data/denki/images/img_area_03.png?ver=1709258410)

![中部電力エリア](https://www.docomo.ne.jp/flcache_data/denki/images/img_area_04.png?ver=1709258410)

![北陸電力エリア](https://www.docomo.ne.jp/flcache_data/denki/images/img_area_05.png?ver=1709258410)

![関西電力エリア](https://www.docomo.ne.jp/flcache_data/denki/images/img_area_06.png?ver=1709258410)

![中国電力エリア](https://www.docomo.ne.jp/flcache_data/denki/images/img_area_07.png?ver=1709258410)

![四国電力エリア](https://www.docomo.ne.jp/flcache_data/denki/images/img_area_08.png?ver=1709258410)

![九州電力エリア](https://www.docomo.ne.jp/flcache_data/denki/images/img_area_09.png?ver=1709258410)

[料金単価表_![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://denki.docomo.ne.jp/plan/price/?utm_source=corp_service&utm_medium=owned&utm_campaign=docomo-denki_202403_denkicorptop-price)

電気料金に対するdポイント還元率
----------------

*   [ドコモでんき Greenの還元率はこちら_![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://denki.docomo.ne.jp/plan/green/?utm_source=corp_service&utm_medium=owned&utm_campaign=docomo-denki_202403_denkicorptop-green2)
    
*   [ドコモでんき Basicの還元率はこちら_![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://denki.docomo.ne.jp/plan/basic/?utm_source=corp_service&utm_medium=owned&utm_campaign=docomo-denki_202403_denkicorptop-basic2)
    

でんきとセットでおトクなガスプラン！
------------------

![毎月のガス代でdポイントをためよう！ドコモでんきやdカードをご利用の方におすすめドコモ ガス還元率最大1%](https://www.docomo.ne.jp/flcache_data/denki/images/img_gas_doint_1pct_pc.png?ver=1748827032)![毎月のガス代でdポイントをためよう！ドコモでんきやdカードをご利用の方におすすめドコモ ガス還元率最大1%](https://www.docomo.ne.jp/flcache_data/denki/images/img_gas_doint_1pct_smt.png?ver=1748827032)

*   ポイント還元対象は基本料金／従量料金（原料費調整制度に基づく調整額を含む）の税抜金額となります。
    
*   ご利用料金100円（税抜）につき1％または0.5％還元し、100円未満が生じる場合は切り捨ていたします。
    
*   ポイント還元率は、dポイントクラブ会員番号との紐づけ状態、ドコモでんきのご契約状態、dカードのご契約状態、ガス料金の支払方法などにより変動いたします。
    
*   詳細は[こちら_![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://denki.docomo.ne.jp/gas/?utm_source=corp_service&utm_medium=owned&utm_campaign=docomo-gas_202505_denkicorptop-gas&utm_content=gas-0048)
    のdポイント還元表をご確認ください。
    

![さらに、対象の回線プランをご契約ならガスと一緒のご利用で電気代のdポイント還元率がアップ！ドコモ でんき還元率＋2%](https://www.docomo.ne.jp/flcache_data/denki/images/img_gas_doint_2pct_pc.png?ver=1753341912)![さらに、対象の回線プランをご契約ならガスと一緒のご利用で電気代のdポイント還元率がアップ！ドコモ でんき還元率＋2%](https://www.docomo.ne.jp/flcache_data/denki/images/img_gas_doint_2pct_smt.png?ver=1753341912)

*   ポイント還元対象は基本料金もしくは最低料金と電力量料金の税抜金額となります。燃料費等調整額・再生可能エネルギー発電促進賦課金は還元対象外です。
    
*   ご利用料金100円（税抜）につき2％還元いたします。
    
*   2019年10月以降に提供開始しているドコモのケータイ料金プランなどをご契約中の場合に限ります。
    
*   dカード未保有でdポイント利用者情報登録がない方はdポイント還元の対象外となります。
    
*   詳細は[こちら_![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://denki.docomo.ne.jp/gas/?utm_source=corp_service&utm_medium=owned&utm_campaign=docomo-gas_202505_denkicorptop-gas&utm_content=gas-0049)
    のdポイント還元表をご確認ください。
    

*   ドコモでんき／ドコモ ガスご利用料金は、dカードで通常たまるポイント（利用額100円（税込）につき1ポイント）の対象外です。
    

ドコモ ガスのご紹介
----------

![あんしん①地域ガス会社からの供給で品質も安全性もそのまま②提供プランも地域ガス会社と内容も料金も同じ※消費税算定の結果、1円の誤差が生じる場合があります※一部取扱いのないプランがございます。また、「ドコモガス Supplied by 大阪ガス」の場合、「まとめトク料金」のご契約には「ドコモでんき」の契約が必要となります。また、割引制度の適用条件が異なるものがございます。](https://www.docomo.ne.jp/flcache_data/denki/images/img_gas_01_pc.png?ver=1748827031)![あんしん①地域ガス会社からの供給で品質も安全性もそのまま②提供プランも地域ガス会社と内容も料金も同じ※消費税算定の結果、1円の誤差が生じる場合があります※一部取扱いのないプランがございます。また、「ドコモガス Supplied by 大阪ガス」の場合、「まとめトク料金」のご契約には「ドコモでんき」の契約が必要となります。また、割引制度の適用条件が異なるものがございます。](https://www.docomo.ne.jp/flcache_data/denki/images/img_gas_01_smt.png?ver=1748827032)

![おトク③ドコモでんきやdカードをご利用の方は、毎月のガス代でdポイントがたまる④ドコモでんきと一緒に利用すると、電気代の還元率がアップ※対象のドコモのケータイ料金プランをご契約中の場合に限ります。](https://www.docomo.ne.jp/flcache_data/denki/images/img_gas_02_pc.png?ver=1748827032)![おトク③ドコモでんきやdカードをご利用の方は、毎月のガス代でdポイントがたまる④ドコモでんきと一緒に利用すると、電気代の還元率がアップ※対象のドコモのケータイ料金プランをご契約中の場合に限ります。](https://www.docomo.ne.jp/flcache_data/denki/images/img_gas_02_smt.png?ver=1748827032)

![カンタン⑤以下すべて不要！切替工事・書類記入・今のガス会社への解約連絡・初期／切替費用0円（現契約先の解約による費用が発生する場合がありますのでご確認ください。）ドコモショップ店頭やWebサイトからお申込みできます（後日電話によるお申込み内容の確認がございます）](https://www.docomo.ne.jp/flcache_data/denki/images/img_gas_03_pc.png?ver=1748827032)![カンタン⑤以下すべて不要！切替工事・書類記入・今のガス会社への解約連絡・初期／切替費用0円（現契約先の解約による費用が発生する場合がありますのでご確認ください。）ドコモショップ店頭やWebサイトからお申込みできます（後日電話によるお申込み内容の確認がございます）](https://www.docomo.ne.jp/flcache_data/denki/images/img_gas_03_smt.png?ver=1748827032)

![ドコモ ガス Supplied by TOKYO GAS、ドコモ ガス Supplied by 大阪ガス、ドコモ ガス Supplied by 東邦ガスのロゴ](https://www.docomo.ne.jp/flcache_data/denki/images/logo_gas_pc.png?ver=1762304431)![ドコモ ガス Supplied by TOKYO GAS、ドコモ ガス Supplied by 大阪ガス、ドコモ ガス Supplied by 東邦ガスのロゴ](https://www.docomo.ne.jp/flcache_data/denki/images/logo_gas_smt.png?ver=1762304431)

[ドコモ ガスの詳細はこちら_![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://denki.docomo.ne.jp/gas/?utm_source=corp_service&utm_medium=owned&utm_campaign=docomo-gas_202504_denkicorptop-gas&utm_content=gas-0045)

*   対象のドコモのケータイプラン：  
    後続に記載のある2019年10月以降に提供開始しているドコモのケータイ料金プランなどをご契約中の場合に限ります。  
    対象プラン：5Gギガホ プレミア／ギガホ プレミア／はじめてスマホプラン／ahamo／5Gギガホ／5Gギガライト／5Gデータプラス／ギガホ2（Xi）／ギガライト2（Xi）／データプラス2（Xi）／ケータイプラン2（Xi）／キッズケータイプラン2（Xi）／キッズケータイプラン3／home 5G プラン／LTE上空利用プラン／U15はじめてスマホプラン／homeでんわ ライト／homeでんわ ベーシック／eximo／eximo ポイ活／irumo／ドコモ MAX／ドコモ ポイ活 MAX／ドコモ ポイ活 20／ドコモ mini／ちかく専用プラン／OCN モバイル ONE。  
    なお、OCN モバイル ONEをご契約の場合は、電気料金の請求月の前月末日時点で、ドコモでんきの契約に紐づくキャリアフリーdアカウントとOCN IDを連携の上、当社所定の方法により特典適用の登録をしていることが必要です。新規登録受付は2025年9月30日（火曜）をもって終了いたしました。2025年9月30日（火曜）までにご登録済みのお客さまは、継続して特典を受けられます。
    

キャンペーン
------

[![地球にやさしくdポイント（期間・用途限定）がコツコツたまる ドコモでんきエコ得プログラム ドコモでんきご契約者さま全員対象！ 対象時間内の節電量に応じてdポイントを獲得！ 電気を使用する時間をシフトしてdポイント分お得に！ 特典内容や進呈条件等、詳細はリンク先のページをご確認ください](https://www.docomo.ne.jp/flcache_data/denki/images/bnr_campaign02_pc.jpg?ver=1709600415)![地球にやさしくdポイント（期間・用途限定）がコツコツたまる ドコモでんきエコ得プログラム ドコモでんきご契約者さま全員対象！ 対象時間内の節電量に応じてdポイントを獲得！ 電気を使用する時間をシフトしてdポイント分お得に！ 特典内容や進呈条件等、詳細はリンク先のページをご確認ください](https://www.docomo.ne.jp/flcache_data/denki/images/bnr_campaign02_smt.jpg?ver=1709600415)_![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://denki.docomo.ne.jp/ecotoku/?utm_source=corp_service&utm_medium=free-display&utm_campaign=docomo-denki_202403_corpcampaign)

お知らせ
----

ドコモでんき／ドコモ ガスの新しいお知らせはこちらから確認してください。

[お知らせはこちら_![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://denki.docomo.ne.jp/notice/?utm_source=corp_service&utm_medium=owned&utm_campaign=docomo-denki_202403_denkicorptop-notice)

よくあるご質問
-------

「ドコモでんき／ドコモ ガス」に関するよくあるご質問（FAQ）をまとめました。

[よくあるご質問（FAQ）へ__](https://faq.front.smt.docomo.ne.jp/search?categoryId=189&utm_source=docomo.ne.jp&utm_medium=api_linkage&utm_campaign=api_CRP_DENKI)

関連情報
----

[#### 供給約款・重要事項説明等\
\
_![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://denki.docomo.ne.jp/terms/?utm_source=corp_service&utm_medium=owned&utm_campaign=docomo-denki_202403_denkicorptop-term)

[#### お困りの方\
\
_![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://denki.docomo.ne.jp/support/?utm_source=corp_service&utm_medium=owned&utm_campaign=docomo-denki_202403_denkicorptop-support)

[#### 停電のときは\
\
_![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://denki.docomo.ne.jp/support/outage/?utm_source=corp_service&utm_medium=owned&utm_campaign=docomo-denki_202403_denkicorptop-outage)

[#### ガス漏れ・ガスが出ないときの対処法\
\
_![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://denki.docomo.ne.jp/support/gas-leak/?utm_source=corp_service&utm_medium=owned&utm_campaign=docomo-denki_202510&utm_content=denki-0636)

[#### ドコモでんき 対応エリア\
\
_![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://denki.docomo.ne.jp/area/?utm_source=corp_service&utm_medium=owned&utm_campaign=docomo-denki_202403_denkicorptop-area)

*   [ドコモでんき／ガス  \
    お申込み_![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window02.png)_](https://denki.docomo.ne.jp/application-select/?utm_source=corp_service&utm_medium=owned&utm_campaign=docomo-denki_202510&utm_content=denki-0635)
    

閉じる

[![このページのトップへ](https://www.docomo.ne.jp/images_osp/common/btn/btn_pagetop_01.png)](https://www.docomo.ne.jp/denki/#)

  

[![お困りですか？](https://www.docomo.ne.jp/images_osp/common/chat_tool/bnr_chat_tool.svg)](https://tetsuduki-support.docomo.ne.jp/?utm_source=corp&utm_medium=free-display&utm_campaign=onsapo_)

*   [お知らせ](https://www.docomo.ne.jp/info/?icid=CRP_common_footer_to_CRP_INFO)
    
*   [企業情報](https://www.docomo.ne.jp/corporate/?icid=CRP_common_footer_to_CRP_CORP)
    

* * *

*   [パーソナルデータ（個人情報など）について](https://www.docomo.ne.jp/utility/personal_data/?icid=CRP_common_footer_to_CRP_UTI_personal_data)
    
*   [プライバシーポリシー](https://www.docomo.ne.jp/utility/privacy/?icid=CRP_common_footer_to_CRP_UTI_privacy)
    
*   [サイトご利用にあたって](https://www.docomo.ne.jp/utility/term/?icid=CRP_common_footer_to_CRP_UTI_term)
    
*   [お客さまご利用端末からの情報の外部送信について](https://www.docomo.ne.jp/utility/term/?icid=CRP_common_footer_02_to_CRP_UTI_term#p09)
    
*   [見やすさ・使いやすさの調整](https://www.docomo.ne.jp/utility/term/web_accessibility/faciliti/?icid=CRP_common_footer_to_CRP_UTI_term_web_accessibility_faciliti)
    
*   [サイトメンテナンス情報_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon-white.svg)_](https://www.docomo.ne.jp/mydocomo/maint/?icid=CRP_common_footer_to_CRP_MYD_maint)
    
*   [サイトマップ](https://www.docomo.ne.jp/sitemap/?icid=CRP_common_footer_to_CRP_sitemap)
    
*   [ご意見・ご要望](https://www.docomo.ne.jp/support/inquiry/feedback/?icid=CRP_common_footer_to_CRP_SUP_inquiry_feedback)
    
*   [お問い合わせ](https://www.docomo.ne.jp/support/inquiry/?icid=CRP_common_footer_to_CRP_SUP_inquiry)
    
*   [NTTドコモグループ_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon-white.svg)_](https://nttdocomo-group.com/index.html)
    

© NTT DOCOMO

![閉じる](https://www.docomo.ne.jp/images_osp/common/smtnav/btn_smtmenu_01_close_crp.png)

M
