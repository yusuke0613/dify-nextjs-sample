# 製品 | NTTドコモ

URL: https://www.docomo.ne.jp/product/

---

[![NTT docomo](https://www.docomo.ne.jp/images_osp/common/newhf/header/cmn-rwd-header-logo.svg?ver=1751324418)](https://www.docomo.ne.jp/?icid=CRP_common_header_to_CRP_TOP)

*   [![別ウィンドウで開きます。my docomo](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-my-docomo-logo.svg)](https://www.docomo.ne.jp/mydocomo/?icid=CRP_outerhead_to_MYD_TOP)
    
*   [![別ウィンドウで開きます。Online Shop](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-online-shop-icon2.svg)](https://onlineshop.docomo.ne.jp/top-ols/?xcid=OLS_TOP_from_CRP_outerhead)
    

*   商品・サービス
    
    *   *   モバイル
        *   *   [iPhone](https://www.docomo.ne.jp/iphone/?icid=CRP_menu_to_CRP_IPH)
                
            *   [iPad](https://www.docomo.ne.jp/ipad/?icid=CRP_menu_to_CRP_IPA)
                
            *   [製品](https://www.docomo.ne.jp/product/?icid=CRP_menu_to_CRP_PRD)
                
            *   [料金・割引](https://www.docomo.ne.jp/charge/?icid=CRP_menu_to_CRP_CHA)
                
            *   [サービス・機能](https://www.docomo.ne.jp/service/?icid=CRP_menu_to_CRP_SER)
                
            *   [通信・エリア](https://www.docomo.ne.jp/area/?icid=CRP_menu_to_CRP_AREA)
                
    *   *   インターネット回線・固定電話
        *   *   [インターネット回線・固定電話トップ](https://www.docomo.ne.jp/internet/?icid=CRP_menu_to_CRP_INT)
                
            *   [ドコモ光](https://www.docomo.ne.jp/internet/hikari/?icid=CRP_menu_to_CRP_INT_hikari)
                
            *   [ahamo光](https://www.docomo.ne.jp/internet/ahamo_hikari/?icid=CRP_menu_to_CRP_internet_ahamo_hikari)
                
            *   [home 5G](https://www.docomo.ne.jp/home_5g/?icid=CRP_menu_to_CRP_HOM)
                
            *   [homeでんわ](https://www.docomo.ne.jp/home_denwa/?icid=CRP_menu_to_CRP_DENWA)
                
    *   *   スマートライフ
        *   *   [スマートライフ トップ](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_menu_to_CRP_SER_smart-life)
                
            *   [決済・保険・投資](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_menu_to_CRP_SER_smart-life_finance&tgl_entertainment=0&tgl_life-support=0&tgl_finance=1&tgl_shopping=0&tgl_healthcare=0#finance)
                
            *   [エンターテインメント](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_menu_to_CRP_SER_smart-life_entertainment&tgl_entertainment=1&tgl_life-support=0&tgl_finance=0&tgl_shopping=0&tgl_healthcare=0#entertainment)
                
            *   [ライフサポート](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_menu_to_CRP_SER_smart-life_life-support&tgl_entertainment=0&tgl_life-support=1&tgl_finance=0&tgl_shopping=0&tgl_healthcare=0#life-support)
                
            *   [ショッピング](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_menu_to_CRP_SER_smart-life_shopping&tgl_entertainment=0&tgl_life-support=0&tgl_finance=0&tgl_shopping=1&tgl_healthcare=0#shopping)
                
            *   [ヘルスケア](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_menu_to_CRP_SER_smart-life_healthcare&tgl_entertainment=0&tgl_life-support=0&tgl_finance=0&tgl_shopping=0&tgl_healthcare=1#healthcare)
                
    *   *   電気・ガス
        *   *   [ドコモでんき／  \
                ドコモ ガス トップ](https://www.docomo.ne.jp/denki/?icid=CRP_menu_to_CRP_DENKI)
                
    
*   お知らせ
    
    *   [お知らせトップ](https://www.docomo.ne.jp/info/?icid=CRP_menu_to_CRP_INFO)
        
    *   [ニュースルーム](https://www.docomo.ne.jp/info/update/?icid=CRP_menu_to_CRP_INFO_update)
        
    *   [報道発表](https://www.docomo.ne.jp/info/news_release/?icid=CRP_menu_to_CRP_INFO_news_release)
        
    *   [重要なお知らせ（通信障害）](https://www.docomo.ne.jp/info/network/?icid=CRP_menu_to_CRP_INFO_network)
        
    *   [携帯電話サービスの通信状況（地域別）](https://www.docomo.ne.jp/info/status/?icid=CRP_menu_to_CRP_INFO_status)
        
    *   [工事のお知らせ](https://www.docomo.ne.jp/info/construction/?icid=CRP_menu_to_CRP_INFO_construction)
        
    
*   企業情報
    
    *   [企業情報トップ](https://www.docomo.ne.jp/corporate/?icid=CRP_menu_to_CRP_CORP)
        
    *   [あなたとドコモ](https://www.docomo.ne.jp/corporate/anatatodocomo/?icid=CRP_menu_to_CRP_CORP_anatatodocomo)
        
    *   [企業理念・ビジョン](https://www.docomo.ne.jp/corporate/philosophy_vision/?icid=CRP_menu_to_CRP_CORP_philosophy_vision)
        
    *   [会社案内](https://www.docomo.ne.jp/corporate/about/?icid=CRP_menu_to_CRP_CORP_about)
        
    *   [サステナビリティ](https://www.docomo.ne.jp/corporate/csr/?icid=CRP_menu_to_CRP_CORP_csr)
        
    *   [技術とあんしん](https://www.docomo.ne.jp/corporate/technology_safety/?icid=CRP_menu_to_CRP_CORP_technology_safety)
        
    *   [IR情報](https://www.docomo.ne.jp/corporate/ir/library/?icid=CRP_menu_to_CRP_CORP_ir_library)
        
    *   [採用情報](https://www.docomo.ne.jp/corporate/recruit/?icid=CRP_menu_to_CRP_CORP_recruit)
        
    *   [NTTドコモグループ_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://nttdocomo-group.com/index.html)
        
    
*   法人のお客さま
    
    *   [NTTドコモビジネス_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.ntt.com/index.html)
        
    *   [NTTドコモ  \
        ソリューションズ_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.nttcom.co.jp/)
        
    *   [NTTドコモ・グローバル](https://www.docomo.ne.jp/global/?icid=CRP_TOP_to_CRP_global)
        
    
*   [![別ウィンドウで開きます。my docomo](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-my-docomo-logo.svg)](https://www.docomo.ne.jp/mydocomo/?icid=CRP_outerhead_to_MYD_TOP)
    
    [![別ウィンドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-online-shop-icon.svg)\
    \
    Online Shop](https://onlineshop.docomo.ne.jp/top-ols/?xcid=OLS_TOP_from_CRP_outerhead)
    
    [![別ウィンドウで開きます。のりかえ（MNP）](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-online-mnp-icon_pc.png)](https://onlineshop.docomo.ne.jp/special-contents/mnp?xcid=OLS_special-contents_mnp_flow_from_CRP_TOP_mnp_btn)
    
    [![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-switch-online-icon.svg)機種変更](https://www.docomo.ne.jp/support/switch_online/?icid=CRP_outerhead_to_SUP_switch_online)
    

 [![](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-daccount-logo.svg) ログインする](https://www.docomo.ne.jp/product/)

[![dポイントクラブ](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-d-point-club-logo.svg)\
\
P\
\
![ランク](https://www.docomo.ne.jp/product/)](https://www.docomo.ne.jp/product/)
[![ドコモビジネスメンバーズ](https://www.docomo.ne.jp/images_osp/common/newhf/ico/ico_businessmembers.png)](https://www.docomo.ne.jp/product/)

MENU

[![NTT docomo](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-header-logo.svg?ver=1751324418)](https://www.docomo.ne.jp/?icid=CRP_drawer_to_CRP_TOP)

[English](https://www.docomo.ne.jp/english/?icid=CRP_drawer_to_CRP_EN)

* * *

   ![検索する](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-header-search-icon.svg)

*    [![](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-my-docomo-logo.svg) My docomo _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.docomo.ne.jp/mydocomo/?icid=CRP_drawer_to_MYD_TOP)
     
*    [![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-online-shop-icon.svg) Online Shop _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://onlineshop.docomo.ne.jp/top-ols/?xcid=OLS_TOP_from_CRP_drawer)
     
*    [![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-docomo-shop-icon.svg) ドコモショップ _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://shop.smt.docomo.ne.jp/?xcid=DS_TOP_from_CRP_drawer)
     
*    [![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-customer-support-icon.svg) お客さまサポート](https://www.docomo.ne.jp/support/?icid=CRP_drawer_sup01_to_CRP_SUP)
    
*    [![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-campaign-icon.svg) キャンペーン・特典](https://www.docomo.ne.jp/campaign_event/?icid=CRP_drawer_to_CRP_CAM)
    
*    [![](https://www.docomo.ne.jp/assets/content/dam/corp/jp/ja/common/images/logo/cmn-rwd-d-point-club-logo.svg) dポイントクラブ _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://dpoint.docomo.ne.jp/)
     

*   *   *   商品・サービス
        *   *   ![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/ico_mobile.png) モバイル
                
                *   [iPhone](https://www.docomo.ne.jp/iphone/?icid=CRP_drawer_to_CRP_IPH)
                    
                *   [iPad](https://www.docomo.ne.jp/ipad/?icid=CRP_drawer_to_CRP_IPA)
                    
                *   [製品](https://www.docomo.ne.jp/product/?icid=CRP_drawer_to_CRP_PRD)
                    
                *   [料金・割引](https://www.docomo.ne.jp/charge/?icid=CRP_drawer_to_CRP_CHA)
                    
                *   [サービス・機能](https://www.docomo.ne.jp/service/?icid=CRP_drawer_to_CRP_SER)
                    
                *   [通信・エリア](https://www.docomo.ne.jp/area/?icid=CRP_drawer_to_CRP_AREA)
                    
                
            *   ![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/ico_internet.png) インターネット回線・固定電話
                
                *   [インターネット回線・固定電話トップ](https://www.docomo.ne.jp/internet/?icid=CRP_drawer_to_CRP_INT)
                    
                *   [ドコモ光](https://www.docomo.ne.jp/internet/hikari/?icid=CRP_drawer_to_CRP_INT_hikari)
                    
                *   [ahamo光](https://www.docomo.ne.jp/internet/ahamo_hikari/?icid=CRP_drawer_to_CRP_internet_ahamo_hikari)
                    
                *   [home 5G](https://www.docomo.ne.jp/home_5g/?icid=CRP_drawer_to_CRP_HOM)
                    
                *   [homeでんわ](https://www.docomo.ne.jp/home_denwa/?icid=CRP_drawer_to_CRP_DENWA)
                    
                
            *   ![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/ico_smartlife.png) スマートライフ
                
                *   [スマートライフ トップ](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_drawer_to_CRP_SER_smart-life)
                    
                *   [決済・保険・投資](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_drawer_to_CRP_SER_smart-life_finance&tgl_entertainment=0&tgl_life-support=0&tgl_finance=1&tgl_shopping=0&tgl_healthcare=0#finance)
                    
                *   [エンターテインメント](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_drawer_to_CRP_SER_smart-life_entertainment&tgl_entertainment=1&tgl_life-support=0&tgl_finance=0&tgl_shopping=0&tgl_healthcare=0#entertainment)
                    
                *   [ライフサポート](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_drawer_to_CRP_SER_smart-life_life-support&tgl_entertainment=0&tgl_life-support=1&tgl_finance=0&tgl_shopping=0&tgl_healthcare=0#life-support)
                    
                *   [ショッピング](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_drawer_to_CRP_SER_smart-life_shopping&tgl_entertainment=0&tgl_life-support=0&tgl_finance=0&tgl_shopping=1&tgl_healthcare=0#shopping)
                    
                *   [ヘルスケア](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_drawer_to_CRP_SER_smart-life_healthcare&tgl_entertainment=0&tgl_life-support=0&tgl_finance=0&tgl_shopping=0&tgl_healthcare=1#healthcare)
                    
                
            *   ![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/ico_denki.png?ver=1748827032) 電気・ガス
                
                *   [ドコモでんき／  \
                    ドコモ ガス トップ](https://www.docomo.ne.jp/denki/?icid=CRP_drawer_to_CRP_DENKI)
                    
                
    *   *   お知らせ
        *   *   お知らせ
                
                *   [お知らせ トップ](https://www.docomo.ne.jp/info/?icid=CRP_drawer_to_CRP_INFO)
                    
                *   [ニュースルーム](https://www.docomo.ne.jp/info/update/?icid=CRP_drawer_to_CRP_INFO_update)
                    
                *   [報道発表](https://www.docomo.ne.jp/info/news_release/?icid=CRP_drawer_to_CRP_INFO_news_release)
                    
                *   [重要なお知らせ（通信障害）](https://www.docomo.ne.jp/info/network/?icid=CRP_drawer_to_CRP_INFO_network)
                    
                *   [携帯電話サービスの通信状況（地域別）](https://www.docomo.ne.jp/info/status/?icid=CRP_drawer_to_CRP_INFO_status)
                    
                *   [工事のお知らせ](https://www.docomo.ne.jp/info/construction/?icid=CRP_drawer_to_CRP_INFO_construction)
                    
                
    *   *   企業情報
        *   *   企業情報
                
                *   [企業情報 トップ](https://www.docomo.ne.jp/corporate/?icid=CRP_drawer_to_CRP_CORP)
                    
                *   [あなたとドコモ](https://www.docomo.ne.jp/corporate/anatatodocomo/?icid=CRP_drawer_to_CRP_CORP_anatatodocomo)
                    
                *   [企業理念・ビジョン](https://www.docomo.ne.jp/corporate/philosophy_vision/?icid=CRP_drawer_to_CRP_CORP_philosophy_vision)
                    
                *   [会社案内](https://www.docomo.ne.jp/corporate/about/?icid=CRP_drawer_to_CRP_CORP_about)
                    
                *   [サステナビリティ](https://www.docomo.ne.jp/corporate/csr/?icid=CRP_drawer_to_CRP_CORP_csr)
                    
                *   [技術とあんしん](https://www.docomo.ne.jp/corporate/technology_safety/?icid=CRP_drawer_to_CRP_CORP_technology_safety)
                    
                *   [IR情報](https://www.docomo.ne.jp/corporate/ir/library/?icid=CRP_drawer_to_CRP_CORP_ir_library)
                    
                *   [採用情報](https://www.docomo.ne.jp/corporate/recruit/?icid=CRP_drawer_to_CRP_CORP_recruit)
                    
                *   [NTTドコモグループ_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://nttdocomo-group.com/index.html)
                    
                
*   *   地域別情報
        
        *   [北海道](https://www.docomo.ne.jp/hokkaido/?icid=CRP_drawer_to_hokkaido)
            
        *   [東北](https://www.docomo.ne.jp/tohoku/?icid=CRP_drawer_to_tohoku)
            
        *   [関東・甲信越](https://www.docomo.ne.jp/kanto/?icid=CRP_drawer_to_kanto)
            
        *   [東海](https://www.docomo.ne.jp/tokai/?icid=CRP_drawer_to_tokai)
            
        *   [北陸](https://www.docomo.ne.jp/hokuriku/?icid=CRP_drawer_to_hokuriku)
            
        *   [関西](https://www.docomo.ne.jp/kansai/?icid=CRP_drawer_to_kansai)
            
        *   [中国](https://www.docomo.ne.jp/chugoku/?icid=CRP_drawer_to_chugoku)
            
        *   [四国](https://www.docomo.ne.jp/shikoku/?icid=CRP_drawer_to_shikoku)
            
        *   [九州・沖縄](https://www.docomo.ne.jp/kyushu/?icid=CRP_drawer_to_kyushu)
            
        
    *   地域別情報
        
        *   [北海道](https://www.docomo.ne.jp/hokkaido/?icid=CRP_drawer_to_hokkaido)
            |
        *   [東北](https://www.docomo.ne.jp/tohoku/?icid=CRP_drawer_to_tohoku)
            |
        *   [関東・甲信越](https://www.docomo.ne.jp/kanto/?icid=CRP_drawer_to_kanto)
            |
        *   [東海](https://www.docomo.ne.jp/tokai/?icid=CRP_drawer_to_tokai)
            |
        *   [北陸](https://www.docomo.ne.jp/hokuriku/?icid=CRP_drawer_to_hokuriku)
            |
        *   [関西](https://www.docomo.ne.jp/kansai/?icid=CRP_drawer_to_kansai)
            |
        *   [中国](https://www.docomo.ne.jp/chugoku/?icid=CRP_drawer_to_chugoku)
            |
        *   [四国](https://www.docomo.ne.jp/shikoku/?icid=CRP_drawer_to_shikoku)
            |
        *   [九州・沖縄](https://www.docomo.ne.jp/kyushu/?icid=CRP_drawer_to_kyushu)
            
        
*   *   法人のお客さま
        
        *   [NTTドコモビジネス_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.ntt.com/index.html)
            
        *   [NTTドコモソリューションズ_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.nttcom.co.jp/)
            
        *   [NTTドコモ・グローバル](https://www.docomo.ne.jp/global/?icid=CRP_drawer_to_CRP_global)
            
        
    *   法人のお客さま
        
        *   [NTTドコモビジネス_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.ntt.com/index.html)
            |
        *   [NTTドコモソリューションズ_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.nttcom.co.jp/)
            |
        *   [NTTドコモ・グローバル](https://www.docomo.ne.jp/global/?icid=CRP_drawer_to_CRP_global)
            
        

[![](https://www.docomo.ne.jp/assets/content/dam/corp/jp/ja/common/images/logo/cmn-rwd-d-point-club-logo.svg)](https://www.docomo.ne.jp/product/)

*   [dアカウントでもっと便利に](https://www.docomo.ne.jp/utility/daccount/?icid=CRP_drawer_to_CRP_UTI_daccount)
    
*   [別のIDでログイン](https://cfg.smt.docomo.ne.jp/auth/cgi/anidlogin?rl=https%3A%2F%2Fwww.docomo.ne.jp%2F)
    
*   [ログアウト](https://www.docomo.ne.jp/mydocomo/utility/confirm_logout/index.html)
    
*   [会員情報確認・変更_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon-white.svg)_](https://profile.smt.docomo.ne.jp/VIEW_ESITE/mem/sc/main.jsp?nid=MEG002006BJP)
    
*   [ログインでお困りの方_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon-white.svg)_](https://id.smt.docomo.ne.jp/src/utility/idpw_forget.html)
    
*   [２段階認証のお願い_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon-white.svg)_](https://id.smt.docomo.ne.jp/src/utility/sp/twostepauth.html)
    

オートログイン中

[![ランク](https://www.docomo.ne.jp/product/#)](https://dpoint.docomo.ne.jp/member/stage_info/index.html)

* * *

[うち期間・用途限定](https://www.docomo.ne.jp/product/)

* * *

[![ドコモビジネスメンバーズ](https://www.docomo.ne.jp/images_osp/common/newhf/ico/ico_businessmembers.png)](https://www.docomo.ne.jp/product/)

*   [別のIDでログイン](https://cfg.smt.docomo.ne.jp/auth/cgi/anidlogin?rl=https%3A%2F%2Fwww.docomo.ne.jp%2F)
    
*   [ログアウト](https://www.docomo.ne.jp/mydocomo/utility/confirm_logout/index.html)
    
*   [会員情報確認・変更_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon-white.svg)_](https://profile.smt.docomo.ne.jp/VIEW_ESITE/mem/sc/main.jsp?nid=MEG002006BJP)
    
*   [２段階認証のお願い_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon-white.svg)_](https://id.smt.docomo.ne.jp/src/utility/sp/twostepauth.html)
    

*   [CMギャラリー_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.youtube.com/playlist?list=PLB334710B4B8111A8)
    
*   [よくあるご質問](https://faq.front.smt.docomo.ne.jp/?utm_source=docomo.ne.jp&utm_medium=api_linkage&utm_campaign=api_CRP_TOP)
    
*   [見やすさ・使いやすさの調整](https://www.docomo.ne.jp/utility/term/web_accessibility/faciliti/?icid=CRP_drawer_to_CRP_UTI_term_web_accessibility_faciliti)
    
*   [パーソナルデータ（個人情報など）について](https://www.docomo.ne.jp/utility/personal_data/?icid=CRP_drawer_to_CRP_UTI_personal_data)
    

*    [![](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-daccount-logo.svg) ログインする](https://www.docomo.ne.jp/product/)
    
*   [![別ウィンドウで開きます。のりかえ（MNP）](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-online-mnp-icon_smt.png)](https://onlineshop.docomo.ne.jp/special-contents/mnp?xcid=OLS_special-contents_mnp_flow_from_CRP_TOP_mnp_btn)
    

*   [![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-switch-online-icon.svg)機種変更](https://www.docomo.ne.jp/support/switch_online/?icid=CRP_outerhead_to_SUP_switch_online)
    
*   [![](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-d-point-club-logo.svg)\
    \
    P\
    \
    ![](https://www.docomo.ne.jp/product/)](https://www.docomo.ne.jp/product/)
    

[![ドコモビジネスメンバーズ](https://www.docomo.ne.jp/images_osp/common/newhf/ico/ico_businessmembers.png)](https://www.docomo.ne.jp/product/)

お客さまの設定により、お客さま情報が「非表示」となっております。お客さま情報を表示するにはdアカウントでログインしてください。  
[お客さま情報表示について](https://www.docomo.ne.jp/product/)
へ

[お客さま情報表示について](https://www.docomo.ne.jp/product/)
へ

*   [ホーム](https://www.docomo.ne.jp/)
    
*   製品

製品
==

 ![タブの自動切り替えを停止](https://www.docomo.ne.jp/assets/content/dam/corp/jp/ja/common/image/main_pr/pause.svg)![タブの自動切り替えを再開](https://www.docomo.ne.jp/assets/content/dam/corp/jp/ja/common/image/main_pr/play.svg)

*   11
*   22
*   33
*   44

![前へ](https://www.docomo.ne.jp/images_osp/common/btn/btn_carousel_prev01.png)

*   [![1年ごとにおトクに最新機種へ買いかえできるプログラム！](https://www.docomo.ne.jp/assets/content/dam/corp/jp/ja/home/images/campaign_event/mobile_event/cp_mobile_event_50_230822.png?ver=1695176845)](https://www.docomo.ne.jp/campaign_event/kaedoki_program_plus/?icid=CRP_PRD_carousel_to_CRP_CAM_kaedoki_program_plus)
    
*   [![下取りプログラム iPhone・Androidスマホ・iPad・タブレットなどを下取り実施中](https://www.docomo.ne.jp/flcache_data/product/images/img_mainpr_shitadori.jpg?ver=1750320015)](https://www.docomo.ne.jp/campaign_event/shitadori/?icid=CRP_PRD_carousel_to_CRP_CAM_shitadori)
    
*   [![SPECIAL SALE 人気機種が大幅割引！](https://www.docomo.ne.jp/flcache_data/product/images/img_mainpr_special_sale_02.png?ver=1764637222)![別ウインドウが開きます](https://www.docomo.ne.jp/assets/content/dam/corp/jp/ja/home/images/campaign_event/common/cmn-rwd-new-window-icon.svg)](https://onlineshop.docomo.ne.jp/special/special-sale?xcid=OLS_SP_special-sale_from_CRP_PRD_carousel)
    
*   [![“あなたのぴったり”がみつかる！ 自分で探せる、docomoで買える、なんでも選べる！](https://www.docomo.ne.jp/flcache_data/product/images/img_mainpr_cross_use.jpg?ver=1753405215)](https://www.docomo.ne.jp/product/promotion/cross_use/?icid=CRP_PRD_top_to_CRP_PRD_promotion_cross_use)
    
*   [![1年ごとにおトクに最新機種へ買いかえできるプログラム！](https://www.docomo.ne.jp/assets/content/dam/corp/jp/ja/home/images/campaign_event/mobile_event/cp_mobile_event_50_230822.png?ver=1695176845)](https://www.docomo.ne.jp/campaign_event/kaedoki_program_plus/?icid=CRP_PRD_carousel_to_CRP_CAM_kaedoki_program_plus)
    
*   [![下取りプログラム iPhone・Androidスマホ・iPad・タブレットなどを下取り実施中](https://www.docomo.ne.jp/flcache_data/product/images/img_mainpr_shitadori.jpg?ver=1750320015)](https://www.docomo.ne.jp/campaign_event/shitadori/?icid=CRP_PRD_carousel_to_CRP_CAM_shitadori)
    
*   [![SPECIAL SALE 人気機種が大幅割引！](https://www.docomo.ne.jp/flcache_data/product/images/img_mainpr_special_sale_02.png?ver=1764637222)![別ウインドウが開きます](https://www.docomo.ne.jp/assets/content/dam/corp/jp/ja/home/images/campaign_event/common/cmn-rwd-new-window-icon.svg)](https://onlineshop.docomo.ne.jp/special/special-sale?xcid=OLS_SP_special-sale_from_CRP_PRD_carousel)
    
*   [![“あなたのぴったり”がみつかる！ 自分で探せる、docomoで買える、なんでも選べる！](https://www.docomo.ne.jp/flcache_data/product/images/img_mainpr_cross_use.jpg?ver=1753405215)](https://www.docomo.ne.jp/product/promotion/cross_use/?icid=CRP_PRD_top_to_CRP_PRD_promotion_cross_use)
    
*   [![1年ごとにおトクに最新機種へ買いかえできるプログラム！](https://www.docomo.ne.jp/assets/content/dam/corp/jp/ja/home/images/campaign_event/mobile_event/cp_mobile_event_50_230822.png?ver=1695176845)](https://www.docomo.ne.jp/campaign_event/kaedoki_program_plus/?icid=CRP_PRD_carousel_to_CRP_CAM_kaedoki_program_plus)
    
*   [![下取りプログラム iPhone・Androidスマホ・iPad・タブレットなどを下取り実施中](https://www.docomo.ne.jp/flcache_data/product/images/img_mainpr_shitadori.jpg?ver=1750320015)](https://www.docomo.ne.jp/campaign_event/shitadori/?icid=CRP_PRD_carousel_to_CRP_CAM_shitadori)
    

![次へ](https://www.docomo.ne.jp/images_osp/common/btn/btn_carousel_next01.png)

おすすめ！
-----

Apple製品
-------

[### iPhone\
\
![iPhone](https://www.docomo.ne.jp/flcache_data/common/images/img_product_01.png?ver=1757492410)](https://www.docomo.ne.jp/iphone/?icid=CRP_PRD_to_CRP_IPH)

[### iPad\
\
![iPad](https://www.docomo.ne.jp/flcache_data/common/images/img_product_02.png?ver=1760597231)](https://www.docomo.ne.jp/ipad/?icid=CRP_PRD_to_CRP_IPA)

Android™製品
----------

[### Android™  \
スマートフォン\
\
![Android™ スマートフォン](https://www.docomo.ne.jp/flcache_data/common/images/img_product_17.png?ver=1761872431)](https://www.docomo.ne.jp/product/android_smartphone.html?icid=CRP_PRD_to_CRP_PRD_android_smartphone)

[### Android™ タブレット\
\
![Android™ タブレット](https://www.docomo.ne.jp/flcache_data/common/images/img_product_05.png?ver=1666338672)](https://www.docomo.ne.jp/product/tablet.html?icid=CRP_PRD_to_CRP_PRD_tablet)

Watch製品
-------

[### Apple Watch\
\
![Apple Watch](https://www.docomo.ne.jp/flcache_data/common/images/img_product_10.png?ver=1757492410)](https://www.docomo.ne.jp/apple-watch/?icid=CRP_PRD_to_CRP_AW)

[### スマートウォッチ\
\
![スマートウォッチ](https://www.docomo.ne.jp/flcache_data/common/images/img_product_26.png?ver=1755734415)](https://www.docomo.ne.jp/product/smart_watch.html?icid=CRP_PRD_to_PRD_smart_watch)

ドコモケータイ など
----------

[### ドコモ ケータイ\
\
![ドコモ ケータイ](https://www.docomo.ne.jp/flcache_data/common/images/img_product_06.png?ver=1665018026)](https://www.docomo.ne.jp/product/feature_phone.html?icid=CRP_PRD_to_CRP_PRD_feature_phone)

[### ドコモ らくらくホン\
\
![ドコモ らくらくホン](https://www.docomo.ne.jp/flcache_data/common/images/img_product_07.png?ver=1750125618)](https://www.docomo.ne.jp/product/easy_phone.html?icid=CRP_PRD_to_CRP_PRD_easy_phone)

[### ドコモ キッズ\
\
![ドコモ キッズ](https://www.docomo.ne.jp/flcache_data/common/images/img_product_08.png?ver=1709859629)](https://www.docomo.ne.jp/product/kids_junior.html?icid=CRP_PRD_to_CRP_PRD_kids_junior)

ルーター・その他
--------

[### データ通信製品\
\
![データ通信製品](https://www.docomo.ne.jp/flcache_data/common/images/img_product_09.png?ver=1758157223)](https://www.docomo.ne.jp/product/data.html?icid=CRP_PRD_to_CRP_PRD_data)

[### home 5G /  \
home でんわ\
\
![home 5G/home でんわ](https://www.docomo.ne.jp/flcache_data/common/images/img_product_21.png?ver=1692666025)](https://www.docomo.ne.jp/product/home_5g.html?icid=CRP_PRD_to_CRP_PRD_home_5g)

[### Chromebook\
\
![Chromebook](https://www.docomo.ne.jp/flcache_data/common/images/img_product_29.png?ver=1728954024)](https://www.docomo.ne.jp/product/cm30/?icid=CRP_PRD_to_CRP_PRD_cm30)

[### イエナカ関連製品\
\
![イエナカ関連製品](https://www.docomo.ne.jp/flcache_data/common/images/img_product_27.png?ver=1715648423)](https://www.docomo.ne.jp/product/chikaku/?icid=CRP_PRD_to_CRP_PRD_chikaku)

[### ワイヤレス  \
イヤホン\
\
![ワイヤレスイヤホン](https://www.docomo.ne.jp/flcache_data/common/images/img_product_25.png?ver=1690246816)\
\
_別ウインドウが開きます_](https://onlineshop.docomo.ne.jp/products/accessories/list?category=17&xcid=OLS_products_accessories_list_from_CRP_PRD)

[### XR対応製品\
\
![XR対応製品](https://www.docomo.ne.jp/flcache_data/common/images/img_product_18.png?ver=1700614828)](https://www.docomo.ne.jp/product/xr.html?icid=CRP_PRD_to_CRP_PRD_xr)

[### スマートリング\
\
![スマートリング](https://www.docomo.ne.jp/flcache_data/common/images/img_product_28.png?ver=1745971212)](https://www.docomo.ne.jp/product/smart_ring.html?icid=CRP_PRD_to_CRP_PRD_smart_ring)

[### docomo select\
\
![docomo select](https://www.docomo.ne.jp/flcache_data/common/images/img_product_12.png?ver=1670221512)](https://www.docomo.ne.jp/product/docomo_select.html?icid=CRP_PRD_to_CRP_PRD_docomo_select)

[### デバイス  \
お試しサービス  \
kikito\
\
![デバイスお試しサービス kikito](https://www.docomo.ne.jp/flcache_data/common/images/img_product_20.png?ver=1635230112)\
\
_別ウインドウが開きます_](https://rental.kikito.docomo.ne.jp/?utm_source=corp_product&utm_medium=other&utm_campaign=kikito_202103_corporateproduct)

[### ドコモ認定リユース品  \
（中古品）\
\
![ドコモ認定リユース品（中古品）](https://www.docomo.ne.jp/flcache_data/common/images/img_product_30.png?ver=1732842851)](https://www.docomo.ne.jp/special_contents/docomo-certified/?icid=CRP_PRD_to_CRP_SPE_docomo-certified)

[![働くあなたの1日をドコモでもっと快適に！](https://www.docomo.ne.jp/flcache_data/product/images/common/bnr_business_product_w940_pc.png?ver=1757034031)![働くあなたの1日をドコモでもっと快適に！](https://www.docomo.ne.jp/flcache_data/product/images/common/bnr_business_product_w676_smt.png?ver=1757034030)](https://www.docomo.ne.jp/product/promotion/business_product/?icid=CRP_PRD_to_CRP_PRD_promotion_business_product)

[![子育てをもっと楽しく、もっと便利に！こどもと、ドコモと、パパとママと。](https://www.docomo.ne.jp/flcache_data/product/promotion/kids_product/images/bnr_kids_products_w940_pc.png?ver=1728349219)![子育てをもっと楽しく、もっと便利に！こどもと、ドコモと、パパとママと。](https://www.docomo.ne.jp/flcache_data/product/promotion/kids_product/images/bnr_kids_products_w676_smt.png?ver=1728349219)](https://www.docomo.ne.jp/product/promotion/kids_product/?icid=CRP_PRD_to_CRP_PRD_promotion_kids_product)

[![SPECIAL SALE 人気機種が大幅割引！](https://www.docomo.ne.jp/flcache_data/product/images/bnr_onlineshop_02_pc.png?ver=1764637222)![SPECIAL SALE 人気機種が大幅割引！](https://www.docomo.ne.jp/flcache_data/product/images/bnr_onlineshop_02_smt.png?ver=1764637222)_![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://onlineshop.docomo.ne.jp/special/special-sale?xcid=OLS_SP_special-sale_from_CRP_PRD)

[![docomo Certified ドコモが選んだ、リユース品。ドコモの認定 リユース スマートフォン 30日間保証であんしん](https://www.docomo.ne.jp/flcache_data/product/images/bnr_reuse_02_pc.png?ver=1675061472)![docomo Certified ドコモが選んだ、リユース品。ドコモの認定 リユース スマートフォン 30日間保証であんしん](https://www.docomo.ne.jp/flcache_data/product/images/bnr_reuse_02_smt.png?ver=1675061472)_![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://onlineshop.docomo.ne.jp/products/other/docomo-certified?category=036&xcid=OLS_products_other_docomo-certified_from_CRP_PRD)

*   リンク先の価格はドコモオンラインショップの販売価格となります。
    

[![スマホを売るならあんしんの買取プログラム ドコモ以外の機種もOK！画面割れや水濡れでも何台でもOK！](https://www.docomo.ne.jp/flcache_data/product/images/bnr_sp_kaitori_01_pc.png?ver=1733360419)![スマホを売るならあんしんの買取プログラム ドコモ以外の機種もOK！画面割れや水濡れでも何台でもOK！](https://www.docomo.ne.jp/flcache_data/product/images/bnr_sp_kaitori_01_smt.png?ver=1733360419)](https://www.docomo.ne.jp/service/sp_kaitori/?icid=CRP_PRD_to_CRP_SER_sp_kaitori)

製品のサポート情報
---------

### 製品別のサポート情報を探す

名称や型番から、製品情報、アップデート情報、取扱説明書が探せます。

![検索](https://www.docomo.ne.jp/images_osp/common/ico/ico_search01.png)

入力例（GALAXY、F-05D）

### 故障かな？と思ったときは

#### [おたすけロボット_別ウインドウが開きます_](https://ct-otasuke-robot.macaron.docomo.ne.jp/sp/?utm_source=product_top&utm_medium=referral)

スマートフォン・タブレットやドコモ光に関する疑問・お困りごとを診断し、おたすけロボットがチャット形式で24時間いつでも回答いたします。

#### [スマホ診断 online__](https://www.docomo.ne.jp/service/diagnosis/?icid=CRP_PRD_to_CRP_SER_diagnosis)

ドコモのスマートフォン、タブレットをお使いのお客さまに、故障かな？と思ったときにその場で簡単に診断ができるアプリ「スマホ診断 online」をご案内いたします。

### 安全にケータイを使うために

#### [安全に関するご注意__](https://www.docomo.ne.jp/support/safety/?icid=CRP_PRD_to_CRP_SUP_utilization_safety)

ドコモのケータイや電池、アダプタ（充電器含む）などのオプション品をお使いになる前に、よくご注意事項をお読みください。

#### [携帯電話の電波防護への適合性について_PCサイトが開きます___](https://www.docomo.ne.jp/product/sar/?icid=CRP_PRD_to_CRP_PRD_sar)

各機種の電波防護への適合性を参照できます。

![](https://www.docomo.ne.jp/images_osp/common/ico/icon_red_notice.png) 盗難・紛失したときは
----------------------------------------------------------------------------------

****まずは「[利用中断](https://www.docomo.ne.jp/support/inquiry/lost/?icid=CRP_PRD_to_CRP_SUP_inquiry_lost#p001)
」をおこなってください。****24時間受付

更新情報
----

[![](https://www.docomo.ne.jp/images_osp/common/ico/ico_rss_01.png)RSS](https://www.docomo.ne.jp/info/rss/)

*   2025年10月31日
    
    [「AQUOS sense10 SH-53F」11月13日発売](https://www.docomo.ne.jp/product/sh53f/)
    
*   2025年10月24日
    
    [「Aterm CM51FD」10月31日発売](https://www.docomo.ne.jp/product/cm51fd/)
    
*   2025年10月2日
    
    [「Xperia 10 VII SO-52F」10月9日発売](https://www.docomo.ne.jp/product/so52f/)
    

[更新情報一覧へ__](https://www.docomo.ne.jp/info/update/?icid=CRP_PRD_to_CRP_INFO_update&directSearch=1&year-select=%E3%83%BC&category-select=%E6%9B%B4%E6%96%B0%E6%83%85%E5%A0%B1&type=%E8%A3%BD%E5%93%81)

キャンペーン・特典
---------

[### 家族まとめてキャンペーン\
\
![家族まとめてキャンペーン](https://www.docomo.ne.jp/campaign_event/common/images/20250701_kazoku.png)\
\
ご家族で2台（同一名義可）対象機種を購入（同一店舗・同月内）していただくと、ご購入者それぞれに後日dポイントを進呈！](https://www.docomo.ne.jp/campaign_event/kazoku_matomete6/?icid=CRP_PRD_img_to_CRP_CAM_kazoku_matomete6)

[キャンペーン・特典一覧へ__](https://www.docomo.ne.jp/campaign_event/?icid=CRP_PRD_to_CRP_CAM)

キャンペーン・特典
---------

[### 家族まとめてキャンペーン\
\
![家族まとめてキャンペーン](https://www.docomo.ne.jp/campaign_event/common/images/20250701_kazoku.png)\
\
ご家族で2台（同一名義可）対象機種を購入（同一店舗・同月内）していただくと、ご購入者それぞれに後日dポイントを進呈！](https://www.docomo.ne.jp/campaign_event/kazoku_matomete6/?icid=CRP_SMT_PRD_txt_to_CRP_SMT_CAM_kazoku_matomete6)

[キャンペーン・特典一覧へ__](https://www.docomo.ne.jp/campaign_event/?icid=CRP_PRD_to_CRP_CAM)

    

*   機種の販売価格は、店舗ごとに異なります。
    
*   Apple、Appleのロゴ、AirPlay、AirPods、Apple Music、Apple Pay、Apple Pencil、Apple TV、Apple Watch、Ceramic Shield、Dynamic Island、Face ID、FaceTime、iBooks、iPad、iPhone、iTunes、Lightning、Magic Keyboard、MagSafe、ProMotion、Siri、Touch ID、TrueDepth、True Toneは、米国および他の国々で登録されたApple Inc.の商標です。iPhoneの商標は、[アイホン株式会社_別ウインドウが開きます_](https://www.aiphone.co.jp/)
    のライセンスにもとづき使用されています。App Store、Apple Arcade、AppleCare+、Apple TV+、iCloudは、Apple Inc.のサービスマークです。TM and © 2025 Apple Inc. All rights reserved.
    
*   Android は Google LLC の商標です。
    

[![docomo Online Shop 2,750円（税込）以上で送料は当社負担！](https://www.docomo.ne.jp/product/images/common/bnr_onlineshop_01.png?ver=1717660152)_別ウインドウが開きます_](https://onlineshop.docomo.ne.jp/top-ols?online_shop=product_top&xcid=OLS_TOP_from_CRP_PRD_TOP)

****ドコモ最新機種情報****をいち早くお届け!

*   [](https://www.facebook.com/docomo.official)
    ![facebook](https://www.docomo.ne.jp/product/images/common/ico_sns_facebook_01.png?ver=1570762834)
*   [](https://twitter.com/docomo)
    ![twitter](https://www.docomo.ne.jp/product/images/common/ico_sns_twitter_01.png?ver=1712131393)[@docomoをフォローする](https://twitter.com/docomo)
    
*   [![LINE](https://www.docomo.ne.jp/product/images/common/ico_sns_line_01.png?ver=1457467429)LINE公式アカウント__](https://www.docomo.ne.jp/utility/personal_data/social_media/?icid=CRP_PRD_to_CRP_utility_personal_data_social_media#line)
    

[![このページのトップへ](https://www.docomo.ne.jp/images_osp/common/btn/btn_pagetop_01.png)](https://www.docomo.ne.jp/product/#)

[![閉じる](https://www.docomo.ne.jp/images_osp/common/btn/btn_x_close_01_pc.png)![閉じる](https://www.docomo.ne.jp/images_osp/common/btn/btn_x_close_01_smt.png)](https://www.docomo.ne.jp/product/#)

オンラインなら簡単自宅受け取り  
事務手数料0円！

[![Online Shop](https://www.docomo.ne.jp/images_osp/common/bnr/bnr_online_shop_01_pc.png)![Online Shop](https://www.docomo.ne.jp/images_osp/common/bnr/bnr_online_shop_01_smt.png)](https://onlineshop.docomo.ne.jp/top-ols?xcid=OLS_TOP_from_CRP_PRD_float)

  

[![お困りですか？](https://www.docomo.ne.jp/images_osp/common/chat_tool/bnr_chat_tool.svg)](https://tetsuduki-support.docomo.ne.jp/?utm_source=corp&utm_medium=free-display&utm_campaign=onsapo_)

*   [お知らせ](https://www.docomo.ne.jp/info/?icid=CRP_common_footer_to_CRP_INFO)
    
*   [企業情報](https://www.docomo.ne.jp/corporate/?icid=CRP_common_footer_to_CRP_CORP)
    

* * *

*   [パーソナルデータ（個人情報など）について](https://www.docomo.ne.jp/utility/personal_data/?icid=CRP_common_footer_to_CRP_UTI_personal_data)
    
*   [プライバシーポリシー](https://www.docomo.ne.jp/utility/privacy/?icid=CRP_common_footer_to_CRP_UTI_privacy)
    
*   [サイトご利用にあたって](https://www.docomo.ne.jp/utility/term/?icid=CRP_common_footer_to_CRP_UTI_term)
    
*   [お客さまご利用端末からの情報の外部送信について](https://www.docomo.ne.jp/utility/term/?icid=CRP_common_footer_02_to_CRP_UTI_term#p09)
    
*   [見やすさ・使いやすさの調整](https://www.docomo.ne.jp/utility/term/web_accessibility/faciliti/?icid=CRP_common_footer_to_CRP_UTI_term_web_accessibility_faciliti)
    
*   [サイトメンテナンス情報_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon-white.svg)_](https://www.docomo.ne.jp/mydocomo/maint/?icid=CRP_common_footer_to_CRP_MYD_maint)
    
*   [サイトマップ](https://www.docomo.ne.jp/sitemap/?icid=CRP_common_footer_to_CRP_sitemap)
    
*   [ご意見・ご要望](https://www.docomo.ne.jp/support/inquiry/feedback/?icid=CRP_common_footer_to_CRP_SUP_inquiry_feedback)
    
*   [お問い合わせ](https://www.docomo.ne.jp/support/inquiry/?icid=CRP_common_footer_to_CRP_SUP_inquiry)
    
*   [NTTドコモグループ_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon-white.svg)_](https://nttdocomo-group.com/index.html)
    

© NTT DOCOMO

![閉じる](https://www.docomo.ne.jp/images_osp/common/smtnav/btn_smtmenu_01_close_crp.png)

M
