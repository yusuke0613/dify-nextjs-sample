# ドコモ光（光インターネット回線サービス） | インターネット回線・固定電話 | NTTドコモ

URL: https://www.docomo.ne.jp/hikari/

---

[![NTT docomo](https://www.docomo.ne.jp/images_osp/common/newhf/header/cmn-rwd-header-logo.svg?ver=1751324418)](https://www.docomo.ne.jp/?icid=CRP_common_header_to_CRP_TOP)

*   [![別ウィンドウで開きます。my docomo](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-my-docomo-logo.svg)](https://www.docomo.ne.jp/mydocomo/?icid=CRP_outerhead_to_MYD_TOP)
    
*   [![別ウィンドウで開きます。Online Shop](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-online-shop-icon2.svg)](https://onlineshop.docomo.ne.jp/top-ols/?xcid=OLS_TOP_from_CRP_outerhead)
    

*   商品・サービス
    
    *   *   モバイル
        *   *   [iPhone](https://www.docomo.ne.jp/iphone/?icid=CRP_menu_to_CRP_IPH)
                
            *   [iPad](https://www.docomo.ne.jp/ipad/?icid=CRP_menu_to_CRP_IPA)
                
            *   [製品](https://www.docomo.ne.jp/product/?icid=CRP_menu_to_CRP_PRD)
                
            *   [料金・割引](https://www.docomo.ne.jp/charge/?icid=CRP_menu_to_CRP_CHA)
                
            *   [サービス・機能](https://www.docomo.ne.jp/service/?icid=CRP_menu_to_CRP_SER)
                
            *   [通信・エリア](https://www.docomo.ne.jp/area/?icid=CRP_menu_to_CRP_AREA)
                
    *   *   インターネット回線・固定電話
        *   *   [インターネット回線・固定電話トップ](https://www.docomo.ne.jp/internet/?icid=CRP_menu_to_CRP_INT)
                
            *   [ドコモ光](https://www.docomo.ne.jp/internet/hikari/?icid=CRP_menu_to_CRP_INT_hikari)
                
            *   [ahamo光](https://www.docomo.ne.jp/internet/ahamo_hikari/?icid=CRP_menu_to_CRP_internet_ahamo_hikari)
                
            *   [home 5G](https://www.docomo.ne.jp/home_5g/?icid=CRP_menu_to_CRP_HOM)
                
            *   [homeでんわ](https://www.docomo.ne.jp/home_denwa/?icid=CRP_menu_to_CRP_DENWA)
                
    *   *   スマートライフ
        *   *   [スマートライフ トップ](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_menu_to_CRP_SER_smart-life)
                
            *   [決済・保険・投資](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_menu_to_CRP_SER_smart-life_finance&tgl_entertainment=0&tgl_life-support=0&tgl_finance=1&tgl_shopping=0&tgl_healthcare=0#finance)
                
            *   [エンターテインメント](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_menu_to_CRP_SER_smart-life_entertainment&tgl_entertainment=1&tgl_life-support=0&tgl_finance=0&tgl_shopping=0&tgl_healthcare=0#entertainment)
                
            *   [ライフサポート](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_menu_to_CRP_SER_smart-life_life-support&tgl_entertainment=0&tgl_life-support=1&tgl_finance=0&tgl_shopping=0&tgl_healthcare=0#life-support)
                
            *   [ショッピング](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_menu_to_CRP_SER_smart-life_shopping&tgl_entertainment=0&tgl_life-support=0&tgl_finance=0&tgl_shopping=1&tgl_healthcare=0#shopping)
                
            *   [ヘルスケア](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_menu_to_CRP_SER_smart-life_healthcare&tgl_entertainment=0&tgl_life-support=0&tgl_finance=0&tgl_shopping=0&tgl_healthcare=1#healthcare)
                
    *   *   電気・ガス
        *   *   [ドコモでんき／  \
                ドコモ ガス トップ](https://www.docomo.ne.jp/denki/?icid=CRP_menu_to_CRP_DENKI)
                
    
*   お知らせ
    
    *   [お知らせトップ](https://www.docomo.ne.jp/info/?icid=CRP_menu_to_CRP_INFO)
        
    *   [ニュースルーム](https://www.docomo.ne.jp/info/update/?icid=CRP_menu_to_CRP_INFO_update)
        
    *   [報道発表](https://www.docomo.ne.jp/info/news_release/?icid=CRP_menu_to_CRP_INFO_news_release)
        
    *   [重要なお知らせ（通信障害）](https://www.docomo.ne.jp/info/network/?icid=CRP_menu_to_CRP_INFO_network)
        
    *   [携帯電話サービスの通信状況（地域別）](https://www.docomo.ne.jp/info/status/?icid=CRP_menu_to_CRP_INFO_status)
        
    *   [工事のお知らせ](https://www.docomo.ne.jp/info/construction/?icid=CRP_menu_to_CRP_INFO_construction)
        
    
*   企業情報
    
    *   [企業情報トップ](https://www.docomo.ne.jp/corporate/?icid=CRP_menu_to_CRP_CORP)
        
    *   [あなたとドコモ](https://www.docomo.ne.jp/corporate/anatatodocomo/?icid=CRP_menu_to_CRP_CORP_anatatodocomo)
        
    *   [企業理念・ビジョン](https://www.docomo.ne.jp/corporate/philosophy_vision/?icid=CRP_menu_to_CRP_CORP_philosophy_vision)
        
    *   [会社案内](https://www.docomo.ne.jp/corporate/about/?icid=CRP_menu_to_CRP_CORP_about)
        
    *   [サステナビリティ](https://www.docomo.ne.jp/corporate/csr/?icid=CRP_menu_to_CRP_CORP_csr)
        
    *   [技術とあんしん](https://www.docomo.ne.jp/corporate/technology_safety/?icid=CRP_menu_to_CRP_CORP_technology_safety)
        
    *   [IR情報](https://www.docomo.ne.jp/corporate/ir/library/?icid=CRP_menu_to_CRP_CORP_ir_library)
        
    *   [採用情報](https://www.docomo.ne.jp/corporate/recruit/?icid=CRP_menu_to_CRP_CORP_recruit)
        
    *   [NTTドコモグループ_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://nttdocomo-group.com/index.html)
        
    
*   法人のお客さま
    
    *   [NTTドコモビジネス_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.ntt.com/index.html)
        
    *   [NTTドコモ  \
        ソリューションズ_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.nttcom.co.jp/)
        
    *   [NTTドコモ・グローバル](https://www.docomo.ne.jp/global/?icid=CRP_TOP_to_CRP_global)
        
    
*   [![別ウィンドウで開きます。my docomo](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-my-docomo-logo.svg)](https://www.docomo.ne.jp/mydocomo/?icid=CRP_outerhead_to_MYD_TOP)
    
    [![別ウィンドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-online-shop-icon.svg)\
    \
    Online Shop](https://onlineshop.docomo.ne.jp/top-ols/?xcid=OLS_TOP_from_CRP_outerhead)
    
    [![別ウィンドウで開きます。のりかえ（MNP）](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-online-mnp-icon_pc.png)](https://onlineshop.docomo.ne.jp/special-contents/mnp?xcid=OLS_special-contents_mnp_flow_from_CRP_TOP_mnp_btn)
    
    [![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-switch-online-icon.svg)機種変更](https://www.docomo.ne.jp/support/switch_online/?icid=CRP_outerhead_to_SUP_switch_online)
    

 [![](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-daccount-logo.svg) ログインする](https://www.docomo.ne.jp/hikari/)

[![dポイントクラブ](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-d-point-club-logo.svg)\
\
P\
\
![ランク](https://www.docomo.ne.jp/hikari/)](https://www.docomo.ne.jp/hikari/)
[![ドコモビジネスメンバーズ](https://www.docomo.ne.jp/images_osp/common/newhf/ico/ico_businessmembers.png)](https://www.docomo.ne.jp/hikari/)

MENU

[![NTT docomo](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-header-logo.svg?ver=1751324418)](https://www.docomo.ne.jp/?icid=CRP_drawer_to_CRP_TOP)

[English](https://www.docomo.ne.jp/english/?icid=CRP_drawer_to_CRP_EN)

* * *

   ![検索する](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-header-search-icon.svg)

*    [![](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-my-docomo-logo.svg) My docomo _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.docomo.ne.jp/mydocomo/?icid=CRP_drawer_to_MYD_TOP)
     
*    [![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-online-shop-icon.svg) Online Shop _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://onlineshop.docomo.ne.jp/top-ols/?xcid=OLS_TOP_from_CRP_drawer)
     
*    [![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-docomo-shop-icon.svg) ドコモショップ _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://shop.smt.docomo.ne.jp/?xcid=DS_TOP_from_CRP_drawer)
     
*    [![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-customer-support-icon.svg) お客さまサポート](https://www.docomo.ne.jp/support/?icid=CRP_drawer_sup01_to_CRP_SUP)
    
*    [![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-campaign-icon.svg) キャンペーン・特典](https://www.docomo.ne.jp/campaign_event/?icid=CRP_drawer_to_CRP_CAM)
    
*    [![](https://www.docomo.ne.jp/assets/content/dam/corp/jp/ja/common/images/logo/cmn-rwd-d-point-club-logo.svg) dポイントクラブ _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://dpoint.docomo.ne.jp/)
     

*   *   *   商品・サービス
        *   *   ![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/ico_mobile.png) モバイル
                
                *   [iPhone](https://www.docomo.ne.jp/iphone/?icid=CRP_drawer_to_CRP_IPH)
                    
                *   [iPad](https://www.docomo.ne.jp/ipad/?icid=CRP_drawer_to_CRP_IPA)
                    
                *   [製品](https://www.docomo.ne.jp/product/?icid=CRP_drawer_to_CRP_PRD)
                    
                *   [料金・割引](https://www.docomo.ne.jp/charge/?icid=CRP_drawer_to_CRP_CHA)
                    
                *   [サービス・機能](https://www.docomo.ne.jp/service/?icid=CRP_drawer_to_CRP_SER)
                    
                *   [通信・エリア](https://www.docomo.ne.jp/area/?icid=CRP_drawer_to_CRP_AREA)
                    
                
            *   ![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/ico_internet.png) インターネット回線・固定電話
                
                *   [インターネット回線・固定電話トップ](https://www.docomo.ne.jp/internet/?icid=CRP_drawer_to_CRP_INT)
                    
                *   [ドコモ光](https://www.docomo.ne.jp/internet/hikari/?icid=CRP_drawer_to_CRP_INT_hikari)
                    
                *   [ahamo光](https://www.docomo.ne.jp/internet/ahamo_hikari/?icid=CRP_drawer_to_CRP_internet_ahamo_hikari)
                    
                *   [home 5G](https://www.docomo.ne.jp/home_5g/?icid=CRP_drawer_to_CRP_HOM)
                    
                *   [homeでんわ](https://www.docomo.ne.jp/home_denwa/?icid=CRP_drawer_to_CRP_DENWA)
                    
                
            *   ![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/ico_smartlife.png) スマートライフ
                
                *   [スマートライフ トップ](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_drawer_to_CRP_SER_smart-life)
                    
                *   [決済・保険・投資](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_drawer_to_CRP_SER_smart-life_finance&tgl_entertainment=0&tgl_life-support=0&tgl_finance=1&tgl_shopping=0&tgl_healthcare=0#finance)
                    
                *   [エンターテインメント](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_drawer_to_CRP_SER_smart-life_entertainment&tgl_entertainment=1&tgl_life-support=0&tgl_finance=0&tgl_shopping=0&tgl_healthcare=0#entertainment)
                    
                *   [ライフサポート](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_drawer_to_CRP_SER_smart-life_life-support&tgl_entertainment=0&tgl_life-support=1&tgl_finance=0&tgl_shopping=0&tgl_healthcare=0#life-support)
                    
                *   [ショッピング](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_drawer_to_CRP_SER_smart-life_shopping&tgl_entertainment=0&tgl_life-support=0&tgl_finance=0&tgl_shopping=1&tgl_healthcare=0#shopping)
                    
                *   [ヘルスケア](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_drawer_to_CRP_SER_smart-life_healthcare&tgl_entertainment=0&tgl_life-support=0&tgl_finance=0&tgl_shopping=0&tgl_healthcare=1#healthcare)
                    
                
            *   ![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/ico_denki.png?ver=1748827032) 電気・ガス
                
                *   [ドコモでんき／  \
                    ドコモ ガス トップ](https://www.docomo.ne.jp/denki/?icid=CRP_drawer_to_CRP_DENKI)
                    
                
    *   *   お知らせ
        *   *   お知らせ
                
                *   [お知らせ トップ](https://www.docomo.ne.jp/info/?icid=CRP_drawer_to_CRP_INFO)
                    
                *   [ニュースルーム](https://www.docomo.ne.jp/info/update/?icid=CRP_drawer_to_CRP_INFO_update)
                    
                *   [報道発表](https://www.docomo.ne.jp/info/news_release/?icid=CRP_drawer_to_CRP_INFO_news_release)
                    
                *   [重要なお知らせ（通信障害）](https://www.docomo.ne.jp/info/network/?icid=CRP_drawer_to_CRP_INFO_network)
                    
                *   [携帯電話サービスの通信状況（地域別）](https://www.docomo.ne.jp/info/status/?icid=CRP_drawer_to_CRP_INFO_status)
                    
                *   [工事のお知らせ](https://www.docomo.ne.jp/info/construction/?icid=CRP_drawer_to_CRP_INFO_construction)
                    
                
    *   *   企業情報
        *   *   企業情報
                
                *   [企業情報 トップ](https://www.docomo.ne.jp/corporate/?icid=CRP_drawer_to_CRP_CORP)
                    
                *   [あなたとドコモ](https://www.docomo.ne.jp/corporate/anatatodocomo/?icid=CRP_drawer_to_CRP_CORP_anatatodocomo)
                    
                *   [企業理念・ビジョン](https://www.docomo.ne.jp/corporate/philosophy_vision/?icid=CRP_drawer_to_CRP_CORP_philosophy_vision)
                    
                *   [会社案内](https://www.docomo.ne.jp/corporate/about/?icid=CRP_drawer_to_CRP_CORP_about)
                    
                *   [サステナビリティ](https://www.docomo.ne.jp/corporate/csr/?icid=CRP_drawer_to_CRP_CORP_csr)
                    
                *   [技術とあんしん](https://www.docomo.ne.jp/corporate/technology_safety/?icid=CRP_drawer_to_CRP_CORP_technology_safety)
                    
                *   [IR情報](https://www.docomo.ne.jp/corporate/ir/library/?icid=CRP_drawer_to_CRP_CORP_ir_library)
                    
                *   [採用情報](https://www.docomo.ne.jp/corporate/recruit/?icid=CRP_drawer_to_CRP_CORP_recruit)
                    
                *   [NTTドコモグループ_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://nttdocomo-group.com/index.html)
                    
                
*   *   地域別情報
        
        *   [北海道](https://www.docomo.ne.jp/hokkaido/?icid=CRP_drawer_to_hokkaido)
            
        *   [東北](https://www.docomo.ne.jp/tohoku/?icid=CRP_drawer_to_tohoku)
            
        *   [関東・甲信越](https://www.docomo.ne.jp/kanto/?icid=CRP_drawer_to_kanto)
            
        *   [東海](https://www.docomo.ne.jp/tokai/?icid=CRP_drawer_to_tokai)
            
        *   [北陸](https://www.docomo.ne.jp/hokuriku/?icid=CRP_drawer_to_hokuriku)
            
        *   [関西](https://www.docomo.ne.jp/kansai/?icid=CRP_drawer_to_kansai)
            
        *   [中国](https://www.docomo.ne.jp/chugoku/?icid=CRP_drawer_to_chugoku)
            
        *   [四国](https://www.docomo.ne.jp/shikoku/?icid=CRP_drawer_to_shikoku)
            
        *   [九州・沖縄](https://www.docomo.ne.jp/kyushu/?icid=CRP_drawer_to_kyushu)
            
        
    *   地域別情報
        
        *   [北海道](https://www.docomo.ne.jp/hokkaido/?icid=CRP_drawer_to_hokkaido)
            |
        *   [東北](https://www.docomo.ne.jp/tohoku/?icid=CRP_drawer_to_tohoku)
            |
        *   [関東・甲信越](https://www.docomo.ne.jp/kanto/?icid=CRP_drawer_to_kanto)
            |
        *   [東海](https://www.docomo.ne.jp/tokai/?icid=CRP_drawer_to_tokai)
            |
        *   [北陸](https://www.docomo.ne.jp/hokuriku/?icid=CRP_drawer_to_hokuriku)
            |
        *   [関西](https://www.docomo.ne.jp/kansai/?icid=CRP_drawer_to_kansai)
            |
        *   [中国](https://www.docomo.ne.jp/chugoku/?icid=CRP_drawer_to_chugoku)
            |
        *   [四国](https://www.docomo.ne.jp/shikoku/?icid=CRP_drawer_to_shikoku)
            |
        *   [九州・沖縄](https://www.docomo.ne.jp/kyushu/?icid=CRP_drawer_to_kyushu)
            
        
*   *   法人のお客さま
        
        *   [NTTドコモビジネス_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.ntt.com/index.html)
            
        *   [NTTドコモソリューションズ_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.nttcom.co.jp/)
            
        *   [NTTドコモ・グローバル](https://www.docomo.ne.jp/global/?icid=CRP_drawer_to_CRP_global)
            
        
    *   法人のお客さま
        
        *   [NTTドコモビジネス_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.ntt.com/index.html)
            |
        *   [NTTドコモソリューションズ_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.nttcom.co.jp/)
            |
        *   [NTTドコモ・グローバル](https://www.docomo.ne.jp/global/?icid=CRP_drawer_to_CRP_global)
            
        

[![](https://www.docomo.ne.jp/assets/content/dam/corp/jp/ja/common/images/logo/cmn-rwd-d-point-club-logo.svg)](https://www.docomo.ne.jp/hikari/)

*   [dアカウントでもっと便利に](https://www.docomo.ne.jp/utility/daccount/?icid=CRP_drawer_to_CRP_UTI_daccount)
    
*   [別のIDでログイン](https://cfg.smt.docomo.ne.jp/auth/cgi/anidlogin?rl=https%3A%2F%2Fwww.docomo.ne.jp%2F)
    
*   [ログアウト](https://www.docomo.ne.jp/mydocomo/utility/confirm_logout/index.html)
    
*   [会員情報確認・変更_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon-white.svg)_](https://profile.smt.docomo.ne.jp/VIEW_ESITE/mem/sc/main.jsp?nid=MEG002006BJP)
    
*   [ログインでお困りの方_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon-white.svg)_](https://id.smt.docomo.ne.jp/src/utility/idpw_forget.html)
    
*   [２段階認証のお願い_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon-white.svg)_](https://id.smt.docomo.ne.jp/src/utility/sp/twostepauth.html)
    

オートログイン中

[![ランク](https://www.docomo.ne.jp/hikari/#)](https://dpoint.docomo.ne.jp/member/stage_info/index.html)

* * *

[うち期間・用途限定](https://www.docomo.ne.jp/hikari/)

* * *

[![ドコモビジネスメンバーズ](https://www.docomo.ne.jp/images_osp/common/newhf/ico/ico_businessmembers.png)](https://www.docomo.ne.jp/hikari/)

*   [別のIDでログイン](https://cfg.smt.docomo.ne.jp/auth/cgi/anidlogin?rl=https%3A%2F%2Fwww.docomo.ne.jp%2F)
    
*   [ログアウト](https://www.docomo.ne.jp/mydocomo/utility/confirm_logout/index.html)
    
*   [会員情報確認・変更_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon-white.svg)_](https://profile.smt.docomo.ne.jp/VIEW_ESITE/mem/sc/main.jsp?nid=MEG002006BJP)
    
*   [２段階認証のお願い_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon-white.svg)_](https://id.smt.docomo.ne.jp/src/utility/sp/twostepauth.html)
    

*   [CMギャラリー_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.youtube.com/playlist?list=PLB334710B4B8111A8)
    
*   [よくあるご質問](https://faq.front.smt.docomo.ne.jp/?utm_source=docomo.ne.jp&utm_medium=api_linkage&utm_campaign=api_CRP_TOP)
    
*   [見やすさ・使いやすさの調整](https://www.docomo.ne.jp/utility/term/web_accessibility/faciliti/?icid=CRP_drawer_to_CRP_UTI_term_web_accessibility_faciliti)
    
*   [パーソナルデータ（個人情報など）について](https://www.docomo.ne.jp/utility/personal_data/?icid=CRP_drawer_to_CRP_UTI_personal_data)
    

*    [![](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-daccount-logo.svg) ログインする](https://www.docomo.ne.jp/hikari/)
    
*   [![別ウィンドウで開きます。のりかえ（MNP）](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-online-mnp-icon_smt.png)](https://onlineshop.docomo.ne.jp/special-contents/mnp?xcid=OLS_special-contents_mnp_flow_from_CRP_TOP_mnp_btn)
    

*   [![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-switch-online-icon.svg)機種変更](https://www.docomo.ne.jp/support/switch_online/?icid=CRP_outerhead_to_SUP_switch_online)
    
*   [![](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-d-point-club-logo.svg)\
    \
    P\
    \
    ![](https://www.docomo.ne.jp/hikari/)](https://www.docomo.ne.jp/hikari/)
    

[![ドコモビジネスメンバーズ](https://www.docomo.ne.jp/images_osp/common/newhf/ico/ico_businessmembers.png)](https://www.docomo.ne.jp/hikari/)

お客さまの設定により、お客さま情報が「非表示」となっております。お客さま情報を表示するにはdアカウントでログインしてください。  
[お客さま情報表示について](https://www.docomo.ne.jp/hikari/)
へ

[お客さま情報表示について](https://www.docomo.ne.jp/hikari/)
へ

*   [ホーム](https://www.docomo.ne.jp/)
    
*   [インターネット回線・固定電話](https://www.docomo.ne.jp/internet/)
    
*   ドコモ光（光インターネット回線サービス）

ドコモ光（光インターネット回線サービス）
====================

![ドコモ光 10ギガ ド速い！ド安い！ドコモ光10ギガ キャンペーン中 新規申込みで基本料金が最大6か月間 月額500円 [キャンペーン適用終了後] タイプAの場合 6,380円／月](https://www.docomo.ne.jp/flcache_data/internet/hikari/mv.png?ver=1756454417) ![ドコモ光 10ギガ ド速い！ド安い！ドコモ光10ギガ キャンペーン中 新規申込みで基本料金が最大6か月間 月額500円 [キャンペーン適用終了後] タイプAの場合 6,380円／月](https://www.docomo.ne.jp/flcache_data/internet/hikari/mv_sp.png?ver=1756454417)

*   「ドコモ光」はベストエフォート型サービスです。最大通信速度は技術規格上の最大値となり、  
    お客さま宅内での実使用速度はお客さまのご利用環境・ご利用機器、回線の混雑状況などによって低下します。
    
*   「ドコモ光 10ギガ」の対象エリアは、一部に限られます。詳しくは[こちら](https://www.docomo.ne.jp/internet/hikari/10g_plan/?icid=CRP_INT_hikari_01_to_CRP_INT_hikari_10g_plan)
    

[重要なお知らせ（通信障害等）__](https://www.docomo.ne.jp/info/network/?icid=CRP_INT_hikari_to_CRP_INFO_network)

[工事・故障情報一覧__](https://www.docomo.ne.jp/internet/hikari/trouble/construction/?icid=CRP_INT_hikari_to_CRP_INT_hikari_trouble_construction)

[新規契約を  \
ご検討中のお客さま](https://www.docomo.ne.jp/hikari/#sec_Features)

[すでに  \
ご契約中のお客さま](https://www.docomo.ne.jp/hikari/#sec_Customers)

*   [![](https://www.docomo.ne.jp/flcache_data/internet/hikari/icon_features.svg)ドコモ光の特長](https://www.docomo.ne.jp/hikari/#sec_Features)
    
*   [![](https://www.docomo.ne.jp/flcache_data/internet/hikari/icon_price.svg)ドコモ光の月額料金](https://www.docomo.ne.jp/hikari/#sec_Price)
    
*   [![](https://www.docomo.ne.jp/flcache_data/internet/hikari/icon_provider.svg)ドコモ光の選べるプロバイダ](https://www.docomo.ne.jp/hikari/#sec_Provider)
    
*   [![](https://www.docomo.ne.jp/flcache_data/internet/hikari/icon_option.svg?ver=1711674014)充実のオプション・サービス](https://www.docomo.ne.jp/hikari/#sec_Option)
    
*   [![](https://www.docomo.ne.jp/flcache_data/internet/hikari/icon_campaign.svg)おトクな割引・キャンペーン](https://www.docomo.ne.jp/hikari/#sec_Campaign)
    
*   [![](https://www.docomo.ne.jp/flcache_data/internet/hikari/icon_app.svg)ドコモ光のお申込みについて](https://www.docomo.ne.jp/hikari/#sec_App)
    
*   [![](https://www.docomo.ne.jp/flcache_data/internet/hikari/icon_customers.svg)ご契約中のお客さま](https://www.docomo.ne.jp/hikari/#sec_Customers)
    

[法人のお客さまはこちら_![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://www.onlineshop.docomobusiness.ntt.com/service/internet/docomohikari?utm_source=other&utm_medium=referral&utm_campaign=dbols_docomohikari_dols_website_001_smdm)

ドコモ光の特長
-------

ドコモ光とは、フレッツ光回線またはケーブルテレビの設備を使ってドコモが提供する  
プロバイダ一体型の光インターネット回線サービスです。  
プロバイダとしてドコモはOCN インターネットを提供しています。

 ![利用用途に合わせて”選べる”](https://www.docomo.ne.jp/flcache_data/internet/hikari/txt_unlimited_use_data_pc.svg?ver=1708477224)![利用用途に合わせて”選べる”](https://www.docomo.ne.jp/flcache_data/internet/hikari/txt_unlimited_use_data_smt.svg?ver=1708477224)

基本料金最大6か月間  
＼ワンコインキャンペーン実施中！／

基本料金最大6か月間  
＼ワンコインキャンペーン実施中！／

 [![ドコモ光 10ギガ](https://www.docomo.ne.jp/flcache_data/internet/hikari/logo_hikari_10g.svg) ド速い！最大通信速度10Gbps※](https://www.docomo.ne.jp/internet/hikari/10g_plan/?icid=CRP_INT_hikari_02_to_CRP_INT_hikari_10g_plan)

 [![ドコモ光 1ギガ](https://www.docomo.ne.jp/flcache_data/internet/hikari/logo_hikari_1g.svg) あんしん・快適なインターネット](https://www.docomo.ne.jp/internet/hikari/1g_plan/?icid=CRP_INT_hikari_to_CRP_INT_hikari_1g_plan)

*   「ドコモ光」はベストエフォート型サービスです。最大通信速度は技術規格上の最大値となり、お客さま宅内での実使用速度はお客さまのご利用環境・ご利用機器、回線の混雑状況などによって低下します。
    
*   「ドコモ光 10ギガ」の提供エリアは、一部に限られます。別途10ギガ対応ルーターのご用意が必要となります。
    
*   キャンペーンの適用には条件があります。詳しくは「ドコモ光 10ギガページ」でご確認ください。
    

ドコモ光の月額料金
---------

＼キャンペーン実施中！／

![ドコモ光10ギガ](https://www.docomo.ne.jp/flcache_data/internet/hikari/ttl_hikari_10g.svg)

 [![マンション/戸建共通 6,380円（税込）/月～ ※2年定期契約の場合](https://www.docomo.ne.jp/flcache_data/internet/hikari/bnr_hikari_common_pc.png?ver=1703131238) ![マンション/戸建共通 6,380円（税込）/月～ ※2年定期契約の場合](https://www.docomo.ne.jp/flcache_data/internet/hikari/bnr_hikari_common_smt.png?ver=1703131238)](https://www.docomo.ne.jp/internet/hikari/charge/?icid=CRP_INT_hikari_to_CRP_INT_hikari_charge#anc-10giga)

![ドコモ光1ギガ](https://www.docomo.ne.jp/flcache_data/internet/hikari/ttl_hikari_1g.svg)

 [![マンションにお住まいの方 4,400円（税込）/月～ ※2年定期契約の場合](https://www.docomo.ne.jp/flcache_data/internet/hikari/bnr_hikari_apartment_pc.png?ver=1703131238) ![マンションにお住まいの方 4,400円（税込）/月～ ※2年定期契約の場合](https://www.docomo.ne.jp/flcache_data/internet/hikari/bnr_hikari_apartment_smt.png?ver=1703131238)](https://www.docomo.ne.jp/internet/hikari/charge/?icid=CRP_INT_hikari_01_to_CRP_INT_hikari_charge#anc-1giga)

 [![戸建にお住まいの方 5,720円（税込）/月～ ※2年定期契約の場合](https://www.docomo.ne.jp/flcache_data/internet/hikari/bnr_hikari_house_pc.png?ver=1703131238) ![戸建にお住まいの方 5,720円（税込）/月～ ※2年定期契約の場合](https://www.docomo.ne.jp/flcache_data/internet/hikari/bnr_hikari_house_smt.png?ver=1703131238)](https://www.docomo.ne.jp/internet/hikari/charge/?icid=CRP_INT_hikari_02_to_CRP_INT_hikari_charge#anc-1giga)

*   定期契約プランは、2年間同一の「ドコモ光」契約を継続して利用することが条件となり、解約（定期契約のない料金プランへの変更含む）のお申出がない場合は自動更新となります。当該期間内での「ドコモ光 1ギガ」の解約、定期契約のない料金プランへの変更などの場合、更新期間を除いて戸建タイプ5,500円（税込）、マンションタイプ4,180円（税込）の解約金がかかります（2022年6月30日以前にお申込みのお客さまの場合、戸建タイプ14,300円（税込）、マンションタイプ8,800円（税込）の解約金となります）。当該期間内での「ドコモ光 10ギガ」の解約、定期契約のない料金プランへの変更などの場合、更新期間を除いて5,500円（税込）の解約金がかかります。ただし、契約満了月の当月・翌月・翌々月はかかりません。「ドコモ光」の契約期間とペア回線（「ドコモ光」と対になる携帯電話回線）の契約期間は別々に取り扱われます。それぞれの契約期間が異なる場合、ペア回線の契約期間満了時に「ドコモ光」を解約した場合には、「ドコモ光」の解約金が発生します。  
    解約金は、お手続き当月のご利用分に対する請求時にあわせて請求させていただきます。なお、各月1日でのお手続きにより解約金が生じた場合のみ、お手続き前月のご利用分とあわせて解約金を請求させていただきます。  
    単独タイプは別途プロバイダ料金・お申込みが必要です。ご利用予定のプロバイダのドコモ光対応可否については、工事予定日までにお客さまご自身でプロバイダ事業者へご確認ください。
    

[#### 初期費用について](https://www.docomo.ne.jp/internet/hikari/charge/?icid=CRP_INT_hikari_ito_CRP_INT_hikari_charge#p06)

[#### 工事料分割払い](https://www.docomo.ne.jp/internet/hikari/construction_costs/?icid=CRP_INT_hikari_to_CRP_INT_hikari_construction_costs)

*   [### 料金シミュレーション\
    \
    開く![](https://www.docomo.ne.jp/images_osp/common/btn/btn_toggle_open01_v2.png)](https://www.docomo.ne.jp/hikari/#)
    
    #### 転用・新規契約・各種変更時にかかる  
    工事費がわかる！
    
    [工事料金シミュレーション_![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03-strong_v2.png)_](https://docomohikari-koujiryo.ac.at.nttdocomo.co.jp/index.php/site)
    
    #### ドコモ光と携帯電話を合わせた  
    毎月のお支払い額がわかる！
    
    *   [料金シミュレーション__](https://www.docomo.ne.jp/charge/simulation/?icid=CRP_INT_hikari_to_CRP_CHA_simulation)
        
    
    *   ※「おてがる料金シミュレーション」は、  
        「ドコモ光 1ギガ」料金プランでの試算となります。
        
    

### ドコモ光の選べるプロバイダ

ドコモの提供プロバイダ「OCN インターネット」をはじめ、さまざまなプロバイダから選べますが、  
プロバイダにより料金プランが異なります。  
なお、ドコモはプロバイダとしてOCN インターネットを提供しています。

[**ドコモ公式プロバイダの提供**\
\
ドコモ提供のプロバイダ  \
（1ギガ・10ギガ）\
\
**![OCN Internet](https://www.docomo.ne.jp/flcache_data/internet/hikari/logo_ocn.png?ver=1703131239)**](https://www.docomo.ne.jp/internet/hikari/provider_list/ocn/?icid=CRP_INT_hikari_to_CRP_INT_hikari_provider_list_ocn)

[ドコモ光のプロバイダ（1ギガ・10ギガ）\
\
**プロバイダ一覧を見る**](https://www.docomo.ne.jp/internet/hikari/provider_list/?icid=CRP_INT_hikari_to_CRP_INT_hikari_provider_list)

充実のオプション・サービス
-------------

ご利用スタイルに合わせて、「ドコモ光電話」や映像サービスなどをご契約になれます。

[![ドコモ光電話](https://www.docomo.ne.jp/flcache_data/internet/hikari/img-option-hikaridenwa_pc.png?ver=1711674014)![ドコモ光電話](https://www.docomo.ne.jp/flcache_data/internet/hikari/img-option-hikaridenwa_smt.png?ver=1711674014)\
\
### ドコモ光電話](https://www.docomo.ne.jp/internet/hikari/tell_service/?icid=CRP_INT_hikari_btn_to_CRP_INT_hikari_tell_service)

[![ドコモ光テレビオプション](https://www.docomo.ne.jp/flcache_data/internet/hikari/img-option-tvoption_pc.png?ver=1711674014)![ドコモ光テレビオプション](https://www.docomo.ne.jp/flcache_data/internet/hikari/img-option-tvoption_smt.png?ver=1711674015)\
\
### ドコモ光テレビオプション](https://www.docomo.ne.jp/internet/hikari/eizo_service/tv_option/?icid=CRP_INT_hikari_btn_to_CRP_INT_hikari_eizo_service_tv_option)

[![スカパー！](https://www.docomo.ne.jp/flcache_data/internet/hikari/img-option-sk_pc.png?ver=1711674014)![スカパー！](https://www.docomo.ne.jp/flcache_data/internet/hikari/img-option-sk_smt.png?ver=1711674014)\
\
### スカパー！](https://www.docomo.ne.jp/internet/hikari/eizo_service/skyperfectv/?icid=CRP_INT_hikari_btn_to_CRP_INT_hikari_eizo_service_skyperfectv)

[![homeひかりTV](https://www.docomo.ne.jp/flcache_data/internet/hikari/img-option-hikaritv_pc.png?ver=1711674014)![homeひかりTV](https://www.docomo.ne.jp/flcache_data/internet/hikari/img-option-hikaritv_smt.png?ver=1711674014)\
\
### ひかりＴＶ](https://www.docomo.ne.jp/internet/hikari/eizo_service/hikaritv/?icid=CRP_INT_hikari_btn_to_CRP_INT_hikari_eizo_service_hikaritv)

[![あんしんパックホーム](https://www.docomo.ne.jp/flcache_data/internet/hikari/img-option-anshin_pc.png?ver=1711674014)![あんしんパックホーム](https://www.docomo.ne.jp/flcache_data/internet/hikari/img-option-anshin_smt.png?ver=1711674014)\
\
### あんしんパックホーム](https://www.docomo.ne.jp/service/anshinpack_home/?icid=CRP_INT_hikari_btn_to_CRP_SER_anshinpack_home)

[![homeあんしんパック](https://www.docomo.ne.jp/flcache_data/internet/hikari/img-option-home_pc.png?ver=1711674014)![homeあんしんパック](https://www.docomo.ne.jp/flcache_data/internet/hikari/img-option-home_smt.png?ver=1711674014)\
\
### homeあんしんパック  \
（smartあんしん補償をご契約のお客さま）](https://www.docomo.ne.jp/service/home_anshinpack/?icid=CRP_INT_hikari_btn_to_CRP_SER_home_anshinpack)

おトクな割引・キャンペーン
-------------

### 割引・特典

 [![ドコモ光 セット割 スマホとセットでスマホ料金から 永年最大1,210円（税込）／月 割引！！](https://www.docomo.ne.jp/flcache_data/internet/hikari/img_hikari_01_pc.png?ver=1749049275) ![ドコモ光 セット割 スマホとセットでスマホ料金から 永年最大1,210円（税込）／月 割引！！](https://www.docomo.ne.jp/flcache_data/internet/hikari/img_hikari_01_smt.png?ver=1749049275)](https://www.docomo.ne.jp/charge/hikari_set/?icid=CRP_INT_hikari_txt02_to_CRP_CHA_hikari_set)

*   プラン・利用データ量により割引額は変動します。
    
*   「ドコモ光」契約者と同一「ファミリー割引」グループ内の「ドコモ MAX」「ドコモ ポイ活 MAX」「ドコモ ポイ活 20」「ドコモ mini」が対象です。
    
*   「eximo」「eximo ポイ活」「irumo（0.5GBを除く）」「5Gギガホ プレミア」「5Gギガホ」「5Gギガライト」「ギガホ プレミア」「ギガホ」「ギガライト」は最大1,100円／月（税込）割引となります。
    

キャンペーン・特典
---------

[### ドコモ光 10ギガ基本料金最大6か月間ワンコインキャンペーン\
\
![ドコモ光 10ギガ基本料金最大6か月間ワンコインキャンペーン](https://www.docomo.ne.jp/campaign_event/common/images/20240829_docomohikari_1coin.jpg?ver=1724857212)\
\
「ドコモ光 10ギガ」（2年定期契約）の新規お申込みで、月額基本料金を6か月目まで500円／月（税込）！](https://www.docomo.ne.jp/campaign_event/docomo_hikari_onecoin/?icid=CRP_INT_hikari_img_to_CRP_CAM_docomo_hikari_onecoin)

[### 「ドコモ光」乗り換え特典\
\
![ドコモ光 乗り換え特典](https://www.docomo.ne.jp/campaign_event/common/images/20240401_hikari_norikae.jpg?ver=1711933239)\
\
他社インターネットから「ドコモ光」へお乗り換えで他社解約金のうちdポイント（期間・用途限定）最大25,000ptプレゼント！](https://www.docomo.ne.jp/campaign_event/hikari_norikae/?icid=CRP_INT_hikari_img_to_CRP_CAM_hikari_norikae)

[### ドコモ光 新規工事料実質0円特典！\
\
![ドコモ光 新規工事料実質0円特典！](https://www.docomo.ne.jp/campaign_event/common/images/20250331_hikari_construction.png?ver=1743408025)\
\
新規お申込みで新規工事料相当のdポイント（期間・用途限定）をプレゼント！\
\
*   回線工事種類に応じたdポイントをプレゼントいたします。](https://www.docomo.ne.jp/campaign_event/hikari_shinkikojiryo_free/?icid=CRP_INT_hikari_01_to_CRP_CAM_hikari_shinkikojiryo_free)

[キャンペーン・特典一覧へ__](https://www.docomo.ne.jp/campaign_event/?icid=CRP_INT_hikari_to_CRP_CAM)

キャンペーン・特典
---------

[### ドコモ光 10ギガ基本料金最大6か月間ワンコインキャンペーン\
\
![ドコモ光 10ギガ基本料金最大6か月間ワンコインキャンペーン](https://www.docomo.ne.jp/campaign_event/common/images/20240829_docomohikari_1coin.jpg?ver=1724857212)\
\
「ドコモ光 10ギガ」（2年定期契約）の新規お申込みで、月額基本料金を6か月目まで500円／月（税込）！](https://www.docomo.ne.jp/campaign_event/docomo_hikari_onecoin/?icid=CRP_INT_hikari_txt_to_CRP_CAM_docomo_hikari_onecoin)

[### 「ドコモ光」乗り換え特典\
\
![ドコモ光 乗り換え特典](https://www.docomo.ne.jp/campaign_event/common/images/20240401_hikari_norikae.jpg?ver=1711933239)\
\
他社インターネットから「ドコモ光」へお乗り換えで他社解約金のうちdポイント（期間・用途限定）最大25,000ptプレゼント！](https://www.docomo.ne.jp/campaign_event/hikari_norikae/?icid=CRP_SMT_INT_hikari_txt_to_CRP_SMT_CAM_hikari_norikae)

[### ドコモ光 新規工事料実質0円特典！\
\
![ドコモ光 新規工事料実質0円特典！](https://www.docomo.ne.jp/campaign_event/common/images/20250331_hikari_construction.png?ver=1743408025)\
\
新規お申込みで新規工事料相当のdポイント（期間・用途限定）をプレゼント！\
\
*   回線工事種類に応じたdポイントをプレゼントいたします。](https://www.docomo.ne.jp/campaign_event/hikari_shinkikojiryo_free/?icid=CRP_INT_hikari_01_to_CRP_CAM_hikari_shinkikojiryo_free)

[キャンペーン・特典一覧へ__](https://www.docomo.ne.jp/campaign_event/?icid=CRP_INT_hikari_to_CRP_CAM)

ドコモ光のお申込み
---------

ドコモ光のお申込みはドコモ光お申込み／ご相談フォームで入力受付後、担当オペレーターからお電話いたします。  
その際に料金プラン、通信速度などお申込み内容について確認させていただきます。  
お申込みは24時間受付ております。

ドコモ光Webお申込みの流れとご確認事項
--------------------

ドコモ光お申込み／ご相談フォームで受付後、担当オペレーターからお電話いたします。

![](https://www.docomo.ne.jp/flcache_data/internet/hikari/img_application_step01.png?ver=1703131239)

24時間受付可能だから便利！

*   **ペア回線（「ドコモ光」と対となる携帯電話）の番号が必要です。**
    
*   **未成年の方は、本フォームからお申込みいただけません。**
    
*   **一部の法人名義のお客さまは、本フォームからお申込みいただけない場合があります。**
    

![](https://www.docomo.ne.jp/flcache_data/internet/hikari/img_application_step02.png?ver=1703131239)

担当オペレーターからお客さまご希望の曜日・時間にお電話

*   ご指定可能な時間帯は、午前11時～午後8時となります。
    

![](https://www.docomo.ne.jp/flcache_data/internet/hikari/img_application_step03.png?ver=1703131239)

そのままお電話で、ドコモ光のお申込みができます！

*   お申込みにあたり、事前に[お申込み前のご確認書面__](https://www.docomo.ne.jp/hikari/#anc-01)
    をご確認ください。
    

[すべて開く![](https://www.docomo.ne.jp/images_osp/common/btn/btn_toggle_open01_v2.png)\
\
すべて開く![](https://www.docomo.ne.jp/images_osp/common/btn/btn_toggle_open01_v2.png)](https://www.docomo.ne.jp/hikari/#)

*   [#### お申込み前のご確認書面\
    \
    開く![](https://www.docomo.ne.jp/images_osp/common/btn/btn_toggle_open01_v2.png)](https://www.docomo.ne.jp/hikari/#)
    
    お申込み前に、下記をご確認ください。
    
    *   [電話によるご契約時の確認事項（PDF形式：5,017KB）_PDF_](https://www.docomo.ne.jp/binary/pdf/internet/hikari/consultation/docomohikari_explanation_procedures.pdf?ver=1764550834)
        
    *   [ドコモからのご案内～ご契約前の重要説明事項～（ドコモ光版）（PDF形式：1,426KB）_PDF_](https://www.docomo.ne.jp/binary/pdf/internet/hikari/notice/important_explanation_hikari.pdf?ver=1764550834)
        
    *   [プロバイダご利用にあたっての注意事項（プロバイダ提供条件書）__](https://www.docomo.ne.jp/internet/hikari/notice/?icid=CRP_INT_hikari_01_to_CRP_INT_hikari_notice#anc-02)
        
    *   [「ドコモ光 10ギガ」お申込みからご利用開始までの流れ（PDF形式：681KB）_PDF_](https://www.docomo.ne.jp/binary/pdf/internet/hikari/consultation/docomohikari_10g_flow.pdf?ver=1703131226)
        
    
*   [#### ドコモ光 エリア検索\
    \
    開く![](https://www.docomo.ne.jp/images_osp/common/btn/btn_toggle_open01_v2.png)](https://www.docomo.ne.jp/hikari/#)
    
    ![NTT東日本／NTT西日本のサービス提供地域](https://www.docomo.ne.jp/flcache_data/internet/hikari/img_map_pco.png?ver=1740465431)  
    
    ![NTT東日本／NTT西日本のサービス提供地域](https://www.docomo.ne.jp/flcache_data/internet/hikari/img_map_pco.png?ver=1740465431)
    
    ご自宅が「ドコモ光」のサービスエリア内かご確認ください。サービスエリア内なら、「ドコモ光」をお申込みになれます。詳しくはNTT東日本／NTT西日本のウェブサイトでご確認ください。
    
    *   [NTT東日本エリア検索_別ウインドウが開きます_](https://flets.com/app2/search_c.html)
        
    *   [NTT西日本エリア検索_別ウインドウが開きます_](https://flets-w.com/area/)
        
    
    1.  静岡県熱海市・裾野市の一部エリア、富山県中新川郡立山町の一部エリアはNTT東日本の提供エリアとなります。
        
    2.  長野県木曽郡南木曽町田立の一部エリアはNTT西日本の提供エリアとなります。
        
    
    *   「ドコモ光 10ギガ」の場合、提供エリアが異なります。詳しくは「[ドコモ光 10ギガ](https://www.docomo.ne.jp/internet/hikari/10g_plan/?icid=CRP_INT_hikari_03_to_CRP_INT_hikari_10g_plan#anc-02)
        」の提供エリアページから提供エリアをご確認ください。
        
    *   提携ケーブルテレビのエリアは「[ドコモ光 1ギガ タイプC](https://www.docomo.ne.jp/internet/hikari/charge/type_c/?icid=CRP_INT_hikari_txt01_to_CRP_INT_hikari_charge_type_c)
        」「[ドコモ光 10ギガ タイプC](https://www.docomo.ne.jp/internet/hikari/charge/10g_type_c/?icid=CRP_INT_hikari_txt01_to_CRP_INT_hikari_charge_10g_type_c)
        」にてご確認ください。
        
    

### 各種お申込み方法のご案内

[新規契約](https://www.docomo.ne.jp/internet/hikari/subscribe/?icid=CRP_INT_hikari_to_CRP_INT_hikari_subscribe)

[他社光サービスからの  \
契約変更（事業者変更）](https://www.docomo.ne.jp/internet/hikari/collabo_change/?icid=CRP_INT_hikari_to_CRP_INT_hikari_collabo_change)

[「フレッツ光」からの  \
契約変更（転用）](https://www.docomo.ne.jp/internet/hikari/tenyou/?icid=CRP_INT_hikari_to_CRP_INT_hikari_tenyou)

[他社光サービスからの  \
契約変更（光回線再利用）](https://www.docomo.ne.jp/internet/hikari/hikari_reuse?icid=CRP_INT_hikari_to_CRP_INT_hikari_hikari_reuse)

### [提供条件書__](https://www.docomo.ne.jp/support/utilization_notice/document/?icid=CRP_INT_hikari_to_CRP_SUP_utilization_notice_document)

料金プラン、割引の詳細については提供条件書をご確認ください。

### [ご注意事項__](https://www.docomo.ne.jp/internet/hikari/notice/?icid=CRP_INT_hikari_02_to_CRP_INT_hikari_notice)

お申込みにあたっての各種ご注意事項をご案内します。

### ドコモのインターネットサービスのご紹介

 [![home 5G 工事不要で今日からドコモのインターネットが使える](https://www.docomo.ne.jp/flcache_data/internet/hikari/bnr_home5g_pc.png?ver=1703131238) ![home 5G 工事不要で今日からドコモのインターネットが使える](https://www.docomo.ne.jp/flcache_data/internet/hikari/bnr_home5g_smt.png?ver=1703131238)](https://www.docomo.ne.jp/home_5g/?icid=CRP_INT_hikari_to_CRP_HOM)

 [![ahamo光 ahamoユーザー専用プラン](https://www.docomo.ne.jp/flcache_data/internet/hikari/bnr_ahamohikari_pc.png?ver=1703131238) ![ahamo光 ahamoユーザー専用プラン](https://www.docomo.ne.jp/flcache_data/internet/hikari/bnr_ahamohikari_smt.png?ver=1703131238)](https://www.docomo.ne.jp/internet/ahamo_hikari/?icid=CRP_INT_hikari_01_to_CRP_INT_ahamo_hikari)

すでにご契約中のお客さま
------------

### お手続き

[### 「ドコモ光 10ギガ」への料金プラン変更](https://www.docomo.ne.jp/internet/hikari/10g_plan_change/?icid=CRP_INT_hikari_to_CRP_INT_hikari_10g_plan_change)

[### 「ahamo光」 への料金プラン変更](https://www.docomo.ne.jp/internet/ahamo_hikari/?icid=CRP_INT_hikari_02_to_CRP_INT_ahamo_hikari)

[### お引越し（移転）のお手続き](https://www.docomo.ne.jp/internet/hikari/procedure/moving/?icid=CRP_INT_hikari_01_to_CRP_INT_hikari_procedure_moving)

### サポート

[### サービス内容全般  \
（料金・割引・キャンペーンなど）](https://www.docomo.ne.jp/support/hikari.html?sim_num=step_01&icid=CRP_INT_hikari_to_CRP_SUP_hikari_step_01)

[### 契約内容確認・変更](https://www.docomo.ne.jp/support/hikari.html?sim_num=step_02&icid=CRP_INT_hikari_to_CRP_SUP_hikari_step_02)

[### 解約・他社への乗り換え](https://www.docomo.ne.jp/support/hikari.html?sim_num=step_04&icid=CRP_INT_hikari_to_CRP_SUP_hikari_step_04)

[### 接続機器の設定や故障](https://www.docomo.ne.jp/support/hikari.html?sim_num=step_06&icid=CRP_INT_hikari_to_CRP_SUP_hikari_step_06)

[### その他サポート情報](https://www.docomo.ne.jp/internet/hikari/trouble/?icid=CRP_INT_hikari_to_CRP_INT_hikari_trouble)

*   [電話でお問い合わせ  \
    （ドコモ光をご利用中の方）__](https://www.docomo.ne.jp/support/inquiry/hikari/?icid=CRP_INT_hikari_btm_to_CRP_SUP_inquiry_hikari#p123)
    

 [![ドコモ光のお引越しはWebがおすすめ dポイント特典実施中！](https://www.docomo.ne.jp/flcache_data/internet/hikari/bnr_change_address_02_pc.gif?ver=1703131238) ![ドコモ光のお引越しはWebがおすすめ dポイント特典実施中！](https://www.docomo.ne.jp/flcache_data/internet/hikari/bnr_change_address_02_smt.gif?ver=1703131238)](https://www.docomo.ne.jp/internet/hikari/procedure/moving/?icid=CRP_INT_hikari_02_to_CRP_INT_hikari_procedure_moving)

  [![ドコモ光 ドコモ光に関するお困りごとはありませんか？「トラブルのご相談」や、「Web修理受付」を24時間チャットでご案内できる【おたすけロボット】はこちらをクリック！](https://www.docomo.ne.jp/flcache_data/internet/hikari/bnr_otasuke_robot_pc.png?ver=1703131238) ![ドコモ光 ドコモ光に関するお困りごとはありませんか？「トラブルのご相談」や、「Web修理受付」を24時間チャットでご案内できる【おたすけロボット】はこちらをクリック！](https://www.docomo.ne.jp/flcache_data/internet/hikari/bnr_otasuke_robot_smt.png?ver=1703131238) _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://ct-otasuke-robot.macaron.docomo.ne.jp/hikari/)

新着情報
----

**「ドコモ光 1ギガ」定期契約プラン（旧プラン）の提供終了について**  
2022年6月30日（木曜）に新規受付を終了した※[1](https://www.docomo.ne.jp/hikari/#notice01)
「ドコモ光 1ギガ」定期契約プラン（以下、旧プラン）の提供は、2025年6月30日（月曜）に終了いたしました。  
また、旧プランの提供終了に伴い、「ドコモ光更新ありがとうポイント」※[2](https://www.docomo.ne.jp/hikari/#notice02)
の進呈を終了いたします※[3](https://www.docomo.ne.jp/hikari/#notice03)
。  
旧プランをご契約中のお客さまは、2025年7月1日（火曜）以降も定期契約満了を迎えるまで旧プランでサービスをご利用いただけ、2025年7月以降の契約更新時に、解約金を変更した「ドコモ光 1ギガ」の定期契約プラン※[1](https://www.docomo.ne.jp/hikari/#notice01)
（以下、新プラン）へ自動移行となります。  
新プランについて、詳しくは[報道発表の別紙](https://www.docomo.ne.jp/info/news_release/2024/07/04_01.html?icid=CRP_INT_hikari_to_CRP_INFO_news_release_2024_07_04_01)
をご確認ください。  
なお、旧プランをご契約のお客さまが、更新月以外にほかプランへ変更する場合は、旧プランの解約金が発生します※[4](https://www.docomo.ne.jp/hikari/#notice04)
。

■今後のスケジュール

1.  旧プラン提供終了
    
2.  定期契約満了時に新プランへ自動移行  
    「ドコモ光更新ありがとうポイント」進呈対象外※[3](https://www.docomo.ne.jp/hikari/#notice03)
    

*   2025年6月30日（月曜）：  
    旧プラン提供終了
    
*   2025年7月1日（火曜）以降：  
    定期契約満了時に新プランへ自動移行  
    「ドコモ光更新ありがとうポイント」進呈対象外※[3](https://www.docomo.ne.jp/hikari/#notice03)
    

1.  2022年6月9日報道発表[「『ドコモ光』定期契約プランにおける解約金の変更について」](https://www.docomo.ne.jp/info/news_release/2022/06/09_00.html?icid=CRP_INT_hikari_to_CRP_INFO_news_release_2022_06_09_00)
    
2.  法人のお客さまは従前より「ドコモ光更新ありがとうポイント」進呈の対象外となります。
    
3.  2025年7月に自動移行（6月契約満了）のお客さまから進呈の対象外となります。
    
4.  お引越しによる住居タイプ変更やプロバイダタイプ変更による場合などを除きます。
    

*   2025年11月21日
    
    [2026年1月13日（火曜）より「ドコモ光 タイプC」の提携CATVに「株式会社ZTV」が追加になります。（PDF形式：353KB）_PDF_※申込受付は1月13日（火曜）より開始予定](https://www.docomo.ne.jp/binary/pdf/internet/hikari/topics_251121.pdf?ver=1763690412)
    
*   2025年5月9日
    
    [2025年5月26日（月曜）より「ドコモ光 タイプC」の提携CATVに「株式会社御前崎ケーブルテレビ」が追加になりました。（1ギガ・10ギガ同時提携）（PDF形式：324KB）_PDF_](https://www.docomo.ne.jp/binary/pdf/internet/hikari/topics_250509_01.pdf?ver=1746756012)
    

[ドコモ光 1ギガ・10ギガ  \
Webお申込み _![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03-strong_v2.png)_](https://fmd.docomo-de.net/539/toPINQ01_input.jsp?formid=002&cid=001&utm_source=corp&utm_medium=owned&utm_campaign=dcmhikari_202312_bb-crp-from-hikari-3) 

[![ドコモユーザーならお支払い方法をdカード GOLDに設定すると対象のドコモの通信料金1,000円（税抜）ごとに税抜金額の10%dポイント還元 ※年会費11,000円（税込）、入会審査有 ※ahamo／irumoご利用料金・端末代金等、一部対象外あり d CARD GOLD 適用条件など詳しくはこちら](https://www.docomo.ne.jp/flcache_data/internet/hikari/bnr/bnr_dcard_gold.jpg?ver=1722477615)](https://www.docomo.ne.jp/service/dcard/?icid=CRP_INT_hikari_to_CRP_SER_dcard)

[![法人のお客さまドコモ光](https://www.docomo.ne.jp/flcache_data/internet/hikari/bnr/bnr_business_hikari_01.png?ver=1703131241)](https://www.docomo.ne.jp/biz/charge/hikari/?icid=CRP_INT_hikari_to_CRP_BIZ_charge_hikari)

 [![ドコモ光 光回線に関する豆知識はこちら！](https://www.docomo.ne.jp/flcache_data/internet/hikari/bnr/bnr_hikari_mamechishiki.jpg?ver=1703131241) _別ウインドウが開きます_](https://nttdocomo-ssw.com/nssw/dhkr/ouchinetpress/)

*   [![別ウインドウで開きます Get Adobe Acrobat Reader](https://www.docomo.ne.jp/images_osp/common/bnr/bnr_adobe_reader01.png)](https://get.adobe.com/jp/reader/)
    
    PDF形式のファイルをご覧いただくには、アドビシステムズ社から無償提供されている  
    [![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window01.png)Adobe® Reader®](https://get.adobe.com/jp/reader/)
    プラグインが必要です。「Adobe® Acrobat®」でご覧になる場合は、バージョン10以降をご利用ください。
    

[![このページのトップへ](https://www.docomo.ne.jp/images_osp/common/btn/btn_pagetop_01.png)](https://www.docomo.ne.jp/hikari/#)

  

[![お困りですか？](https://www.docomo.ne.jp/images_osp/common/chat_tool/bnr_chat_tool.svg)](https://tetsuduki-support.docomo.ne.jp/?utm_source=corp&utm_medium=free-display&utm_campaign=onsapo_)

*   [お知らせ](https://www.docomo.ne.jp/info/?icid=CRP_common_footer_to_CRP_INFO)
    
*   [企業情報](https://www.docomo.ne.jp/corporate/?icid=CRP_common_footer_to_CRP_CORP)
    

* * *

*   [パーソナルデータ（個人情報など）について](https://www.docomo.ne.jp/utility/personal_data/?icid=CRP_common_footer_to_CRP_UTI_personal_data)
    
*   [プライバシーポリシー](https://www.docomo.ne.jp/utility/privacy/?icid=CRP_common_footer_to_CRP_UTI_privacy)
    
*   [サイトご利用にあたって](https://www.docomo.ne.jp/utility/term/?icid=CRP_common_footer_to_CRP_UTI_term)
    
*   [お客さまご利用端末からの情報の外部送信について](https://www.docomo.ne.jp/utility/term/?icid=CRP_common_footer_02_to_CRP_UTI_term#p09)
    
*   [見やすさ・使いやすさの調整](https://www.docomo.ne.jp/utility/term/web_accessibility/faciliti/?icid=CRP_common_footer_to_CRP_UTI_term_web_accessibility_faciliti)
    
*   [サイトメンテナンス情報_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon-white.svg)_](https://www.docomo.ne.jp/mydocomo/maint/?icid=CRP_common_footer_to_CRP_MYD_maint)
    
*   [サイトマップ](https://www.docomo.ne.jp/sitemap/?icid=CRP_common_footer_to_CRP_sitemap)
    
*   [ご意見・ご要望](https://www.docomo.ne.jp/support/inquiry/feedback/?icid=CRP_common_footer_to_CRP_SUP_inquiry_feedback)
    
*   [お問い合わせ](https://www.docomo.ne.jp/support/inquiry/?icid=CRP_common_footer_to_CRP_SUP_inquiry)
    
*   [NTTドコモグループ_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon-white.svg)_](https://nttdocomo-group.com/index.html)
    

© NTT DOCOMO

![閉じる](https://www.docomo.ne.jp/images_osp/common/smtnav/btn_smtmenu_01_close_crp.png)

M
