# 料金プラン | ドコモ光 | インターネット回線・固定電話 | NTTドコモ

URL: https://www.docomo.ne.jp/hikari/charge/

---

[![NTT docomo](https://www.docomo.ne.jp/images_osp/common/newhf/header/cmn-rwd-header-logo.svg?ver=1751324418)](https://www.docomo.ne.jp/?icid=CRP_common_header_to_CRP_TOP)

*   [![別ウィンドウで開きます。my docomo](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-my-docomo-logo.svg)](https://www.docomo.ne.jp/mydocomo/?icid=CRP_outerhead_to_MYD_TOP)
    
*   [![別ウィンドウで開きます。Online Shop](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-online-shop-icon2.svg)](https://onlineshop.docomo.ne.jp/top-ols/?xcid=OLS_TOP_from_CRP_outerhead)
    

*   商品・サービス
    
    *   *   モバイル
        *   *   [iPhone](https://www.docomo.ne.jp/iphone/?icid=CRP_menu_to_CRP_IPH)
                
            *   [iPad](https://www.docomo.ne.jp/ipad/?icid=CRP_menu_to_CRP_IPA)
                
            *   [製品](https://www.docomo.ne.jp/product/?icid=CRP_menu_to_CRP_PRD)
                
            *   [料金・割引](https://www.docomo.ne.jp/charge/?icid=CRP_menu_to_CRP_CHA)
                
            *   [サービス・機能](https://www.docomo.ne.jp/service/?icid=CRP_menu_to_CRP_SER)
                
            *   [通信・エリア](https://www.docomo.ne.jp/area/?icid=CRP_menu_to_CRP_AREA)
                
    *   *   インターネット回線・固定電話
        *   *   [インターネット回線・固定電話トップ](https://www.docomo.ne.jp/internet/?icid=CRP_menu_to_CRP_INT)
                
            *   [ドコモ光](https://www.docomo.ne.jp/internet/hikari/?icid=CRP_menu_to_CRP_INT_hikari)
                
            *   [ahamo光](https://www.docomo.ne.jp/internet/ahamo_hikari/?icid=CRP_menu_to_CRP_internet_ahamo_hikari)
                
            *   [home 5G](https://www.docomo.ne.jp/home_5g/?icid=CRP_menu_to_CRP_HOM)
                
            *   [homeでんわ](https://www.docomo.ne.jp/home_denwa/?icid=CRP_menu_to_CRP_DENWA)
                
    *   *   スマートライフ
        *   *   [スマートライフ トップ](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_menu_to_CRP_SER_smart-life)
                
            *   [決済・保険・投資](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_menu_to_CRP_SER_smart-life_finance&tgl_entertainment=0&tgl_life-support=0&tgl_finance=1&tgl_shopping=0&tgl_healthcare=0#finance)
                
            *   [エンターテインメント](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_menu_to_CRP_SER_smart-life_entertainment&tgl_entertainment=1&tgl_life-support=0&tgl_finance=0&tgl_shopping=0&tgl_healthcare=0#entertainment)
                
            *   [ライフサポート](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_menu_to_CRP_SER_smart-life_life-support&tgl_entertainment=0&tgl_life-support=1&tgl_finance=0&tgl_shopping=0&tgl_healthcare=0#life-support)
                
            *   [ショッピング](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_menu_to_CRP_SER_smart-life_shopping&tgl_entertainment=0&tgl_life-support=0&tgl_finance=0&tgl_shopping=1&tgl_healthcare=0#shopping)
                
            *   [ヘルスケア](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_menu_to_CRP_SER_smart-life_healthcare&tgl_entertainment=0&tgl_life-support=0&tgl_finance=0&tgl_shopping=0&tgl_healthcare=1#healthcare)
                
    *   *   電気・ガス
        *   *   [ドコモでんき／  \
                ドコモ ガス トップ](https://www.docomo.ne.jp/denki/?icid=CRP_menu_to_CRP_DENKI)
                
    
*   お知らせ
    
    *   [お知らせトップ](https://www.docomo.ne.jp/info/?icid=CRP_menu_to_CRP_INFO)
        
    *   [ニュースルーム](https://www.docomo.ne.jp/info/update/?icid=CRP_menu_to_CRP_INFO_update)
        
    *   [報道発表](https://www.docomo.ne.jp/info/news_release/?icid=CRP_menu_to_CRP_INFO_news_release)
        
    *   [重要なお知らせ（通信障害）](https://www.docomo.ne.jp/info/network/?icid=CRP_menu_to_CRP_INFO_network)
        
    *   [携帯電話サービスの通信状況（地域別）](https://www.docomo.ne.jp/info/status/?icid=CRP_menu_to_CRP_INFO_status)
        
    *   [工事のお知らせ](https://www.docomo.ne.jp/info/construction/?icid=CRP_menu_to_CRP_INFO_construction)
        
    
*   企業情報
    
    *   [企業情報トップ](https://www.docomo.ne.jp/corporate/?icid=CRP_menu_to_CRP_CORP)
        
    *   [あなたとドコモ](https://www.docomo.ne.jp/corporate/anatatodocomo/?icid=CRP_menu_to_CRP_CORP_anatatodocomo)
        
    *   [企業理念・ビジョン](https://www.docomo.ne.jp/corporate/philosophy_vision/?icid=CRP_menu_to_CRP_CORP_philosophy_vision)
        
    *   [会社案内](https://www.docomo.ne.jp/corporate/about/?icid=CRP_menu_to_CRP_CORP_about)
        
    *   [サステナビリティ](https://www.docomo.ne.jp/corporate/csr/?icid=CRP_menu_to_CRP_CORP_csr)
        
    *   [技術とあんしん](https://www.docomo.ne.jp/corporate/technology_safety/?icid=CRP_menu_to_CRP_CORP_technology_safety)
        
    *   [IR情報](https://www.docomo.ne.jp/corporate/ir/library/?icid=CRP_menu_to_CRP_CORP_ir_library)
        
    *   [採用情報](https://www.docomo.ne.jp/corporate/recruit/?icid=CRP_menu_to_CRP_CORP_recruit)
        
    *   [NTTドコモグループ_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://nttdocomo-group.com/index.html)
        
    
*   法人のお客さま
    
    *   [NTTドコモビジネス_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.ntt.com/index.html)
        
    *   [NTTドコモ  \
        ソリューションズ_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.nttcom.co.jp/)
        
    *   [NTTドコモ・グローバル](https://www.docomo.ne.jp/global/?icid=CRP_TOP_to_CRP_global)
        
    
*   [![別ウィンドウで開きます。my docomo](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-my-docomo-logo.svg)](https://www.docomo.ne.jp/mydocomo/?icid=CRP_outerhead_to_MYD_TOP)
    
    [![別ウィンドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-online-shop-icon.svg)\
    \
    Online Shop](https://onlineshop.docomo.ne.jp/top-ols/?xcid=OLS_TOP_from_CRP_outerhead)
    
    [![別ウィンドウで開きます。のりかえ（MNP）](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-online-mnp-icon_pc.png)](https://onlineshop.docomo.ne.jp/special-contents/mnp?xcid=OLS_special-contents_mnp_flow_from_CRP_TOP_mnp_btn)
    
    [![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-switch-online-icon.svg)機種変更](https://www.docomo.ne.jp/support/switch_online/?icid=CRP_outerhead_to_SUP_switch_online)
    

 [![](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-daccount-logo.svg) ログインする](https://cfg.smt.docomo.ne.jp/auth/cgi/anidlogin?rl=https%3A%2F%2Fwww.docomo.ne.jp%2Finternet%2Fhikari%2Fcharge%2Findex.html)

[![dポイントクラブ](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-d-point-club-logo.svg)\
\
P\
\
![ランク](https://www.docomo.ne.jp/hikari/charge/)](https://www.docomo.ne.jp/hikari/charge/)
[![ドコモビジネスメンバーズ](https://www.docomo.ne.jp/images_osp/common/newhf/ico/ico_businessmembers.png)](https://www.docomo.ne.jp/hikari/charge/)

MENU

[![NTT docomo](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-header-logo.svg?ver=1751324418)](https://www.docomo.ne.jp/?icid=CRP_drawer_to_CRP_TOP)

[English](https://www.docomo.ne.jp/english/?icid=CRP_drawer_to_CRP_EN)

* * *

   ![検索する](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-header-search-icon.svg)

*    [![](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-my-docomo-logo.svg) My docomo _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.docomo.ne.jp/mydocomo/?icid=CRP_drawer_to_MYD_TOP)
     
*    [![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-online-shop-icon.svg) Online Shop _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://onlineshop.docomo.ne.jp/top-ols/?xcid=OLS_TOP_from_CRP_drawer)
     
*    [![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-docomo-shop-icon.svg) ドコモショップ _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://shop.smt.docomo.ne.jp/?xcid=DS_TOP_from_CRP_drawer)
     
*    [![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-customer-support-icon.svg) お客さまサポート](https://www.docomo.ne.jp/support/?icid=CRP_drawer_sup01_to_CRP_SUP)
    
*    [![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-campaign-icon.svg) キャンペーン・特典](https://www.docomo.ne.jp/campaign_event/?icid=CRP_drawer_to_CRP_CAM)
    
*    [![](https://www.docomo.ne.jp/assets/content/dam/corp/jp/ja/common/images/logo/cmn-rwd-d-point-club-logo.svg) dポイントクラブ _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://dpoint.docomo.ne.jp/)
     

*   *   *   商品・サービス
        *   *   ![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/ico_mobile.png) モバイル
                
                *   [iPhone](https://www.docomo.ne.jp/iphone/?icid=CRP_drawer_to_CRP_IPH)
                    
                *   [iPad](https://www.docomo.ne.jp/ipad/?icid=CRP_drawer_to_CRP_IPA)
                    
                *   [製品](https://www.docomo.ne.jp/product/?icid=CRP_drawer_to_CRP_PRD)
                    
                *   [料金・割引](https://www.docomo.ne.jp/charge/?icid=CRP_drawer_to_CRP_CHA)
                    
                *   [サービス・機能](https://www.docomo.ne.jp/service/?icid=CRP_drawer_to_CRP_SER)
                    
                *   [通信・エリア](https://www.docomo.ne.jp/area/?icid=CRP_drawer_to_CRP_AREA)
                    
                
            *   ![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/ico_internet.png) インターネット回線・固定電話
                
                *   [インターネット回線・固定電話トップ](https://www.docomo.ne.jp/internet/?icid=CRP_drawer_to_CRP_INT)
                    
                *   [ドコモ光](https://www.docomo.ne.jp/internet/hikari/?icid=CRP_drawer_to_CRP_INT_hikari)
                    
                *   [ahamo光](https://www.docomo.ne.jp/internet/ahamo_hikari/?icid=CRP_drawer_to_CRP_internet_ahamo_hikari)
                    
                *   [home 5G](https://www.docomo.ne.jp/home_5g/?icid=CRP_drawer_to_CRP_HOM)
                    
                *   [homeでんわ](https://www.docomo.ne.jp/home_denwa/?icid=CRP_drawer_to_CRP_DENWA)
                    
                
            *   ![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/ico_smartlife.png) スマートライフ
                
                *   [スマートライフ トップ](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_drawer_to_CRP_SER_smart-life)
                    
                *   [決済・保険・投資](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_drawer_to_CRP_SER_smart-life_finance&tgl_entertainment=0&tgl_life-support=0&tgl_finance=1&tgl_shopping=0&tgl_healthcare=0#finance)
                    
                *   [エンターテインメント](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_drawer_to_CRP_SER_smart-life_entertainment&tgl_entertainment=1&tgl_life-support=0&tgl_finance=0&tgl_shopping=0&tgl_healthcare=0#entertainment)
                    
                *   [ライフサポート](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_drawer_to_CRP_SER_smart-life_life-support&tgl_entertainment=0&tgl_life-support=1&tgl_finance=0&tgl_shopping=0&tgl_healthcare=0#life-support)
                    
                *   [ショッピング](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_drawer_to_CRP_SER_smart-life_shopping&tgl_entertainment=0&tgl_life-support=0&tgl_finance=0&tgl_shopping=1&tgl_healthcare=0#shopping)
                    
                *   [ヘルスケア](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_drawer_to_CRP_SER_smart-life_healthcare&tgl_entertainment=0&tgl_life-support=0&tgl_finance=0&tgl_shopping=0&tgl_healthcare=1#healthcare)
                    
                
            *   ![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/ico_denki.png?ver=1748827032) 電気・ガス
                
                *   [ドコモでんき／  \
                    ドコモ ガス トップ](https://www.docomo.ne.jp/denki/?icid=CRP_drawer_to_CRP_DENKI)
                    
                
    *   *   お知らせ
        *   *   お知らせ
                
                *   [お知らせ トップ](https://www.docomo.ne.jp/info/?icid=CRP_drawer_to_CRP_INFO)
                    
                *   [ニュースルーム](https://www.docomo.ne.jp/info/update/?icid=CRP_drawer_to_CRP_INFO_update)
                    
                *   [報道発表](https://www.docomo.ne.jp/info/news_release/?icid=CRP_drawer_to_CRP_INFO_news_release)
                    
                *   [重要なお知らせ（通信障害）](https://www.docomo.ne.jp/info/network/?icid=CRP_drawer_to_CRP_INFO_network)
                    
                *   [携帯電話サービスの通信状況（地域別）](https://www.docomo.ne.jp/info/status/?icid=CRP_drawer_to_CRP_INFO_status)
                    
                *   [工事のお知らせ](https://www.docomo.ne.jp/info/construction/?icid=CRP_drawer_to_CRP_INFO_construction)
                    
                
    *   *   企業情報
        *   *   企業情報
                
                *   [企業情報 トップ](https://www.docomo.ne.jp/corporate/?icid=CRP_drawer_to_CRP_CORP)
                    
                *   [あなたとドコモ](https://www.docomo.ne.jp/corporate/anatatodocomo/?icid=CRP_drawer_to_CRP_CORP_anatatodocomo)
                    
                *   [企業理念・ビジョン](https://www.docomo.ne.jp/corporate/philosophy_vision/?icid=CRP_drawer_to_CRP_CORP_philosophy_vision)
                    
                *   [会社案内](https://www.docomo.ne.jp/corporate/about/?icid=CRP_drawer_to_CRP_CORP_about)
                    
                *   [サステナビリティ](https://www.docomo.ne.jp/corporate/csr/?icid=CRP_drawer_to_CRP_CORP_csr)
                    
                *   [技術とあんしん](https://www.docomo.ne.jp/corporate/technology_safety/?icid=CRP_drawer_to_CRP_CORP_technology_safety)
                    
                *   [IR情報](https://www.docomo.ne.jp/corporate/ir/library/?icid=CRP_drawer_to_CRP_CORP_ir_library)
                    
                *   [採用情報](https://www.docomo.ne.jp/corporate/recruit/?icid=CRP_drawer_to_CRP_CORP_recruit)
                    
                *   [NTTドコモグループ_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://nttdocomo-group.com/index.html)
                    
                
*   *   地域別情報
        
        *   [北海道](https://www.docomo.ne.jp/hokkaido/?icid=CRP_drawer_to_hokkaido)
            
        *   [東北](https://www.docomo.ne.jp/tohoku/?icid=CRP_drawer_to_tohoku)
            
        *   [関東・甲信越](https://www.docomo.ne.jp/kanto/?icid=CRP_drawer_to_kanto)
            
        *   [東海](https://www.docomo.ne.jp/tokai/?icid=CRP_drawer_to_tokai)
            
        *   [北陸](https://www.docomo.ne.jp/hokuriku/?icid=CRP_drawer_to_hokuriku)
            
        *   [関西](https://www.docomo.ne.jp/kansai/?icid=CRP_drawer_to_kansai)
            
        *   [中国](https://www.docomo.ne.jp/chugoku/?icid=CRP_drawer_to_chugoku)
            
        *   [四国](https://www.docomo.ne.jp/shikoku/?icid=CRP_drawer_to_shikoku)
            
        *   [九州・沖縄](https://www.docomo.ne.jp/kyushu/?icid=CRP_drawer_to_kyushu)
            
        
    *   地域別情報
        
        *   [北海道](https://www.docomo.ne.jp/hokkaido/?icid=CRP_drawer_to_hokkaido)
            |
        *   [東北](https://www.docomo.ne.jp/tohoku/?icid=CRP_drawer_to_tohoku)
            |
        *   [関東・甲信越](https://www.docomo.ne.jp/kanto/?icid=CRP_drawer_to_kanto)
            |
        *   [東海](https://www.docomo.ne.jp/tokai/?icid=CRP_drawer_to_tokai)
            |
        *   [北陸](https://www.docomo.ne.jp/hokuriku/?icid=CRP_drawer_to_hokuriku)
            |
        *   [関西](https://www.docomo.ne.jp/kansai/?icid=CRP_drawer_to_kansai)
            |
        *   [中国](https://www.docomo.ne.jp/chugoku/?icid=CRP_drawer_to_chugoku)
            |
        *   [四国](https://www.docomo.ne.jp/shikoku/?icid=CRP_drawer_to_shikoku)
            |
        *   [九州・沖縄](https://www.docomo.ne.jp/kyushu/?icid=CRP_drawer_to_kyushu)
            
        
*   *   法人のお客さま
        
        *   [NTTドコモビジネス_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.ntt.com/index.html)
            
        *   [NTTドコモソリューションズ_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.nttcom.co.jp/)
            
        *   [NTTドコモ・グローバル](https://www.docomo.ne.jp/global/?icid=CRP_drawer_to_CRP_global)
            
        
    *   法人のお客さま
        
        *   [NTTドコモビジネス_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.ntt.com/index.html)
            |
        *   [NTTドコモソリューションズ_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.nttcom.co.jp/)
            |
        *   [NTTドコモ・グローバル](https://www.docomo.ne.jp/global/?icid=CRP_drawer_to_CRP_global)
            
        

ログインすると  
ポイント・ランク情報が確認できます

 [![](https://www.docomo.ne.jp/assets/content/dam/corp/jp/ja/common/images/logo/cmn-rwd-d-point-club-logo.svg) dアカウントにログインする](https://cfg.smt.docomo.ne.jp/auth/cgi/anidlogin?rl=https%3A%2F%2Fwww.docomo.ne.jp)

*   [dアカウントでもっと便利に](https://www.docomo.ne.jp/utility/daccount/?icid=CRP_drawer_to_CRP_UTI_daccount)
    
*   [別のIDでログイン](https://cfg.smt.docomo.ne.jp/auth/cgi/anidlogin?rl=https%3A%2F%2Fwww.docomo.ne.jp%2F)
    
*   [ログアウト](https://www.docomo.ne.jp/mydocomo/utility/confirm_logout/index.html)
    
*   [会員情報確認・変更_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon-white.svg)_](https://profile.smt.docomo.ne.jp/VIEW_ESITE/mem/sc/main.jsp?nid=MEG002006BJP)
    
*   [ログインでお困りの方_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon-white.svg)_](https://id.smt.docomo.ne.jp/src/utility/idpw_forget.html)
    
*   [２段階認証のお願い_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon-white.svg)_](https://id.smt.docomo.ne.jp/src/utility/sp/twostepauth.html)
    

オートログイン中

[![ランク](https://www.docomo.ne.jp/hikari/charge/#)](https://dpoint.docomo.ne.jp/member/stage_info/index.html)

* * *

[うち期間・用途限定](https://www.docomo.ne.jp/hikari/charge/)

* * *

[![ドコモビジネスメンバーズ](https://www.docomo.ne.jp/images_osp/common/newhf/ico/ico_businessmembers.png)](https://www.docomo.ne.jp/hikari/charge/)

*   [別のIDでログイン](https://cfg.smt.docomo.ne.jp/auth/cgi/anidlogin?rl=https%3A%2F%2Fwww.docomo.ne.jp%2F)
    
*   [ログアウト](https://www.docomo.ne.jp/mydocomo/utility/confirm_logout/index.html)
    
*   [会員情報確認・変更_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon-white.svg)_](https://profile.smt.docomo.ne.jp/VIEW_ESITE/mem/sc/main.jsp?nid=MEG002006BJP)
    
*   [２段階認証のお願い_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon-white.svg)_](https://id.smt.docomo.ne.jp/src/utility/sp/twostepauth.html)
    

*   [CMギャラリー_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.youtube.com/playlist?list=PLB334710B4B8111A8)
    
*   [よくあるご質問](https://faq.front.smt.docomo.ne.jp/?utm_source=docomo.ne.jp&utm_medium=api_linkage&utm_campaign=api_CRP_TOP)
    
*   [見やすさ・使いやすさの調整](https://www.docomo.ne.jp/utility/term/web_accessibility/faciliti/?icid=CRP_drawer_to_CRP_UTI_term_web_accessibility_faciliti)
    
*   [パーソナルデータ（個人情報など）について](https://www.docomo.ne.jp/utility/personal_data/?icid=CRP_drawer_to_CRP_UTI_personal_data)
    

*    [![](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-daccount-logo.svg) ログインする](https://cfg.smt.docomo.ne.jp/auth/cgi/anidlogin?rl=https%3A%2F%2Fwww.docomo.ne.jp%2Finternet%2Fhikari%2Fcharge%2Findex.html)
    
*   [![別ウィンドウで開きます。のりかえ（MNP）](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-online-mnp-icon_smt.png)](https://onlineshop.docomo.ne.jp/special-contents/mnp?xcid=OLS_special-contents_mnp_flow_from_CRP_TOP_mnp_btn)
    

*   [![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-switch-online-icon.svg)機種変更](https://www.docomo.ne.jp/support/switch_online/?icid=CRP_outerhead_to_SUP_switch_online)
    
*   [![](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-d-point-club-logo.svg)\
    \
    P\
    \
    ![](https://www.docomo.ne.jp/hikari/charge/)](https://www.docomo.ne.jp/hikari/charge/)
    

[![ドコモビジネスメンバーズ](https://www.docomo.ne.jp/images_osp/common/newhf/ico/ico_businessmembers.png)](https://www.docomo.ne.jp/hikari/charge/)

お客さまの設定により、お客さま情報が「非表示」となっております。お客さま情報を表示するにはdアカウントでログインしてください。  
[お客さま情報表示について](https://www.docomo.ne.jp/hikari/charge/)
へ

[お客さま情報表示について](https://www.docomo.ne.jp/hikari/charge/)
へ

*   [ホーム](https://www.docomo.ne.jp/)
    
*   [インターネット回線・固定電話](https://www.docomo.ne.jp/internet/)
    
*   [ドコモ光（光インターネット回線サービス）](https://www.docomo.ne.jp/internet/hikari/)
    
*   料金プラン

料金プラン
=====

マンション・戸建てにお住まいの方へ「ドコモ光 1ギガ／10ギガ」「ahamo光 1ギガ／10ギガ」の月額料金についてご案内します。

このページの内容
--------

*   [ドコモ光の月額料金__](https://www.docomo.ne.jp/hikari/charge/#anc-01)
    
*   [割引・特典__](https://www.docomo.ne.jp/hikari/charge/#anc-02)
    
*   [ahamo光の月額料金__](https://www.docomo.ne.jp/hikari/charge/#anc-03)
    
*   [初期費用__](https://www.docomo.ne.jp/hikari/charge/#anc-04)
    

*   [ドコモ光の月額料金__](https://www.docomo.ne.jp/hikari/charge/#anc-01)
    
*   [割引・特典__](https://www.docomo.ne.jp/hikari/charge/#anc-02)
    
*   [ahamo光の月額料金__](https://www.docomo.ne.jp/hikari/charge/#anc-03)
    
*   [初期費用__](https://www.docomo.ne.jp/hikari/charge/#anc-04)
    

ドコモ光の月額料金
---------

### ドコモ光 1ギガ

![ドコモ光 1ギガの画像](https://www.docomo.ne.jp/flcache_data/internet/hikari/charge/logo_docomo_hikari1giga_pc.png)![ドコモ光 1ギガの画像](https://www.docomo.ne.jp/flcache_data/internet/hikari/charge/logo_docomo_hikari1giga_smt.png)

対応プロバイダの違う4つのタイプをご用意しています。  
ご契約するプロバイダ、お住まいの形態により料金が異なります。  
1ギガ 単独タイプはお客さまご自身でプロバイダへのお申込みが必要なプランです。別途プロバイダ料金が発生します。  
ドコモはOCN インターネットをプロバイダとして提供（1ギガ タイプA）しています。  
「[1ギガ タイプC](https://www.docomo.ne.jp/internet/hikari/charge/type_c/?icid=CRP_INT_hikari_charge_manshon_01_to_CRP_INT_hikari_charge_type_c)
」をご利用の場合は、「1ギガ タイプA」と同様のプロバイダ料金一体型でご利用になれます。

#### マンションにお住まいの方

![1ギガ タイプAC※1 2年定期契約の場合※2 4,400円（税込） 定期契約なし 5,500円（税込） 1ギガ タイプB※1 2年定期契約の場合※2 4,620円（税込） 定期契約なし 5,720円（税込） 1ギガ 単独タイプ 2年定期契約の場合※2 4,180円（税込） 定期契約なし 5,280円（税込）](https://www.docomo.ne.jp/flcache_data/internet/hikari/charge/img_01_01_pc.png?ver=1741941070)![1ギガ タイプAC※1 2年定期契約の場合※2 4,400円（税込） 定期契約なし 5,500円（税込） 1ギガ タイプB※1 2年定期契約の場合※2 4,620円（税込） 定期契約なし 5,720円（税込） 1ギガ 単独タイプ 2年定期契約の場合※2 4,180円（税込） 定期契約なし 5,280円（税込）](https://www.docomo.ne.jp/flcache_data/internet/hikari/charge/img_01_01_smt.png?ver=1741941070)

#### 戸建てにお住まいの方

 ![1ギガ タイプAC※1 2年定期契約の場合※2 5,720円（税込） 定期契約なし 7,370円（税込） 1ギガ タイプB※1 2年定期契約の場合※2 5,940円（税込） 定期契約なし 7,590円（税込） 1ギガ 単独タイプ 2年定期契約の場合※2 5,500円（税込） 定期契約なし 7,150円（税込）](https://www.docomo.ne.jp/flcache_data/internet/hikari/charge/img_01_02_pc.png?ver=1743408019) ![1ギガ タイプAC※1 2年定期契約の場合※2 5,720円（税込） 定期契約なし 7,370円（税込） 1ギガ タイプB※1 2年定期契約の場合※2 5,940円（税込） 定期契約なし 7,590円（税込） 1ギガ 単独タイプ 2年定期契約の場合※2 5,500円（税込） 定期契約なし 7,150円（税込）](https://www.docomo.ne.jp/flcache_data/internet/hikari/charge/img_01_02_smt.png?ver=1743408019)

[ドコモ光 1ギガについて__](https://www.docomo.ne.jp/internet/hikari/1g_plan/?icid=CRP_INT_hikari_charge_to_CRP_INT_hikari_1g_plan)

[ドコモ光 1ギガ タイプC  \
について__](https://www.docomo.ne.jp/internet/hikari/charge/type_c/?icid=CRP_INT_hikari_charge_manshon_02_to_CRP_INT_hikari_charge_type_c)

*   ＼Webお申込みはこちら／
    
    [ドコモ光  \
    お申込み／ご相談フォームへ_![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://fmd.docomo-de.net/539/toPINQ01_input.jsp?formid=002&cid=001&utm_source=corp&utm_medium=owned&utm_campaign=dcmhikari_202312_bb-crp-from-charge-1)
    

*   ドコモ光お申込み／ご相談フォームはドコモ光 1ギガ、10ギガともに共通です。  
    担当オペレーターからのご連絡の際に料金プラン、通信速度などお申込み内容について確認させていただきます。
    
*   「ドコモ光ミニ」は2025年3月31日（月曜）をもってサービスの提供を終了いたしました。  
    詳しくは、報道発表「[「ドコモ光ミニ」の提供を終了](https://www.docomo.ne.jp/info/news_release/2022/12/05_00.html?icid=CRP_INT_hikari_charge_txt01_to_CRP_INFO_news_release_2022_12_05_00)
    」をご確認ください。
    

1.  プロバイダ料金が含まれたプランです。対応しているプロバイダは「[ドコモ光 1ギガ対応プロバイダ（タイプA・B・C）](https://www.docomo.ne.jp/internet/hikari/provider_list/?icid=CRP_INT_hikari_charge_01_to_CRP_INT_hikari_provider_list#provider_A)
    」よりご確認ください。
    
2.  定期契約プランは、2年間同一の「ドコモ光」契約を継続して利用することが条件となり、解約（定期契約のない料金プランへの変更含む）のお申出がない場合は自動更新となります。当該期間内での解約、定期契約のない料金プランへの変更などの場合、更新期間を除いて戸建タイプ5,500円（税込）、マンションタイプ4,180円（税込）の解約金がかかります（2022年6月30日以前にお申込みのお客さまの場合、戸建タイプ14,300円（税込）、マンションタイプ8,800円（税込）の解約金となります）。ただし、契約満了月の当月・翌月・翌々月はかかりません。「ドコモ光」の契約期間とペア回線（「ドコモ光」と対になる携帯電話回線）の契約期間は別々に取り扱われます。それぞれの契約期間が異なる場合、ペア回線の契約期間満了時に「ドコモ光」を解約した場合には、「ドコモ光」の解約金が発生します。  
    解約金は、お手続き当月のご利用分に対する請求時にあわせて請求させていただきます。なお、各月1日でのお手続きにより解約金が生じた場合のみ、お手続き前月のご利用分とあわせて解約金を請求させていただきます。単独タイプは別途プロバイダ料金・お申込みが必要です。ご利用予定のプロバイダのドコモ光対応可否については、工事予定日までにお客さまご自身でプロバイダ事業者へご確認ください。
    

### ドコモ光 10ギガ

![ドコモ光 10ギガの画像](https://www.docomo.ne.jp/flcache_data/internet/hikari/charge/logo_docomo_hikari10giga_pc.png)![ドコモ光 10ギガの画像](https://www.docomo.ne.jp/flcache_data/internet/hikari/charge/logo_docomo_hikari10giga_smt.png)

「ドコモ光 10ギガ」の月額料金は戸建プラン・マンションプラン同額となります。  
対応プロバイダの違う4つのタイプをご用意しています。  
ご契約するプロバイダにより料金が異なります。  
10ギガ 単独タイプはお客さまご自身でプロバイダへのお申込みが必要なプランです。別途プロバイダ料金が発生します。  
ドコモはOCN インターネットをプロバイダとして提供（10ギガ タイプA）しています。

![ドコモ光 10ギガ 基本料金ワンコインキャンペーン 新規お申込みで最大6か月間 500円／月（税込） ※ルーター利用料金別途など、各種条件があります。 ※キャンペーン適用終了後、タイプAの場合6,380／月（税込）となります。](https://www.docomo.ne.jp/flcache_data/internet/hikari/10g_plan/bnr_campaign_pc.png?ver=1724857213)![ドコモ光 10ギガ 基本料金ワンコインキャンペーン 新規お申込みで最大6か月間 500円／月（税込） ※ルーター利用料金別途など、各種条件があります。 ※キャンペーン適用終了後、タイプAの場合6,380／月（税込）となります。](https://www.docomo.ne.jp/flcache_data/internet/hikari/10g_plan/bnr_campaign_sp.png?ver=1724857213)

#### マンション・戸建てにお住まいの方

![10ギガ タイプAC※3 2年定期契約の場合※4 6,380円（税込） 定期契約なし 8,030円（税込） 10ギガ タイプB※3 2年定期契約の場合※4 6,600円（税込） 定期契約なし 8,250円（税込） 10ギガ 単独タイプ 2年定期契約の場合※4 5,940円（税込） 定期契約なし 7,590円（税込）](https://www.docomo.ne.jp/flcache_data/internet/hikari/charge/img_02_pc.png?ver=1741941070)![10ギガ タイプAC※3 2年定期契約の場合※4 6,380円（税込） 定期契約なし 8,030円（税込） 10ギガ タイプB※3 2年定期契約の場合※4 6,600円（税込） 定期契約なし 8,250円（税込） 10ギガ 単独タイプ 2年定期契約の場合※4 5,940円（税込） 定期契約なし 7,590円（税込）](https://www.docomo.ne.jp/flcache_data/internet/hikari/charge/img_02_smt.png?ver=1741941071)

[ドコモ光 10ギガについて__](https://www.docomo.ne.jp/internet/hikari/10g_plan/?icid=CRP_INT_hikari_charge_to_CRP_INT_hikari_10g_plan)

[ドコモ光 10ギガ タイプC  \
について__](https://www.docomo.ne.jp/internet/hikari/charge/10g_type_c/?icid=CRP_INT_hikari_charge_01_to_CRP_INT_hikari_charge_10g_type_c)

*   ＼Webお申込みはこちら／
    
    [ドコモ光  \
    お申込み／ご相談フォームへ_![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://fmd.docomo-de.net/539/toPINQ01_input.jsp?formid=002&cid=001&utm_source=corp&utm_medium=owned&utm_campaign=dcmhikari_202312_bb-crp-from-charge-2)
    

*   ドコモ光お申込み／ご相談フォームはドコモ光 1ギガ、10ギガともに共通です。  
    担当オペレーターからのご連絡の際に料金プラン、通信速度などお申込み内容について確認させていただきます。
    

1.  プロバイダ料金が含まれたプランです。対応しているプロバイダは「[ドコモ光 10ギガ対応プロバイダ（タイプA・B・C）](https://www.docomo.ne.jp/internet/hikari/provider_list/?icid=CRP_INT_hikari_charge_02_to_CRP_INT_hikari_provider_list#provider_10A)
    」よりご確認ください。
    
2.  2年間同一の「ドコモ光」の継続利用が条件となり、当該期間内での解約、定期契約のない料金プランへの変更などの場合、更新期間を除いて5,500円（税込）の解約金がかかります。なお、「ドコモ光」とペア回線（「ドコモ光」と対になる携帯電話回線）の契約期間および更新期間はそれぞれ異なりますので、ご注意ください。
    

#### プロバイダについて

ドコモの提供プロバイダ「OCN インターネット」をはじめ、さまざまなプロバイダから選べますが、プロバイダにより料金プランが異なります。  
なお、ドコモはプロバイダとしてOCN インターネットを提供しています。

*   [OCNインターネット__](https://www.docomo.ne.jp/internet/hikari/provider_list/ocn/?icid=CRP_INT_hikari_charge_to_CRP_INT_hikari_provider_list_ocn)
    
*   [プロバイダ一覧__](https://www.docomo.ne.jp/internet/hikari/provider_list/?icid=CRP_INT_hikari_charge_03_to_CRP_INT_hikari_provider_list)
    

#### 料金シミュレーション

ケータイ電話とドコモ光を組み合わせた場合の月々のお支払い額をシミュレーションできます。

*   [料金シミュレーション__](https://www.docomo.ne.jp/charge/simulation/?icid=CRP_INT_hikari_charge_to_CRP_CHA_simulation)
    

割引・特典
-----

### ドコモ光セット割

[![ドコモユーザーなら スマホとセットでスマホ料金から永年最大1,210円（税込）／月割引！！ ※「ドコモ光」のご契約と同一「ファミリー割引」グループ内の「ドコモ MAX」「ドコモ ポイ活 MAX」「ドコモ ポイ活 20」「ドコモ mini」が対象 ※プラン・利用データ量により割引額は変動](https://www.docomo.ne.jp/flcache_data/internet/hikari/charge/img_03_pc.png?ver=1749049275)![ドコモユーザーなら スマホとセットでスマホ料金から永年最大1,210円（税込）／月割引！！ ※「ドコモ光」のご契約と同一「ファミリー割引」グループ内の「ドコモ MAX」「ドコモ ポイ活 MAX」「ドコモ ポイ活 20」「ドコモ mini」が対象 ※プラン・利用データ量により割引額は変動](https://www.docomo.ne.jp/flcache_data/internet/hikari/charge/img_03_smt.png?ver=1749049275)](https://www.docomo.ne.jp/charge/hikari_set/?icid=CRP_INT_hikari_charge_to_CRP_CHA_hikari_set)

家族内（同一「ファミリー割引」グループ内）に、「ドコモ光」をご契約の方がいれば、スマホ1回線ごとに永年最大1,210円（税込）割引します。

*   「eximo」「eximo ポイ活」「irumo（0.5GBを除く）」「5Gギガホ プレミア」「5Gギガホ」「5Gギガライト」「ギガホ プレミア」「ギガホ」「ギガライト」は最大1,100円／月（税込）割引となります。
    

ahamo光の月額料金
-----------

![ahamo 光](https://www.docomo.ne.jp/flcache_data/internet/hikari/charge/logo_docomo_ahamohikari_pc.png)![ahamo 光](https://www.docomo.ne.jp/flcache_data/internet/hikari/charge/logo_docomo_ahamohikari_smt.png)

フレッツ光回線の設備を使ってドコモが提供する  
「ahamoユーザー専用」の光インターネットサービスです！

*   「ahamo光」のお申込みには、ペア回線（「ahamo」を契約している携帯電話回線）の番号が必要です。
    
*   ahamo光 1ギガ／10ギガともにご利用には「OCNバーチャルコネクト」に対応したルーターが必要です。さらにahamo光 10ギガの場合、最大通信速度10Gbpsのインターネット接続には10Gbpsに対応したルーターが必要です。
    
*   「OCNバーチャルコネクト」対応ルーターは[こちら_PDF_](https://www.ntt.com/content/dam/nttcom/hq/jp/business/services/network/internet-connect/ocn-business/option/v-access-ipoe/pdf/bocn_vc_router.pdf)
    をご確認ください。対応ルーターであってもOCNバーチャルコネクトサービス（IPoE接続）に対応したバージョンでない場合は接続ができない可能性がございます。
    

### ahamo光 1ギガ

「ahamo光 1ギガ」は最大1Gbps※の高速通信をデータ容量無制限であんしん快適に利用できる光回線サービスです。

*   「ahamo光」はベストエフォート型サービスです。最大通信速度は技術規格上の最大値となり、お客さま宅内での実使用速度はお客さまのご利用環境・ご利用機器、回線の混雑状況などによって低下します。
    

[![ahamo光 1ギガ マンションにお住まいの方 2年定期契約の場合 3,630円／月（税込） （契約期間なし：4,730円／月（税込）） 戸建にお住まいの方 2年定期契約の場合 4,950円／月（税込） （契約期間なし：6,600円／月（税込））](https://www.docomo.ne.jp/flcache_data/internet/hikari/charge/1giga_pc.png?ver=1709254839)![ahamo光 1ギガ マンションにお住まいの方 2年定期契約の場合 3,630円／月（税込） （契約期間なし：4,730円／月（税込）） 戸建にお住まいの方 2年定期契約の場合 4,950円／月（税込） （契約期間なし：6,600円／月（税込））](https://www.docomo.ne.jp/flcache_data/internet/hikari/charge/1giga_sp.png?ver=1709254839)](https://www.docomo.ne.jp/internet/ahamo_hikari/1g_plan/?icid=CRP_INT_hikari_charge_img_to_CRP_INT_ahamo_hikari_1g_plan)

[ahamo光 1ギガ について__](https://www.docomo.ne.jp/internet/ahamo_hikari/1g_plan/?icid=CRP_INT_hikari_charge_to_CRP_INT_ahamo_hikari_1g_plan)

*   定期契約プランは、2年間同一の「ahamo光」契約を継続して利用することが条件となり、解約（定期契約のない料金プランへの変更含む）のお申出がない場合は自動更新となります。当該期間内での解約、定期契約のない料金プランへの変更などの場合、更新期間を除いて解約金がかかります（「ahamo光 1ギガ」の場合、戸建タイプ4,950円（税込）／マンションタイプ3,630円（税込））。ただし、契約満了月の当月・翌月・翌々月はかかりません。「ahamo光」の契約期間とペア回線（「ahamo光」と対となるahamo契約の携帯電話回線）の契約期間は別々に取り扱われます。それぞれの契約期間が異なる場合、ペア回線の契約期間満了時に「ahamo光」を解約した場合には、「ahamo光」の解約金が発生します。  
    解約金は、お手続き当月のご利用分に対する請求時にあわせて請求させていただきます。なお、各月1日でのお手続きにより解約金が生じた場合のみ、お手続き前月のご利用分とあわせて解約金を請求させていただきます。
    
*   「ahamo光」はドコモ光セット割の割引対象外となります。
    

### ahamo光 10ギガ

「ahamo光 10ギガ」は最大通信速度10Gbps※の超高速インターネット！  
月額料金は戸建プラン・マンションプラン同額となります。

*   「ahamo光」はベストエフォート型サービスです。最大通信速度は技術規格上の最大値となり、お客さま宅内での実使用速度はお客さまのご利用環境・ご利用機器、回線の混雑状況などによって低下します。
    

![ahamo光 10ギガ 基本料金ワンコインキャンペーン 新規お申込みで最大6か月間 500円／月（税込） ※ルーター利用料金別途など、各種条件があります。 ※キャンペーン適用終了後、ahamo光 10ギガの場合5,610円／月（税込）となります。](https://www.docomo.ne.jp/flcache_data/internet/hikari/charge/bnr_campaign02_pc.png?ver=1724857213)![ahamo光 10ギガ 基本料金ワンコインキャンペーン 新規お申込みで最大6か月間 500円／月（税込） ※ルーター利用料金別途など、各種条件があります。 ※キャンペーン適用終了後、ahamo光 10ギガの場合5,610円／月（税込）となります。](https://www.docomo.ne.jp/flcache_data/internet/hikari/charge/bnr_campaign02_sp.png?ver=1724857213)

[![ahamo光 10ギガ マンション・戸建 共通2年定期契約の場合 5,610円／月（税込） （契約期間なし：7,260円／月（税込））](https://www.docomo.ne.jp/flcache_data/internet/hikari/charge/10giga_pc.png?ver=1709254839)![ahamo光 10ギガ マンション・戸建 共通2年定期契約の場合 5,610円／月（税込） （契約期間なし：7,260円／月（税込））](https://www.docomo.ne.jp/flcache_data/internet/hikari/charge/10giga_sp.png?ver=1709254839)](https://www.docomo.ne.jp/internet/ahamo_hikari/10g_plan/?icid=CRP_INT_hikari_charge_img_to_CRP_INT_ahamo_hikari_10g_plan)

[ahamo光 10ギガ について__](https://www.docomo.ne.jp/internet/ahamo_hikari/10g_plan/?icid=CRP_INT_hikari_charge_to_CRP_INT_ahamo_hikari_10g_plan)

*   定期契約プランは、2年間同一の「ahamo光」契約を継続して利用することが条件となり、解約（定期契約のない料金プランへの変更含む）のお申出がない場合は自動更新となります。当該期間内での解約、定期契約のない料金プランへの変更などの場合、更新期間を除いて解約金がかかります（「ahamo光 10ギガ」の場合、戸建・マンションタイプともに5,610円（税込））。ただし、契約満了月の当月・翌月・翌々月はかかりません。「ahamo光」の契約期間とペア回線（「ahamo光」と対となるahamo契約の携帯電話回線）の契約期間は別々に取り扱われます。それぞれの契約期間が異なる場合、ペア回線の契約期間満了時に「ahamo光」を解約した場合には、「ahamo光」の解約金が発生します。  
    解約金は、お手続き当月のご利用分に対する請求時にあわせて請求させていただきます。なお、各月1日でのお手続きにより解約金が生じた場合のみ、お手続き前月のご利用分とあわせて解約金を請求させていただきます。
    
*   「ahamo光」はドコモ光セット割の割引対象外となります。
    

初期費用
----

契約事務手数料、工事料が必要です。  
お客さまの設備、お申込み状況によって異なりますので、詳細は工事料金シミュレーションにてご自身の工事料をご確認ください。  
原則、ご利用開始日の翌月にご利用料金とあわせてご請求させていただきます。

*   2024年2月1日（木曜）より工事料を改定いたしました。
    

*   [工事料金シミュレーション_![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://docomohikari-koujiryo.ac.at.nttdocomo.co.jp/index.php/site)
    

### ドコモ光 1ギガの初期費用例

#### 新規お申込みの場合

![契約事務手数料4,950円（税込）＋工事料（※代表例）戸建・マンション：22,000円（税込）](https://www.docomo.ne.jp/flcache_data/internet/hikari/charge/img_05_pc.png?ver=1756998013)![契約事務手数料4,950円（税込）＋工事料（※代表例）戸建・マンション：22,000円（税込）](https://www.docomo.ne.jp/flcache_data/internet/hikari/charge/img_05_smt.png?ver=1756998013)

#### 転用お申込みの場合（速度そのまま）

![契約事務手数料4,950円（税込）＋工事料（※代表例）0円](https://www.docomo.ne.jp/flcache_data/internet/hikari/charge/img_06_pc.png?ver=1756998013)![契約事務手数料4,950円（税込）＋工事料（※代表例）0円](https://www.docomo.ne.jp/flcache_data/internet/hikari/charge/img_06_smt.png?ver=1756998013)

### ドコモ光 10ギガの初期費用例

#### 新規お申込みの場合

![契約事務手数料4,950円（税込）＋工事料（※代表例）戸建・マンション：22,000円（税込）](https://www.docomo.ne.jp/flcache_data/internet/hikari/charge/img_07_pc.png?ver=1756998013)![契約事務手数料4,950円（税込）＋工事料（※代表例）戸建・マンション：22,000円（税込）](https://www.docomo.ne.jp/flcache_data/internet/hikari/charge/img_07_smt.png?ver=1756998013)

#### 「ドコモ光 1ギガ」から「ドコモ光 10ギガ」への料金プラン変更例

![工事料（※代表例）戸建・マンション：22,000円（税込）](https://www.docomo.ne.jp/flcache_data/internet/hikari/charge/img_08_pc.png?ver=1708477224)![工事料（※代表例）戸建・マンション：22,000円（税込）](https://www.docomo.ne.jp/flcache_data/internet/hikari/charge/img_08_smt.png?ver=1708477224)

*   設備状況により11,660円（税込）となる場合があります。 （工事担当者がお客さま宅の設備を確認させていただいたのちに判明します）
    

### 初期費用に関するご注意事項

*   「フレッツ光」の割引サービス（にねん割、光もっともっと割など）の、中途解約金はかかりません。
    
*   工事料は一般的な代表例です。お客さまの設備状況によっては変動することがあります。
    
*   一部の「ドコモ光」工事料のお支払いは一括、分割をお選びいただくことができます。分割支払い期間中に「ドコモ光」を解約された場合、解約月の翌月に残債を一括で請求させていただきます。
    
*   工事実施前であれば、お申込みの取消が可能です。その場合「ドコモ光」に関するキャンセル料などはかかりません。ただし、工事着手後にお申込みの取消をされた場合は、発生した費用について、お客さまにご請求させていただきます。
    
*   土日休日に派遣工事を実施する場合は、上記に加え3,300円（税込）かかります。
    
*   年末年始に派遣工事を実施する場合は、料金が異なります。詳しくはお問い合わせください。
    
*   フレッツ光初期工事料の分割払いの残債がある場合は、その残債相当額を当社より「ドコモ光」のご利用料金と合わせて、毎月分割して請求させていただきます。請求開始は転用月の翌々月からとなります。
    

*   工事料・事務手数料を含むご利用料金は、ご利用開始日時点の消費税率が適用されます。
    

* * *

*   [![別ウインドウで開きます Get Adobe Acrobat Reader](https://www.docomo.ne.jp/images_osp/common/bnr/bnr_adobe_reader01.png)](https://get.adobe.com/jp/reader/)
    
    PDF形式のファイルをご覧いただくには、アドビシステムズ社から無償提供されている  
    [![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window01.png)Adobe® Reader®](https://get.adobe.com/jp/reader/)
    プラグインが必要です。「Adobe® Acrobat®」でご覧になる場合は、バージョン10以降をご利用ください。
    

よくあるご質問（FAQ）
------------

*   ![Q](https://www.docomo.ne.jp/images_osp/common/ico/ico_question01.png)
    
    [【_ドコモ光_】_ドコモ光_ 1ギガから_ドコモ光_ 10ギガへ_料金__プラン_を変更したい](https://faq.front.smt.docomo.ne.jp/detail?faqId=280359&utm_source=docomo.ne.jp&utm_medium=api_linkage&utm_campaign=api_CRP_INT_hikari_charge)
    
*   ![Q](https://www.docomo.ne.jp/images_osp/common/ico/ico_question01.png)
    
    [【_ドコモ光_】_ドコモ光_ 10ギガの_料金__プラン_について教えてください](https://faq.front.smt.docomo.ne.jp/detail?faqId=281466&utm_source=docomo.ne.jp&utm_medium=api_linkage&utm_campaign=api_CRP_INT_hikari_charge)
    
*   ![Q](https://www.docomo.ne.jp/images_osp/common/ico/ico_question01.png)
    
    [【_ドコモ光_】_ドコモ光_ 1ギガの_料金__プラン_について教えてください](https://faq.front.smt.docomo.ne.jp/detail?faqId=247436&utm_source=docomo.ne.jp&utm_medium=api_linkage&utm_campaign=api_CRP_INT_hikari_charge)
    

[「ドコモ光　料金プラン」に関するよくあるご質問（FAQ）へ](https://faq.front.smt.docomo.ne.jp/search?keyword=%E3%83%89%E3%82%B3%E3%83%A2%E5%85%89%E3%80%80%E6%96%99%E9%87%91%E3%83%97%E3%83%A9%E3%83%B3&categoryId=161&utm_source=docomo.ne.jp&utm_medium=api_linkage&utm_campaign=api_CRP_INT_hikari_charge&sort=3)

[インターネット回線・固定電話](https://www.docomo.ne.jp/internet/)

-----------------------------------------------------

*   [ドコモ光（光インターネット回線サービス）](https://www.docomo.ne.jp/internet/hikari/)
    
*   [メニューを開く![](https://www.docomo.ne.jp/images_osp/common/btn/btn_toggle_open02.png)](https://www.docomo.ne.jp/hikari/charge/#)
    
    *   [_料金プラン_](https://www.docomo.ne.jp/internet/hikari/charge/)
        
    *   [工事料分割払い](https://www.docomo.ne.jp/internet/hikari/construction_costs/)
        
    *   [映像サービス](https://www.docomo.ne.jp/internet/hikari/eizo_service/)
        
    *   [ご注意事項](https://www.docomo.ne.jp/internet/hikari/notice/)
        
    *   [各種お手続き方法](https://www.docomo.ne.jp/internet/hikari/procedure/)
        
    *   [ドコモ光のプロバイダ](https://www.docomo.ne.jp/internet/hikari/provider_list/)
        
    *   [充実のサポート](https://www.docomo.ne.jp/internet/hikari/support/)
        
    *   [ドコモ光電話](https://www.docomo.ne.jp/internet/hikari/tell_service/)
        
    *   [その他サポート情報](https://www.docomo.ne.jp/internet/hikari/trouble/)
        
    *   [転用](https://www.docomo.ne.jp/internet/hikari/tenyou/)
        
    *   [ドコモ光 1ギガ（固定回線）](https://www.docomo.ne.jp/internet/hikari/1g_plan/)
        
    *   [ドコモ光 10ギガ](https://www.docomo.ne.jp/internet/hikari/10g_plan/)
        
    *   [「ドコモ光 10ギガ」への料金プラン変更](https://www.docomo.ne.jp/internet/hikari/10g_plan_change/)
        
    *   [他社光サービスからのきりかえ（事業者変更）](https://www.docomo.ne.jp/internet/hikari/collabo_change/)
        
    *   [新規契約](https://www.docomo.ne.jp/internet/hikari/subscribe/)
        
    *   [ドコモ光の宅内機器の接続設定方法](https://www.docomo.ne.jp/internet/hikari/hikari_connection/)
        
    *   [他社サービスからのきりかえ（光回線再利用）](https://www.docomo.ne.jp/internet/hikari/hikari_reuse/)
        
    

[![このページのトップへ](https://www.docomo.ne.jp/images_osp/common/btn/btn_pagetop_01.png)](https://www.docomo.ne.jp/hikari/charge/#)

  

[![お困りですか？](https://www.docomo.ne.jp/images_osp/common/chat_tool/bnr_chat_tool.svg)](https://tetsuduki-support.docomo.ne.jp/?utm_source=corp&utm_medium=free-display&utm_campaign=onsapo_)

  

このページの情報は役に立ちましたか？

*    はい
*    いいえ

送信する

このページの情報は役に立ちましたか？

*    はい
*    いいえ

送信する

ドコモサイトの改善のために、  
あなたの回答の理由を教えてください（問）
-------------------------------------

※「アンケートに回答する」ボタンを押すと、  
アンケート画面が開きます。

[アンケートに回答する](https://www.docomo.ne.jp/hikari/charge/#survey)

ご回答ありがとうございました
--------------

ご意見は今後のWebサイト改善の参考とさせていただきます。

*   データは匿名化されており、個人が特定されることはございません。また調査以外の目的で利用されることはございません。
    

  

NTTドコモサイトについてのアンケート
-------------------

差し支えなければ、以下のアンケートにもご協力ください。

※この画面を閉じて元のページに戻るには画面右上の「閉じる」を押してください。

### Q.お探しの情報はどのような情報でしたか？あてはまるものをすべて選択してください。

### Q.あなたの年齢をお答えください。

*   10代以下
*   20代
*   30代
*   40代
*   50代
*   60代
*   70代以上
*   回答しない

10代以下 20代 30代 選択してください 40代 50代 60代 70代以上 回答しない

### Q.このページが「役に立たなかった」と思われた点について、あてはまるものをすべて選択してください。

*   [ ] 知りたい情報が書かれていなかった
*   [ ] 必要な情報がまとまっていなかった
*   [ ] 知りたい内容までの適切な誘導がなかった
*   [ ] GoogleやYahoo！で検索しても目的のページが出てこなかった
*   [ ] このサイト内で検索しても目的のページが出てこなかった
*   [ ] どのキーワードで検索すればいいかわからなかった
*   [ ] 目的と違うページにたどり着いた
*   [ ] 見たい情報がどこにありそうか想定できなかった
*   [ ] 選択肢が紛らわしかった
*   [ ] クリックなど操作がしづらかった
*   [ ] 文章がわかりづらかった
*   [ ] 絵や画像がわかりづらかった
*   [ ] 表示されるのが遅かった
*   [ ] その他
*   [ ] あてはまるものはない

回答を送信する

NTTドコモサイトについてのアンケート
-------------------

### ご回答ありがとうございました。

※本アンケートに関する個人情報等の取扱いについては「[NTTドコモ プライバシーポリシー](https://www.docomo.ne.jp/utility/privacy/?icid=CRP_SURVEY_end_to_CRP_UTI_privacy)
」で定めています。

*   [お知らせ](https://www.docomo.ne.jp/info/?icid=CRP_common_footer_to_CRP_INFO)
    
*   [企業情報](https://www.docomo.ne.jp/corporate/?icid=CRP_common_footer_to_CRP_CORP)
    

* * *

*   [パーソナルデータ（個人情報など）について](https://www.docomo.ne.jp/utility/personal_data/?icid=CRP_common_footer_to_CRP_UTI_personal_data)
    
*   [プライバシーポリシー](https://www.docomo.ne.jp/utility/privacy/?icid=CRP_common_footer_to_CRP_UTI_privacy)
    
*   [サイトご利用にあたって](https://www.docomo.ne.jp/utility/term/?icid=CRP_common_footer_to_CRP_UTI_term)
    
*   [お客さまご利用端末からの情報の外部送信について](https://www.docomo.ne.jp/utility/term/?icid=CRP_common_footer_02_to_CRP_UTI_term#p09)
    
*   [見やすさ・使いやすさの調整](https://www.docomo.ne.jp/utility/term/web_accessibility/faciliti/?icid=CRP_common_footer_to_CRP_UTI_term_web_accessibility_faciliti)
    
*   [サイトメンテナンス情報_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon-white.svg)_](https://www.docomo.ne.jp/mydocomo/maint/?icid=CRP_common_footer_to_CRP_MYD_maint)
    
*   [サイトマップ](https://www.docomo.ne.jp/sitemap/?icid=CRP_common_footer_to_CRP_sitemap)
    
*   [ご意見・ご要望](https://www.docomo.ne.jp/support/inquiry/feedback/?icid=CRP_common_footer_to_CRP_SUP_inquiry_feedback)
    
*   [お問い合わせ](https://www.docomo.ne.jp/support/inquiry/?icid=CRP_common_footer_to_CRP_SUP_inquiry)
    
*   [NTTドコモグループ_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon-white.svg)_](https://nttdocomo-group.com/index.html)
    

© NTT DOCOMO

![閉じる](https://www.docomo.ne.jp/images_osp/common/smtnav/btn_smtmenu_01_close_crp.png)
