# NTTドコモビジネス（旧：NTTコミュニケーションズ） オフィシャルサイト

URL: https://www.nttdocomo.co.jp/biz/

---

[2025年7月より、NTTコミュニケーションズは  \
NTTドコモビジネスに社名を変更しました](https://www.nttdocomo.co.jp/about-us/nttdocomobusiness.html)

[![NTTドコモビジネス](https://www.nttdocomo.co.jp/content/dam/nttcom/cmn/img/header/ntt-docomo-business_logo_jp_1line.svg)](https://www.nttdocomo.co.jp/index.html)

*   [![ビジネスdアカウントログイン](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/business/lp/img/btn_login_businesspoint.png)](https://www.nttdocomo.co.jp/docomo-id-biz/auth-login.html?orgurl=%2Findex.html)
    
*   [![ビジネスdアカウントログアウト](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/business/lp/img/btn_logout__businesspoint.png)](https://www.nttdocomo.co.jp/docomo-id-biz/auth-logout.html?orgurl=%2Findex.html)
    
*   [オンラインショップ 別ウィンドウで開きます。](https://www.onlineshop.docomobusiness.ntt.com/)
    
*   *   [ご契約中のお客さま](https://www.nttdocomo.co.jp/biz/#)
        
        *   [×閉じる](https://www.nttdocomo.co.jp/biz/#)
            
        
        *   [![](https://www.nttdocomo.co.jp/content/dam/nttcom/cmn/img/icn_contract_support.png)\
            \
            サービス別サポート情報  \
            (サポートサイト)](https://support.ntt.com/)
            
        *   [![](https://www.nttdocomo.co.jp/content/dam/nttcom/cmn/img/icn_contract_portal.png)\
            \
            ご契約中サービスの一元管理  \
            (NTTドコモビジネス  \
            ビジネスポータル)![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://b-portal.ntt.com/login/)
            
        *   [![](https://www.nttdocomo.co.jp/content/dam/nttcom/cmn/img/icn_contract_billingstation.png)\
            \
            NTTドコモビジネス  \
            Web明細  \
            (ビリングステーション)![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://www.billingstation.ntt.com/user/UA01W001)
            
        *   [![](https://www.nttdocomo.co.jp/content/dam/nttcom/cmn/img/icn_contract_gorikan.png)\
            \
            NTTドコモ(携帯回線)  \
            料金分析  \
            (ご利用料金管理サービス)![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://gorikan.billing.smt.docomo.ne.jp/bbilling/srv/ghadp001.srv?_ebx=swv0q1a1be.1708318872.811fu7s)
            
        *   [![](https://www.nttdocomo.co.jp/content/dam/nttcom/cmn/img/icn_contract_mydocomo.png)\
            \
            NTTドコモ(携帯回線)  \
            Web明細  \
            (My docomo)![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://www.docomo.ne.jp/mydocomo/)
            
        
    *   [個人のお客さま](https://www.nttdocomo.co.jp/biz/#)
        
        *   [×閉じる](https://www.nttdocomo.co.jp/biz/#)
            
        
        *   [個人のお客さま（NTTドコモ） ![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://www.docomo.ne.jp/)
             
            
        *   [個人のお客さま（OCNなど） ![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://service.ocn.ne.jp/)
             
            
        
*   [![Global Site](https://www.nttdocomo.co.jp/content/dam/nttcom/cmn/img/icn-country-selector.svg)JP](https://www.nttdocomo.co.jp/biz/#)
    
    Select Language : [English](https://www.nttdocomo.co.jp/en/index.html)
     日本語
    
    [×閉じる](https://www.nttdocomo.co.jp/biz/#)
    
    Global Site : [NTT Ltd. ![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://services.global.ntt/)
     
    
*       
    
    [![Search](https://www.nttdocomo.co.jp/content/dam/nttcom/cmn/img/icn-search.svg)](https://www.nttdocomo.co.jp/sitesearch.html)
    

[_MENU_](https://www.nttdocomo.co.jp/biz/#)

*   [産業・地域DX/事業共創](https://www.nttdocomo.co.jp/biz/#)
    
    *   [OPEN HUB ![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://openhub.ntt.com/)
         
        
        新規ビジネスの創出や社会実装を  
        目指す事業共創の場です
        
        *   [OPEN HUB for Smart Worldとは ![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://openhub.ntt.com/about/)
             
        *   [イベント/ウェビナー ![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://openhub.ntt.com/event/)
             
        *   [記事コンテンツ ![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://openhub.ntt.com/journal/)
             
        *   [プレイヤー(カタリスト/パートナー企業) ![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://openhub.ntt.com/player/)
             
        *   [事例 ![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://openhub.ntt.com/project/)
             
        
    *   [Smart World](https://www.nttdocomo.co.jp/business/dx/smart.html)
        
        産業・地域DXプラットフォーマーとして  
        企業と地域が持続成長する社会を目指します
        
        *   [Smart City](https://www.nttdocomo.co.jp/business/dx/smart/city.html)
            
        *   [Smart Education](https://www.nttdocomo.co.jp/business/dx/smart/education.html)
            
        *   [Smart Healthcare](https://www.nttdocomo.co.jp/business/dx/smart/healthcare.html)
            
        *   [Smart Industry](https://www.nttdocomo.co.jp/business/dx/smart/industry.html)
            
        *   [Smart Mobility](https://www.nttdocomo.co.jp/business/dx/smart/mobility.html)
            
        *   [Smart Worksite](https://www.nttdocomo.co.jp/business/dx/smart/worksite.html)
            
        *   [生成AI(Generative AI)](https://www.nttdocomo.co.jp/business/dx/smart/generative-ai.html)
            
        
    *   [地域の取り組み](https://www.nttdocomo.co.jp/business/lp/regional-effort.html)
        
        地域社会を支える皆さまと地域課題の解決や  
        地域経済のさらなる活性化に取り組みます
        
        *   [自治体・地域社会との共創](https://www.nttdocomo.co.jp/business/lp/regional-effort/local-goverments.html)
            
        *   [LGPF（Local Government Platform）](https://www.nttdocomo.co.jp/business/lp/regional-effort/lgpf.html)
            
        
    
    *    [![OPEN HUB│for Smart World　詳しくはこちら](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/about-us/img/header-banner/banner-open_hub.png) 別ウィンドウで開きます。](https://openhub.ntt.com/)
        
    *   [![地域とともに取り組むドコモビジネス](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/about-us/img/header-banner/banner-regional-effort.png)](https://www.nttdocomo.co.jp/business/lp/regional-effort.html)
        
    
*   [サービス・ソリューション・モバイル](https://www.nttdocomo.co.jp/biz/#)
    
    *   [サービス・ソリューション](https://www.nttdocomo.co.jp/business/services.html)
        
        IT/DXに関する課題を解決する  
        サービス・ソリューションをご紹介
        
        *   [カテゴリーで探す](https://www.nttdocomo.co.jp/business/services.html#category)
            
            [サービス・ソリューションTOP](https://www.nttdocomo.co.jp/business/services.html)
            
            ----------------------------------------------------------------------
            
            *   [ネットワーク・モバイル](https://www.nttdocomo.co.jp/business/services.html#lc03)
                
            *   [クラウド・データセンター](https://www.nttdocomo.co.jp/business/services.html#lc01)
                
            *   [電話・映像コミュニケーション](https://www.nttdocomo.co.jp/business/services.html#lc04)
                
            *   [セキュリティ](https://www.nttdocomo.co.jp/business/services.html#lc06)
                
            *   [5G](https://www.nttdocomo.co.jp/business/services.html#lc02)
                
            *   [IoT](https://www.nttdocomo.co.jp/business/services.html#lc07)
                
            *   [AI](https://www.nttdocomo.co.jp/business/services.html#lc08)
                
            *   [データ利活用](https://www.nttdocomo.co.jp/business/services.html#lc09)
                
            *   [運用管理](https://www.nttdocomo.co.jp/business/services.html#lc05)
                
            *   [業務支援・マーケティング](https://www.nttdocomo.co.jp/business/services.html#lc10)
                
            *   [災害対策・BCP](https://www.nttdocomo.co.jp/business/services.html#lc11)
                
            
        *   [課題・ニーズで探す](https://www.nttdocomo.co.jp/business/services.html#needs)
            
            [サービス・ソリューションTOP](https://www.nttdocomo.co.jp/business/services.html#category)
            
            -------------------------------------------------------------------------------
            
            *   [コミュニケーション・情報共有](https://www.nttdocomo.co.jp/business/services.html#ln01)
                
            *   [マーケティング](https://www.nttdocomo.co.jp/business/services.html#ln03)
                
            *   [業務効率化](https://www.nttdocomo.co.jp/business/services.html#ln05)
                
            *   [災害対策](https://www.nttdocomo.co.jp/business/services.html#ln07)
                
            *   [職場環境整備](https://www.nttdocomo.co.jp/business/services.html#ln09)
                
            *   [地域共創・地方創生](https://www.nttdocomo.co.jp/business/services.html#ln11)
                
            *   [セキュリティ対策](https://www.nttdocomo.co.jp/business/services.html#ln02)
                
            *   [遠隔監視](https://www.nttdocomo.co.jp/business/services.html#ln04)
                
            *   [顧客体験（CX）改善](https://www.nttdocomo.co.jp/business/services.html#ln06)
                
            *   [自動化・省電化](https://www.nttdocomo.co.jp/business/services.html#ln08)
                
            *   [人材不足解消](https://www.nttdocomo.co.jp/business/services.html#ln10)
                
            
        *   [業種・業態で探す](https://www.nttdocomo.co.jp/business/services.html#jobtype)
            
            [サービス・ソリューションTOP](https://www.nttdocomo.co.jp/business/services.html)
            
            ----------------------------------------------------------------------
            
            *   [自治体](https://www.nttdocomo.co.jp/business/services/type.html?t=lc12_mc91)
                
            *   [一次産業](https://www.nttdocomo.co.jp/business/services/type.html?t=lc12_mc94)
                
            *   [医療・介護](https://www.nttdocomo.co.jp/business/services/type.html?t=lc12_mc90)
                
            *   [観光](https://www.nttdocomo.co.jp/business/services/type.html?t=lc12_mc95)
                
            *   [教育](https://www.nttdocomo.co.jp/business/services/type.html?t=lc12_mc96)
                
            *   [モビリティ](https://www.nttdocomo.co.jp/business/services/type.html?t=lc12_mc93)
                
            *   [製造・建設業](https://www.nttdocomo.co.jp/business/services/type.html?t=lc12_mc92)
                
            *   [小売業](https://www.nttdocomo.co.jp/business/services/type.html?t=lc12_mc97)
                
            
        *   [キーワードで探す](https://www.nttdocomo.co.jp/business/services.html#keyword)
            
        
    *   [モバイル](https://www.nttdocomo.co.jp/business/mobile.html)
        
        法人向けスマホ・携帯に関する、  
        おすすめの機種、料金やサービスをご紹介
        
        *   [製品](https://www.nttdocomo.co.jp/business/mobile/product.html)
            
            [製品TOP](https://www.nttdocomo.co.jp/business/mobile/product.html)
            
            ------------------------------------------------------------------
            
            *   [ビジネス向けスマートフォン![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://www.onlineshop.docomobusiness.ntt.com/service/mobile/list/android-smartphone)
                
            *   [タフネススマートフォン![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://www.onlineshop.docomobusiness.ntt.com/service/mobile/product/ky51d)
                
            *   [データ通信製品![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://www.onlineshop.docomobusiness.ntt.com/service/mobile/list/data)
                
            *   [ドコモケータイ![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://www.onlineshop.docomobusiness.ntt.com/service/mobile/list/feature-phone)
                
            *   [5G対応ホームルーター](https://www.nttdocomo.co.jp/business/mobile/product/home_5G_router/)
                
            *   [通信モジュール製品](https://www.nttdocomo.co.jp/business/mobile/product/module/product.html)
                
            *   [衛星携帯電話](https://www.nttdocomo.co.jp/business/mobile/product/satellite.html)
                
            *   [IOT完了済みメーカーブランド製品](https://www.nttdocomo.co.jp/business/iot/product.html)
                
            
        *   [料金](https://www.nttdocomo.co.jp/business/mobile/charge.html)
            
            [料金TOP](https://www.nttdocomo.co.jp/business/mobile/charge.html)
            
            -----------------------------------------------------------------
            
            [ドコモBiz データ無制限　ドコモ MAX　ドコモ mini　ドコモBiz かけ放題](https://www.nttdocomo.co.jp/business/mobile/charge/new-plan.html)
            
            *   [ケータイプラン](https://www.nttdocomo.co.jp/business/mobile/charge/keitaiplan-2.html)
                
            *   [はじめてスマホプラン](https://www.nttdocomo.co.jp/business/mobile/charge/hajimete_plan.html)
                
            *   [5Gデータプラス](https://www.nttdocomo.co.jp/business/mobile/charge/5g-dataplus.html)
                
            *   [データプラス](https://www.nttdocomo.co.jp/business/mobile/charge/dataplus-2.html)
                
            *   [IoT向け回線料金](https://www.nttdocomo.co.jp/business/mobile/charge/module.html)
                
            *   [home5Gプラン](https://www.nttdocomo.co.jp/business/mobile/charge/home_5g.html)
                
            
        *   [モバイルサービス](javascript:void(0))
            
            *   [モバイルアクセス](https://www.nttdocomo.co.jp/business/services.html#lc03-mc30)
                
            *   [モバイルデバイス管理(MDM)](https://www.nttdocomo.co.jp/business/services.html#lc06-mc54)
                
            *   [音声・固定電話(FMC)](https://www.nttdocomo.co.jp/business/services.html#lc04-mc41)
                
            *   [オプション](https://www.nttdocomo.co.jp/business/services.html#lc03-mc98)
                
            
        *   [お手続き](https://support.ntt.com/purpose?subContentsType=2106&businessPersonalFlg=business)
            
        
    
    *   [![docomo business RINK](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/about-us/img/header-banner/banner-rink-v2.png)](https://www.nttdocomo.co.jp/business/services/rink.html)
        
    *   [![ドコモビジネスパッケージ](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/about-us/img/header-banner/banner-dbp.png)](https://www.nttdocomo.co.jp/business/services/dbp.html)
        
    *   [![法人専用のプラン「ドコモBiz」新登場](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/about-us/img/header-banner/ssb_dbw-lp-plan-kakehodai.jpg)](https://www.onlineshop.docomobusiness.ntt.com/service/mobile/lp-plan-kakehodai)
        
    *   [![サービスをご利用中のお客さま](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/about-us/img/header-banner/banner-support.svg)](https://support.ntt.com/)
        
    
*   [導入事例・セミナー](https://www.nttdocomo.co.jp/biz/#)
    
    *   [導入事例](https://www.nttdocomo.co.jp/business/case-studies.html)
        
        最新の導入事例や  
        注目の導入事例をご紹介します
        
    *   [セミナー](https://www.nttdocomo.co.jp/business/event.html)
        
        開催・出展する各種セミナー、  
        イベント情報をご紹介します
        
    
    *   [![オンデマンドセミナー　人気セミナーを好きな時に視聴可能！　docomo business Watch](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/about-us/img/header-banner/banner-seminar.png)](https://www.nttdocomo.co.jp/bizon/d/seminar_archives.html#on-demand)
        
    *    [![OPEN HUB│for Smart World　詳しくはこちら](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/about-us/img/header-banner/banner-open_hub.png) 別ウィンドウで開きます。](https://openhub.ntt.com/event/)
        
    
*   [中堅中小企業のお客さま](https://www.nttdocomo.co.jp/biz/#)
    
    *   [NTTドコモビジネスウォッチ  \
        ビジネスお役立ち情報](https://www.nttdocomo.co.jp/bizon.html)
        
        旬な話題やお役立ち資料などDXの課題を解決するヒントをお届けする記事サイト
        
        *   [新着記事](https://www.nttdocomo.co.jp/bizon/search.html)
            
        *   [お役立ち資料ダウンロード](https://www.nttdocomo.co.jp/bizon/white-paper.html)
            
        *   [トレンド記事特集](https://www.nttdocomo.co.jp/bizon/summary.html)
            
        *   [IT用語集](https://www.nttdocomo.co.jp/bizon/glossary.html)
            
        
    *   [中堅中小企業向け  \
        サービス・ソリューション](https://www.nttdocomo.co.jp/business/lp/smb.html)
        
        課題やニーズに合ったサービスをご紹介し、  
        中堅中小企業のビジネスをサポート！
        
        *   [お悩みから見つける](https://www.nttdocomo.co.jp/business/lp/smb/services/problem.html)
            
            [中堅中小企業向けサイトTOP](https://www.nttdocomo.co.jp/business/lp/smb.html)
            
            -------------------------------------------------------------------
            
            *   [ネットワーク](https://www.nttdocomo.co.jp/business/lp/smb/services/problem/network.html)
                
            *   [モバイル・音声](https://www.nttdocomo.co.jp/business/lp/smb/services/problem/mobile-voice.html)
                
            *   [バックオフィス](https://www.nttdocomo.co.jp/business/lp/smb/services/problem/back-office.html)
                
            
            *   [リモート・ハイブリッドワーク](https://www.nttdocomo.co.jp/business/lp/smb/services/problem/remote-hybridwork.html)
                
            *   [セキュリティ](https://www.nttdocomo.co.jp/business/lp/smb/services/problem/security.html)
                
            *   [その他のお悩みはこちら](https://www.nttdocomo.co.jp/business/lp/smb/services/problem.html)
                
            
        *   [業界から見つける](https://www.nttdocomo.co.jp/business/lp/smb/services/industry.html)
            
            [中堅中小企業向けサイトTOP](https://www.nttdocomo.co.jp/business/lp/smb.html)
            
            -------------------------------------------------------------------
            
            *   [製造業](https://www.nttdocomo.co.jp/business/lp/smb/services/industry/manufacturing.html)
                
            *   [小売・卸売業](https://www.nttdocomo.co.jp/business/lp/smb/services/industry/retailer.html)
                
            *   [運輸業](https://www.nttdocomo.co.jp/business/lp/smb/services/industry/carrier.html)
                
            
            *   [建設業](https://www.nttdocomo.co.jp/business/lp/smb/services/industry/construction.html)
                
            *   [地域産業](https://www.nttdocomo.co.jp/business/lp/smb/regional-effort.html)
                
            *   [その他の業界はこちら](https://www.nttdocomo.co.jp/business/lp/smb/services/industry.html)
                
            
        *   [ゲーム感覚で見つける](https://www.nttdocomo.co.jp/business/lp/smb/services/dx-roadmap.html)
            
        *   [ビジネスお悩み診断](https://www.nttdocomo.co.jp/business/lp/smb/shindan.html)
            
        
    *   [NTTドコモビジネス  \
        オンラインショップ ![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://www.onlineshop.docomobusiness.ntt.com/)
         
        
        モバイル・ICTサービスをオンラインで  
        相談・申し込みができるバーチャルショップ
        
        *   [法人向けモバイルトップ ![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://www.onlineshop.docomobusiness.ntt.com/service/mobile)
             
        *   [はじめての方へ ![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://www.onlineshop.docomobusiness.ntt.com/about-us)
             
        *   [サービス・商品を探す ![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://www.onlineshop.docomobusiness.ntt.com/service)
             
        *   [新規会員登録/ログインはこちら ![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://www.onlineshop.docomobusiness.ntt.com/login)
             
        *   [10回線以上のお問い合わせ・お見積りはこちら ![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://www.onlineshop.docomobusiness.ntt.com/mobile-application-largeorder)
             
        
    
    *   [![NTT docomo business Watch](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/about-us/img/header-banner/banner-smb-dbw_v2.png)](https://www.nttdocomo.co.jp/bizon.html)
        
    *   [![中小企業のビジネスサポート](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/about-us/img/header-banner/banner-smb-smb.png)](https://www.nttdocomo.co.jp/business/lp/smb.html?utm_source=other&utm_medium=email&utm_campaign=lp_smb_smbusiness_glonavi-smbtab_smdm_other)
        
    *   [![NTT docomo business オンラインショップ](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/about-us/img/header-banner/banner-smb-dbols_v2.png)](https://www.onlineshop.docomobusiness.ntt.com/)
        
    *   [![2025年10月14日(火)Windows10サポート終了 診断する](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/about-us/img/header-banner/banner-pc-update_v3.png)](https://www.nttdocomo.co.jp/business/lp/smb/shindan/pc_update.html?utm_source=other&utm_medium=other_own&utm_campaign=lp_smb_2024sh-measure_glonavi-smbtab-pcshindan-banner_smdm_other)
        
    
*   [企業情報](https://www.nttdocomo.co.jp/biz/#)
    
    *   [企業情報](https://www.nttdocomo.co.jp/about-us.html)
        
        *   [会社案内](https://www.nttdocomo.co.jp/about-us/company-profile.html)
            
            [会社案内TOP](https://www.nttdocomo.co.jp/about-us/company-profile.html)
            
            ---------------------------------------------------------------------
            
            *   [組織](https://www.nttdocomo.co.jp/about-us/company-profile/organization.html)
                
            *   [沿革](https://www.nttdocomo.co.jp/about-us/company-profile/keyfacts.html)
                
            *   [社長からのご挨拶](https://www.nttdocomo.co.jp/about-us/company-profile/ceo.html)
                
            *   [事業拠点](https://www.nttdocomo.co.jp/about-us/company-profile/japan.html)
                
            *   [グループ会社](https://www.nttdocomo.co.jp/about-us/company-profile/group-companies.html)
                
            *   [会社案内パンフレット](https://www.nttdocomo.co.jp/about-us/company-profile.html)
                
            
        *   [ニュースルーム](https://www.nttdocomo.co.jp/about-us/newsroom.html)
            
            [ニュースルームTOP](https://www.nttdocomo.co.jp/about-us/newsroom.html)
            
            -----------------------------------------------------------------
            
            *   [ニュースリリース](https://www.nttdocomo.co.jp/about-us/press-releases.html)
                
            *   [地域からの発表](https://www.nttdocomo.co.jp/about-us/area-info.html)
                
            *   [重要なお知らせ](https://www.nttdocomo.co.jp/about-us/important-info.html)
                
            *   [お知らせ](https://www.nttdocomo.co.jp/about-us/information.html)
                
            *   [社外からの評価実績](https://www.nttdocomo.co.jp/about-us/we-are-a-leader.html)
                
            
        *   [サステナビリティ](https://www.nttdocomo.co.jp/about-us/csr.html)
            
            [サステナビリティTOP](https://www.nttdocomo.co.jp/about-us/csr.html)
            
            -------------------------------------------------------------
            
            *   [NTTドコモビジネスグループのサステナビリティ](https://www.nttdocomo.co.jp/about-us/csr/sustainability.html)
                
            *   [サステナビリティ基本方針](https://www.nttdocomo.co.jp/about-us/csr/sustainability/policy.html)
                
            *   [サステナビリティレポート](https://www.nttdocomo.co.jp/about-us/csr/pdf/download.html)
                
            *   [ダイバーシティ](https://www.nttdocomo.co.jp/about-us/we-are-innovative/diversity.html)
                
            
        *   [経営情報](https://www.nttdocomo.co.jp/about-us/company-profile/finance.html)
            
            [経営情報TOP](https://www.nttdocomo.co.jp/about-us/company-profile/finance.html)
            
            -----------------------------------------------------------------------------
            
            *   [業績](https://www.nttdocomo.co.jp/about-us/company-profile/finance/financial.html)
                
            *   [決算公告](https://www.nttdocomo.co.jp/about-us/company-profile/finance/kessankoukoku.html)
                
            *   [電子公告](https://www.nttdocomo.co.jp/about-us/company-profile/finance/denshikoukoku.html)
                
            *   [基礎的電気通信役務損益明細表](https://www.nttdocomo.co.jp/about-us/company-profile/finance/sonekimeisaihyou.html)
                
            
        *   [採用情報](https://www.nttdocomo.co.jp/about-us/recruit/)
            
            [採用情報TOP](https://www.nttdocomo.co.jp/about-us/recruit/)
            
            ---------------------------------------------------------
            
            *   [新卒採用 ![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://information.nttdocomo-fresh.jp/)
                 
            *   [経験者採用](https://www.nttdocomo.co.jp/about-us/recruit/scout/)
                
            *   [障がい者採用](https://www.nttdocomo.co.jp/about-us/recruit/pwd.html)
                
            *   [人材育成制度](https://www.nttdocomo.co.jp/about-us/training.html)
                
            
        *   [NTTドコモグループ ![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://nttdocomo-group.com/index.html)
             
        
    
    *   [![shines](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/about-us/img/header-banner/banner-shines.png)](https://www.nttdocomo.co.jp/shines/index.html)
        
    *   [![NTTドコモビジネスのエバンジェリスト](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/about-us/img/header-banner/banner-evangelist.jpg)](https://www.nttdocomo.co.jp/about-us/we-are-innovative/evangelist.html)
        
    *   [![カスタマーエクスペリエンス](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/about-us/img/header-banner/banner-docomobusiness-cx.png)](https://www.nttdocomo.co.jp/about-us/cs/docomobusiness-cx.html)
        
    

*   産業・地域DX/事業共創
    
    [OPEN HUB\
    \
    新規ビジネスの創出や社会実装を  \
    目指す事業共創の場です](javascript:void(0))
    
    [OPEN HUB TOP ![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://openhub.ntt.com/)
     
    -----------------------------------------------------------------------------------------------------------------------------------------
    
    *   [OPEN HUB for Smart Worldとは ![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://openhub.ntt.com/about/)
         
    *   [イベント/ウェビナー ![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://openhub.ntt.com/event/)
         
    *   [記事コンテンツ ![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://openhub.ntt.com/journal/)
         
    *   [プレイヤー(カタリスト/パートナー企業) ![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://openhub.ntt.com/player/)
         
    *   [事例 ![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://openhub.ntt.com/project/)
         
    
    [Smart World\
    \
    産業・地域DXプラットフォーマーとして  \
    企業と地域が持続成長する社会を目指します](javascript:void(0))
    
    [Smart World TOP](https://www.nttdocomo.co.jp/business/dx/smart.html)
    
    ----------------------------------------------------------------------
    
    *   [Smart City](https://www.nttdocomo.co.jp/business/dx/smart/city.html)
        
    *   [Smart Education](https://www.nttdocomo.co.jp/business/dx/smart/education.html)
        
    *   [Smart Healthcare](https://www.nttdocomo.co.jp/business/dx/smart/healthcare.html)
        
    *   [Smart Industry](https://www.nttdocomo.co.jp/business/dx/smart/industry.html)
        
    *   [Smart Mobility](https://www.nttdocomo.co.jp/business/dx/smart/mobility.html)
        
    *   [Smart Worksite](https://www.nttdocomo.co.jp/business/dx/smart/worksite.html)
        
    *   [生成AI(Generative AI)](https://www.nttdocomo.co.jp/business/dx/smart/generative-ai.html)
        
    
    [地域の取り組み\
    \
    地域社会を支える皆さまと地域課題の解決や  \
    地域経済のさらなる活性化に取り組みます](javascript:void(0))
    
    [地域の取り組み](https://www.nttdocomo.co.jp/business/lp/regional-effort.html)
    
    ------------------------------------------------------------------------
    
    *   [自治体・地域社会との共創](https://www.nttdocomo.co.jp/business/lp/regional-effort/local-goverments.html)
        
    *   [LGPF（Local Government Platform）](https://www.nttdocomo.co.jp/business/lp/regional-effort/lgpf.html)
        
    
    *    [![OPEN HUB│for Smart World　詳しくはこちら](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/about-us/img/header-banner/banner-open_hub.png) 別ウィンドウで開きます。](https://openhub.ntt.com/)
        
    *   [![地域とともに取り組むドコモビジネス](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/about-us/img/header-banner/banner-regional-effort.png)](https://www.nttdocomo.co.jp/business/lp/regional-effort.html)
        
    
*   サービス・ソリューション・モバイル
    
    *   [サービス・ソリューション\
        \
        IT/DXに関する課題を解決する  \
        サービス・ソリューションをご紹介](javascript:void(0))
        
        [サービス・ソリューション TOP](https://www.nttdocomo.co.jp/business/services.html)
        
        -----------------------------------------------------------------------
        
        *   [カテゴリーで探す](javascript:void(0))
            
            *   [ネットワーク・モバイル](https://www.nttdocomo.co.jp/business/services.html#lc03)
                
            *   [クラウド・データセンター](https://www.nttdocomo.co.jp/business/services.html#lc01)
                
            *   [電話・映像コミュニケーション](https://www.nttdocomo.co.jp/business/services.html#lc04)
                
            *   [セキュリティ](https://www.nttdocomo.co.jp/business/services.html#lc06)
                
            *   [5G](https://www.nttdocomo.co.jp/business/services.html#lc02)
                
            *   [IoT](https://www.nttdocomo.co.jp/business/services.html#lc07)
                
            *   [AI](https://www.nttdocomo.co.jp/business/services.html#lc08)
                
            *   [データ利活用](https://www.nttdocomo.co.jp/business/services.html#lc09)
                
            *   [運用管理](https://www.nttdocomo.co.jp/business/services.html#lc05)
                
            *   [業務支援・マーケティング](https://www.nttdocomo.co.jp/business/services.html#lc10)
                
            *   [災害対策・BCP](https://www.nttdocomo.co.jp/business/services.html#lc11)
                
            
        *   [課題・ニーズで探す](javascript:void(0))
            
            *   [コミュニケーション・情報共有](https://www.nttdocomo.co.jp/business/services.html#ln01)
                
            *   [マーケティング](https://www.nttdocomo.co.jp/business/services.html#ln03)
                
            *   [業務効率化](https://www.nttdocomo.co.jp/business/services.html#ln05)
                
            *   [災害対策](https://www.nttdocomo.co.jp/business/services.html#ln05)
                
            *   [職場環境整備](https://www.nttdocomo.co.jp/business/services.html#ln09)
                
            *   [地域共創・地方創生](https://www.nttdocomo.co.jp/business/services.html#ln11)
                
            *   [セキュリティ対策](https://www.nttdocomo.co.jp/business/services.html#ln02)
                
            *   [遠隔監視](https://www.nttdocomo.co.jp/business/services.html#ln04)
                
            *   [顧客体験（CX）改善](https://www.nttdocomo.co.jp/business/services.html#ln06)
                
            *   [自動化・省電化](https://www.nttdocomo.co.jp/business/services.html#ln08)
                
            *   [人材不足解消](https://www.nttdocomo.co.jp/business/services.html#ln10)
                
            
        *   [業種・業態で探す](javascript:void(0))
            
            *   [自治体](https://www.nttdocomo.co.jp/business/services/type.html?t=lc12_mc91)
                
            *   [一次産業](https://www.nttdocomo.co.jp/business/services/type.html?t=lc12_mc94)
                
            *   [医療・介護](https://www.nttdocomo.co.jp/business/services/type.html?t=lc12_mc90)
                
            *   [観光](https://www.nttdocomo.co.jp/business/services/type.html?t=lc12_mc95)
                
            *   [教育](https://www.nttdocomo.co.jp/business/services/type.html?t=lc12_mc96)
                
            *   [モビリティ](https://www.nttdocomo.co.jp/business/services/type.html?t=lc12_mc93)
                
            *   [製造・建設業](https://www.nttdocomo.co.jp/business/services/type.html?t=lc12_mc92)
                
            *   [小売業](https://www.nttdocomo.co.jp/business/services/type.html?t=lc12_mc97)
                
            
        *   [キーワードで探す](https://www.nttdocomo.co.jp/business/services.html#keyword)
            
        
    *   [モバイル\
        \
        法人向けスマホ・携帯に関する、  \
        おすすめの機種、料金やサービスをご紹介](javascript:void(0))
        
        [モバイル TOP](https://www.nttdocomo.co.jp/business/mobile.html)
        
        -------------------------------------------------------------
        
        *   [製品](javascript:void(0))
            
            *   [製品TOP](https://www.nttdocomo.co.jp/business/mobile/product.html)
                
            *   [ビジネス向けスマートフォン ![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://www.onlineshop.docomobusiness.ntt.com/service/mobile/list/android-smartphone)
                 
            *   [タフネススマートフォン ![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://www.onlineshop.docomobusiness.ntt.com/service/mobile/product/ky51d)
                 
            *   [データ通信製品 ![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://www.onlineshop.docomobusiness.ntt.com/service/mobile/list/data)
                 
            *   [ドコモケータイ ![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://www.onlineshop.docomobusiness.ntt.com/service/mobile/list/feature-phone)
                 
            *   [5G対応ホームルーター](https://www.nttdocomo.co.jp/business/mobile/product/home_5G_router/)
                
            *   [通信モジュール製品](https://www.nttdocomo.co.jp/business/mobile/product/module/product.html)
                
            *   [衛星携帯電話](https://www.nttdocomo.co.jp/business/mobile/product/satellite.html)
                
            *   [IOT完了済みメーカーブランド製品](https://www.nttdocomo.co.jp/business/iot/product.html)
                
            
        *   [料金](javascript:void(0))
            
            *   [料金TOP](https://www.nttdocomo.co.jp/business/mobile/charge.html)
                
            *   [ドコモBiz データ無制限　ドコモ MAX　ドコモ mini　ドコモBiz かけ放題](https://www.nttdocomo.co.jp/business/mobile/charge/new-plan.html)
                
            *   [ケータイプラン](https://www.nttdocomo.co.jp/business/mobile/charge/keitaiplan-2.html)
                
            *   [はじめてスマホプラン](https://www.nttdocomo.co.jp/business/mobile/charge/hajimete_plan.html)
                
            *   [5Gデータプラス](https://www.nttdocomo.co.jp/business/mobile/charge/5g-dataplus.html)
                
            *   [データプラス](https://www.nttdocomo.co.jp/business/mobile/charge/dataplus-2.html)
                
            *   [IoT向け回線料金](https://www.nttdocomo.co.jp/business/mobile/charge/module.html)
                
            *   [home5Gプラン](https://www.nttdocomo.co.jp/business/mobile/charge/home_5g.html)
                
            
        *   [モバイルサービス](javascript:void(0))
            
            *   [モバイルアクセス](https://www.nttdocomo.co.jp/business/services.html#lc03-mc30)
                
            *   [モバイルデバイス管理(MDM)](https://www.nttdocomo.co.jp/business/services.html#lc06-mc54)
                
            *   [音声・固定電話(FMC)](https://www.nttdocomo.co.jp/business/services.html#lc04-mc41)
                
            *   [オプション](https://www.nttdocomo.co.jp/business/services.html#lc03-mc98)
                
            
        *   [お手続き](https://support.ntt.com/purpose?subContentsType=2106&businessPersonalFlg=business)
            
        
    
    *   [![docomo business RINK](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/about-us/img/header-banner/banner-rink-v2.png)](https://www.nttdocomo.co.jp/business/services/rink.html)
        
    *   [![ドコモビジネスパッケージ](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/about-us/img/header-banner/banner-dbp.png)](https://www.nttdocomo.co.jp/business/services/dbp.html)
        
    *   [![法人専用のプラン「ドコモBiz」新登場](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/about-us/img/header-banner/ssb_dbw-lp-plan-kakehodai.jpg)](https://www.onlineshop.docomobusiness.ntt.com/service/mobile/lp-plan-kakehodai)
        
    *   [![サービスをご利用中のお客さま](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/about-us/img/header-banner/banner-support.svg)](https://support.ntt.com/)
        
    
*   導入事例・セミナー
    
    *   [導入事例\
        \
        最新の導入事例や注目の導入事例を  \
        ご紹介します](https://www.nttdocomo.co.jp/business/case-studies.html)
        
    *   [セミナー\
        \
        開催・出展する各種セミナー、イベント情報を  \
        ご紹介します](https://www.nttdocomo.co.jp/business/event.html)
        
    *   *   [![オンデマンドセミナー　人気セミナーを好きな時に視聴可能！　docomo business Watch](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/about-us/img/header-banner/banner-seminar.png)](https://www.nttdocomo.co.jp/bizon/d/seminar_archives.html#on-demand)
            
        *    [![OPEN HUB│for Smart World　詳しくはこちら](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/about-us/img/header-banner/banner-open_hub.png) 別ウィンドウで開きます。](https://openhub.ntt.com/event/)
            
    
*   中堅中小企業のお客さま
    
    *   [NTTドコモビジネスウォッチ ビジネスお役立ち情報\
        \
        旬な話題やお役立ち資料などDXの課題を  \
        解決するヒントをお届けする記事サイト](javascript:void(0))
        
        [NTTドコモビジネスウォッチTOP](https://www.nttdocomo.co.jp/bizon.html)
        
        ------------------------------------------------------------
        
        *   [新着記事](https://www.nttdocomo.co.jp/bizon/search.html)
            
        *   [お役立ち資料ダウンロード](https://www.nttdocomo.co.jp/bizon/white-paper.html)
            
        *   [トレンド記事特集](https://www.nttdocomo.co.jp/bizon/summary.html)
            
        *   [IT用語集](https://www.nttdocomo.co.jp/bizon/glossary.html)
            
        
    *   [中堅中小企業向けサービス・ソリューション\
        \
        課題やニーズに合ったサービスをご紹介し、  \
        中堅中小企業のビジネスをサポート！](javascript:void(0))
        
        [中堅中小企業向けサービス・ソリューションTOP](https://www.nttdocomo.co.jp/business/lp/smb.html)
        
        ----------------------------------------------------------------------------
        
        *   [お悩みから見つける](javascript:void(0))
            
            *   [ネットワーク](https://www.nttdocomo.co.jp/business/lp/smb/services/problem/network.html)
                
            *   [リモート・ハイブリッドワーク](https://www.nttdocomo.co.jp/business/lp/smb/services/problem/remote-hybridwork.html)
                
            *   [モバイル・音声](https://www.nttdocomo.co.jp/business/lp/smb/services/problem/mobile-voice.html)
                
            *   [セキュリティ](https://www.nttdocomo.co.jp/business/lp/smb/services/problem/security.html)
                
            *   [バックオフィス](https://www.nttdocomo.co.jp/business/lp/smb/services/problem/back-office.html)
                
            *   [その他のお悩みはこちら](https://www.nttdocomo.co.jp/business/lp/smb/services/problem.html)
                
            
        *   [業界から見つける](javascript:void(0))
            
            *   [製造業](https://www.nttdocomo.co.jp/business/lp/smb/services/industry/manufacturing.html)
                
            *   [建設業](https://www.nttdocomo.co.jp/business/lp/smb/services/industry/construction.html)
                
            *   [小売・卸売業](https://www.nttdocomo.co.jp/business/lp/smb/services/industry/retailer.html)
                
            *   [地域産業](https://www.nttdocomo.co.jp/business/lp/smb/regional-effort.html)
                
            *   [運輸業](https://www.nttdocomo.co.jp/business/lp/smb/services/industry/carrier.html)
                
            *   [その他の業界はこちら](https://www.nttdocomo.co.jp/business/lp/smb/services/industry.html)
                
            
        *   [ゲーム感覚で見つける](https://www.nttdocomo.co.jp/business/lp/smb/services/dx-roadmap.html)
            
        *   [ビジネスお悩み診断](https://www.nttdocomo.co.jp/business/lp/smb/shindan.html)
            
        
    *   [NTTドコモビジネスオンラインショップ\
        \
        モバイル・ICTサービスをオンラインで  \
        相談・申し込みができるバーチャルショップ](javascript:void(0))
        
        [NTTドコモビジネスオンラインショップ ![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://www.onlineshop.docomobusiness.ntt.com/)
         
        ----------------------------------------------------------------------------------------------------------------------------------------------------------------------
        
        *   [法人向けモバイルトップ ![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://www.onlineshop.docomobusiness.ntt.com/service/mobile)
             
        *   [サービス・商品を探す ![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://www.onlineshop.docomobusiness.ntt.com/service/mobile)
             
        *   [はじめての方へ ![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://www.onlineshop.docomobusiness.ntt.com/about-us)
             
        *   [新規会員登録/ログインはこちら ![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://www.onlineshop.docomobusiness.ntt.com/login)
             
        *   [10回線以上のお問い合わせ・お見積りはこちら ![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://www.onlineshop.docomobusiness.ntt.com/mobile-application-largeorder)
             
        
    
    *   [![docomo business Watch](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/about-us/img/header-banner/banner-smb-dbw.png)](https://www.nttdocomo.co.jp/bizon.html)
        
    *   [![中小企業のビジネスサポート](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/about-us/img/header-banner/banner-smb-smb.png)](https://www.nttdocomo.co.jp/business/lp/smb.html?utm_source=other&utm_medium=email&utm_campaign=lp_smb_smbusiness_glonavi-smbtab_smdm_other)
        
    *    [![docomo business オンラインショップ](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/about-us/img/header-banner/banner-smb-dbols.png) 別ウィンドウで開きます。](https://www.onlineshop.docomobusiness.ntt.com/)
        
    *    [![2025年10月14日(火)Windows10サポート終了 診断する](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/about-us/img/header-banner/banner-pc-update_v3.png) 別ウィンドウで開きます。](https://www.nttdocomo.co.jp/business/lp/smb/shindan/pc_update.html?utm_source=other&utm_medium=other_own&utm_campaign=lp_smb_2024sh-measure_glonavi-smbtab-pcshindan-banner_smdm_other)
        
    
*   企業情報
    
    *   [企業情報TOP](https://www.nttdocomo.co.jp/about-us.html)
        
    *   [会社案内](javascript:void(0))
        
        [会社案内TOP](https://www.nttdocomo.co.jp/about-us/company-profile.html)
        
        ---------------------------------------------------------------------
        
        *   [組織](https://www.nttdocomo.co.jp/about-us/company-profile/organization.html)
            
        *   [沿革](https://www.nttdocomo.co.jp/about-us/company-profile/keyfacts.html)
            
        *   [社長からのご挨拶](https://www.nttdocomo.co.jp/about-us/company-profile/ceo.html)
            
        *   [事業拠点](https://www.nttdocomo.co.jp/about-us/company-profile/japan.html)
            
        *   [グループ会社](https://www.nttdocomo.co.jp/about-us/company-profile/group-companies.html)
            
        *   [会社案内パンフレット](https://www.nttdocomo.co.jp/about-us/company-profile.html)
            
        
    *   [ニュースルーム](javascript:void(0))
        
        [ニュースルームTOP](https://www.nttdocomo.co.jp/about-us/newsroom.html)
        
        -----------------------------------------------------------------
        
        *   [ニュースリリース](https://www.nttdocomo.co.jp/about-us/press-releases.html)
            
        *   [地域からの発表](https://www.nttdocomo.co.jp/about-us/area-info.html)
            
        *   [重要なお知らせ](https://www.nttdocomo.co.jp/about-us/important-info.html)
            
        *   [お知らせ](https://www.nttdocomo.co.jp/about-us/information.html)
            
        *   [社外からの評価実績](https://www.nttdocomo.co.jp/about-us/we-are-a-leader.html)
            
        
    *   [サステナビリティ](javascript:void(0))
        
        [サステナビリティTOP](https://www.nttdocomo.co.jp/about-us/csr/sustainability.html)
        
        ----------------------------------------------------------------------------
        
        *   [NTTドコモビジネスグループのサステナビリティ](https://www.nttdocomo.co.jp/about-us/csr/sustainability/about.html)
            
        *   [サステナビリティ基本方針](https://www.nttdocomo.co.jp/about-us/csr/sustainability/policy.html)
            
        *   [サステナビリティレポート](https://www.nttdocomo.co.jp/about-us/csr/pdf/download.html)
            
        *   [ダイバーシティ](https://www.nttdocomo.co.jp/about-us/we-are-innovative/diversity.html)
            
        
    *   [経営情報](javascript:void(0))
        
        [経営情報TOP](https://www.nttdocomo.co.jp/about-us/company-profile/finance.html)
        
        -----------------------------------------------------------------------------
        
        *   [業績](https://www.nttdocomo.co.jp/about-us/company-profile/finance/financial.html)
            
        *   [決算公告](https://www.nttdocomo.co.jp/about-us/company-profile/finance/kessankoukoku.html)
            
        *   [電子公告](https://www.nttdocomo.co.jp/about-us/company-profile/finance/denshikoukoku.html)
            
        *   [基礎的電気通信役務損益明細表](https://www.nttdocomo.co.jp/about-us/company-profile/finance/sonekimeisaihyou.html)
            
        
    *   [採用情報](javascript:void(0))
        
        [採用情報TOP](https://www.nttdocomo.co.jp/about-us/recruit/)
        
        ---------------------------------------------------------
        
        *   [新卒採用 ![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://information.nttdocomo-fresh.jp/)
             
        *   [経験者採用](https://www.nttdocomo.co.jp/about-us/recruit/scout/)
            
        *   [障がい者採用](https://www.nttdocomo.co.jp/about-us/recruit/pwd.html)
            
        *   [人材育成制度](https://www.nttdocomo.co.jp/about-us/training.html)
            
        
    *   [NTTドコモグループ\
        \
        ![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://nttdocomo-group.com/index.html)
        
    
    *   [![Shiens](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/about-us/img/header-banner/banner-shines.png)](https://www.nttdocomo.co.jp/shines/index.html)
        
    *   [![NTTドコモビジネスのエバンジェリスト](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/about-us/img/header-banner/banner-evangelist.jpg)](https://www.nttdocomo.co.jp/about-us/we-are-innovative/evangelist.html)
        
    *   [![カスタマーエクスペリエンス](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/about-us/img/header-banner/banner-docomobusiness-cx.png)](https://www.nttdocomo.co.jp/about-us/cs/docomobusiness-cx.html)
        
    

*   [![ビジネスdアカウントログイン](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/business/lp/img/btn_login_businesspoint.png)](https://www.nttdocomo.co.jp/docomo-id-biz/auth-login.html?orgurl=%2Findex.html)
    
*   [![ビジネスdアカウントログアウト](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/business/lp/img/btn_logout__businesspoint.png)](https://www.nttdocomo.co.jp/docomo-id-biz/auth-logout.html?orgurl=%2Findex.html)
    
*   [![ビジネスdアカウントログイン](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/business/lp/img/btn_login_businesspoint.png)](https://www.nttdocomo.co.jp/docomo-id-biz/auth-login.html?orgurl=%2Findex.html)
    
*   [![ビジネスdアカウントログアウト](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/business/lp/img/btn_logout__businesspoint.png)](https://www.nttdocomo.co.jp/docomo-id-biz/auth-logout.html?orgurl=%2Findex.html)
    
*   [オンラインショップ](https://www.onlineshop.docomobusiness.ntt.com/)
    

*   ご契約中のお客さま
    
    [サポートサイト\
    \
    サービス別サポート情報](https://support.ntt.com/)
    
    [NTTドコモビジネス ビジネスポータル\
    \
    ご契約中サービスの一元管理\
    \
    ![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://b-portal.ntt.com/login/)
    
    [ビリングステーション\
    \
    NTTドコモビジネス Web明細\
    \
    ![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://www.billingstation.ntt.com/user/UA01W001)
    
    [ご利用料金管理サービス\
    \
    NTTドコモ(携帯回線)料金分析\
    \
    ![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://gorikan.billing.smt.docomo.ne.jp/bbilling/srv/ghadp001.srv?_ebx=swv0q1a1be.1708318872.811fu7s)
    
    [My docomo\
    \
    NTTドコモ(携帯回線)Web明細\
    \
    ![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://www.docomo.ne.jp/mydocomo/)
    
*   工事・故障情報
    
    [お客さまサポートサイト](https://support.ntt.com/)
    
    [SDPFナレッジセンター![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://sdpf.ntt.com/service-status/details/)
    
    [NTTドコモ 通信障害情報![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://www.docomo.ne.jp/info/network/)
    
*   個人のお客さま
    
    *   [個人のお客さま（NTTドコモ）![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://www.docomo.ne.jp/)
        
    *   [個人のお客さま（OCNなど）![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://service.ocn.ne.jp/)
        
    

重要なお知らせ
-------

CLOSE [一覧へ](https://www.nttdocomo.co.jp/about-us/important-info.html)

現在、重要なお知らせはありません。

*   工事・故障情報
*   [お客さまサポートサイト](https://support.ntt.com/)
    
*   [SDPFナレッジセンター](https://sdpf.ntt.com/service-status/details/)
    
*   [NTTドコモ 通信障害情報](https://www.docomo.ne.jp/info/network/)
    

スライダーコンテンツ
----------

*    [![人を想うDX](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/pr_area/bnr_top_nttdocomobusiness-lp-20251029_pc.png) ![人を想うDX](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/pr_area/bnr_top_nttdocomobusiness-lp-20251029_sp.png)](https://www.nttdocomo.co.jp/business/lp/nttdocomobusiness/)
    
*    [![NTT docomo Business Forum'25 講演動画アーカイブ](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/pr_area/bnr_top_go-event-2025-archive_pc.jpg) ![NTT docomo Business Forum'25 講演動画アーカイブ](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/pr_area/bnr_top_go-event-2025-archive_sp.jpg)](https://www.nttdocomo.co.jp/business/go-event.html?ir=os)
    
*    [![NTTコミュニケーションズはNTTドコモビジネスへ。](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/pr_area/bnr_top_nttdocomobusiness-lp_pc.png) ![NTTコミュニケーションズはNTTドコモビジネスへ。](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/pr_area/bnr_top_nttdocomobusiness-lp_sp.png)](https://www.nttdocomo.co.jp/about-us/nttdocomobusiness.html)
    
*    [![未来をひらく「コンセプトと社会実装」の実験場　OPEN HUB fot Smart World 別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/pr_area/bnr_top_pc_openhub_2.png) ![未来をひらく「コンセプトと社会実装」の実験場　OPEN HUB fot Smart World 別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/pr_area/bnr_top_sp_openhub_2.png)](https://openhub.ntt.com/)
    
*    [![AIインフラソリューション AIインフラでつくる未来のビジネス](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/pr_area/bnr_top_lp-aiinfra_pc.png) ![AIインフラソリューション AIインフラでつくる未来のビジネス](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/pr_area/bnr_top_lp-aiinfra_sp.png)](https://www.nttdocomo.co.jp/business/lp/aiinfra.html)
    
*    [![中小企業のビジネスをサポート　お客さまのビジネスのDX化をサポートし業務効率化、コスト削減を実現します。](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/pr_area/bnr_top_pc_smb-20230901.jpg) ![中小企業のビジネスをサポート　お客さまのビジネスのDX化をサポートし業務効率化、コスト削減を実現します。](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/pr_area/bnr_top_sp_smb-20230901.jpg)](https://www.nttdocomo.co.jp/business/lp/smb.html)
    
*    [![NTTコミュニケーションズの総合セキュリティサイト　多様化するニーズに応え、最適なソリューションを提供。](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/pr_area/pr_security-site_b_pc.jpg) ![NTTコミュニケーションズの総合セキュリティサイト　多様化するニーズに応え、最適なソリューションを提供。](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/pr_area/pr_security-site_b_sp.jpg)](https://www.nttdocomo.co.jp/business/services/security-site.html)
    
*    [![ドコモビジネスパッケージ　中小企業のお客さま向けのソリューションパッケージ](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/pr_area/bnr_top_dbp_01_pc.png) ![ドコモビジネスパッケージ　中小企業のお客さま向けのソリューションパッケージ](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/pr_area/bnr_top_dbp_01_sp.png)](https://www.nttdocomo.co.jp/business/services/dbp.html)
    
*    [![地域とともにとりくむドコモビジネス](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/pr_area/bnr_top_lp-regional-effort_pc.png) ![地域とともにとりくむドコモビジネス](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/pr_area/bnr_top_lp-regional-effort_sp.png)](https://www.nttdocomo.co.jp/business/lp/regional-effort.html)
    
*    [![オンラインでご相談からお申し込みまで　スマホの「お困りごと」はドコモビジネスオンラインショップでまるごとご相談！　ドコモビジネスオンラインショップ　別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/pr_area/bnr_top_pc_dbos.jpg) ![オンラインでご相談からお申し込みまで　スマホの「お困りごと」はドコモビジネスオンラインショップでまるごとご相談！　ドコモビジネスオンラインショップ　別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/pr_area/bnr_top_sp_dbos.jpg)](https://onlineshop.docomobusiness.ntt.com/)
    

![左へ](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/slider-control-back.svg)

![右へ](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/slider-control-next.svg)

 ![再生](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/slider-control-play.svg)![一時停止](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/slider-control-pause.svg)

NTTドコモビジネスの  
取り組み
------------------

*    [![GX](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/docomobusiness/card_img_gx.jpg) GX\
    \
    脱炭素へともに挑み、地域と企業の持続可能な成長を支援](https://www.nttdocomo.co.jp/business/lp/nttdocomobusiness/green-transformation.html)
    
*    [![AI](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/docomobusiness/card_img_ai.jpg) AI\
    \
    お客さまに合わせたAI技術のソリューションを提供](https://www.nttdocomo.co.jp/business/lp/nttdocomobusiness/ai.html)
    
*    [![IoT](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/docomobusiness/card_img_iot.jpg) IoT\
    \
    つなぐ力でお客さまのビジネスの可能性を広げる](https://www.nttdocomo.co.jp/business/lp/iot.html)
    
*    [![デジタルBPO](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/docomobusiness/card_img_bpo.jpg) デジタルBPO®\
    \
    DXでお客さま業務のプロセス効率化とアウトソーシングを実現](https://www.nttdocomo.co.jp/business/lp/nttdocomobusiness/digital-bpo.html)
    
*    [![中小企業DX](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/docomobusiness/card_img_dx.jpg) 中小企業DX\
    \
    ワンストップで中堅中小企業のお客さまのICT課題を解決](https://www.nttdocomo.co.jp/business/lp/nttdocomobusiness/smb-dx.html)
    
*    [![地域創生](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/docomobusiness/card_img_smart.jpg) 地域創生\
    \
    地域社会と連携しDXの力で地域創生と経済発展を支援](https://www.nttdocomo.co.jp/business/lp/regional-effort.html)
    
*    [![データ活用](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/docomobusiness/card_img_data.jpg) データ活用\
    \
    データ活用に必要な機能を企業の用途やニーズに合わせ提供](https://www.nttdocomo.co.jp/business/lp/nttdocomobusiness/data-dx.html)
    
*    [![IOWN](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/docomobusiness/card_img_iown.jpg) IOWN®\
    \
    最先端の光技術を使ったネットワーク基盤構想](https://www.nttdocomo.co.jp/business/lp/nttdocomobusiness/iown.html)
    
*    [![セキュリティ](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/docomobusiness/card_img_security.jpg) セキュリティ\
    \
    総合的なセキュリティで働き方をもっと自由に](https://www.nttdocomo.co.jp/business/lp/nttdocomobusiness/security.html)
    
*    [![GX](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/docomobusiness/card_img_gx.jpg) GX\
    \
    脱炭素へともに挑み、地域と企業の持続可能な成長を支援](https://www.nttdocomo.co.jp/business/lp/nttdocomobusiness/green-transformation.html)
    
*    [![AI](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/docomobusiness/card_img_ai.jpg) AI\
    \
    お客さまに合わせたAI技術のソリューションを提供](https://www.nttdocomo.co.jp/business/lp/nttdocomobusiness/ai.html)
    
*    [![IoT](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/docomobusiness/card_img_iot.jpg) IoT\
    \
    つなぐ力でお客さまのビジネスの可能性を広げる](https://www.nttdocomo.co.jp/business/lp/iot.html)
    
*    [![デジタルBPO](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/docomobusiness/card_img_bpo.jpg) デジタルBPO®\
    \
    DXでお客さま業務のプロセス効率化とアウトソーシングを実現](https://www.nttdocomo.co.jp/business/lp/nttdocomobusiness/digital-bpo.html)
    
*    [![中小企業DX](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/docomobusiness/card_img_dx.jpg) 中小企業DX\
    \
    ワンストップで中堅中小企業のお客さまのICT課題を解決](https://www.nttdocomo.co.jp/business/lp/nttdocomobusiness/smb-dx.html)
    
*    [![地域創生](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/docomobusiness/card_img_smart.jpg) 地域創生\
    \
    地域社会と連携しDXの力で地域創生と経済発展を支援](https://www.nttdocomo.co.jp/business/lp/regional-effort.html)
    
*    [![データ活用](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/docomobusiness/card_img_data.jpg) データ活用\
    \
    データ活用に必要な機能を企業の用途やニーズに合わせ提供](https://www.nttdocomo.co.jp/business/lp/nttdocomobusiness/data-dx.html)
    
*    [![IOWN](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/docomobusiness/card_img_iown.jpg) IOWN®\
    \
    最先端の光技術を使ったネットワーク基盤構想](https://www.nttdocomo.co.jp/business/lp/nttdocomobusiness/iown.html)
    
*    [![セキュリティ](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/docomobusiness/card_img_security.jpg) セキュリティ\
    \
    総合的なセキュリティで働き方をもっと自由に](https://www.nttdocomo.co.jp/business/lp/nttdocomobusiness/security.html)
    
*    [![GX](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/docomobusiness/card_img_gx.jpg) GX\
    \
    脱炭素へともに挑み、地域と企業の持続可能な成長を支援](https://www.nttdocomo.co.jp/business/lp/nttdocomobusiness/green-transformation.html)
    
*    [![AI](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/docomobusiness/card_img_ai.jpg) AI\
    \
    お客さまに合わせたAI技術のソリューションを提供](https://www.nttdocomo.co.jp/business/lp/nttdocomobusiness/ai.html)
    
*    [![IoT](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/docomobusiness/card_img_iot.jpg) IoT\
    \
    つなぐ力でお客さまのビジネスの可能性を広げる](https://www.nttdocomo.co.jp/business/lp/iot.html)
    
*    [![デジタルBPO](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/docomobusiness/card_img_bpo.jpg) デジタルBPO®\
    \
    DXでお客さま業務のプロセス効率化とアウトソーシングを実現](https://www.nttdocomo.co.jp/business/lp/nttdocomobusiness/digital-bpo.html)
    
*    [![中小企業DX](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/docomobusiness/card_img_dx.jpg) 中小企業DX\
    \
    ワンストップで中堅中小企業のお客さまのICT課題を解決](https://www.nttdocomo.co.jp/business/lp/nttdocomobusiness/smb-dx.html)
    
*    [![地域創生](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/docomobusiness/card_img_smart.jpg) 地域創生\
    \
    地域社会と連携しDXの力で地域創生と経済発展を支援](https://www.nttdocomo.co.jp/business/lp/regional-effort.html)
    
*    [![データ活用](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/docomobusiness/card_img_data.jpg) データ活用\
    \
    データ活用に必要な機能を企業の用途やニーズに合わせ提供](https://www.nttdocomo.co.jp/business/lp/nttdocomobusiness/data-dx.html)
    
*    [![IOWN](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/docomobusiness/card_img_iown.jpg) IOWN®\
    \
    最先端の光技術を使ったネットワーク基盤構想](https://www.nttdocomo.co.jp/business/lp/nttdocomobusiness/iown.html)
    
*    [![セキュリティ](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/docomobusiness/card_img_security.jpg) セキュリティ\
    \
    総合的なセキュリティで働き方をもっと自由に](https://www.nttdocomo.co.jp/business/lp/nttdocomobusiness/security.html)
    
*    [![GX](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/docomobusiness/card_img_gx.jpg) GX\
    \
    脱炭素へともに挑み、地域と企業の持続可能な成長を支援](https://www.nttdocomo.co.jp/business/lp/nttdocomobusiness/green-transformation.html)
    
*    [![AI](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/docomobusiness/card_img_ai.jpg) AI\
    \
    お客さまに合わせたAI技術のソリューションを提供](https://www.nttdocomo.co.jp/business/lp/nttdocomobusiness/ai.html)
    

![pause](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/docomobusiness/pause.png)

[AI](https://www.nttdocomo.co.jp/business/lp/nttdocomobusiness/ai.html)
 [IoT](https://www.nttdocomo.co.jp/business/lp/iot.html)
 [デジタルBPO®](https://www.nttdocomo.co.jp/business/lp/nttdocomobusiness/digital-bpo.html)
 [中小企業DX](https://www.nttdocomo.co.jp/business/lp/nttdocomobusiness/smb-dx.html)
 [地域創生](https://www.nttdocomo.co.jp/business/lp/regional-effort.html)
 [データ活用](https://www.nttdocomo.co.jp/business/lp/nttdocomobusiness/data-dx.html)
 [IOWN®](https://www.nttdocomo.co.jp/business/lp/nttdocomobusiness/iown.html)
 [セキュリティ](https://www.nttdocomo.co.jp/business/lp/nttdocomobusiness/security.html)
 [GX](https://www.nttdocomo.co.jp/business/lp/nttdocomobusiness/green-transformation.html)

※「IOWN®」は、NTT株式会社の商標または登録商標です。

ニュース
----

*   2025年12月4日 [NTTドコモビジネスとダッソー・システムズ、IOWN®を活用し世界で初めて3DCADを用いた遠隔共同作業の実証に成功](https://www.nttdocomo.co.jp/about-us/press-releases/news/article/2025/1204.html)
    
*   2025年12月2日 [NTT・NTTドコモビジネスとMujinの資本業務提携について](https://www.nttdocomo.co.jp/about-us/press-releases/news/article/2025/1202.html)
    
*   2025年12月1日 [運送事業者向けサービス「LINKEETH スマート運送」の提供を開始](https://www.nttdocomo.co.jp/about-us/press-releases/news/article/2025/1201_2.html)
    
*   2025年12月1日 [福島県昭和村とNTTドコモビジネス、セルラードローン Skydio X10を活用した熊対策を開始](https://www.nttdocomo.co.jp/about-us/press-releases/news/article/2025/1201.html)
    
*   2025年11月28日 [「ビジネスd出勤簿」および「ビジネスd電子申請」のサービス提供終了について(お知らせ)](https://www.nttdocomo.co.jp/about-us/information/info_20251128.html)
    
*   2025年5月9日 [社名、コーポレートブランドロゴの変更に関するお知らせ](https://www.nttdocomo.co.jp/about-us/press-releases/news/article/2025/0509_3.html)
    

*   [工事・故障情報 (NTTドコモビジネス)  \
    サポートサイト](https://support.ntt.com/)
    
*   [工事・故障情報 (NTTドコモビジネス)  \
    SDPFナレッジセンター![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/external-link.svg)](https://sdpf.ntt.com/service-status/details/)
    
*   [通信障害情報 (NTTドコモ)![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/external-link.svg)](https://www.docomo.ne.jp/info/network/)
    
*   [ニュースリリース](https://www.nttdocomo.co.jp/about-us/press-releases.html)
    
*   [ドコモの「FOMA®」および「iモード®」サービス終了に伴う法人向け各サービスにおける対応について](https://www.nttdocomo.co.jp/about-us/information/info_20240321.html)
    

*   [工事・故障情報 (NTTドコモビジネス)  \
    サポートサイト](https://support.ntt.com/)
    
*   [工事・故障情報 (NTTドコモビジネス)  \
    SDPFナレッジセンター![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/external-link.svg)](https://sdpf.ntt.com/service-status/details/)
    
*   [通信障害情報 (NTTドコモ)![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/external-link.svg)](https://www.docomo.ne.jp/info/network/)
    
*   [ニュースリリース](https://www.nttdocomo.co.jp/about-us/press-releases.html)
    
*   [ドコモの「FOMA®」および「iモード®」サービス終了に伴う法人向け各サービスにおける対応について](https://www.nttdocomo.co.jp/about-us/information/info_20240321.html)
    

おすすめ記事
------

あなたのビジネスや業務改善のヒントとなるオリジナルコンテンツをピックアップしてご紹介します

*   [docomo business Watch](https://www.nttdocomo.co.jp/bizon.html)
    
*   [OPEN HUB![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/external-link.svg)](https://openhub.ntt.com/)
    
*   [Shines![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/external-link.svg)](https://ntt.com/shines/index.html)
    

*   [![](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/pickup/topic-openhub_journal_13359.jpg)\
    \
    OPEN HUB\
    \
    ### IoTが社会にもたらす新しい価値とは？ 宮田裕章氏と考える、「超接続社会」で求められる企業変革\
    \
    ![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://openhub.ntt.com/journal/13359.html)
    
*   [![](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/pickup/topic-openhub_journal_12843.jpg)\
    \
    OPEN HUB\
    \
    ### 生成AIで人材不足が解消？課題は日本企業の「100%を求める」文化\
    \
    ![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://openhub.ntt.com/journal/12843.html)
    
*   [![](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/pickup/topic-openhub_journal_13680.jpg)\
    \
    OPEN HUB\
    \
    ### 手触り感のある顧客体験「高感度上質消費」をリモートで実現する百貨店DX\
    \
    ![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://openhub.ntt.com/journal/13680.html)
    
*   [![](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/pickup/bizon_phone-bill-savings.jpg)\
    \
    音声\
    \
    ### オフィス固定電話の料金を安くしませんか？ハイブリッドワーク時代におすすめの活用方法を解説\
    \
    ![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://www.nttdocomo.co.jp/bizon/phone-bill-savings.html?utm_source=other&utm_medium=refarral&utm_campaign=bizon_phone-bill-savings_smdm_other)
    
*   [![](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/pickup/bizon_ai-bcp-planning-attention.jpg)\
    \
    災害対策・BCP\
    \
    ### BCP(事業継続計画)とは? はじめてでもわかる策定・構築の手順と対応方法\
    \
    ![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://www.nttdocomo.co.jp/bizon/bcp/planning-attention.html?utm_source=other&utm_medium=refarral&utm_campaign=bizon_bcp_planning-attention_smdm_other)
    
*   [![](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/pickup/bizon_childcare-and-caregiving.jpg)\
    \
    法改正\
    \
    ### 2025年4月に育児介護休業法が改正 その内容と企業への影響をわかりやすく解説\
    \
    ![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://www.nttdocomo.co.jp/bizon/childcare-and-caregiving.html?utm_source=other&utm_medium=refarral&utm_campaign=bizon_childcare-and-caregiving_smdm_other)
    
*   [![](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/pickup/topic-openhub_journal_13192.jpg)\
    \
    OPEN HUB\
    \
    ### 400億台のIoTデバイスがハッキングの危機に——高度化するサイバー攻撃から守るための3つの方法とは\
    \
    ![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://openhub.ntt.com/journal/13192.html)
    
*   [![](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/pickup/topic-openhub_project_13305.jpg)\
    \
    OPEN HUB\
    \
    ### 競合とのデータ連携を実現。日用品業界GX革命にみる、データスペースの可能性\
    \
    ![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://openhub.ntt.com/project/13305.html)
    
*   [![](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/pickup/topics_shines_p-c_20250514.jpg)\
    \
    Shines\
    \
    ### キャリアも私生活も、自分で動機付けをするから納得感を持って生きられる――三BS　池田 真実子さん\
    \
    ![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://www.nttdocomo.co.jp/shines/posts/p-c_20250514.html)
    
*   [![](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/pickup/topic-openhub_journal_13252.jpg)\
    \
    OPEN HUB\
    \
    ### 安斎勇樹氏に聞く、"冒険する組織"と“共創プログラム”の可能性\
    \
    ![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://openhub.ntt.com/journal/13252.html)
    

![左へ](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/slider-control-back.svg)

![右へ](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/slider-control-next.svg)

 ![再生](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/slider-control-play.svg)![一時停止](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/slider-control-pause.svg)

*   [docomo business Watch](https://www.nttdocomo.co.jp/bizon.html)
    
*   [OPEN HUB![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/external-link.svg)](https://openhub.ntt.com/)
    
*   [Shines![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/external-link.svg)](https://ntt.com/shines/index.html)
    

特集ページ
-----

NTTドコモビジネスの幅広いサービス/ソリューションを業界や業種、課題、ニーズごとにわかりやすくご紹介する特集ページの一覧です

*   [特集ページ一覧](https://www.nttdocomo.co.jp/business/lp/)
    

*   [![広告特設サイト「人を想うDX」](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/special/special_nttdocomobusiness-lp-20251029.png)\
    \
    ### 広告特設サイト「人を想うDX」 NTTコミュニケーションズから社名変更したNTTドコモビジネスの新CM特設サイトです。](https://www.nttdocomo.co.jp/business/lp/nttdocomobusiness/)
    
*   [![](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/business/lp/index/img/panel/pc/special-area_lp-smb.png)\
    \
    ### 中小企業向けおすすめのサービスを紹介 サービス紹介に加えて、お悩み診断やお役立ち情報といったさまざまな側面から皆さまをサポートします。](https://www.nttdocomo.co.jp/business/lp/smb.html?utm_source=other&utm_medium=email&utm_campaign=lp_smb_smbusiness_top_tokusyu_smdm_other)
    
*   [![](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/business/lp/index/img/panel/pc/ntn-solution_index.png)\
    \
    ### ドコモビジネスのNTN(非地上系ネットワーク) 人工衛星や無人飛行機を活用し、高信頼・耐災害性に優れた「いつでも、どこでもつながる」を実現します。](https://www.nttdocomo.co.jp/business/lp/ntn-solution.html)
    
*   [![](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/business/lp/index/img/panel/pc/index_biz_iot-partner.png)\
    \
    ### IoT Partner Program IoTを活用したビジネスの実現をサポートします。お気軽にご相談ください。](https://www.nttdocomo.co.jp/business/lp/biz_iot-partner.html)
    
*   [![](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/business/lp/index/img/panel/pc/foma-mvno-end_index.png)\
    \
    ### 「FOMA®」(3G)終了に伴うMVNOサービスの対応について MVNOサービスの3Gアクセス終了についてご案内します。LTE/5G-NSA対応のサービス・通信機器をご検討ください。](https://www.nttdocomo.co.jp/business/lp/3gend.html)
    
*   [![](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/business/lp/index/img/panel/pc/dbs_index.png)\
    \
    ### ドコモビジネスパッケージ 中堅中小企業のお客さまのお困りごとに最適な解決方法をご提案。厳選したサービスをパッケージ化し、簡単・お得に導入可能です。](https://www.nttdocomo.co.jp/business/services/dbp.html)
    
*   [![](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/business/lp/index/img/panel/pc/lp-iot_index.png)\
    \
    ### IoT・5Gソリューション事例 さまざまな業種における最新のIoT・5Gソリューション事例をご紹介します。](https://www.nttdocomo.co.jp/business/lp/iot.html)
    
*   [![](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/business/lp/index/img/panel/pc/madoguchi_pc_top.png)\
    \
    ### 法人サービスのご相談ができるドコモショップのご案内 法人サービスのご相談ができるドコモショップをご紹介します。業務のDX化のお悩みご相談ください。](https://www.nttdocomo.co.jp/business/lp/business-docomoshop.html?utm_source=other&utm_medium=referral&utm_campaign=lp_smb_ostop-docomoshop_2303_other)
    
*   [![](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/business/lp/index/img/panel/pc/business-d-app_pc_top.jpg)\
    \
    ### ビジネスdアプリ ビジネスdアカウントの機能がまとまったビジネス向け総合ポータルアプリ](https://www.nttdocomo.co.jp/business/lp/business-dapp.html)
    

![左へ](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/slider-control-back.svg)

![右へ](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/slider-control-next.svg)

 ![再生](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/slider-control-play.svg)![一時停止](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/slider-control-pause.svg)

*   [特集ページ一覧](https://www.nttdocomo.co.jp/business/lp/)
    

導入事例
----

最新の導入事例や注目の導入事例をご紹介します

*   [導入事例一覧](https://www.nttdocomo.co.jp/business/case-studies.html)
    

*   [![](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/jirei/sej.png)\
    \
    導入事例\
    \
    ### \> 株式会社セブン-イレブン・ジャパン\
    \
    \> サイロ化した社内データを安全な経路でクラウドに集約 DXを推進するデータ利活用基盤を構築](https://www.nttdocomo.co.jp/business/case-studies/network/interconnect/sej.html)
    
*   [![](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/jirei/shiftplus.png)\
    \
    導入事例\
    \
    ### \> シフトプラス株式会社\
    \
    \> 業界最安値のストレージとセキュアな通信接続で80自治体のふるさと納税の申請処理を大幅に効率化](https://www.nttdocomo.co.jp/business/case-studies/network/interconnect/shiftplus.html)
    
*   [![](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/jirei/i0535.png)\
    \
    導入事例\
    \
    ### \> オルガノ株式会社\
    \
    \> 水で培った先端技術にIoTをプラスし新たな価値創造でお客さまのビジネスに貢献](https://www.nttdocomo.co.jp/business/case-studies/iot/iot/organo.html)
    
*   [![](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/jirei/tsk.png)\
    \
    導入事例\
    \
    ### \> TSK株式会社\
    \
    \> Google Workspace と拡張ツールにより決裁業務をデジタル化  \
    業務環境の改善と効率化によって原材料高とコロナ禍に立ち向かう](https://www.nttdocomo.co.jp/business/case-studies/tsk.html)
    
*   [![](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/jirei/i0564.png)\
    \
    導入事例\
    \
    ### \> 京セラ株式会社\
    \
    \> 業務革新プロジェクトで間接業務の効率化を推進 AI翻訳サービスの全社導入でグローバル連携を強化](https://www.nttdocomo.co.jp/business/case-studies/application/ai/kyocera.html)
    
*   [![](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/jirei/i0565.png)\
    \
    導入事例\
    \
    ### \> 第一生命保険株式会社\
    \
    \> PBXクラウド化とスマホの内線利用で、電話環境を刷新  \
    どこでも「オフィスと同等に働ける環境」に](https://www.nttdocomo.co.jp/business/case-studies/application/web-directory/dai-ichi-life.html)
    
*   [![](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/jirei/sdpf_endo-mfg.png)\
    \
    導入事例\
    \
    ### \> 株式会社遠藤製作所\
    \
    \> IoTプラットフォーム「Things Cloud?」の導入でものづくりのDXに挑戦する遠藤製作所](https://www.nttdocomo.co.jp/business/case-studies/sdpf/endo-mfg.html)
    
*   [![](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/jirei/sanics.png)\
    \
    導入事例\
    \
    ### \> 株式会社サニックス\
    \
    \> 遠隔作業支援ソリューション「AceReal? for docomo」でリモート技術指導を実現](https://www.nttdocomo.co.jp/business/case-studies/sanics.html)
    
*   [![](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/jirei/saraya.png)\
    \
    導入事例\
    \
    ### \> サラヤ株式会社・株式会社Cotof\
    \
    \> 顧客満足度を高め、スタッフの業務を停滞させない短納期で高品質な店舗ネットワークの構築を実現](https://www.nttdocomo.co.jp/business/case-studies/saraya.html)
    
*   [![](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/jirei/fukuidaigaku.png)\
    \
    導入事例\
    \
    ### \> 福井大学医学部附属病院\
    \
    \> 「オフィスリンク」の導入で院内はもちろん、外出先にも内線通話が可能に](https://www.nttdocomo.co.jp/business/case-studies/fukuidaigaku.html)
    

![左へ](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/slider-control-back.svg)

![右へ](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/slider-control-next.svg)

 ![再生](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/slider-control-play.svg)![一時停止](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/slider-control-pause.svg)

*   [導入事例一覧](https://www.nttdocomo.co.jp/business/case-studies.html)
    

セミナー・イベント
---------

開催・出展する各種セミナー、  
イベント情報をご紹介します

[セミナーイベント一覧](https://www.nttdocomo.co.jp/business/event.html)

*   受付中
    
    2025年7月10日～
    
    オンライン
    
    [“持っているだけ”から“活かす”へ：無駄を省き、価値を引き出すIT資産管理の最適化アプローチとは](https://www.nttdocomo.co.jp/business/event.html)
      
    開催日時：2025年7月10日(木)～2026年9月9日(水)
    
*   受付中
    
    2025年12月4日
    
    オンライン
    
    [攻撃者の視点で語る、サイバー攻撃の最新トレンド！](https://www.nttdocomo.co.jp/business/event.html)
      
    開催日時：2025年12月4日(木) 15:00～16:15
    
*   受付中
    
    2025年12月9日
    
    オンライン・NTTドコモビジネス本社 大手町プレイス
    
    [歴史思考で読み解く― 盛者必衰とは限らない「続く力」の本質](https://www.nttdocomo.co.jp/business/event.html)
      
    開催日時：2025年12月9日(火) 16:00～18:00
    
*   受付中
    
    2025年12月11日
    
    グランフロント大阪
    
    [生成AI・DX x Android端末のビジネス活用講座（Google共催）](https://www.nttdocomo.co.jp/business/event.html)
      
    開催日時：2025年12月11日(木) 14:30～18:00
    

[セミナーイベント一覧](https://www.nttdocomo.co.jp/business/event.html)

サービス/ソリューション
------------

![](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/service/search.svg)

### サービス/ソリューションを探したい

*   [![](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/2024/service/icon_cat01.svg)\
    \
    クラウド・  \
    データセンター](https://www.nttdocomo.co.jp/business/services.html#lc01)
    
*   [![](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/2024/service/icon_cat02.svg)\
    \
    5G](https://www.nttdocomo.co.jp/business/services.html#lc02)
    
*   [![](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/2024/service/icon_cat03.svg)\
    \
    ネットワーク・  \
    モバイル](https://www.nttdocomo.co.jp/business/services.html#lc03)
    
*   [![](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/2024/service/icon_cat04.svg)\
    \
    電話・映像  \
    コミュニケーション](https://www.nttdocomo.co.jp/business/services.html#lc04)
    
*   [![](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/2024/service/icon_cat05.svg)\
    \
    運用管理](https://www.nttdocomo.co.jp/business/services.html#lc05)
    
*   [![](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/2024/service/icon_cat09.svg)\
    \
    データ利活用](https://www.nttdocomo.co.jp/business/services.html#lc09)
    
*   [![](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/2024/service/icon_cat10.svg)\
    \
    業務支援・  \
    マーケティング](https://www.nttdocomo.co.jp/business/services.html#lc10)
    
*   [![](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/2024/service/icon_cat06.svg)\
    \
    セキュリティ](https://www.nttdocomo.co.jp/business/services.html#lc06)
    
*   [![](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/2024/service/icon_cat11.svg)\
    \
    災害対策・BCP](https://www.nttdocomo.co.jp/business/services.html#lc11)
    
*   [![](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/2024/service/icon_cat07.svg)\
    \
    IoT](https://www.nttdocomo.co.jp/business/services.html#lc07)
    
*   [![](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/2024/service/icon_cat08.svg)\
    \
    AI](https://www.nttdocomo.co.jp/business/services.html#lc08)
    

*   [課題・ニーズで探す](https://www.nttdocomo.co.jp/business/services.html#needs)
    
*   [サービス名・キーワードで探す](https://www.nttdocomo.co.jp/business/services.html#keyword)
    
*   [業種・業態で探す](https://www.nttdocomo.co.jp/business/services.html#jobtype)
    

![](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/2024/service/buy.svg)

### サービスを購入したい

「ドコモビジネスオンラインショップ」は、法人向けモバイルや業務のDX化を支援するICTサービスについてオンラインでご相談・ご注文いただける、NTTドコモビジネスが提供するドコモビジネス“バーチャル”ショップです。

*   [![](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/2024/service/icon-service01.svg)\
    \
    カテゴリから探す![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://www.onlineshop.docomobusiness.ntt.com/service#category-pc)
    
*   [![](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/2024/service/icon-service02.svg)\
    \
    課題から探す![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://www.onlineshop.docomobusiness.ntt.com/service#task)
    
*   [![](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/2024/service/icon-service03.svg)\
    \
    話題のテーマから探す![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://www.onlineshop.docomobusiness.ntt.com/service#theme)
    
*   [![](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/2024/service/icon-service04.svg)\
    \
    新規会員登録  \
    ログインはこちら![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://www.onlineshop.docomobusiness.ntt.com/register)
    

![](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/service/contact.svg)

### 問い合わせをしたい

*   [![](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/2024/service/icon-service-contact01.svg)\
    \
    お電話でのお問い合わせ](https://www.nttdocomo.co.jp/business/contact.html#phone)
    
*   [![](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/2024/service/icon-service-contact02.svg)\
    \
    メールでのお問い合わせ](https://www.nttdocomo.co.jp/business/contact.html#mail)
    
*   [![](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/2024/service/icon-service-contact03.svg)\
    \
    ご契約中のお客さま![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://support.ntt.com/item/b/list)
    
*   [![](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/2024/service/icon-service-contact04.svg)\
    \
    よくあるご質問![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://support.ntt.com/faq/?businessPersonalFlg=business)
    

企業情報
----

*   [![](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/company/company.svg)\
    \
    会社案内](https://www.nttdocomo.co.jp/about-us/company-profile.html)
    
*   [![](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/company/management.svg)\
    \
    社外からの評価実績](https://www.nttdocomo.co.jp/about-us/we-are-a-leader.html)
    
*   [![](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/jp/index/img/company/news-room.svg)\
    \
    ニュースルーム](https://www.nttdocomo.co.jp/about-us/newsroom.html)
    

[その他の企業情報はこちら](https://www.nttdocomo.co.jp/about-us.html)

[このページのトップへ](https://www.nttdocomo.co.jp/biz/#)

*   *   産業・地域DX/事業共創
        
        *   [OPEN HUB for Smart World![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://openhub.ntt.com/)
            *   [OPEN HUB for Smart Worldとは![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://openhub.ntt.com/about/)
                
            *   [OPEN HUB VIRTUAL PARK![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://openhub.ntt.com/virtual-park.html)
                
            *   [アセット![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://openhub.ntt.com/asset/)
                
            *   [OPEN HUB事例![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://openhub.ntt.com/project/)
                
            *   [特集![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://openhub.ntt.com/issue/)
                
            *   [記事コンテンツ![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://openhub.ntt.com/journal/)
                
            *   [イベント/ウェビナー ![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://openhub.ntt.com/event/)
                 
            *   [プレイヤー(カタリスト/パートナー企業)![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://openhub.ntt.com/player/)
                
            *   [RADIO![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://openhub.ntt.com/radio/)
                
        *   [Smart World](https://www.nttdocomo.co.jp/business/dx/smart.html)
            *   [Smart City](https://www.nttdocomo.co.jp/business/dx/smart/city.html)
                
            *   [Smart Education](https://www.nttdocomo.co.jp/business/dx/smart/education.html)
                
            *   [Smart Healthcare](https://www.nttdocomo.co.jp/business/dx/smart/healthcare.html)
                
            *   [Smart Industry](https://www.nttdocomo.co.jp/business/dx/smart/industry.html)
                
            *   [Smart Mobility](https://www.nttdocomo.co.jp/business/dx/smart/mobility.html)
                
            *   [Smart Worksite](https://www.nttdocomo.co.jp/business/dx/smart/worksite.html)
                
            *   [生成AI(Generative AI)](https://www.nttdocomo.co.jp/business/dx/smart/generative-ai.html)
                
        *   [地域の取り組み](https://www.nttdocomo.co.jp/business/lp/regional-effort.html)
            
*   *   サービス・ソリューション・モバイル
        
        *   [サービス・ソリューション](https://www.nttdocomo.co.jp/business/services.html)
            *   [カテゴリーで探す](https://www.nttdocomo.co.jp/business/dx/smart/city.html)
                
            *   [課題・ニーズで探す](https://www.nttdocomo.co.jp/business/services/#needs)
                
            *   [業種・業態で探す](https://www.nttdocomo.co.jp/business/services/#jobtype)
                
            *   [キーワードで探す](https://www.nttdocomo.co.jp/business/services.html#keyword)
                
        *   [モバイル](https://www.nttdocomo.co.jp/business/mobile.html)
            *   [製品](https://www.nttdocomo.co.jp/business/mobile/product.html)
                
            *   [料金](https://www.nttdocomo.co.jp/business/mobile/charge.html)
                
            *   [モバイルサービス](https://www.nttdocomo.co.jp/business/services.html)
                
            *   [お手続き](https://support.ntt.com/purpose?subContentsType=2106&businessPersonalFlg=business)
                
    *   導入事例・セミナー
        
        *   [導入事例](https://www.nttdocomo.co.jp/business/case-studies.html)
            
        *   [セミナー](https://www.nttdocomo.co.jp/business/event.html)
            
*   *   中堅中小企業のお客さま
        
        *   [NTTドコモビジネスウォッチ](https://www.nttdocomo.co.jp/bizon.html)
            *   [新着記事](https://www.nttdocomo.co.jp/bizon/search.html)
                
            *   [お役立ち資料ダウンロード](https://www.nttdocomo.co.jp/bizon/white-paper.html)
                
            *   [トレンド記事特集](https://www.nttdocomo.co.jp/bizon/summary.html)
                
            *   [IT用語集](https://www.nttdocomo.co.jp/bizon/glossary.html)
                
        *   [中堅中小企業向け  \
            サービス・ソリューション](https://www.nttdocomo.co.jp/business/lp/smb.html)
            *   [お悩みから探す](https://www.nttdocomo.co.jp/business/lp/smb/services/problem.html)
                
            *   [業界から探す](https://www.nttdocomo.co.jp/business/lp/smb/services/industry.html)
                
            *   [ゲーム感覚で見つける](https://www.nttdocomo.co.jp/business/lp/smb/services/dx-roadmap.html)
                
            *   [ビジネスお悩み診断](https://www.nttdocomo.co.jp/business/lp/smb/shindan.html)
                
        *   [NTTドコモビジネス  \
            オンラインショップ![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://www.onlineshop.docomobusiness.ntt.com/)
            *   [法人向けモバイルトップ![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://www.onlineshop.docomobusiness.ntt.com/service/mobile)
                
            *   [はじめての方へ![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://www.onlineshop.docomobusiness.ntt.com/about-us)
                
            *   [サービス・商品を探す![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://www.onlineshop.docomobusiness.ntt.com/service)
                
            *   [新規会員登録/ログインはこちら![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://www.onlineshop.docomobusiness.ntt.com/login)
                
            *   [10回線以上のお問い合わせ・お見積りはこちら![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)](https://www.onlineshop.docomobusiness.ntt.com/mobile-application-largeorder)
                
    *   企業情報
        
        *   [企業情報](https://www.nttdocomo.co.jp/about-us.html)
            *   [会社案内](https://www.nttdocomo.co.jp/about-us/company-profile.html)
                
            *   [ニュースルーム](https://www.nttdocomo.co.jp/about-us/newsroom.html)
                
            *   [サステナビリティ](https://www.nttdocomo.co.jp/about-us/csr.html)
                
            *   [経営情報](https://www.nttdocomo.co.jp/about-us/company-profile/finance.html)
                
            *   [採用情報](https://www.nttdocomo.co.jp/about-us/recruit/index.html)
                

*   [![x](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/cmn/img/cmn_ic_footer_x.png)](https://www.nttdocomo.co.jp/about-us/hp/social/list.html#x)
    
*   [![facebook](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/cmn/img/cmn_ic_footer_facebook.png)](https://www.nttdocomo.co.jp/about-us/hp/social/list.html#facebook)
    
*   [![Instagram](https://www.nttdocomo.co.jp/content/dam/nttcom/hq/cmn/img/cmn_ic_footer_instagram.png)](https://www.nttdocomo.co.jp/about-us/hp/social/list.html#instagram)
    
*   [![youtube](https://www.nttdocomo.co.jp/content/dam/nttcom/cmn/img/cmn_ic_footer_youtube.png)](https://www.nttdocomo.co.jp/about-us/hp/social/list.html#youtube)
    

*   [サイトマップ](https://www.nttdocomo.co.jp/sitemap.html)
    
*   [サイトのご利用条件](https://www.nttdocomo.co.jp/about-us/hp.html)
    
*   [お問い合わせ／FAQ](https://www.nttdocomo.co.jp/contact.html)
    
*   [サービス一覧](https://www.nttdocomo.co.jp/business/navi/servicetop.html)
    
*   [プライバシーポリシー](https://www.nttdocomo.co.jp/about-us/hp/privacy.html)
    
*   [ウェブアクセシビリティポリシー](https://www.nttdocomo.co.jp/about-us/hp/accessibility.html)
    
*   [情報の外部送信について](https://www.nttdocomo.co.jp/about-us/hp/webbeacon.html#exsend)
    
*   [NTTドコモグループ](https://nttdocomo-group.com/index.html)
    ![別ウィンドウで開きます。](https://www.nttdocomo.co.jp/content/dam/nttcom/img/external-link-icon-red.svg)

[© NTT DOCOMO BUSINESS, Inc. All Rights Reserved.](https://www.nttdocomo.co.jp/copyright.html)
