# eximo | 料金・割引 | NTTドコモ

URL: https://www.docomo.ne.jp/charge/eximo/

---

[![NTT docomo](https://www.docomo.ne.jp/images_osp/common/newhf/header/cmn-rwd-header-logo.svg?ver=1751324418)](https://www.docomo.ne.jp/?icid=CRP_common_header_to_CRP_TOP)

*   [![別ウィンドウで開きます。my docomo](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-my-docomo-logo.svg)](https://www.docomo.ne.jp/mydocomo/?icid=CRP_outerhead_to_MYD_TOP)
    
*   [![別ウィンドウで開きます。Online Shop](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-online-shop-icon2.svg)](https://onlineshop.docomo.ne.jp/top-ols/?xcid=OLS_TOP_from_CRP_outerhead)
    

*   商品・サービス
    
    *   *   モバイル
        *   *   [iPhone](https://www.docomo.ne.jp/iphone/?icid=CRP_menu_to_CRP_IPH)
                
            *   [iPad](https://www.docomo.ne.jp/ipad/?icid=CRP_menu_to_CRP_IPA)
                
            *   [製品](https://www.docomo.ne.jp/product/?icid=CRP_menu_to_CRP_PRD)
                
            *   [料金・割引](https://www.docomo.ne.jp/charge/?icid=CRP_menu_to_CRP_CHA)
                
            *   [サービス・機能](https://www.docomo.ne.jp/service/?icid=CRP_menu_to_CRP_SER)
                
            *   [通信・エリア](https://www.docomo.ne.jp/area/?icid=CRP_menu_to_CRP_AREA)
                
    *   *   インターネット回線・固定電話
        *   *   [インターネット回線・固定電話トップ](https://www.docomo.ne.jp/internet/?icid=CRP_menu_to_CRP_INT)
                
            *   [ドコモ光](https://www.docomo.ne.jp/internet/hikari/?icid=CRP_menu_to_CRP_INT_hikari)
                
            *   [ahamo光](https://www.docomo.ne.jp/internet/ahamo_hikari/?icid=CRP_menu_to_CRP_internet_ahamo_hikari)
                
            *   [home 5G](https://www.docomo.ne.jp/home_5g/?icid=CRP_menu_to_CRP_HOM)
                
            *   [homeでんわ](https://www.docomo.ne.jp/home_denwa/?icid=CRP_menu_to_CRP_DENWA)
                
    *   *   スマートライフ
        *   *   [スマートライフ トップ](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_menu_to_CRP_SER_smart-life)
                
            *   [決済・保険・投資](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_menu_to_CRP_SER_smart-life_finance&tgl_entertainment=0&tgl_life-support=0&tgl_finance=1&tgl_shopping=0&tgl_healthcare=0#finance)
                
            *   [エンターテインメント](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_menu_to_CRP_SER_smart-life_entertainment&tgl_entertainment=1&tgl_life-support=0&tgl_finance=0&tgl_shopping=0&tgl_healthcare=0#entertainment)
                
            *   [ライフサポート](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_menu_to_CRP_SER_smart-life_life-support&tgl_entertainment=0&tgl_life-support=1&tgl_finance=0&tgl_shopping=0&tgl_healthcare=0#life-support)
                
            *   [ショッピング](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_menu_to_CRP_SER_smart-life_shopping&tgl_entertainment=0&tgl_life-support=0&tgl_finance=0&tgl_shopping=1&tgl_healthcare=0#shopping)
                
            *   [ヘルスケア](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_menu_to_CRP_SER_smart-life_healthcare&tgl_entertainment=0&tgl_life-support=0&tgl_finance=0&tgl_shopping=0&tgl_healthcare=1#healthcare)
                
    *   *   電気・ガス
        *   *   [ドコモでんき／  \
                ドコモ ガス トップ](https://www.docomo.ne.jp/denki/?icid=CRP_menu_to_CRP_DENKI)
                
    
*   お知らせ
    
    *   [お知らせトップ](https://www.docomo.ne.jp/info/?icid=CRP_menu_to_CRP_INFO)
        
    *   [ニュースルーム](https://www.docomo.ne.jp/info/update/?icid=CRP_menu_to_CRP_INFO_update)
        
    *   [報道発表](https://www.docomo.ne.jp/info/news_release/?icid=CRP_menu_to_CRP_INFO_news_release)
        
    *   [重要なお知らせ（通信障害）](https://www.docomo.ne.jp/info/network/?icid=CRP_menu_to_CRP_INFO_network)
        
    *   [携帯電話サービスの通信状況（地域別）](https://www.docomo.ne.jp/info/status/?icid=CRP_menu_to_CRP_INFO_status)
        
    *   [工事のお知らせ](https://www.docomo.ne.jp/info/construction/?icid=CRP_menu_to_CRP_INFO_construction)
        
    
*   企業情報
    
    *   [企業情報トップ](https://www.docomo.ne.jp/corporate/?icid=CRP_menu_to_CRP_CORP)
        
    *   [あなたとドコモ](https://www.docomo.ne.jp/corporate/anatatodocomo/?icid=CRP_menu_to_CRP_CORP_anatatodocomo)
        
    *   [企業理念・ビジョン](https://www.docomo.ne.jp/corporate/philosophy_vision/?icid=CRP_menu_to_CRP_CORP_philosophy_vision)
        
    *   [会社案内](https://www.docomo.ne.jp/corporate/about/?icid=CRP_menu_to_CRP_CORP_about)
        
    *   [サステナビリティ](https://www.docomo.ne.jp/corporate/csr/?icid=CRP_menu_to_CRP_CORP_csr)
        
    *   [技術とあんしん](https://www.docomo.ne.jp/corporate/technology_safety/?icid=CRP_menu_to_CRP_CORP_technology_safety)
        
    *   [IR情報](https://www.docomo.ne.jp/corporate/ir/library/?icid=CRP_menu_to_CRP_CORP_ir_library)
        
    *   [採用情報](https://www.docomo.ne.jp/corporate/recruit/?icid=CRP_menu_to_CRP_CORP_recruit)
        
    *   [NTTドコモグループ_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://nttdocomo-group.com/index.html)
        
    
*   法人のお客さま
    
    *   [NTTドコモビジネス_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.ntt.com/index.html)
        
    *   [NTTドコモ  \
        ソリューションズ_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.nttcom.co.jp/)
        
    *   [NTTドコモ・グローバル](https://www.docomo.ne.jp/global/?icid=CRP_TOP_to_CRP_global)
        
    
*   [![別ウィンドウで開きます。my docomo](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-my-docomo-logo.svg)](https://www.docomo.ne.jp/mydocomo/?icid=CRP_outerhead_to_MYD_TOP)
    
    [![別ウィンドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-online-shop-icon.svg)\
    \
    Online Shop](https://onlineshop.docomo.ne.jp/top-ols/?xcid=OLS_TOP_from_CRP_outerhead)
    
    [![別ウィンドウで開きます。のりかえ（MNP）](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-online-mnp-icon_pc.png)](https://onlineshop.docomo.ne.jp/special-contents/mnp?xcid=OLS_special-contents_mnp_flow_from_CRP_TOP_mnp_btn)
    
    [![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-switch-online-icon.svg)機種変更](https://www.docomo.ne.jp/support/switch_online/?icid=CRP_outerhead_to_SUP_switch_online)
    

 [![](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-daccount-logo.svg) ログインする](https://www.docomo.ne.jp/charge/eximo/)

[![dポイントクラブ](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-d-point-club-logo.svg)\
\
P\
\
![ランク](https://www.docomo.ne.jp/charge/eximo/)](https://www.docomo.ne.jp/charge/eximo/)
[![ドコモビジネスメンバーズ](https://www.docomo.ne.jp/images_osp/common/newhf/ico/ico_businessmembers.png)](https://www.docomo.ne.jp/charge/eximo/)

MENU

[![NTT docomo](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-header-logo.svg?ver=1751324418)](https://www.docomo.ne.jp/?icid=CRP_drawer_to_CRP_TOP)

[English](https://www.docomo.ne.jp/english/?icid=CRP_drawer_to_CRP_EN)

* * *

   ![検索する](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-header-search-icon.svg)

*    [![](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-my-docomo-logo.svg) My docomo _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.docomo.ne.jp/mydocomo/?icid=CRP_drawer_to_MYD_TOP)
     
*    [![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-online-shop-icon.svg) Online Shop _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://onlineshop.docomo.ne.jp/top-ols/?xcid=OLS_TOP_from_CRP_drawer)
     
*    [![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-docomo-shop-icon.svg) ドコモショップ _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://shop.smt.docomo.ne.jp/?xcid=DS_TOP_from_CRP_drawer)
     
*    [![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-customer-support-icon.svg) お客さまサポート](https://www.docomo.ne.jp/support/?icid=CRP_drawer_sup01_to_CRP_SUP)
    
*    [![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-campaign-icon.svg) キャンペーン・特典](https://www.docomo.ne.jp/campaign_event/?icid=CRP_drawer_to_CRP_CAM)
    
*    [![](https://www.docomo.ne.jp/assets/content/dam/corp/jp/ja/common/images/logo/cmn-rwd-d-point-club-logo.svg) dポイントクラブ _![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://dpoint.docomo.ne.jp/)
     

*   *   *   商品・サービス
        *   *   ![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/ico_mobile.png) モバイル
                
                *   [iPhone](https://www.docomo.ne.jp/iphone/?icid=CRP_drawer_to_CRP_IPH)
                    
                *   [iPad](https://www.docomo.ne.jp/ipad/?icid=CRP_drawer_to_CRP_IPA)
                    
                *   [製品](https://www.docomo.ne.jp/product/?icid=CRP_drawer_to_CRP_PRD)
                    
                *   [料金・割引](https://www.docomo.ne.jp/charge/?icid=CRP_drawer_to_CRP_CHA)
                    
                *   [サービス・機能](https://www.docomo.ne.jp/service/?icid=CRP_drawer_to_CRP_SER)
                    
                *   [通信・エリア](https://www.docomo.ne.jp/area/?icid=CRP_drawer_to_CRP_AREA)
                    
                
            *   ![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/ico_internet.png) インターネット回線・固定電話
                
                *   [インターネット回線・固定電話トップ](https://www.docomo.ne.jp/internet/?icid=CRP_drawer_to_CRP_INT)
                    
                *   [ドコモ光](https://www.docomo.ne.jp/internet/hikari/?icid=CRP_drawer_to_CRP_INT_hikari)
                    
                *   [ahamo光](https://www.docomo.ne.jp/internet/ahamo_hikari/?icid=CRP_drawer_to_CRP_internet_ahamo_hikari)
                    
                *   [home 5G](https://www.docomo.ne.jp/home_5g/?icid=CRP_drawer_to_CRP_HOM)
                    
                *   [homeでんわ](https://www.docomo.ne.jp/home_denwa/?icid=CRP_drawer_to_CRP_DENWA)
                    
                
            *   ![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/ico_smartlife.png) スマートライフ
                
                *   [スマートライフ トップ](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_drawer_to_CRP_SER_smart-life)
                    
                *   [決済・保険・投資](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_drawer_to_CRP_SER_smart-life_finance&tgl_entertainment=0&tgl_life-support=0&tgl_finance=1&tgl_shopping=0&tgl_healthcare=0#finance)
                    
                *   [エンターテインメント](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_drawer_to_CRP_SER_smart-life_entertainment&tgl_entertainment=1&tgl_life-support=0&tgl_finance=0&tgl_shopping=0&tgl_healthcare=0#entertainment)
                    
                *   [ライフサポート](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_drawer_to_CRP_SER_smart-life_life-support&tgl_entertainment=0&tgl_life-support=1&tgl_finance=0&tgl_shopping=0&tgl_healthcare=0#life-support)
                    
                *   [ショッピング](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_drawer_to_CRP_SER_smart-life_shopping&tgl_entertainment=0&tgl_life-support=0&tgl_finance=0&tgl_shopping=1&tgl_healthcare=0#shopping)
                    
                *   [ヘルスケア](https://www.docomo.ne.jp/service/smart-life/?icid=CRP_drawer_to_CRP_SER_smart-life_healthcare&tgl_entertainment=0&tgl_life-support=0&tgl_finance=0&tgl_shopping=0&tgl_healthcare=1#healthcare)
                    
                
            *   ![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/ico_denki.png?ver=1748827032) 電気・ガス
                
                *   [ドコモでんき／  \
                    ドコモ ガス トップ](https://www.docomo.ne.jp/denki/?icid=CRP_drawer_to_CRP_DENKI)
                    
                
    *   *   お知らせ
        *   *   お知らせ
                
                *   [お知らせ トップ](https://www.docomo.ne.jp/info/?icid=CRP_drawer_to_CRP_INFO)
                    
                *   [ニュースルーム](https://www.docomo.ne.jp/info/update/?icid=CRP_drawer_to_CRP_INFO_update)
                    
                *   [報道発表](https://www.docomo.ne.jp/info/news_release/?icid=CRP_drawer_to_CRP_INFO_news_release)
                    
                *   [重要なお知らせ（通信障害）](https://www.docomo.ne.jp/info/network/?icid=CRP_drawer_to_CRP_INFO_network)
                    
                *   [携帯電話サービスの通信状況（地域別）](https://www.docomo.ne.jp/info/status/?icid=CRP_drawer_to_CRP_INFO_status)
                    
                *   [工事のお知らせ](https://www.docomo.ne.jp/info/construction/?icid=CRP_drawer_to_CRP_INFO_construction)
                    
                
    *   *   企業情報
        *   *   企業情報
                
                *   [企業情報 トップ](https://www.docomo.ne.jp/corporate/?icid=CRP_drawer_to_CRP_CORP)
                    
                *   [あなたとドコモ](https://www.docomo.ne.jp/corporate/anatatodocomo/?icid=CRP_drawer_to_CRP_CORP_anatatodocomo)
                    
                *   [企業理念・ビジョン](https://www.docomo.ne.jp/corporate/philosophy_vision/?icid=CRP_drawer_to_CRP_CORP_philosophy_vision)
                    
                *   [会社案内](https://www.docomo.ne.jp/corporate/about/?icid=CRP_drawer_to_CRP_CORP_about)
                    
                *   [サステナビリティ](https://www.docomo.ne.jp/corporate/csr/?icid=CRP_drawer_to_CRP_CORP_csr)
                    
                *   [技術とあんしん](https://www.docomo.ne.jp/corporate/technology_safety/?icid=CRP_drawer_to_CRP_CORP_technology_safety)
                    
                *   [IR情報](https://www.docomo.ne.jp/corporate/ir/library/?icid=CRP_drawer_to_CRP_CORP_ir_library)
                    
                *   [採用情報](https://www.docomo.ne.jp/corporate/recruit/?icid=CRP_drawer_to_CRP_CORP_recruit)
                    
                *   [NTTドコモグループ_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://nttdocomo-group.com/index.html)
                    
                
*   *   地域別情報
        
        *   [北海道](https://www.docomo.ne.jp/hokkaido/?icid=CRP_drawer_to_hokkaido)
            
        *   [東北](https://www.docomo.ne.jp/tohoku/?icid=CRP_drawer_to_tohoku)
            
        *   [関東・甲信越](https://www.docomo.ne.jp/kanto/?icid=CRP_drawer_to_kanto)
            
        *   [東海](https://www.docomo.ne.jp/tokai/?icid=CRP_drawer_to_tokai)
            
        *   [北陸](https://www.docomo.ne.jp/hokuriku/?icid=CRP_drawer_to_hokuriku)
            
        *   [関西](https://www.docomo.ne.jp/kansai/?icid=CRP_drawer_to_kansai)
            
        *   [中国](https://www.docomo.ne.jp/chugoku/?icid=CRP_drawer_to_chugoku)
            
        *   [四国](https://www.docomo.ne.jp/shikoku/?icid=CRP_drawer_to_shikoku)
            
        *   [九州・沖縄](https://www.docomo.ne.jp/kyushu/?icid=CRP_drawer_to_kyushu)
            
        
    *   地域別情報
        
        *   [北海道](https://www.docomo.ne.jp/hokkaido/?icid=CRP_drawer_to_hokkaido)
            |
        *   [東北](https://www.docomo.ne.jp/tohoku/?icid=CRP_drawer_to_tohoku)
            |
        *   [関東・甲信越](https://www.docomo.ne.jp/kanto/?icid=CRP_drawer_to_kanto)
            |
        *   [東海](https://www.docomo.ne.jp/tokai/?icid=CRP_drawer_to_tokai)
            |
        *   [北陸](https://www.docomo.ne.jp/hokuriku/?icid=CRP_drawer_to_hokuriku)
            |
        *   [関西](https://www.docomo.ne.jp/kansai/?icid=CRP_drawer_to_kansai)
            |
        *   [中国](https://www.docomo.ne.jp/chugoku/?icid=CRP_drawer_to_chugoku)
            |
        *   [四国](https://www.docomo.ne.jp/shikoku/?icid=CRP_drawer_to_shikoku)
            |
        *   [九州・沖縄](https://www.docomo.ne.jp/kyushu/?icid=CRP_drawer_to_kyushu)
            
        
*   *   法人のお客さま
        
        *   [NTTドコモビジネス_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.ntt.com/index.html)
            
        *   [NTTドコモソリューションズ_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.nttcom.co.jp/)
            
        *   [NTTドコモ・グローバル](https://www.docomo.ne.jp/global/?icid=CRP_drawer_to_CRP_global)
            
        
    *   法人のお客さま
        
        *   [NTTドコモビジネス_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.ntt.com/index.html)
            |
        *   [NTTドコモソリューションズ_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.nttcom.co.jp/)
            |
        *   [NTTドコモ・グローバル](https://www.docomo.ne.jp/global/?icid=CRP_drawer_to_CRP_global)
            
        

[![](https://www.docomo.ne.jp/assets/content/dam/corp/jp/ja/common/images/logo/cmn-rwd-d-point-club-logo.svg)](https://www.docomo.ne.jp/charge/eximo/)

*   [dアカウントでもっと便利に](https://www.docomo.ne.jp/utility/daccount/?icid=CRP_drawer_to_CRP_UTI_daccount)
    
*   [別のIDでログイン](https://cfg.smt.docomo.ne.jp/auth/cgi/anidlogin?rl=https%3A%2F%2Fwww.docomo.ne.jp%2F)
    
*   [ログアウト](https://www.docomo.ne.jp/mydocomo/utility/confirm_logout/index.html)
    
*   [会員情報確認・変更_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon-white.svg)_](https://profile.smt.docomo.ne.jp/VIEW_ESITE/mem/sc/main.jsp?nid=MEG002006BJP)
    
*   [ログインでお困りの方_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon-white.svg)_](https://id.smt.docomo.ne.jp/src/utility/idpw_forget.html)
    
*   [２段階認証のお願い_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon-white.svg)_](https://id.smt.docomo.ne.jp/src/utility/sp/twostepauth.html)
    

オートログイン中

[![ランク](https://www.docomo.ne.jp/charge/eximo/#)](https://dpoint.docomo.ne.jp/member/stage_info/index.html)

* * *

[うち期間・用途限定](https://www.docomo.ne.jp/charge/eximo/)

* * *

[![ドコモビジネスメンバーズ](https://www.docomo.ne.jp/images_osp/common/newhf/ico/ico_businessmembers.png)](https://www.docomo.ne.jp/charge/eximo/)

*   [別のIDでログイン](https://cfg.smt.docomo.ne.jp/auth/cgi/anidlogin?rl=https%3A%2F%2Fwww.docomo.ne.jp%2F)
    
*   [ログアウト](https://www.docomo.ne.jp/mydocomo/utility/confirm_logout/index.html)
    
*   [会員情報確認・変更_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon-white.svg)_](https://profile.smt.docomo.ne.jp/VIEW_ESITE/mem/sc/main.jsp?nid=MEG002006BJP)
    
*   [２段階認証のお願い_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon-white.svg)_](https://id.smt.docomo.ne.jp/src/utility/sp/twostepauth.html)
    

*   [CMギャラリー_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon.svg)_](https://www.youtube.com/playlist?list=PLB334710B4B8111A8)
    
*   [よくあるご質問](https://faq.front.smt.docomo.ne.jp/?utm_source=docomo.ne.jp&utm_medium=api_linkage&utm_campaign=api_CRP_TOP)
    
*   [見やすさ・使いやすさの調整](https://www.docomo.ne.jp/utility/term/web_accessibility/faciliti/?icid=CRP_drawer_to_CRP_UTI_term_web_accessibility_faciliti)
    
*   [パーソナルデータ（個人情報など）について](https://www.docomo.ne.jp/utility/personal_data/?icid=CRP_drawer_to_CRP_UTI_personal_data)
    

*    [![](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-daccount-logo.svg) ログインする](https://www.docomo.ne.jp/charge/eximo/)
    
*   [![別ウィンドウで開きます。のりかえ（MNP）](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-online-mnp-icon_smt.png)](https://onlineshop.docomo.ne.jp/special-contents/mnp?xcid=OLS_special-contents_mnp_flow_from_CRP_TOP_mnp_btn)
    

*   [![](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-switch-online-icon.svg)機種変更](https://www.docomo.ne.jp/support/switch_online/?icid=CRP_outerhead_to_SUP_switch_online)
    
*   [![](https://www.docomo.ne.jp/images_osp/common/newhf/logo/cmn-rwd-d-point-club-logo.svg)\
    \
    P\
    \
    ![](https://www.docomo.ne.jp/charge/eximo/)](https://www.docomo.ne.jp/charge/eximo/)
    

[![ドコモビジネスメンバーズ](https://www.docomo.ne.jp/images_osp/common/newhf/ico/ico_businessmembers.png)](https://www.docomo.ne.jp/charge/eximo/)

お客さまの設定により、お客さま情報が「非表示」となっております。お客さま情報を表示するにはdアカウントでログインしてください。  
[お客さま情報表示について](https://www.docomo.ne.jp/charge/eximo/)
へ

[お客さま情報表示について](https://www.docomo.ne.jp/charge/eximo/)
へ

*   [ホーム](https://www.docomo.ne.jp/)
    
*   [料金・割引](https://www.docomo.ne.jp/charge/)
    
*   [料金プラン](https://www.docomo.ne.jp/charge/#plan)
    
*   eximo

eximo
=====

**「eximo」「irumo」「eximo ポイ活」は、2025年6月4日（水曜）をもって新規お申込み受付を終了いたしました。**
------------------------------------------------------------------

現在受付中の料金プランにつきましては、[こちら](https://www.docomo.ne.jp/charge/?icid=CRP_CHA_eximo_to_CRP_CHA)
をご確認ください。

「eximo」は音声プラン、ISPサービス、データ通信をワンパッケージにした料金プランであり、データ容量が小容量から大容量まで多様なニーズにお応えする家族でおトクな料金プランです。

![ドコモのド定番！ eximo ギガを使った段階に応じてお支払い 割引・特典／キャンペーンが充実 店舗でもオンラインでもいつでも相談可](https://www.docomo.ne.jp/flcache_data/charge/eximo/images/img_01_pc.png?ver=1731642971)![ドコモのド定番！ eximo ギガを使った段階に応じてお支払い 割引・特典／キャンペーンが充実 店舗でもオンラインでもいつでも相談可](https://www.docomo.ne.jp/flcache_data/charge/eximo/images/img_01_smt.png?ver=1731642971)

このページの内容
--------

*   [eximoとは__](https://www.docomo.ne.jp/charge/eximo/#anc-01)
    
*   [ご利用料金__](https://www.docomo.ne.jp/charge/eximo/#anc-02)
    
*   [割引・特典__](https://www.docomo.ne.jp/charge/eximo/#anc-03)
    
*   [オプション__](https://www.docomo.ne.jp/charge/eximo/#anc-04)
    
*   [ご注意事項__](https://www.docomo.ne.jp/charge/eximo/#anc-05)
    
*   [eximoご契約者向けキャンペーン__](https://www.docomo.ne.jp/charge/eximo/#anc-07)
    

*   [eximoとは__](https://www.docomo.ne.jp/charge/eximo/#anc-01)
    
*   [ご利用料金__](https://www.docomo.ne.jp/charge/eximo/#anc-02)
    
*   [割引・特典__](https://www.docomo.ne.jp/charge/eximo/#anc-03)
    
*   [オプション__](https://www.docomo.ne.jp/charge/eximo/#anc-04)
    
*   [ご注意事項__](https://www.docomo.ne.jp/charge/eximo/#anc-05)
    
*   [eximoご契約者向けキャンペーン__](https://www.docomo.ne.jp/charge/eximo/#anc-07)
    

eximoとは
-------

eximoの料金プランの特徴から、おすすめなお客様・他プランとの違いをご説明いたします。

### どんな人におすすめ？

![](https://www.docomo.ne.jp/flcache_data/charge/eximo/images/img_02.png?ver=1731642971)

ギガ利用段階に応じたお支払いだから…

使わない月はおトクに  
たくさん使う月はギガを気にせずにスマホを使いたい人におすすめ

![](https://www.docomo.ne.jp/flcache_data/charge/eximo/images/img_03.png?ver=1731642971)

ドコモショップでのサポートが充実…

スマートフォンの利用に不安がある方におすすめ

### 他プランとの違いは？

ドコモが提供する4つのプランを8つの軸で比較  
割引・サービスの充実がeximoの魅力！

（税込）

        
|     | データ容量 | 月額料金 | 割引額 | 決済特典 | お手続き窓口 | 購入後  <br>店頭サポート | 家族内電話※[10](https://www.docomo.ne.jp/charge/eximo/#notice10) | ドコモメール |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| eximo | 1GB～無制限※[1](https://www.docomo.ne.jp/charge/eximo/#notice01) | 4,565円～  <br>7,315円 | **最大  <br>\-2,387円**  <br>※[3](https://www.docomo.ne.jp/charge/eximo/#notice03) | \-  | **オンライン  <br>店舗・電話** | **無料**※[8](https://www.docomo.ne.jp/charge/eximo/#notice08)<br>  <br>（一部有料サポート） | **無料** | **無料** |
| eximo  <br>ポイ活 | ギガ無制限※[1](https://www.docomo.ne.jp/charge/eximo/#notice01) | 10,615円 | dポイント  <br>上限5,000ポイント  <br>贈呈※[6](https://www.docomo.ne.jp/charge/eximo/#notice06)<br>,[7](https://www.docomo.ne.jp/charge/eximo/#notice07) |
| ahamo | 30GB | 2,970円 | \-  | \-  | オンライン | 有料  <br>WEB申込み・手続き  <br>サポート※[9](https://www.docomo.ne.jp/charge/eximo/#notice09)<br>のみ | 5分間無料※[11](https://www.docomo.ne.jp/charge/eximo/#notice11)<br>  <br>（5分以上22円／30秒） | 有料※[12](https://www.docomo.ne.jp/charge/eximo/#notice12)<br>  <br>（330円／月）  <br>ドコモメール  <br>持ち運び |
| irumo | 0.5GB※[2](https://www.docomo.ne.jp/charge/eximo/#notice02)<br>  <br>3／6／9GB | 550円～  <br>3,377円 | 最大  <br>\-1,287円  <br>※[4](https://www.docomo.ne.jp/charge/eximo/#notice04)<br>,[5](https://www.docomo.ne.jp/charge/eximo/#notice05) | \-  | オンライン  <br>店舗・電話 | 有料  | 有料（22円／30秒） | 有料※[12](https://www.docomo.ne.jp/charge/eximo/#notice12)<br>  <br>（330円／月）  <br>ドコモメール  <br>オプション |

![スクロール](https://www.docomo.ne.jp/images_osp/common/img/img_guide_scroll01@2x.png)

1.  ネットワーク混雑時、大量通信時等に通信制限がかかる場合があります。
    
2.  0.5GBプランの場合、通信速度が最大3Mbpsとなります。
    
3.  「dカードお支払割」（▲187円／月）、「みんなドコモ割」（最大▲1,100円／月）、「『ドコモ光セット割』または『home 5G セット割』」（▲1,100円／月）の適用
    
4.  「ドコモ光セット割」／「home 5G セット割」（▲1,100円／月）、「dカードお支払割」（▲187円／月）の適用
    
5.  0.5GBプランの場合、ドコモ光セット割／home 5G セット割、dカードお支払割は対象外です。
    
6.  税込 約50,000円以上（dカード3%／dカード GOLD U5%／dカードGOLD5%／dカードPLATINUM10%還元）のお買い物で上限5,000ポイント贈呈
    
7.  進呈するポイントは期間・用途限定です。（有効期限：進呈日から93日間）進呈の上限は、キャンペーンの特典により進呈するポイント数を合わせて、合計で5,000ポイント／月です。
    
8.  ドコモショップでの操作案内には一部を除き1,100円（税込）～2,200円（税込）かかります。
    
9.  お申込み・お手続き時の端末操作はお客さまご自身で実施いただきます。お手続きの補助を行うスタッフはお客さまの端末操作画面を拝見し、必要に応じて操作のご案内を行います。
    
10.  「家族」とは同一「ファミリー割引グループ」を指します。「ファミリー割引」をご契約の場合、同一「ファミリー割引」グループ内の国内通話料は無料となります。
    
11.  国内通話無料となる対象通話  
    ドコモ／他社携帯電話着、固定電話着、光／ IP電話着、時報（117）、番号案内通話料（104）※番号案内料を除く、災害対策伝言ダイヤル（171）  
    国内通話無料の対象外通話  
    海外での発着信、「WORLD CALL」、「SMS」、（0570）（0180）（0067）等から始まる他社が料金設定している他社接続サービス、（188）特番、（104）の番号案内料、衛星電話／衛星船舶電話、当社が指定する電話番号（機械的な発信などにより、長時間または多数の通信を一定期間継続して接続する電話番号）など、上記の対象通話以外への発信は定額の対象外となり、別途料金がかかります。
    
12.  プラン変更と同時にお申込みいただくことで、ドコモメールアドレス（@docomo.ne.jp）、クラウドに保存されたメールデータを引き続きご利用になれます。
    

ご利用料金
-----

（税込）

| 利用可能データ量※[13](https://www.docomo.ne.jp/charge/eximo/#notice13)<br>,[14](https://www.docomo.ne.jp/charge/eximo/#notice14) |
| --- |
| 無制限※[15](https://www.docomo.ne.jp/charge/eximo/#notice15) |

 
| 国内通話料 | SMS通信料 |
| --- | --- |
| 家族間通話：無料※[16](https://www.docomo.ne.jp/charge/eximo/#notice16)<br>  <br>家族以外への通話：  <br>22円／30秒 | SMS（国内）：3.3円／1通  <br>国際SMS※[17](https://www.docomo.ne.jp/charge/eximo/#notice17)<br>：50円／1通  <br>（受信無料） |

  ![その月にギガを使った段階に応じてお支払い ～1GB 基本料金 4,150円／月 （税込4,565円／月） 割引後料金 1,980円／月 （税込2,178円／月） 1GB～3GB 基本料金 5,150円／月 （税込5,665円／月） 割引後料金 2,980円／月 （税込3,278円／月） 3GB～無制限※15 基本料金 6,650円／月 （税込7,315円／月） 割引後料金 4,480円／月 （税込4,928円／月） みんなドコモ割（3回線以上）※18 -1,000円（税込1,100円） ドコモ光セット割／home 5Gセット割※19 -1,000円（税込1,100円） dカードお支払割※20 -170円（税込187円）](https://www.docomo.ne.jp/flcache_data/charge/eximo/images/img_04_pc.png?ver=1731642971) ![その月にギガを使った段階に応じてお支払い ～1GB 基本料金 4,150円／月 （税込4,565円／月） 割引後料金 1,980円／月 （税込2,178円／月） 1GB～3GB 基本料金 5,150円／月 （税込5,665円／月） 割引後料金 2,980円／月 （税込3,278円／月） 3GB～無制限※15 基本料金 6,650円／月 （税込7,315円／月） 割引後料金 4,480円／月 （税込4,928円／月） みんなドコモ割（3回線以上）※18 -1,000円（税込1,100円） ドコモ光セット割／home 5Gセット割※19 -1,000円（税込1,100円） dカードお支払割※20 -170円（税込187円）](https://www.docomo.ne.jp/flcache_data/charge/eximo/images/img_04_smt.png?ver=1731642971)    

（税込）

| eximo |     |     |
| --- | --- | --- |
| 月額料金※[21](https://www.docomo.ne.jp/charge/eximo/#notice21) | 無制限 | 7,315円 |
| 1GB～3GB | 5,665円 |
| ～1GB | 4,565円 |

1.  「5Gデータプラス」のペア回線が本料金プランとなる場合は、ペアとなるデータプランの当月のご利用可能データ量は最大30GBまでとなり、超過した場合は通信速度が送受信最大1Mbpsとなります。
    
2.  「eximo」は指定ISPサービスの契約が必須の料金プランです。記載の月額料金は指定ISPサービスの使用料（spモード月額300円分（税込330円））を含んだ金額となります。「mopera U スタンダードプラン」をご契約の場合、記載の月額使用料に追加で200円（税込220円）分の料金が発生します。
    
3.  ネットワーク混雑時・大量通信時などに通信制限がかかる場合があります。「5Gデータプラス」「データプラス」「データプラス（2019年9月30日以前お申込み）」をご契約の場合、ペア回線の利用可能データ量は30GBとなり、上限超過後は通信速度が送受信最大1Mbpsとなります。詳細は「5Gデータプラス」をご確認ください。
    
4.  「家族」とは、同一「ファミリー割引」グループをさします。「ファミリー割引」を契約の場合、同一「ファミリー割引」グループ内の国内通話料は無料となります。
    
5.  国際SMSには消費税は加算されません。
    
6.  同一「ファミリー割引」グループ内における音声通話が可能な料金プラン（「2in1」「キッズケータイプラス」「キッズケータイプラン」「irumo（0.5GB）」を除く）契約回線がカウント対象となります。
    
7.  同一「ファミリー割引」グループ内に「ドコモ光」「home 5Gプラン」の両方が存在する場合は、「ドコモ光セット割」が適用されます。月額料金が日割り計算となる場合は、割引額も日割り計算となります。 また、適用には「ドコモ光」もしくは「home 5Gプラン」のご契約が必要となり別途費用がかかります（「ドコモ光」の場合、プロバイダ込・1ギガ・解約金（戸建：5,500円（税込）／マンション：4,180円（税込））有で月4,400円（税込）～5,940円（税込）。「home 5G プラン」の場合、月5,280円（税込）と別途HR01／HR02のご購入が必要）。
    
8.  各ご利用月の末日時点でご利用料金のお支払い方法をdカード／dカード GOLD U／dカード GOLD／dカード PLATINUM（家族カード含む）に設定（一括請求グループは代表回線での設定）をされている方が対象です。
    
9.  「eximo」をご契約中のお客さまは、当月の「世界そのままギガ」をご利用したデータ量が30GBを超過した場合は、残りの利用可能データ量にかかわらず、当月末まで「世界そのままギガ」ご利用時の通信速度が送受信最大1Mbpsとなります。「5Gデータプラス」をご契約の場合、ペア回線（本料金プラン）の「世界そのままギガ」と合算したご利用データ量が30GBを超過した場合、「5Gデータプラス」及びペア回線が当月末まで「世界そのままギガ」ご利用時の通信速度が送受信最大1Mbpsとなります。
    

*   別途機種代金・通話料（国内通話の場合30秒ごとに22円（税込））などがかかります。
    

割引・特典
-----

「eximo」ご契約の方は、ご利用可能な割引・特典が充実！割引・特典の詳細内容をご確認ください。

（税込）

 
| 対象割引 | 割引額 |
| --- | --- |
| [みんなドコモ割](https://www.docomo.ne.jp/charge/minna_docomo/?icid=CRP_CHA_eximo_txt_to_CRP_CHA_minna_docomo)<br>（3回線以上） | \-1,100円 |
| [ドコモ光セット割](https://www.docomo.ne.jp/charge/hikari_set/?icid=CRP_CHA_eximo_txt_to_CRP_CHA_hikari_set)<br>／[home 5Gセット割](https://www.docomo.ne.jp/charge/home_5g_set/?icid=CRP_CHA_eximo_txt_to_CRP_CHA_home_5g_set) | \-1,100円 |
| [dカードお支払額](https://www.docomo.ne.jp/charge/dcard_oshiharai/?icid=CRP_CHA_eximo_txt_to_CRP_CHA_dcard_oshiharai) | \-187円 |

### みんなドコモ割

*   [### **ドコモを使う人が多いほどおトクに！**](javascript:void(0);)
    
    同一「ファミリー割引」グループ内の対象音声回線数に応じて、月額料金を各回線ごとに**最大1,100円（税込）割引**します。
    
    *   同一「ファミリー割引」グループ内における音声通話が可能な料金プラン（「2in1」、「キッズケータイプラス」、「キッズケータイプラン」「irumo（0.5GB）」を除く）契約回線がカウント対象となります。
        
    
    （税込）
    
       
    |     | 1回線 | 2回線 | 3回線 |
    | --- | --- | --- | --- |
    | 割引額 | ―   | \-550円 | \-1,100円 |
    
    [みんなドコモ割 __](https://www.docomo.ne.jp/charge/minna_docomo/?icid=CRP_CHA_eximo_to_CRP_CHA_minna_docomo)
    
    [閉じる](https://www.docomo.ne.jp/charge/eximo/#acc-point01)
    

### ドコモ光セット割／home 5G セット割

*   [### **ネットとスマホをまとめるとおトクに！**](javascript:void(0);)
    
    同一「ファミリー割引」グループ内に「ドコモ光」「home 5G」をご契約している回線がある場合、「eximo」の月額料金から**永年1,100円（税込）割引**します。
    
    *   同一「ファミリー割引」グループ内に「ドコモ光」「home 5G プラン」の両方が存在する場合は、「ドコモ光セット割」が適用されます。月額料金が日割り計算となる場合は、割引額も日割り計算となります。
        
    
    *   [ドコモ光セット割__](https://www.docomo.ne.jp/charge/hikari_set/?icid=CRP_CHA_eximo_to_CRP_CHA_hikari_set)
        
    *   [home 5G セット割__](https://www.docomo.ne.jp/charge/home_5g_set/?icid=CRP_CHA_eximo_to_CRP_CHA_home_5g_set)
        
    
    [閉じる](https://www.docomo.ne.jp/charge/eximo/#acc-point02)
    

### dカードお支払割

*   [### **月額料金をdカードでお支払いするとおトクに！**](javascript:void(0);)
    
    ご利用月の末日時点でご利用料金のお支払方法をdカード／dカード GOLD U／dカード GOLD／dカード PLATINUM（家族カード含む）に設定していただいている場合、「eximo」の月額料金が**187円（税込）割引**になります。
    
    [dカードお支払割__](https://www.docomo.ne.jp/charge/dcard_oshiharai/?icid=CRP_CHA_eximo_to_CRP_CHA_dcard_oshiharai)
    
    [閉じる](https://www.docomo.ne.jp/charge/eximo/#acc-point03)
    

 [![My docomo ドコモユーザー向け 契約内容・料金確認 別ウインドウが開きます](https://www.docomo.ne.jp/charge/images/common/bnr_mydocomo01_pc.png?ver=1731642971) ![My docomo ドコモユーザー向け 契約内容・料金確認 別ウインドウが開きます](https://www.docomo.ne.jp/charge/images/common/bnr_mydocomo01_smt.png?ver=1731642971)](https://www.docomo.ne.jp/mydocomo/?icid=CRP_CHA_eximo_to_CRP_MYD)

オプション
-----

ご利用状況・ニーズに合わせて、選べるオプション。  
オンラインでご契約の場合、プランご契約後、別途お申込みが必要となります。ご希望のオプション詳細・手続き方法をご確認ください。

### 音声オプション

お申込み：必要

*   [### **ご家族以外とも通話をする方におすすめ**  \
    月額使用料：880円～](javascript:void(0);)
    
    利用状況に応じて、「かけ放題オプション」・「5分通話無料オプション」からお選びいただけます。
    
    *   [![かけ放題オプション](https://www.docomo.ne.jp/charge/images/common/ico_houdai.png?ver=1731642971)\
        \
        **かけ放題オプション  \
        **1,980円／月****\
        \
        国内通話かけ放題 ※22 __](https://www.docomo.ne.jp/charge/onsei_option/?icid=CRP_CHA_eximo_txt01_to_CRP_CHA_onsei_option)
        
    *   [![5分通話無料オプション](https://www.docomo.ne.jp/charge/images/common/ico_5min.png?ver=1731642971)\
        \
        **5分通話無料オプション  \
        **880円／月****\
        \
        国内通話\
        \
        *   5分以内：無料※23\
            \
        *   5分超過分：30秒あたり22円\
            \
        \
        __](https://www.docomo.ne.jp/charge/onsei_option/?icid=CRP_CHA_eximo_txt02_to_CRP_CHA_onsei_option)
        
    
    _+_音声オプションをご契約の方は  
    留守番電話・キャッチホンが実質無料※[24](https://www.docomo.ne.jp/charge/eximo/#notice24)
    ,[25](https://www.docomo.ne.jp/charge/eximo/#notice25)
    ,[26](https://www.docomo.ne.jp/charge/eximo/#notice26)
    
    *   [![留守番電話](https://www.docomo.ne.jp/charge/images/common/ico_answer_phone.png?ver=1731642971)\
        \
        **留守番電話**\
        \
        **330円／月→ **0円／月****  \
        （定額料割引：-330円／月） __](https://www.docomo.ne.jp/service/answer_phone/?icid=CRP_CHA_eximo_to_CRP_SER_answer_phone)
        
    *   [![キャッチホン](https://www.docomo.ne.jp/charge/images/common/ico_catch_phone.png?ver=1731642971)\
        \
        **キャッチホン**\
        \
        **220円／月→ **0円／月****  \
        （定額料割引：-220円／月） __](https://www.docomo.ne.jp/service/catch_phone/?icid=CRP_CHA_eximo_to_CRP_SER_catch_phone)
        
    
    [音声オプションお申込み_![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://mydocomo.docomo.ne.jp/procedure/process?pid=203&xcid=MYD_procedure_from_CRP_CHA_eximo)
     
    
    1.  国内通話無料となる対象通話  
        ドコモ／他社携帯電話着、固定電話着、光／IP電話着、時報（117）、番号案内通話料（104）※番号案内料を除く、災害対策伝言ダイヤル（171）  
        国内通話無料の対象外通話  
        海外での発着信、「WORLD CALL」、「SMS」、（0570）（0180）（0067）等から始まる他社が料金設定している他社接続サービス、（188）特番、（104）の番号案内料、衛星電話／衛星船舶電話、当社が指定する電話番号（機械的な発信などにより、長時間または多数の通信を一定期間継続して接続する電話番号）など、上記の対象通話以外への発信は定額の対象外となり、別途料金がかかります。
        
    2.  1回あたり5分以内の通話が、回数無制限で定額対象となります。ただし、1回あたりの通話時間が5分を超過した場合、超過分について30秒ごとに22円（税込）の通話料がかかります。
        
    3.  「かけ放題オプション」または「5分通話無料オプション」をご契約と同月内に、留守番電話／キャッチホンのいずれかまたは両方をご契約されている場合、留守番電話／キャッチホンのいずれかまたは両方の月額料金を割引いたします。
        
    4.  留守番電話またはキャッチホンを月途中で契約もしくは解約した場合、割引適用額も留守番電話またはキャッチホンのご利用日数に応じて日割りとなります。
        
    5.  2024年6月1日（土曜）以降、「かけ放題オプション」または「5分通話無料オプション」を翌月適用でご契約された場合も、翌月適用お申込完了日の当月から留守番電話またはキャッチホンのいずれかまたは両方の月額料金を割り引きします。（ご契約内容一覧、請求書には「音声OP定額料当月割引」と表示されます。）  
        上記の翌月適用お申込時の割引は、翌月適用をキャンセルされた場合、適用されません。
        
    
    [閉じる](https://www.docomo.ne.jp/charge/eximo/#acc-point04)
    

### データ使用量制限

お申込み：必要

*   [### **スマホの使いすぎを防ぎたい・使用データ量の目安を把握したい方におすすめ**  \
    月額使用料：無料](javascript:void(0);)
    
    ご利用ニーズに応じて、「上限設定オプション」「データ量到達通知サービス」からお選びいただけます。
    
    *   [![上限設定オプション](https://www.docomo.ne.jp/charge/images/common/ico_upper_limit.png?ver=1731642971)\
        \
        **上限設定オプション**  \
        **無料**\
        \
        通常速度での利用可能  \
        データ量上限設定 __](https://www.docomo.ne.jp/charge/upper_limit_option/?icid=CRP_CHA_eximo_to_CRP_CHA_upper_limit_option)
        
    
    [お申込み_![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://payment2.smt.docomo.ne.jp/pcguide/charges/gkzdp002.srv?xcid=MYD_pcguide_charges_from_CRP_CHA_eximo)
    
    *   [![データ量到達通知サービス](https://www.docomo.ne.jp/charge/images/common/ico_data.png?ver=1727763672)\
        \
        **データ量到達通知サービス**  \
        **無料**\
        \
        指定したデータ量に達した場合、  \
        メールでお知らせ __](https://www.docomo.ne.jp/charge/online_notification_service/?icid=CRP_CHA_eximo_to_CRP_CHA_online_notification_service)
        
    
    [お申込み_![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://mydocomo.docomo.ne.jp/procedure/process?pid=234&xcid=MYD_procedure_from_CRP_CHA_eximo)
     
    
    [閉じる](https://www.docomo.ne.jp/charge/eximo/#acc-point05)
    

### テザリング

お申込み：不要

*   [### **外出先でもパソコンやゲーム機でインターネットを利用したい方におすすめ**  \
    月額使用料：無料](javascript:void(0);)
    
    eximoならテザリングも無制限でご利用いただけます。
    
    *   [![テザリング](https://www.docomo.ne.jp/charge/images/common/ico_tethering.png?ver=1731642971)\
        \
        **テザリング**  \
        **無料**\
        \
        スマートフォンなどに接続し、  \
        外部機器でインターネット利用可能 __](https://www.docomo.ne.jp/service/tethering/?icid=CRP_CHA_eximo_to_CRP_SER_tethering)
        
    
    [閉じる](https://www.docomo.ne.jp/charge/eximo/#acc-point06)
    

ご注意事項
-----

*   「eximo」は5G契約の料金プランとなり、対応端末のご利用が必要になります。ドコモでご購入いただいた5G端末（スマホ）であればご利用になれます。
    
    *   ドコモ以外の端末をご利用の場合は、端末が実装している周波数帯がドコモが提供している周波数帯とあっているかご確認ください。
        
    
*   4G端末をご利用の方はご自身の端末がご利用可能か[4G対応端末一覧（PDF形式：330KB）_PDF_](https://www.docomo.ne.jp/binary/pdf/charge/eximo/notice/supported_phones.pdf?ver=1758865571)
    よりご確認ください。
    
    *   4G対応機種をご利用中かつSIM形状の変更が必要な方・SIM形状の変更が必要な方は、「ドコモオンラインショップ」または「店頭」でのお申込みとなります。
        
    
*   未成年の方は、ドコモオンラインショップでの購入が不可となっております。お申込みいただいても、購入できませんのでご注意ください。
    

その他「eximo」に関する注意事項は、お申込み前に、必ずお読みください。

[ご注意事項__](https://www.docomo.ne.jp/charge/eximo/notice.html?icid=CRP_CHA_eximo_to_CRP_CHA_eximo)

eximoご契約者様向けキャンペーン
------------------

「eximo」をご契約の方に、おトクなお知らせ！うれしい特典もついてきます。

*   [![ドコモからAmazonプライム登録で毎月dポイント還元！](https://www.docomo.ne.jp/flcache_data/service/eximo/image/20240531_amazonprime.png?ver=1745283611)\
    \
    ### Amazonプライム\
    \
    ドコモからAmazonプライム登録で毎月dポイント還元！\
    \
    ![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)](https://ssw.web.docomo.ne.jp/prime/?utm_source=corp_top&utm_medium=free-display&utm_campaign=ap_202405_ap_0000096)
    
*   [![dポイント（期間・限定）還元でおトク！ 爆アゲセレクション](https://www.docomo.ne.jp/flcache_data/service/eximo/image/20230306_bakuage_smt.jpg?ver=1749049282)\
    \
    ### 爆アゲセレクション\
    \
    あの人気サブスクが賢くおトクに！月額料金の10～25％相当のdポイント還元！\
    \
    ![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)](https://ssw.web.docomo.ne.jp/bakuage/?icid=CRP_CHA_eximo_to_CRP_bakuage)
    
*   [![ディズニープラスの月額料金から毎月1,140円が最大6か月間割引](https://www.docomo.ne.jp/flcache_data/service/eximo/image/20250501_disney1140.jpg?ver=1746025212)\
    \
    ### ディズニープラスの月額料金が最大6か月間割引！\
    \
    セット割でディズニープラスがお得！\
    \
    ![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)](https://service.smt.docomo.ne.jp/site/special/src/disneyplus_campaign_index.html?ex_cmp=dp_ddcm_corp_rec_set&utm_source=corp_rec&utm_medium=free-display&utm_campaign=dp_202006_set)
    

[キャンペーン・特典__](https://www.docomo.ne.jp/campaign_event/?icid=CRP_CHA_eximo_to_CRP_CAM)

*   [### Amazonプライム\
    \
    ![ドコモからAmazonプライム登録で毎月dポイント還元！](https://www.docomo.ne.jp/flcache_data/service/eximo/image/20240531_amazonprime.png?ver=1745283611)\
    \
    ドコモからAmazonプライム登録で毎月dポイント還元！\
    \
    ![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)](https://ssw.web.docomo.ne.jp/prime/?utm_source=corp_top&utm_medium=free-display&utm_campaign=ap_202405_ap_0000096)
    
*   [### 爆アゲセレクション\
    \
    ![dポイント（期間・限定）還元でおトク！ 爆アゲセレクション](https://www.docomo.ne.jp/flcache_data/service/eximo/image/20230306_bakuage_smt.jpg?ver=1749049282)\
    \
    あの人気サブスクが賢くおトクに！月額料金の10～25％相当のdポイント還元！\
    \
    ![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)](https://ssw.web.docomo.ne.jp/bakuage/?icid=CRP_CHA_eximo_to_CRP_bakuage)
    
*   [### ディズニープラスの月額料金が最大6か月間割引！\
    \
    ![ディズニープラスの月額料金から毎月1,140円が最大6か月間割引](https://www.docomo.ne.jp/flcache_data/service/eximo/image/20250501_disney1140.jpg?ver=1746025212)\
    \
    セット割でディズニープラスがお得！\
    \
    ![別ウインドウが開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)](https://service.smt.docomo.ne.jp/site/special/src/disneyplus_campaign_index.html?ex_cmp=dp_ddcm_corp_rec_set&utm_source=corp_rec&utm_medium=free-display&utm_campaign=dp_202006_set)
    

[キャンペーン・特典__](https://www.docomo.ne.jp/campaign_event/?icid=CRP_CHA_eximo_to_CRP_CAM)

* * *

*   **「eximo」の詳細については、「[提供条件書](https://www.docomo.ne.jp/support/utilization_notice/document/?icid=CRP_CHA_eximo_to_CRP_SUP_utilization_notice_document)
    」をご確認ください。**
    

*   [![別ウインドウで開きます Get Adobe Acrobat Reader](https://www.docomo.ne.jp/images_osp/common/bnr/bnr_adobe_reader01.png)](https://get.adobe.com/jp/reader/)
    
    PDF形式のファイルをご覧いただくには、アドビシステムズ社から無償提供されている  
    [![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/ico/ico_window01.png)Adobe® Reader®](https://get.adobe.com/jp/reader/)
    プラグインが必要です。「Adobe® Acrobat®」でご覧になる場合は、バージョン10以降をご利用ください。
    

×

#### プランのみ契約

[ドコモ回線から  \
eximoへ変更\
\
_![別ウインドウで開きます。](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://mydocomo.docomo.ne.jp/procedure/process?pid=201&xcid=MYD_procedure_from_CRP_CHA_eximo)
[他社・ahamo回線から  \
eximoへ変更※\
\
_![別ウインドウで開きます。](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://onlineshop.smt.docomo.ne.jp/sim-card/index.html?xcid=OLS_sim-card_from_CRP_CHA_eximo)
[eximoを新規契約※\
\
_![別ウインドウで開きます。](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://onlineshop.smt.docomo.ne.jp/sim-card/index.html?xcid=OLS_sim-card_from_CRP_CHA_eximo)

*   他社・ahamo回線からプラン変更／新規契約される  
    お客様は、SIMカードの発行手続きが必要です。
    

閉じる

×

#### プランのみ契約

[ドコモ回線から  \
eximoへ変更\
\
_![別ウインドウで開きます。](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://mydocomo.docomo.ne.jp/procedure/process?pid=201&xcid=MYD_procedure_from_CRP_CHA_eximo)
[他社・ahamo回線から  \
eximoへ変更※\
\
_![別ウインドウで開きます。](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://onlineshop.smt.docomo.ne.jp/sim-card/index.html?xcid=OLS_sim-card_from_CRP_CHA_eximo)
[eximoを新規契約※\
\
_![別ウインドウで開きます。](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://onlineshop.smt.docomo.ne.jp/sim-card/index.html?xcid=OLS_sim-card_from_CRP_CHA_eximo)

*   他社・ahamo回線からプラン変更／新規契約される  
    お客様は、SIMカードの発行手続きが必要です。
    

閉じる

×

#### プランのみ契約

[ドコモ回線から  \
eximoへ変更\
\
_![別ウインドウで開きます。](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://mydocomo.docomo.ne.jp/procedure/process?pid=201&xcid=MYD_procedure_from_CRP_CHA_eximo)
[他社・ahamo回線から  \
eximoへ変更※\
\
_![別ウインドウで開きます。](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://onlineshop.smt.docomo.ne.jp/sim-card/index.html?xcid=OLS_sim-card_from_CRP_CHA_eximo)
[eximoを新規契約※\
\
_![別ウインドウで開きます。](https://www.docomo.ne.jp/images_osp/common/ico/ico_window03_v2.png)_](https://onlineshop.smt.docomo.ne.jp/sim-card/index.html?xcid=OLS_sim-card_from_CRP_CHA_eximo)

*   他社・ahamo回線からプラン変更／新規契約される  
    お客様は、SIMカードの発行手続きが必要です。
    

閉じる

[![このページのトップへ](https://www.docomo.ne.jp/images_osp/common/btn/btn_pagetop_01.png)](https://www.docomo.ne.jp/charge/eximo/#)

[料金・割引](https://www.docomo.ne.jp/charge/)

------------------------------------------

*   [料金プラン](https://www.docomo.ne.jp/charge/#plan)
    
*   *   [eximo ポイ活](https://www.docomo.ne.jp/charge/eximo_poikatsu/?dynaviid=case0017.dynavi)
        
    *   _eximo_
    *   [はじめてスマホプラン](https://www.docomo.ne.jp/charge/hajimete_plan/?dynaviid=case0017.dynavi)
        
    *   [U15はじめてスマホプラン](https://www.docomo.ne.jp/charge/u15_hajimete_plan/?dynaviid=case0017.dynavi)
        
    *   [5Gデータプラス](https://www.docomo.ne.jp/charge/5g-dataplus/?dynaviid=case0017.dynavi)
        

*   [ホーム](https://www.docomo.ne.jp/)
    
*   [料金・割引](https://www.docomo.ne.jp/charge/)
    
*   [料金プラン](https://www.docomo.ne.jp/charge/#plan)
    
*   eximo

  

[![お困りですか？](https://www.docomo.ne.jp/images_osp/common/chat_tool/bnr_chat_tool.svg)](https://tetsuduki-support.docomo.ne.jp/?utm_source=corp&utm_medium=free-display&utm_campaign=onsapo_)

  

このページの情報は役に立ちましたか？

*    はい
*    いいえ

送信する

このページの情報は役に立ちましたか？

*    はい
*    いいえ

送信する

ドコモサイトの改善のために、  
あなたの回答の理由を教えてください（問）
-------------------------------------

※「アンケートに回答する」ボタンを押すと、  
アンケート画面が開きます。

[アンケートに回答する](https://www.docomo.ne.jp/charge/eximo/#survey)

ご回答ありがとうございました
--------------

ご意見は今後のWebサイト改善の参考とさせていただきます。

*   データは匿名化されており、個人が特定されることはございません。また調査以外の目的で利用されることはございません。
    

  

NTTドコモサイトについてのアンケート
-------------------

差し支えなければ、以下のアンケートにもご協力ください。

※この画面を閉じて元のページに戻るには画面右上の「閉じる」を押してください。

### Q.お探しの情報はどのような情報でしたか？あてはまるものをすべて選択してください。

### Q.あなたの年齢をお答えください。

*   10代以下
*   20代
*   30代
*   40代
*   50代
*   60代
*   70代以上
*   回答しない

10代以下 20代 30代 選択してください 40代 50代 60代 70代以上 回答しない

### Q.このページが「役に立たなかった」と思われた点について、あてはまるものをすべて選択してください。

*   [ ] 知りたい情報が書かれていなかった
*   [ ] 必要な情報がまとまっていなかった
*   [ ] 知りたい内容までの適切な誘導がなかった
*   [ ] GoogleやYahoo！で検索しても目的のページが出てこなかった
*   [ ] このサイト内で検索しても目的のページが出てこなかった
*   [ ] どのキーワードで検索すればいいかわからなかった
*   [ ] 目的と違うページにたどり着いた
*   [ ] 見たい情報がどこにありそうか想定できなかった
*   [ ] 選択肢が紛らわしかった
*   [ ] クリックなど操作がしづらかった
*   [ ] 文章がわかりづらかった
*   [ ] 絵や画像がわかりづらかった
*   [ ] 表示されるのが遅かった
*   [ ] その他
*   [ ] あてはまるものはない

回答を送信する

NTTドコモサイトについてのアンケート
-------------------

### ご回答ありがとうございました。

※本アンケートに関する個人情報等の取扱いについては「[NTTドコモ プライバシーポリシー](https://www.docomo.ne.jp/utility/privacy/?icid=CRP_SURVEY_end_to_CRP_UTI_privacy)
」で定めています。

*   [お知らせ](https://www.docomo.ne.jp/info/?icid=CRP_common_footer_to_CRP_INFO)
    
*   [企業情報](https://www.docomo.ne.jp/corporate/?icid=CRP_common_footer_to_CRP_CORP)
    

* * *

*   [パーソナルデータ（個人情報など）について](https://www.docomo.ne.jp/utility/personal_data/?icid=CRP_common_footer_to_CRP_UTI_personal_data)
    
*   [プライバシーポリシー](https://www.docomo.ne.jp/utility/privacy/?icid=CRP_common_footer_to_CRP_UTI_privacy)
    
*   [サイトご利用にあたって](https://www.docomo.ne.jp/utility/term/?icid=CRP_common_footer_to_CRP_UTI_term)
    
*   [お客さまご利用端末からの情報の外部送信について](https://www.docomo.ne.jp/utility/term/?icid=CRP_common_footer_02_to_CRP_UTI_term#p09)
    
*   [見やすさ・使いやすさの調整](https://www.docomo.ne.jp/utility/term/web_accessibility/faciliti/?icid=CRP_common_footer_to_CRP_UTI_term_web_accessibility_faciliti)
    
*   [サイトメンテナンス情報_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon-white.svg)_](https://www.docomo.ne.jp/mydocomo/maint/?icid=CRP_common_footer_to_CRP_MYD_maint)
    
*   [サイトマップ](https://www.docomo.ne.jp/sitemap/?icid=CRP_common_footer_to_CRP_sitemap)
    
*   [ご意見・ご要望](https://www.docomo.ne.jp/support/inquiry/feedback/?icid=CRP_common_footer_to_CRP_SUP_inquiry_feedback)
    
*   [お問い合わせ](https://www.docomo.ne.jp/support/inquiry/?icid=CRP_common_footer_to_CRP_SUP_inquiry)
    
*   [NTTドコモグループ_![別ウインドウで開きます](https://www.docomo.ne.jp/images_osp/common/newhf/ico/cmn-rwd-new-window-icon-white.svg)_](https://nttdocomo-group.com/index.html)
    

© NTT DOCOMO

![閉じる](https://www.docomo.ne.jp/images_osp/common/smtnav/btn_smtmenu_01_close_crp.png)
